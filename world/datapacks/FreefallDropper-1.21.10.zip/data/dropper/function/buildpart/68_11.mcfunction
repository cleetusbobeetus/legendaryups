fill 402 293 276 402 296 276 minecraft:red_terracotta
fill 402 293 316 405 293 316 minecraft:red_terracotta
fill 403 293 277 404 293 277 minecraft:red_terracotta
fill 404 293 279 404 294 279 minecraft:stripped_oak_log
fill 404 293 281 404 294 281 minecraft:stripped_oak_log
fill 404 293 283 404 294 283 minecraft:stripped_oak_log
setblock 405 293 276 minecraft:red_terracotta
fill 405 293 277 405 293 278 minecraft:stripped_oak_log
fill 405 293 280 405 294 280 minecraft:stripped_oak_log
fill 405 293 282 405 294 282 minecraft:stripped_oak_log
fill 406 293 276 406 293 277 minecraft:stripped_oak_log
fill 406 293 279 406 294 279 minecraft:stripped_oak_log
fill 406 293 281 406 294 281 minecraft:stripped_oak_log
fill 406 293 283 406 294 283 minecraft:stripped_oak_log
setblock 406 293 316 minecraft:stripped_oak_log
fill 407 293 276 407 294 276 minecraft:red_terracotta
fill 407 293 278 407 294 278 minecraft:stripped_oak_log
fill 407 293 280 407 294 280 minecraft:stripped_oak_log
fill 407 293 282 407 294 282 minecraft:stripped_oak_log
setblock 407 293 285 minecraft:light[level=12]
setblock 407 293 292 minecraft:light[level=12]
setblock 407 293 299 minecraft:light[level=12]
setblock 407 293 306 minecraft:light[level=12]
setblock 407 293 313 minecraft:light[level=12]
fill 407 293 316 407 295 316 minecraft:red_terracotta
fill 408 293 277 408 294 277 minecraft:stripped_oak_log
fill 408 293 279 408 294 279 minecraft:stripped_oak_log
fill 408 293 281 408 294 281 minecraft:stripped_oak_log
fill 408 293 283 408 294 283 minecraft:stripped_oak_log
fill 409 293 276 409 294 276 minecraft:stripped_oak_log
fill 409 293 278 409 294 278 minecraft:stripped_oak_log
fill 409 293 280 409 294 280 minecraft:stripped_oak_log
fill 409 293 282 409 294 282 minecraft:stripped_oak_log
fill 410 293 277 410 294 277 minecraft:stripped_oak_log
fill 410 293 279 410 294 279 minecraft:stripped_oak_log
fill 410 293 281 410 294 281 minecraft:stripped_oak_log
fill 410 293 283 410 294 283 minecraft:stripped_oak_log
fill 413 293 280 413 294 280 minecraft:stripped_oak_log
fill 413 293 282 413 294 282 minecraft:stripped_oak_log
fill 413 293 284 413 294 284 minecraft:stripped_oak_log
fill 413 293 286 413 294 286 minecraft:stripped_oak_log
fill 413 293 288 413 294 288 minecraft:stripped_oak_log
fill 413 293 290 413 294 290 minecraft:stripped_oak_log
setblock 414 293 278 minecraft:light[level=12]
fill 414 293 281 414 294 281 minecraft:stripped_oak_log
fill 414 293 283 414 294 283 minecraft:stripped_oak_log
fill 414 293 285 414 294 285 minecraft:stripped_oak_log
fill 414 293 287 414 294 287 minecraft:stripped_oak_log
fill 414 293 289 414 294 289 minecraft:stripped_oak_log
setblock 414 293 292 minecraft:light[level=12]
setblock 414 293 299 minecraft:light[level=12]
setblock 414 293 306 minecraft:light[level=12]
setblock 414 293 313 minecraft:light[level=12]
fill 415 293 280 415 294 280 minecraft:stripped_oak_log
fill 415 293 282 415 294 282 minecraft:stripped_oak_log
fill 415 293 284 415 294 284 minecraft:stripped_oak_log
fill 415 293 286 415 294 286 minecraft:stripped_oak_log
fill 415 293 288 415 294 288 minecraft:stripped_oak_log
fill 415 293 290 415 294 290 minecraft:stripped_oak_log
fill 416 293 281 416 294 281 minecraft:stripped_oak_log
setblock 416 293 283 minecraft:stripped_oak_log
fill 416 293 285 417 293 285 minecraft:stripped_oak_log
fill 416 293 287 416 294 287 minecraft:stripped_oak_log
fill 416 293 289 416 294 289 minecraft:stripped_oak_log
setblock 416 293 300 minecraft:red_terracotta
setblock 416 293 301 minecraft:stripped_oak_log
fill 416 293 302 416 296 302 minecraft:red_terracotta
fill 417 293 278 417 294 278 minecraft:red_terracotta
setblock 417 293 280 minecraft:stripped_oak_log
fill 417 293 281 417 294 282 minecraft:red_terracotta
setblock 417 293 284 minecraft:red_terracotta
fill 417 293 286 417 294 288 minecraft:red_terracotta
setblock 417 293 290 minecraft:stripped_oak_log
setblock 417 293 295 minecraft:stripped_oak_log
fill 417 293 296 417 296 296 minecraft:red_terracotta
setblock 417 293 300 minecraft:stripped_oak_log
fill 417 293 301 417 296 301 minecraft:red_terracotta
setblock 417 293 305 minecraft:stripped_oak_log
fill 417 293 306 417 296 306 minecraft:red_terracotta
fill 377 294 276 377 294 278 minecraft:red_terracotta
setblock 377 294 279 minecraft:stripped_oak_log
fill 377 294 280 377 297 280 minecraft:red_terracotta
setblock 377 294 283 minecraft:red_terracotta
setblock 377 294 284 minecraft:stripped_oak_log
fill 377 294 285 377 297 285 minecraft:red_terracotta
setblock 377 294 289 minecraft:stripped_oak_log
fill 377 294 290 377 297 290 minecraft:red_terracotta
setblock 377 294 300 minecraft:red_terracotta
fill 377 294 305 377 297 305 minecraft:red_terracotta
fill 378 294 276 378 294 277 minecraft:red_terracotta
setblock 378 294 278 minecraft:stripped_oak_log
fill 378 294 279 378 297 279 minecraft:red_terracotta
setblock 378 294 283 minecraft:stripped_oak_log
fill 378 294 284 378 297 284 minecraft:red_terracotta
setblock 378 294 287 minecraft:red_terracotta
setblock 378 294 288 minecraft:stripped_oak_log
setblock 379 294 276 minecraft:red_terracotta
setblock 379 294 277 minecraft:stripped_oak_log
fill 379 294 278 379 297 278 minecraft:red_terracotta
setblock 379 294 282 minecraft:stripped_oak_log
fill 379 294 283 380 296 283 minecraft:red_terracotta
fill 379 294 285 379 294 286 minecraft:red_terracotta
setblock 380 294 276 minecraft:stripped_oak_log
fill 380 294 277 380 297 277 minecraft:red_terracotta
fill 380 294 279 380 294 280 minecraft:red_terracotta
setblock 380 294 281 minecraft:stripped_oak_log
fill 380 294 282 380 297 282 minecraft:red_terracotta
setblock 380 294 316 minecraft:stripped_oak_log
fill 381 294 276 381 297 276 minecraft:red_terracotta
fill 381 294 316 381 297 316 minecraft:red_terracotta
setblock 382 294 279 minecraft:stripped_oak_log
setblock 383 294 278 minecraft:stripped_oak_log
fill 383 294 279 383 297 279 minecraft:red_terracotta
setblock 384 294 277 minecraft:stripped_oak_log
fill 384 294 278 384 297 278 minecraft:red_terracotta
fill 384 294 315 385 294 315 minecraft:red_terracotta
setblock 385 294 276 minecraft:stripped_oak_log
fill 385 294 277 388 294 277 minecraft:red_terracotta
setblock 385 294 316 minecraft:stripped_oak_log
fill 386 294 276 389 294 276 minecraft:red_terracotta
setblock 386 294 315 minecraft:stripped_oak_log
fill 386 294 316 386 297 316 minecraft:red_terracotta
setblock 387 294 279 minecraft:stripped_oak_log
fill 387 294 315 387 297 315 minecraft:red_terracotta
setblock 388 294 278 minecraft:stripped_oak_log
setblock 388 294 315 minecraft:stripped_oak_log
setblock 389 294 277 minecraft:stripped_oak_log
setblock 389 294 278 minecraft:red_terracotta
setblock 390 294 276 minecraft:stripped_oak_log
fill 390 294 277 390 295 277 minecraft:red_terracotta
setblock 390 294 316 minecraft:stripped_oak_log
fill 391 294 276 391 296 276 minecraft:red_terracotta
fill 391 294 316 391 297 316 minecraft:red_terracotta
setblock 393 294 276 minecraft:red_terracotta
fill 397 294 316 399 294 316 minecraft:red_terracotta
fill 398 294 276 398 295 276 minecraft:red_terracotta
setblock 400 294 276 minecraft:stripped_oak_log
setblock 400 294 316 minecraft:stripped_oak_log
fill 401 294 276 401 297 276 minecraft:red_terracotta
fill 401 294 316 404 294 316 minecraft:red_terracotta
fill 402 294 277 403 294 277 minecraft:red_terracotta
fill 402 294 315 404 295 315 minecraft:red_terracotta
setblock 404 294 277 minecraft:stripped_oak_log
setblock 405 294 276 minecraft:stripped_oak_log
setblock 405 294 277 minecraft:red_terracotta
setblock 405 294 278 minecraft:stripped_oak_log
setblock 405 294 316 minecraft:stripped_oak_log
fill 406 294 276 406 296 276 minecraft:red_terracotta
setblock 406 294 277 minecraft:stripped_oak_log
fill 406 294 316 406 297 316 minecraft:red_terracotta
fill 416 294 282 416 294 284 minecraft:red_terracotta
setblock 416 294 285 minecraft:stripped_oak_log
setblock 416 294 300 minecraft:stripped_oak_log
fill 416 294 301 416 297 301 minecraft:red_terracotta
fill 416 294 303 416 294 304 minecraft:red_terracotta
setblock 417 294 279 minecraft:stripped_oak_log
setblock 417 294 280 minecraft:red_terracotta
setblock 417 294 284 minecraft:stripped_oak_log
fill 417 294 285 417 297 285 minecraft:red_terracotta
fill 417 294 290 417 294 293 minecraft:red_terracotta
setblock 417 294 294 minecraft:stripped_oak_log
fill 417 294 295 417 297 295 minecraft:red_terracotta
setblock 417 294 299 minecraft:stripped_oak_log
fill 417 294 300 417 297 300 minecraft:red_terracotta
setblock 417 294 303 minecraft:red_terracotta
setblock 417 294 304 minecraft:stripped_oak_log
fill 417 294 305 417 297 305 minecraft:red_terracotta
fill 417 294 307 417 295 307 minecraft:red_terracotta
fill 377 295 276 377 295 277 minecraft:red_terracotta
setblock 377 295 278 minecraft:stripped_oak_log
fill 377 295 279 377 298 279 minecraft:red_terracotta
setblock 377 295 283 minecraft:stripped_oak_log
fill 377 295 284 377 298 284 minecraft:red_terracotta
setblock 377 295 288 minecraft:stripped_oak_log
fill 377 295 289 378 297 289 minecraft:red_terracotta
fill 377 295 291 377 296 291 minecraft:red_terracotta
setblock 377 295 296 minecraft:shroomlight
setblock 377 295 298 minecraft:shroomlight
fill 377 295 299 377 296 299 minecraft:red_terracotta
setblock 377 295 300 minecraft:shroomlight
fill 377 295 301 377 296 301 minecraft:red_terracotta
setblock 377 295 302 minecraft:shroomlight
setblock 377 295 303 minecraft:stripped_oak_log
setblock 377 295 304 minecraft:shroomlight
fill 377 295 306 377 295 307 minecraft:red_terracotta
setblock 378 295 276 minecraft:red_terracotta
setblock 378 295 277 minecraft:stripped_oak_log
fill 378 295 278 378 298 278 minecraft:red_terracotta
setblock 378 295 281 minecraft:red_terracotta
setblock 378 295 282 minecraft:stripped_oak_log
fill 378 295 283 378 298 283 minecraft:red_terracotta
setblock 378 295 287 minecraft:stripped_oak_log
fill 378 295 288 378 298 288 minecraft:red_terracotta
setblock 378 295 295 minecraft:shroomlight
setblock 378 295 297 minecraft:shroomlight
setblock 378 295 299 minecraft:shroomlight
setblock 378 295 301 minecraft:shroomlight
setblock 378 295 303 minecraft:shroomlight
setblock 378 295 305 minecraft:shroomlight
setblock 379 295 276 minecraft:stripped_oak_log
fill 379 295 277 379 298 277 minecraft:red_terracotta
setblock 379 295 281 minecraft:stripped_oak_log
fill 379 295 282 379 298 282 minecraft:red_terracotta
setblock 379 295 285 minecraft:red_terracotta
setblock 379 295 286 minecraft:stripped_oak_log
fill 379 295 287 379 298 287 minecraft:red_terracotta
setblock 379 295 294 minecraft:light[level=15]
setblock 379 295 296 minecraft:shroomlight
setblock 379 295 298 minecraft:shroomlight
setblock 379 295 300 minecraft:shroomlight
setblock 379 295 302 minecraft:shroomlight
setblock 379 295 304 minecraft:shroomlight
setblock 379 295 310 minecraft:light[level=15]
setblock 379 295 316 minecraft:stripped_oak_log
fill 380 295 276 380 298 276 minecraft:red_terracotta
setblock 380 295 279 minecraft:red_terracotta
setblock 380 295 280 minecraft:stripped_oak_log
fill 380 295 281 380 298 281 minecraft:red_terracotta
setblock 380 295 284 minecraft:red_terracotta
setblock 380 295 285 minecraft:stripped_oak_log
setblock 380 295 295 minecraft:shroomlight
setblock 380 295 297 minecraft:shroomlight
setblock 380 295 299 minecraft:shroomlight
setblock 380 295 301 minecraft:shroomlight
setblock 380 295 303 minecraft:shroomlight
setblock 380 295 305 minecraft:shroomlight
fill 380 295 316 380 298 316 minecraft:red_terracotta
setblock 381 295 279 minecraft:stripped_oak_log
setblock 381 295 296 minecraft:shroomlight
setblock 381 295 298 minecraft:shroomlight
setblock 381 295 300 minecraft:shroomlight
setblock 381 295 302 minecraft:shroomlight
setblock 381 295 304 minecraft:shroomlight
setblock 382 295 278 minecraft:stripped_oak_log
fill 382 295 279 382 298 279 minecraft:red_terracotta
setblock 382 295 295 minecraft:shroomlight
setblock 382 295 297 minecraft:shroomlight
setblock 382 295 299 minecraft:shroomlight
setblock 382 295 301 minecraft:shroomlight
setblock 382 295 303 minecraft:shroomlight
setblock 382 295 305 minecraft:shroomlight
fill 382 295 315 384 295 315 minecraft:red_terracotta
setblock 383 295 277 minecraft:stripped_oak_log
fill 383 295 278 383 298 278 minecraft:red_terracotta
setblock 383 295 296 minecraft:shroomlight
setblock 383 295 298 minecraft:shroomlight
setblock 383 295 300 minecraft:shroomlight
setblock 383 295 302 minecraft:shroomlight
setblock 383 295 304 minecraft:shroomlight
setblock 384 295 276 minecraft:stripped_oak_log
fill 384 295 277 387 295 277 minecraft:red_terracotta
setblock 384 295 295 minecraft:shroomlight
setblock 384 295 297 minecraft:shroomlight
setblock 384 295 299 minecraft:shroomlight
setblock 384 295 301 minecraft:shroomlight
setblock 384 295 303 minecraft:shroomlight
setblock 384 295 305 minecraft:shroomlight
setblock 384 295 316 minecraft:stripped_oak_log
fill 385 295 276 388 295 276 minecraft:red_terracotta
setblock 385 295 315 minecraft:stripped_oak_log
fill 385 295 316 385 298 316 minecraft:red_terracotta
setblock 386 295 279 minecraft:stripped_oak_log
fill 386 295 315 386 298 315 minecraft:red_terracotta
setblock 387 295 278 minecraft:stripped_oak_log
setblock 387 295 286 minecraft:light[level=15]
setblock 387 295 294 minecraft:light[level=15]
setblock 387 295 302 minecraft:light[level=15]
setblock 387 295 310 minecraft:light[level=15]
setblock 388 295 277 minecraft:stripped_oak_log
setblock 388 295 278 minecraft:red_terracotta
setblock 389 295 276 minecraft:stripped_oak_log
fill 389 295 277 389 296 277 minecraft:red_terracotta
setblock 389 295 316 minecraft:stripped_oak_log
fill 390 295 276 390 297 276 minecraft:red_terracotta
fill 390 295 316 390 298 316 minecraft:red_terracotta
setblock 395 295 278 minecraft:light[level=15]
setblock 395 295 286 minecraft:light[level=15]
setblock 395 295 294 minecraft:light[level=15]
setblock 395 295 302 minecraft:light[level=15]
setblock 395 295 310 minecraft:light[level=15]
fill 396 295 316 398 295 316 minecraft:red_terracotta
setblock 399 295 276 minecraft:stripped_oak_log
setblock 399 295 316 minecraft:stripped_oak_log
fill 400 295 276 400 298 276 minecraft:red_terracotta
setblock 400 295 315 minecraft:stripped_oak_log
fill 400 295 316 403 295 316 minecraft:red_terracotta
fill 401 295 315 401 298 315 minecraft:red_terracotta
setblock 402 295 277 minecraft:red_terracotta
setblock 403 295 277 minecraft:stripped_oak_log
setblock 403 295 278 minecraft:light[level=15]
setblock 403 295 286 minecraft:light[level=15]
setblock 403 295 294 minecraft:light[level=15]
setblock 403 295 302 minecraft:light[level=15]
setblock 403 295 310 minecraft:light[level=15]
setblock 404 295 276 minecraft:stripped_oak_log
setblock 404 295 277 minecraft:shroomlight
setblock 404 295 279 minecraft:shroomlight
setblock 404 295 281 minecraft:shroomlight
setblock 404 295 283 minecraft:shroomlight
setblock 404 295 316 minecraft:stripped_oak_log
setblock 405 295 276 minecraft:shroomlight
fill 405 295 277 405 300 277 minecraft:stripped_oak_log
setblock 405 295 278 minecraft:shroomlight
setblock 405 295 280 minecraft:shroomlight
setblock 405 295 282 minecraft:shroomlight
fill 405 295 316 405 298 316 minecraft:red_terracotta
setblock 406 295 277 minecraft:shroomlight
setblock 406 295 279 minecraft:shroomlight
setblock 406 295 281 minecraft:shroomlight
setblock 406 295 283 minecraft:shroomlight
setblock 407 295 276 minecraft:shroomlight
setblock 407 295 278 minecraft:shroomlight
setblock 407 295 280 minecraft:shroomlight
setblock 407 295 282 minecraft:shroomlight
fill 408 295 276 408 300 276 minecraft:stripped_oak_log
setblock 408 295 277 minecraft:shroomlight
setblock 408 295 279 minecraft:shroomlight
setblock 408 295 281 minecraft:shroomlight
setblock 408 295 283 minecraft:shroomlight
setblock 409 295 276 minecraft:shroomlight
setblock 409 295 278 minecraft:shroomlight
setblock 409 295 280 minecraft:shroomlight
setblock 409 295 282 minecraft:shroomlight
setblock 410 295 277 minecraft:shroomlight
setblock 410 295 279 minecraft:shroomlight
setblock 410 295 281 minecraft:shroomlight
setblock 410 295 283 minecraft:shroomlight
setblock 411 295 278 minecraft:light[level=15]
setblock 411 295 286 minecraft:light[level=15]
setblock 411 295 294 minecraft:light[level=15]
setblock 411 295 302 minecraft:light[level=15]
setblock 411 295 310 minecraft:light[level=15]
setblock 413 295 280 minecraft:shroomlight
setblock 413 295 282 minecraft:shroomlight
setblock 413 295 284 minecraft:shroomlight
setblock 413 295 286 minecraft:shroomlight
setblock 413 295 288 minecraft:shroomlight
setblock 413 295 290 minecraft:shroomlight
setblock 414 295 281 minecraft:shroomlight
setblock 414 295 283 minecraft:shroomlight
setblock 414 295 285 minecraft:shroomlight
setblock 414 295 287 minecraft:shroomlight
setblock 414 295 289 minecraft:shroomlight
setblock 415 295 280 minecraft:shroomlight
setblock 415 295 282 minecraft:shroomlight
setblock 415 295 284 minecraft:shroomlight
setblock 415 295 286 minecraft:shroomlight
setblock 415 295 288 minecraft:shroomlight
setblock 415 295 290 minecraft:shroomlight
setblock 416 295 281 minecraft:shroomlight
fill 416 295 282 416 296 282 minecraft:red_terracotta
setblock 416 295 283 minecraft:shroomlight
setblock 416 295 284 minecraft:stripped_oak_log
setblock 416 295 285 minecraft:shroomlight
fill 416 295 286 416 297 286 minecraft:red_terracotta
setblock 416 295 287 minecraft:shroomlight
setblock 416 295 288 minecraft:red_terracotta
setblock 416 295 289 minecraft:shroomlight
fill 416 295 300 416 296 300 minecraft:red_terracotta
setblock 416 295 303 minecraft:red_terracotta
setblock 416 295 304 minecraft:stripped_oak_log
fill 416 295 305 416 298 305 minecraft:red_terracotta
setblock 417 295 277 minecraft:red_terracotta
setblock 417 295 278 minecraft:stripped_oak_log
fill 417 295 279 417 298 279 minecraft:red_terracotta
setblock 417 295 280 minecraft:shroomlight
fill 417 295 281 417 296 281 minecraft:red_terracotta
setblock 417 295 282 minecraft:shroomlight
setblock 417 295 283 minecraft:stripped_oak_log
setblock 417 295 284 minecraft:shroomlight
setblock 417 295 286 minecraft:shroomlight
setblock 417 295 287 minecraft:red_terracotta
setblock 417 295 288 minecraft:shroomlight
fill 417 295 289 417 298 289 minecraft:red_terracotta
setblock 417 295 290 minecraft:shroomlight
fill 417 295 291 417 295 292 minecraft:red_terracotta
setblock 417 295 293 minecraft:stripped_oak_log
fill 417 295 294 417 298 294 minecraft:red_terracotta
setblock 417 295 298 minecraft:stripped_oak_log
fill 417 295 299 417 298 299 minecraft:red_terracotta
setblock 417 295 303 minecraft:stripped_oak_log
fill 417 295 304 417 298 304 minecraft:red_terracotta
setblock 417 295 308 minecraft:stripped_oak_log
fill 376 296 275 376 299 317 minecraft:terracotta
fill 377 296 275 418 299 275 minecraft:terracotta
setblock 377 296 276 minecraft:red_terracotta
setblock 377 296 277 minecraft:stripped_oak_log
fill 377 296 278 377 299 278 minecraft:red_terracotta
setblock 377 296 282 minecraft:stripped_oak_log
fill 377 296 283 377 299 283 minecraft:red_terracotta
setblock 377 296 286 minecraft:red_terracotta
setblock 377 296 287 minecraft:stripped_oak_log
fill 377 296 288 377 299 288 minecraft:red_terracotta
setblock 377 296 292 minecraft:stripped_oak_log
fill 377 296 296 377 297 296 minecraft:stripped_oak_log
fill 377 296 298 377 297 298 minecraft:stripped_oak_log
fill 377 296 300 377 297 300 minecraft:red_terracotta
setblock 377 296 302 minecraft:stripped_oak_log
fill 377 296 303 378 297 304 minecraft:red_terracotta
setblock 377 296 306 minecraft:red_terracotta
setblock 377 296 307 minecraft:stripped_oak_log
fill 377 296 308 377 298 309 minecraft:red_terracotta
fill 377 296 317 418 299 317 minecraft:terracotta
setblock 378 296 276 minecraft:stripped_oak_log
fill 378 296 277 378 299 277 minecraft:red_terracotta
setblock 378 296 281 minecraft:stripped_oak_log
fill 378 296 282 378 299 282 minecraft:red_terracotta
setblock 378 296 286 minecraft:stripped_oak_log
fill 378 296 287 378 299 287 minecraft:red_terracotta
setblock 378 296 290 minecraft:red_terracotta
fill 378 296 295 378 297 295 minecraft:stripped_oak_log
fill 378 296 297 378 297 297 minecraft:stripped_oak_log
fill 378 296 299 378 297 299 minecraft:stripped_oak_log
fill 378 296 301 378 297 301 minecraft:stripped_oak_log
setblock 378 296 305 minecraft:red_terracotta
setblock 378 296 306 minecraft:stripped_oak_log
fill 379 296 276 379 299 276 minecraft:red_terracotta
setblock 379 296 280 minecraft:stripped_oak_log
fill 379 296 281 379 299 281 minecraft:red_terracotta
setblock 379 296 285 minecraft:stripped_oak_log
fill 379 296 286 380 298 286 minecraft:red_terracotta
fill 379 296 288 379 297 288 minecraft:red_terracotta
fill 379 296 296 379 297 296 minecraft:stripped_oak_log
fill 379 296 298 379 297 298 minecraft:stripped_oak_log
fill 379 296 300 379 297 300 minecraft:stripped_oak_log
fill 379 296 302 379 297 302 minecraft:stripped_oak_log
fill 379 296 304 379 297 304 minecraft:stripped_oak_log
fill 379 296 316 379 299 316 minecraft:red_terracotta
setblock 380 296 279 minecraft:stripped_oak_log
fill 380 296 280 380 298 280 minecraft:red_terracotta
setblock 380 296 284 minecraft:stripped_oak_log
fill 380 296 285 380 299 285 minecraft:red_terracotta
fill 380 296 295 380 297 295 minecraft:stripped_oak_log
fill 380 296 297 380 297 297 minecraft:stripped_oak_log
fill 380 296 299 380 297 299 minecraft:stripped_oak_log
fill 380 296 301 380 297 301 minecraft:stripped_oak_log
fill 380 296 303 380 297 303 minecraft:stripped_oak_log
fill 380 296 305 380 297 305 minecraft:stripped_oak_log
setblock 381 296 278 minecraft:stripped_oak_log
fill 381 296 279 381 298 279 minecraft:red_terracotta
setblock 381 296 282 minecraft:red_terracotta
fill 381 296 296 381 297 296 minecraft:stripped_oak_log
fill 381 296 298 381 297 298 minecraft:stripped_oak_log
fill 381 296 300 381 297 300 minecraft:stripped_oak_log
fill 381 296 302 381 297 302 minecraft:stripped_oak_log
fill 381 296 304 381 297 304 minecraft:stripped_oak_log
fill 381 296 315 383 296 315 minecraft:red_terracotta
setblock 382 296 277 minecraft:stripped_oak_log
fill 382 296 278 382 299 278 minecraft:red_terracotta
fill 382 296 295 382 297 295 minecraft:stripped_oak_log
fill 382 296 297 382 297 297 minecraft:stripped_oak_log
fill 382 296 299 382 297 299 minecraft:stripped_oak_log
fill 382 296 301 382 297 301 minecraft:stripped_oak_log
fill 382 296 303 382 297 303 minecraft:stripped_oak_log
fill 382 296 305 382 297 305 minecraft:stripped_oak_log
setblock 383 296 276 minecraft:stripped_oak_log
fill 383 296 277 386 296 277 minecraft:red_terracotta
fill 383 296 296 383 297 296 minecraft:stripped_oak_log
fill 383 296 298 383 297 298 minecraft:stripped_oak_log
fill 383 296 300 383 297 300 minecraft:stripped_oak_log
fill 383 296 302 383 297 302 minecraft:stripped_oak_log
fill 383 296 304 383 297 304 minecraft:stripped_oak_log
setblock 383 296 316 minecraft:stripped_oak_log
fill 384 296 276 387 296 276 minecraft:red_terracotta
fill 384 296 295 384 297 295 minecraft:stripped_oak_log
fill 384 296 297 384 297 297 minecraft:stripped_oak_log
fill 384 296 299 384 297 299 minecraft:stripped_oak_log
fill 384 296 301 384 297 301 minecraft:stripped_oak_log
fill 384 296 303 384 297 303 minecraft:stripped_oak_log
fill 384 296 305 384 297 305 minecraft:stripped_oak_log
setblock 384 296 315 minecraft:stripped_oak_log
fill 384 296 316 384 299 316 minecraft:red_terracotta
setblock 385 296 279 minecraft:stripped_oak_log
fill 385 296 315 385 299 315 minecraft:red_terracotta
setblock 386 296 278 minecraft:stripped_oak_log
setblock 387 296 277 minecraft:stripped_oak_log
setblock 387 296 278 minecraft:red_terracotta
setblock 388 296 276 minecraft:stripped_oak_log
fill 388 296 277 388 297 277 minecraft:red_terracotta
setblock 388 296 316 minecraft:stripped_oak_log
fill 389 296 276 389 298 276 minecraft:red_terracotta
fill 389 296 316 389 299 316 minecraft:red_terracotta
fill 395 296 316 397 296 316 minecraft:red_terracotta
setblock 398 296 276 minecraft:stripped_oak_log
setblock 398 296 316 minecraft:stripped_oak_log
fill 399 296 276 399 298 276 minecraft:red_terracotta
setblock 399 296 315 minecraft:stripped_oak_log
fill 399 296 316 402 296 316 minecraft:red_terracotta
fill 400 296 315 400 299 315 minecraft:red_terracotta
fill 402 296 315 403 296 315 minecraft:red_terracotta
setblock 403 296 276 minecraft:stripped_oak_log
setblock 403 296 316 minecraft:stripped_oak_log
fill 404 296 276 405 297 276 minecraft:red_terracotta
fill 404 296 277 404 297 277 minecraft:stripped_oak_log
fill 404 296 279 404 297 279 minecraft:stripped_oak_log
fill 404 296 281 404 297 281 minecraft:stripped_oak_log
fill 404 296 283 404 297 283 minecraft:stripped_oak_log
setblock 404 296 315 minecraft:stripped_oak_log
fill 404 296 316 404 299 316 minecraft:red_terracotta
fill 405 296 278 405 297 278 minecraft:stripped_oak_log
fill 405 296 280 405 297 280 minecraft:stripped_oak_log
fill 405 296 282 405 297 282 minecraft:stripped_oak_log
fill 406 296 277 406 297 277 minecraft:stripped_oak_log
fill 406 296 279 406 297 279 minecraft:stripped_oak_log
fill 406 296 281 406 297 281 minecraft:stripped_oak_log
fill 406 296 283 406 297 283 minecraft:stripped_oak_log
fill 407 296 276 407 297 276 minecraft:stripped_oak_log
fill 407 296 278 407 297 278 minecraft:stripped_oak_log
fill 407 296 280 407 297 280 minecraft:stripped_oak_log
fill 407 296 282 407 297 282 minecraft:stripped_oak_log
fill 408 296 277 408 297 277 minecraft:stripped_oak_log
fill 408 296 279 408 297 279 minecraft:stripped_oak_log
fill 408 296 281 408 297 281 minecraft:stripped_oak_log
fill 408 296 283 408 297 283 minecraft:stripped_oak_log
fill 409 296 276 409 297 276 minecraft:stripped_oak_log
fill 409 296 278 409 297 278 minecraft:stripped_oak_log
fill 409 296 280 409 297 280 minecraft:stripped_oak_log
fill 409 296 282 409 297 282 minecraft:stripped_oak_log
fill 410 296 277 410 297 277 minecraft:stripped_oak_log
fill 410 296 279 410 297 279 minecraft:stripped_oak_log
fill 410 296 281 410 297 281 minecraft:stripped_oak_log
fill 410 296 283 410 297 283 minecraft:stripped_oak_log
fill 413 296 280 413 297 280 minecraft:stripped_oak_log
fill 413 296 282 413 297 282 minecraft:stripped_oak_log
fill 413 296 284 413 297 284 minecraft:stripped_oak_log
fill 413 296 286 413 297 286 minecraft:stripped_oak_log
fill 413 296 288 413 297 288 minecraft:stripped_oak_log
fill 413 296 290 413 297 290 minecraft:stripped_oak_log
fill 414 296 281 414 297 281 minecraft:stripped_oak_log
fill 414 296 283 414 297 283 minecraft:stripped_oak_log
fill 414 296 285 414 297 285 minecraft:stripped_oak_log
fill 414 296 287 414 297 287 minecraft:stripped_oak_log
fill 414 296 289 414 297 289 minecraft:stripped_oak_log
fill 415 296 280 415 297 280 minecraft:stripped_oak_log
fill 415 296 282 415 297 282 minecraft:stripped_oak_log
setblock 415 296 284 minecraft:stripped_oak_log
setblock 415 296 286 minecraft:stripped_oak_log
fill 415 296 288 416 296 288 minecraft:stripped_oak_log
fill 415 296 290 415 297 290 minecraft:stripped_oak_log
fill 416 296 280 416 297 281 minecraft:red_terracotta
setblock 416 296 283 minecraft:stripped_oak_log
fill 416 296 284 416 297 285 minecraft:red_terracotta
setblock 416 296 287 minecraft:red_terracotta
fill 416 296 289 416 297 290 minecraft:red_terracotta
setblock 416 296 303 minecraft:stripped_oak_log
fill 416 296 304 416 298 304 minecraft:red_terracotta
fill 416 296 306 416 297 306 minecraft:red_terracotta
setblock 417 296 277 minecraft:stripped_oak_log
fill 417 296 278 417 299 278 minecraft:red_terracotta
fill 417 296 280 417 297 280 minecraft:red_terracotta
setblock 417 296 282 minecraft:stripped_oak_log
fill 417 296 283 417 297 284 minecraft:red_terracotta
setblock 417 296 286 minecraft:red_terracotta
setblock 417 296 287 minecraft:stripped_oak_log
fill 417 296 288 417 297 288 minecraft:red_terracotta
fill 417 296 290 417 296 291 minecraft:red_terracotta
setblock 417 296 292 minecraft:stripped_oak_log
fill 417 296 293 417 299 293 minecraft:red_terracotta
setblock 417 296 297 minecraft:stripped_oak_log
fill 417 296 298 417 299 298 minecraft:red_terracotta
setblock 417 296 302 minecraft:stripped_oak_log
fill 417 296 303 417 299 303 minecraft:red_terracotta
setblock 417 296 307 minecraft:stripped_oak_log
fill 417 296 308 417 298 309 minecraft:red_terracotta
fill 418 296 276 418 299 316 minecraft:terracotta
setblock 377 297 276 minecraft:stripped_oak_log
fill 377 297 277 377 300 277 minecraft:red_terracotta
setblock 377 297 281 minecraft:stripped_oak_log
fill 377 297 282 377 300 282 minecraft:red_terracotta
setblock 377 297 286 minecraft:stripped_oak_log
fill 377 297 287 377 300 287 minecraft:red_terracotta
setblock 377 297 291 minecraft:stripped_oak_log
fill 377 297 292 377 299 293 minecraft:red_terracotta
fill 377 297 299 377 300 299 minecraft:stripped_oak_log
setblock 377 297 301 minecraft:stripped_oak_log
setblock 377 297 302 minecraft:red_terracotta
setblock 377 297 306 minecraft:stripped_oak_log
fill 377 297 307 378 299 307 minecraft:red_terracotta
setblock 377 297 310 minecraft:red_terracotta
setblock 377 297 311 minecraft:stripped_oak_log
fill 377 297 312 377 300 312 minecraft:red_terracotta
fill 378 297 276 378 300 276 minecraft:red_terracotta
setblock 378 297 280 minecraft:stripped_oak_log
fill 378 297 281 378 300 281 minecraft:red_terracotta
setblock 378 297 285 minecraft:stripped_oak_log
fill 378 297 286 378 300 286 minecraft:red_terracotta
setblock 378 297 290 minecraft:stripped_oak_log
fill 378 297 291 378 300 291 minecraft:red_terracotta
setblock 378 297 305 minecraft:stripped_oak_log
fill 378 297 306 378 300 306 minecraft:red_terracotta
fill 378 297 308 378 297 309 minecraft:red_terracotta
fill 378 297 316 378 300 316 minecraft:red_terracotta
setblock 379 297 279 minecraft:stripped_oak_log
fill 379 297 280 379 300 280 minecraft:red_terracotta
setblock 379 297 283 minecraft:red_terracotta
setblock 379 297 284 minecraft:stripped_oak_log
fill 379 297 285 379 300 285 minecraft:red_terracotta
setblock 379 297 289 minecraft:stripped_oak_log
fill 379 297 294 381 297 294 minecraft:orange_terracotta
setblock 380 297 278 minecraft:stripped_oak_log
fill 380 297 279 380 298 279 minecraft:red_terracotta
setblock 380 297 283 minecraft:stripped_oak_log
fill 380 297 284 380 300 284 minecraft:red_terracotta
setblock 380 297 287 minecraft:red_terracotta
fill 380 297 293 385 297 293 minecraft:orange_terracotta
fill 380 297 315 382 297 315 minecraft:red_terracotta
setblock 381 297 277 minecraft:stripped_oak_log
fill 381 297 278 381 300 278 minecraft:red_terracotta
setblock 381 297 283 minecraft:red_terracotta
fill 381 297 292 384 297 292 minecraft:orange_terracotta
setblock 382 297 276 minecraft:stripped_oak_log
fill 382 297 277 385 297 277 minecraft:red_terracotta
setblock 382 297 316 minecraft:stripped_oak_log
fill 383 297 276 386 297 276 minecraft:red_terracotta
setblock 383 297 315 minecraft:stripped_oak_log
fill 383 297 316 383 300 316 minecraft:red_terracotta
setblock 384 297 279 minecraft:stripped_oak_log
fill 384 297 294 386 297 294 minecraft:orange_terracotta
fill 384 297 315 384 300 315 minecraft:red_terracotta
setblock 385 297 278 minecraft:stripped_oak_log
fill 385 297 295 385 297 299 minecraft:orange_terracotta
setblock 386 297 277 minecraft:stripped_oak_log
setblock 386 297 278 minecraft:red_terracotta
fill 386 297 295 386 297 298 minecraft:orange_terracotta
setblock 387 297 276 minecraft:stripped_oak_log
fill 387 297 277 387 298 277 minecraft:red_terracotta
setblock 387 297 316 minecraft:stripped_oak_log
fill 388 297 276 388 299 276 minecraft:red_terracotta
fill 388 297 316 388 300 316 minecraft:red_terracotta
setblock 392 297 316 minecraft:stripped_oak_log
fill 393 297 316 396 297 316 minecraft:red_terracotta
setblock 397 297 316 minecraft:stripped_oak_log
setblock 398 297 276 minecraft:red_terracotta
setblock 398 297 315 minecraft:stripped_oak_log
fill 398 297 316 401 297 316 minecraft:red_terracotta
fill 399 297 315 399 300 315 minecraft:red_terracotta
setblock 402 297 276 minecraft:stripped_oak_log
setblock 402 297 315 minecraft:red_terracotta
setblock 402 297 316 minecraft:stripped_oak_log
fill 403 297 276 403 298 276 minecraft:red_terracotta
setblock 403 297 315 minecraft:stripped_oak_log
fill 403 297 316 403 300 316 minecraft:red_terracotta
setblock 404 297 315 minecraft:red_terracotta
fill 406 297 276 406 300 276 minecraft:stripped_oak_log
fill 415 297 284 415 297 286 minecraft:red_terracotta
setblock 415 297 288 minecraft:stripped_oak_log
setblock 416 297 282 minecraft:stripped_oak_log
setblock 416 297 283 minecraft:red_terracotta
setblock 416 297 287 minecraft:stripped_oak_log
fill 416 297 288 416 300 288 minecraft:red_terracotta
setblock 416 297 291 minecraft:red_terracotta
setblock 416 297 302 minecraft:stripped_oak_log
fill 416 297 303 416 298 303 minecraft:red_terracotta
fill 417 297 277 417 300 277 minecraft:red_terracotta
setblock 417 297 281 minecraft:stripped_oak_log
setblock 417 297 282 minecraft:red_terracotta
setblock 417 297 286 minecraft:stripped_oak_log
fill 417 297 287 417 300 287 minecraft:red_terracotta
setblock 417 297 290 minecraft:red_terracotta
setblock 417 297 291 minecraft:stripped_oak_log
fill 417 297 292 417 300 292 minecraft:red_terracotta
setblock 417 297 296 minecraft:stripped_oak_log
fill 417 297 297 417 300 297 minecraft:red_terracotta
setblock 417 297 301 minecraft:stripped_oak_log
fill 417 297 302 417 300 302 minecraft:red_terracotta
setblock 417 297 306 minecraft:stripped_oak_log
fill 417 297 307 417 300 307 minecraft:red_terracotta
setblock 417 297 310 minecraft:red_terracotta
fill 377 298 276 377 300 276 minecraft:red_terracotta
setblock 377 298 280 minecraft:stripped_oak_log
fill 377 298 281 377 300 281 minecraft:red_terracotta
setblock 377 298 285 minecraft:stripped_oak_log
fill 377 298 286 377 300 286 minecraft:red_terracotta
setblock 377 298 289 minecraft:red_terracotta
setblock 377 298 290 minecraft:stripped_oak_log
fill 377 298 291 377 300 291 minecraft:red_terracotta
setblock 377 298 296 minecraft:shroomlight
setblock 377 298 298 minecraft:shroomlight
setblock 377 298 300 minecraft:shroomlight
setblock 377 298 301 minecraft:red_terracotta
setblock 377 298 302 minecraft:shroomlight
fill 377 298 303 377 299 303 minecraft:red_terracotta
setblock 377 298 304 minecraft:shroomlight
setblock 377 298 305 minecraft:stripped_oak_log
fill 377 298 306 377 300 306 minecraft:red_terracotta
setblock 377 298 310 minecraft:stripped_oak_log
fill 377 298 311 378 300 311 minecraft:red_terracotta
fill 377 298 313 377 298 314 minecraft:red_terracotta
setblock 377 298 315 minecraft:stripped_oak_log
fill 377 298 316 377 300 316 minecraft:red_terracotta
setblock 378 298 279 minecraft:stripped_oak_log
fill 378 298 280 378 300 280 minecraft:red_terracotta
setblock 378 298 284 minecraft:stripped_oak_log
fill 378 298 285 378 300 285 minecraft:red_terracotta
setblock 378 298 289 minecraft:stripped_oak_log
fill 378 298 290 378 300 290 minecraft:red_terracotta
setblock 378 298 295 minecraft:shroomlight
setblock 378 298 297 minecraft:shroomlight
setblock 378 298 299 minecraft:shroomlight
setblock 378 298 301 minecraft:shroomlight
setblock 378 298 303 minecraft:shroomlight
setblock 378 298 304 minecraft:stripped_oak_log
setblock 378 298 305 minecraft:shroomlight
setblock 378 298 308 minecraft:red_terracotta
setblock 378 298 309 minecraft:stripped_oak_log
fill 378 298 310 378 300 310 minecraft:red_terracotta
setblock 379 298 278 minecraft:stripped_oak_log
fill 379 298 279 379 300 279 minecraft:red_terracotta
setblock 379 298 283 minecraft:stripped_oak_log
fill 379 298 284 379 300 284 minecraft:red_terracotta
setblock 379 298 288 minecraft:stripped_oak_log
fill 379 298 289 379 300 289 minecraft:red_terracotta
setblock 379 298 296 minecraft:shroomlight
setblock 379 298 298 minecraft:shroomlight
setblock 379 298 300 minecraft:shroomlight
setblock 379 298 302 minecraft:shroomlight
setblock 379 298 304 minecraft:shroomlight
setblock 380 298 277 minecraft:stripped_oak_log
fill 380 298 278 380 300 278 minecraft:red_terracotta
setblock 380 298 282 minecraft:stripped_oak_log
fill 380 298 283 380 300 283 minecraft:red_terracotta
setblock 380 298 287 minecraft:stripped_oak_log
fill 380 298 294 381 298 294 minecraft:orange_terracotta
setblock 380 298 295 minecraft:shroomlight
setblock 380 298 297 minecraft:shroomlight
setblock 380 298 299 minecraft:shroomlight
setblock 380 298 301 minecraft:shroomlight
setblock 380 298 303 minecraft:shroomlight
setblock 380 298 305 minecraft:shroomlight
fill 380 298 315 381 298 315 minecraft:red_terracotta
setblock 381 298 276 minecraft:stripped_oak_log
fill 381 298 277 384 298 277 minecraft:red_terracotta
fill 381 298 293 384 298 293 minecraft:orange_terracotta
setblock 381 298 296 minecraft:shroomlight
setblock 381 298 298 minecraft:shroomlight
setblock 381 298 300 minecraft:shroomlight
setblock 381 298 302 minecraft:shroomlight
setblock 381 298 304 minecraft:shroomlight
setblock 381 298 316 minecraft:stripped_oak_log
fill 382 298 276 385 298 276 minecraft:red_terracotta
setblock 382 298 295 minecraft:shroomlight
setblock 382 298 297 minecraft:shroomlight
setblock 382 298 299 minecraft:shroomlight
setblock 382 298 301 minecraft:shroomlight
setblock 382 298 303 minecraft:shroomlight
setblock 382 298 305 minecraft:shroomlight
setblock 382 298 315 minecraft:stripped_oak_log
fill 382 298 316 382 300 316 minecraft:red_terracotta
setblock 383 298 296 minecraft:shroomlight
setblock 383 298 298 minecraft:shroomlight
setblock 383 298 300 minecraft:shroomlight
setblock 383 298 302 minecraft:shroomlight
setblock 383 298 304 minecraft:shroomlight
fill 383 298 315 383 300 315 minecraft:red_terracotta
setblock 384 298 278 minecraft:stripped_oak_log
fill 384 298 294 385 298 294 minecraft:orange_terracotta
setblock 384 298 295 minecraft:shroomlight
setblock 384 298 297 minecraft:shroomlight
setblock 384 298 299 minecraft:shroomlight
setblock 384 298 301 minecraft:shroomlight
setblock 384 298 303 minecraft:shroomlight
setblock 384 298 305 minecraft:shroomlight
setblock 385 298 277 minecraft:stripped_oak_log
setblock 385 298 278 minecraft:red_terracotta
fill 385 298 295 385 298 298 minecraft:orange_terracotta
setblock 386 298 276 minecraft:stripped_oak_log
setblock 386 298 277 minecraft:red_terracotta
fill 386 298 295 386 298 297 minecraft:orange_terracotta
setblock 386 298 316 minecraft:stripped_oak_log
fill 387 298 276 387 299 276 minecraft:red_terracotta
setblock 387 298 315 minecraft:stripped_oak_log
fill 387 298 316 387 300 316 minecraft:red_terracotta
setblock 391 298 316 minecraft:stripped_oak_log
fill 394 298 316 395 298 316 minecraft:red_terracotta
setblock 396 298 316 minecraft:stripped_oak_log
fill 397 298 316 400 298 316 minecraft:red_terracotta
fill 398 298 315 398 300 315 minecraft:red_terracotta
setblock 401 298 276 minecraft:stripped_oak_log
setblock 401 298 316 minecraft:stripped_oak_log
setblock 402 298 276 minecraft:red_terracotta
setblock 402 298 315 minecraft:stripped_oak_log
fill 402 298 316 402 300 316 minecraft:red_terracotta
fill 403 298 315 403 299 315 minecraft:red_terracotta
setblock 404 298 276 minecraft:red_terracotta
setblock 404 298 277 minecraft:shroomlight
setblock 404 298 279 minecraft:shroomlight
setblock 404 298 281 minecraft:shroomlight
setblock 404 298 283 minecraft:shroomlight
setblock 405 298 276 minecraft:shroomlight
setblock 405 298 278 minecraft:shroomlight
setblock 405 298 280 minecraft:shroomlight
setblock 405 298 282 minecraft:shroomlight
setblock 406 298 277 minecraft:shroomlight
setblock 406 298 279 minecraft:shroomlight
setblock 406 298 281 minecraft:shroomlight
setblock 406 298 283 minecraft:shroomlight
setblock 407 298 276 minecraft:shroomlight
setblock 407 298 278 minecraft:shroomlight
setblock 407 298 280 minecraft:shroomlight
setblock 407 298 282 minecraft:shroomlight
setblock 408 298 277 minecraft:shroomlight
setblock 408 298 279 minecraft:shroomlight
setblock 408 298 281 minecraft:shroomlight
setblock 408 298 283 minecraft:shroomlight
setblock 409 298 276 minecraft:shroomlight
setblock 409 298 278 minecraft:shroomlight
setblock 409 298 280 minecraft:shroomlight
setblock 409 298 282 minecraft:shroomlight
setblock 410 298 277 minecraft:shroomlight
setblock 410 298 279 minecraft:shroomlight
setblock 410 298 281 minecraft:shroomlight
setblock 410 298 283 minecraft:shroomlight
setblock 413 298 280 minecraft:shroomlight
setblock 413 298 282 minecraft:shroomlight
setblock 413 298 284 minecraft:shroomlight
setblock 413 298 286 minecraft:shroomlight
setblock 413 298 288 minecraft:shroomlight
setblock 413 298 290 minecraft:shroomlight
setblock 414 298 281 minecraft:shroomlight
setblock 414 298 283 minecraft:shroomlight
setblock 414 298 285 minecraft:shroomlight
setblock 414 298 287 minecraft:shroomlight
setblock 414 298 289 minecraft:shroomlight
setblock 415 298 280 minecraft:shroomlight
setblock 415 298 282 minecraft:shroomlight
setblock 415 298 284 minecraft:shroomlight
fill 415 298 285 415 299 285 minecraft:red_terracotta
setblock 415 298 286 minecraft:shroomlight
setblock 415 298 288 minecraft:shroomlight
setblock 415 298 290 minecraft:shroomlight
setblock 416 298 280 minecraft:red_terracotta
setblock 416 298 281 minecraft:shroomlight
fill 416 298 282 416 300 282 minecraft:red_terracotta
setblock 416 298 283 minecraft:shroomlight
fill 416 298 284 416 299 284 minecraft:red_terracotta
setblock 416 298 285 minecraft:shroomlight
setblock 416 298 286 minecraft:stripped_oak_log
setblock 416 298 287 minecraft:shroomlight
setblock 416 298 289 minecraft:shroomlight
setblock 416 298 290 minecraft:red_terracotta
setblock 416 298 291 minecraft:stripped_oak_log
fill 416 298 292 416 300 292 minecraft:red_terracotta
setblock 416 298 306 minecraft:stripped_oak_log
fill 416 298 307 416 299 307 minecraft:red_terracotta
fill 417 298 276 417 300 276 minecraft:red_terracotta
setblock 417 298 280 minecraft:shroomlight
fill 417 298 281 417 300 281 minecraft:red_terracotta
setblock 417 298 282 minecraft:shroomlight
fill 417 298 283 417 299 283 minecraft:red_terracotta
setblock 417 298 284 minecraft:shroomlight
setblock 417 298 285 minecraft:stripped_oak_log
setblock 417 298 286 minecraft:shroomlight
setblock 417 298 288 minecraft:shroomlight
setblock 417 298 290 minecraft:shroomlight
fill 417 298 291 417 300 291 minecraft:red_terracotta
setblock 417 298 295 minecraft:stripped_oak_log
fill 417 298 296 417 300 296 minecraft:red_terracotta
setblock 417 298 300 minecraft:stripped_oak_log
fill 417 298 301 417 300 301 minecraft:red_terracotta
setblock 417 298 305 minecraft:stripped_oak_log
fill 417 298 306 417 300 306 minecraft:red_terracotta
setblock 417 298 310 minecraft:stripped_oak_log
fill 417 298 311 417 300 311 minecraft:red_terracotta
setblock 377 299 279 minecraft:stripped_oak_log
fill 377 299 280 377 300 280 minecraft:red_terracotta
setblock 377 299 284 minecraft:stripped_oak_log
fill 377 299 285 377 300 285 minecraft:red_terracotta
setblock 377 299 289 minecraft:stripped_oak_log
fill 377 299 290 377 300 290 minecraft:red_terracotta
setblock 377 299 294 minecraft:stripped_oak_log
fill 377 299 296 377 300 296 minecraft:stripped_oak_log
fill 377 299 298 377 300 298 minecraft:stripped_oak_log
fill 377 299 300 377 300 301 minecraft:stripped_oak_log
setblock 377 299 302 minecraft:red_terracotta
setblock 377 299 304 minecraft:stripped_oak_log
fill 377 299 305 378 300 305 minecraft:red_terracotta
setblock 377 299 308 minecraft:red_terracotta
setblock 377 299 309 minecraft:stripped_oak_log
fill 377 299 310 377 300 310 minecraft:red_terracotta
setblock 377 299 313 minecraft:red_terracotta
setblock 377 299 314 minecraft:stripped_oak_log
fill 377 299 315 377 300 315 minecraft:red_terracotta
setblock 378 299 278 minecraft:stripped_oak_log
fill 378 299 279 378 300 279 minecraft:red_terracotta
setblock 378 299 283 minecraft:stripped_oak_log
fill 378 299 284 378 300 284 minecraft:red_terracotta
setblock 378 299 288 minecraft:stripped_oak_log
fill 378 299 289 378 300 289 minecraft:red_terracotta
fill 378 299 295 378 300 295 minecraft:stripped_oak_log
fill 378 299 297 378 300 297 minecraft:stripped_oak_log
fill 378 299 299 378 300 299 minecraft:stripped_oak_log
fill 378 299 301 378 300 301 minecraft:stripped_oak_log
fill 378 299 303 378 300 303 minecraft:stripped_oak_log
setblock 378 299 304 minecraft:red_terracotta
setblock 378 299 308 minecraft:stripped_oak_log
fill 378 299 309 379 300 309 minecraft:red_terracotta
setblock 378 299 312 minecraft:red_terracotta
setblock 378 299 313 minecraft:stripped_oak_log
setblock 379 299 277 minecraft:stripped_oak_log
setblock 379 299 278 minecraft:red_terracotta
setblock 379 299 282 minecraft:stripped_oak_log
fill 379 299 283 379 300 283 minecraft:red_terracotta
setblock 379 299 286 minecraft:red_terracotta
setblock 379 299 287 minecraft:stripped_oak_log
fill 379 299 288 379 300 288 minecraft:red_terracotta
setblock 379 299 292 minecraft:light[level=12]
fill 379 299 296 379 300 296 minecraft:stripped_oak_log
fill 379 299 298 379 300 298 minecraft:stripped_oak_log
fill 379 299 300 379 300 300 minecraft:stripped_oak_log
fill 379 299 302 379 300 302 minecraft:stripped_oak_log
fill 379 299 304 379 300 304 minecraft:stripped_oak_log
setblock 379 299 306 minecraft:light[level=12]
fill 379 299 308 379 300 308 minecraft:red_terracotta
setblock 379 299 313 minecraft:light[level=12]
fill 379 299 315 380 299 315 minecraft:red_terracotta
setblock 380 299 276 minecraft:stripped_oak_log
fill 380 299 277 383 299 277 minecraft:red_terracotta
setblock 380 299 281 minecraft:stripped_oak_log
setblock 380 299 282 minecraft:red_terracotta
setblock 380 299 286 minecraft:stripped_oak_log
fill 380 299 287 380 300 287 minecraft:red_terracotta
fill 380 299 295 380 300 295 minecraft:stripped_oak_log
fill 380 299 297 380 300 297 minecraft:stripped_oak_log
fill 380 299 299 380 300 299 minecraft:stripped_oak_log
fill 380 299 301 380 300 301 minecraft:stripped_oak_log
fill 380 299 303 380 300 303 minecraft:stripped_oak_log
fill 380 299 305 380 300 305 minecraft:stripped_oak_log
setblock 380 299 316 minecraft:stripped_oak_log
fill 381 299 276 384 299 276 minecraft:red_terracotta
setblock 381 299 294 minecraft:orange_terracotta
fill 381 299 296 381 300 296 minecraft:stripped_oak_log
fill 381 299 298 381 300 298 minecraft:stripped_oak_log
fill 381 299 300 381 300 300 minecraft:stripped_oak_log
fill 381 299 302 381 300 302 minecraft:stripped_oak_log
fill 381 299 304 381 300 304 minecraft:stripped_oak_log
setblock 381 299 315 minecraft:stripped_oak_log
fill 381 299 316 381 300 316 minecraft:red_terracotta
fill 382 299 295 382 300 295 minecraft:stripped_oak_log
fill 382 299 297 382 300 297 minecraft:stripped_oak_log
fill 382 299 299 382 300 299 minecraft:stripped_oak_log
fill 382 299 301 382 300 301 minecraft:stripped_oak_log
fill 382 299 303 382 300 303 minecraft:stripped_oak_log
fill 382 299 305 382 300 305 minecraft:stripped_oak_log
fill 382 299 315 382 300 315 minecraft:red_terracotta
setblock 383 299 278 minecraft:stripped_oak_log
setblock 383 299 293 minecraft:orange_terracotta
fill 383 299 296 383 300 296 minecraft:stripped_oak_log
fill 383 299 298 383 300 298 minecraft:stripped_oak_log
fill 383 299 300 383 300 300 minecraft:stripped_oak_log
fill 383 299 302 383 300 302 minecraft:stripped_oak_log
fill 383 299 304 383 300 304 minecraft:stripped_oak_log
setblock 384 299 277 minecraft:stripped_oak_log
setblock 384 299 294 minecraft:orange_terracotta
fill 384 299 295 384 300 295 minecraft:stripped_oak_log
fill 384 299 297 384 300 297 minecraft:stripped_oak_log
fill 384 299 299 384 300 299 minecraft:stripped_oak_log
fill 384 299 301 384 300 301 minecraft:stripped_oak_log
fill 384 299 303 384 300 303 minecraft:stripped_oak_log
fill 384 299 305 384 300 305 minecraft:stripped_oak_log
setblock 385 299 276 minecraft:stripped_oak_log
setblock 385 299 277 minecraft:red_terracotta
fill 385 299 295 385 299 297 minecraft:orange_terracotta
setblock 385 299 316 minecraft:stripped_oak_log
fill 386 299 276 386 300 276 minecraft:red_terracotta
setblock 386 299 278 minecraft:light[level=12]
setblock 386 299 285 minecraft:light[level=12]
setblock 386 299 292 minecraft:light[level=12]
setblock 386 299 299 minecraft:light[level=12]
setblock 386 299 306 minecraft:light[level=12]
fill 386 299 312 388 299 314 minecraft:terracotta
setblock 386 299 315 minecraft:stripped_oak_log
fill 386 299 316 386 300 316 minecraft:red_terracotta
setblock 390 299 316 minecraft:stripped_oak_log
setblock 393 299 278 minecraft:light[level=12]
setblock 393 299 285 minecraft:light[level=12]
setblock 393 299 292 minecraft:light[level=12]
setblock 393 299 299 minecraft:light[level=12]
setblock 393 299 306 minecraft:light[level=12]
setblock 393 299 313 minecraft:light[level=12]
setblock 394 299 316 minecraft:red_terracotta
setblock 395 299 316 minecraft:stripped_oak_log
fill 396 299 316 399 299 316 minecraft:red_terracotta
fill 397 299 315 397 300 315 minecraft:red_terracotta
setblock 400 299 276 minecraft:stripped_oak_log
setblock 400 299 278 minecraft:light[level=12]
setblock 400 299 285 minecraft:light[level=12]
setblock 400 299 292 minecraft:light[level=12]
setblock 400 299 299 minecraft:light[level=12]
setblock 400 299 306 minecraft:light[level=12]
setblock 400 299 313 minecraft:light[level=12]
setblock 400 299 316 minecraft:stripped_oak_log
setblock 401 299 276 minecraft:red_terracotta
setblock 401 299 315 minecraft:stripped_oak_log
fill 401 299 316 401 300 316 minecraft:red_terracotta
fill 402 299 315 402 300 315 minecraft:red_terracotta
fill 404 299 276 404 300 277 minecraft:stripped_oak_log
fill 404 299 279 404 300 279 minecraft:stripped_oak_log
fill 404 299 281 404 300 281 minecraft:stripped_oak_log
fill 404 299 283 404 300 283 minecraft:stripped_oak_log
fill 405 299 276 405 300 276 minecraft:stripped_oak_log
fill 405 299 278 405 300 278 minecraft:stripped_oak_log
fill 405 299 280 405 300 280 minecraft:stripped_oak_log
fill 405 299 282 405 300 282 minecraft:stripped_oak_log
fill 406 299 277 406 300 277 minecraft:stripped_oak_log
fill 406 299 279 406 300 279 minecraft:stripped_oak_log
fill 406 299 281 406 300 281 minecraft:stripped_oak_log
fill 406 299 283 406 300 283 minecraft:stripped_oak_log
fill 407 299 276 407 300 276 minecraft:stripped_oak_log
fill 407 299 278 407 300 278 minecraft:stripped_oak_log
fill 407 299 280 407 300 280 minecraft:stripped_oak_log
fill 407 299 282 407 300 282 minecraft:stripped_oak_log
setblock 407 299 285 minecraft:light[level=12]
setblock 407 299 292 minecraft:light[level=12]
setblock 407 299 299 minecraft:light[level=12]
setblock 407 299 306 minecraft:light[level=12]
setblock 407 299 313 minecraft:light[level=12]
fill 408 299 277 408 300 277 minecraft:stripped_oak_log
fill 408 299 279 408 300 279 minecraft:stripped_oak_log
fill 408 299 281 408 300 281 minecraft:stripped_oak_log
fill 408 299 283 408 300 283 minecraft:stripped_oak_log
fill 409 299 276 409 300 276 minecraft:stripped_oak_log
fill 409 299 278 409 300 278 minecraft:stripped_oak_log
fill 409 299 280 409 300 280 minecraft:stripped_oak_log
fill 409 299 282 409 300 282 minecraft:stripped_oak_log
fill 410 299 277 410 300 277 minecraft:stripped_oak_log
fill 410 299 279 410 300 279 minecraft:stripped_oak_log
fill 410 299 281 410 300 281 minecraft:stripped_oak_log
fill 410 299 283 410 300 283 minecraft:stripped_oak_log
fill 413 299 280 413 300 280 minecraft:stripped_oak_log
fill 413 299 282 413 300 282 minecraft:stripped_oak_log
fill 413 299 284 413 300 284 minecraft:stripped_oak_log
fill 413 299 286 413 300 286 minecraft:stripped_oak_log
fill 413 299 288 413 300 288 minecraft:stripped_oak_log
fill 413 299 290 413 300 290 minecraft:stripped_oak_log
setblock 414 299 278 minecraft:light[level=12]
fill 414 299 281 414 300 281 minecraft:stripped_oak_log
fill 414 299 283 414 300 283 minecraft:stripped_oak_log
fill 414 299 285 414 300 285 minecraft:stripped_oak_log
fill 414 299 287 414 300 287 minecraft:stripped_oak_log
fill 414 299 289 414 300 289 minecraft:stripped_oak_log
setblock 414 299 292 minecraft:light[level=12]
setblock 414 299 299 minecraft:light[level=12]
setblock 414 299 306 minecraft:light[level=12]
setblock 414 299 313 minecraft:light[level=12]
fill 415 299 280 416 300 280 minecraft:stripped_oak_log
fill 415 299 282 415 300 282 minecraft:stripped_oak_log
fill 415 299 284 415 300 284 minecraft:red_terracotta
setblock 415 299 286 minecraft:stripped_oak_log
fill 415 299 287 415 300 288 minecraft:red_terracotta
fill 415 299 290 416 299 290 minecraft:stripped_oak_log
fill 416 299 281 416 300 281 minecraft:red_terracotta
fill 416 299 283 416 300 283 minecraft:red_terracotta
setblock 416 299 285 minecraft:stripped_oak_log
fill 416 299 286 416 300 287 minecraft:red_terracotta
setblock 416 299 289 minecraft:red_terracotta
fill 416 299 291 416 300 291 minecraft:red_terracotta
setblock 416 299 305 minecraft:stripped_oak_log
setblock 416 299 306 minecraft:red_terracotta
setblock 417 299 279 minecraft:stripped_oak_log
fill 417 299 280 417 300 280 minecraft:red_terracotta
fill 417 299 282 417 300 282 minecraft:red_terracotta
setblock 417 299 284 minecraft:stripped_oak_log
fill 417 299 285 417 300 286 minecraft:red_terracotta
setblock 417 299 288 minecraft:red_terracotta
setblock 417 299 289 minecraft:stripped_oak_log
fill 417 299 290 417 300 290 minecraft:red_terracotta
setblock 417 299 294 minecraft:stripped_oak_log
fill 417 299 295 417 300 295 minecraft:red_terracotta
setblock 417 299 299 minecraft:stripped_oak_log
fill 417 299 300 417 300 300 minecraft:red_terracotta
setblock 417 299 304 minecraft:stripped_oak_log
fill 417 299 305 417 300 305 minecraft:red_terracotta
setblock 417 299 308 minecraft:red_terracotta
setblock 417 299 309 minecraft:stripped_oak_log
fill 417 299 310 417 300 310 minecraft:red_terracotta
fill 417 299 312 417 300 312 minecraft:red_terracotta
fill 376 300 275 376 303 317 minecraft:brown_terracotta
fill 377 300 275 418 303 275 minecraft:brown_terracotta
setblock 377 300 278 minecraft:stripped_oak_log
setblock 377 300 279 minecraft:red_terracotta
setblock 377 300 283 minecraft:stripped_oak_log
setblock 377 300 284 minecraft:red_terracotta
setblock 377 300 288 minecraft:stripped_oak_log
setblock 377 300 289 minecraft:red_terracotta
setblock 377 300 292 minecraft:red_terracotta
setblock 377 300 293 minecraft:stripped_oak_log
setblock 377 300 294 minecraft:red_terracotta
fill 377 300 302 377 300 303 minecraft:stripped_oak_log
setblock 377 300 304 minecraft:red_terracotta
setblock 377 300 307 minecraft:red_terracotta
setblock 377 300 308 minecraft:stripped_oak_log
setblock 377 300 309 minecraft:red_terracotta
setblock 377 300 313 minecraft:stripped_oak_log
fill 377 300 314 378 300 314 minecraft:red_terracotta
fill 377 300 317 418 303 317 minecraft:brown_terracotta
setblock 378 300 277 minecraft:stripped_oak_log
setblock 378 300 278 minecraft:red_terracotta
setblock 378 300 282 minecraft:stripped_oak_log
setblock 378 300 283 minecraft:red_terracotta
setblock 378 300 287 minecraft:stripped_oak_log
setblock 378 300 288 minecraft:red_terracotta
setblock 378 300 292 minecraft:stripped_oak_log
setblock 378 300 304 minecraft:stripped_oak_log
setblock 378 300 307 minecraft:stripped_oak_log
setblock 378 300 308 minecraft:red_terracotta
setblock 378 300 312 minecraft:stripped_oak_log
setblock 378 300 313 minecraft:red_terracotta
setblock 379 300 276 minecraft:stripped_oak_log
fill 379 300 277 382 300 277 minecraft:red_terracotta
setblock 379 300 281 minecraft:stripped_oak_log
setblock 379 300 282 minecraft:red_terracotta
setblock 379 300 286 minecraft:stripped_oak_log
setblock 379 300 287 minecraft:red_terracotta
setblock 379 300 310 minecraft:red_terracotta
setblock 379 300 315 minecraft:red_terracotta
setblock 379 300 316 minecraft:stripped_oak_log
fill 380 300 276 383 300 276 minecraft:red_terracotta
setblock 380 300 285 minecraft:stripped_oak_log
setblock 380 300 286 minecraft:red_terracotta
setblock 380 300 315 minecraft:stripped_oak_log
setblock 380 300 316 minecraft:red_terracotta
setblock 381 300 315 minecraft:red_terracotta
setblock 383 300 277 minecraft:stripped_oak_log
setblock 384 300 276 minecraft:stripped_oak_log
setblock 384 300 277 minecraft:red_terracotta
setblock 384 300 316 minecraft:stripped_oak_log
setblock 385 300 276 minecraft:red_terracotta
setblock 385 300 315 minecraft:stripped_oak_log
setblock 385 300 316 minecraft:red_terracotta
setblock 386 300 315 minecraft:red_terracotta
fill 387 300 313 387 303 313 minecraft:green_concrete
setblock 389 300 316 minecraft:stripped_oak_log
setblock 394 300 316 minecraft:stripped_oak_log
fill 395 300 316 398 300 316 minecraft:red_terracotta
setblock 399 300 316 minecraft:stripped_oak_log
setblock 400 300 315 minecraft:stripped_oak_log
setblock 400 300 316 minecraft:red_terracotta
setblock 401 300 315 minecraft:red_terracotta
setblock 404 300 316 minecraft:stripped_oak_log
setblock 415 300 285 minecraft:stripped_oak_log
setblock 415 300 286 minecraft:red_terracotta
setblock 415 300 289 minecraft:red_terracotta
setblock 415 300 290 minecraft:stripped_oak_log
setblock 416 300 284 minecraft:stripped_oak_log
setblock 416 300 285 minecraft:red_terracotta
setblock 416 300 289 minecraft:stripped_oak_log
setblock 416 300 290 minecraft:red_terracotta
setblock 416 300 293 minecraft:red_terracotta
setblock 417 300 278 minecraft:stripped_oak_log
setblock 417 300 279 minecraft:red_terracotta
setblock 417 300 283 minecraft:stripped_oak_log
setblock 417 300 284 minecraft:red_terracotta
setblock 417 300 288 minecraft:stripped_oak_log
setblock 417 300 289 minecraft:red_terracotta
setblock 417 300 293 minecraft:stripped_oak_log
setblock 417 300 294 minecraft:red_terracotta
setblock 417 300 298 minecraft:stripped_oak_log
setblock 417 300 299 minecraft:red_terracotta
setblock 417 300 303 minecraft:stripped_oak_log
setblock 417 300 304 minecraft:red_terracotta
setblock 417 300 308 minecraft:stripped_oak_log
setblock 417 300 309 minecraft:red_terracotta
fill 418 300 276 418 303 316 minecraft:brown_terracotta
setblock 379 303 278 minecraft:light[level=15]
setblock 379 303 286 minecraft:light[level=15]
setblock 379 303 294 minecraft:light[level=15]
setblock 379 303 302 minecraft:light[level=15]
setblock 379 303 310 minecraft:light[level=15]
setblock 387 303 278 minecraft:light[level=15]
setblock 387 303 286 minecraft:light[level=15]
setblock 387 303 294 minecraft:light[level=15]
setblock 387 303 302 minecraft:light[level=15]
setblock 387 303 310 minecraft:light[level=15]
setblock 388 303 313 minecraft:green_concrete
setblock 395 303 278 minecraft:light[level=15]
setblock 395 303 286 minecraft:light[level=15]
setblock 395 303 294 minecraft:light[level=15]
setblock 395 303 302 minecraft:light[level=15]
setblock 395 303 310 minecraft:light[level=15]
setblock 403 303 278 minecraft:light[level=15]
setblock 403 303 286 minecraft:light[level=15]
setblock 403 303 294 minecraft:light[level=15]
setblock 403 303 302 minecraft:light[level=15]
setblock 403 303 310 minecraft:light[level=15]
setblock 411 303 278 minecraft:light[level=15]
setblock 411 303 286 minecraft:light[level=15]
setblock 411 303 294 minecraft:light[level=15]
setblock 411 303 302 minecraft:light[level=15]
setblock 411 303 310 minecraft:light[level=15]
fill 376 304 275 376 307 317 minecraft:light_gray_terracotta
fill 377 304 275 418 307 275 minecraft:light_gray_terracotta
fill 377 304 317 418 307 317 minecraft:light_gray_terracotta
fill 418 304 276 418 307 316 minecraft:light_gray_terracotta
fill 376 308 275 376 308 317 minecraft:orange_terracotta
fill 377 308 275 418 308 275 minecraft:orange_terracotta
fill 377 308 317 418 308 317 minecraft:orange_terracotta
fill 418 308 276 418 308 316 minecraft:orange_terracotta
