setblock 238 259 208 minecraft:light[level=13]
setblock 238 259 216 minecraft:light[level=13]
setblock 246 259 184 minecraft:light[level=13]
setblock 246 259 192 minecraft:light[level=13]
setblock 246 259 200 minecraft:light[level=13]
setblock 246 259 208 minecraft:light[level=13]
setblock 246 259 216 minecraft:light[level=13]
setblock 254 259 184 minecraft:light[level=13]
setblock 254 259 192 minecraft:light[level=13]
setblock 254 259 200 minecraft:light[level=13]
setblock 254 259 208 minecraft:light[level=13]
setblock 254 259 216 minecraft:light[level=13]
setblock 262 259 184 minecraft:light[level=13]
setblock 262 259 192 minecraft:light[level=13]
setblock 262 259 200 minecraft:light[level=13]
setblock 262 259 208 minecraft:light[level=13]
setblock 262 259 216 minecraft:light[level=13]
setblock 270 259 184 minecraft:light[level=13]
setblock 270 259 192 minecraft:light[level=13]
setblock 270 259 200 minecraft:light[level=13]
setblock 270 259 208 minecraft:light[level=13]
setblock 270 259 216 minecraft:light[level=13]
fill 236 261 186 236 261 189 minecraft:smooth_stone
fill 236 261 196 236 261 199 minecraft:smooth_stone
fill 236 261 206 236 261 209 minecraft:smooth_stone
fill 236 261 216 236 261 219 minecraft:smooth_stone
fill 237 261 182 240 261 182 minecraft:smooth_stone
fill 240 261 222 243 261 222 minecraft:smooth_stone
fill 247 261 182 250 261 182 minecraft:smooth_stone
fill 250 261 222 253 261 222 minecraft:smooth_stone
fill 257 261 182 260 261 182 minecraft:smooth_stone
fill 260 261 222 263 261 222 minecraft:smooth_stone
fill 267 261 182 270 261 182 minecraft:smooth_stone
fill 270 261 222 273 261 222 minecraft:smooth_stone
fill 276 261 183 276 261 186 minecraft:smooth_stone
fill 276 261 193 276 261 196 minecraft:smooth_stone
fill 276 261 203 276 261 206 minecraft:smooth_stone
fill 276 261 213 276 261 216 minecraft:smooth_stone
setblock 236 264 184 minecraft:smooth_stone
setblock 236 264 194 minecraft:smooth_stone
setblock 236 264 204 minecraft:smooth_stone
setblock 236 264 214 minecraft:smooth_stone
setblock 238 264 222 minecraft:smooth_stone
setblock 242 264 182 minecraft:smooth_stone
setblock 248 264 222 minecraft:smooth_stone
setblock 252 264 182 minecraft:smooth_stone
setblock 258 264 222 minecraft:smooth_stone
setblock 262 264 182 minecraft:smooth_stone
setblock 268 264 222 minecraft:smooth_stone
setblock 272 264 182 minecraft:smooth_stone
setblock 276 264 188 minecraft:smooth_stone
setblock 276 264 198 minecraft:smooth_stone
setblock 276 264 208 minecraft:smooth_stone
setblock 276 264 218 minecraft:smooth_stone
fill 235 265 187 235 265 190 minecraft:ochre_froglight
fill 235 265 197 235 265 200 minecraft:ochre_froglight
fill 235 265 207 235 265 210 minecraft:ochre_froglight
fill 235 265 217 235 265 220 minecraft:ochre_froglight
fill 238 265 181 241 265 181 minecraft:ochre_froglight
fill 239 265 223 242 265 223 minecraft:ochre_froglight
fill 248 265 181 251 265 181 minecraft:ochre_froglight
fill 249 265 223 252 265 223 minecraft:ochre_froglight
fill 258 265 181 261 265 181 minecraft:ochre_froglight
fill 259 265 223 262 265 223 minecraft:ochre_froglight
fill 268 265 181 271 265 181 minecraft:ochre_froglight
fill 269 265 223 272 265 223 minecraft:ochre_froglight
fill 277 265 182 277 265 185 minecraft:ochre_froglight
fill 277 265 192 277 265 195 minecraft:ochre_froglight
fill 277 265 202 277 265 205 minecraft:ochre_froglight
fill 277 265 212 277 265 215 minecraft:ochre_froglight
setblock 277 265 222 minecraft:ochre_froglight
fill 235 266 187 235 282 190 minecraft:polished_andesite
fill 235 266 197 235 282 200 minecraft:polished_andesite
fill 235 266 207 235 282 210 minecraft:polished_andesite
fill 235 266 217 235 282 220 minecraft:polished_andesite
fill 238 266 181 241 282 181 minecraft:polished_andesite
fill 239 266 223 242 282 223 minecraft:polished_andesite
fill 248 266 181 251 282 181 minecraft:polished_andesite
fill 249 266 223 252 282 223 minecraft:polished_andesite
fill 258 266 181 261 282 181 minecraft:polished_andesite
fill 259 266 223 262 282 223 minecraft:polished_andesite
fill 268 266 181 271 282 181 minecraft:polished_andesite
fill 269 266 223 272 282 223 minecraft:polished_andesite
fill 277 266 182 277 282 185 minecraft:polished_andesite
fill 277 266 192 277 282 195 minecraft:polished_andesite
fill 277 266 202 277 282 205 minecraft:polished_andesite
fill 277 266 212 277 282 215 minecraft:polished_andesite
fill 277 266 222 277 282 222 minecraft:polished_andesite
setblock 238 267 184 minecraft:light[level=13]
setblock 238 267 192 minecraft:light[level=13]
setblock 238 267 200 minecraft:light[level=13]
setblock 238 267 208 minecraft:light[level=13]
setblock 238 267 216 minecraft:light[level=13]
setblock 246 267 184 minecraft:light[level=13]
setblock 246 267 192 minecraft:light[level=13]
setblock 246 267 200 minecraft:light[level=13]
setblock 246 267 208 minecraft:light[level=13]
setblock 246 267 216 minecraft:light[level=13]
setblock 254 267 184 minecraft:light[level=13]
setblock 254 267 192 minecraft:light[level=13]
setblock 254 267 200 minecraft:light[level=13]
setblock 254 267 208 minecraft:light[level=13]
setblock 254 267 216 minecraft:light[level=13]
setblock 262 267 184 minecraft:light[level=13]
setblock 262 267 192 minecraft:light[level=13]
setblock 262 267 200 minecraft:light[level=13]
setblock 262 267 208 minecraft:light[level=13]
setblock 262 267 216 minecraft:light[level=13]
setblock 270 267 184 minecraft:light[level=13]
setblock 270 267 192 minecraft:light[level=13]
setblock 270 267 200 minecraft:light[level=13]
setblock 270 267 208 minecraft:light[level=13]
setblock 270 267 216 minecraft:light[level=13]
setblock 236 270 184 minecraft:smooth_stone
fill 236 270 186 236 270 189 minecraft:smooth_stone
setblock 236 270 194 minecraft:smooth_stone
fill 236 270 196 236 270 199 minecraft:smooth_stone
setblock 236 270 204 minecraft:smooth_stone
fill 236 270 206 236 270 209 minecraft:smooth_stone
setblock 236 270 214 minecraft:smooth_stone
fill 236 270 216 236 270 219 minecraft:smooth_stone
fill 237 270 182 240 270 182 minecraft:smooth_stone
setblock 238 270 222 minecraft:smooth_stone
fill 240 270 222 243 270 222 minecraft:smooth_stone
setblock 242 270 182 minecraft:smooth_stone
fill 247 270 182 250 270 182 minecraft:smooth_stone
setblock 248 270 222 minecraft:smooth_stone
fill 250 270 222 253 270 222 minecraft:smooth_stone
setblock 252 270 182 minecraft:smooth_stone
fill 257 270 182 260 270 182 minecraft:smooth_stone
setblock 258 270 222 minecraft:smooth_stone
fill 260 270 222 263 270 222 minecraft:smooth_stone
setblock 262 270 182 minecraft:smooth_stone
fill 267 270 182 270 270 182 minecraft:smooth_stone
setblock 268 270 222 minecraft:smooth_stone
fill 270 270 222 273 270 222 minecraft:smooth_stone
setblock 272 270 182 minecraft:smooth_stone
fill 276 270 183 276 270 186 minecraft:smooth_stone
setblock 276 270 188 minecraft:smooth_stone
fill 276 270 193 276 270 196 minecraft:smooth_stone
setblock 276 270 198 minecraft:smooth_stone
fill 276 270 203 276 270 206 minecraft:smooth_stone
setblock 276 270 208 minecraft:smooth_stone
fill 276 270 213 276 270 216 minecraft:smooth_stone
setblock 276 270 218 minecraft:smooth_stone
setblock 238 275 184 minecraft:light[level=13]
setblock 238 275 192 minecraft:light[level=13]
setblock 238 275 200 minecraft:light[level=13]
setblock 238 275 208 minecraft:light[level=13]
setblock 238 275 216 minecraft:light[level=13]
setblock 246 275 184 minecraft:light[level=13]
setblock 246 275 192 minecraft:light[level=13]
setblock 246 275 200 minecraft:light[level=13]
setblock 246 275 208 minecraft:light[level=13]
setblock 246 275 216 minecraft:light[level=13]
setblock 254 275 184 minecraft:light[level=13]
setblock 254 275 192 minecraft:light[level=13]
setblock 254 275 200 minecraft:light[level=13]
setblock 254 275 208 minecraft:light[level=13]
setblock 254 275 216 minecraft:light[level=13]
setblock 262 275 184 minecraft:light[level=13]
setblock 262 275 192 minecraft:light[level=13]
setblock 262 275 200 minecraft:light[level=13]
setblock 262 275 208 minecraft:light[level=13]
setblock 262 275 216 minecraft:light[level=13]
setblock 270 275 184 minecraft:light[level=13]
setblock 270 275 192 minecraft:light[level=13]
setblock 270 275 200 minecraft:light[level=13]
setblock 270 275 208 minecraft:light[level=13]
setblock 270 275 216 minecraft:light[level=13]
fill 244 277 203 254 278 203 minecraft:iron_block
fill 245 277 200 255 278 202 minecraft:iron_block
fill 245 277 207 268 278 208 minecraft:iron_block
fill 246 277 196 267 278 196 minecraft:iron_block
fill 246 277 209 268 278 209 minecraft:iron_block
fill 247 277 195 266 278 195 minecraft:iron_block
fill 247 277 199 271 278 199 minecraft:iron_block
fill 247 277 204 255 278 206 minecraft:iron_block
fill 248 277 194 248 279 194 minecraft:iron_block
fill 248 277 197 270 278 198 minecraft:iron_block
fill 249 277 210 270 278 210 minecraft:iron_block
fill 249 277 213 264 279 213 minecraft:iron_block
fill 250 277 211 265 278 212 minecraft:iron_block
fill 250 277 214 251 279 214 minecraft:iron_block
fill 251 277 194 266 278 194 minecraft:iron_block
fill 251 277 215 251 279 215 minecraft:iron_block
fill 252 277 191 254 279 193 minecraft:iron_block
fill 253 277 190 254 279 190 minecraft:iron_block
fill 254 277 214 264 279 214 minecraft:iron_block
fill 255 277 192 262 279 193 minecraft:iron_block
fill 255 277 215 258 279 216 minecraft:iron_block
fill 256 277 200 257 278 200 minecraft:iron_block
fill 256 277 206 257 278 206 minecraft:iron_block
fill 258 277 189 258 279 191 minecraft:iron_block
fill 258 277 217 258 279 217 minecraft:iron_block
fill 259 277 190 261 279 191 minecraft:iron_block
fill 259 277 200 269 278 200 minecraft:iron_block
fill 259 277 206 271 278 206 minecraft:iron_block
fill 261 277 201 269 278 202 minecraft:iron_block
fill 261 277 204 271 278 205 minecraft:iron_block
fill 262 277 203 272 278 203 minecraft:iron_block
fill 262 277 215 263 279 216 minecraft:iron_block
fill 263 277 193 267 279 193 minecraft:iron_block
fill 264 277 215 264 279 215 minecraft:iron_block
fill 265 277 191 265 279 192 minecraft:iron_block
fill 266 277 192 266 279 192 minecraft:iron_block
fill 266 277 211 269 279 211 minecraft:iron_block
fill 268 277 212 268 279 212 minecraft:iron_block
fill 269 277 207 269 279 207 minecraft:iron_block
fill 271 277 198 271 279 198 minecraft:iron_block
fill 236 279 182 243 279 222 minecraft:gray_concrete
fill 244 279 182 244 279 202 minecraft:gray_concrete
fill 244 279 203 253 279 203 minecraft:iron_block
fill 244 279 204 244 279 222 minecraft:gray_concrete
fill 245 279 182 245 279 199 minecraft:gray_concrete
fill 245 279 200 253 279 202 minecraft:iron_block
fill 245 279 204 246 279 206 minecraft:gray_concrete
fill 245 279 207 249 279 208 minecraft:iron_block
fill 245 279 209 245 279 222 minecraft:gray_concrete
fill 246 279 182 246 279 195 minecraft:gray_concrete
fill 246 279 196 253 279 196 minecraft:iron_block
fill 246 279 197 246 279 199 minecraft:gray_concrete
fill 246 279 209 250 279 209 minecraft:iron_block
fill 246 279 210 248 279 222 minecraft:gray_concrete
fill 247 279 182 247 279 194 minecraft:gray_concrete
fill 247 279 195 253 279 195 minecraft:iron_block
fill 247 279 197 247 279 198 minecraft:gray_concrete
fill 247 279 199 255 279 199 minecraft:iron_block
fill 247 279 204 248 279 206 minecraft:iron_block
fill 248 279 182 251 279 193 minecraft:gray_concrete
fill 248 279 197 254 279 198 minecraft:iron_block
fill 249 279 194 250 279 194 minecraft:gray_concrete
fill 249 279 204 253 279 206 minecraft:redstone_block
fill 249 279 210 251 279 210 minecraft:iron_block
fill 249 279 211 249 279 212 minecraft:gray_concrete
fill 249 279 214 249 279 222 minecraft:gray_concrete
fill 250 279 207 255 279 208 minecraft:redstone_block
fill 250 279 211 252 279 212 minecraft:iron_block
fill 250 279 215 250 279 222 minecraft:gray_concrete
fill 251 279 194 254 279 194 minecraft:iron_block
fill 251 279 209 254 279 209 minecraft:redstone_block
fill 251 279 216 254 279 222 minecraft:gray_concrete
fill 252 279 182 252 279 190 minecraft:gray_concrete
fill 252 279 210 253 279 210 minecraft:redstone_block
fill 252 279 214 253 279 215 minecraft:gray_concrete
fill 253 279 182 257 279 189 minecraft:gray_concrete
setblock 253 279 211 minecraft:redstone_block
fill 253 279 212 265 279 212 minecraft:iron_block
fill 254 279 195 262 279 196 minecraft:redstone_block
fill 254 279 200 254 279 201 minecraft:iron_block
fill 254 279 202 254 279 204 minecraft:ochre_froglight
fill 254 279 205 254 279 206 minecraft:redstone_block
fill 254 279 210 262 279 211 minecraft:iron_block
setblock 254 279 215 minecraft:gray_concrete
fill 255 279 190 257 279 191 minecraft:gray_concrete
fill 255 279 194 261 279 194 minecraft:redstone_block
fill 255 279 197 261 279 197 minecraft:redstone_block
setblock 255 279 198 minecraft:iron_block
fill 255 279 200 255 279 202 minecraft:ochre_froglight
fill 255 279 204 255 279 206 minecraft:ochre_froglight
fill 255 279 209 261 279 209 minecraft:iron_block
fill 255 279 217 257 279 222 minecraft:gray_concrete
fill 256 279 198 256 279 199 minecraft:redstone_block
fill 256 279 200 257 279 200 minecraft:ochre_froglight
fill 256 279 206 257 279 206 minecraft:ochre_froglight
fill 256 279 207 256 279 208 minecraft:iron_block
fill 257 279 198 260 279 198 minecraft:redstone_block
fill 257 279 199 259 279 199 minecraft:ochre_froglight
fill 257 279 207 259 279 207 minecraft:ochre_froglight
fill 257 279 208 260 279 208 minecraft:iron_block
fill 258 279 182 276 279 188 minecraft:gray_concrete
fill 258 279 218 276 279 222 minecraft:gray_concrete
fill 259 279 189 276 279 189 minecraft:gray_concrete
fill 259 279 200 261 279 200 minecraft:ochre_froglight
fill 259 279 206 261 279 206 minecraft:ochre_froglight
fill 259 279 215 261 279 217 minecraft:gray_concrete
setblock 260 279 199 minecraft:redstone_block
setblock 260 279 207 minecraft:iron_block
fill 261 279 198 270 279 199 minecraft:iron_block
fill 261 279 201 261 279 202 minecraft:ochre_froglight
fill 261 279 204 261 279 205 minecraft:ochre_froglight
fill 261 279 207 266 279 208 minecraft:redstone_block
fill 262 279 190 264 279 191 minecraft:gray_concrete
fill 262 279 194 266 279 194 minecraft:iron_block
fill 262 279 197 270 279 197 minecraft:iron_block
fill 262 279 200 269 279 201 minecraft:iron_block
fill 262 279 202 262 279 204 minecraft:ochre_froglight
fill 262 279 205 267 279 206 minecraft:redstone_block
fill 262 279 209 265 279 209 minecraft:redstone_block
fill 262 279 217 276 279 217 minecraft:gray_concrete
fill 263 279 192 264 279 192 minecraft:gray_concrete
fill 263 279 195 266 279 196 minecraft:iron_block
fill 263 279 202 269 279 202 minecraft:iron_block
fill 263 279 203 267 279 204 minecraft:redstone_block
fill 263 279 210 263 279 211 minecraft:redstone_block
setblock 264 279 210 minecraft:redstone_block
fill 264 279 211 265 279 211 minecraft:iron_block
fill 264 279 216 276 279 216 minecraft:gray_concrete
fill 265 279 190 276 279 190 minecraft:gray_concrete
fill 265 279 210 270 279 210 minecraft:iron_block
fill 265 279 213 276 279 215 minecraft:gray_concrete
fill 266 279 191 276 279 191 minecraft:gray_concrete
fill 266 279 209 268 279 209 minecraft:iron_block
fill 266 279 212 267 279 212 minecraft:gray_concrete
fill 267 279 192 276 279 192 minecraft:gray_concrete
fill 267 279 194 276 279 195 minecraft:gray_concrete
setblock 267 279 196 minecraft:iron_block
fill 267 279 207 268 279 208 minecraft:iron_block
fill 268 279 193 276 279 193 minecraft:gray_concrete
fill 268 279 196 276 279 196 minecraft:gray_concrete
fill 268 279 203 271 279 206 minecraft:iron_block
fill 269 279 208 276 279 209 minecraft:gray_concrete
fill 269 279 212 276 279 212 minecraft:gray_concrete
fill 270 279 200 276 279 202 minecraft:gray_concrete
fill 270 279 207 276 279 207 minecraft:gray_concrete
fill 270 279 211 276 279 211 minecraft:gray_concrete
fill 271 279 197 276 279 197 minecraft:gray_concrete
setblock 271 279 199 minecraft:iron_block
fill 271 279 210 276 279 210 minecraft:gray_concrete
fill 272 279 198 276 279 199 minecraft:gray_concrete
setblock 272 279 203 minecraft:iron_block
fill 272 279 204 276 279 206 minecraft:gray_concrete
fill 273 279 203 276 279 203 minecraft:gray_concrete
fill 235 283 187 235 283 190 minecraft:ochre_froglight
fill 235 283 197 235 283 200 minecraft:ochre_froglight
fill 235 283 207 235 283 210 minecraft:ochre_froglight
fill 235 283 217 235 283 220 minecraft:ochre_froglight
fill 236 283 183 236 300 183 minecraft:iron_block
fill 236 283 193 236 300 193 minecraft:iron_block
fill 236 283 203 236 300 203 minecraft:iron_block
fill 236 283 213 236 300 213 minecraft:iron_block
fill 237 283 222 237 300 222 minecraft:iron_block
fill 238 283 181 241 283 181 minecraft:ochre_froglight
setblock 238 283 184 minecraft:light[level=13]
setblock 238 283 192 minecraft:light[level=13]
setblock 238 283 200 minecraft:light[level=13]
setblock 238 283 208 minecraft:light[level=13]
setblock 238 283 216 minecraft:light[level=13]
fill 239 283 223 242 283 223 minecraft:ochre_froglight
fill 243 283 182 243 300 182 minecraft:iron_block
setblock 246 283 184 minecraft:light[level=13]
setblock 246 283 192 minecraft:light[level=13]
setblock 246 283 200 minecraft:light[level=13]
setblock 246 283 208 minecraft:light[level=13]
setblock 246 283 216 minecraft:light[level=13]
fill 247 283 222 247 300 222 minecraft:iron_block
fill 248 283 181 251 283 181 minecraft:ochre_froglight
fill 249 283 223 252 283 223 minecraft:ochre_froglight
fill 253 283 182 253 300 182 minecraft:iron_block
setblock 254 283 184 minecraft:light[level=13]
setblock 254 283 192 minecraft:light[level=13]
setblock 254 283 200 minecraft:light[level=13]
setblock 254 283 208 minecraft:light[level=13]
setblock 254 283 216 minecraft:light[level=13]
fill 257 283 222 257 300 222 minecraft:iron_block
fill 258 283 181 261 283 181 minecraft:ochre_froglight
fill 259 283 223 262 283 223 minecraft:ochre_froglight
setblock 262 283 184 minecraft:light[level=13]
setblock 262 283 192 minecraft:light[level=13]
setblock 262 283 200 minecraft:light[level=13]
setblock 262 283 208 minecraft:light[level=13]
setblock 262 283 216 minecraft:light[level=13]
fill 263 283 182 263 300 182 minecraft:iron_block
fill 267 283 222 267 300 222 minecraft:iron_block
fill 268 283 181 271 283 181 minecraft:ochre_froglight
fill 269 283 223 272 283 223 minecraft:ochre_froglight
setblock 270 283 184 minecraft:light[level=13]
setblock 270 283 192 minecraft:light[level=13]
setblock 270 283 200 minecraft:light[level=13]
setblock 270 283 208 minecraft:light[level=13]
setblock 270 283 216 minecraft:light[level=13]
fill 272 283 200 274 300 202 minecraft:iron_block
fill 273 283 182 273 300 182 minecraft:iron_block
fill 276 283 189 276 300 189 minecraft:iron_block
fill 276 283 199 276 300 199 minecraft:iron_block
fill 276 283 209 276 300 209 minecraft:iron_block
fill 276 283 219 276 300 219 minecraft:iron_block
fill 277 283 182 277 283 185 minecraft:ochre_froglight
fill 277 283 192 277 283 195 minecraft:ochre_froglight
fill 277 283 202 277 283 205 minecraft:ochre_froglight
fill 277 283 212 277 283 215 minecraft:ochre_froglight
setblock 277 283 222 minecraft:ochre_froglight
fill 235 284 187 235 291 190 minecraft:polished_andesite
fill 235 284 197 235 291 200 minecraft:polished_andesite
fill 235 284 207 235 291 210 minecraft:polished_andesite
fill 235 284 217 235 291 220 minecraft:polished_andesite
fill 238 284 181 241 291 181 minecraft:polished_andesite
fill 239 284 223 242 291 223 minecraft:polished_andesite
fill 248 284 181 251 291 181 minecraft:polished_andesite
fill 249 284 223 252 291 223 minecraft:polished_andesite
fill 258 284 181 261 291 181 minecraft:polished_andesite
fill 259 284 223 262 291 223 minecraft:polished_andesite
fill 268 284 181 271 291 181 minecraft:polished_andesite
fill 269 284 223 272 291 223 minecraft:polished_andesite
fill 277 284 182 277 291 185 minecraft:polished_andesite
fill 277 284 192 277 291 195 minecraft:polished_andesite
fill 277 284 202 277 291 205 minecraft:polished_andesite
fill 277 284 212 277 291 215 minecraft:polished_andesite
fill 277 284 222 277 291 222 minecraft:polished_andesite
fill 271 285 200 271 285 202 minecraft:smooth_stone
fill 272 285 199 274 285 199 minecraft:smooth_stone
fill 272 285 203 274 285 203 minecraft:smooth_stone
fill 275 285 200 275 285 202 minecraft:smooth_stone
setblock 236 288 184 minecraft:smooth_stone
fill 236 288 186 236 288 189 minecraft:smooth_stone
setblock 236 288 194 minecraft:smooth_stone
fill 236 288 196 236 288 199 minecraft:smooth_stone
setblock 236 288 204 minecraft:smooth_stone
fill 236 288 206 236 288 209 minecraft:smooth_stone
setblock 236 288 214 minecraft:smooth_stone
fill 236 288 216 236 288 219 minecraft:smooth_stone
fill 237 288 182 240 288 182 minecraft:smooth_stone
setblock 238 288 222 minecraft:smooth_stone
fill 240 288 222 243 288 222 minecraft:smooth_stone
setblock 242 288 182 minecraft:smooth_stone
fill 247 288 182 250 288 182 minecraft:smooth_stone
setblock 248 288 222 minecraft:smooth_stone
fill 250 288 222 253 288 222 minecraft:smooth_stone
setblock 252 288 182 minecraft:smooth_stone
fill 257 288 182 260 288 182 minecraft:smooth_stone
setblock 258 288 222 minecraft:smooth_stone
fill 260 288 222 263 288 222 minecraft:smooth_stone
setblock 262 288 182 minecraft:smooth_stone
fill 267 288 182 270 288 182 minecraft:smooth_stone
setblock 268 288 222 minecraft:smooth_stone
fill 270 288 222 273 288 222 minecraft:smooth_stone
setblock 272 288 182 minecraft:smooth_stone
fill 276 288 183 276 288 186 minecraft:smooth_stone
setblock 276 288 188 minecraft:smooth_stone
fill 276 288 193 276 288 196 minecraft:smooth_stone
setblock 276 288 198 minecraft:smooth_stone
fill 276 288 203 276 288 206 minecraft:smooth_stone
setblock 276 288 208 minecraft:smooth_stone
fill 276 288 213 276 288 216 minecraft:smooth_stone
setblock 276 288 218 minecraft:smooth_stone
setblock 238 291 184 minecraft:light[level=13]
setblock 238 291 192 minecraft:light[level=13]
setblock 238 291 200 minecraft:light[level=13]
setblock 238 291 208 minecraft:light[level=13]
setblock 238 291 216 minecraft:light[level=13]
setblock 246 291 184 minecraft:light[level=13]
setblock 246 291 192 minecraft:light[level=13]
setblock 246 291 200 minecraft:light[level=13]
setblock 246 291 208 minecraft:light[level=13]
setblock 246 291 216 minecraft:light[level=13]
setblock 254 291 184 minecraft:light[level=13]
setblock 254 291 192 minecraft:light[level=13]
setblock 254 291 200 minecraft:light[level=13]
setblock 254 291 208 minecraft:light[level=13]
setblock 254 291 216 minecraft:light[level=13]
setblock 262 291 184 minecraft:light[level=13]
setblock 262 291 192 minecraft:light[level=13]
setblock 262 291 200 minecraft:light[level=13]
setblock 262 291 208 minecraft:light[level=13]
setblock 262 291 216 minecraft:light[level=13]
setblock 270 291 184 minecraft:light[level=13]
setblock 270 291 192 minecraft:light[level=13]
setblock 270 291 200 minecraft:light[level=13]
setblock 270 291 208 minecraft:light[level=13]
setblock 270 291 216 minecraft:light[level=13]
fill 271 291 200 271 291 202 minecraft:smooth_stone
fill 272 291 199 274 291 199 minecraft:smooth_stone
fill 272 291 203 274 291 203 minecraft:smooth_stone
fill 275 291 200 275 291 202 minecraft:smooth_stone
fill 235 292 187 235 292 190 minecraft:ochre_froglight
fill 235 292 197 235 292 200 minecraft:ochre_froglight
fill 235 292 207 235 292 210 minecraft:ochre_froglight
fill 235 292 217 235 292 220 minecraft:ochre_froglight
fill 238 292 181 241 292 181 minecraft:ochre_froglight
fill 239 292 223 242 292 223 minecraft:ochre_froglight
fill 248 292 181 251 292 181 minecraft:ochre_froglight
fill 249 292 223 252 292 223 minecraft:ochre_froglight
fill 258 292 181 261 292 181 minecraft:ochre_froglight
fill 259 292 223 262 292 223 minecraft:ochre_froglight
fill 268 292 181 271 292 181 minecraft:ochre_froglight
fill 269 292 182 269 293 184 minecraft:iron_block
fill 269 292 223 272 292 223 minecraft:ochre_froglight
fill 277 292 182 277 292 185 minecraft:ochre_froglight
fill 277 292 192 277 292 195 minecraft:ochre_froglight
fill 277 292 202 277 292 205 minecraft:ochre_froglight
fill 277 292 212 277 292 215 minecraft:ochre_froglight
setblock 277 292 222 minecraft:ochre_froglight
fill 235 293 187 235 307 190 minecraft:polished_andesite
fill 235 293 197 235 307 200 minecraft:polished_andesite
fill 235 293 207 235 307 210 minecraft:polished_andesite
fill 235 293 217 235 307 220 minecraft:polished_andesite
fill 238 293 181 241 307 181 minecraft:polished_andesite
fill 239 293 223 242 307 223 minecraft:polished_andesite
fill 248 293 181 251 307 181 minecraft:polished_andesite
fill 249 293 223 252 307 223 minecraft:polished_andesite
fill 258 293 181 261 307 181 minecraft:polished_andesite
fill 259 293 223 262 307 223 minecraft:polished_andesite
fill 268 293 181 271 307 181 minecraft:polished_andesite
fill 269 293 223 272 307 223 minecraft:polished_andesite
fill 277 293 182 277 307 185 minecraft:polished_andesite
fill 277 293 192 277 307 195 minecraft:polished_andesite
fill 277 293 202 277 307 205 minecraft:polished_andesite
fill 277 293 212 277 307 215 minecraft:polished_andesite
fill 277 293 222 277 307 222 minecraft:polished_andesite
setblock 236 294 184 minecraft:smooth_stone
setblock 236 294 194 minecraft:smooth_stone
setblock 236 294 204 minecraft:smooth_stone
setblock 236 294 214 minecraft:smooth_stone
setblock 238 294 222 minecraft:smooth_stone
setblock 242 294 182 minecraft:smooth_stone
setblock 248 294 222 minecraft:smooth_stone
setblock 252 294 182 minecraft:smooth_stone
setblock 258 294 222 minecraft:smooth_stone
setblock 262 294 182 minecraft:smooth_stone
setblock 268 294 222 minecraft:smooth_stone
setblock 272 294 182 minecraft:smooth_stone
setblock 276 294 188 minecraft:smooth_stone
setblock 276 294 198 minecraft:smooth_stone
setblock 276 294 208 minecraft:smooth_stone
setblock 276 294 218 minecraft:smooth_stone
fill 236 297 186 236 297 189 minecraft:smooth_stone
fill 236 297 196 236 297 199 minecraft:smooth_stone
fill 236 297 206 236 297 209 minecraft:smooth_stone
fill 236 297 216 236 297 219 minecraft:smooth_stone
fill 237 297 182 240 297 182 minecraft:smooth_stone
fill 240 297 222 243 297 222 minecraft:smooth_stone
fill 247 297 182 250 297 182 minecraft:smooth_stone
fill 250 297 222 253 297 222 minecraft:smooth_stone
fill 257 297 182 260 297 182 minecraft:smooth_stone
fill 260 297 222 263 297 222 minecraft:smooth_stone
fill 267 297 182 270 297 182 minecraft:smooth_stone
fill 270 297 222 273 297 222 minecraft:smooth_stone
fill 271 297 200 271 297 202 minecraft:smooth_stone
fill 272 297 199 274 297 199 minecraft:smooth_stone
fill 272 297 203 274 297 203 minecraft:smooth_stone
fill 275 297 200 275 297 202 minecraft:smooth_stone
fill 276 297 183 276 297 186 minecraft:smooth_stone
fill 276 297 193 276 297 196 minecraft:smooth_stone
fill 276 297 203 276 297 206 minecraft:smooth_stone
fill 276 297 213 276 297 216 minecraft:smooth_stone
fill 275 298 200 276 299 202 minecraft:iron_block
setblock 238 299 184 minecraft:light[level=13]
setblock 238 299 192 minecraft:light[level=13]
setblock 238 299 200 minecraft:light[level=13]
setblock 238 299 208 minecraft:light[level=13]
setblock 238 299 216 minecraft:light[level=13]
setblock 246 299 184 minecraft:light[level=13]
setblock 246 299 192 minecraft:light[level=13]
setblock 246 299 200 minecraft:light[level=13]
setblock 246 299 208 minecraft:light[level=13]
setblock 246 299 216 minecraft:light[level=13]
setblock 254 299 184 minecraft:light[level=13]
setblock 254 299 192 minecraft:light[level=13]
setblock 254 299 200 minecraft:light[level=13]
setblock 254 299 208 minecraft:light[level=13]
setblock 254 299 216 minecraft:light[level=13]
setblock 262 299 184 minecraft:light[level=13]
setblock 262 299 192 minecraft:light[level=13]
setblock 262 299 200 minecraft:light[level=13]
setblock 262 299 208 minecraft:light[level=13]
setblock 262 299 216 minecraft:light[level=13]
setblock 270 299 184 minecraft:light[level=13]
setblock 270 299 192 minecraft:light[level=13]
setblock 270 299 200 minecraft:light[level=13]
setblock 270 299 208 minecraft:light[level=13]
setblock 270 299 216 minecraft:light[level=13]
setblock 271 299 201 minecraft:ochre_froglight
setblock 236 300 184 minecraft:smooth_stone
setblock 236 300 194 minecraft:smooth_stone
setblock 236 300 204 minecraft:smooth_stone
setblock 236 300 214 minecraft:smooth_stone
setblock 238 300 222 minecraft:smooth_stone
setblock 242 300 182 minecraft:smooth_stone
setblock 248 300 222 minecraft:smooth_stone
setblock 252 300 182 minecraft:smooth_stone
setblock 258 300 222 minecraft:smooth_stone
setblock 262 300 182 minecraft:smooth_stone
setblock 268 300 222 minecraft:smooth_stone
setblock 272 300 182 minecraft:smooth_stone
setblock 276 300 188 minecraft:smooth_stone
setblock 276 300 198 minecraft:smooth_stone
setblock 276 300 208 minecraft:smooth_stone
setblock 276 300 218 minecraft:smooth_stone
