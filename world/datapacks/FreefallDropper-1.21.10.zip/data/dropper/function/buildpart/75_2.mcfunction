setblock 161 4 362 minecraft:dark_prismarine
fill 161 4 363 161 7 363 minecraft:blue_terracotta
setblock 165 4 363 minecraft:dark_prismarine
fill 166 4 363 166 7 363 minecraft:blue_terracotta
fill 168 4 362 170 4 362 minecraft:blue_terracotta
setblock 170 4 363 minecraft:dark_prismarine
setblock 171 4 361 minecraft:blue_terracotta
setblock 171 4 362 minecraft:dark_prismarine
fill 171 4 363 171 7 363 minecraft:blue_terracotta
setblock 172 4 361 minecraft:dark_prismarine
fill 172 4 362 172 7 362 minecraft:blue_terracotta
fill 173 4 323 174 4 323 minecraft:blue_terracotta
setblock 173 4 360 minecraft:dark_prismarine
fill 173 4 361 173 7 361 minecraft:blue_terracotta
fill 174 4 360 177 4 360 minecraft:blue_terracotta
setblock 175 4 323 minecraft:dark_prismarine
fill 175 4 337 175 33 337 minecraft:magenta_terracotta
fill 175 4 355 175 4 357 minecraft:purple_concrete
setblock 175 4 363 minecraft:dark_prismarine
fill 176 4 323 176 7 323 minecraft:blue_terracotta
setblock 176 4 354 minecraft:purple_concrete
setblock 176 4 358 minecraft:purple_concrete
setblock 176 4 361 minecraft:blue_terracotta
setblock 176 4 362 minecraft:dark_prismarine
fill 176 4 363 176 7 363 minecraft:blue_terracotta
fill 176 4 364 176 127 364 minecraft:black_concrete
fill 177 4 353 178 4 353 minecraft:purple_concrete
fill 177 4 359 178 4 359 minecraft:purple_concrete
setblock 177 4 361 minecraft:dark_prismarine
fill 177 4 362 177 7 362 minecraft:blue_terracotta
fill 178 4 361 179 6 361 minecraft:blue_terracotta
setblock 180 4 354 minecraft:blue_terracotta
setblock 180 4 358 minecraft:dark_prismarine
fill 180 4 359 180 6 360 minecraft:blue_terracotta
setblock 180 4 363 minecraft:dark_prismarine
setblock 181 4 336 minecraft:blue_terracotta
setblock 181 4 337 minecraft:dark_prismarine
fill 181 4 338 181 5 340 minecraft:blue_terracotta
fill 181 4 352 181 6 352 minecraft:dark_prismarine
fill 181 4 353 181 6 353 minecraft:blue_terracotta
setblock 181 4 357 minecraft:dark_prismarine
fill 181 4 358 181 6 358 minecraft:blue_terracotta
fill 181 4 363 181 7 363 minecraft:blue_terracotta
setblock 182 4 336 minecraft:dark_prismarine
fill 182 4 337 182 7 337 minecraft:blue_terracotta
setblock 182 4 340 minecraft:blue_terracotta
setblock 182 4 341 minecraft:dark_prismarine
fill 182 4 342 182 7 342 minecraft:blue_terracotta
fill 182 4 344 182 5 344 minecraft:blue_terracotta
setblock 182 4 351 minecraft:dark_prismarine
fill 182 4 352 182 7 352 minecraft:blue_terracotta
setblock 182 4 356 minecraft:dark_prismarine
fill 182 4 357 182 6 357 minecraft:blue_terracotta
setblock 182 4 361 minecraft:dark_prismarine
fill 182 4 362 182 7 362 minecraft:blue_terracotta
fill 142 5 331 142 7 331 minecraft:blue_terracotta
setblock 142 5 335 minecraft:dark_prismarine
fill 142 5 336 142 5 339 minecraft:blue_terracotta
setblock 142 5 340 minecraft:dark_prismarine
fill 142 5 341 143 7 341 minecraft:blue_terracotta
setblock 142 5 345 minecraft:dark_prismarine
setblock 142 5 355 minecraft:dark_prismarine
setblock 142 5 356 minecraft:blue_terracotta
setblock 143 5 334 minecraft:dark_prismarine
fill 143 5 335 143 8 335 minecraft:blue_terracotta
setblock 143 5 339 minecraft:dark_prismarine
fill 143 5 340 143 8 340 minecraft:blue_terracotta
setblock 144 5 323 minecraft:purple_concrete
setblock 144 5 325 minecraft:light[level=13]
setblock 144 5 332 minecraft:light[level=12]
setblock 144 5 333 minecraft:light[level=13]
setblock 144 5 339 minecraft:light[level=12]
setblock 144 5 341 minecraft:light[level=13]
setblock 144 5 346 minecraft:light[level=12]
setblock 144 5 349 minecraft:light[level=13]
setblock 144 5 353 minecraft:light[level=12]
setblock 144 5 357 minecraft:light[level=13]
setblock 144 5 360 minecraft:light[level=12]
fill 146 5 340 146 10 340 minecraft:purple_concrete
fill 150 5 323 153 5 323 minecraft:blue_terracotta
fill 150 5 353 150 10 353 minecraft:magenta_terracotta
fill 150 5 363 151 7 363 minecraft:blue_terracotta
setblock 151 5 325 minecraft:light[level=12]
setblock 151 5 332 minecraft:light[level=12]
setblock 151 5 339 minecraft:light[level=12]
setblock 151 5 346 minecraft:light[level=12]
setblock 151 5 353 minecraft:light[level=12]
setblock 151 5 360 minecraft:light[level=12]
setblock 152 5 324 minecraft:blue_terracotta
setblock 152 5 325 minecraft:light[level=13]
setblock 152 5 333 minecraft:light[level=13]
setblock 152 5 341 minecraft:light[level=13]
setblock 152 5 349 minecraft:light[level=13]
setblock 152 5 357 minecraft:light[level=13]
fill 152 5 362 154 5 362 minecraft:blue_terracotta
setblock 153 5 324 minecraft:dark_prismarine
setblock 153 5 363 minecraft:blue_terracotta
setblock 154 5 323 minecraft:dark_prismarine
fill 154 5 324 154 8 324 minecraft:blue_terracotta
setblock 154 5 363 minecraft:dark_prismarine
fill 155 5 323 155 8 323 minecraft:blue_terracotta
setblock 155 5 361 minecraft:blue_terracotta
setblock 155 5 362 minecraft:dark_prismarine
fill 155 5 363 155 8 363 minecraft:blue_terracotta
setblock 156 5 361 minecraft:dark_prismarine
fill 156 5 362 156 8 362 minecraft:blue_terracotta
fill 157 5 361 158 7 361 minecraft:blue_terracotta
setblock 158 5 324 minecraft:dark_prismarine
setblock 158 5 332 minecraft:light[level=12]
setblock 158 5 339 minecraft:light[level=12]
setblock 158 5 346 minecraft:light[level=12]
setblock 158 5 353 minecraft:light[level=12]
setblock 158 5 360 minecraft:light[level=12]
fill 158 5 362 159 5 362 minecraft:blue_terracotta
setblock 159 5 323 minecraft:dark_prismarine
fill 159 5 324 159 8 324 minecraft:blue_terracotta
setblock 159 5 363 minecraft:dark_prismarine
fill 160 5 323 160 8 323 minecraft:blue_terracotta
setblock 160 5 333 minecraft:light[level=13]
setblock 160 5 341 minecraft:light[level=13]
setblock 160 5 349 minecraft:light[level=13]
setblock 160 5 357 minecraft:light[level=13]
setblock 160 5 362 minecraft:dark_prismarine
fill 160 5 363 160 8 363 minecraft:blue_terracotta
fill 161 5 362 164 5 362 minecraft:blue_terracotta
fill 162 5 363 163 5 363 minecraft:blue_terracotta
setblock 163 5 323 minecraft:purple_concrete
setblock 164 5 363 minecraft:dark_prismarine
setblock 165 5 325 minecraft:light[level=12]
setblock 165 5 332 minecraft:light[level=12]
setblock 165 5 339 minecraft:light[level=12]
setblock 165 5 346 minecraft:light[level=12]
setblock 165 5 353 minecraft:light[level=12]
fill 165 5 356 165 33 356 minecraft:magenta_terracotta
setblock 165 5 362 minecraft:dark_prismarine
fill 165 5 363 165 8 363 minecraft:blue_terracotta
fill 166 5 362 169 5 362 minecraft:blue_terracotta
fill 167 5 363 168 5 363 minecraft:blue_terracotta
setblock 168 5 325 minecraft:light[level=13]
setblock 168 5 333 minecraft:light[level=13]
setblock 168 5 341 minecraft:light[level=13]
setblock 168 5 349 minecraft:light[level=13]
setblock 168 5 357 minecraft:light[level=13]
setblock 169 5 323 minecraft:purple_concrete
fill 169 5 361 170 5 361 minecraft:blue_terracotta
setblock 169 5 363 minecraft:dark_prismarine
fill 170 5 323 173 5 323 minecraft:blue_terracotta
fill 170 5 353 170 6 353 minecraft:sea_lantern
setblock 170 5 362 minecraft:dark_prismarine
fill 170 5 363 170 8 363 minecraft:blue_terracotta
setblock 171 5 361 minecraft:dark_prismarine
fill 171 5 362 171 8 362 minecraft:blue_terracotta
setblock 172 5 325 minecraft:light[level=12]
setblock 172 5 332 minecraft:light[level=12]
setblock 172 5 339 minecraft:light[level=12]
setblock 172 5 346 minecraft:light[level=12]
setblock 172 5 353 minecraft:light[level=12]
setblock 172 5 360 minecraft:dark_prismarine
fill 172 5 361 172 8 361 minecraft:blue_terracotta
fill 173 5 360 176 5 360 minecraft:blue_terracotta
setblock 174 5 323 minecraft:dark_prismarine
fill 174 5 351 175 6 359 minecraft:dark_prismarine
setblock 174 5 363 minecraft:dark_prismarine
fill 175 5 323 175 8 323 minecraft:blue_terracotta
setblock 175 5 362 minecraft:dark_prismarine
fill 175 5 363 175 8 363 minecraft:blue_terracotta
setblock 176 5 325 minecraft:light[level=13]
setblock 176 5 333 minecraft:light[level=13]
fill 176 5 334 176 23 334 minecraft:magenta_terracotta
fill 176 5 336 176 33 336 minecraft:magenta_terracotta
setblock 176 5 341 minecraft:light[level=13]
fill 176 5 352 176 6 359 minecraft:dark_prismarine
setblock 176 5 361 minecraft:dark_prismarine
fill 176 5 362 176 8 362 minecraft:blue_terracotta
fill 177 5 323 177 6 323 minecraft:blue_terracotta
fill 177 5 353 179 5 360 minecraft:dark_prismarine
fill 177 5 361 177 8 361 minecraft:blue_terracotta
setblock 179 5 325 minecraft:light[level=12]
setblock 179 5 332 minecraft:light[level=12]
setblock 179 5 339 minecraft:light[level=12]
setblock 179 5 346 minecraft:light[level=12]
setblock 179 5 363 minecraft:dark_prismarine
fill 180 5 352 180 6 354 minecraft:dark_prismarine
setblock 180 5 357 minecraft:dark_prismarine
fill 180 5 358 180 7 358 minecraft:blue_terracotta
fill 180 5 361 180 5 362 minecraft:dark_prismarine
fill 180 5 363 180 8 363 minecraft:blue_terracotta
setblock 181 5 336 minecraft:dark_prismarine
fill 181 5 337 181 8 337 minecraft:blue_terracotta
setblock 181 5 341 minecraft:dark_prismarine
fill 181 5 342 181 8 342 minecraft:blue_terracotta
fill 181 5 351 181 20 351 minecraft:dark_prismarine
setblock 181 5 356 minecraft:dark_prismarine
fill 181 5 357 181 8 357 minecraft:blue_terracotta
setblock 181 5 361 minecraft:dark_prismarine
setblock 182 5 329 minecraft:purple_concrete
setblock 182 5 335 minecraft:dark_prismarine
fill 182 5 336 182 8 336 minecraft:blue_terracotta
setblock 182 5 340 minecraft:dark_prismarine
fill 182 5 341 182 8 341 minecraft:blue_terracotta
setblock 182 5 345 minecraft:dark_prismarine
fill 182 5 346 182 6 348 minecraft:blue_terracotta
setblock 182 5 350 minecraft:dark_prismarine
fill 182 5 351 182 6 351 minecraft:blue_terracotta
setblock 182 5 355 minecraft:dark_prismarine
fill 182 5 356 182 8 356 minecraft:blue_terracotta
setblock 182 5 360 minecraft:dark_prismarine
fill 182 5 361 182 6 361 minecraft:blue_terracotta
fill 182 5 363 182 6 363 minecraft:blue_terracotta
fill 183 5 355 183 41 356 minecraft:black_concrete
setblock 183 5 357 minecraft:cyan_concrete
fill 183 5 358 183 22 359 minecraft:black_concrete
setblock 142 6 334 minecraft:dark_prismarine
fill 142 6 335 142 6 338 minecraft:blue_terracotta
setblock 142 6 339 minecraft:dark_prismarine
fill 142 6 340 142 9 340 minecraft:blue_terracotta
setblock 142 6 344 minecraft:dark_prismarine
fill 142 6 345 142 9 345 minecraft:blue_terracotta
setblock 142 6 359 minecraft:dark_prismarine
fill 142 6 360 142 8 360 minecraft:blue_terracotta
setblock 142 6 363 minecraft:purple_concrete
fill 143 6 334 143 8 334 minecraft:blue_terracotta
setblock 143 6 338 minecraft:dark_prismarine
fill 143 6 339 143 9 339 minecraft:blue_terracotta
setblock 143 6 342 minecraft:blue_terracotta
fill 143 6 364 144 82 364 minecraft:black_concrete
fill 145 6 340 145 10 340 minecraft:purple_concrete
setblock 145 6 364 minecraft:light_blue_wool
fill 146 6 364 148 17 364 minecraft:black_concrete
setblock 148 6 323 minecraft:dark_prismarine
setblock 148 6 363 minecraft:dark_prismarine
fill 149 6 323 152 6 323 minecraft:blue_terracotta
fill 149 6 363 149 9 363 minecraft:blue_terracotta
fill 150 6 344 151 7 345 minecraft:spruce_planks
fill 150 6 362 153 6 362 minecraft:blue_terracotta
setblock 151 6 324 minecraft:blue_terracotta
setblock 152 6 324 minecraft:dark_prismarine
setblock 153 6 323 minecraft:dark_prismarine
fill 153 6 324 153 9 324 minecraft:blue_terracotta
fill 153 6 361 154 6 361 minecraft:blue_terracotta
setblock 153 6 363 minecraft:dark_prismarine
fill 154 6 323 154 9 323 minecraft:blue_terracotta
setblock 154 6 362 minecraft:dark_prismarine
fill 154 6 363 154 9 363 minecraft:blue_terracotta
setblock 155 6 325 minecraft:blue_terracotta
setblock 155 6 361 minecraft:dark_prismarine
fill 155 6 362 155 9 362 minecraft:blue_terracotta
fill 156 6 361 156 9 361 minecraft:blue_terracotta
setblock 157 6 324 minecraft:dark_prismarine
setblock 158 6 323 minecraft:dark_prismarine
fill 158 6 324 158 9 324 minecraft:blue_terracotta
setblock 158 6 362 minecraft:blue_terracotta
setblock 158 6 363 minecraft:dark_prismarine
fill 159 6 323 159 9 323 minecraft:blue_terracotta
setblock 159 6 361 minecraft:blue_terracotta
setblock 159 6 362 minecraft:dark_prismarine
fill 159 6 363 159 9 363 minecraft:blue_terracotta
setblock 160 6 361 minecraft:dark_prismarine
fill 160 6 362 163 6 362 minecraft:blue_terracotta
setblock 162 6 363 minecraft:blue_terracotta
setblock 163 6 323 minecraft:dark_prismarine
setblock 163 6 363 minecraft:dark_prismarine
fill 164 6 323 164 9 323 minecraft:blue_terracotta
setblock 164 6 362 minecraft:dark_prismarine
fill 164 6 363 164 9 363 minecraft:blue_terracotta
fill 165 6 362 168 6 362 minecraft:blue_terracotta
setblock 167 6 323 minecraft:blue_terracotta
fill 167 6 361 169 6 361 minecraft:blue_terracotta
setblock 167 6 363 minecraft:blue_terracotta
setblock 168 6 323 minecraft:dark_prismarine
setblock 168 6 363 minecraft:dark_prismarine
fill 169 6 323 172 6 323 minecraft:blue_terracotta
setblock 169 6 362 minecraft:dark_prismarine
fill 169 6 363 169 9 363 minecraft:blue_terracotta
setblock 170 6 360 minecraft:blue_terracotta
setblock 170 6 361 minecraft:dark_prismarine
fill 170 6 362 170 9 362 minecraft:blue_terracotta
setblock 171 6 360 minecraft:dark_prismarine
fill 171 6 361 171 9 361 minecraft:blue_terracotta
fill 172 6 360 175 6 360 minecraft:blue_terracotta
setblock 173 6 323 minecraft:dark_prismarine
setblock 173 6 363 minecraft:dark_prismarine
fill 174 6 323 174 9 323 minecraft:blue_terracotta
setblock 174 6 362 minecraft:dark_prismarine
fill 174 6 363 174 9 363 minecraft:blue_terracotta
setblock 175 6 361 minecraft:dark_prismarine
fill 175 6 362 175 9 362 minecraft:blue_terracotta
setblock 176 6 360 minecraft:dark_prismarine
setblock 176 6 361 minecraft:blue_terracotta
fill 177 6 353 179 6 359 minecraft:dark_prismarine
fill 177 6 360 178 6 360 minecraft:blue_terracotta
setblock 178 6 363 minecraft:dark_prismarine
setblock 179 6 360 minecraft:dark_prismarine
setblock 179 6 362 minecraft:dark_prismarine
fill 179 6 363 179 9 363 minecraft:blue_terracotta
fill 180 6 355 180 6 356 minecraft:dark_prismarine
setblock 180 6 357 minecraft:blue_terracotta
setblock 180 6 361 minecraft:dark_prismarine
fill 180 6 362 181 8 362 minecraft:blue_terracotta
fill 181 6 336 181 8 336 minecraft:blue_terracotta
fill 181 6 338 181 6 339 minecraft:blue_terracotta
setblock 181 6 340 minecraft:dark_prismarine
fill 181 6 341 181 9 341 minecraft:blue_terracotta
fill 181 6 343 181 7 343 minecraft:blue_terracotta
setblock 181 6 355 minecraft:dark_prismarine
setblock 181 6 356 minecraft:blue_terracotta
setblock 181 6 360 minecraft:dark_prismarine
fill 181 6 361 181 9 361 minecraft:blue_terracotta
setblock 182 6 323 minecraft:purple_concrete
setblock 182 6 334 minecraft:dark_prismarine
fill 182 6 335 182 9 335 minecraft:blue_terracotta
setblock 182 6 339 minecraft:dark_prismarine
fill 182 6 340 182 9 340 minecraft:blue_terracotta
setblock 182 6 344 minecraft:dark_prismarine
fill 182 6 345 182 9 345 minecraft:blue_terracotta
setblock 182 6 349 minecraft:dark_prismarine
fill 182 6 350 182 8 350 minecraft:blue_terracotta
setblock 182 6 354 minecraft:dark_prismarine
setblock 182 6 355 minecraft:blue_terracotta
setblock 182 6 359 minecraft:dark_prismarine
fill 182 6 360 182 9 360 minecraft:blue_terracotta
fill 183 6 357 183 12 357 minecraft:black_concrete
setblock 141 7 356 minecraft:light_blue_wool
fill 141 7 357 141 51 361 minecraft:black_concrete
setblock 142 7 325 minecraft:purple_concrete
setblock 142 7 333 minecraft:dark_prismarine
fill 142 7 334 142 7 337 minecraft:blue_terracotta
setblock 142 7 338 minecraft:dark_prismarine
fill 142 7 339 142 10 339 minecraft:blue_terracotta
setblock 142 7 343 minecraft:dark_prismarine
fill 142 7 344 142 10 344 minecraft:blue_terracotta
fill 142 7 346 142 8 346 minecraft:blue_terracotta
setblock 142 7 358 minecraft:dark_prismarine
fill 142 7 359 142 8 359 minecraft:blue_terracotta
fill 142 7 361 142 8 361 minecraft:blue_terracotta
setblock 143 7 337 minecraft:dark_prismarine
fill 143 7 338 144 9 338 minecraft:blue_terracotta
setblock 143 7 342 minecraft:dark_prismarine
fill 143 7 343 143 10 343 minecraft:blue_terracotta
fill 144 7 337 144 8 337 minecraft:blue_terracotta
fill 144 7 339 144 8 339 minecraft:blue_terracotta
fill 145 7 339 147 10 339 minecraft:purple_concrete
fill 145 7 341 147 10 341 minecraft:purple_concrete
fill 145 7 364 145 131 364 minecraft:black_concrete
setblock 147 7 323 minecraft:dark_prismarine
fill 147 7 340 147 10 340 minecraft:purple_concrete
setblock 147 7 363 minecraft:dark_prismarine
fill 148 7 323 151 7 323 minecraft:blue_terracotta
fill 148 7 363 148 10 363 minecraft:blue_terracotta
fill 149 7 324 150 7 324 minecraft:blue_terracotta
fill 149 7 362 152 7 362 minecraft:blue_terracotta
setblock 151 7 324 minecraft:dark_prismarine
fill 151 7 361 153 7 361 minecraft:blue_terracotta
setblock 152 7 323 minecraft:dark_prismarine
fill 152 7 324 152 9 325 minecraft:blue_terracotta
setblock 152 7 363 minecraft:dark_prismarine
fill 153 7 323 153 10 323 minecraft:blue_terracotta
fill 153 7 325 154 7 325 minecraft:blue_terracotta
setblock 153 7 362 minecraft:dark_prismarine
fill 153 7 363 153 10 363 minecraft:blue_terracotta
setblock 154 7 361 minecraft:dark_prismarine
fill 154 7 362 154 10 362 minecraft:blue_terracotta
setblock 155 7 325 minecraft:dark_prismarine
fill 155 7 361 155 10 361 minecraft:blue_terracotta
setblock 156 7 324 minecraft:dark_prismarine
fill 156 7 325 156 10 325 minecraft:blue_terracotta
setblock 157 7 323 minecraft:dark_prismarine
fill 157 7 324 157 10 324 minecraft:blue_terracotta
fill 157 7 327 158 7 327 minecraft:magenta_terracotta
setblock 157 7 363 minecraft:dark_prismarine
fill 158 7 323 158 10 323 minecraft:blue_terracotta
setblock 158 7 362 minecraft:dark_prismarine
fill 158 7 363 158 10 363 minecraft:blue_terracotta
setblock 159 7 361 minecraft:dark_prismarine
fill 159 7 362 162 7 362 minecraft:blue_terracotta
setblock 160 7 324 minecraft:blue_terracotta
fill 160 7 361 161 9 361 minecraft:blue_terracotta
setblock 161 7 323 minecraft:blue_terracotta
setblock 162 7 323 minecraft:dark_prismarine
setblock 162 7 363 minecraft:dark_prismarine
fill 163 7 323 163 10 323 minecraft:blue_terracotta
setblock 163 7 362 minecraft:dark_prismarine
fill 163 7 363 163 10 363 minecraft:blue_terracotta
fill 164 7 362 167 7 362 minecraft:blue_terracotta
fill 165 7 323 166 7 323 minecraft:blue_terracotta
fill 165 7 361 168 7 361 minecraft:blue_terracotta
fill 166 7 358 167 7 358 minecraft:magenta_terracotta
setblock 167 7 323 minecraft:dark_prismarine
setblock 167 7 363 minecraft:dark_prismarine
fill 168 7 323 171 7 323 minecraft:blue_terracotta
setblock 168 7 362 minecraft:dark_prismarine
fill 168 7 363 168 10 363 minecraft:blue_terracotta
setblock 169 7 360 minecraft:blue_terracotta
setblock 169 7 361 minecraft:dark_prismarine
fill 169 7 362 169 10 362 minecraft:blue_terracotta
fill 170 7 353 170 15 353 minecraft:black_concrete
setblock 170 7 360 minecraft:dark_prismarine
fill 170 7 361 170 10 361 minecraft:blue_terracotta
fill 171 7 360 174 7 360 minecraft:blue_terracotta
setblock 172 7 323 minecraft:dark_prismarine
setblock 172 7 363 minecraft:dark_prismarine
fill 173 7 323 173 10 323 minecraft:blue_terracotta
fill 173 7 359 173 9 359 minecraft:blue_terracotta
setblock 173 7 362 minecraft:dark_prismarine
fill 173 7 363 173 10 363 minecraft:blue_terracotta
fill 174 7 333 174 11 333 minecraft:magenta_terracotta
setblock 174 7 351 minecraft:sea_lantern
fill 174 7 352 174 28 352 minecraft:dark_prismarine
setblock 174 7 353 minecraft:sea_lantern
fill 174 7 354 174 28 354 minecraft:dark_prismarine
setblock 174 7 355 minecraft:sea_lantern
fill 174 7 356 174 28 356 minecraft:dark_prismarine
setblock 174 7 357 minecraft:sea_lantern
fill 174 7 358 174 28 358 minecraft:dark_prismarine
setblock 174 7 359 minecraft:sea_lantern
setblock 174 7 361 minecraft:sea_lantern
fill 174 7 362 174 10 362 minecraft:blue_terracotta
fill 175 7 351 175 28 351 minecraft:dark_prismarine
setblock 175 7 352 minecraft:sea_lantern
fill 175 7 353 175 28 353 minecraft:dark_prismarine
setblock 175 7 354 minecraft:sea_lantern
fill 175 7 355 175 28 355 minecraft:dark_prismarine
setblock 175 7 356 minecraft:sea_lantern
fill 175 7 357 175 28 357 minecraft:dark_prismarine
setblock 175 7 358 minecraft:sea_lantern
fill 175 7 359 175 28 359 minecraft:dark_prismarine
setblock 175 7 360 minecraft:sea_lantern
fill 175 7 361 175 10 361 minecraft:blue_terracotta
fill 176 7 349 176 10 350 minecraft:magenta_terracotta
setblock 176 7 351 minecraft:sea_lantern
fill 176 7 352 176 28 352 minecraft:dark_prismarine
setblock 176 7 353 minecraft:sea_lantern
fill 176 7 354 176 28 354 minecraft:dark_prismarine
setblock 176 7 355 minecraft:sea_lantern
fill 176 7 356 176 28 356 minecraft:dark_prismarine
setblock 176 7 357 minecraft:sea_lantern
fill 176 7 358 176 28 358 minecraft:dark_prismarine
setblock 176 7 359 minecraft:sea_lantern
fill 176 7 360 176 9 360 minecraft:blue_terracotta
setblock 176 7 361 minecraft:sea_lantern
setblock 177 7 323 minecraft:dark_prismarine
setblock 177 7 352 minecraft:sea_lantern
fill 177 7 353 177 28 353 minecraft:dark_prismarine
setblock 177 7 354 minecraft:sea_lantern
fill 177 7 355 177 28 355 minecraft:dark_prismarine
setblock 177 7 356 minecraft:sea_lantern
fill 177 7 357 177 28 357 minecraft:dark_prismarine
setblock 177 7 358 minecraft:sea_lantern
fill 177 7 359 177 28 359 minecraft:dark_prismarine
setblock 177 7 360 minecraft:sea_lantern
setblock 177 7 363 minecraft:dark_prismarine
fill 178 7 323 178 10 323 minecraft:blue_terracotta
setblock 178 7 351 minecraft:sea_lantern
fill 178 7 352 178 33 352 minecraft:magenta_terracotta
setblock 178 7 353 minecraft:sea_lantern
fill 178 7 354 178 28 354 minecraft:dark_prismarine
setblock 178 7 355 minecraft:sea_lantern
fill 178 7 356 178 28 356 minecraft:dark_prismarine
setblock 178 7 357 minecraft:sea_lantern
fill 178 7 358 178 28 358 minecraft:dark_prismarine
setblock 178 7 359 minecraft:sea_lantern
fill 178 7 360 178 28 360 minecraft:dark_prismarine
setblock 178 7 361 minecraft:sea_lantern
setblock 178 7 362 minecraft:dark_prismarine
fill 178 7 363 178 10 363 minecraft:blue_terracotta
setblock 179 7 352 minecraft:sea_lantern
fill 179 7 353 179 28 353 minecraft:dark_prismarine
setblock 179 7 354 minecraft:sea_lantern
fill 179 7 355 179 28 355 minecraft:dark_prismarine
setblock 179 7 356 minecraft:sea_lantern
fill 179 7 357 179 28 357 minecraft:dark_prismarine
setblock 179 7 358 minecraft:sea_lantern
fill 179 7 359 179 28 359 minecraft:dark_prismarine
setblock 179 7 360 minecraft:sea_lantern
setblock 179 7 361 minecraft:dark_prismarine
fill 179 7 362 179 10 362 minecraft:blue_terracotta
setblock 180 7 339 minecraft:blue_terracotta
setblock 180 7 340 minecraft:dark_prismarine
fill 180 7 341 180 10 341 minecraft:blue_terracotta
setblock 180 7 351 minecraft:sea_lantern
fill 180 7 352 180 28 352 minecraft:dark_prismarine
setblock 180 7 353 minecraft:sea_lantern
fill 180 7 354 180 28 354 minecraft:dark_prismarine
setblock 180 7 355 minecraft:sea_lantern
fill 180 7 356 180 28 356 minecraft:dark_prismarine
setblock 180 7 357 minecraft:sea_lantern
setblock 180 7 359 minecraft:sea_lantern
fill 180 7 360 180 28 360 minecraft:dark_prismarine
setblock 180 7 361 minecraft:sea_lantern
setblock 181 7 338 minecraft:blue_terracotta
setblock 181 7 339 minecraft:dark_prismarine
fill 181 7 340 181 10 340 minecraft:blue_terracotta
setblock 181 7 344 minecraft:dark_prismarine
fill 181 7 345 181 10 345 minecraft:blue_terracotta
setblock 181 7 352 minecraft:sea_lantern
fill 181 7 353 181 21 353 minecraft:dark_prismarine
setblock 181 7 354 minecraft:sea_lantern
setblock 181 7 355 minecraft:blue_terracotta
setblock 181 7 356 minecraft:sea_lantern
setblock 181 7 358 minecraft:sea_lantern
setblock 181 7 359 minecraft:dark_prismarine
setblock 181 7 360 minecraft:sea_lantern
fill 182 7 334 182 8 334 minecraft:blue_terracotta
setblock 182 7 338 minecraft:dark_prismarine
fill 182 7 339 182 10 339 minecraft:blue_terracotta
setblock 182 7 343 minecraft:dark_prismarine
fill 182 7 344 182 10 344 minecraft:blue_terracotta
fill 182 7 346 182 7 347 minecraft:blue_terracotta
setblock 182 7 348 minecraft:dark_prismarine
fill 182 7 349 182 10 349 minecraft:blue_terracotta
setblock 182 7 351 minecraft:sea_lantern
setblock 182 7 353 minecraft:sea_lantern
fill 182 7 354 182 9 354 minecraft:blue_terracotta
setblock 182 7 355 minecraft:sea_lantern
setblock 182 7 357 minecraft:sea_lantern
setblock 182 7 358 minecraft:dark_prismarine
setblock 182 7 359 minecraft:sea_lantern
setblock 182 7 361 minecraft:sea_lantern
setblock 182 7 363 minecraft:dark_prismarine
fill 141 8 333 141 122 337 minecraft:black_concrete
setblock 141 8 338 minecraft:cyan_concrete
fill 141 8 339 141 38 343 minecraft:black_concrete
fill 141 8 356 141 131 356 minecraft:black_concrete
setblock 142 8 331 minecraft:purple_concrete
setblock 142 8 332 minecraft:dark_prismarine
fill 142 8 333 142 8 336 minecraft:blue_terracotta
setblock 142 8 337 minecraft:dark_prismarine
fill 142 8 338 142 11 338 minecraft:blue_terracotta
setblock 142 8 341 minecraft:blue_terracotta
setblock 142 8 342 minecraft:dark_prismarine
fill 142 8 343 142 11 343 minecraft:blue_terracotta
setblock 142 8 350 minecraft:purple_concrete
fill 142 8 356 142 9 356 minecraft:purple_concrete
setblock 142 8 362 minecraft:dark_prismarine
setblock 143 8 336 minecraft:dark_prismarine
fill 143 8 337 143 11 337 minecraft:blue_terracotta
setblock 143 8 341 minecraft:dark_prismarine
fill 143 8 342 143 11 342 minecraft:blue_terracotta
setblock 144 8 340 minecraft:dark_prismarine
setblock 144 8 341 minecraft:purple_concrete
setblock 145 8 323 minecraft:blue_terracotta
fill 145 8 338 146 10 338 minecraft:purple_concrete
fill 145 8 342 146 10 342 minecraft:purple_concrete
setblock 145 8 363 minecraft:blue_terracotta
setblock 146 8 323 minecraft:dark_prismarine
fill 146 8 335 147 8 336 minecraft:pink_terracotta
setblock 146 8 363 minecraft:dark_prismarine
fill 147 8 323 150 8 323 minecraft:blue_terracotta
fill 147 8 363 147 11 363 minecraft:blue_terracotta
fill 148 8 324 149 8 324 minecraft:blue_terracotta
fill 148 8 340 148 10 340 minecraft:purple_concrete
fill 148 8 362 151 8 362 minecraft:blue_terracotta
fill 149 8 350 150 8 351 minecraft:pink_terracotta
setblock 150 8 324 minecraft:dark_prismarine
fill 150 8 361 152 8 361 minecraft:blue_terracotta
setblock 150 8 363 minecraft:blue_terracotta
setblock 151 8 323 minecraft:dark_prismarine
fill 151 8 324 151 10 325 minecraft:blue_terracotta
setblock 151 8 363 minecraft:dark_prismarine
fill 152 8 323 152 11 323 minecraft:blue_terracotta
setblock 152 8 362 minecraft:dark_prismarine
fill 152 8 363 152 11 363 minecraft:blue_terracotta
setblock 153 8 325 minecraft:blue_terracotta
setblock 153 8 361 minecraft:dark_prismarine
fill 153 8 362 153 11 362 minecraft:blue_terracotta
setblock 154 8 325 minecraft:dark_prismarine
fill 154 8 361 154 11 361 minecraft:blue_terracotta
setblock 155 8 324 minecraft:dark_prismarine
fill 155 8 325 155 11 325 minecraft:blue_terracotta
setblock 156 8 323 minecraft:dark_prismarine
fill 156 8 324 156 11 324 minecraft:blue_terracotta
setblock 156 8 363 minecraft:dark_prismarine
fill 157 8 323 157 11 323 minecraft:blue_terracotta
fill 157 8 325 157 9 325 minecraft:blue_terracotta
fill 157 8 327 157 21 328 minecraft:magenta_terracotta
setblock 157 8 361 minecraft:blue_terracotta
setblock 157 8 362 minecraft:dark_prismarine
fill 157 8 363 157 11 363 minecraft:blue_terracotta
fill 158 8 327 159 8 328 minecraft:pink_terracotta
setblock 158 8 361 minecraft:dark_prismarine
fill 158 8 362 161 8 362 minecraft:blue_terracotta
fill 159 8 361 159 10 361 minecraft:blue_terracotta
setblock 160 8 324 minecraft:dark_prismarine
setblock 161 8 323 minecraft:dark_prismarine
setblock 161 8 363 minecraft:dark_prismarine
fill 162 8 323 162 11 323 minecraft:blue_terracotta
setblock 162 8 361 minecraft:blue_terracotta
setblock 162 8 362 minecraft:dark_prismarine
fill 162 8 363 162 11 363 minecraft:blue_terracotta
setblock 163 8 361 minecraft:dark_prismarine
fill 163 8 362 166 8 362 minecraft:blue_terracotta
fill 164 8 361 167 8 361 minecraft:blue_terracotta
setblock 165 8 323 minecraft:blue_terracotta
fill 165 8 358 166 9 358 minecraft:pink_terracotta
setblock 166 8 323 minecraft:dark_prismarine
setblock 166 8 363 minecraft:dark_prismarine
fill 167 8 323 170 8 323 minecraft:blue_terracotta
fill 167 8 358 167 23 358 minecraft:magenta_terracotta
setblock 167 8 362 minecraft:dark_prismarine
fill 167 8 363 167 11 363 minecraft:blue_terracotta
setblock 168 8 360 minecraft:blue_terracotta
setblock 168 8 361 minecraft:dark_prismarine
fill 168 8 362 168 11 362 minecraft:blue_terracotta
setblock 169 8 360 minecraft:dark_prismarine
fill 169 8 361 169 11 361 minecraft:blue_terracotta
setblock 170 8 324 minecraft:dark_prismarine
fill 170 8 360 173 8 360 minecraft:blue_terracotta
setblock 171 8 323 minecraft:dark_prismarine
fill 171 8 324 174 8 324 minecraft:blue_terracotta
setblock 171 8 363 minecraft:dark_prismarine
fill 172 8 323 172 11 323 minecraft:blue_terracotta
fill 172 8 359 172 9 359 minecraft:blue_terracotta
setblock 172 8 362 minecraft:dark_prismarine
fill 172 8 363 172 11 363 minecraft:blue_terracotta
setblock 173 8 361 minecraft:dark_prismarine
fill 173 8 362 173 11 362 minecraft:blue_terracotta
fill 174 8 335 174 9 336 minecraft:pink_terracotta
fill 174 8 351 174 9 351 minecraft:dark_prismarine
fill 174 8 353 174 9 353 minecraft:dark_prismarine
fill 174 8 355 174 9 355 minecraft:dark_prismarine
fill 174 8 357 174 9 357 minecraft:dark_prismarine
setblock 174 8 359 minecraft:blue_terracotta
setblock 174 8 360 minecraft:dark_prismarine
fill 174 8 361 174 9 361 minecraft:blue_terracotta
setblock 175 8 335 minecraft:pink_terracotta
fill 175 8 352 175 9 352 minecraft:dark_prismarine
fill 175 8 354 175 9 354 minecraft:dark_prismarine
fill 175 8 356 175 9 356 minecraft:dark_prismarine
fill 175 8 358 175 9 358 minecraft:dark_prismarine
fill 175 8 360 175 9 360 minecraft:blue_terracotta
setblock 176 8 323 minecraft:dark_prismarine
fill 176 8 351 176 9 351 minecraft:magenta_terracotta
fill 176 8 353 176 9 353 minecraft:dark_prismarine
fill 176 8 355 176 9 355 minecraft:dark_prismarine
fill 176 8 357 176 9 357 minecraft:dark_prismarine
fill 176 8 359 176 9 359 minecraft:dark_prismarine
fill 176 8 361 176 9 361 minecraft:blue_terracotta
setblock 176 8 363 minecraft:dark_prismarine
fill 177 8 323 177 11 323 minecraft:blue_terracotta
fill 177 8 350 177 33 350 minecraft:magenta_terracotta
fill 177 8 352 177 9 352 minecraft:magenta_terracotta
fill 177 8 354 177 9 354 minecraft:dark_prismarine
fill 177 8 356 177 9 356 minecraft:dark_prismarine
fill 177 8 358 177 9 358 minecraft:dark_prismarine
setblock 177 8 360 minecraft:blue_terracotta
setblock 177 8 362 minecraft:dark_prismarine
fill 177 8 363 177 11 363 minecraft:blue_terracotta
fill 178 8 350 178 9 351 minecraft:pink_terracotta
fill 178 8 353 178 9 353 minecraft:dark_prismarine
fill 178 8 355 178 9 355 minecraft:dark_prismarine
fill 178 8 357 178 9 357 minecraft:dark_prismarine
fill 178 8 359 178 9 359 minecraft:dark_prismarine
setblock 178 8 361 minecraft:dark_prismarine
fill 178 8 362 178 11 362 minecraft:blue_terracotta
fill 179 8 350 179 33 350 minecraft:magenta_terracotta
fill 179 8 352 179 9 352 minecraft:magenta_terracotta
fill 179 8 354 179 9 354 minecraft:dark_prismarine
fill 179 8 356 179 9 356 minecraft:dark_prismarine
fill 179 8 358 181 8 358 minecraft:dark_prismarine
fill 179 8 360 179 9 360 minecraft:dark_prismarine
setblock 179 8 361 minecraft:blue_terracotta
setblock 180 8 339 minecraft:dark_prismarine
fill 180 8 340 180 10 340 minecraft:blue_terracotta
fill 180 8 342 180 9 342 minecraft:blue_terracotta
fill 180 8 351 180 9 351 minecraft:magenta_terracotta
fill 180 8 353 180 9 353 minecraft:dark_prismarine
fill 180 8 355 181 9 355 minecraft:dark_prismarine
fill 180 8 357 180 9 357 minecraft:dark_prismarine
fill 180 8 359 180 9 359 minecraft:dark_prismarine
fill 180 8 361 180 9 361 minecraft:dark_prismarine
setblock 181 8 338 minecraft:dark_prismarine
fill 181 8 339 181 11 339 minecraft:blue_terracotta
setblock 181 8 343 minecraft:dark_prismarine
fill 181 8 344 181 11 344 minecraft:blue_terracotta
fill 181 8 346 182 8 346 minecraft:blue_terracotta
fill 181 8 352 182 9 352 minecraft:dark_prismarine
fill 181 8 354 181 9 354 minecraft:dark_prismarine
setblock 181 8 356 minecraft:blue_terracotta
fill 181 8 359 181 9 360 minecraft:blue_terracotta
setblock 181 8 363 minecraft:dark_prismarine
setblock 182 8 330 minecraft:purple_concrete
setblock 182 8 337 minecraft:dark_prismarine
fill 182 8 338 182 11 338 minecraft:blue_terracotta
setblock 182 8 342 minecraft:dark_prismarine
fill 182 8 343 182 11 343 minecraft:blue_terracotta
setblock 182 8 347 minecraft:dark_prismarine
fill 182 8 348 182 11 348 minecraft:blue_terracotta
setblock 182 8 351 minecraft:blue_terracotta
setblock 182 8 353 minecraft:blue_terracotta
fill 182 8 355 182 9 355 minecraft:blue_terracotta
setblock 182 8 357 minecraft:dark_prismarine
fill 182 8 358 182 9 359 minecraft:blue_terracotta
setblock 182 8 361 minecraft:blue_terracotta
setblock 182 8 362 minecraft:dark_prismarine
fill 182 8 363 182 11 363 minecraft:blue_terracotta
fill 141 9 338 141 128 338 minecraft:black_concrete
fill 142 9 332 142 9 335 minecraft:blue_terracotta
setblock 142 9 336 minecraft:dark_prismarine
fill 142 9 337 142 12 337 minecraft:blue_terracotta
setblock 142 9 341 minecraft:dark_prismarine
fill 142 9 342 142 12 342 minecraft:blue_terracotta
setblock 142 9 346 minecraft:dark_prismarine
setblock 142 9 361 minecraft:dark_prismarine
setblock 142 9 362 minecraft:blue_terracotta
fill 143 9 323 144 9 323 minecraft:blue_terracotta
setblock 143 9 335 minecraft:dark_prismarine
fill 143 9 336 143 11 336 minecraft:blue_terracotta
setblock 143 9 340 minecraft:dark_prismarine
fill 143 9 341 144 10 341 minecraft:blue_terracotta
setblock 143 9 344 minecraft:blue_terracotta
fill 143 9 363 144 9 363 minecraft:blue_terracotta
setblock 144 9 339 minecraft:dark_prismarine
fill 144 9 340 144 10 340 minecraft:blue_terracotta
fill 144 9 342 144 10 342 minecraft:purple_concrete
setblock 145 9 323 minecraft:dark_prismarine
setblock 145 9 363 minecraft:dark_prismarine
fill 146 9 323 149 9 323 minecraft:blue_terracotta
fill 146 9 335 146 9 336 minecraft:pink_terracotta
fill 146 9 363 146 12 363 minecraft:blue_terracotta
fill 147 9 324 148 9 324 minecraft:blue_terracotta
fill 147 9 335 147 33 336 minecraft:magenta_terracotta
fill 147 9 338 147 10 338 minecraft:purple_concrete
fill 147 9 342 147 10 342 minecraft:purple_concrete
fill 147 9 362 150 9 362 minecraft:blue_terracotta
fill 148 9 339 148 10 339 minecraft:purple_concrete
fill 148 9 341 148 10 341 minecraft:purple_concrete
setblock 149 9 324 minecraft:dark_prismarine
fill 149 9 350 149 32 350 minecraft:magenta_terracotta
fill 149 9 351 150 9 351 minecraft:pink_terracotta
setblock 150 9 323 minecraft:dark_prismarine
fill 150 9 324 150 11 325 minecraft:blue_terracotta
setblock 150 9 350 minecraft:pink_terracotta
fill 150 9 361 151 9 361 minecraft:blue_terracotta
setblock 150 9 363 minecraft:dark_prismarine
fill 151 9 323 151 12 323 minecraft:blue_terracotta
setblock 151 9 362 minecraft:dark_prismarine
fill 151 9 363 151 12 363 minecraft:blue_terracotta
setblock 152 9 361 minecraft:dark_prismarine
fill 152 9 362 152 12 362 minecraft:blue_terracotta
setblock 153 9 325 minecraft:dark_prismarine
fill 153 9 361 153 12 361 minecraft:blue_terracotta
setblock 154 9 324 minecraft:dark_prismarine
fill 154 9 325 154 12 325 minecraft:blue_terracotta
setblock 155 9 323 minecraft:dark_prismarine
fill 155 9 324 155 12 324 minecraft:blue_terracotta
setblock 155 9 363 minecraft:dark_prismarine
fill 156 9 323 156 12 323 minecraft:blue_terracotta
setblock 156 9 362 minecraft:dark_prismarine
fill 156 9 363 156 12 363 minecraft:blue_terracotta
setblock 157 9 361 minecraft:dark_prismarine
fill 157 9 362 160 9 362 minecraft:blue_terracotta
fill 158 9 327 159 32 327 minecraft:magenta_terracotta
fill 158 9 328 159 9 328 minecraft:pink_terracotta
fill 158 9 330 158 33 330 minecraft:magenta_terracotta
fill 158 9 361 158 11 361 minecraft:blue_terracotta
setblock 159 9 324 minecraft:dark_prismarine
setblock 160 9 323 minecraft:dark_prismarine
fill 160 9 324 160 11 324 minecraft:blue_terracotta
setblock 160 9 363 minecraft:dark_prismarine
fill 161 9 323 161 12 323 minecraft:blue_terracotta
setblock 161 9 362 minecraft:dark_prismarine
fill 161 9 363 161 12 363 minecraft:blue_terracotta
setblock 162 9 361 minecraft:dark_prismarine
fill 162 9 362 165 9 362 minecraft:blue_terracotta
fill 163 9 361 166 9 361 minecraft:blue_terracotta
setblock 165 9 323 minecraft:dark_prismarine
setblock 165 9 363 minecraft:dark_prismarine
fill 166 9 323 169 9 323 minecraft:blue_terracotta
fill 166 9 359 166 15 360 minecraft:magenta_terracotta
setblock 166 9 362 minecraft:dark_prismarine
fill 166 9 363 166 12 363 minecraft:blue_terracotta
fill 167 9 359 167 18 359 minecraft:magenta_terracotta
setblock 167 9 361 minecraft:dark_prismarine
fill 167 9 362 167 12 362 minecraft:blue_terracotta
setblock 168 9 360 minecraft:dark_prismarine
fill 168 9 361 168 12 361 minecraft:blue_terracotta
setblock 169 9 324 minecraft:dark_prismarine
fill 169 9 360 172 9 360 minecraft:blue_terracotta
setblock 170 9 323 minecraft:dark_prismarine
fill 170 9 324 173 9 324 minecraft:blue_terracotta
fill 170 9 352 171 15 352 minecraft:black_concrete
setblock 170 9 363 minecraft:dark_prismarine
fill 171 9 323 171 12 323 minecraft:blue_terracotta
fill 171 9 353 171 15 353 minecraft:black_concrete
setblock 171 9 362 minecraft:dark_prismarine
fill 171 9 363 171 12 363 minecraft:blue_terracotta
setblock 172 9 361 minecraft:dark_prismarine
fill 172 9 362 172 12 362 minecraft:blue_terracotta
setblock 173 9 360 minecraft:dark_prismarine
fill 173 9 361 173 12 361 minecraft:blue_terracotta
setblock 174 9 324 minecraft:dark_prismarine
setblock 174 9 359 minecraft:dark_prismarine
fill 174 9 360 174 11 360 minecraft:blue_terracotta
setblock 175 9 323 minecraft:dark_prismarine
fill 175 9 324 175 10 324 minecraft:blue_terracotta
fill 175 9 335 175 33 335 minecraft:magenta_terracotta
setblock 175 9 363 minecraft:dark_prismarine
fill 176 9 323 176 12 323 minecraft:blue_terracotta
setblock 176 9 362 minecraft:dark_prismarine
fill 176 9 363 176 12 363 minecraft:blue_terracotta
fill 177 9 360 177 9 361 minecraft:dark_prismarine
fill 177 9 362 177 12 362 minecraft:blue_terracotta
setblock 178 9 361 minecraft:blue_terracotta
fill 179 9 358 180 9 358 minecraft:dark_prismarine
fill 179 9 361 179 28 361 minecraft:dark_prismarine
setblock 180 9 339 minecraft:blue_terracotta
setblock 180 9 343 minecraft:dark_prismarine
setblock 180 9 362 minecraft:blue_terracotta
setblock 180 9 363 minecraft:dark_prismarine
setblock 181 9 337 minecraft:dark_prismarine
fill 181 9 338 181 11 338 minecraft:blue_terracotta
setblock 181 9 342 minecraft:dark_prismarine
fill 181 9 343 181 12 343 minecraft:blue_terracotta
setblock 181 9 346 minecraft:blue_terracotta
fill 181 9 356 181 9 357 minecraft:dark_prismarine
setblock 181 9 358 minecraft:blue_terracotta
fill 181 9 363 181 11 363 minecraft:blue_terracotta
setblock 182 9 324 minecraft:purple_concrete
setblock 182 9 336 minecraft:dark_prismarine
fill 182 9 337 182 12 337 minecraft:blue_terracotta
setblock 182 9 341 minecraft:dark_prismarine
fill 182 9 342 182 12 342 minecraft:blue_terracotta
setblock 182 9 346 minecraft:dark_prismarine
fill 182 9 347 182 12 347 minecraft:blue_terracotta
setblock 182 9 351 minecraft:dark_prismarine
setblock 182 9 353 minecraft:dark_prismarine
fill 182 9 356 182 10 356 minecraft:dark_prismarine
setblock 182 9 357 minecraft:blue_terracotta
setblock 182 9 361 minecraft:dark_prismarine
fill 182 9 362 182 11 362 minecraft:blue_terracotta
fill 142 10 323 143 10 323 minecraft:blue_terracotta
setblock 142 10 324 minecraft:purple_concrete
fill 142 10 333 142 10 334 minecraft:blue_terracotta
setblock 142 10 335 minecraft:dark_prismarine
fill 142 10 336 142 13 336 minecraft:blue_terracotta
setblock 142 10 340 minecraft:dark_prismarine
fill 142 10 341 142 13 341 minecraft:blue_terracotta
setblock 142 10 345 minecraft:dark_prismarine
fill 142 10 346 142 13 346 minecraft:blue_terracotta
setblock 143 10 335 minecraft:blue_terracotta
setblock 143 10 338 minecraft:blue_terracotta
setblock 143 10 339 minecraft:dark_prismarine
fill 143 10 340 143 13 340 minecraft:blue_terracotta
setblock 143 10 344 minecraft:dark_prismarine
setblock 143 10 363 minecraft:blue_terracotta
setblock 144 10 323 minecraft:dark_prismarine
fill 144 10 337 144 10 338 minecraft:purple_concrete
setblock 144 10 339 minecraft:blue_terracotta
fill 144 10 343 147 10 343 minecraft:purple_concrete
setblock 144 10 363 minecraft:dark_prismarine
setblock 145 10 322 minecraft:light_blue_wool
fill 145 10 323 148 10 323 minecraft:blue_terracotta
fill 145 10 363 145 13 363 minecraft:blue_terracotta
fill 146 10 324 147 10 324 minecraft:blue_terracotta
fill 146 10 335 146 33 336 minecraft:magenta_terracotta
fill 147 10 362 149 10 362 minecraft:blue_terracotta
setblock 148 10 324 minecraft:dark_prismarine
setblock 148 10 338 minecraft:purple_concrete
setblock 148 10 342 minecraft:purple_concrete
fill 148 10 349 148 33 349 minecraft:magenta_terracotta
setblock 149 10 323 minecraft:dark_prismarine
fill 149 10 324 149 12 325 minecraft:blue_terracotta
fill 149 10 339 149 10 341 minecraft:purple_concrete
fill 149 10 351 150 33 351 minecraft:magenta_terracotta
fill 149 10 361 150 10 361 minecraft:blue_terracotta
setblock 149 10 363 minecraft:dark_prismarine
fill 150 10 323 150 13 323 minecraft:blue_terracotta
fill 150 10 350 150 33 350 minecraft:magenta_terracotta
setblock 150 10 362 minecraft:dark_prismarine
fill 150 10 363 150 13 363 minecraft:blue_terracotta
setblock 151 10 361 minecraft:dark_prismarine
fill 151 10 362 151 13 362 minecraft:blue_terracotta
setblock 152 10 324 minecraft:blue_terracotta
setblock 152 10 325 minecraft:dark_prismarine
fill 152 10 361 152 13 361 minecraft:blue_terracotta
setblock 153 10 324 minecraft:dark_prismarine
fill 153 10 325 153 13 325 minecraft:blue_terracotta
setblock 154 10 323 minecraft:dark_prismarine
fill 154 10 324 154 13 324 minecraft:blue_terracotta
setblock 154 10 363 minecraft:dark_prismarine
fill 155 10 323 155 13 323 minecraft:blue_terracotta
setblock 155 10 362 minecraft:dark_prismarine
fill 155 10 363 155 13 363 minecraft:blue_terracotta
setblock 156 10 361 minecraft:dark_prismarine
fill 156 10 362 159 10 362 minecraft:blue_terracotta
fill 157 10 361 157 11 361 minecraft:blue_terracotta
setblock 158 10 324 minecraft:dark_prismarine
fill 158 10 328 159 33 328 minecraft:magenta_terracotta
setblock 159 10 323 minecraft:dark_prismarine
fill 159 10 324 159 13 324 minecraft:blue_terracotta
fill 159 10 330 159 33 330 minecraft:magenta_terracotta
setblock 159 10 363 minecraft:dark_prismarine
fill 160 10 323 160 13 323 minecraft:blue_terracotta
setblock 160 10 361 minecraft:blue_terracotta
setblock 160 10 362 minecraft:dark_prismarine
fill 160 10 363 160 13 363 minecraft:blue_terracotta
fill 161 10 362 164 10 362 minecraft:blue_terracotta
fill 163 10 361 165 10 361 minecraft:blue_terracotta
setblock 164 10 323 minecraft:dark_prismarine
setblock 164 10 363 minecraft:dark_prismarine
fill 165 10 323 168 10 323 minecraft:blue_terracotta
fill 165 10 358 166 33 358 minecraft:magenta_terracotta
setblock 165 10 362 minecraft:dark_prismarine
fill 165 10 363 165 13 363 minecraft:blue_terracotta
setblock 166 10 361 minecraft:dark_prismarine
fill 166 10 362 166 13 362 minecraft:blue_terracotta
setblock 167 10 324 minecraft:blue_terracotta
fill 167 10 361 167 13 361 minecraft:blue_terracotta
setblock 168 10 324 minecraft:dark_prismarine
fill 168 10 360 171 10 360 minecraft:blue_terracotta
setblock 169 10 323 minecraft:dark_prismarine
fill 169 10 324 172 10 324 minecraft:blue_terracotta
fill 169 10 353 169 15 353 minecraft:black_concrete
setblock 169 10 363 minecraft:dark_prismarine
fill 170 10 323 170 13 323 minecraft:blue_terracotta
fill 170 10 354 171 15 354 minecraft:black_concrete
setblock 170 10 362 minecraft:dark_prismarine
fill 170 10 363 170 13 363 minecraft:blue_terracotta
setblock 171 10 361 minecraft:dark_prismarine
fill 171 10 362 171 13 362 minecraft:blue_terracotta
setblock 172 10 360 minecraft:dark_prismarine
fill 172 10 361 172 13 361 minecraft:blue_terracotta
setblock 173 10 324 minecraft:dark_prismarine
fill 173 10 334 174 19 334 minecraft:magenta_terracotta
fill 173 10 360 173 11 360 minecraft:blue_terracotta
setblock 174 10 323 minecraft:dark_prismarine
fill 174 10 324 174 12 324 minecraft:blue_terracotta
fill 174 10 335 174 33 336 minecraft:magenta_terracotta
setblock 174 10 351 minecraft:sea_lantern
setblock 174 10 353 minecraft:sea_lantern
setblock 174 10 355 minecraft:sea_lantern
setblock 174 10 357 minecraft:sea_lantern
setblock 174 10 359 minecraft:sea_lantern
setblock 174 10 361 minecraft:sea_lantern
setblock 174 10 363 minecraft:dark_prismarine
fill 175 10 323 175 13 323 minecraft:blue_terracotta
setblock 175 10 352 minecraft:sea_lantern
setblock 175 10 354 minecraft:sea_lantern
setblock 175 10 356 minecraft:sea_lantern
setblock 175 10 358 minecraft:sea_lantern
setblock 175 10 360 minecraft:sea_lantern
setblock 175 10 362 minecraft:dark_prismarine
fill 175 10 363 175 13 363 minecraft:blue_terracotta
setblock 176 10 351 minecraft:sea_lantern
setblock 176 10 353 minecraft:sea_lantern
setblock 176 10 355 minecraft:sea_lantern
setblock 176 10 357 minecraft:sea_lantern
setblock 176 10 359 minecraft:sea_lantern
fill 176 10 360 176 28 360 minecraft:dark_prismarine
setblock 176 10 361 minecraft:sea_lantern
fill 176 10 362 176 13 362 minecraft:blue_terracotta
setblock 177 10 352 minecraft:sea_lantern
setblock 177 10 354 minecraft:sea_lantern
setblock 177 10 356 minecraft:sea_lantern
setblock 177 10 358 minecraft:sea_lantern
setblock 177 10 360 minecraft:sea_lantern
setblock 177 10 361 minecraft:blue_terracotta
fill 178 10 350 178 32 350 minecraft:magenta_terracotta
setblock 178 10 351 minecraft:sea_lantern
setblock 178 10 353 minecraft:sea_lantern
setblock 178 10 355 minecraft:sea_lantern
setblock 178 10 357 minecraft:sea_lantern
setblock 178 10 359 minecraft:sea_lantern
setblock 178 10 361 minecraft:sea_lantern
setblock 179 10 352 minecraft:sea_lantern
setblock 179 10 354 minecraft:sea_lantern
setblock 179 10 356 minecraft:sea_lantern
setblock 179 10 358 minecraft:sea_lantern
setblock 179 10 360 minecraft:sea_lantern
setblock 179 10 363 minecraft:dark_prismarine
setblock 180 10 342 minecraft:dark_prismarine
fill 180 10 343 180 11 343 minecraft:blue_terracotta
setblock 180 10 351 minecraft:sea_lantern
setblock 180 10 353 minecraft:sea_lantern
setblock 180 10 355 minecraft:sea_lantern
setblock 180 10 357 minecraft:sea_lantern
fill 180 10 358 180 28 358 minecraft:dark_prismarine
setblock 180 10 359 minecraft:sea_lantern
setblock 180 10 361 minecraft:sea_lantern
setblock 180 10 362 minecraft:dark_prismarine
fill 180 10 363 180 12 363 minecraft:blue_terracotta
setblock 181 10 337 minecraft:blue_terracotta
setblock 181 10 341 minecraft:dark_prismarine
fill 181 10 342 181 13 342 minecraft:blue_terracotta
setblock 181 10 346 minecraft:dark_prismarine
setblock 181 10 352 minecraft:sea_lantern
setblock 181 10 354 minecraft:sea_lantern
fill 181 10 355 181 23 355 minecraft:dark_prismarine
setblock 181 10 356 minecraft:sea_lantern
fill 181 10 357 181 28 357 minecraft:dark_prismarine
setblock 181 10 358 minecraft:sea_lantern
fill 181 10 359 181 28 359 minecraft:dark_prismarine
setblock 181 10 360 minecraft:sea_lantern
fill 181 10 361 181 28 361 minecraft:dark_prismarine
setblock 182 10 335 minecraft:dark_prismarine
fill 182 10 336 182 11 336 minecraft:blue_terracotta
setblock 182 10 340 minecraft:dark_prismarine
fill 182 10 341 182 13 341 minecraft:blue_terracotta
setblock 182 10 345 minecraft:dark_prismarine
fill 182 10 346 182 13 346 minecraft:blue_terracotta
setblock 182 10 351 minecraft:sea_lantern
fill 182 10 352 182 18 352 minecraft:dark_prismarine
setblock 182 10 353 minecraft:sea_lantern
fill 182 10 354 182 21 354 minecraft:dark_prismarine
setblock 182 10 355 minecraft:sea_lantern
setblock 182 10 357 minecraft:sea_lantern
setblock 182 10 358 minecraft:blue_terracotta
setblock 182 10 359 minecraft:sea_lantern
setblock 182 10 360 minecraft:dark_prismarine
setblock 182 10 361 minecraft:sea_lantern
setblock 142 11 323 minecraft:blue_terracotta
setblock 142 11 324 minecraft:dark_prismarine
setblock 142 11 330 minecraft:purple_concrete
setblock 142 11 333 minecraft:blue_terracotta
fill 142 11 334 144 17 334 minecraft:dark_prismarine
fill 142 11 335 142 12 335 minecraft:blue_terracotta
setblock 142 11 339 minecraft:dark_prismarine
fill 142 11 340 142 14 340 minecraft:blue_terracotta
setblock 142 11 344 minecraft:dark_prismarine
fill 142 11 345 142 14 345 minecraft:blue_terracotta
setblock 142 11 349 minecraft:purple_concrete
setblock 143 11 323 minecraft:dark_prismarine
fill 143 11 335 143 20 335 minecraft:dark_prismarine
fill 143 11 338 150 11 338 minecraft:dark_prismarine
fill 143 11 339 143 13 339 minecraft:blue_terracotta
fill 143 11 341 143 12 341 minecraft:blue_terracotta
fill 143 11 343 150 11 343 minecraft:dark_prismarine
fill 143 11 344 143 13 344 minecraft:blue_terracotta
fill 143 11 345 146 18 346 minecraft:dark_prismarine
setblock 143 11 363 minecraft:dark_prismarine
fill 144 11 323 147 11 323 minecraft:blue_terracotta
setblock 144 11 325 minecraft:light[level=12]
setblock 144 11 332 minecraft:light[level=12]
fill 144 11 337 144 28 337 minecraft:dark_prismarine
fill 144 11 339 150 28 342 minecraft:dark_prismarine
fill 144 11 344 150 28 344 minecraft:dark_prismarine
setblock 144 11 353 minecraft:light[level=12]
setblock 144 11 360 minecraft:light[level=12]
fill 144 11 363 144 14 363 minecraft:blue_terracotta
fill 145 11 322 145 23 322 minecraft:black_concrete
fill 145 11 324 146 11 324 minecraft:blue_terracotta
setblock 147 11 324 minecraft:dark_prismarine
fill 147 11 362 148 11 362 minecraft:blue_terracotta
setblock 148 11 323 minecraft:dark_prismarine
fill 148 11 324 148 13 325 minecraft:blue_terracotta
fill 148 11 337 150 26 337 minecraft:dark_prismarine
setblock 148 11 363 minecraft:dark_prismarine
fill 149 11 323 149 14 323 minecraft:blue_terracotta
fill 149 11 334 150 28 336 minecraft:dark_prismarine
setblock 149 11 362 minecraft:dark_prismarine
fill 149 11 363 149 14 363 minecraft:blue_terracotta
fill 150 11 345 150 28 346 minecraft:dark_prismarine
setblock 150 11 361 minecraft:dark_prismarine
fill 150 11 362 150 14 362 minecraft:blue_terracotta
setblock 151 11 324 minecraft:blue_terracotta
setblock 151 11 325 minecraft:dark_prismarine
setblock 151 11 332 minecraft:light[level=12]
setblock 151 11 339 minecraft:light[level=12]
setblock 151 11 346 minecraft:light[level=12]
setblock 151 11 353 minecraft:light[level=12]
setblock 151 11 360 minecraft:light[level=12]
fill 151 11 361 151 13 361 minecraft:blue_terracotta
setblock 152 11 324 minecraft:dark_prismarine
fill 152 11 325 152 14 325 minecraft:blue_terracotta
setblock 153 11 323 minecraft:dark_prismarine
fill 153 11 324 153 14 324 minecraft:blue_terracotta
setblock 153 11 363 minecraft:dark_prismarine
fill 154 11 323 154 14 323 minecraft:blue_terracotta
setblock 154 11 362 minecraft:dark_prismarine
fill 154 11 363 154 14 363 minecraft:blue_terracotta
setblock 155 11 361 minecraft:dark_prismarine
fill 155 11 362 158 11 362 minecraft:blue_terracotta
setblock 156 11 325 minecraft:dark_prismarine
fill 156 11 361 156 12 361 minecraft:blue_terracotta
setblock 157 11 324 minecraft:dark_prismarine
setblock 157 11 364 minecraft:cyan_concrete
setblock 158 11 323 minecraft:dark_prismarine
fill 158 11 324 158 14 324 minecraft:blue_terracotta
setblock 158 11 325 minecraft:light[level=12]
setblock 158 11 332 minecraft:light[level=12]
setblock 158 11 339 minecraft:light[level=12]
setblock 158 11 346 minecraft:light[level=12]
setblock 158 11 353 minecraft:light[level=12]
setblock 158 11 360 minecraft:light[level=12]
setblock 158 11 363 minecraft:dark_prismarine
fill 159 11 323 159 14 323 minecraft:blue_terracotta
setblock 159 11 362 minecraft:dark_prismarine
fill 159 11 363 159 14 363 minecraft:blue_terracotta
fill 160 11 362 163 11 362 minecraft:blue_terracotta
setblock 163 11 323 minecraft:dark_prismarine
setblock 163 11 363 minecraft:dark_prismarine
fill 164 11 323 167 11 323 minecraft:blue_terracotta
setblock 164 11 361 minecraft:blue_terracotta
setblock 164 11 362 minecraft:dark_prismarine
fill 164 11 363 164 14 363 minecraft:blue_terracotta
setblock 165 11 325 minecraft:light[level=12]
setblock 165 11 332 minecraft:light[level=12]
setblock 165 11 339 minecraft:light[level=12]
setblock 165 11 346 minecraft:light[level=12]
setblock 165 11 353 minecraft:light[level=12]
setblock 165 11 361 minecraft:dark_prismarine
fill 165 11 362 165 14 362 minecraft:blue_terracotta
setblock 166 11 324 minecraft:blue_terracotta
fill 166 11 361 166 13 361 minecraft:blue_terracotta
setblock 167 11 324 minecraft:dark_prismarine
setblock 168 11 323 minecraft:dark_prismarine
fill 168 11 324 171 11 324 minecraft:blue_terracotta
fill 168 11 360 170 11 360 minecraft:blue_terracotta
setblock 168 11 363 minecraft:dark_prismarine
fill 169 11 323 169 14 323 minecraft:blue_terracotta
fill 169 11 352 169 15 352 minecraft:black_concrete
fill 169 11 354 169 15 354 minecraft:black_concrete
setblock 169 11 362 minecraft:dark_prismarine
fill 169 11 363 169 14 363 minecraft:blue_terracotta
fill 170 11 351 171 15 351 minecraft:black_concrete
setblock 170 11 361 minecraft:dark_prismarine
fill 170 11 362 170 14 362 minecraft:blue_terracotta
setblock 171 11 360 minecraft:dark_prismarine
fill 171 11 361 171 14 361 minecraft:blue_terracotta
setblock 172 11 324 minecraft:dark_prismarine
setblock 172 11 325 minecraft:light[level=12]
setblock 172 11 332 minecraft:light[level=12]
setblock 172 11 339 minecraft:light[level=12]
setblock 172 11 346 minecraft:light[level=12]
fill 172 11 352 172 15 354 minecraft:black_concrete
fill 172 11 360 172 12 360 minecraft:blue_terracotta
setblock 173 11 323 minecraft:dark_prismarine
fill 173 11 324 173 13 324 minecraft:blue_terracotta
setblock 173 11 363 minecraft:dark_prismarine
fill 174 11 323 174 14 323 minecraft:blue_terracotta
fill 174 11 351 174 12 351 minecraft:dark_prismarine
fill 174 11 353 174 12 353 minecraft:dark_prismarine
fill 174 11 355 174 12 355 minecraft:dark_prismarine
fill 174 11 357 174 12 357 minecraft:dark_prismarine
fill 174 11 359 174 12 359 minecraft:dark_prismarine
setblock 174 11 361 minecraft:blue_terracotta
setblock 174 11 362 minecraft:dark_prismarine
fill 174 11 363 174 14 363 minecraft:blue_terracotta
fill 175 11 352 175 12 352 minecraft:dark_prismarine
fill 175 11 354 175 12 354 minecraft:dark_prismarine
fill 175 11 356 175 12 356 minecraft:dark_prismarine
fill 175 11 358 175 12 358 minecraft:dark_prismarine
fill 175 11 360 175 11 361 minecraft:dark_prismarine
fill 175 11 362 175 13 362 minecraft:blue_terracotta
fill 176 11 350 176 12 351 minecraft:magenta_terracotta
fill 176 11 353 176 12 353 minecraft:dark_prismarine
fill 176 11 355 176 12 355 minecraft:dark_prismarine
fill 176 11 357 176 12 357 minecraft:dark_prismarine
fill 176 11 359 176 12 359 minecraft:dark_prismarine
setblock 176 11 361 minecraft:blue_terracotta
fill 177 11 352 177 12 352 minecraft:magenta_terracotta
fill 177 11 354 177 12 354 minecraft:dark_prismarine
fill 177 11 356 177 12 356 minecraft:dark_prismarine
fill 177 11 358 177 12 358 minecraft:dark_prismarine
fill 177 11 360 177 12 361 minecraft:dark_prismarine
setblock 178 11 323 minecraft:dark_prismarine
fill 178 11 351 178 12 351 minecraft:magenta_terracotta
fill 178 11 353 178 12 353 minecraft:dark_prismarine
fill 178 11 355 178 12 355 minecraft:dark_prismarine
fill 178 11 357 178 12 357 minecraft:dark_prismarine
fill 178 11 359 178 12 359 minecraft:dark_prismarine
fill 178 11 361 178 12 361 minecraft:dark_prismarine
setblock 178 11 363 minecraft:dark_prismarine
setblock 179 11 325 minecraft:light[level=12]
setblock 179 11 332 minecraft:light[level=12]
setblock 179 11 339 minecraft:light[level=12]
setblock 179 11 346 minecraft:light[level=12]
fill 179 11 352 179 12 352 minecraft:magenta_terracotta
fill 179 11 354 179 12 354 minecraft:dark_prismarine
fill 179 11 356 179 12 356 minecraft:dark_prismarine
fill 179 11 358 179 12 358 minecraft:dark_prismarine
fill 179 11 360 179 12 360 minecraft:dark_prismarine
setblock 179 11 362 minecraft:dark_prismarine
fill 179 11 363 179 12 363 minecraft:blue_terracotta
setblock 180 11 342 minecraft:blue_terracotta
fill 180 11 351 180 12 351 minecraft:magenta_terracotta
fill 180 11 353 180 12 353 minecraft:dark_prismarine
fill 180 11 355 180 12 355 minecraft:dark_prismarine
fill 180 11 357 180 12 357 minecraft:dark_prismarine
fill 180 11 359 180 12 359 minecraft:dark_prismarine
fill 180 11 361 180 12 361 minecraft:dark_prismarine
setblock 181 11 340 minecraft:dark_prismarine
fill 181 11 341 181 14 341 minecraft:blue_terracotta
setblock 181 11 345 minecraft:dark_prismarine
fill 181 11 346 181 14 346 minecraft:blue_terracotta
fill 181 11 352 181 12 352 minecraft:dark_prismarine
fill 181 11 354 181 12 354 minecraft:dark_prismarine
fill 181 11 356 181 12 356 minecraft:dark_prismarine
fill 181 11 358 182 12 358 minecraft:dark_prismarine
fill 181 11 360 181 12 360 minecraft:dark_prismarine
setblock 182 11 339 minecraft:dark_prismarine
fill 182 11 340 182 14 340 minecraft:blue_terracotta
setblock 182 11 344 minecraft:dark_prismarine
fill 182 11 345 182 14 345 minecraft:blue_terracotta
setblock 182 11 349 minecraft:dark_prismarine
fill 182 11 351 182 12 351 minecraft:dark_prismarine
fill 182 11 353 182 12 353 minecraft:dark_prismarine
fill 182 11 355 182 12 355 minecraft:dark_prismarine
setblock 182 11 356 minecraft:purple_concrete
fill 182 11 357 182 12 357 minecraft:dark_prismarine
fill 182 11 359 182 12 359 minecraft:dark_prismarine
fill 182 11 360 182 11 361 minecraft:blue_terracotta
setblock 142 12 323 minecraft:dark_prismarine
fill 142 12 324 142 14 325 minecraft:blue_terracotta
setblock 142 12 338 minecraft:dark_prismarine
fill 142 12 339 142 15 339 minecraft:blue_terracotta
setblock 142 12 343 minecraft:dark_prismarine
fill 142 12 344 142 15 344 minecraft:blue_terracotta
setblock 142 12 355 minecraft:purple_concrete
fill 143 12 323 146 12 323 minecraft:blue_terracotta
fill 143 12 336 143 20 337 minecraft:dark_prismarine
setblock 143 12 338 minecraft:blue_terracotta
setblock 143 12 342 minecraft:dark_prismarine
fill 143 12 343 143 14 343 minecraft:blue_terracotta
fill 144 12 338 150 28 338 minecraft:dark_prismarine
fill 144 12 343 150 28 343 minecraft:dark_prismarine
setblock 145 12 324 minecraft:blue_terracotta
setblock 146 12 324 minecraft:dark_prismarine
setblock 147 12 323 minecraft:dark_prismarine
fill 147 12 324 147 14 325 minecraft:blue_terracotta
setblock 147 12 362 minecraft:blue_terracotta
setblock 147 12 363 minecraft:dark_prismarine
fill 148 12 323 148 15 323 minecraft:blue_terracotta
setblock 148 12 362 minecraft:dark_prismarine
fill 148 12 363 148 15 363 minecraft:blue_terracotta
fill 149 12 362 149 15 362 minecraft:blue_terracotta
setblock 150 12 324 minecraft:blue_terracotta
setblock 150 12 325 minecraft:dark_prismarine
setblock 150 12 361 minecraft:blue_terracotta
fill 151 12 322 151 14 322 minecraft:black_concrete
setblock 151 12 324 minecraft:dark_prismarine
fill 151 12 325 151 15 325 minecraft:blue_terracotta
setblock 152 12 322 minecraft:cyan_concrete
setblock 152 12 323 minecraft:dark_prismarine
fill 152 12 324 152 15 324 minecraft:blue_terracotta
setblock 152 12 363 minecraft:dark_prismarine
fill 153 12 322 160 71 322 minecraft:black_concrete
fill 153 12 323 153 15 323 minecraft:blue_terracotta
setblock 153 12 362 minecraft:dark_prismarine
fill 153 12 363 153 15 363 minecraft:blue_terracotta
setblock 154 12 361 minecraft:dark_prismarine
fill 154 12 362 157 12 362 minecraft:blue_terracotta
setblock 155 12 325 minecraft:dark_prismarine
setblock 155 12 361 minecraft:blue_terracotta
setblock 156 12 324 minecraft:dark_prismarine
setblock 156 12 325 minecraft:blue_terracotta
setblock 157 12 323 minecraft:dark_prismarine
fill 157 12 324 157 15 324 minecraft:blue_terracotta
setblock 157 12 363 minecraft:dark_prismarine
fill 157 12 364 157 39 364 minecraft:black_concrete
fill 158 12 323 158 15 323 minecraft:blue_terracotta
fill 158 12 326 158 19 326 minecraft:magenta_terracotta
setblock 158 12 362 minecraft:dark_prismarine
fill 158 12 363 158 15 363 minecraft:blue_terracotta
fill 159 12 362 162 12 362 minecraft:blue_terracotta
setblock 162 12 323 minecraft:dark_prismarine
setblock 162 12 363 minecraft:dark_prismarine
fill 163 12 323 166 12 323 minecraft:blue_terracotta
setblock 163 12 362 minecraft:dark_prismarine
fill 163 12 363 163 15 363 minecraft:blue_terracotta
fill 164 12 362 164 15 362 minecraft:blue_terracotta
setblock 165 12 361 minecraft:blue_terracotta
setblock 166 12 324 minecraft:dark_prismarine
setblock 167 12 323 minecraft:dark_prismarine
fill 167 12 324 170 12 324 minecraft:blue_terracotta
setblock 167 12 363 minecraft:dark_prismarine
fill 168 12 323 168 15 323 minecraft:blue_terracotta
fill 168 12 352 168 15 353 minecraft:black_concrete
setblock 168 12 362 minecraft:dark_prismarine
fill 168 12 363 168 15 363 minecraft:blue_terracotta
fill 169 12 351 169 15 351 minecraft:black_concrete
setblock 169 12 360 minecraft:blue_terracotta
setblock 169 12 361 minecraft:dark_prismarine
fill 169 12 362 169 15 362 minecraft:blue_terracotta
fill 170 12 355 171 15 355 minecraft:black_concrete
setblock 170 12 360 minecraft:dark_prismarine
fill 170 12 361 170 15 361 minecraft:blue_terracotta
setblock 171 12 324 minecraft:dark_prismarine
setblock 171 12 360 minecraft:blue_terracotta
setblock 172 12 323 minecraft:dark_prismarine
fill 172 12 324 172 14 324 minecraft:blue_terracotta
fill 172 12 351 172 15 351 minecraft:black_concrete
setblock 172 12 363 minecraft:dark_prismarine
fill 173 12 323 173 15 323 minecraft:blue_terracotta
setblock 173 12 362 minecraft:dark_prismarine
fill 173 12 363 173 15 363 minecraft:blue_terracotta
fill 174 12 360 174 12 361 minecraft:dark_prismarine
fill 174 12 362 174 14 362 minecraft:blue_terracotta
setblock 175 12 360 minecraft:dark_prismarine
setblock 175 12 361 minecraft:blue_terracotta
setblock 176 12 361 minecraft:dark_prismarine
setblock 177 12 323 minecraft:dark_prismarine
setblock 177 12 363 minecraft:dark_prismarine
fill 178 12 363 178 13 363 minecraft:blue_terracotta
setblock 181 12 339 minecraft:dark_prismarine
fill 181 12 340 181 13 340 minecraft:blue_terracotta
setblock 181 12 344 minecraft:dark_prismarine
fill 181 12 345 181 15 345 minecraft:blue_terracotta
setblock 182 12 331 minecraft:purple_concrete
setblock 182 12 338 minecraft:dark_prismarine
fill 182 12 339 182 15 339 minecraft:blue_terracotta
setblock 182 12 343 minecraft:dark_prismarine
fill 182 12 344 182 15 344 minecraft:blue_terracotta
setblock 182 12 348 minecraft:dark_prismarine
setblock 182 12 349 minecraft:blue_terracotta
setblock 182 12 350 minecraft:purple_concrete
fill 182 12 356 182 21 356 minecraft:dark_prismarine
fill 182 12 360 182 12 361 minecraft:dark_prismarine
fill 142 13 323 145 13 323 minecraft:blue_terracotta
setblock 142 13 326 minecraft:blue_terracotta
fill 142 13 335 142 15 335 minecraft:dark_prismarine
setblock 142 13 337 minecraft:dark_prismarine
fill 142 13 338 142 15 338 minecraft:blue_terracotta
setblock 142 13 342 minecraft:dark_prismarine
fill 142 13 343 142 16 343 minecraft:blue_terracotta
setblock 142 13 361 minecraft:purple_concrete
fill 143 13 338 143 22 338 minecraft:dark_prismarine
setblock 143 13 341 minecraft:dark_prismarine
fill 143 13 342 143 14 342 minecraft:blue_terracotta
setblock 144 13 324 minecraft:blue_terracotta
setblock 144 13 325 minecraft:light[level=13]
setblock 144 13 333 minecraft:light[level=13]
setblock 144 13 349 minecraft:light[level=13]
setblock 144 13 357 minecraft:light[level=13]
setblock 145 13 324 minecraft:dark_prismarine
setblock 146 13 323 minecraft:dark_prismarine
fill 146 13 324 146 16 324 minecraft:blue_terracotta
setblock 146 13 363 minecraft:dark_prismarine
fill 147 13 323 147 16 323 minecraft:blue_terracotta
setblock 147 13 362 minecraft:dark_prismarine
fill 147 13 363 147 16 363 minecraft:blue_terracotta
fill 148 13 362 148 16 362 minecraft:blue_terracotta
setblock 149 13 324 minecraft:blue_terracotta
setblock 149 13 325 minecraft:dark_prismarine
setblock 150 13 324 minecraft:dark_prismarine
fill 150 13 325 150 16 325 minecraft:blue_terracotta
setblock 151 13 323 minecraft:dark_prismarine
fill 151 13 324 151 16 324 minecraft:blue_terracotta
setblock 151 13 363 minecraft:dark_prismarine
fill 152 13 322 152 49 322 minecraft:black_concrete
fill 152 13 323 152 16 323 minecraft:blue_terracotta
setblock 152 13 333 minecraft:light[level=13]
setblock 152 13 341 minecraft:light[level=13]
setblock 152 13 349 minecraft:light[level=13]
setblock 152 13 357 minecraft:light[level=13]
setblock 152 13 362 minecraft:dark_prismarine
fill 152 13 363 152 16 363 minecraft:blue_terracotta
setblock 153 13 361 minecraft:dark_prismarine
fill 153 13 362 156 13 362 minecraft:blue_terracotta
setblock 154 13 325 minecraft:dark_prismarine
setblock 155 13 324 minecraft:dark_prismarine
setblock 155 13 325 minecraft:blue_terracotta
setblock 156 13 323 minecraft:dark_prismarine
fill 156 13 324 156 16 324 minecraft:blue_terracotta
setblock 156 13 363 minecraft:dark_prismarine
fill 157 13 323 157 16 323 minecraft:blue_terracotta
setblock 157 13 362 minecraft:dark_prismarine
fill 157 13 363 157 16 363 minecraft:blue_terracotta
fill 158 13 362 161 13 362 minecraft:blue_terracotta
setblock 160 13 325 minecraft:light[level=13]
setblock 160 13 333 minecraft:light[level=13]
setblock 160 13 341 minecraft:light[level=13]
setblock 160 13 349 minecraft:light[level=13]
setblock 160 13 357 minecraft:light[level=13]
setblock 161 13 323 minecraft:dark_prismarine
setblock 161 13 363 minecraft:dark_prismarine
fill 162 13 323 165 13 323 minecraft:blue_terracotta
setblock 162 13 362 minecraft:dark_prismarine
fill 162 13 363 162 16 363 minecraft:blue_terracotta
fill 163 13 362 163 15 362 minecraft:blue_terracotta
setblock 166 13 323 minecraft:dark_prismarine
fill 166 13 324 169 13 324 minecraft:blue_terracotta
setblock 166 13 363 minecraft:dark_prismarine
fill 167 13 323 167 16 323 minecraft:blue_terracotta
setblock 167 13 362 minecraft:dark_prismarine
fill 167 13 363 167 16 363 minecraft:blue_terracotta
setblock 168 13 325 minecraft:light[level=13]
setblock 168 13 333 minecraft:light[level=13]
setblock 168 13 341 minecraft:light[level=13]
setblock 168 13 349 minecraft:light[level=13]
fill 168 13 351 168 15 351 minecraft:black_concrete
fill 168 13 354 168 15 354 minecraft:black_concrete
setblock 168 13 357 minecraft:light[level=13]
setblock 168 13 361 minecraft:dark_prismarine
fill 168 13 362 168 16 362 minecraft:blue_terracotta
fill 169 13 355 169 15 355 minecraft:black_concrete
fill 169 13 357 169 14 357 minecraft:black_concrete
fill 169 13 361 169 15 361 minecraft:blue_terracotta
setblock 170 13 324 minecraft:dark_prismarine
fill 170 13 350 171 15 350 minecraft:black_concrete
setblock 171 13 323 minecraft:dark_prismarine
fill 171 13 324 171 16 324 minecraft:blue_terracotta
setblock 171 13 363 minecraft:dark_prismarine
fill 172 13 323 172 16 323 minecraft:blue_terracotta
fill 172 13 355 172 15 355 minecraft:black_concrete
setblock 172 13 362 minecraft:dark_prismarine
fill 172 13 363 172 16 363 minecraft:blue_terracotta
fill 173 13 352 173 15 354 minecraft:black_concrete
setblock 173 13 361 minecraft:dark_prismarine
fill 173 13 362 173 15 362 minecraft:blue_terracotta
setblock 174 13 351 minecraft:sea_lantern
setblock 174 13 353 minecraft:sea_lantern
setblock 174 13 355 minecraft:sea_lantern
setblock 174 13 357 minecraft:sea_lantern
setblock 174 13 359 minecraft:sea_lantern
fill 174 13 360 174 28 360 minecraft:dark_prismarine
setblock 174 13 361 minecraft:sea_lantern
setblock 175 13 352 minecraft:sea_lantern
setblock 175 13 354 minecraft:sea_lantern
setblock 175 13 356 minecraft:sea_lantern
setblock 175 13 358 minecraft:sea_lantern
setblock 175 13 360 minecraft:sea_lantern
fill 175 13 361 175 28 361 minecraft:dark_prismarine
setblock 176 13 323 minecraft:dark_prismarine
setblock 176 13 325 minecraft:light[level=13]
setblock 176 13 333 minecraft:light[level=13]
setblock 176 13 341 minecraft:light[level=13]
setblock 176 13 349 minecraft:light[level=13]
fill 176 13 350 176 33 350 minecraft:magenta_terracotta
setblock 176 13 351 minecraft:sea_lantern
setblock 176 13 353 minecraft:sea_lantern
setblock 176 13 355 minecraft:sea_lantern
setblock 176 13 357 minecraft:sea_lantern
setblock 176 13 359 minecraft:sea_lantern
setblock 176 13 361 minecraft:sea_lantern
setblock 176 13 363 minecraft:dark_prismarine
setblock 177 13 352 minecraft:sea_lantern
setblock 177 13 354 minecraft:sea_lantern
setblock 177 13 356 minecraft:sea_lantern
setblock 177 13 358 minecraft:sea_lantern
setblock 177 13 360 minecraft:sea_lantern
fill 177 13 361 177 28 361 minecraft:dark_prismarine
fill 177 13 363 177 14 363 minecraft:blue_terracotta
setblock 178 13 351 minecraft:sea_lantern
setblock 178 13 353 minecraft:sea_lantern
setblock 178 13 355 minecraft:sea_lantern
setblock 178 13 357 minecraft:sea_lantern
setblock 178 13 359 minecraft:sea_lantern
setblock 178 13 361 minecraft:sea_lantern
setblock 179 13 352 minecraft:sea_lantern
setblock 179 13 354 minecraft:sea_lantern
setblock 179 13 356 minecraft:sea_lantern
setblock 179 13 358 minecraft:sea_lantern
setblock 179 13 360 minecraft:sea_lantern
setblock 180 13 351 minecraft:sea_lantern
setblock 180 13 353 minecraft:sea_lantern
setblock 180 13 355 minecraft:sea_lantern
setblock 180 13 357 minecraft:sea_lantern
setblock 180 13 359 minecraft:sea_lantern
setblock 180 13 361 minecraft:sea_lantern
setblock 181 13 343 minecraft:dark_prismarine
fill 181 13 344 181 16 344 minecraft:blue_terracotta
setblock 181 13 352 minecraft:sea_lantern
setblock 181 13 354 minecraft:sea_lantern
setblock 181 13 356 minecraft:sea_lantern
setblock 181 13 358 minecraft:sea_lantern
setblock 181 13 360 minecraft:sea_lantern
setblock 182 13 325 minecraft:purple_concrete
setblock 182 13 337 minecraft:dark_prismarine
fill 182 13 338 182 14 338 minecraft:blue_terracotta
setblock 182 13 342 minecraft:dark_prismarine
fill 182 13 343 182 16 343 minecraft:blue_terracotta
setblock 182 13 347 minecraft:dark_prismarine
fill 182 13 348 182 16 348 minecraft:blue_terracotta
setblock 182 13 351 minecraft:sea_lantern
setblock 182 13 353 minecraft:sea_lantern
setblock 182 13 355 minecraft:sea_lantern
setblock 182 13 357 minecraft:sea_lantern
fill 182 13 358 182 17 358 minecraft:dark_prismarine
setblock 182 13 359 minecraft:sea_lantern
fill 182 13 360 182 24 360 minecraft:dark_prismarine
setblock 182 13 361 minecraft:sea_lantern
fill 183 13 323 183 28 329 minecraft:black_concrete
setblock 183 13 330 minecraft:cyan_concrete
fill 183 13 331 183 19 333 minecraft:black_concrete
setblock 183 13 357 minecraft:light_blue_wool
fill 183 13 361 183 38 361 minecraft:black_concrete
setblock 183 13 362 minecraft:cyan_concrete
fill 183 13 363 183 131 363 minecraft:black_concrete
fill 142 14 323 144 14 323 minecraft:blue_terracotta
setblock 142 14 326 minecraft:dark_prismarine
fill 142 14 327 142 17 327 minecraft:blue_terracotta
fill 142 14 336 142 19 336 minecraft:dark_prismarine
setblock 142 14 337 minecraft:blue_terracotta
setblock 142 14 341 minecraft:dark_prismarine
fill 142 14 342 142 17 342 minecraft:blue_terracotta
setblock 142 14 346 minecraft:dark_prismarine
setblock 142 14 348 minecraft:purple_concrete
fill 143 14 339 143 28 340 minecraft:dark_prismarine
setblock 143 14 341 minecraft:blue_terracotta
fill 143 14 344 143 18 344 minecraft:dark_prismarine
setblock 144 14 324 minecraft:dark_prismarine
setblock 145 14 323 minecraft:dark_prismarine
fill 145 14 324 145 17 324 minecraft:blue_terracotta
setblock 145 14 363 minecraft:dark_prismarine
fill 146 14 323 146 17 323 minecraft:blue_terracotta
fill 146 14 325 146 15 325 minecraft:blue_terracotta
fill 146 14 363 146 17 363 minecraft:blue_terracotta
setblock 147 14 362 minecraft:blue_terracotta
setblock 148 14 324 minecraft:blue_terracotta
setblock 148 14 325 minecraft:dark_prismarine
setblock 149 14 324 minecraft:dark_prismarine
fill 149 14 325 149 17 325 minecraft:blue_terracotta
setblock 150 14 323 minecraft:dark_prismarine
fill 150 14 324 150 17 324 minecraft:blue_terracotta
setblock 150 14 363 minecraft:dark_prismarine
fill 151 14 323 151 17 323 minecraft:blue_terracotta
setblock 151 14 362 minecraft:dark_prismarine
fill 151 14 363 151 17 363 minecraft:blue_terracotta
fill 152 14 362 155 14 362 minecraft:blue_terracotta
setblock 153 14 325 minecraft:dark_prismarine
setblock 154 14 324 minecraft:dark_prismarine
fill 154 14 325 154 15 325 minecraft:blue_terracotta
setblock 155 14 323 minecraft:dark_prismarine
fill 155 14 324 155 17 324 minecraft:blue_terracotta
setblock 155 14 363 minecraft:dark_prismarine
fill 156 14 323 156 17 323 minecraft:blue_terracotta
setblock 156 14 362 minecraft:dark_prismarine
fill 156 14 363 156 17 363 minecraft:blue_terracotta
setblock 157 14 362 minecraft:blue_terracotta
setblock 160 14 323 minecraft:dark_prismarine
setblock 160 14 363 minecraft:dark_prismarine
fill 161 14 323 164 14 323 minecraft:blue_terracotta
fill 161 14 363 161 17 363 minecraft:blue_terracotta
setblock 162 14 362 minecraft:blue_terracotta
fill 163 14 358 163 33 358 minecraft:magenta_terracotta
fill 164 14 356 164 33 356 minecraft:magenta_terracotta
setblock 165 14 323 minecraft:dark_prismarine
setblock 165 14 363 minecraft:dark_prismarine
fill 166 14 323 166 16 324 minecraft:blue_terracotta
setblock 166 14 362 minecraft:dark_prismarine
fill 166 14 363 166 17 363 minecraft:blue_terracotta
fill 167 14 324 168 14 324 minecraft:blue_terracotta
fill 167 14 352 167 15 353 minecraft:black_concrete
setblock 167 14 361 minecraft:dark_prismarine
fill 167 14 362 167 17 362 minecraft:blue_terracotta
fill 168 14 355 168 15 355 minecraft:black_concrete
fill 168 14 361 168 15 361 minecraft:blue_terracotta
setblock 169 14 324 minecraft:dark_prismarine
fill 169 14 350 169 15 350 minecraft:black_concrete
fill 169 14 356 171 15 356 minecraft:black_concrete
setblock 170 14 323 minecraft:dark_prismarine
fill 170 14 324 170 17 324 minecraft:blue_terracotta
setblock 170 14 363 minecraft:dark_prismarine
fill 171 14 323 171 17 323 minecraft:blue_terracotta
setblock 171 14 362 minecraft:dark_prismarine
fill 171 14 363 171 17 363 minecraft:blue_terracotta
fill 172 14 350 172 15 350 minecraft:black_concrete
setblock 172 14 361 minecraft:dark_prismarine
fill 172 14 362 172 16 362 minecraft:blue_terracotta
fill 173 14 351 173 15 351 minecraft:black_concrete
fill 173 14 355 173 15 355 minecraft:black_concrete
fill 174 14 351 174 15 351 minecraft:dark_prismarine
fill 174 14 353 174 15 353 minecraft:dark_prismarine
fill 174 14 355 174 15 355 minecraft:dark_prismarine
fill 174 14 357 174 15 357 minecraft:dark_prismarine
fill 174 14 359 174 15 359 minecraft:dark_prismarine
fill 174 14 361 174 15 361 minecraft:dark_prismarine
setblock 175 14 323 minecraft:dark_prismarine
fill 175 14 352 175 15 352 minecraft:dark_prismarine
fill 175 14 354 175 15 354 minecraft:dark_prismarine
fill 175 14 356 175 15 356 minecraft:dark_prismarine
fill 175 14 358 175 15 358 minecraft:dark_prismarine
fill 175 14 360 175 15 360 minecraft:dark_prismarine
setblock 175 14 363 minecraft:dark_prismarine
setblock 176 14 323 minecraft:blue_terracotta
fill 176 14 337 176 33 337 minecraft:magenta_terracotta
fill 176 14 351 176 15 351 minecraft:magenta_terracotta
fill 176 14 353 176 15 353 minecraft:dark_prismarine
fill 176 14 355 176 15 355 minecraft:dark_prismarine
fill 176 14 357 176 15 357 minecraft:dark_prismarine
fill 176 14 359 176 15 359 minecraft:dark_prismarine
fill 176 14 361 176 15 361 minecraft:dark_prismarine
fill 176 14 363 176 15 363 minecraft:blue_terracotta
fill 177 14 352 177 15 352 minecraft:magenta_terracotta
fill 177 14 354 177 15 354 minecraft:dark_prismarine
fill 177 14 356 177 15 356 minecraft:dark_prismarine
fill 177 14 358 177 15 358 minecraft:dark_prismarine
fill 177 14 360 177 15 360 minecraft:dark_prismarine
setblock 178 14 323 minecraft:purple_concrete
fill 178 14 351 178 15 351 minecraft:magenta_terracotta
fill 178 14 353 178 15 353 minecraft:dark_prismarine
fill 178 14 355 178 15 355 minecraft:dark_prismarine
fill 178 14 357 178 15 357 minecraft:dark_prismarine
fill 178 14 359 178 15 359 minecraft:dark_prismarine
fill 178 14 361 178 15 361 minecraft:dark_prismarine
fill 179 14 352 179 15 352 minecraft:magenta_terracotta
fill 179 14 354 179 15 354 minecraft:dark_prismarine
fill 179 14 356 179 15 356 minecraft:dark_prismarine
fill 179 14 358 179 15 358 minecraft:dark_prismarine
fill 179 14 360 179 15 360 minecraft:dark_prismarine
fill 180 14 351 180 15 351 minecraft:magenta_terracotta
fill 180 14 353 180 15 353 minecraft:dark_prismarine
fill 180 14 355 180 15 355 minecraft:dark_prismarine
fill 180 14 357 180 15 357 minecraft:dark_prismarine
fill 180 14 359 180 15 359 minecraft:dark_prismarine
fill 180 14 361 180 15 361 minecraft:dark_prismarine
setblock 181 14 342 minecraft:dark_prismarine
fill 181 14 343 181 17 343 minecraft:blue_terracotta
fill 181 14 352 181 15 352 minecraft:dark_prismarine
fill 181 14 354 181 15 354 minecraft:dark_prismarine
fill 181 14 356 181 15 356 minecraft:dark_prismarine
fill 181 14 358 181 15 358 minecraft:dark_prismarine
fill 181 14 360 181 15 360 minecraft:dark_prismarine
setblock 182 14 341 minecraft:dark_prismarine
fill 182 14 342 182 17 342 minecraft:blue_terracotta
setblock 182 14 346 minecraft:dark_prismarine
fill 182 14 347 182 17 347 minecraft:blue_terracotta
fill 182 14 351 182 15 351 minecraft:dark_prismarine
fill 182 14 353 182 15 353 minecraft:dark_prismarine
fill 182 14 355 182 15 355 minecraft:dark_prismarine
setblock 182 14 357 minecraft:dark_prismarine
fill 182 14 359 182 15 359 minecraft:dark_prismarine
fill 182 14 361 182 15 361 minecraft:dark_prismarine
fill 183 14 330 183 131 330 minecraft:black_concrete
fill 183 14 357 183 131 357 minecraft:black_concrete
fill 183 14 362 183 41 362 minecraft:black_concrete
fill 142 15 323 142 15 324 minecraft:blue_terracotta
setblock 142 15 325 minecraft:dark_prismarine
fill 142 15 326 142 18 326 minecraft:blue_terracotta
fill 142 15 328 142 16 328 minecraft:blue_terracotta
setblock 142 15 329 minecraft:purple_concrete
fill 142 15 337 142 18 337 minecraft:dark_prismarine
setblock 142 15 340 minecraft:dark_prismarine
fill 142 15 341 142 18 341 minecraft:blue_terracotta
setblock 142 15 345 minecraft:dark_prismarine
fill 142 15 346 142 18 346 minecraft:blue_terracotta
setblock 142 15 354 minecraft:purple_concrete
setblock 143 15 323 minecraft:blue_terracotta
setblock 143 15 324 minecraft:dark_prismarine
fill 143 15 325 143 18 325 minecraft:blue_terracotta
fill 143 15 341 143 21 343 minecraft:dark_prismarine
setblock 144 15 323 minecraft:dark_prismarine
fill 144 15 324 144 18 324 minecraft:blue_terracotta
setblock 144 15 363 minecraft:dark_prismarine
fill 145 15 323 145 18 323 minecraft:blue_terracotta
fill 145 15 363 145 18 363 minecraft:blue_terracotta
setblock 147 15 324 minecraft:blue_terracotta
setblock 147 15 325 minecraft:dark_prismarine
setblock 148 15 324 minecraft:dark_prismarine
fill 148 15 325 148 18 325 minecraft:blue_terracotta
setblock 149 15 323 minecraft:dark_prismarine
fill 149 15 324 149 18 324 minecraft:blue_terracotta
setblock 149 15 363 minecraft:dark_prismarine
fill 150 15 323 150 18 323 minecraft:blue_terracotta
setblock 150 15 362 minecraft:dark_prismarine
fill 150 15 363 150 18 363 minecraft:blue_terracotta
setblock 151 15 322 minecraft:cyan_concrete
fill 151 15 362 154 15 362 minecraft:blue_terracotta
setblock 152 15 325 minecraft:dark_prismarine
setblock 153 15 324 minecraft:dark_prismarine
fill 153 15 325 153 18 325 minecraft:blue_terracotta
setblock 154 15 323 minecraft:dark_prismarine
fill 154 15 324 154 18 324 minecraft:blue_terracotta
setblock 154 15 363 minecraft:dark_prismarine
fill 155 15 323 155 18 323 minecraft:blue_terracotta
setblock 155 15 362 minecraft:dark_prismarine
fill 155 15 363 155 18 363 minecraft:blue_terracotta
setblock 159 15 323 minecraft:dark_prismarine
setblock 159 15 363 minecraft:dark_prismarine
fill 160 15 323 163 15 323 minecraft:blue_terracotta
fill 160 15 363 160 18 363 minecraft:blue_terracotta
fill 161 15 328 161 33 328 minecraft:magenta_terracotta
setblock 164 15 323 minecraft:dark_prismarine
setblock 164 15 363 minecraft:dark_prismarine
fill 165 15 323 165 17 324 minecraft:blue_terracotta
setblock 165 15 362 minecraft:dark_prismarine
fill 165 15 363 165 18 363 minecraft:blue_terracotta
fill 166 15 362 166 18 362 minecraft:blue_terracotta
setblock 167 15 324 minecraft:blue_terracotta
setblock 167 15 351 minecraft:black_concrete
setblock 167 15 354 minecraft:black_concrete
setblock 168 15 324 minecraft:dark_prismarine
setblock 168 15 350 minecraft:black_concrete
setblock 169 15 323 minecraft:dark_prismarine
fill 169 15 324 169 18 324 minecraft:blue_terracotta
setblock 169 15 363 minecraft:dark_prismarine
fill 170 15 323 170 18 323 minecraft:blue_terracotta
fill 170 15 349 171 15 349 minecraft:black_concrete
setblock 170 15 362 minecraft:dark_prismarine
fill 170 15 363 170 18 363 minecraft:blue_terracotta
fill 171 15 362 171 17 362 minecraft:blue_terracotta
setblock 172 15 356 minecraft:black_concrete
setblock 173 15 350 minecraft:black_concrete
setblock 174 15 323 minecraft:dark_prismarine
setblock 174 15 363 minecraft:dark_prismarine
setblock 175 15 323 minecraft:blue_terracotta
setblock 175 15 363 minecraft:blue_terracotta
fill 176 15 349 176 18 349 minecraft:magenta_terracotta
setblock 177 15 363 minecraft:purple_concrete
setblock 181 15 342 minecraft:blue_terracotta
setblock 181 15 346 minecraft:dark_prismarine
setblock 182 15 332 minecraft:purple_concrete
setblock 182 15 340 minecraft:dark_prismarine
fill 182 15 341 182 18 341 minecraft:blue_terracotta
setblock 182 15 345 minecraft:dark_prismarine
fill 182 15 346 182 18 346 minecraft:blue_terracotta
setblock 182 15 349 minecraft:blue_terracotta
setblock 182 15 357 minecraft:purple_concrete
setblock 142 16 323 minecraft:blue_terracotta
setblock 142 16 324 minecraft:dark_prismarine
fill 142 16 325 142 19 325 minecraft:blue_terracotta
setblock 142 16 329 minecraft:dark_prismarine
fill 142 16 330 142 19 330 minecraft:blue_terracotta
setblock 142 16 335 minecraft:purple_concrete
fill 142 16 338 142 18 339 minecraft:dark_prismarine
fill 142 16 340 142 19 340 minecraft:blue_terracotta
setblock 142 16 344 minecraft:dark_prismarine
fill 142 16 345 142 19 345 minecraft:blue_terracotta
fill 142 16 347 142 17 347 minecraft:blue_terracotta
setblock 142 16 360 minecraft:purple_concrete
setblock 143 16 323 minecraft:dark_prismarine
fill 143 16 324 143 19 324 minecraft:blue_terracotta
fill 143 16 326 143 16 327 minecraft:blue_terracotta
fill 144 16 323 144 19 323 minecraft:blue_terracotta
fill 144 16 363 144 19 363 minecraft:blue_terracotta
setblock 145 16 325 minecraft:blue_terracotta
setblock 146 16 325 minecraft:dark_prismarine
setblock 147 16 324 minecraft:dark_prismarine
fill 147 16 325 147 19 325 minecraft:blue_terracotta
setblock 148 16 323 minecraft:dark_prismarine
fill 148 16 324 148 19 324 minecraft:blue_terracotta
setblock 148 16 363 minecraft:dark_prismarine
fill 149 16 323 149 19 323 minecraft:blue_terracotta
setblock 149 16 326 minecraft:blue_terracotta
setblock 149 16 362 minecraft:dark_prismarine
fill 149 16 363 149 19 363 minecraft:blue_terracotta
fill 150 16 362 153 16 362 minecraft:blue_terracotta
fill 151 16 322 151 131 322 minecraft:black_concrete
setblock 151 16 325 minecraft:dark_prismarine
setblock 152 16 324 minecraft:dark_prismarine
fill 152 16 325 152 19 325 minecraft:blue_terracotta
setblock 153 16 323 minecraft:dark_prismarine
fill 153 16 324 153 19 324 minecraft:blue_terracotta
setblock 153 16 363 minecraft:dark_prismarine
fill 154 16 323 154 19 323 minecraft:blue_terracotta
fill 154 16 363 154 19 363 minecraft:blue_terracotta
setblock 157 16 324 minecraft:dark_prismarine
setblock 158 16 323 minecraft:dark_prismarine
setblock 158 16 363 minecraft:dark_prismarine
fill 159 16 323 162 16 323 minecraft:blue_terracotta
fill 159 16 363 159 19 363 minecraft:blue_terracotta
setblock 163 16 323 minecraft:dark_prismarine
fill 163 16 357 163 33 357 minecraft:magenta_terracotta
setblock 163 16 363 minecraft:dark_prismarine
fill 164 16 323 164 19 323 minecraft:blue_terracotta
setblock 164 16 362 minecraft:dark_prismarine
fill 164 16 363 164 19 363 minecraft:blue_terracotta
fill 165 16 362 165 19 362 minecraft:blue_terracotta
fill 166 16 359 166 28 359 minecraft:magenta_terracotta
setblock 167 16 324 minecraft:dark_prismarine
fill 167 16 337 169 17 337 minecraft:spruce_planks
setblock 168 16 323 minecraft:dark_prismarine
fill 168 16 324 168 19 324 minecraft:blue_terracotta
fill 168 16 336 168 17 336 minecraft:spruce_planks
fill 168 16 338 169 17 338 minecraft:spruce_planks
setblock 168 16 363 minecraft:dark_prismarine
fill 169 16 323 169 19 323 minecraft:blue_terracotta
fill 169 16 353 169 20 353 minecraft:dark_prismarine
setblock 169 16 362 minecraft:dark_prismarine
fill 169 16 363 169 19 363 minecraft:blue_terracotta
fill 170 16 362 170 18 362 minecraft:blue_terracotta
fill 171 16 351 171 18 351 minecraft:dark_prismarine
fill 171 16 354 171 17 354 minecraft:dark_prismarine
setblock 173 16 323 minecraft:dark_prismarine
setblock 173 16 363 minecraft:dark_prismarine
setblock 174 16 323 minecraft:blue_terracotta
setblock 174 16 351 minecraft:sea_lantern
setblock 174 16 353 minecraft:sea_lantern
setblock 174 16 355 minecraft:sea_lantern
setblock 174 16 357 minecraft:sea_lantern
setblock 174 16 359 minecraft:sea_lantern
setblock 174 16 361 minecraft:sea_lantern
setblock 174 16 363 minecraft:blue_terracotta
setblock 175 16 352 minecraft:sea_lantern
setblock 175 16 354 minecraft:sea_lantern
setblock 175 16 356 minecraft:sea_lantern
setblock 175 16 358 minecraft:sea_lantern
setblock 175 16 360 minecraft:sea_lantern
setblock 176 16 351 minecraft:sea_lantern
setblock 176 16 353 minecraft:sea_lantern
setblock 176 16 355 minecraft:sea_lantern
setblock 176 16 357 minecraft:sea_lantern
setblock 176 16 359 minecraft:sea_lantern
setblock 176 16 361 minecraft:sea_lantern
setblock 177 16 352 minecraft:sea_lantern
setblock 177 16 354 minecraft:sea_lantern
setblock 177 16 356 minecraft:sea_lantern
setblock 177 16 358 minecraft:sea_lantern
setblock 177 16 360 minecraft:sea_lantern
setblock 178 16 351 minecraft:sea_lantern
setblock 178 16 353 minecraft:sea_lantern
setblock 178 16 355 minecraft:sea_lantern
setblock 178 16 357 minecraft:sea_lantern
setblock 178 16 359 minecraft:sea_lantern
setblock 178 16 361 minecraft:sea_lantern
setblock 179 16 352 minecraft:sea_lantern
setblock 179 16 354 minecraft:sea_lantern
setblock 179 16 356 minecraft:sea_lantern
setblock 179 16 358 minecraft:sea_lantern
setblock 179 16 360 minecraft:sea_lantern
setblock 180 16 351 minecraft:sea_lantern
setblock 180 16 353 minecraft:sea_lantern
setblock 180 16 355 minecraft:sea_lantern
setblock 180 16 357 minecraft:sea_lantern
setblock 180 16 359 minecraft:sea_lantern
setblock 180 16 361 minecraft:sea_lantern
setblock 181 16 345 minecraft:dark_prismarine
fill 181 16 346 181 19 346 minecraft:blue_terracotta
setblock 181 16 352 minecraft:sea_lantern
setblock 181 16 354 minecraft:sea_lantern
setblock 181 16 356 minecraft:sea_lantern
setblock 181 16 358 minecraft:sea_lantern
setblock 181 16 360 minecraft:sea_lantern
setblock 182 16 326 minecraft:purple_concrete
setblock 182 16 339 minecraft:dark_prismarine
fill 182 16 340 182 19 340 minecraft:blue_terracotta
setblock 182 16 344 minecraft:dark_prismarine
fill 182 16 345 182 19 345 minecraft:blue_terracotta
setblock 182 16 349 minecraft:dark_prismarine
setblock 182 16 351 minecraft:sea_lantern
setblock 182 16 353 minecraft:sea_lantern
setblock 182 16 355 minecraft:sea_lantern
setblock 182 16 357 minecraft:sea_lantern
setblock 182 16 359 minecraft:sea_lantern
setblock 182 16 361 minecraft:sea_lantern
setblock 142 17 323 minecraft:dark_prismarine
fill 142 17 324 142 20 324 minecraft:blue_terracotta
setblock 142 17 328 minecraft:dark_prismarine
fill 142 17 329 143 19 329 minecraft:blue_terracotta
fill 142 17 331 142 18 331 minecraft:blue_terracotta
fill 142 17 335 142 18 335 minecraft:dark_prismarine
setblock 142 17 343 minecraft:dark_prismarine
fill 142 17 344 142 20 344 minecraft:blue_terracotta
fill 143 17 323 143 20 323 minecraft:blue_terracotta
setblock 143 17 326 minecraft:blue_terracotta
setblock 143 17 327 minecraft:dark_prismarine
fill 143 17 328 143 20 328 minecraft:blue_terracotta
setblock 144 17 325 minecraft:blue_terracotta
setblock 144 17 326 minecraft:dark_prismarine
fill 144 17 327 144 20 327 minecraft:blue_terracotta
setblock 144 17 332 minecraft:light[level=12]
setblock 144 17 353 minecraft:light[level=12]
setblock 144 17 360 minecraft:light[level=12]
setblock 145 17 325 minecraft:dark_prismarine
setblock 146 17 324 minecraft:dark_prismarine
fill 146 17 325 146 20 325 minecraft:blue_terracotta
setblock 147 17 323 minecraft:dark_prismarine
fill 147 17 324 147 20 324 minecraft:blue_terracotta
fill 147 17 326 148 17 326 minecraft:blue_terracotta
setblock 147 17 363 minecraft:dark_prismarine
fill 148 17 323 148 20 323 minecraft:blue_terracotta
setblock 148 17 362 minecraft:dark_prismarine
fill 148 17 363 148 20 363 minecraft:blue_terracotta
setblock 149 17 326 minecraft:dark_prismarine
fill 149 17 362 152 17 362 minecraft:blue_terracotta
setblock 150 17 325 minecraft:dark_prismarine
fill 150 17 326 150 20 326 minecraft:blue_terracotta
setblock 151 17 324 minecraft:dark_prismarine
fill 151 17 325 151 20 325 minecraft:blue_terracotta
setblock 151 17 332 minecraft:light[level=12]
setblock 151 17 339 minecraft:light[level=12]
setblock 151 17 346 minecraft:light[level=12]
setblock 151 17 353 minecraft:light[level=12]
setblock 151 17 360 minecraft:light[level=12]
setblock 152 17 323 minecraft:dark_prismarine
fill 152 17 324 152 20 324 minecraft:blue_terracotta
setblock 152 17 363 minecraft:dark_prismarine
fill 153 17 323 153 20 323 minecraft:blue_terracotta
fill 153 17 363 153 20 363 minecraft:blue_terracotta
setblock 156 17 324 minecraft:dark_prismarine
setblock 157 17 323 minecraft:dark_prismarine
setblock 157 17 363 minecraft:dark_prismarine
fill 158 17 323 161 17 323 minecraft:blue_terracotta
setblock 158 17 325 minecraft:light[level=12]
setblock 158 17 332 minecraft:light[level=12]
setblock 158 17 339 minecraft:light[level=12]
setblock 158 17 346 minecraft:light[level=12]
setblock 158 17 353 minecraft:light[level=12]
setblock 158 17 360 minecraft:light[level=12]
fill 158 17 363 158 20 363 minecraft:blue_terracotta
setblock 162 17 323 minecraft:dark_prismarine
setblock 162 17 363 minecraft:dark_prismarine
fill 163 17 323 163 20 323 minecraft:blue_terracotta
fill 163 17 363 163 20 363 minecraft:blue_terracotta
fill 164 17 324 164 18 324 minecraft:blue_terracotta
fill 164 17 362 164 20 362 minecraft:blue_terracotta
setblock 165 17 325 minecraft:light[level=12]
setblock 165 17 332 minecraft:light[level=12]
setblock 165 17 339 minecraft:light[level=12]
setblock 165 17 346 minecraft:light[level=12]
setblock 165 17 353 minecraft:light[level=12]
setblock 166 17 323 minecraft:blue_terracotta
setblock 166 17 324 minecraft:dark_prismarine
setblock 167 17 323 minecraft:dark_prismarine
fill 167 17 324 167 20 324 minecraft:blue_terracotta
setblock 167 17 363 minecraft:dark_prismarine
fill 168 17 323 168 20 323 minecraft:blue_terracotta
setblock 168 17 362 minecraft:dark_prismarine
fill 168 17 363 168 20 363 minecraft:blue_terracotta
fill 169 17 362 169 20 362 minecraft:blue_terracotta
setblock 171 17 324 minecraft:dark_prismarine
setblock 172 17 323 minecraft:dark_prismarine
setblock 172 17 325 minecraft:light[level=12]
setblock 172 17 332 minecraft:light[level=12]
setblock 172 17 339 minecraft:light[level=12]
setblock 172 17 346 minecraft:light[level=12]
setblock 172 17 353 minecraft:light[level=12]
setblock 172 17 360 minecraft:light[level=12]
setblock 172 17 363 minecraft:dark_prismarine
fill 173 17 323 173 19 323 minecraft:blue_terracotta
fill 173 17 363 173 18 363 minecraft:blue_terracotta
fill 174 17 351 174 18 351 minecraft:dark_prismarine
fill 174 17 353 174 18 353 minecraft:dark_prismarine
fill 174 17 355 174 18 355 minecraft:dark_prismarine
fill 174 17 357 174 18 357 minecraft:dark_prismarine
fill 174 17 359 174 18 359 minecraft:dark_prismarine
fill 174 17 361 174 18 361 minecraft:dark_prismarine
fill 175 17 352 175 18 352 minecraft:dark_prismarine
fill 175 17 354 175 18 354 minecraft:dark_prismarine
fill 175 17 356 175 18 356 minecraft:dark_prismarine
fill 175 17 358 175 18 358 minecraft:dark_prismarine
fill 175 17 360 175 18 360 minecraft:dark_prismarine
fill 176 17 351 176 18 351 minecraft:magenta_terracotta
fill 176 17 353 176 18 353 minecraft:dark_prismarine
fill 176 17 355 176 18 355 minecraft:dark_prismarine
fill 176 17 357 176 18 357 minecraft:dark_prismarine
fill 176 17 359 176 18 359 minecraft:dark_prismarine
fill 176 17 361 176 18 361 minecraft:dark_prismarine
fill 177 17 352 177 18 352 minecraft:magenta_terracotta
fill 177 17 354 177 18 354 minecraft:dark_prismarine
fill 177 17 356 177 18 356 minecraft:dark_prismarine
fill 177 17 358 177 18 358 minecraft:dark_prismarine
fill 177 17 360 177 18 360 minecraft:dark_prismarine
fill 178 17 351 178 18 351 minecraft:magenta_terracotta
fill 178 17 353 178 18 353 minecraft:dark_prismarine
fill 178 17 355 178 18 355 minecraft:dark_prismarine
fill 178 17 357 178 18 357 minecraft:dark_prismarine
fill 178 17 359 178 18 359 minecraft:dark_prismarine
fill 178 17 361 178 18 361 minecraft:dark_prismarine
setblock 179 17 323 minecraft:purple_concrete
setblock 179 17 325 minecraft:light[level=12]
setblock 179 17 332 minecraft:light[level=12]
setblock 179 17 339 minecraft:light[level=12]
setblock 179 17 346 minecraft:light[level=12]
fill 179 17 352 179 18 352 minecraft:magenta_terracotta
fill 179 17 354 179 18 354 minecraft:dark_prismarine
fill 179 17 356 179 18 356 minecraft:dark_prismarine
fill 179 17 358 179 18 358 minecraft:dark_prismarine
fill 179 17 360 179 18 360 minecraft:dark_prismarine
fill 180 17 351 180 18 351 minecraft:magenta_terracotta
fill 180 17 353 180 18 353 minecraft:dark_prismarine
fill 180 17 355 180 18 355 minecraft:dark_prismarine
fill 180 17 357 180 18 357 minecraft:dark_prismarine
fill 180 17 359 180 18 359 minecraft:dark_prismarine
fill 180 17 361 180 18 361 minecraft:dark_prismarine
setblock 181 17 344 minecraft:dark_prismarine
fill 181 17 345 181 20 345 minecraft:blue_terracotta
fill 181 17 347 181 18 347 minecraft:blue_terracotta
fill 181 17 352 181 18 352 minecraft:dark_prismarine
fill 181 17 354 181 18 354 minecraft:dark_prismarine
fill 181 17 356 181 18 356 minecraft:dark_prismarine
fill 181 17 358 181 18 358 minecraft:dark_prismarine
fill 181 17 360 181 18 360 minecraft:dark_prismarine
fill 182 17 324 182 17 327 minecraft:blue_terracotta
fill 182 17 339 182 20 339 minecraft:blue_terracotta
setblock 182 17 343 minecraft:dark_prismarine
fill 182 17 344 182 20 344 minecraft:blue_terracotta
setblock 182 17 348 minecraft:dark_prismarine
fill 182 17 349 182 19 350 minecraft:blue_terracotta
setblock 182 17 351 minecraft:dark_prismarine
fill 182 17 353 182 18 353 minecraft:dark_prismarine
fill 182 17 355 182 18 355 minecraft:dark_prismarine
fill 182 17 357 182 18 357 minecraft:dark_prismarine
fill 182 17 359 182 18 359 minecraft:dark_prismarine
fill 182 17 361 182 18 361 minecraft:dark_prismarine
fill 142 18 323 142 21 323 minecraft:blue_terracotta
setblock 142 18 327 minecraft:dark_prismarine
fill 142 18 328 142 21 328 minecraft:blue_terracotta
setblock 142 18 332 minecraft:dark_prismarine
fill 142 18 333 142 20 334 minecraft:blue_terracotta
setblock 142 18 342 minecraft:dark_prismarine
fill 142 18 343 142 21 343 minecraft:blue_terracotta
setblock 142 18 347 minecraft:dark_prismarine
fill 142 18 348 142 20 349 minecraft:blue_terracotta
fill 142 18 353 142 19 353 minecraft:purple_concrete
setblock 143 18 326 minecraft:dark_prismarine
fill 143 18 327 143 21 327 minecraft:blue_terracotta
setblock 143 18 330 minecraft:blue_terracotta
setblock 143 18 331 minecraft:dark_prismarine
fill 143 18 334 144 20 334 minecraft:dark_prismarine
setblock 144 18 325 minecraft:dark_prismarine
fill 144 18 326 144 21 326 minecraft:blue_terracotta
fill 144 18 328 144 18 329 minecraft:blue_terracotta
setblock 145 18 324 minecraft:dark_prismarine
fill 145 18 325 145 21 325 minecraft:blue_terracotta
setblock 146 18 323 minecraft:dark_prismarine
fill 146 18 324 146 21 324 minecraft:blue_terracotta
fill 146 18 326 147 18 326 minecraft:blue_terracotta
setblock 146 18 363 minecraft:dark_prismarine
fill 146 18 364 146 131 364 minecraft:black_concrete
fill 147 18 323 147 21 323 minecraft:blue_terracotta
fill 147 18 363 147 21 363 minecraft:blue_terracotta
setblock 147 18 364 minecraft:light_blue_wool
setblock 148 18 326 minecraft:dark_prismarine
fill 148 18 362 151 18 362 minecraft:blue_terracotta
fill 148 18 364 148 131 364 minecraft:black_concrete
setblock 149 18 325 minecraft:dark_prismarine
fill 149 18 326 149 21 326 minecraft:blue_terracotta
setblock 150 18 324 minecraft:dark_prismarine
fill 150 18 325 150 21 325 minecraft:blue_terracotta
fill 150 18 352 150 27 352 minecraft:magenta_terracotta
setblock 151 18 323 minecraft:dark_prismarine
fill 151 18 324 151 21 324 minecraft:blue_terracotta
setblock 151 18 363 minecraft:dark_prismarine
fill 152 18 323 152 21 323 minecraft:blue_terracotta
fill 152 18 363 152 21 363 minecraft:blue_terracotta
setblock 155 18 324 minecraft:dark_prismarine
setblock 156 18 323 minecraft:dark_prismarine
fill 156 18 324 156 20 324 minecraft:blue_terracotta
setblock 156 18 363 minecraft:dark_prismarine
fill 157 18 323 160 18 323 minecraft:blue_terracotta
fill 157 18 363 157 21 363 minecraft:blue_terracotta
fill 160 18 330 160 33 330 minecraft:magenta_terracotta
setblock 161 18 323 minecraft:dark_prismarine
setblock 161 18 363 minecraft:dark_prismarine
fill 162 18 323 162 21 323 minecraft:blue_terracotta
fill 162 18 363 162 21 363 minecraft:blue_terracotta
fill 163 18 324 163 19 324 minecraft:blue_terracotta
setblock 165 18 323 minecraft:blue_terracotta
setblock 165 18 324 minecraft:dark_prismarine
setblock 166 18 323 minecraft:dark_prismarine
fill 166 18 324 166 21 324 minecraft:blue_terracotta
setblock 166 18 363 minecraft:dark_prismarine
fill 167 18 322 168 20 322 minecraft:black_concrete
fill 167 18 323 167 21 323 minecraft:blue_terracotta
setblock 167 18 362 minecraft:dark_prismarine
fill 167 18 363 167 21 363 minecraft:blue_terracotta
fill 168 18 362 168 21 362 minecraft:blue_terracotta
setblock 169 18 322 minecraft:cyan_concrete
setblock 170 18 324 minecraft:dark_prismarine
setblock 171 18 323 minecraft:dark_prismarine
setblock 171 18 363 minecraft:dark_prismarine
fill 172 18 323 172 21 323 minecraft:blue_terracotta
fill 172 18 363 172 19 363 minecraft:blue_terracotta
setblock 176 18 363 minecraft:purple_concrete
setblock 181 18 343 minecraft:dark_prismarine
fill 181 18 344 181 21 344 minecraft:blue_terracotta
setblock 181 18 348 minecraft:dark_prismarine
fill 182 18 323 182 18 326 minecraft:blue_terracotta
setblock 182 18 327 minecraft:dark_prismarine
fill 182 18 328 182 19 330 minecraft:blue_terracotta
setblock 182 18 333 minecraft:purple_concrete
fill 182 18 338 182 21 338 minecraft:blue_terracotta
setblock 182 18 342 minecraft:dark_prismarine
fill 182 18 343 182 21 343 minecraft:blue_terracotta
setblock 182 18 347 minecraft:dark_prismarine
fill 182 18 348 182 21 348 minecraft:blue_terracotta
setblock 182 18 351 minecraft:blue_terracotta
setblock 182 18 358 minecraft:purple_concrete
setblock 142 19 326 minecraft:dark_prismarine
fill 142 19 327 142 22 327 minecraft:blue_terracotta
setblock 142 19 331 minecraft:dark_prismarine
fill 142 19 332 143 21 332 minecraft:blue_terracotta
setblock 142 19 335 minecraft:blue_terracotta
fill 142 19 337 142 20 339 minecraft:blue_terracotta
setblock 142 19 341 minecraft:dark_prismarine
fill 142 19 342 142 22 342 minecraft:blue_terracotta
setblock 142 19 346 minecraft:dark_prismarine
fill 142 19 347 143 21 347 minecraft:blue_terracotta
setblock 142 19 350 minecraft:blue_terracotta
setblock 142 19 359 minecraft:purple_concrete
setblock 143 19 325 minecraft:dark_prismarine
fill 143 19 326 143 22 326 minecraft:blue_terracotta
setblock 143 19 330 minecraft:dark_prismarine
fill 143 19 331 143 22 331 minecraft:blue_terracotta
fill 143 19 333 143 20 333 minecraft:blue_terracotta
setblock 143 19 344 minecraft:blue_terracotta
fill 143 19 345 146 19 345 minecraft:dark_prismarine
fill 143 19 346 143 22 346 minecraft:blue_terracotta
fill 143 19 363 143 20 363 minecraft:blue_terracotta
setblock 144 19 324 minecraft:dark_prismarine
fill 144 19 325 144 22 325 minecraft:blue_terracotta
setblock 144 19 328 minecraft:blue_terracotta
setblock 144 19 329 minecraft:dark_prismarine
fill 144 19 330 144 22 330 minecraft:blue_terracotta
fill 144 19 336 144 28 336 minecraft:dark_prismarine
fill 144 19 346 146 28 346 minecraft:dark_prismarine
setblock 145 19 323 minecraft:dark_prismarine
fill 145 19 324 145 22 324 minecraft:blue_terracotta
fill 145 19 326 145 19 327 minecraft:blue_terracotta
setblock 145 19 328 minecraft:dark_prismarine
fill 145 19 336 145 33 336 minecraft:magenta_terracotta
setblock 145 19 363 minecraft:dark_prismarine
fill 146 19 323 146 22 323 minecraft:blue_terracotta
setblock 146 19 326 minecraft:blue_terracotta
fill 146 19 363 146 22 363 minecraft:blue_terracotta
setblock 147 19 326 minecraft:dark_prismarine
fill 147 19 362 150 19 362 minecraft:blue_terracotta
fill 147 19 364 147 114 364 minecraft:black_concrete
setblock 148 19 325 minecraft:dark_prismarine
fill 148 19 326 148 22 326 minecraft:blue_terracotta
setblock 149 19 324 minecraft:dark_prismarine
fill 149 19 325 149 22 325 minecraft:blue_terracotta
setblock 150 19 323 minecraft:dark_prismarine
fill 150 19 324 150 22 324 minecraft:blue_terracotta
setblock 150 19 363 minecraft:dark_prismarine
fill 151 19 323 151 22 323 minecraft:blue_terracotta
setblock 151 19 362 minecraft:dark_prismarine
fill 151 19 363 151 22 363 minecraft:blue_terracotta
setblock 153 19 325 minecraft:dark_prismarine
setblock 154 19 324 minecraft:dark_prismarine
setblock 155 19 323 minecraft:dark_prismarine
fill 155 19 324 155 22 324 minecraft:blue_terracotta
setblock 155 19 363 minecraft:dark_prismarine
fill 156 19 323 159 19 323 minecraft:blue_terracotta
fill 156 19 363 156 22 363 minecraft:blue_terracotta
setblock 160 19 323 minecraft:dark_prismarine
setblock 160 19 363 minecraft:dark_prismarine
fill 161 19 323 161 22 323 minecraft:blue_terracotta
fill 161 19 363 161 22 363 minecraft:blue_terracotta
fill 162 19 324 162 20 324 minecraft:blue_terracotta
fill 163 19 362 163 21 362 minecraft:blue_terracotta
setblock 164 19 324 minecraft:dark_prismarine
setblock 165 19 323 minecraft:dark_prismarine
fill 165 19 324 165 22 324 minecraft:blue_terracotta
setblock 165 19 363 minecraft:dark_prismarine
fill 166 19 323 166 22 323 minecraft:blue_terracotta
setblock 166 19 362 minecraft:dark_prismarine
fill 166 19 363 166 22 363 minecraft:blue_terracotta
fill 167 19 362 167 22 362 minecraft:blue_terracotta
fill 169 19 322 169 72 322 minecraft:black_concrete
setblock 169 19 324 minecraft:dark_prismarine
setblock 170 19 323 minecraft:dark_prismarine
fill 170 19 324 170 21 324 minecraft:blue_terracotta
setblock 170 19 363 minecraft:dark_prismarine
fill 171 19 323 171 22 323 minecraft:blue_terracotta
fill 171 19 363 171 21 363 minecraft:blue_terracotta
setblock 174 19 351 minecraft:sea_lantern
setblock 174 19 353 minecraft:sea_lantern
setblock 174 19 355 minecraft:sea_lantern
setblock 174 19 357 minecraft:sea_lantern
setblock 174 19 359 minecraft:sea_lantern
setblock 174 19 361 minecraft:sea_lantern
setblock 175 19 352 minecraft:sea_lantern
setblock 175 19 354 minecraft:sea_lantern
setblock 175 19 356 minecraft:sea_lantern
setblock 175 19 358 minecraft:sea_lantern
setblock 175 19 360 minecraft:sea_lantern
setblock 176 19 351 minecraft:sea_lantern
setblock 176 19 353 minecraft:sea_lantern
setblock 176 19 355 minecraft:sea_lantern
setblock 176 19 357 minecraft:sea_lantern
setblock 176 19 359 minecraft:sea_lantern
setblock 176 19 361 minecraft:sea_lantern
setblock 177 19 352 minecraft:sea_lantern
setblock 177 19 354 minecraft:sea_lantern
setblock 177 19 356 minecraft:sea_lantern
setblock 177 19 358 minecraft:sea_lantern
setblock 177 19 360 minecraft:sea_lantern
setblock 178 19 351 minecraft:sea_lantern
setblock 178 19 353 minecraft:sea_lantern
setblock 178 19 355 minecraft:sea_lantern
setblock 178 19 357 minecraft:sea_lantern
setblock 178 19 359 minecraft:sea_lantern
setblock 178 19 361 minecraft:sea_lantern
setblock 179 19 352 minecraft:sea_lantern
setblock 179 19 354 minecraft:sea_lantern
setblock 179 19 356 minecraft:sea_lantern
setblock 179 19 358 minecraft:sea_lantern
setblock 179 19 360 minecraft:sea_lantern
setblock 180 19 351 minecraft:sea_lantern
setblock 180 19 353 minecraft:sea_lantern
setblock 180 19 355 minecraft:sea_lantern
setblock 180 19 357 minecraft:sea_lantern
setblock 180 19 359 minecraft:sea_lantern
setblock 180 19 361 minecraft:sea_lantern
fill 181 19 323 182 21 323 minecraft:blue_terracotta
setblock 181 19 342 minecraft:dark_prismarine
fill 181 19 343 181 22 343 minecraft:blue_terracotta
setblock 181 19 347 minecraft:dark_prismarine
fill 181 19 348 181 21 349 minecraft:blue_terracotta
setblock 181 19 352 minecraft:sea_lantern
setblock 181 19 354 minecraft:sea_lantern
setblock 181 19 356 minecraft:sea_lantern
setblock 181 19 358 minecraft:sea_lantern
setblock 181 19 360 minecraft:sea_lantern
fill 182 19 324 182 19 325 minecraft:blue_terracotta
setblock 182 19 326 minecraft:dark_prismarine
fill 182 19 327 182 22 327 minecraft:blue_terracotta
setblock 182 19 331 minecraft:dark_prismarine
fill 182 19 332 182 19 335 minecraft:blue_terracotta
setblock 182 19 336 minecraft:dark_prismarine
fill 182 19 337 182 22 337 minecraft:blue_terracotta
setblock 182 19 341 minecraft:dark_prismarine
fill 182 19 342 182 22 342 minecraft:blue_terracotta
setblock 182 19 346 minecraft:dark_prismarine
fill 182 19 347 182 22 347 minecraft:blue_terracotta
setblock 182 19 351 minecraft:sea_lantern
fill 182 19 352 182 22 352 minecraft:blue_terracotta
setblock 182 19 353 minecraft:sea_lantern
setblock 182 19 355 minecraft:sea_lantern
setblock 182 19 357 minecraft:sea_lantern
fill 182 19 358 182 23 358 minecraft:dark_prismarine
setblock 182 19 359 minecraft:sea_lantern
setblock 182 19 361 minecraft:sea_lantern
setblock 182 19 363 minecraft:purple_concrete
setblock 142 20 325 minecraft:dark_prismarine
fill 142 20 326 142 23 326 minecraft:blue_terracotta
setblock 142 20 329 minecraft:blue_terracotta
setblock 142 20 330 minecraft:dark_prismarine
fill 142 20 331 142 23 331 minecraft:blue_terracotta
setblock 142 20 335 minecraft:dark_prismarine
fill 142 20 336 142 23 336 minecraft:blue_terracotta
setblock 142 20 340 minecraft:dark_prismarine
fill 142 20 341 142 23 341 minecraft:blue_terracotta
setblock 142 20 345 minecraft:dark_prismarine
fill 142 20 346 142 23 346 minecraft:blue_terracotta
setblock 142 20 350 minecraft:dark_prismarine
fill 142 20 351 142 22 352 minecraft:blue_terracotta
setblock 143 20 324 minecraft:dark_prismarine
fill 143 20 325 143 23 325 minecraft:blue_terracotta
setblock 143 20 329 minecraft:dark_prismarine
fill 143 20 330 143 23 330 minecraft:blue_terracotta
setblock 143 20 344 minecraft:dark_prismarine
fill 143 20 345 143 23 345 minecraft:blue_terracotta
setblock 143 20 348 minecraft:blue_terracotta
setblock 143 20 349 minecraft:dark_prismarine
setblock 144 20 323 minecraft:dark_prismarine
fill 144 20 324 144 23 324 minecraft:blue_terracotta
setblock 144 20 328 minecraft:dark_prismarine
fill 144 20 329 145 22 329 minecraft:blue_terracotta
fill 144 20 331 144 20 332 minecraft:blue_terracotta
fill 144 20 335 144 23 335 minecraft:dark_prismarine
fill 144 20 345 146 28 345 minecraft:dark_prismarine
setblock 144 20 363 minecraft:dark_prismarine
fill 145 20 323 145 23 323 minecraft:blue_terracotta
setblock 145 20 326 minecraft:blue_terracotta
setblock 145 20 327 minecraft:dark_prismarine
fill 145 20 328 145 23 328 minecraft:blue_terracotta
fill 145 20 330 145 21 330 minecraft:blue_terracotta
fill 145 20 363 145 23 363 minecraft:blue_terracotta
setblock 146 20 326 minecraft:dark_prismarine
fill 146 20 362 149 20 362 minecraft:blue_terracotta
setblock 147 20 325 minecraft:dark_prismarine
fill 147 20 326 147 23 326 minecraft:blue_terracotta
fill 147 20 350 147 33 350 minecraft:magenta_terracotta
setblock 148 20 324 minecraft:dark_prismarine
fill 148 20 325 148 23 325 minecraft:blue_terracotta
fill 148 20 348 148 25 348 minecraft:dark_prismarine
setblock 149 20 323 minecraft:dark_prismarine
fill 149 20 324 149 23 324 minecraft:blue_terracotta
fill 149 20 348 149 33 348 minecraft:magenta_terracotta
setblock 149 20 363 minecraft:dark_prismarine
fill 150 20 323 150 23 323 minecraft:blue_terracotta
setblock 150 20 362 minecraft:dark_prismarine
fill 150 20 363 150 23 363 minecraft:blue_terracotta
setblock 152 20 325 minecraft:dark_prismarine
setblock 153 20 324 minecraft:dark_prismarine
setblock 153 20 325 minecraft:blue_terracotta
setblock 154 20 323 minecraft:dark_prismarine
fill 154 20 324 154 23 324 minecraft:blue_terracotta
setblock 154 20 363 minecraft:dark_prismarine
fill 155 20 323 158 20 323 minecraft:blue_terracotta
fill 155 20 363 155 23 363 minecraft:blue_terracotta
setblock 159 20 323 minecraft:dark_prismarine
setblock 159 20 363 minecraft:dark_prismarine
fill 160 20 323 160 23 323 minecraft:blue_terracotta
fill 160 20 363 160 23 363 minecraft:blue_terracotta
fill 161 20 324 161 21 324 minecraft:blue_terracotta
fill 161 20 329 161 33 329 minecraft:magenta_terracotta
fill 162 20 362 162 22 362 minecraft:blue_terracotta
setblock 163 20 324 minecraft:dark_prismarine
setblock 164 20 323 minecraft:dark_prismarine
fill 164 20 324 164 23 324 minecraft:blue_terracotta
setblock 164 20 363 minecraft:dark_prismarine
fill 165 20 323 165 23 323 minecraft:blue_terracotta
fill 165 20 359 165 33 359 minecraft:magenta_terracotta
setblock 165 20 362 minecraft:dark_prismarine
fill 165 20 363 165 23 363 minecraft:blue_terracotta
fill 166 20 362 166 23 362 minecraft:blue_terracotta
setblock 168 20 324 minecraft:dark_prismarine
setblock 169 20 323 minecraft:dark_prismarine
fill 169 20 324 169 22 324 minecraft:blue_terracotta
setblock 169 20 363 minecraft:dark_prismarine
fill 170 20 323 170 23 323 minecraft:blue_terracotta
fill 170 20 363 170 23 363 minecraft:blue_terracotta
fill 174 20 334 174 28 334 minecraft:magenta_terracotta
fill 174 20 351 174 21 351 minecraft:dark_prismarine
fill 174 20 353 174 21 353 minecraft:dark_prismarine
fill 174 20 355 174 21 355 minecraft:dark_prismarine
fill 174 20 357 174 21 357 minecraft:dark_prismarine
fill 174 20 359 174 21 359 minecraft:dark_prismarine
fill 174 20 361 174 21 361 minecraft:dark_prismarine
fill 175 20 352 175 21 352 minecraft:dark_prismarine
fill 175 20 354 175 21 354 minecraft:dark_prismarine
fill 175 20 356 175 21 356 minecraft:dark_prismarine
fill 175 20 358 175 21 358 minecraft:dark_prismarine
fill 175 20 360 175 21 360 minecraft:dark_prismarine
fill 176 20 351 176 21 351 minecraft:magenta_terracotta
fill 176 20 353 176 21 353 minecraft:dark_prismarine
fill 176 20 355 176 21 355 minecraft:dark_prismarine
fill 176 20 357 176 21 357 minecraft:dark_prismarine
fill 176 20 359 176 21 359 minecraft:dark_prismarine
fill 176 20 361 176 21 361 minecraft:dark_prismarine
fill 177 20 352 177 21 352 minecraft:magenta_terracotta
fill 177 20 354 177 21 354 minecraft:dark_prismarine
fill 177 20 356 177 21 356 minecraft:dark_prismarine
fill 177 20 358 177 21 358 minecraft:dark_prismarine
fill 177 20 360 177 21 360 minecraft:dark_prismarine
fill 178 20 351 178 21 351 minecraft:magenta_terracotta
fill 178 20 353 178 21 353 minecraft:dark_prismarine
fill 178 20 355 178 21 355 minecraft:dark_prismarine
fill 178 20 357 178 21 357 minecraft:dark_prismarine
fill 178 20 359 178 21 359 minecraft:dark_prismarine
fill 178 20 361 178 21 361 minecraft:dark_prismarine
fill 179 20 352 179 21 352 minecraft:magenta_terracotta
fill 179 20 354 179 21 354 minecraft:dark_prismarine
fill 179 20 356 179 21 356 minecraft:dark_prismarine
fill 179 20 358 179 21 358 minecraft:dark_prismarine
fill 179 20 360 179 21 360 minecraft:dark_prismarine
setblock 180 20 323 minecraft:purple_concrete
fill 180 20 351 180 21 351 minecraft:magenta_terracotta
fill 180 20 353 180 21 353 minecraft:dark_prismarine
fill 180 20 355 180 21 355 minecraft:dark_prismarine
fill 180 20 357 180 21 357 minecraft:dark_prismarine
fill 180 20 359 180 21 359 minecraft:dark_prismarine
fill 180 20 361 180 21 361 minecraft:dark_prismarine
setblock 181 20 326 minecraft:dark_prismarine
fill 181 20 327 181 20 330 minecraft:blue_terracotta
fill 181 20 342 181 23 342 minecraft:blue_terracotta
setblock 181 20 346 minecraft:dark_prismarine
fill 181 20 347 181 23 347 minecraft:blue_terracotta
setblock 181 20 350 minecraft:blue_terracotta
setblock 181 20 352 minecraft:dark_prismarine
fill 181 20 354 181 21 354 minecraft:dark_prismarine
fill 181 20 356 181 21 356 minecraft:dark_prismarine
fill 181 20 358 181 21 358 minecraft:dark_prismarine
fill 181 20 360 181 21 360 minecraft:dark_prismarine
setblock 182 20 324 minecraft:blue_terracotta
setblock 182 20 325 minecraft:dark_prismarine
fill 182 20 326 182 23 326 minecraft:blue_terracotta
fill 182 20 328 182 20 329 minecraft:blue_terracotta
setblock 182 20 330 minecraft:dark_prismarine
fill 182 20 331 182 20 334 minecraft:blue_terracotta
setblock 182 20 335 minecraft:dark_prismarine
fill 182 20 336 182 23 336 minecraft:blue_terracotta
setblock 182 20 340 minecraft:dark_prismarine
fill 182 20 341 182 23 341 minecraft:blue_terracotta
setblock 182 20 345 minecraft:dark_prismarine
fill 182 20 346 182 23 346 minecraft:blue_terracotta
setblock 182 20 349 minecraft:blue_terracotta
setblock 182 20 350 minecraft:dark_prismarine
fill 182 20 351 182 21 351 minecraft:blue_terracotta
fill 182 20 353 182 21 353 minecraft:blue_terracotta
fill 182 20 355 182 21 355 minecraft:dark_prismarine
fill 182 20 357 182 21 357 minecraft:dark_prismarine
setblock 182 20 359 minecraft:dark_prismarine
fill 182 20 361 182 21 361 minecraft:dark_prismarine
fill 183 20 331 183 131 331 minecraft:black_concrete
setblock 183 20 332 minecraft:cyan_concrete
setblock 183 20 333 minecraft:black_concrete
setblock 142 21 324 minecraft:dark_prismarine
fill 142 21 325 142 24 325 minecraft:blue_terracotta
setblock 142 21 329 minecraft:dark_prismarine
fill 142 21 330 142 24 330 minecraft:blue_terracotta
setblock 142 21 333 minecraft:blue_terracotta
setblock 142 21 334 minecraft:dark_prismarine
fill 142 21 335 143 23 335 minecraft:blue_terracotta
fill 142 21 337 142 21 338 minecraft:blue_terracotta
setblock 142 21 339 minecraft:dark_prismarine
fill 142 21 340 142 24 340 minecraft:blue_terracotta
setblock 142 21 344 minecraft:dark_prismarine
fill 142 21 345 142 24 345 minecraft:blue_terracotta
setblock 142 21 348 minecraft:blue_terracotta
setblock 142 21 349 minecraft:dark_prismarine
fill 142 21 350 143 23 350 minecraft:blue_terracotta
setblock 142 21 353 minecraft:blue_terracotta
setblock 142 21 354 minecraft:dark_prismarine
setblock 142 21 363 minecraft:blue_terracotta
setblock 143 21 323 minecraft:dark_prismarine
fill 143 21 324 143 24 324 minecraft:blue_terracotta
setblock 143 21 328 minecraft:dark_prismarine
fill 143 21 329 143 24 329 minecraft:blue_terracotta
setblock 143 21 333 minecraft:dark_prismarine
fill 143 21 334 143 24 334 minecraft:blue_terracotta
fill 143 21 336 143 22 336 minecraft:blue_terracotta
fill 143 21 337 143 22 337 minecraft:dark_prismarine
fill 143 21 344 143 23 344 minecraft:blue_terracotta
setblock 143 21 348 minecraft:dark_prismarine
fill 143 21 349 143 24 349 minecraft:blue_terracotta
fill 143 21 351 143 22 351 minecraft:blue_terracotta
setblock 143 21 363 minecraft:dark_prismarine
fill 144 21 323 144 24 323 minecraft:blue_terracotta
setblock 144 21 327 minecraft:dark_prismarine
fill 144 21 328 144 24 328 minecraft:blue_terracotta
setblock 144 21 331 minecraft:blue_terracotta
setblock 144 21 332 minecraft:dark_prismarine
fill 144 21 333 144 24 333 minecraft:blue_terracotta
setblock 144 21 334 minecraft:dark_prismarine
setblock 144 21 349 minecraft:light[level=13]
setblock 144 21 357 minecraft:light[level=13]
fill 144 21 363 144 24 363 minecraft:blue_terracotta
setblock 145 21 326 minecraft:dark_prismarine
fill 145 21 327 147 22 327 minecraft:blue_terracotta
setblock 145 21 331 minecraft:dark_prismarine
fill 145 21 362 148 21 362 minecraft:blue_terracotta
setblock 146 21 325 minecraft:dark_prismarine
fill 146 21 326 146 24 326 minecraft:blue_terracotta
fill 146 21 328 146 22 328 minecraft:blue_terracotta
setblock 147 21 324 minecraft:dark_prismarine
fill 147 21 325 147 24 325 minecraft:blue_terracotta
setblock 148 21 323 minecraft:dark_prismarine
fill 148 21 324 148 24 324 minecraft:blue_terracotta
setblock 148 21 363 minecraft:dark_prismarine
fill 149 21 323 149 24 323 minecraft:blue_terracotta
setblock 149 21 362 minecraft:dark_prismarine
fill 149 21 363 149 24 363 minecraft:blue_terracotta
setblock 150 21 326 minecraft:dark_prismarine
fill 150 21 362 150 22 362 minecraft:blue_terracotta
setblock 151 21 325 minecraft:dark_prismarine
setblock 152 21 324 minecraft:dark_prismarine
fill 152 21 325 152 22 325 minecraft:blue_terracotta
setblock 152 21 333 minecraft:light[level=13]
setblock 152 21 341 minecraft:light[level=13]
setblock 152 21 349 minecraft:light[level=13]
setblock 152 21 357 minecraft:light[level=13]
setblock 153 21 323 minecraft:dark_prismarine
fill 153 21 324 153 23 324 minecraft:blue_terracotta
setblock 153 21 363 minecraft:dark_prismarine
fill 154 21 323 157 21 323 minecraft:blue_terracotta
fill 154 21 363 154 24 363 minecraft:blue_terracotta
setblock 158 21 323 minecraft:dark_prismarine
setblock 158 21 363 minecraft:dark_prismarine
fill 159 21 323 159 24 323 minecraft:blue_terracotta
fill 159 21 363 159 24 363 minecraft:blue_terracotta
fill 160 21 324 160 22 324 minecraft:blue_terracotta
setblock 160 21 325 minecraft:light[level=13]
setblock 160 21 333 minecraft:light[level=13]
setblock 160 21 341 minecraft:light[level=13]
setblock 160 21 349 minecraft:light[level=13]
setblock 160 21 357 minecraft:light[level=13]
setblock 162 21 324 minecraft:dark_prismarine
setblock 163 21 323 minecraft:dark_prismarine
fill 163 21 324 163 24 324 minecraft:blue_terracotta
setblock 163 21 363 minecraft:dark_prismarine
fill 164 21 323 164 24 323 minecraft:blue_terracotta
setblock 164 21 362 minecraft:dark_prismarine
fill 164 21 363 164 24 363 minecraft:blue_terracotta
fill 165 21 362 165 24 362 minecraft:blue_terracotta
setblock 167 21 322 minecraft:light_blue_wool
setblock 167 21 324 minecraft:dark_prismarine
fill 168 21 322 168 131 322 minecraft:black_concrete
setblock 168 21 323 minecraft:dark_prismarine
fill 168 21 324 168 23 324 minecraft:blue_terracotta
setblock 168 21 325 minecraft:light[level=13]
setblock 168 21 333 minecraft:light[level=13]
setblock 168 21 341 minecraft:light[level=13]
setblock 168 21 349 minecraft:light[level=13]
setblock 168 21 357 minecraft:light[level=13]
setblock 168 21 363 minecraft:dark_prismarine
fill 169 21 323 169 24 323 minecraft:blue_terracotta
fill 169 21 363 169 24 363 minecraft:blue_terracotta
setblock 174 21 323 minecraft:purple_concrete
fill 175 21 338 175 33 338 minecraft:magenta_terracotta
setblock 176 21 325 minecraft:light[level=13]
setblock 176 21 333 minecraft:light[level=13]
setblock 176 21 341 minecraft:light[level=13]
fill 176 21 349 176 33 349 minecraft:magenta_terracotta
fill 180 21 323 180 23 323 minecraft:blue_terracotta
setblock 181 21 324 minecraft:blue_terracotta
setblock 181 21 325 minecraft:dark_prismarine
fill 181 21 326 181 21 329 minecraft:blue_terracotta
setblock 181 21 330 minecraft:dark_prismarine
fill 181 21 331 181 21 334 minecraft:blue_terracotta
fill 181 21 341 181 24 341 minecraft:blue_terracotta
setblock 181 21 345 minecraft:dark_prismarine
fill 181 21 346 181 24 346 minecraft:blue_terracotta
setblock 181 21 350 minecraft:dark_prismarine
fill 181 21 351 181 21 352 minecraft:blue_terracotta
setblock 182 21 324 minecraft:dark_prismarine
fill 182 21 325 182 24 325 minecraft:blue_terracotta
setblock 182 21 328 minecraft:blue_terracotta
setblock 182 21 329 minecraft:dark_prismarine
fill 182 21 330 182 21 333 minecraft:blue_terracotta
setblock 182 21 334 minecraft:dark_prismarine
fill 182 21 335 182 24 335 minecraft:blue_terracotta
setblock 182 21 339 minecraft:dark_prismarine
fill 182 21 340 182 24 340 minecraft:blue_terracotta
setblock 182 21 344 minecraft:dark_prismarine
fill 182 21 345 182 24 345 minecraft:blue_terracotta
setblock 182 21 349 minecraft:dark_prismarine
fill 182 21 350 182 24 350 minecraft:blue_terracotta
setblock 182 21 359 minecraft:purple_concrete
fill 183 21 332 183 131 332 minecraft:black_concrete
setblock 183 21 333 minecraft:cyan_concrete
setblock 183 21 346 minecraft:cyan_concrete
fill 183 21 347 183 131 350 minecraft:black_concrete
setblock 142 22 323 minecraft:dark_prismarine
fill 142 22 324 142 25 324 minecraft:blue_terracotta
schedule function dropper:buildpart/75_3 1t
