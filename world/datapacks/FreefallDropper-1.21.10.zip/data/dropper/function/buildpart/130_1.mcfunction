setblock 498 221 552 minecraft:white_concrete
fill 499 221 529 499 222 529 minecraft:white_concrete
fill 499 221 552 501 223 552 minecraft:light_blue_concrete
fill 501 221 529 501 221 530 minecraft:white_concrete
fill 502 221 528 502 222 529 minecraft:white_concrete
fill 504 221 529 509 221 529 minecraft:white_concrete
fill 505 221 510 505 223 510 minecraft:light_blue_concrete
fill 507 221 528 510 221 528 minecraft:white_concrete
fill 508 221 552 508 223 552 minecraft:light_blue_concrete
setblock 509 221 552 minecraft:white_concrete
fill 512 221 511 512 223 511 minecraft:light_blue_concrete
fill 512 221 514 512 221 515 minecraft:light_blue_concrete
fill 512 221 517 512 225 517 minecraft:light_blue_concrete
setblock 512 221 520 minecraft:white_concrete
setblock 512 221 525 minecraft:light_blue_concrete
setblock 512 221 529 minecraft:white_concrete
fill 512 221 530 512 221 533 minecraft:light_blue_concrete
setblock 512 221 534 minecraft:white_concrete
fill 512 221 538 512 223 538 minecraft:light_blue_concrete
fill 470 222 520 470 222 521 minecraft:white_concrete
setblock 470 222 524 minecraft:white_concrete
setblock 470 222 532 minecraft:white_concrete
setblock 470 222 534 minecraft:white_concrete
fill 470 222 537 470 223 537 minecraft:light_blue_concrete
setblock 470 222 538 minecraft:white_concrete
fill 470 222 539 470 223 540 minecraft:light_blue_concrete
fill 470 222 544 470 223 545 minecraft:light_blue_concrete
fill 471 222 510 471 223 510 minecraft:light_blue_concrete
fill 471 222 528 474 222 528 minecraft:white_concrete
fill 472 222 529 474 222 529 minecraft:white_concrete
fill 474 222 552 475 223 552 minecraft:light_blue_concrete
setblock 476 222 552 minecraft:white_concrete
fill 477 222 552 479 223 552 minecraft:light_blue_concrete
fill 478 222 510 479 222 510 minecraft:white_concrete
fill 478 222 528 479 223 528 minecraft:white_concrete
setblock 479 222 529 minecraft:white_concrete
setblock 481 222 510 minecraft:white_concrete
fill 481 222 528 481 223 529 minecraft:white_concrete
fill 482 222 528 482 223 528 minecraft:white_concrete
fill 482 222 530 483 222 530 minecraft:white_concrete
fill 484 222 552 484 223 552 minecraft:light_blue_concrete
setblock 486 222 510 minecraft:white_concrete
fill 487 222 552 487 223 552 minecraft:light_blue_concrete
fill 490 222 552 491 223 552 minecraft:light_blue_concrete
setblock 492 222 552 minecraft:white_concrete
fill 493 222 552 493 223 552 minecraft:light_blue_concrete
fill 498 222 552 498 223 552 minecraft:light_blue_concrete
fill 499 222 530 500 222 530 minecraft:white_concrete
fill 500 222 528 501 223 528 minecraft:white_concrete
fill 501 222 529 501 223 529 minecraft:white_concrete
fill 503 222 510 503 223 510 minecraft:light_blue_concrete
fill 503 222 528 503 222 529 minecraft:white_concrete
fill 504 222 528 504 223 528 minecraft:white_concrete
setblock 504 222 552 minecraft:white_concrete
fill 507 222 537 507 223 537 minecraft:gold_block
fill 508 222 528 510 222 529 minecraft:white_concrete
fill 509 222 552 509 223 552 minecraft:light_blue_concrete
setblock 511 222 528 minecraft:white_concrete
setblock 512 222 514 minecraft:white_concrete
fill 512 222 515 512 224 515 minecraft:light_blue_concrete
fill 512 222 520 512 223 520 minecraft:light_blue_concrete
setblock 512 222 525 minecraft:white_concrete
fill 512 222 529 512 223 530 minecraft:light_blue_concrete
setblock 512 222 531 minecraft:white_concrete
fill 512 222 532 512 223 534 minecraft:light_blue_concrete
fill 512 222 539 512 223 540 minecraft:light_blue_concrete
setblock 512 222 541 minecraft:white_concrete
fill 512 222 544 512 223 545 minecraft:light_blue_concrete
setblock 512 222 546 minecraft:white_concrete
setblock 470 223 513 minecraft:light_blue_concrete
fill 470 223 520 470 223 521 minecraft:light_blue_concrete
setblock 470 223 524 minecraft:light_blue_concrete
setblock 470 223 532 minecraft:light_blue_concrete
setblock 470 223 534 minecraft:light_blue_concrete
setblock 470 223 538 minecraft:light_blue_concrete
setblock 470 223 542 minecraft:light_blue_concrete
setblock 476 223 510 minecraft:light_blue_concrete
fill 476 223 527 478 224 527 minecraft:white_concrete
setblock 476 223 552 minecraft:light_blue_concrete
setblock 477 223 528 minecraft:white_concrete
fill 478 223 510 479 223 510 minecraft:light_blue_concrete
fill 480 223 527 480 224 528 minecraft:white_concrete
setblock 481 223 510 minecraft:light_blue_concrete
setblock 486 223 510 minecraft:light_blue_concrete
setblock 492 223 552 minecraft:light_blue_concrete
fill 502 223 527 502 224 528 minecraft:white_concrete
fill 503 223 528 503 224 528 minecraft:white_concrete
fill 504 223 527 506 224 527 minecraft:white_concrete
setblock 504 223 552 minecraft:light_blue_concrete
setblock 505 223 528 minecraft:white_concrete
setblock 512 223 514 minecraft:light_blue_concrete
setblock 512 223 525 minecraft:light_blue_concrete
setblock 512 223 531 minecraft:light_blue_concrete
setblock 512 223 541 minecraft:light_blue_concrete
fill 512 223 546 512 224 546 minecraft:light_blue_concrete
fill 470 224 510 470 224 550 minecraft:white_concrete
setblock 470 224 551 minecraft:light_blue_concrete
fill 470 224 552 502 224 552 minecraft:white_concrete
fill 471 224 510 489 224 510 minecraft:white_concrete
fill 474 224 526 475 225 527 minecraft:white_concrete
setblock 476 224 526 minecraft:white_concrete
fill 479 224 527 479 224 528 minecraft:white_concrete
setblock 481 224 528 minecraft:white_concrete
setblock 490 224 510 minecraft:light_blue_concrete
fill 491 224 510 499 225 510 minecraft:white_concrete
fill 491 224 515 492 225 516 minecraft:white_wool
fill 501 224 510 507 224 510 minecraft:white_concrete
setblock 501 224 528 minecraft:white_concrete
fill 503 224 527 503 225 527 minecraft:white_concrete
fill 503 224 552 503 225 552 minecraft:light_blue_concrete
fill 504 224 552 512 225 552 minecraft:white_concrete
fill 506 224 526 508 224 526 minecraft:white_concrete
fill 507 224 527 508 225 527 minecraft:white_concrete
fill 508 224 510 508 225 510 minecraft:light_blue_concrete
fill 509 224 510 512 307 510 minecraft:white_concrete
fill 512 224 511 512 225 514 minecraft:white_concrete
fill 512 224 516 512 307 516 minecraft:white_concrete
fill 512 224 518 512 307 518 minecraft:white_concrete
setblock 512 224 519 minecraft:light_blue_concrete
fill 512 224 520 512 224 526 minecraft:white_concrete
fill 512 224 528 512 225 533 minecraft:white_concrete
setblock 512 224 534 minecraft:light_blue_concrete
fill 512 224 535 512 225 535 minecraft:white_concrete
fill 512 224 536 512 225 536 minecraft:light_blue_concrete
fill 512 224 537 512 224 545 minecraft:white_concrete
fill 512 224 547 512 225 551 minecraft:white_concrete
fill 470 225 510 470 225 519 minecraft:white_concrete
fill 470 225 520 470 225 523 minecraft:light_blue_concrete
fill 470 225 524 470 225 551 minecraft:white_concrete
setblock 470 225 552 minecraft:light_blue_concrete
fill 471 225 510 475 307 510 minecraft:white_concrete
fill 471 225 514 471 225 519 minecraft:smooth_quartz
fill 471 225 526 471 225 531 minecraft:smooth_quartz
fill 471 225 538 471 225 543 minecraft:smooth_quartz
fill 471 225 550 471 225 551 minecraft:smooth_quartz
setblock 471 225 552 minecraft:white_concrete
fill 472 225 525 473 226 526 minecraft:white_concrete
fill 472 225 551 475 225 551 minecraft:smooth_quartz
setblock 472 225 552 minecraft:light_blue_concrete
fill 473 225 552 474 225 552 minecraft:white_concrete
fill 475 225 511 480 225 511 minecraft:smooth_quartz
setblock 475 225 552 minecraft:light_blue_concrete
fill 476 225 510 478 225 510 minecraft:light_blue_concrete
fill 476 225 552 487 225 552 minecraft:white_concrete
fill 477 225 526 479 225 526 minecraft:white_concrete
fill 478 225 527 479 225 527 minecraft:white_concrete
fill 479 225 510 484 225 510 minecraft:white_concrete
fill 482 225 551 487 225 551 minecraft:smooth_quartz
fill 485 225 510 485 226 510 minecraft:light_blue_concrete
fill 486 225 510 490 225 510 minecraft:white_concrete
fill 487 225 511 492 225 511 minecraft:smooth_quartz
setblock 488 225 552 minecraft:light_blue_concrete
fill 489 225 552 502 225 552 minecraft:white_concrete
fill 494 225 551 499 225 551 minecraft:smooth_quartz
fill 499 225 511 504 225 511 minecraft:smooth_quartz
fill 500 225 510 500 307 510 minecraft:white_concrete
setblock 501 225 510 minecraft:light_blue_concrete
fill 502 225 510 507 225 510 minecraft:white_concrete
fill 503 225 526 505 225 526 minecraft:white_concrete
setblock 504 225 527 minecraft:white_concrete
fill 506 225 551 511 225 551 minecraft:smooth_quartz
fill 507 225 526 510 225 526 minecraft:white_concrete
fill 509 225 525 510 226 525 minecraft:white_concrete
fill 511 225 511 511 225 516 minecraft:smooth_quartz
fill 511 225 523 511 225 528 minecraft:smooth_quartz
fill 511 225 535 511 225 540 minecraft:smooth_quartz
fill 511 225 547 511 225 550 minecraft:smooth_quartz
fill 512 225 515 512 307 515 minecraft:white_concrete
fill 512 225 519 512 307 521 minecraft:white_concrete
setblock 512 225 522 minecraft:light_blue_concrete
fill 512 225 523 512 225 525 minecraft:white_concrete
setblock 512 225 526 minecraft:light_blue_concrete
fill 512 225 527 512 307 527 minecraft:white_concrete
fill 512 225 534 512 307 534 minecraft:white_concrete
fill 512 225 537 512 225 539 minecraft:white_concrete
setblock 512 225 540 minecraft:light_blue_concrete
fill 512 225 541 512 225 546 minecraft:white_concrete
fill 470 226 510 470 307 515 minecraft:white_concrete
fill 470 226 516 470 231 519 minecraft:pearlescent_froglight
setblock 470 226 520 minecraft:light_blue_concrete
fill 470 226 521 470 307 527 minecraft:white_concrete
fill 470 226 528 470 231 531 minecraft:pearlescent_froglight
fill 470 226 532 470 307 539 minecraft:white_concrete
fill 470 226 540 470 231 543 minecraft:pearlescent_froglight
fill 470 226 544 470 307 550 minecraft:white_concrete
setblock 470 226 551 minecraft:light_blue_concrete
fill 470 226 552 473 231 552 minecraft:pearlescent_froglight
setblock 471 226 525 minecraft:white_concrete
setblock 473 226 513 minecraft:light[level=14]
setblock 473 226 521 minecraft:light[level=14]
setblock 473 226 529 minecraft:light[level=14]
setblock 473 226 537 minecraft:light[level=14]
setblock 473 226 545 minecraft:light[level=14]
fill 474 226 552 478 307 552 minecraft:white_concrete
setblock 476 226 510 minecraft:light_blue_concrete
fill 476 226 525 477 226 526 minecraft:white_concrete
fill 477 226 510 480 231 510 minecraft:pearlescent_froglight
setblock 478 226 526 minecraft:white_concrete
setblock 479 226 552 minecraft:light_blue_concrete
fill 480 226 552 481 307 552 minecraft:white_concrete
fill 481 226 510 484 307 510 minecraft:white_concrete
setblock 481 226 513 minecraft:light[level=14]
setblock 481 226 521 minecraft:light[level=14]
setblock 481 226 529 minecraft:light[level=14]
setblock 481 226 537 minecraft:light[level=14]
setblock 481 226 545 minecraft:light[level=14]
fill 482 226 552 485 231 552 minecraft:pearlescent_froglight
fill 486 226 510 488 307 510 minecraft:white_concrete
fill 486 226 552 493 307 552 minecraft:white_concrete
fill 489 226 510 492 231 510 minecraft:pearlescent_froglight
setblock 489 226 513 minecraft:light[level=14]
setblock 489 226 521 minecraft:light[level=14]
setblock 489 226 529 minecraft:light[level=14]
setblock 489 226 537 minecraft:light[level=14]
setblock 489 226 545 minecraft:light[level=14]
fill 493 226 510 493 307 510 minecraft:white_concrete
setblock 494 226 510 minecraft:light_blue_concrete
fill 494 226 552 497 231 552 minecraft:pearlescent_froglight
fill 495 226 510 497 307 510 minecraft:white_concrete
setblock 497 226 513 minecraft:light[level=14]
setblock 497 226 521 minecraft:light[level=14]
setblock 497 226 529 minecraft:light[level=14]
setblock 497 226 537 minecraft:light[level=14]
setblock 497 226 545 minecraft:light[level=14]
setblock 498 226 510 minecraft:light_blue_concrete
fill 498 226 552 500 307 552 minecraft:white_concrete
fill 499 226 510 499 307 510 minecraft:white_concrete
fill 501 226 510 504 231 510 minecraft:pearlescent_froglight
setblock 501 226 552 minecraft:light_blue_concrete
fill 502 226 552 505 307 552 minecraft:white_concrete
fill 504 226 526 506 226 526 minecraft:white_concrete
fill 505 226 510 508 307 510 minecraft:white_concrete
setblock 505 226 513 minecraft:light[level=14]
setblock 505 226 521 minecraft:light[level=14]
fill 505 226 525 506 226 525 minecraft:white_concrete
setblock 505 226 529 minecraft:light[level=14]
setblock 505 226 537 minecraft:light[level=14]
setblock 505 226 545 minecraft:light[level=14]
fill 506 226 552 509 231 552 minecraft:pearlescent_froglight
fill 507 226 537 508 227 537 minecraft:white_wool
fill 509 226 526 510 226 526 minecraft:white_concrete
fill 510 226 552 511 307 552 minecraft:white_concrete
setblock 511 226 525 minecraft:white_concrete
fill 512 226 511 512 231 514 minecraft:pearlescent_froglight
fill 512 226 517 512 307 517 minecraft:white_concrete
fill 512 226 522 512 307 522 minecraft:white_concrete
fill 512 226 523 512 231 526 minecraft:pearlescent_froglight
setblock 512 226 528 minecraft:light_blue_concrete
fill 512 226 529 512 307 530 minecraft:white_concrete
setblock 512 226 531 minecraft:light_blue_concrete
fill 512 226 532 512 307 532 minecraft:white_concrete
setblock 512 226 533 minecraft:light_blue_concrete
fill 512 226 535 512 231 538 minecraft:pearlescent_froglight
setblock 512 226 539 minecraft:light_blue_concrete
fill 512 226 540 512 307 540 minecraft:white_concrete
setblock 512 226 541 minecraft:light_blue_concrete
fill 512 226 542 512 307 546 minecraft:white_concrete
fill 512 226 547 512 231 550 minecraft:pearlescent_froglight
fill 512 226 551 512 307 551 minecraft:white_concrete
setblock 512 226 552 minecraft:light_blue_concrete
fill 470 227 520 470 307 520 minecraft:white_concrete
fill 470 227 551 470 307 551 minecraft:white_concrete
fill 474 227 524 476 227 524 minecraft:white_concrete
fill 475 227 525 476 227 525 minecraft:white_concrete
fill 476 227 510 476 307 510 minecraft:white_concrete
fill 476 227 526 476 229 536 minecraft:gold_block
fill 477 227 524 477 229 530 minecraft:gold_block
fill 477 227 532 477 229 538 minecraft:gold_block
fill 478 227 522 478 229 525 minecraft:gold_block
fill 478 227 537 478 229 540 minecraft:gold_block
fill 479 227 521 479 229 523 minecraft:gold_block
fill 479 227 539 479 229 541 minecraft:gold_block
fill 479 227 552 479 307 552 minecraft:white_concrete
fill 480 227 520 480 229 522 minecraft:gold_block
fill 480 227 540 480 229 542 minecraft:gold_block
fill 481 227 519 481 229 521 minecraft:gold_block
fill 481 227 541 481 229 543 minecraft:gold_block
fill 482 227 518 482 229 520 minecraft:gold_block
fill 482 227 542 482 229 544 minecraft:gold_block
fill 483 227 518 483 229 519 minecraft:gold_block
fill 483 227 543 483 229 544 minecraft:gold_block
fill 484 227 517 485 229 518 minecraft:gold_block
fill 484 227 544 485 229 545 minecraft:gold_block
fill 485 227 510 485 307 510 minecraft:white_concrete
fill 486 227 516 490 229 517 minecraft:gold_block
fill 486 227 545 490 229 546 minecraft:gold_block
fill 491 227 516 496 229 516 minecraft:gold_block
fill 491 227 546 496 229 546 minecraft:gold_block
fill 492 227 517 498 229 517 minecraft:gold_block
fill 492 227 545 498 229 545 minecraft:gold_block
fill 494 227 510 494 307 510 minecraft:white_concrete
fill 497 227 518 500 229 518 minecraft:gold_block
fill 497 227 544 500 229 544 minecraft:gold_block
fill 498 227 510 498 307 510 minecraft:white_concrete
fill 499 227 519 501 229 519 minecraft:gold_block
fill 499 227 543 501 229 543 minecraft:gold_block
fill 500 227 520 502 229 520 minecraft:gold_block
fill 500 227 542 502 229 542 minecraft:gold_block
fill 501 227 521 503 229 521 minecraft:gold_block
fill 501 227 541 503 229 541 minecraft:gold_block
fill 501 227 552 501 307 552 minecraft:white_concrete
fill 502 227 522 504 229 522 minecraft:gold_block
fill 502 227 540 504 229 540 minecraft:gold_block
fill 503 227 523 504 229 523 minecraft:gold_block
fill 503 227 539 504 229 539 minecraft:gold_block
fill 504 227 524 505 229 525 minecraft:gold_block
fill 504 227 537 505 229 538 minecraft:gold_block
fill 505 227 526 506 229 530 minecraft:gold_block
fill 505 227 532 506 229 536 minecraft:gold_block
fill 506 227 524 507 227 525 minecraft:white_concrete
fill 506 227 531 506 229 531 minecraft:gold_block
fill 508 227 524 508 229 524 minecraft:white_concrete
fill 512 227 528 512 307 528 minecraft:white_concrete
fill 512 227 531 512 307 531 minecraft:white_concrete
fill 512 227 533 512 307 533 minecraft:white_concrete
fill 512 227 539 512 307 539 minecraft:white_concrete
fill 512 227 541 512 307 541 minecraft:white_concrete
fill 512 227 552 512 307 552 minecraft:white_concrete
fill 473 228 523 474 229 524 minecraft:white_concrete
fill 475 228 524 475 228 525 minecraft:white_concrete
fill 475 228 528 475 228 534 minecraft:gold_block
setblock 476 228 525 minecraft:gold_block
setblock 476 228 537 minecraft:gold_block
setblock 477 228 523 minecraft:gold_block
setblock 477 228 531 minecraft:gold_block
setblock 477 228 539 minecraft:gold_block
fill 478 228 526 478 228 527 minecraft:gold_block
fill 478 228 535 478 228 536 minecraft:gold_block
setblock 479 228 520 minecraft:gold_block
setblock 479 228 524 minecraft:gold_block
setblock 479 228 538 minecraft:gold_block
setblock 479 228 542 minecraft:gold_block
setblock 480 228 519 minecraft:gold_block
setblock 480 228 523 minecraft:gold_block
setblock 480 228 539 minecraft:gold_block
setblock 480 228 543 minecraft:gold_block
setblock 483 228 517 minecraft:gold_block
setblock 483 228 520 minecraft:gold_block
setblock 483 228 542 minecraft:gold_block
setblock 483 228 545 minecraft:gold_block
setblock 484 228 519 minecraft:gold_block
setblock 484 228 543 minecraft:gold_block
setblock 485 228 516 minecraft:gold_block
setblock 485 228 546 minecraft:gold_block
fill 486 228 518 487 228 518 minecraft:gold_block
fill 486 228 544 487 228 544 minecraft:gold_block
fill 488 228 515 494 228 515 minecraft:gold_block
fill 488 228 547 494 228 547 minecraft:gold_block
setblock 491 228 517 minecraft:gold_block
setblock 491 228 545 minecraft:gold_block
fill 495 228 518 496 228 518 minecraft:gold_block
fill 495 228 544 496 228 544 minecraft:gold_block
setblock 497 228 516 minecraft:gold_block
setblock 497 228 546 minecraft:gold_block
setblock 498 228 519 minecraft:gold_block
setblock 498 228 543 minecraft:gold_block
setblock 499 228 517 minecraft:gold_block
setblock 499 228 520 minecraft:gold_block
setblock 499 228 542 minecraft:gold_block
setblock 499 228 545 minecraft:gold_block
setblock 502 228 519 minecraft:gold_block
setblock 502 228 523 minecraft:gold_block
setblock 502 228 539 minecraft:gold_block
setblock 502 228 543 minecraft:gold_block
setblock 503 228 520 minecraft:gold_block
setblock 503 228 524 minecraft:gold_block
setblock 503 228 538 minecraft:gold_block
setblock 503 228 542 minecraft:gold_block
fill 504 228 526 504 228 527 minecraft:gold_block
fill 504 228 535 504 228 536 minecraft:gold_block
setblock 505 228 523 minecraft:gold_block
setblock 505 228 531 minecraft:gold_block
setblock 505 228 539 minecraft:gold_block
setblock 506 228 525 minecraft:gold_block
setblock 506 228 537 minecraft:gold_block
fill 507 228 524 507 228 525 minecraft:white_concrete
fill 507 228 528 507 228 534 minecraft:gold_block
fill 508 228 523 509 229 523 minecraft:white_concrete
fill 509 228 524 509 229 524 minecraft:white_concrete
fill 472 229 522 472 230 523 minecraft:white_concrete
setblock 473 229 522 minecraft:white_concrete
fill 489 229 547 490 230 547 minecraft:gold_block
fill 509 229 522 510 229 522 minecraft:white_concrete
fill 510 229 523 510 230 523 minecraft:white_concrete
setblock 473 230 523 minecraft:white_concrete
fill 489 230 546 490 230 546 minecraft:gold_block
setblock 509 230 523 minecraft:white_concrete
fill 510 230 522 511 230 522 minecraft:white_concrete
fill 509 231 516 509 232 522 minecraft:gold_block
fill 470 232 516 470 245 516 minecraft:white_concrete
fill 470 232 517 470 232 518 minecraft:pearlescent_froglight
fill 470 232 519 470 245 519 minecraft:white_concrete
fill 470 232 528 470 245 528 minecraft:white_concrete
fill 470 232 529 470 232 530 minecraft:pearlescent_froglight
fill 470 232 531 470 245 531 minecraft:white_concrete
fill 470 232 540 470 245 540 minecraft:white_concrete
fill 470 232 541 470 232 542 minecraft:pearlescent_froglight
fill 470 232 543 470 245 543 minecraft:white_concrete
fill 470 232 552 470 245 552 minecraft:white_concrete
fill 471 232 552 472 232 552 minecraft:pearlescent_froglight
fill 473 232 552 473 245 552 minecraft:white_concrete
fill 477 232 510 477 245 510 minecraft:white_concrete
fill 478 232 510 479 232 510 minecraft:pearlescent_froglight
fill 480 232 510 480 245 510 minecraft:white_concrete
fill 482 232 552 482 245 552 minecraft:white_concrete
fill 483 232 552 484 232 552 minecraft:pearlescent_froglight
fill 485 232 552 485 245 552 minecraft:white_concrete
fill 489 232 510 489 245 510 minecraft:white_concrete
fill 490 232 510 491 232 510 minecraft:pearlescent_froglight
fill 492 232 510 492 245 510 minecraft:white_concrete
fill 494 232 552 494 245 552 minecraft:white_concrete
fill 495 232 552 496 232 552 minecraft:pearlescent_froglight
fill 497 232 552 497 245 552 minecraft:white_concrete
fill 501 232 510 501 245 510 minecraft:white_concrete
fill 502 232 510 503 232 510 minecraft:pearlescent_froglight
fill 504 232 510 504 245 510 minecraft:white_concrete
fill 506 232 552 506 245 552 minecraft:white_concrete
fill 507 232 552 508 232 552 minecraft:pearlescent_froglight
fill 509 232 552 509 245 552 minecraft:white_concrete
fill 512 232 511 512 245 511 minecraft:white_concrete
fill 512 232 512 512 232 513 minecraft:pearlescent_froglight
fill 512 232 514 512 245 514 minecraft:white_concrete
fill 512 232 523 512 245 523 minecraft:white_concrete
fill 512 232 524 512 232 525 minecraft:pearlescent_froglight
fill 512 232 526 512 245 526 minecraft:white_concrete
fill 512 232 535 512 245 535 minecraft:white_concrete
fill 512 232 536 512 232 537 minecraft:pearlescent_froglight
fill 512 232 538 512 245 538 minecraft:white_concrete
fill 512 232 547 512 245 547 minecraft:white_concrete
fill 512 232 548 512 232 549 minecraft:pearlescent_froglight
fill 512 232 550 512 245 550 minecraft:white_concrete
fill 470 233 517 470 245 518 minecraft:white_concrete
fill 470 233 529 470 245 530 minecraft:white_concrete
fill 470 233 541 470 245 542 minecraft:white_concrete
fill 471 233 552 472 245 552 minecraft:white_concrete
fill 478 233 510 479 245 510 minecraft:white_concrete
fill 483 233 552 484 245 552 minecraft:white_concrete
fill 490 233 510 491 245 510 minecraft:white_concrete
fill 495 233 552 496 245 552 minecraft:white_concrete
fill 502 233 510 503 245 510 minecraft:white_concrete
fill 507 233 552 508 245 552 minecraft:white_concrete
fill 512 233 512 512 245 513 minecraft:white_concrete
fill 512 233 524 512 245 525 minecraft:white_concrete
fill 512 233 536 512 245 537 minecraft:white_concrete
fill 512 233 548 512 245 549 minecraft:white_concrete
setblock 473 234 513 minecraft:light[level=14]
setblock 473 234 521 minecraft:light[level=14]
setblock 473 234 529 minecraft:light[level=14]
setblock 473 234 537 minecraft:light[level=14]
setblock 473 234 545 minecraft:light[level=14]
setblock 481 234 513 minecraft:light[level=14]
setblock 481 234 521 minecraft:light[level=14]
setblock 481 234 529 minecraft:light[level=14]
setblock 481 234 537 minecraft:light[level=14]
setblock 481 234 545 minecraft:light[level=14]
setblock 489 234 513 minecraft:light[level=14]
setblock 489 234 521 minecraft:light[level=14]
setblock 489 234 529 minecraft:light[level=14]
setblock 489 234 537 minecraft:light[level=14]
setblock 489 234 545 minecraft:light[level=14]
setblock 497 234 513 minecraft:light[level=14]
setblock 497 234 521 minecraft:light[level=14]
setblock 497 234 529 minecraft:light[level=14]
setblock 497 234 537 minecraft:light[level=14]
setblock 497 234 545 minecraft:light[level=14]
setblock 505 234 513 minecraft:light[level=14]
setblock 505 234 521 minecraft:light[level=14]
setblock 505 234 529 minecraft:light[level=14]
setblock 505 234 537 minecraft:light[level=14]
setblock 505 234 545 minecraft:light[level=14]
fill 490 239 524 492 239 526 minecraft:redstone_block
fill 490 239 532 492 239 534 minecraft:redstone_block
fill 498 239 528 500 239 530 minecraft:redstone_block
fill 471 240 511 511 241 513 minecraft:white_wool
fill 471 240 514 511 241 514 minecraft:light_gray_wool
fill 471 240 515 511 241 517 minecraft:white_wool
fill 471 240 518 511 241 518 minecraft:light_gray_wool
fill 471 240 519 511 241 521 minecraft:white_wool
fill 471 240 522 511 241 522 minecraft:light_gray_wool
fill 471 240 523 489 240 525 minecraft:white_wool
fill 471 240 526 489 240 526 minecraft:light_gray_wool
fill 471 240 527 492 240 529 minecraft:white_wool
fill 471 240 530 492 240 530 minecraft:light_gray_wool
fill 471 240 531 489 240 533 minecraft:white_wool
fill 471 240 534 489 240 534 minecraft:light_gray_wool
fill 471 240 535 511 240 537 minecraft:white_wool
fill 471 240 538 511 241 538 minecraft:light_gray_wool
fill 471 240 539 511 241 541 minecraft:white_wool
fill 471 240 542 511 241 542 minecraft:light_gray_wool
fill 471 240 543 511 241 545 minecraft:white_wool
fill 471 240 546 511 241 546 minecraft:light_gray_wool
fill 471 240 547 511 241 549 minecraft:white_wool
fill 471 240 550 511 241 550 minecraft:light_gray_wool
fill 471 240 551 511 241 551 minecraft:white_wool
fill 490 240 523 511 240 523 minecraft:white_wool
fill 490 240 531 511 240 531 minecraft:white_wool
fill 493 240 524 511 240 525 minecraft:white_wool
fill 493 240 526 511 240 526 minecraft:light_gray_wool
fill 493 240 527 511 240 527 minecraft:white_wool
fill 493 240 532 511 240 533 minecraft:white_wool
fill 493 240 534 511 240 534 minecraft:light_gray_wool
fill 496 240 528 497 240 529 minecraft:white_wool
fill 496 240 530 497 240 530 minecraft:light_gray_wool
fill 501 240 528 511 240 529 minecraft:white_wool
fill 501 240 530 511 240 530 minecraft:light_gray_wool
fill 471 241 523 488 241 525 minecraft:white_wool
fill 471 241 526 488 241 526 minecraft:light_gray_wool
fill 471 241 527 488 241 529 minecraft:white_wool
fill 471 241 530 491 241 530 minecraft:light_gray_wool
fill 471 241 531 488 241 533 minecraft:white_wool
fill 471 241 534 488 241 534 minecraft:light_gray_wool
fill 471 241 535 488 241 537 minecraft:white_wool
fill 489 241 523 489 241 527 minecraft:pearlescent_froglight
fill 489 241 528 491 241 529 minecraft:white_wool
fill 489 241 531 489 241 535 minecraft:pearlescent_froglight
fill 489 241 536 511 241 537 minecraft:white_wool
fill 490 241 523 493 241 523 minecraft:pearlescent_froglight
fill 490 241 524 492 241 526 minecraft:white_wool
fill 490 241 527 501 241 527 minecraft:pearlescent_froglight
fill 490 241 531 501 241 531 minecraft:pearlescent_froglight
fill 490 241 532 492 241 534 minecraft:white_wool
fill 490 241 535 493 241 535 minecraft:pearlescent_froglight
fill 492 241 528 492 241 530 minecraft:pearlescent_froglight
fill 493 241 524 493 241 526 minecraft:pearlescent_froglight
fill 493 241 532 493 241 534 minecraft:pearlescent_froglight
fill 494 241 523 511 241 525 minecraft:white_wool
fill 494 241 526 511 241 526 minecraft:light_gray_wool
fill 494 241 532 511 241 533 minecraft:white_wool
fill 494 241 534 511 241 534 minecraft:light_gray_wool
fill 494 241 535 511 241 535 minecraft:white_wool
fill 496 241 528 497 241 530 minecraft:pearlescent_froglight
fill 498 241 528 500 241 530 minecraft:white_wool
fill 501 241 528 501 241 530 minecraft:pearlescent_froglight
fill 502 241 527 511 241 529 minecraft:white_wool
fill 502 241 530 511 241 530 minecraft:light_gray_wool
fill 502 241 531 511 241 531 minecraft:white_wool
setblock 473 242 513 minecraft:light[level=14]
setblock 473 242 521 minecraft:light[level=14]
setblock 473 242 529 minecraft:light[level=14]
setblock 473 242 537 minecraft:light[level=14]
setblock 473 242 545 minecraft:light[level=14]
setblock 481 242 513 minecraft:light[level=14]
setblock 481 242 521 minecraft:light[level=14]
setblock 481 242 529 minecraft:light[level=14]
setblock 481 242 537 minecraft:light[level=14]
setblock 481 242 545 minecraft:light[level=14]
setblock 489 242 513 minecraft:light[level=14]
setblock 489 242 521 minecraft:light[level=14]
setblock 489 242 529 minecraft:light[level=14]
setblock 489 242 537 minecraft:light[level=14]
setblock 489 242 545 minecraft:light[level=14]
fill 492 242 528 492 242 530 minecraft:lime_stained_glass
fill 493 242 527 495 242 527 minecraft:lime_stained_glass
fill 493 242 531 495 242 531 minecraft:lime_stained_glass
fill 496 242 528 496 242 530 minecraft:lime_stained_glass
setblock 497 242 513 minecraft:light[level=14]
setblock 497 242 521 minecraft:light[level=14]
setblock 497 242 529 minecraft:light[level=14]
setblock 497 242 537 minecraft:light[level=14]
setblock 497 242 545 minecraft:light[level=14]
setblock 505 242 513 minecraft:light[level=14]
setblock 505 242 521 minecraft:light[level=14]
setblock 505 242 529 minecraft:light[level=14]
setblock 505 242 537 minecraft:light[level=14]
setblock 505 242 545 minecraft:light[level=14]
fill 483 243 527 491 243 531 minecraft:light_gray_concrete
fill 484 243 524 504 243 526 minecraft:light_gray_concrete
fill 484 243 532 504 243 534 minecraft:light_gray_concrete
fill 485 243 523 503 246 523 minecraft:light_gray_concrete
fill 485 243 535 503 246 535 minecraft:light_gray_concrete
fill 486 243 522 502 246 522 minecraft:light_gray_concrete
fill 486 243 536 502 246 536 minecraft:light_gray_concrete
fill 487 243 521 501 246 521 minecraft:light_gray_concrete
fill 487 243 537 501 246 537 minecraft:light_gray_concrete
fill 488 243 520 500 246 520 minecraft:light_gray_concrete
fill 488 243 538 500 246 538 minecraft:light_gray_concrete
fill 489 243 519 499 246 519 minecraft:light_gray_concrete
fill 489 243 539 499 246 539 minecraft:light_gray_concrete
fill 492 243 518 496 246 518 minecraft:light_gray_concrete
fill 492 243 527 492 243 528 minecraft:light_gray_concrete
fill 492 243 530 492 243 531 minecraft:light_gray_concrete
fill 492 243 540 496 246 540 minecraft:light_gray_concrete
setblock 493 243 527 minecraft:light_gray_concrete
setblock 493 243 531 minecraft:light_gray_concrete
fill 495 243 527 505 243 527 minecraft:light_gray_concrete
fill 495 243 531 505 243 531 minecraft:light_gray_concrete
fill 496 243 528 505 243 528 minecraft:light_gray_concrete
fill 496 243 530 505 243 530 minecraft:light_gray_concrete
fill 497 243 529 505 243 529 minecraft:light_gray_concrete
fill 481 244 525 481 245 533 minecraft:sea_lantern
fill 482 244 523 482 245 526 minecraft:sea_lantern
fill 482 244 527 490 244 531 minecraft:light_gray_concrete
fill 482 244 532 482 245 535 minecraft:sea_lantern
fill 483 244 521 483 245 523 minecraft:sea_lantern
fill 483 244 524 493 244 526 minecraft:light_gray_concrete
fill 483 244 532 493 244 534 minecraft:light_gray_concrete
fill 483 244 535 483 245 537 minecraft:sea_lantern
fill 484 244 520 484 245 521 minecraft:sea_lantern
fill 484 244 522 484 245 523 minecraft:light_gray_concrete
fill 484 244 535 484 245 536 minecraft:light_gray_concrete
fill 484 244 537 484 245 538 minecraft:sea_lantern
fill 485 244 519 485 245 520 minecraft:sea_lantern
fill 485 244 521 485 245 522 minecraft:light_gray_concrete
fill 485 244 536 485 245 537 minecraft:light_gray_concrete
fill 485 244 538 485 245 539 minecraft:sea_lantern
fill 486 244 518 486 245 519 minecraft:sea_lantern
fill 486 244 520 486 245 521 minecraft:light_gray_concrete
fill 486 244 537 486 245 538 minecraft:light_gray_concrete
fill 486 244 539 486 245 540 minecraft:sea_lantern
fill 487 244 518 488 245 518 minecraft:sea_lantern
fill 487 244 519 487 245 520 minecraft:light_gray_concrete
fill 487 244 538 487 245 539 minecraft:light_gray_concrete
fill 487 244 540 488 245 540 minecraft:sea_lantern
fill 488 244 517 491 245 517 minecraft:sea_lantern
fill 488 244 519 488 245 519 minecraft:light_gray_concrete
fill 488 244 539 488 245 539 minecraft:light_gray_concrete
fill 488 244 541 491 245 541 minecraft:sea_lantern
fill 489 244 518 491 245 518 minecraft:light_gray_concrete
fill 489 244 540 491 245 540 minecraft:light_gray_concrete
fill 490 244 516 498 245 516 minecraft:sea_lantern
fill 490 244 542 498 245 542 minecraft:sea_lantern
fill 491 244 527 491 244 528 minecraft:light_gray_concrete
fill 491 244 529 491 247 529 minecraft:light_blue_stained_glass
fill 491 244 530 491 244 531 minecraft:light_gray_concrete
fill 492 244 517 496 245 517 minecraft:light_gray_concrete
fill 492 244 527 492 246 527 minecraft:light_blue_stained_glass
fill 492 244 531 492 246 531 minecraft:light_blue_stained_glass
fill 492 244 541 496 245 541 minecraft:light_gray_concrete
fill 494 244 524 505 244 525 minecraft:light_gray_concrete
fill 494 244 526 494 247 526 minecraft:light_blue_stained_glass
fill 494 244 532 494 247 532 minecraft:light_blue_stained_glass
fill 494 244 533 505 244 534 minecraft:light_gray_concrete
fill 495 244 526 505 244 526 minecraft:light_gray_concrete
fill 495 244 532 505 244 532 minecraft:light_gray_concrete
fill 496 244 527 496 246 527 minecraft:light_blue_stained_glass
fill 496 244 531 496 246 531 minecraft:light_blue_stained_glass
fill 497 244 517 500 245 517 minecraft:sea_lantern
fill 497 244 518 499 245 518 minecraft:light_gray_concrete
fill 497 244 527 506 244 528 minecraft:light_gray_concrete
fill 497 244 529 497 247 529 minecraft:light_blue_stained_glass
fill 497 244 530 506 244 531 minecraft:light_gray_concrete
fill 497 244 540 499 245 540 minecraft:light_gray_concrete
fill 497 244 541 500 245 541 minecraft:sea_lantern
fill 498 244 529 506 244 529 minecraft:light_gray_concrete
fill 500 244 518 502 245 518 minecraft:sea_lantern
fill 500 244 519 501 245 519 minecraft:light_gray_concrete
fill 500 244 539 501 245 539 minecraft:light_gray_concrete
fill 500 244 540 502 245 540 minecraft:sea_lantern
fill 501 244 520 502 245 520 minecraft:light_gray_concrete
fill 501 244 538 502 245 538 minecraft:light_gray_concrete
fill 502 244 519 503 245 519 minecraft:sea_lantern
fill 502 244 521 503 245 521 minecraft:light_gray_concrete
fill 502 244 537 503 245 537 minecraft:light_gray_concrete
fill 502 244 539 503 245 539 minecraft:sea_lantern
fill 503 244 520 504 245 520 minecraft:sea_lantern
fill 503 244 522 504 245 522 minecraft:light_gray_concrete
fill 503 244 536 504 245 536 minecraft:light_gray_concrete
fill 503 244 538 504 245 538 minecraft:sea_lantern
fill 504 244 521 505 245 521 minecraft:sea_lantern
fill 504 244 523 504 245 523 minecraft:light_gray_concrete
fill 504 244 535 504 245 535 minecraft:light_gray_concrete
fill 504 244 537 505 245 537 minecraft:sea_lantern
fill 505 244 522 505 245 523 minecraft:sea_lantern
fill 505 244 535 505 245 536 minecraft:sea_lantern
fill 506 244 523 506 245 526 minecraft:sea_lantern
fill 506 244 532 506 245 535 minecraft:sea_lantern
fill 507 244 525 507 245 533 minecraft:sea_lantern
fill 471 245 511 473 273 511 minecraft:quartz_block
fill 471 245 514 471 245 519 minecraft:smooth_quartz
fill 471 245 521 471 273 523 minecraft:quartz_block
fill 471 245 526 471 245 531 minecraft:smooth_quartz
fill 471 245 533 471 273 535 minecraft:quartz_block
fill 471 245 538 471 245 543 minecraft:smooth_quartz
fill 471 245 545 471 273 547 minecraft:quartz_block
fill 471 245 550 471 245 551 minecraft:smooth_quartz
fill 472 245 520 472 245 522 minecraft:quartz_block
fill 472 245 532 472 245 534 minecraft:quartz_block
fill 472 245 544 472 245 546 minecraft:quartz_block
fill 472 245 551 475 245 551 minecraft:smooth_quartz
fill 473 245 545 474 245 545 minecraft:smooth_quartz
fill 473 245 546 476 273 547 minecraft:quartz_block
setblock 473 245 548 minecraft:smooth_quartz
fill 474 245 548 475 273 548 minecraft:quartz_block
fill 474 245 549 475 245 549 minecraft:smooth_quartz
fill 475 245 511 480 245 511 minecraft:smooth_quartz
fill 475 245 545 475 273 545 minecraft:quartz_block
setblock 476 245 545 minecraft:smooth_quartz
setblock 476 245 548 minecraft:smooth_quartz
fill 477 245 546 477 245 547 minecraft:smooth_quartz
fill 477 245 551 479 273 551 minecraft:quartz_block
fill 478 245 550 480 245 550 minecraft:quartz_block
fill 482 245 512 484 245 512 minecraft:quartz_block
fill 482 245 527 489 245 531 minecraft:light_gray_concrete
fill 482 245 551 487 245 551 minecraft:smooth_quartz
fill 483 245 511 485 273 511 minecraft:quartz_block
fill 483 245 524 490 245 526 minecraft:light_gray_concrete
fill 483 245 532 490 245 534 minecraft:light_gray_concrete
fill 487 245 511 492 245 511 minecraft:smooth_quartz
fill 489 245 551 491 273 551 minecraft:quartz_block
fill 490 245 527 490 249 531 minecraft:light_blue_stained_glass
fill 490 245 550 492 245 550 minecraft:quartz_block
fill 491 245 524 491 245 525 minecraft:light_gray_concrete
fill 491 245 526 491 248 528 minecraft:light_blue_stained_glass
fill 491 245 530 491 248 532 minecraft:light_blue_stained_glass
fill 491 245 533 491 245 534 minecraft:light_gray_concrete
fill 492 245 524 505 245 524 minecraft:light_gray_concrete
fill 492 245 525 493 248 526 minecraft:light_blue_stained_glass
fill 492 245 532 493 248 533 minecraft:light_blue_stained_glass
fill 492 245 534 505 245 534 minecraft:light_gray_concrete
fill 494 245 512 496 245 512 minecraft:quartz_block
fill 494 245 525 496 249 525 minecraft:light_blue_stained_glass
fill 494 245 533 496 249 533 minecraft:light_blue_stained_glass
fill 494 245 551 499 245 551 minecraft:smooth_quartz
fill 495 245 511 497 273 511 minecraft:quartz_block
fill 495 245 526 497 248 526 minecraft:light_blue_stained_glass
fill 495 245 532 497 248 532 minecraft:light_blue_stained_glass
fill 497 245 525 505 245 525 minecraft:light_gray_concrete
fill 497 245 527 498 248 528 minecraft:light_blue_stained_glass
fill 497 245 530 498 248 531 minecraft:light_blue_stained_glass
fill 497 245 533 505 245 533 minecraft:light_gray_concrete
fill 498 245 526 505 245 526 minecraft:light_gray_concrete
fill 498 245 529 498 249 529 minecraft:light_blue_stained_glass
fill 498 245 532 505 245 532 minecraft:light_gray_concrete
fill 499 245 511 504 245 511 minecraft:smooth_quartz
fill 499 245 527 506 245 531 minecraft:light_gray_concrete
fill 501 245 551 503 273 551 minecraft:quartz_block
fill 502 245 550 504 245 550 minecraft:quartz_block
fill 504 245 546 504 245 548 minecraft:smooth_quartz
fill 505 245 545 507 245 545 minecraft:smooth_quartz
fill 505 245 546 507 273 548 minecraft:quartz_block
setblock 505 245 549 minecraft:smooth_quartz
fill 506 245 512 508 245 512 minecraft:quartz_block
fill 506 245 549 506 273 549 minecraft:quartz_block
fill 506 245 551 511 245 551 minecraft:smooth_quartz
fill 507 245 511 509 273 511 minecraft:quartz_block
fill 507 245 549 508 245 549 minecraft:smooth_quartz
setblock 508 245 546 minecraft:smooth_quartz
fill 508 245 547 508 273 547 minecraft:quartz_block
setblock 508 245 548 minecraft:smooth_quartz
fill 510 245 520 510 245 522 minecraft:quartz_block
fill 510 245 532 510 245 534 minecraft:quartz_block
fill 510 245 544 510 245 546 minecraft:quartz_block
fill 511 245 511 511 245 516 minecraft:smooth_quartz
fill 511 245 519 511 273 521 minecraft:quartz_block
fill 511 245 523 511 245 528 minecraft:smooth_quartz
fill 511 245 531 511 273 533 minecraft:quartz_block
fill 511 245 535 511 245 540 minecraft:smooth_quartz
fill 511 245 543 511 273 545 minecraft:quartz_block
fill 511 245 547 511 245 550 minecraft:smooth_quartz
fill 470 246 516 470 251 519 minecraft:pearlescent_froglight
fill 470 246 528 470 251 531 minecraft:pearlescent_froglight
fill 470 246 540 470 251 543 minecraft:pearlescent_froglight
fill 470 246 552 473 251 552 minecraft:pearlescent_froglight
fill 477 246 510 480 251 510 minecraft:pearlescent_froglight
fill 482 246 552 485 251 552 minecraft:pearlescent_froglight
fill 483 246 527 488 246 531 minecraft:light_gray_concrete
fill 484 246 524 489 246 526 minecraft:light_gray_concrete
fill 484 246 532 489 246 534 minecraft:light_gray_concrete
fill 489 246 510 492 251 510 minecraft:pearlescent_froglight
fill 489 246 527 489 248 531 minecraft:light_blue_stained_glass
fill 490 246 524 491 246 524 minecraft:light_gray_concrete
fill 490 246 525 490 248 526 minecraft:light_blue_stained_glass
fill 490 246 532 490 248 533 minecraft:light_blue_stained_glass
fill 490 246 534 491 246 534 minecraft:light_gray_concrete
fill 491 246 525 491 248 525 minecraft:light_blue_stained_glass
fill 491 246 533 491 248 533 minecraft:light_blue_stained_glass
fill 492 246 524 496 248 524 minecraft:light_blue_stained_glass
fill 492 246 534 496 248 534 minecraft:light_blue_stained_glass
fill 494 246 552 497 251 552 minecraft:pearlescent_froglight
fill 497 246 524 504 246 524 minecraft:light_gray_concrete
fill 497 246 525 498 248 525 minecraft:light_blue_stained_glass
fill 497 246 533 498 248 533 minecraft:light_blue_stained_glass
fill 497 246 534 504 246 534 minecraft:light_gray_concrete
fill 498 246 526 498 248 526 minecraft:light_blue_stained_glass
fill 498 246 532 498 248 532 minecraft:light_blue_stained_glass
fill 499 246 525 504 246 526 minecraft:light_gray_concrete
fill 499 246 527 499 248 531 minecraft:light_blue_stained_glass
fill 499 246 532 504 246 533 minecraft:light_gray_concrete
fill 500 246 527 505 246 531 minecraft:light_gray_concrete
fill 501 246 510 504 251 510 minecraft:pearlescent_froglight
fill 506 246 552 509 251 552 minecraft:pearlescent_froglight
fill 512 246 511 512 251 514 minecraft:pearlescent_froglight
fill 512 246 523 512 251 526 minecraft:pearlescent_froglight
fill 512 246 535 512 251 538 minecraft:pearlescent_froglight
fill 512 246 547 512 251 550 minecraft:pearlescent_froglight
setblock 488 247 529 minecraft:light_blue_stained_glass
setblock 489 247 526 minecraft:light_blue_stained_glass
setblock 489 247 532 minecraft:light_blue_stained_glass
setblock 491 247 524 minecraft:light_blue_stained_glass
setblock 491 247 534 minecraft:light_blue_stained_glass
setblock 494 247 523 minecraft:light_blue_stained_glass
setblock 494 247 535 minecraft:light_blue_stained_glass
setblock 497 247 524 minecraft:light_blue_stained_glass
setblock 497 247 534 minecraft:light_blue_stained_glass
setblock 499 247 526 minecraft:light_blue_stained_glass
setblock 499 247 532 minecraft:light_blue_stained_glass
setblock 500 247 529 minecraft:light_blue_stained_glass
fill 491 249 526 491 249 527 minecraft:light_blue_stained_glass
fill 491 249 531 491 249 532 minecraft:light_blue_stained_glass
fill 492 249 525 492 249 526 minecraft:light_blue_stained_glass
fill 492 249 532 492 249 533 minecraft:light_blue_stained_glass
setblock 493 249 525 minecraft:light_blue_stained_glass
setblock 493 249 533 minecraft:light_blue_stained_glass
fill 496 249 526 497 249 526 minecraft:light_blue_stained_glass
fill 496 249 532 497 249 532 minecraft:light_blue_stained_glass
fill 497 249 527 498 249 527 minecraft:light_blue_stained_glass
fill 497 249 531 498 249 531 minecraft:light_blue_stained_glass
setblock 498 249 528 minecraft:light_blue_stained_glass
setblock 498 249 530 minecraft:light_blue_stained_glass
setblock 473 250 513 minecraft:light[level=14]
setblock 473 250 521 minecraft:light[level=14]
setblock 473 250 529 minecraft:light[level=14]
setblock 473 250 537 minecraft:light[level=14]
setblock 473 250 545 minecraft:light[level=14]
setblock 481 250 513 minecraft:light[level=14]
setblock 481 250 521 minecraft:light[level=14]
setblock 481 250 529 minecraft:light[level=14]
setblock 481 250 537 minecraft:light[level=14]
setblock 481 250 545 minecraft:light[level=14]
setblock 489 250 513 minecraft:light[level=14]
setblock 489 250 521 minecraft:light[level=14]
setblock 489 250 529 minecraft:light[level=14]
setblock 489 250 537 minecraft:light[level=14]
setblock 489 250 545 minecraft:light[level=14]
setblock 497 250 513 minecraft:light[level=14]
setblock 497 250 521 minecraft:light[level=14]
setblock 497 250 537 minecraft:light[level=14]
setblock 497 250 545 minecraft:light[level=14]
setblock 505 250 513 minecraft:light[level=14]
setblock 505 250 521 minecraft:light[level=14]
setblock 505 250 529 minecraft:light[level=14]
setblock 505 250 537 minecraft:light[level=14]
setblock 505 250 545 minecraft:light[level=14]
fill 470 252 516 470 265 516 minecraft:white_concrete
fill 470 252 517 470 252 518 minecraft:pearlescent_froglight
fill 470 252 519 470 265 519 minecraft:white_concrete
fill 470 252 528 470 265 528 minecraft:white_concrete
fill 470 252 529 470 252 530 minecraft:pearlescent_froglight
fill 470 252 531 470 265 531 minecraft:white_concrete
fill 470 252 540 470 265 540 minecraft:white_concrete
fill 470 252 541 470 252 542 minecraft:pearlescent_froglight
fill 470 252 543 470 265 543 minecraft:white_concrete
fill 470 252 552 470 265 552 minecraft:white_concrete
fill 471 252 552 472 252 552 minecraft:pearlescent_froglight
fill 473 252 552 473 265 552 minecraft:white_concrete
fill 477 252 510 477 265 510 minecraft:white_concrete
fill 478 252 510 479 252 510 minecraft:pearlescent_froglight
fill 480 252 510 480 265 510 minecraft:white_concrete
fill 482 252 552 482 265 552 minecraft:white_concrete
fill 483 252 552 484 252 552 minecraft:pearlescent_froglight
fill 485 252 552 485 265 552 minecraft:white_concrete
fill 489 252 510 489 265 510 minecraft:white_concrete
fill 490 252 510 491 252 510 minecraft:pearlescent_froglight
fill 492 252 510 492 265 510 minecraft:white_concrete
fill 494 252 552 494 265 552 minecraft:white_concrete
fill 495 252 552 496 252 552 minecraft:pearlescent_froglight
fill 497 252 552 497 265 552 minecraft:white_concrete
fill 501 252 510 501 265 510 minecraft:white_concrete
fill 502 252 510 503 252 510 minecraft:pearlescent_froglight
fill 504 252 510 504 265 510 minecraft:white_concrete
fill 506 252 552 506 265 552 minecraft:white_concrete
fill 507 252 552 508 252 552 minecraft:pearlescent_froglight
fill 509 252 552 509 265 552 minecraft:white_concrete
fill 512 252 511 512 265 511 minecraft:white_concrete
fill 512 252 512 512 252 513 minecraft:pearlescent_froglight
fill 512 252 514 512 265 514 minecraft:white_concrete
fill 512 252 523 512 265 523 minecraft:white_concrete
fill 512 252 524 512 252 525 minecraft:pearlescent_froglight
fill 512 252 526 512 265 526 minecraft:white_concrete
fill 512 252 535 512 265 535 minecraft:white_concrete
fill 512 252 536 512 252 537 minecraft:pearlescent_froglight
fill 512 252 538 512 265 538 minecraft:white_concrete
fill 512 252 547 512 265 547 minecraft:white_concrete
fill 512 252 548 512 252 549 minecraft:pearlescent_froglight
fill 512 252 550 512 265 550 minecraft:white_concrete
fill 470 253 517 470 265 518 minecraft:white_concrete
fill 470 253 529 470 265 530 minecraft:white_concrete
fill 470 253 541 470 265 542 minecraft:white_concrete
fill 471 253 552 472 265 552 minecraft:white_concrete
fill 473 253 545 474 253 545 minecraft:smooth_quartz
setblock 473 253 548 minecraft:smooth_quartz
fill 474 253 549 475 253 549 minecraft:smooth_quartz
setblock 476 253 545 minecraft:smooth_quartz
setblock 476 253 548 minecraft:smooth_quartz
fill 477 253 546 477 253 547 minecraft:smooth_quartz
fill 478 253 510 479 265 510 minecraft:white_concrete
fill 483 253 552 484 265 552 minecraft:white_concrete
fill 490 253 510 491 265 510 minecraft:white_concrete
fill 495 253 552 496 265 552 minecraft:white_concrete
fill 502 253 510 503 265 510 minecraft:white_concrete
fill 504 253 546 504 253 548 minecraft:smooth_quartz
fill 505 253 545 507 253 545 minecraft:smooth_quartz
setblock 505 253 549 minecraft:smooth_quartz
fill 507 253 549 508 253 549 minecraft:smooth_quartz
fill 507 253 552 508 265 552 minecraft:white_concrete
setblock 508 253 546 minecraft:smooth_quartz
setblock 508 253 548 minecraft:smooth_quartz
fill 509 253 533 509 264 533 minecraft:white_wool
fill 512 253 512 512 265 513 minecraft:white_concrete
fill 512 253 524 512 265 525 minecraft:white_concrete
fill 512 253 536 512 265 537 minecraft:white_concrete
fill 512 253 548 512 265 549 minecraft:white_concrete
fill 509 254 531 509 264 532 minecraft:white_wool
fill 509 254 534 509 264 535 minecraft:white_wool
setblock 473 258 513 minecraft:light[level=14]
setblock 473 258 521 minecraft:light[level=14]
setblock 473 258 529 minecraft:light[level=14]
setblock 473 258 537 minecraft:light[level=14]
setblock 473 258 545 minecraft:light[level=14]
setblock 481 258 513 minecraft:light[level=14]
setblock 481 258 521 minecraft:light[level=14]
setblock 481 258 529 minecraft:light[level=14]
setblock 481 258 537 minecraft:light[level=14]
setblock 481 258 545 minecraft:light[level=14]
setblock 489 258 513 minecraft:light[level=14]
setblock 489 258 521 minecraft:light[level=14]
setblock 489 258 529 minecraft:light[level=14]
setblock 489 258 537 minecraft:light[level=14]
setblock 489 258 545 minecraft:light[level=14]
setblock 497 258 513 minecraft:light[level=14]
setblock 497 258 521 minecraft:light[level=14]
setblock 497 258 529 minecraft:light[level=14]
setblock 497 258 537 minecraft:light[level=14]
setblock 497 258 545 minecraft:light[level=14]
setblock 505 258 513 minecraft:light[level=14]
setblock 505 258 521 minecraft:light[level=14]
setblock 505 258 529 minecraft:light[level=14]
setblock 505 258 537 minecraft:light[level=14]
setblock 505 258 545 minecraft:light[level=14]
fill 472 260 520 472 265 522 minecraft:quartz_block
fill 472 260 532 472 265 534 minecraft:quartz_block
fill 472 260 544 472 265 546 minecraft:quartz_block
fill 478 260 550 480 265 550 minecraft:quartz_block
fill 482 260 512 484 265 512 minecraft:quartz_block
fill 490 260 550 492 265 550 minecraft:quartz_block
fill 494 260 512 496 265 512 minecraft:quartz_block
fill 502 260 550 504 265 550 minecraft:quartz_block
fill 506 260 512 508 265 512 minecraft:quartz_block
fill 510 260 520 510 265 522 minecraft:quartz_block
fill 510 260 532 510 265 534 minecraft:quartz_block
fill 510 260 544 510 265 546 minecraft:quartz_block
fill 473 261 545 474 261 545 minecraft:smooth_quartz
setblock 473 261 548 minecraft:smooth_quartz
fill 474 261 549 475 261 549 minecraft:smooth_quartz
setblock 476 261 545 minecraft:smooth_quartz
setblock 476 261 548 minecraft:smooth_quartz
fill 477 261 546 477 261 547 minecraft:smooth_quartz
fill 504 261 546 504 261 548 minecraft:smooth_quartz
fill 505 261 545 507 261 545 minecraft:smooth_quartz
setblock 505 261 549 minecraft:smooth_quartz
fill 507 261 549 508 261 549 minecraft:smooth_quartz
setblock 508 261 546 minecraft:smooth_quartz
setblock 508 261 548 minecraft:smooth_quartz
fill 471 265 514 471 265 519 minecraft:smooth_quartz
fill 471 265 526 471 265 531 minecraft:smooth_quartz
fill 471 265 538 471 265 543 minecraft:smooth_quartz
fill 471 265 550 471 265 551 minecraft:smooth_quartz
fill 472 265 551 475 265 551 minecraft:smooth_quartz
fill 475 265 511 480 265 511 minecraft:smooth_quartz
fill 482 265 551 487 265 551 minecraft:smooth_quartz
fill 487 265 511 492 265 511 minecraft:smooth_quartz
fill 494 265 551 499 265 551 minecraft:smooth_quartz
fill 499 265 511 504 265 511 minecraft:smooth_quartz
fill 506 265 551 511 265 551 minecraft:smooth_quartz
fill 509 265 530 509 266 536 minecraft:gold_block
fill 511 265 511 511 265 516 minecraft:smooth_quartz
fill 511 265 523 511 265 528 minecraft:smooth_quartz
fill 511 265 535 511 265 540 minecraft:smooth_quartz
fill 511 265 547 511 265 550 minecraft:smooth_quartz
fill 470 266 516 470 271 519 minecraft:pearlescent_froglight
fill 470 266 528 470 271 531 minecraft:pearlescent_froglight
fill 470 266 540 470 271 543 minecraft:pearlescent_froglight
fill 470 266 552 473 271 552 minecraft:pearlescent_froglight
setblock 473 266 513 minecraft:light[level=14]
setblock 473 266 521 minecraft:light[level=14]
setblock 473 266 529 minecraft:light[level=14]
setblock 473 266 537 minecraft:light[level=14]
setblock 473 266 545 minecraft:light[level=14]
fill 477 266 510 480 271 510 minecraft:pearlescent_froglight
setblock 481 266 513 minecraft:light[level=14]
setblock 481 266 521 minecraft:light[level=14]
setblock 481 266 529 minecraft:light[level=14]
setblock 481 266 537 minecraft:light[level=14]
setblock 481 266 545 minecraft:light[level=14]
fill 482 266 552 485 271 552 minecraft:pearlescent_froglight
fill 489 266 510 492 271 510 minecraft:pearlescent_froglight
setblock 489 266 513 minecraft:light[level=14]
setblock 489 266 521 minecraft:light[level=14]
setblock 489 266 529 minecraft:light[level=14]
setblock 489 266 537 minecraft:light[level=14]
setblock 489 266 545 minecraft:light[level=14]
fill 494 266 552 497 271 552 minecraft:pearlescent_froglight
setblock 497 266 513 minecraft:light[level=14]
setblock 497 266 521 minecraft:light[level=14]
setblock 497 266 529 minecraft:light[level=14]
setblock 497 266 537 minecraft:light[level=14]
setblock 497 266 545 minecraft:light[level=14]
fill 501 266 510 504 271 510 minecraft:pearlescent_froglight
setblock 505 266 513 minecraft:light[level=14]
setblock 505 266 521 minecraft:light[level=14]
setblock 505 266 529 minecraft:light[level=14]
setblock 505 266 537 minecraft:light[level=14]
setblock 505 266 545 minecraft:light[level=14]
fill 506 266 552 509 271 552 minecraft:pearlescent_froglight
fill 512 266 511 512 271 514 minecraft:pearlescent_froglight
fill 512 266 523 512 271 526 minecraft:pearlescent_froglight
fill 512 266 535 512 271 538 minecraft:pearlescent_froglight
fill 512 266 547 512 271 550 minecraft:pearlescent_froglight
fill 483 268 531 483 269 532 minecraft:gold_block
fill 473 269 545 474 269 545 minecraft:smooth_quartz
setblock 473 269 548 minecraft:smooth_quartz
fill 474 269 549 475 269 549 minecraft:smooth_quartz
setblock 476 269 545 minecraft:smooth_quartz
setblock 476 269 548 minecraft:smooth_quartz
fill 477 269 546 477 269 547 minecraft:smooth_quartz
fill 504 269 546 504 269 548 minecraft:smooth_quartz
fill 505 269 545 507 269 545 minecraft:smooth_quartz
setblock 505 269 549 minecraft:smooth_quartz
fill 507 269 549 508 269 549 minecraft:smooth_quartz
setblock 508 269 546 minecraft:smooth_quartz
setblock 508 269 548 minecraft:smooth_quartz
fill 470 272 516 470 285 516 minecraft:white_concrete
fill 470 272 517 470 272 518 minecraft:pearlescent_froglight
fill 470 272 519 470 285 519 minecraft:white_concrete
fill 470 272 528 470 285 528 minecraft:white_concrete
fill 470 272 529 470 272 530 minecraft:pearlescent_froglight
fill 470 272 531 470 285 531 minecraft:white_concrete
fill 470 272 540 470 285 540 minecraft:white_concrete
fill 470 272 541 470 272 542 minecraft:pearlescent_froglight
fill 470 272 543 470 285 543 minecraft:white_concrete
fill 470 272 552 470 285 552 minecraft:white_concrete
fill 471 272 552 472 272 552 minecraft:pearlescent_froglight
fill 473 272 545 474 273 545 minecraft:gold_block
fill 473 272 548 473 273 548 minecraft:gold_block
fill 473 272 552 473 285 552 minecraft:white_concrete
fill 474 272 549 475 273 549 minecraft:gold_block
fill 476 272 545 476 273 545 minecraft:gold_block
fill 476 272 548 476 273 548 minecraft:gold_block
fill 477 272 510 477 285 510 minecraft:white_concrete
fill 477 272 547 477 273 547 minecraft:gold_block
fill 478 272 510 479 272 510 minecraft:pearlescent_froglight
fill 480 272 510 480 285 510 minecraft:white_concrete
fill 482 272 552 482 285 552 minecraft:white_concrete
fill 483 272 552 484 272 552 minecraft:pearlescent_froglight
fill 485 272 552 485 285 552 minecraft:white_concrete
fill 489 272 510 489 285 510 minecraft:white_concrete
fill 490 272 510 491 272 510 minecraft:pearlescent_froglight
fill 492 272 510 492 285 510 minecraft:white_concrete
fill 494 272 552 494 285 552 minecraft:white_concrete
fill 495 272 552 496 272 552 minecraft:pearlescent_froglight
fill 497 272 552 497 285 552 minecraft:white_concrete
fill 501 272 510 501 285 510 minecraft:white_concrete
fill 502 272 510 503 272 510 minecraft:pearlescent_froglight
fill 504 272 510 504 285 510 minecraft:white_concrete
fill 504 272 547 504 273 548 minecraft:gold_block
fill 505 272 549 505 273 549 minecraft:gold_block
fill 506 272 545 507 273 545 minecraft:gold_block
fill 506 272 552 506 285 552 minecraft:white_concrete
fill 507 272 549 507 273 549 minecraft:gold_block
fill 507 272 552 508 272 552 minecraft:pearlescent_froglight
fill 508 272 546 508 273 546 minecraft:gold_block
fill 508 272 548 508 273 548 minecraft:gold_block
fill 509 272 552 509 285 552 minecraft:white_concrete
fill 512 272 511 512 285 511 minecraft:white_concrete
fill 512 272 512 512 272 513 minecraft:pearlescent_froglight
fill 512 272 514 512 285 514 minecraft:white_concrete
fill 512 272 523 512 285 523 minecraft:white_concrete
fill 512 272 524 512 272 525 minecraft:pearlescent_froglight
fill 512 272 526 512 285 526 minecraft:white_concrete
fill 512 272 535 512 285 535 minecraft:white_concrete
fill 512 272 536 512 272 537 minecraft:pearlescent_froglight
fill 512 272 538 512 285 538 minecraft:white_concrete
fill 512 272 547 512 285 547 minecraft:white_concrete
fill 512 272 548 512 272 549 minecraft:pearlescent_froglight
fill 512 272 550 512 285 550 minecraft:white_concrete
fill 470 273 517 470 285 518 minecraft:white_concrete
fill 470 273 529 470 285 530 minecraft:white_concrete
fill 470 273 541 470 285 542 minecraft:white_concrete
fill 471 273 552 472 285 552 minecraft:white_concrete
fill 478 273 510 479 285 510 minecraft:white_concrete
fill 483 273 552 484 285 552 minecraft:white_concrete
fill 490 273 510 491 285 510 minecraft:white_concrete
fill 495 273 552 496 285 552 minecraft:white_concrete
fill 502 273 510 503 285 510 minecraft:white_concrete
fill 507 273 552 508 285 552 minecraft:white_concrete
fill 512 273 512 512 285 513 minecraft:white_concrete
fill 512 273 524 512 285 525 minecraft:white_concrete
fill 512 273 536 512 285 537 minecraft:white_concrete
fill 512 273 548 512 285 549 minecraft:white_concrete
setblock 473 274 513 minecraft:light[level=14]
setblock 473 274 521 minecraft:light[level=14]
setblock 473 274 529 minecraft:light[level=14]
setblock 473 274 537 minecraft:light[level=14]
setblock 473 274 545 minecraft:light[level=14]
setblock 481 274 513 minecraft:light[level=14]
setblock 481 274 521 minecraft:light[level=14]
setblock 481 274 529 minecraft:light[level=14]
setblock 481 274 537 minecraft:light[level=14]
setblock 481 274 545 minecraft:light[level=14]
setblock 489 274 513 minecraft:light[level=14]
setblock 489 274 521 minecraft:light[level=14]
setblock 489 274 529 minecraft:light[level=14]
setblock 489 274 537 minecraft:light[level=14]
setblock 489 274 545 minecraft:light[level=14]
setblock 497 274 513 minecraft:light[level=14]
setblock 497 274 521 minecraft:light[level=14]
setblock 497 274 529 minecraft:light[level=14]
setblock 497 274 537 minecraft:light[level=14]
setblock 497 274 545 minecraft:light[level=14]
setblock 505 274 513 minecraft:light[level=14]
setblock 505 274 521 minecraft:light[level=14]
setblock 505 274 529 minecraft:light[level=14]
setblock 505 274 537 minecraft:light[level=14]
setblock 505 274 545 minecraft:light[level=14]
fill 487 278 531 489 278 533 minecraft:redstone_block
fill 491 278 523 493 278 525 minecraft:redstone_block
fill 495 278 531 497 278 533 minecraft:redstone_block
fill 481 279 526 481 281 532 minecraft:gold_block
fill 482 279 524 482 281 528 minecraft:gold_block
fill 482 279 529 490 279 529 minecraft:white_stained_glass
fill 482 279 530 482 281 534 minecraft:gold_block
fill 483 279 522 483 281 524 minecraft:gold_block
fill 483 279 525 490 279 528 minecraft:white_stained_glass
fill 483 279 530 486 279 533 minecraft:white_stained_glass
fill 483 279 534 483 281 536 minecraft:gold_block
fill 484 279 521 484 281 522 minecraft:gold_block
fill 484 279 523 490 279 524 minecraft:white_stained_glass
fill 484 279 534 500 279 535 minecraft:white_stained_glass
fill 484 279 536 484 281 537 minecraft:gold_block
fill 485 279 520 485 281 521 minecraft:gold_block
fill 485 279 522 499 279 522 minecraft:white_stained_glass
fill 485 279 536 499 280 536 minecraft:white_stained_glass
fill 485 279 537 485 281 538 minecraft:gold_block
fill 486 279 520 487 281 520 minecraft:gold_block
fill 486 279 521 498 280 521 minecraft:white_stained_glass
fill 486 279 537 498 280 537 minecraft:white_stained_glass
fill 486 279 538 487 281 538 minecraft:gold_block
fill 487 279 519 491 281 519 minecraft:gold_block
fill 487 279 530 490 279 530 minecraft:white_stained_glass
fill 487 279 539 491 281 539 minecraft:gold_block
fill 488 279 520 496 280 520 minecraft:white_stained_glass
fill 488 279 538 496 280 538 minecraft:white_stained_glass
fill 489 279 518 495 281 518 minecraft:gold_block
fill 489 279 540 495 281 540 minecraft:gold_block
fill 490 279 531 494 279 533 minecraft:white_stained_glass
fill 491 279 526 501 279 527 minecraft:white_stained_glass
fill 492 279 519 492 280 519 minecraft:white_stained_glass
fill 492 279 539 492 280 539 minecraft:white_stained_glass
fill 493 279 519 497 281 519 minecraft:gold_block
fill 493 279 539 497 281 539 minecraft:gold_block
fill 494 279 523 500 279 525 minecraft:white_stained_glass
fill 494 279 528 501 279 530 minecraft:white_stained_glass
fill 497 279 520 499 281 520 minecraft:gold_block
fill 497 279 538 499 281 538 minecraft:gold_block
fill 498 279 531 501 279 533 minecraft:white_stained_glass
fill 499 279 521 500 281 521 minecraft:gold_block
fill 499 279 537 500 281 537 minecraft:gold_block
fill 500 279 522 501 281 522 minecraft:gold_block
fill 500 279 536 501 281 536 minecraft:gold_block
fill 501 279 523 501 281 524 minecraft:gold_block
fill 501 279 525 501 280 525 minecraft:white_stained_glass
fill 501 279 534 501 281 535 minecraft:gold_block
fill 502 279 524 502 281 528 minecraft:gold_block
fill 502 279 529 502 280 529 minecraft:white_stained_glass
fill 502 279 530 502 281 534 minecraft:gold_block
fill 503 279 526 503 281 532 minecraft:gold_block
fill 471 280 511 480 280 551 minecraft:quartz_block
fill 481 280 511 481 280 524 minecraft:quartz_block
setblock 481 280 525 minecraft:gold_block
setblock 481 280 533 minecraft:gold_block
fill 481 280 534 481 280 551 minecraft:quartz_block
fill 482 280 511 482 280 522 minecraft:quartz_block
setblock 482 280 523 minecraft:gold_block
fill 482 280 529 489 280 529 minecraft:white_stained_glass
setblock 482 280 535 minecraft:gold_block
fill 482 280 536 482 280 551 minecraft:quartz_block
fill 483 280 511 483 280 521 minecraft:quartz_block
fill 483 280 525 489 280 528 minecraft:white_stained_glass
fill 483 280 530 485 280 533 minecraft:white_stained_glass
fill 483 280 537 483 280 551 minecraft:quartz_block
fill 484 280 511 484 280 520 minecraft:quartz_block
fill 484 280 523 489 280 524 minecraft:white_stained_glass
fill 484 280 534 485 280 535 minecraft:white_stained_glass
fill 484 280 538 484 280 551 minecraft:quartz_block
fill 485 280 511 485 280 519 minecraft:quartz_block
fill 485 280 522 489 280 522 minecraft:white_stained_glass
fill 485 280 539 485 280 551 minecraft:quartz_block
fill 486 280 511 487 280 518 minecraft:quartz_block
setblock 486 280 519 minecraft:gold_block
fill 486 280 530 486 280 534 minecraft:pearlescent_froglight
fill 486 280 535 500 280 535 minecraft:white_stained_glass
setblock 486 280 539 minecraft:gold_block
fill 486 280 540 487 280 551 minecraft:quartz_block
fill 487 280 530 490 280 530 minecraft:pearlescent_froglight
fill 487 280 531 489 280 533 minecraft:quartz_block
fill 487 280 534 490 280 534 minecraft:pearlescent_froglight
fill 488 280 511 511 280 517 minecraft:quartz_block
setblock 488 280 518 minecraft:gold_block
setblock 488 280 540 minecraft:gold_block
fill 488 280 541 511 280 551 minecraft:quartz_block
fill 490 280 522 490 280 529 minecraft:pearlescent_froglight
fill 490 280 531 490 280 533 minecraft:pearlescent_froglight
fill 491 280 522 494 280 522 minecraft:pearlescent_froglight
fill 491 280 523 493 280 525 minecraft:quartz_block
fill 491 280 526 494 280 527 minecraft:pearlescent_froglight
fill 491 280 531 494 280 531 minecraft:pearlescent_froglight
fill 491 280 532 493 280 534 minecraft:white_stained_glass
fill 494 280 523 494 280 525 minecraft:pearlescent_froglight
fill 494 280 528 494 280 530 minecraft:pearlescent_froglight
fill 494 280 532 494 280 534 minecraft:pearlescent_froglight
fill 495 280 522 499 280 529 minecraft:white_stained_glass
fill 495 280 530 498 280 530 minecraft:pearlescent_froglight
fill 495 280 531 497 280 533 minecraft:quartz_block
fill 495 280 534 498 280 534 minecraft:pearlescent_froglight
setblock 496 280 518 minecraft:gold_block
setblock 496 280 540 minecraft:gold_block
fill 497 280 518 511 280 518 minecraft:quartz_block
fill 497 280 540 511 280 540 minecraft:quartz_block
setblock 498 280 519 minecraft:gold_block
fill 498 280 531 498 280 533 minecraft:pearlescent_froglight
setblock 498 280 539 minecraft:gold_block
fill 499 280 519 511 280 519 minecraft:quartz_block
fill 499 280 530 500 280 534 minecraft:white_stained_glass
fill 499 280 539 511 280 539 minecraft:quartz_block
fill 500 280 520 511 280 520 minecraft:quartz_block
fill 500 280 523 500 280 529 minecraft:white_stained_glass
fill 500 280 538 511 280 538 minecraft:quartz_block
fill 501 280 521 511 280 521 minecraft:quartz_block
fill 501 280 526 501 280 533 minecraft:white_stained_glass
fill 501 280 537 511 280 537 minecraft:quartz_block
fill 502 280 522 511 280 522 minecraft:quartz_block
setblock 502 280 523 minecraft:gold_block
setblock 502 280 535 minecraft:gold_block
fill 502 280 536 511 280 536 minecraft:quartz_block
fill 503 280 523 511 280 524 minecraft:quartz_block
setblock 503 280 525 minecraft:gold_block
setblock 503 280 533 minecraft:gold_block
fill 503 280 534 511 280 535 minecraft:quartz_block
fill 504 280 525 511 280 533 minecraft:quartz_block
fill 482 281 529 483 281 529 minecraft:gold_block
fill 483 281 525 483 281 528 minecraft:gold_block
fill 483 281 530 483 281 533 minecraft:gold_block
fill 484 281 523 484 281 526 minecraft:gold_block
fill 484 281 532 484 281 535 minecraft:gold_block
fill 485 281 522 485 281 524 minecraft:gold_block
fill 485 281 534 485 281 536 minecraft:gold_block
fill 486 281 521 487 281 522 minecraft:gold_block
fill 486 281 536 487 281 537 minecraft:gold_block
fill 488 281 520 489 281 521 minecraft:gold_block
fill 488 281 537 489 281 538 minecraft:gold_block
fill 490 281 520 496 281 520 minecraft:gold_block
fill 490 281 538 496 281 538 minecraft:gold_block
setblock 492 281 519 minecraft:gold_block
setblock 492 281 539 minecraft:gold_block
fill 495 281 521 498 281 521 minecraft:gold_block
fill 495 281 537 498 281 537 minecraft:gold_block
fill 497 281 522 499 281 522 minecraft:gold_block
fill 497 281 536 499 281 536 minecraft:gold_block
fill 499 281 523 500 281 524 minecraft:gold_block
fill 499 281 534 500 281 535 minecraft:gold_block
fill 500 281 525 501 281 526 minecraft:gold_block
fill 500 281 532 501 281 533 minecraft:gold_block
fill 501 281 527 501 281 531 minecraft:gold_block
setblock 502 281 529 minecraft:gold_block
setblock 473 282 513 minecraft:light[level=14]
setblock 473 282 521 minecraft:light[level=14]
setblock 473 282 529 minecraft:light[level=14]
setblock 473 282 537 minecraft:light[level=14]
setblock 473 282 545 minecraft:light[level=14]
setblock 481 282 513 minecraft:light[level=14]
setblock 481 282 521 minecraft:light[level=14]
setblock 481 282 529 minecraft:light[level=14]
setblock 481 282 537 minecraft:light[level=14]
setblock 481 282 545 minecraft:light[level=14]
setblock 489 282 513 minecraft:light[level=14]
setblock 489 282 521 minecraft:light[level=14]
setblock 489 282 529 minecraft:light[level=14]
setblock 489 282 537 minecraft:light[level=14]
setblock 489 282 545 minecraft:light[level=14]
setblock 497 282 513 minecraft:light[level=14]
setblock 497 282 521 minecraft:light[level=14]
setblock 497 282 529 minecraft:light[level=14]
setblock 497 282 537 minecraft:light[level=14]
setblock 497 282 545 minecraft:light[level=14]
setblock 505 282 513 minecraft:light[level=14]
setblock 505 282 521 minecraft:light[level=14]
setblock 505 282 529 minecraft:light[level=14]
setblock 505 282 537 minecraft:light[level=14]
setblock 505 282 545 minecraft:light[level=14]
fill 471 284 511 473 300 511 minecraft:quartz_block
fill 471 284 521 471 300 523 minecraft:quartz_block
fill 471 284 533 471 300 535 minecraft:quartz_block
fill 471 284 545 471 300 547 minecraft:quartz_block
fill 472 284 520 472 285 522 minecraft:quartz_block
fill 472 284 532 472 285 534 minecraft:quartz_block
fill 472 284 544 472 285 546 minecraft:quartz_block
fill 477 284 551 479 300 551 minecraft:quartz_block
fill 478 284 550 480 285 550 minecraft:quartz_block
fill 482 284 512 484 285 512 minecraft:quartz_block
fill 483 284 511 485 300 511 minecraft:quartz_block
setblock 485 284 524 minecraft:white_wool
fill 489 284 551 491 300 551 minecraft:quartz_block
fill 490 284 550 492 285 550 minecraft:quartz_block
fill 494 284 512 496 285 512 minecraft:quartz_block
fill 495 284 511 497 300 511 minecraft:quartz_block
fill 501 284 525 502 284 526 minecraft:white_wool
fill 501 284 551 503 300 551 minecraft:quartz_block
fill 502 284 550 504 285 550 minecraft:quartz_block
fill 505 284 515 505 284 517 minecraft:smooth_quartz
fill 506 284 512 508 285 512 minecraft:quartz_block
fill 506 284 514 509 284 514 minecraft:smooth_quartz
fill 506 284 515 508 300 517 minecraft:quartz_block
fill 506 284 518 508 284 518 minecraft:smooth_quartz
fill 507 284 511 509 300 511 minecraft:quartz_block
setblock 509 284 515 minecraft:smooth_quartz
fill 509 284 516 509 300 516 minecraft:quartz_block
setblock 509 284 517 minecraft:smooth_quartz
fill 510 284 520 510 285 522 minecraft:quartz_block
fill 510 284 532 510 285 534 minecraft:quartz_block
fill 510 284 544 510 285 546 minecraft:quartz_block
fill 511 284 519 511 300 521 minecraft:quartz_block
fill 511 284 531 511 300 533 minecraft:quartz_block
fill 511 284 543 511 300 545 minecraft:quartz_block
fill 471 285 514 471 285 519 minecraft:smooth_quartz
fill 471 285 526 471 285 531 minecraft:smooth_quartz
fill 471 285 538 471 285 543 minecraft:smooth_quartz
fill 471 285 550 471 285 551 minecraft:smooth_quartz
fill 472 285 551 475 285 551 minecraft:smooth_quartz
fill 475 285 511 480 285 511 minecraft:smooth_quartz
fill 482 285 551 487 285 551 minecraft:smooth_quartz
fill 487 285 511 492 285 511 minecraft:smooth_quartz
fill 494 285 551 499 285 551 minecraft:smooth_quartz
fill 499 285 511 504 285 511 minecraft:smooth_quartz
fill 506 285 551 511 285 551 minecraft:smooth_quartz
fill 511 285 511 511 285 516 minecraft:smooth_quartz
fill 511 285 523 511 285 528 minecraft:smooth_quartz
fill 511 285 535 511 285 540 minecraft:smooth_quartz
fill 511 285 547 511 285 550 minecraft:smooth_quartz
fill 470 286 516 470 291 519 minecraft:pearlescent_froglight
fill 470 286 528 470 291 531 minecraft:pearlescent_froglight
fill 470 286 540 470 291 543 minecraft:pearlescent_froglight
fill 470 286 552 473 291 552 minecraft:pearlescent_froglight
fill 477 286 510 480 291 510 minecraft:pearlescent_froglight
fill 482 286 552 485 291 552 minecraft:pearlescent_froglight
fill 489 286 510 492 291 510 minecraft:pearlescent_froglight
fill 494 286 552 497 291 552 minecraft:pearlescent_froglight
fill 501 286 510 504 291 510 minecraft:pearlescent_froglight
fill 506 286 552 509 291 552 minecraft:pearlescent_froglight
fill 512 286 511 512 291 514 minecraft:pearlescent_froglight
fill 512 286 523 512 291 526 minecraft:pearlescent_froglight
fill 512 286 535 512 291 538 minecraft:pearlescent_froglight
fill 512 286 547 512 291 550 minecraft:pearlescent_froglight
setblock 473 290 513 minecraft:light[level=14]
setblock 473 290 521 minecraft:light[level=14]
setblock 473 290 529 minecraft:light[level=14]
setblock 473 290 537 minecraft:light[level=14]
setblock 473 290 545 minecraft:light[level=14]
setblock 481 290 513 minecraft:light[level=14]
setblock 481 290 521 minecraft:light[level=14]
setblock 481 290 529 minecraft:light[level=14]
setblock 481 290 537 minecraft:light[level=14]
setblock 481 290 545 minecraft:light[level=14]
setblock 489 290 513 minecraft:light[level=14]
setblock 489 290 521 minecraft:light[level=14]
setblock 489 290 529 minecraft:light[level=14]
setblock 489 290 537 minecraft:light[level=14]
setblock 489 290 545 minecraft:light[level=14]
setblock 497 290 513 minecraft:light[level=14]
setblock 497 290 521 minecraft:light[level=14]
setblock 497 290 529 minecraft:light[level=14]
setblock 497 290 537 minecraft:light[level=14]
setblock 497 290 545 minecraft:light[level=14]
setblock 505 290 513 minecraft:light[level=14]
setblock 505 290 521 minecraft:light[level=14]
setblock 505 290 529 minecraft:light[level=14]
setblock 505 290 537 minecraft:light[level=14]
setblock 505 290 545 minecraft:light[level=14]
fill 470 292 516 470 307 516 minecraft:white_concrete
fill 470 292 517 470 292 518 minecraft:pearlescent_froglight
fill 470 292 519 470 307 519 minecraft:white_concrete
fill 470 292 528 470 307 528 minecraft:white_concrete
fill 470 292 529 470 292 530 minecraft:pearlescent_froglight
fill 470 292 531 470 307 531 minecraft:white_concrete
fill 470 292 540 470 307 540 minecraft:white_concrete
fill 470 292 541 470 292 542 minecraft:pearlescent_froglight
fill 470 292 543 470 307 543 minecraft:white_concrete
fill 470 292 552 470 307 552 minecraft:white_concrete
fill 471 292 552 472 292 552 minecraft:pearlescent_froglight
fill 473 292 552 473 307 552 minecraft:white_concrete
fill 477 292 510 477 307 510 minecraft:white_concrete
fill 478 292 510 479 292 510 minecraft:pearlescent_froglight
fill 480 292 510 480 307 510 minecraft:white_concrete
fill 482 292 552 482 307 552 minecraft:white_concrete
fill 483 292 552 484 292 552 minecraft:pearlescent_froglight
fill 485 292 552 485 307 552 minecraft:white_concrete
fill 489 292 510 489 307 510 minecraft:white_concrete
fill 490 292 510 491 292 510 minecraft:pearlescent_froglight
fill 492 292 510 492 307 510 minecraft:white_concrete
fill 494 292 552 494 307 552 minecraft:white_concrete
fill 495 292 552 496 292 552 minecraft:pearlescent_froglight
fill 497 292 552 497 307 552 minecraft:white_concrete
fill 501 292 510 501 307 510 minecraft:white_concrete
fill 502 292 510 503 292 510 minecraft:pearlescent_froglight
fill 504 292 510 504 307 510 minecraft:white_concrete
fill 505 292 515 505 292 517 minecraft:smooth_quartz
fill 506 292 514 509 292 514 minecraft:smooth_quartz
fill 506 292 518 508 292 518 minecraft:smooth_quartz
fill 506 292 552 506 307 552 minecraft:white_concrete
fill 507 292 552 508 292 552 minecraft:pearlescent_froglight
setblock 509 292 515 minecraft:smooth_quartz
setblock 509 292 517 minecraft:smooth_quartz
fill 509 292 552 509 307 552 minecraft:white_concrete
fill 512 292 511 512 307 511 minecraft:white_concrete
fill 512 292 512 512 292 513 minecraft:pearlescent_froglight
fill 512 292 514 512 307 514 minecraft:white_concrete
fill 512 292 523 512 307 523 minecraft:white_concrete
fill 512 292 524 512 292 525 minecraft:pearlescent_froglight
fill 512 292 526 512 307 526 minecraft:white_concrete
fill 512 292 535 512 307 535 minecraft:white_concrete
fill 512 292 536 512 292 537 minecraft:pearlescent_froglight
fill 512 292 538 512 307 538 minecraft:white_concrete
fill 512 292 547 512 307 547 minecraft:white_concrete
fill 512 292 548 512 292 549 minecraft:pearlescent_froglight
fill 512 292 550 512 307 550 minecraft:white_concrete
fill 470 293 517 470 307 518 minecraft:white_concrete
fill 470 293 529 470 307 530 minecraft:white_concrete
fill 470 293 541 470 307 542 minecraft:white_concrete
fill 471 293 552 472 307 552 minecraft:white_concrete
fill 478 293 510 479 307 510 minecraft:white_concrete
fill 483 293 552 484 307 552 minecraft:white_concrete
fill 490 293 510 491 307 510 minecraft:white_concrete
fill 495 293 552 496 307 552 minecraft:white_concrete
fill 496 293 513 496 294 513 minecraft:gold_block
fill 502 293 510 503 307 510 minecraft:white_concrete
fill 507 293 552 508 307 552 minecraft:white_concrete
fill 512 293 512 512 307 513 minecraft:white_concrete
fill 512 293 524 512 307 525 minecraft:white_concrete
fill 512 293 536 512 307 537 minecraft:white_concrete
fill 512 293 548 512 307 549 minecraft:white_concrete
fill 480 295 536 480 296 537 minecraft:gold_block
setblock 473 298 513 minecraft:light[level=14]
setblock 473 298 521 minecraft:light[level=14]
setblock 473 298 529 minecraft:light[level=14]
setblock 473 298 537 minecraft:light[level=14]
setblock 473 298 545 minecraft:light[level=14]
setblock 481 298 513 minecraft:light[level=14]
setblock 481 298 521 minecraft:light[level=14]
setblock 481 298 529 minecraft:light[level=14]
setblock 481 298 537 minecraft:light[level=14]
setblock 481 298 545 minecraft:light[level=14]
setblock 489 298 513 minecraft:light[level=14]
setblock 489 298 521 minecraft:light[level=14]
setblock 489 298 529 minecraft:light[level=14]
setblock 489 298 537 minecraft:light[level=14]
setblock 489 298 545 minecraft:light[level=14]
setblock 497 298 513 minecraft:light[level=14]
setblock 497 298 521 minecraft:light[level=14]
setblock 497 298 529 minecraft:light[level=14]
setblock 497 298 537 minecraft:light[level=14]
setblock 497 298 545 minecraft:light[level=14]
fill 500 298 529 501 299 530 minecraft:white_wool
setblock 505 298 513 minecraft:light[level=14]
setblock 505 298 521 minecraft:light[level=14]
setblock 505 298 529 minecraft:light[level=14]
setblock 505 298 537 minecraft:light[level=14]
setblock 505 298 545 minecraft:light[level=14]
fill 494 299 542 495 300 543 minecraft:gold_block
fill 505 299 516 505 300 516 minecraft:gold_block
fill 506 299 514 508 300 514 minecraft:gold_block
fill 507 299 518 508 300 518 minecraft:gold_block
fill 509 299 515 509 300 515 minecraft:gold_block
fill 509 299 517 509 300 517 minecraft:gold_block
fill 472 300 520 472 300 522 minecraft:quartz_block
fill 472 300 532 472 300 534 minecraft:quartz_block
fill 472 300 544 472 300 546 minecraft:quartz_block
fill 478 300 550 480 300 550 minecraft:quartz_block
fill 482 300 512 484 300 512 minecraft:quartz_block
fill 490 300 550 492 300 550 minecraft:quartz_block
fill 494 300 512 496 300 512 minecraft:quartz_block
fill 502 300 550 504 300 550 minecraft:quartz_block
fill 506 300 512 508 300 512 minecraft:quartz_block
fill 510 300 520 510 300 522 minecraft:quartz_block
fill 510 300 532 510 300 534 minecraft:quartz_block
fill 510 300 544 510 300 546 minecraft:quartz_block
