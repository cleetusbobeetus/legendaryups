fill 8 77 362 8 79 362 minecraft:honeycomb_block
setblock 10 77 324 minecraft:yellow_terracotta
setblock 11 77 323 minecraft:yellow_terracotta
setblock 11 77 324 minecraft:honeycomb_block
setblock 11 77 363 minecraft:yellow_terracotta
fill 12 77 323 12 78 323 minecraft:honeycomb_block
fill 12 77 363 12 78 363 minecraft:honeycomb_block
setblock 16 77 323 minecraft:yellow_terracotta
setblock 17 77 323 minecraft:honeycomb_block
setblock 20 77 324 minecraft:yellow_terracotta
fill 21 77 322 21 92 322 minecraft:honeycomb_block
setblock 21 77 323 minecraft:yellow_terracotta
fill 21 77 324 21 80 324 minecraft:honeycomb_block
setblock 21 77 363 minecraft:yellow_terracotta
fill 22 77 323 22 80 323 minecraft:honeycomb_block
fill 22 77 325 23 77 325 minecraft:honeycomb_block
fill 22 77 326 22 84 330 minecraft:honey_block
fill 22 77 363 22 79 363 minecraft:honeycomb_block
fill 23 77 331 23 84 331 minecraft:honey_block
setblock 24 77 325 minecraft:yellow_terracotta
fill 24 77 326 27 77 326 minecraft:honeycomb_block
fill 24 77 327 24 88 328 minecraft:honey_block
fill 24 77 332 24 84 332 minecraft:honey_block
setblock 25 77 324 minecraft:yellow_terracotta
fill 25 77 325 28 77 325 minecraft:honeycomb_block
setblock 26 77 323 minecraft:yellow_terracotta
fill 26 77 324 26 80 324 minecraft:honeycomb_block
setblock 26 77 363 minecraft:yellow_terracotta
fill 27 77 323 27 80 323 minecraft:honeycomb_block
setblock 27 77 362 minecraft:yellow_terracotta
fill 27 77 363 27 80 363 minecraft:honeycomb_block
setblock 28 77 326 minecraft:yellow_terracotta
setblock 28 77 362 minecraft:honeycomb_block
setblock 29 77 325 minecraft:yellow_terracotta
fill 29 77 326 29 79 326 minecraft:honeycomb_block
setblock 30 77 324 minecraft:yellow_terracotta
fill 30 77 325 30 80 325 minecraft:honeycomb_block
fill 30 77 332 30 84 332 minecraft:honey_block
setblock 31 77 323 minecraft:yellow_terracotta
fill 31 77 324 31 80 324 minecraft:honeycomb_block
fill 31 77 331 31 84 331 minecraft:honey_block
setblock 31 77 363 minecraft:yellow_terracotta
fill 31 77 364 31 104 364 minecraft:honeycomb_block
fill 32 77 323 32 80 323 minecraft:honeycomb_block
fill 32 77 330 32 84 330 minecraft:honey_block
fill 32 77 363 32 79 363 minecraft:honeycomb_block
setblock 34 77 325 minecraft:yellow_terracotta
setblock 35 77 324 minecraft:yellow_terracotta
fill 35 77 325 35 78 325 minecraft:honeycomb_block
setblock 36 77 323 minecraft:yellow_terracotta
fill 36 77 324 36 80 324 minecraft:honeycomb_block
setblock 36 77 363 minecraft:yellow_terracotta
fill 37 77 323 37 80 323 minecraft:honeycomb_block
fill 37 77 363 37 79 363 minecraft:honeycomb_block
fill 38 77 322 38 198 322 minecraft:honeycomb_block
setblock 39 77 325 minecraft:yellow_terracotta
fill 39 77 326 39 80 326 minecraft:honeycomb_block
setblock 40 77 324 minecraft:yellow_terracotta
fill 40 77 325 40 80 325 minecraft:honeycomb_block
setblock 40 77 329 minecraft:yellow_terracotta
setblock 41 77 323 minecraft:yellow_terracotta
fill 41 77 324 41 80 324 minecraft:honeycomb_block
setblock 41 77 328 minecraft:yellow_terracotta
fill 41 77 329 41 80 329 minecraft:honeycomb_block
setblock 41 77 332 minecraft:honeycomb_block
setblock 41 77 338 minecraft:honey_block
setblock 41 77 342 minecraft:honeycomb_block
setblock 41 77 343 minecraft:yellow_terracotta
fill 41 77 344 41 80 344 minecraft:honeycomb_block
fill 41 77 346 41 77 347 minecraft:honeycomb_block
setblock 41 77 348 minecraft:yellow_terracotta
fill 41 77 349 41 80 349 minecraft:honeycomb_block
setblock 41 77 352 minecraft:honeycomb_block
setblock 41 77 353 minecraft:yellow_terracotta
fill 41 77 354 41 80 354 minecraft:honeycomb_block
setblock 41 77 357 minecraft:honeycomb_block
setblock 41 77 358 minecraft:yellow_terracotta
fill 41 77 359 41 80 359 minecraft:honeycomb_block
setblock 41 77 363 minecraft:yellow_terracotta
fill 41 77 364 41 124 364 minecraft:honeycomb_block
fill 0 78 324 3 78 324 minecraft:honeycomb_block
setblock 0 78 354 minecraft:yellow_concrete
fill 1 78 323 1 81 323 minecraft:honeycomb_block
setblock 1 78 326 minecraft:honeycomb_block
setblock 1 78 327 minecraft:yellow_terracotta
fill 1 78 328 1 81 328 minecraft:honeycomb_block
setblock 1 78 331 minecraft:honeycomb_block
fill 1 78 335 1 79 335 minecraft:honey_block
setblock 1 78 341 minecraft:honeycomb_block
setblock 1 78 342 minecraft:yellow_terracotta
fill 1 78 343 1 78 346 minecraft:honeycomb_block
setblock 1 78 347 minecraft:yellow_terracotta
fill 1 78 348 1 78 351 minecraft:honeycomb_block
setblock 1 78 352 minecraft:yellow_terracotta
fill 1 78 353 1 81 353 minecraft:honeycomb_block
setblock 1 78 357 minecraft:yellow_terracotta
fill 1 78 358 1 81 358 minecraft:honeycomb_block
setblock 1 78 362 minecraft:yellow_terracotta
fill 1 78 363 1 81 363 minecraft:honeycomb_block
setblock 2 78 326 minecraft:yellow_terracotta
fill 2 78 327 2 81 327 minecraft:honeycomb_block
fill 2 78 329 2 79 329 minecraft:honeycomb_block
fill 2 78 342 2 79 342 minecraft:honeycomb_block
setblock 2 78 345 minecraft:honeycomb_block
setblock 2 78 346 minecraft:yellow_terracotta
fill 2 78 347 2 81 347 minecraft:honeycomb_block
setblock 2 78 350 minecraft:honeycomb_block
setblock 2 78 351 minecraft:yellow_terracotta
fill 2 78 352 2 81 352 minecraft:honeycomb_block
setblock 2 78 356 minecraft:yellow_terracotta
fill 2 78 357 2 81 357 minecraft:honeycomb_block
setblock 2 78 360 minecraft:honeycomb_block
setblock 2 78 361 minecraft:yellow_terracotta
fill 2 78 362 2 81 362 minecraft:honeycomb_block
setblock 3 78 325 minecraft:yellow_terracotta
fill 3 78 326 3 79 326 minecraft:honeycomb_block
setblock 3 78 345 minecraft:yellow_terracotta
fill 3 78 346 3 81 346 minecraft:honeycomb_block
setblock 3 78 350 minecraft:yellow_terracotta
fill 3 78 351 3 81 351 minecraft:honeycomb_block
setblock 3 78 355 minecraft:yellow_terracotta
setblock 3 78 361 minecraft:honeycomb_block
setblock 4 78 324 minecraft:yellow_terracotta
fill 4 78 325 4 79 325 minecraft:honeycomb_block
setblock 4 78 345 minecraft:honeycomb_block
setblock 4 78 349 minecraft:yellow_terracotta
fill 4 78 350 4 81 350 minecraft:honeycomb_block
fill 4 78 352 4 79 352 minecraft:honeycomb_block
setblock 5 78 323 minecraft:yellow_terracotta
fill 5 78 324 5 81 324 minecraft:honeycomb_block
setblock 5 78 363 minecraft:yellow_terracotta
fill 6 78 323 6 81 323 minecraft:honeycomb_block
setblock 6 78 362 minecraft:yellow_terracotta
fill 6 78 363 6 81 363 minecraft:honeycomb_block
setblock 7 78 325 minecraft:honeycomb_block
fill 7 78 362 7 79 362 minecraft:honeycomb_block
setblock 9 78 324 minecraft:yellow_terracotta
setblock 10 78 323 minecraft:yellow_terracotta
setblock 10 78 324 minecraft:honeycomb_block
setblock 10 78 363 minecraft:yellow_terracotta
fill 11 78 323 11 79 323 minecraft:honeycomb_block
setblock 11 78 363 minecraft:honeycomb_block
setblock 17 78 363 minecraft:honey_block
setblock 20 78 323 minecraft:yellow_terracotta
fill 20 78 324 20 81 324 minecraft:honeycomb_block
fill 21 78 323 21 81 323 minecraft:honeycomb_block
fill 21 78 326 21 83 328 minecraft:honey_block
setblock 22 78 325 minecraft:honeycomb_block
setblock 23 78 325 minecraft:yellow_terracotta
fill 23 78 326 26 78 326 minecraft:honeycomb_block
fill 23 78 327 23 87 328 minecraft:honey_block
setblock 24 78 322 minecraft:yellow_concrete
setblock 24 78 324 minecraft:yellow_terracotta
fill 24 78 325 27 78 325 minecraft:honeycomb_block
setblock 25 78 323 minecraft:yellow_terracotta
fill 25 78 324 25 81 324 minecraft:honeycomb_block
setblock 25 78 363 minecraft:yellow_terracotta
fill 26 78 323 26 81 323 minecraft:honeycomb_block
fill 26 78 333 28 83 333 minecraft:honey_block
fill 26 78 363 26 80 363 minecraft:honeycomb_block
fill 27 78 322 33 84 322 minecraft:honeycomb_block
setblock 27 78 326 minecraft:yellow_terracotta
setblock 28 78 325 minecraft:yellow_terracotta
fill 28 78 326 28 80 326 minecraft:honeycomb_block
setblock 29 78 324 minecraft:yellow_terracotta
fill 29 78 325 29 81 325 minecraft:honeycomb_block
setblock 30 78 323 minecraft:yellow_terracotta
fill 30 78 324 30 81 324 minecraft:honeycomb_block
setblock 30 78 363 minecraft:yellow_terracotta
fill 31 78 323 31 81 323 minecraft:honeycomb_block
fill 31 78 363 31 79 363 minecraft:honeycomb_block
fill 32 78 326 33 83 326 minecraft:honey_block
setblock 33 78 325 minecraft:yellow_terracotta
fill 33 78 327 33 83 328 minecraft:honey_block
setblock 34 78 322 minecraft:yellow_terracotta
setblock 34 78 324 minecraft:yellow_terracotta
fill 34 78 325 34 79 325 minecraft:honeycomb_block
fill 35 78 322 35 198 322 minecraft:honeycomb_block
setblock 35 78 323 minecraft:yellow_terracotta
fill 35 78 324 35 80 324 minecraft:honeycomb_block
setblock 35 78 363 minecraft:yellow_terracotta
fill 36 78 323 36 81 323 minecraft:honeycomb_block
fill 36 78 363 36 79 363 minecraft:honeycomb_block
setblock 38 78 325 minecraft:yellow_terracotta
setblock 39 78 324 minecraft:yellow_terracotta
fill 39 78 325 39 80 325 minecraft:honeycomb_block
fill 39 78 327 40 78 327 minecraft:honeycomb_block
setblock 40 78 323 minecraft:yellow_terracotta
fill 40 78 324 40 81 324 minecraft:honeycomb_block
setblock 40 78 328 minecraft:yellow_terracotta
fill 40 78 329 40 80 330 minecraft:honeycomb_block
setblock 40 78 363 minecraft:yellow_terracotta
setblock 40 78 364 minecraft:orange_terracotta
fill 41 78 323 41 81 323 minecraft:honeycomb_block
setblock 41 78 327 minecraft:yellow_terracotta
fill 41 78 328 41 81 328 minecraft:honeycomb_block
setblock 41 78 332 minecraft:yellow_terracotta
setblock 41 78 342 minecraft:yellow_terracotta
fill 41 78 343 41 79 343 minecraft:honeycomb_block
setblock 41 78 346 minecraft:honeycomb_block
setblock 41 78 347 minecraft:yellow_terracotta
fill 41 78 348 41 81 348 minecraft:honeycomb_block
setblock 41 78 352 minecraft:yellow_terracotta
fill 41 78 353 41 81 353 minecraft:honeycomb_block
fill 41 78 355 41 78 356 minecraft:honeycomb_block
setblock 41 78 357 minecraft:yellow_terracotta
fill 41 78 358 41 81 358 minecraft:honeycomb_block
setblock 41 78 362 minecraft:yellow_terracotta
fill 41 78 363 41 81 363 minecraft:honeycomb_block
fill 0 79 324 2 79 324 minecraft:honeycomb_block
fill 0 79 354 0 163 354 minecraft:honeycomb_block
setblock 1 79 326 minecraft:yellow_terracotta
fill 1 79 327 1 82 327 minecraft:honeycomb_block
setblock 1 79 331 minecraft:yellow_terracotta
setblock 1 79 341 minecraft:yellow_terracotta
fill 1 79 342 1 79 345 minecraft:honeycomb_block
setblock 1 79 346 minecraft:yellow_terracotta
fill 1 79 347 1 79 350 minecraft:honeycomb_block
setblock 1 79 351 minecraft:yellow_terracotta
fill 1 79 352 1 82 352 minecraft:honeycomb_block
setblock 1 79 355 minecraft:honeycomb_block
setblock 1 79 356 minecraft:yellow_terracotta
fill 1 79 357 1 82 357 minecraft:honeycomb_block
setblock 1 79 361 minecraft:yellow_terracotta
fill 1 79 362 1 82 362 minecraft:honeycomb_block
setblock 2 79 325 minecraft:yellow_terracotta
fill 2 79 326 2 82 326 minecraft:honeycomb_block
fill 2 79 340 2 80 340 minecraft:brown_terracotta
setblock 2 79 345 minecraft:yellow_terracotta
fill 2 79 346 2 82 346 minecraft:honeycomb_block
setblock 2 79 350 minecraft:yellow_terracotta
fill 2 79 351 2 82 351 minecraft:honeycomb_block
setblock 2 79 355 minecraft:yellow_terracotta
fill 2 79 356 3 81 356 minecraft:honeycomb_block
setblock 2 79 360 minecraft:yellow_terracotta
fill 2 79 361 2 81 361 minecraft:honeycomb_block
setblock 3 79 324 minecraft:yellow_terracotta
setblock 3 79 325 minecraft:honeycomb_block
setblock 3 79 333 minecraft:light[level=15]
fill 3 79 339 3 80 339 minecraft:brown_terracotta
fill 3 79 341 3 80 341 minecraft:brown_terracotta
setblock 3 79 344 minecraft:yellow_terracotta
fill 3 79 345 3 81 345 minecraft:honeycomb_block
setblock 3 79 348 minecraft:honeycomb_block
setblock 3 79 349 minecraft:yellow_terracotta
fill 3 79 350 3 82 350 minecraft:honeycomb_block
setblock 3 79 354 minecraft:yellow_terracotta
fill 3 79 355 3 82 355 minecraft:honeycomb_block
setblock 3 79 357 minecraft:light[level=15]
setblock 4 79 323 minecraft:yellow_terracotta
fill 4 79 324 4 81 324 minecraft:honeycomb_block
fill 4 79 340 4 80 340 minecraft:brown_terracotta
setblock 4 79 348 minecraft:yellow_terracotta
fill 4 79 349 4 82 349 minecraft:honeycomb_block
setblock 4 79 363 minecraft:yellow_terracotta
fill 5 79 323 5 82 323 minecraft:honeycomb_block
setblock 5 79 362 minecraft:yellow_terracotta
fill 5 79 363 5 82 363 minecraft:honeycomb_block
fill 6 79 362 6 80 362 minecraft:honeycomb_block
setblock 8 79 324 minecraft:yellow_terracotta
setblock 9 79 323 minecraft:yellow_terracotta
setblock 9 79 324 minecraft:honeycomb_block
setblock 9 79 363 minecraft:yellow_terracotta
setblock 10 79 323 minecraft:honeycomb_block
setblock 10 79 363 minecraft:honeycomb_block
setblock 11 79 325 minecraft:light[level=15]
setblock 11 79 333 minecraft:light[level=15]
setblock 11 79 341 minecraft:light[level=15]
setblock 11 79 349 minecraft:light[level=15]
setblock 11 79 357 minecraft:light[level=15]
setblock 19 79 323 minecraft:yellow_terracotta
setblock 19 79 325 minecraft:light[level=15]
setblock 19 79 333 minecraft:light[level=15]
setblock 19 79 349 minecraft:light[level=15]
setblock 19 79 357 minecraft:light[level=15]
fill 20 79 323 20 82 323 minecraft:honeycomb_block
setblock 21 79 325 minecraft:honeycomb_block
setblock 21 79 329 minecraft:ochre_froglight
setblock 22 79 325 minecraft:yellow_terracotta
fill 22 79 331 22 82 331 minecraft:ochre_froglight
setblock 23 79 324 minecraft:yellow_terracotta
fill 23 79 325 25 79 326 minecraft:honeycomb_block
fill 23 79 332 23 82 332 minecraft:ochre_froglight
fill 24 79 322 24 113 322 minecraft:honeycomb_block
setblock 24 79 323 minecraft:yellow_terracotta
fill 24 79 324 24 82 324 minecraft:honeycomb_block
setblock 24 79 363 minecraft:yellow_terracotta
fill 25 79 323 25 82 323 minecraft:honeycomb_block
setblock 25 79 333 minecraft:ochre_froglight
fill 25 79 363 25 81 363 minecraft:honeycomb_block
setblock 26 79 325 minecraft:honeycomb_block
setblock 26 79 326 minecraft:yellow_terracotta
setblock 27 79 325 minecraft:yellow_terracotta
fill 27 79 326 27 81 326 minecraft:honeycomb_block
setblock 27 79 341 minecraft:light[level=15]
setblock 27 79 349 minecraft:light[level=15]
setblock 27 79 357 minecraft:light[level=15]
setblock 28 79 324 minecraft:yellow_terracotta
fill 28 79 325 28 82 325 minecraft:honeycomb_block
setblock 29 79 323 minecraft:yellow_terracotta
fill 29 79 324 29 82 324 minecraft:honeycomb_block
setblock 29 79 333 minecraft:ochre_froglight
setblock 29 79 363 minecraft:yellow_terracotta
fill 30 79 323 30 82 323 minecraft:honeycomb_block
setblock 30 79 363 minecraft:honeycomb_block
fill 31 79 326 31 87 326 minecraft:honey_block
fill 31 79 332 31 82 332 minecraft:ochre_froglight
setblock 32 79 325 minecraft:yellow_terracotta
fill 32 79 331 32 82 331 minecraft:ochre_froglight
setblock 33 79 324 minecraft:yellow_terracotta
setblock 33 79 325 minecraft:honeycomb_block
setblock 33 79 329 minecraft:ochre_froglight
fill 34 79 322 34 122 322 minecraft:honeycomb_block
setblock 34 79 323 minecraft:yellow_terracotta
fill 34 79 324 34 80 324 minecraft:honeycomb_block
fill 34 79 364 34 89 364 minecraft:honeycomb_block
fill 35 79 323 35 82 323 minecraft:honeycomb_block
setblock 35 79 325 minecraft:light[level=15]
setblock 35 79 333 minecraft:light[level=15]
setblock 35 79 341 minecraft:light[level=15]
setblock 35 79 349 minecraft:light[level=15]
setblock 35 79 357 minecraft:light[level=15]
setblock 38 79 324 minecraft:yellow_terracotta
setblock 38 79 325 minecraft:honeycomb_block
setblock 39 79 323 minecraft:yellow_terracotta
fill 39 79 324 39 82 324 minecraft:honeycomb_block
setblock 39 79 327 minecraft:honeycomb_block
setblock 39 79 363 minecraft:yellow_terracotta
fill 40 79 323 40 82 323 minecraft:honeycomb_block
setblock 40 79 327 minecraft:yellow_terracotta
fill 40 79 328 40 82 328 minecraft:honeycomb_block
fill 40 79 363 40 82 364 minecraft:honeycomb_block
setblock 41 79 326 minecraft:yellow_terracotta
fill 41 79 327 41 82 327 minecraft:honeycomb_block
setblock 41 79 331 minecraft:yellow_terracotta
fill 41 79 332 41 81 333 minecraft:honeycomb_block
setblock 41 79 346 minecraft:yellow_terracotta
fill 41 79 347 41 82 347 minecraft:honeycomb_block
setblock 41 79 350 minecraft:honeycomb_block
setblock 41 79 351 minecraft:yellow_terracotta
fill 41 79 352 41 82 352 minecraft:honeycomb_block
setblock 41 79 355 minecraft:honeycomb_block
setblock 41 79 356 minecraft:yellow_terracotta
fill 41 79 357 41 82 357 minecraft:honeycomb_block
setblock 41 79 361 minecraft:yellow_terracotta
fill 41 79 362 41 82 362 minecraft:honeycomb_block
setblock 42 79 332 minecraft:yellow_concrete
fill 0 80 324 1 80 324 minecraft:honeycomb_block
fill 0 80 338 0 94 340 minecraft:honeycomb_block
setblock 0 80 341 minecraft:yellow_concrete
setblock 0 80 359 minecraft:yellow_concrete
setblock 1 80 325 minecraft:yellow_terracotta
fill 1 80 326 1 83 326 minecraft:honeycomb_block
setblock 1 80 329 minecraft:honeycomb_block
setblock 1 80 330 minecraft:yellow_terracotta
fill 1 80 331 1 82 332 minecraft:honeycomb_block
fill 1 80 342 1 80 344 minecraft:honeycomb_block
setblock 1 80 345 minecraft:yellow_terracotta
fill 1 80 346 1 80 349 minecraft:honeycomb_block
setblock 1 80 350 minecraft:yellow_terracotta
fill 1 80 351 1 83 351 minecraft:honeycomb_block
setblock 1 80 355 minecraft:yellow_terracotta
fill 1 80 356 1 83 356 minecraft:honeycomb_block
setblock 1 80 360 minecraft:yellow_terracotta
fill 1 80 361 1 83 361 minecraft:honeycomb_block
setblock 2 80 324 minecraft:yellow_terracotta
fill 2 80 325 2 82 325 minecraft:honeycomb_block
setblock 2 80 329 minecraft:yellow_terracotta
setblock 2 80 344 minecraft:yellow_terracotta
fill 2 80 345 2 83 345 minecraft:honeycomb_block
setblock 2 80 349 minecraft:yellow_terracotta
fill 2 80 350 2 83 350 minecraft:honeycomb_block
setblock 2 80 353 minecraft:honeycomb_block
setblock 2 80 354 minecraft:yellow_terracotta
fill 2 80 355 2 83 355 minecraft:honeycomb_block
setblock 2 80 359 minecraft:yellow_terracotta
fill 2 80 360 2 81 360 minecraft:honeycomb_block
setblock 3 80 323 minecraft:yellow_terracotta
fill 3 80 324 3 81 324 minecraft:honeycomb_block
setblock 3 80 344 minecraft:honeycomb_block
setblock 3 80 348 minecraft:yellow_terracotta
fill 3 80 349 3 83 349 minecraft:honeycomb_block
setblock 3 80 353 minecraft:yellow_terracotta
fill 3 80 354 3 83 354 minecraft:honeycomb_block
setblock 3 80 363 minecraft:yellow_terracotta
fill 4 80 323 4 83 323 minecraft:honeycomb_block
setblock 4 80 347 minecraft:yellow_terracotta
fill 4 80 348 4 82 348 minecraft:honeycomb_block
setblock 4 80 352 minecraft:yellow_terracotta
fill 4 80 353 4 83 353 minecraft:honeycomb_block
setblock 4 80 362 minecraft:yellow_terracotta
fill 4 80 363 4 83 363 minecraft:honeycomb_block
setblock 5 80 362 minecraft:honeycomb_block
setblock 7 80 324 minecraft:yellow_terracotta
setblock 8 80 323 minecraft:yellow_terracotta
setblock 8 80 363 minecraft:yellow_terracotta
setblock 9 80 323 minecraft:honeycomb_block
setblock 9 80 363 minecraft:honeycomb_block
setblock 13 80 323 minecraft:honey_block
fill 16 80 343 16 119 346 minecraft:yellow_terracotta
fill 17 80 344 17 119 346 minecraft:yellow_terracotta
fill 19 80 323 19 82 323 minecraft:honeycomb_block
fill 21 80 325 21 81 325 minecraft:honey_block
fill 21 80 329 21 81 329 minecraft:honey_block
setblock 22 80 324 minecraft:yellow_terracotta
fill 22 80 325 25 80 325 minecraft:honeycomb_block
setblock 23 80 323 minecraft:yellow_terracotta
fill 23 80 324 23 83 324 minecraft:honeycomb_block
fill 23 80 326 24 80 326 minecraft:honeycomb_block
setblock 23 80 363 minecraft:yellow_terracotta
fill 24 80 323 24 83 323 minecraft:honeycomb_block
setblock 24 80 363 minecraft:honeycomb_block
setblock 25 80 326 minecraft:yellow_terracotta
fill 25 80 333 25 81 333 minecraft:honey_block
setblock 26 80 325 minecraft:yellow_terracotta
fill 26 80 326 26 81 326 minecraft:honeycomb_block
setblock 27 80 324 minecraft:yellow_terracotta
fill 27 80 325 27 82 325 minecraft:honeycomb_block
setblock 28 80 323 minecraft:yellow_terracotta
fill 28 80 324 28 83 324 minecraft:honeycomb_block
setblock 28 80 363 minecraft:yellow_terracotta
fill 29 80 323 29 83 323 minecraft:honeycomb_block
fill 29 80 326 30 88 326 minecraft:honey_block
fill 29 80 333 29 81 333 minecraft:honey_block
setblock 29 80 363 minecraft:honeycomb_block
setblock 31 80 325 minecraft:yellow_terracotta
setblock 32 80 324 minecraft:yellow_terracotta
fill 32 80 325 33 81 325 minecraft:honey_block
setblock 33 80 323 minecraft:yellow_terracotta
fill 33 80 324 33 81 324 minecraft:honeycomb_block
fill 33 80 329 33 81 329 minecraft:honey_block
fill 34 80 323 34 82 323 minecraft:honeycomb_block
setblock 37 80 324 minecraft:yellow_terracotta
setblock 38 80 323 minecraft:yellow_terracotta
fill 38 80 324 38 82 324 minecraft:honeycomb_block
setblock 38 80 363 minecraft:yellow_terracotta
fill 39 80 323 39 83 323 minecraft:honeycomb_block
fill 39 80 363 39 83 363 minecraft:honeycomb_block
setblock 40 80 326 minecraft:yellow_terracotta
fill 40 80 327 40 83 327 minecraft:honeycomb_block
setblock 40 80 350 minecraft:honeycomb_block
setblock 41 80 325 minecraft:yellow_terracotta
fill 41 80 326 41 83 326 minecraft:honeycomb_block
setblock 41 80 330 minecraft:yellow_terracotta
fill 41 80 331 41 83 331 minecraft:honeycomb_block
setblock 41 80 339 minecraft:honey_block
setblock 41 80 345 minecraft:yellow_terracotta
fill 41 80 346 41 83 346 minecraft:honeycomb_block
setblock 41 80 350 minecraft:yellow_terracotta
fill 41 80 351 41 83 351 minecraft:honeycomb_block
setblock 41 80 355 minecraft:yellow_terracotta
fill 41 80 356 41 83 356 minecraft:honeycomb_block
setblock 41 80 360 minecraft:yellow_terracotta
fill 41 80 361 41 83 361 minecraft:honeycomb_block
fill 42 80 332 42 99 332 minecraft:honeycomb_block
setblock 0 81 324 minecraft:yellow_concrete
fill 0 81 341 0 115 341 minecraft:honeycomb_block
setblock 0 81 351 minecraft:yellow_terracotta
fill 0 81 359 0 89 359 minecraft:honeycomb_block
setblock 1 81 324 minecraft:yellow_terracotta
fill 1 81 325 1 84 325 minecraft:honeycomb_block
setblock 1 81 329 minecraft:yellow_terracotta
fill 1 81 330 2 83 330 minecraft:honeycomb_block
fill 1 81 342 1 81 343 minecraft:honeycomb_block
setblock 1 81 344 minecraft:yellow_terracotta
fill 1 81 345 1 81 348 minecraft:honeycomb_block
setblock 1 81 349 minecraft:yellow_terracotta
fill 1 81 350 1 84 350 minecraft:honeycomb_block
setblock 1 81 354 minecraft:yellow_terracotta
fill 1 81 355 1 84 355 minecraft:honeycomb_block
setblock 1 81 359 minecraft:yellow_terracotta
fill 1 81 360 1 84 360 minecraft:honeycomb_block
setblock 2 81 323 minecraft:yellow_terracotta
setblock 2 81 324 minecraft:honeycomb_block
setblock 2 81 328 minecraft:yellow_terracotta
fill 2 81 329 2 84 329 minecraft:honeycomb_block
setblock 2 81 343 minecraft:yellow_terracotta
fill 2 81 344 2 83 344 minecraft:honeycomb_block
setblock 2 81 348 minecraft:yellow_terracotta
fill 2 81 349 2 84 349 minecraft:honeycomb_block
setblock 2 81 353 minecraft:yellow_terracotta
fill 2 81 354 2 84 354 minecraft:honeycomb_block
setblock 2 81 358 minecraft:yellow_terracotta
fill 2 81 359 2 84 359 minecraft:honeycomb_block
setblock 2 81 363 minecraft:yellow_terracotta
fill 3 81 323 3 83 323 minecraft:honeycomb_block
setblock 3 81 325 minecraft:light[level=12]
setblock 3 81 332 minecraft:light[level=12]
setblock 3 81 339 minecraft:light[level=12]
setblock 3 81 347 minecraft:yellow_terracotta
fill 3 81 348 3 84 348 minecraft:honeycomb_block
setblock 3 81 352 minecraft:yellow_terracotta
fill 3 81 353 3 84 353 minecraft:honeycomb_block
setblock 3 81 360 minecraft:light[level=12]
setblock 3 81 362 minecraft:yellow_terracotta
fill 3 81 363 3 84 363 minecraft:honeycomb_block
setblock 4 81 347 minecraft:honeycomb_block
setblock 4 81 351 minecraft:yellow_terracotta
fill 4 81 352 4 84 352 minecraft:honeycomb_block
setblock 4 81 362 minecraft:honeycomb_block
setblock 7 81 323 minecraft:yellow_terracotta
setblock 7 81 363 minecraft:yellow_terracotta
setblock 10 81 325 minecraft:light[level=12]
setblock 10 81 332 minecraft:light[level=12]
setblock 10 81 339 minecraft:light[level=12]
setblock 10 81 346 minecraft:light[level=12]
setblock 10 81 353 minecraft:light[level=12]
setblock 10 81 360 minecraft:light[level=12]
setblock 10 81 363 minecraft:honey_block
setblock 17 81 325 minecraft:light[level=12]
setblock 17 81 332 minecraft:light[level=12]
setblock 17 81 339 minecraft:light[level=12]
setblock 17 81 353 minecraft:light[level=12]
setblock 17 81 360 minecraft:light[level=12]
setblock 21 81 324 minecraft:yellow_terracotta
setblock 22 81 323 minecraft:yellow_terracotta
fill 22 81 324 22 82 325 minecraft:honeycomb_block
fill 23 81 323 23 84 323 minecraft:honeycomb_block
fill 23 81 325 24 81 325 minecraft:honeycomb_block
fill 23 81 326 23 87 326 minecraft:honey_block
setblock 24 81 326 minecraft:yellow_terracotta
setblock 24 81 339 minecraft:light[level=12]
setblock 24 81 346 minecraft:light[level=12]
setblock 24 81 353 minecraft:light[level=12]
setblock 24 81 360 minecraft:light[level=12]
setblock 25 81 325 minecraft:yellow_terracotta
setblock 25 81 326 minecraft:honeycomb_block
setblock 26 81 324 minecraft:yellow_terracotta
fill 26 81 325 26 83 325 minecraft:honeycomb_block
setblock 27 81 323 minecraft:yellow_terracotta
fill 27 81 324 27 84 324 minecraft:honeycomb_block
fill 28 81 323 28 84 323 minecraft:honeycomb_block
fill 28 81 326 28 89 326 minecraft:honey_block
setblock 30 81 325 minecraft:yellow_terracotta
setblock 31 81 324 minecraft:yellow_terracotta
fill 31 81 325 31 86 325 minecraft:honey_block
setblock 31 81 339 minecraft:light[level=12]
setblock 31 81 346 minecraft:light[level=12]
setblock 31 81 353 minecraft:light[level=12]
setblock 31 81 360 minecraft:light[level=12]
setblock 32 81 323 minecraft:yellow_terracotta
setblock 32 81 324 minecraft:honeycomb_block
fill 33 81 323 33 82 323 minecraft:honeycomb_block
setblock 35 81 363 minecraft:honey_block
setblock 36 81 324 minecraft:yellow_terracotta
setblock 37 81 323 minecraft:yellow_terracotta
setblock 37 81 324 minecraft:honeycomb_block
fill 38 81 323 38 84 323 minecraft:honeycomb_block
setblock 38 81 325 minecraft:light[level=12]
setblock 38 81 332 minecraft:light[level=12]
setblock 38 81 339 minecraft:light[level=12]
setblock 38 81 346 minecraft:light[level=12]
setblock 38 81 353 minecraft:light[level=12]
setblock 38 81 360 minecraft:light[level=12]
setblock 38 81 363 minecraft:honeycomb_block
setblock 40 81 325 minecraft:yellow_terracotta
fill 40 81 326 40 84 326 minecraft:honeycomb_block
setblock 40 81 329 minecraft:honeycomb_block
setblock 40 81 330 minecraft:yellow_terracotta
setblock 40 81 349 minecraft:honeycomb_block
setblock 40 81 350 minecraft:yellow_terracotta
fill 40 81 351 40 83 352 minecraft:honeycomb_block
setblock 41 81 324 minecraft:yellow_terracotta
fill 41 81 325 41 84 325 minecraft:honeycomb_block
fill 41 81 329 42 81 329 minecraft:yellow_terracotta
fill 41 81 330 41 84 330 minecraft:honeycomb_block
setblock 41 81 344 minecraft:yellow_terracotta
fill 41 81 345 41 83 345 minecraft:honeycomb_block
setblock 41 81 349 minecraft:yellow_terracotta
fill 41 81 350 41 84 350 minecraft:honeycomb_block
setblock 41 81 354 minecraft:yellow_terracotta
fill 41 81 355 41 84 355 minecraft:honeycomb_block
setblock 41 81 359 minecraft:yellow_terracotta
fill 41 81 360 41 84 360 minecraft:honeycomb_block
setblock 42 81 347 minecraft:yellow_concrete
fill 0 82 324 1 85 324 minecraft:honeycomb_block
fill 0 82 351 0 308 351 minecraft:honeycomb_block
setblock 1 82 323 minecraft:yellow_terracotta
setblock 1 82 328 minecraft:yellow_terracotta
fill 1 82 329 1 85 329 minecraft:honeycomb_block
setblock 1 82 333 minecraft:yellow_terracotta
setblock 1 82 334 minecraft:honey_block
setblock 1 82 342 minecraft:honeycomb_block
setblock 1 82 343 minecraft:yellow_terracotta
fill 1 82 344 1 82 347 minecraft:honeycomb_block
setblock 1 82 348 minecraft:yellow_terracotta
fill 1 82 349 1 85 349 minecraft:honeycomb_block
setblock 1 82 353 minecraft:yellow_terracotta
fill 1 82 354 1 85 354 minecraft:honeycomb_block
setblock 1 82 358 minecraft:yellow_terracotta
fill 1 82 359 1 85 359 minecraft:honeycomb_block
setblock 1 82 363 minecraft:yellow_terracotta
fill 2 82 323 2 84 323 minecraft:honeycomb_block
setblock 2 82 327 minecraft:yellow_terracotta
fill 2 82 328 2 84 328 minecraft:honeycomb_block
setblock 2 82 347 minecraft:yellow_terracotta
fill 2 82 348 2 85 348 minecraft:honeycomb_block
setblock 2 82 352 minecraft:yellow_terracotta
fill 2 82 353 2 85 353 minecraft:honeycomb_block
setblock 2 82 356 minecraft:honeycomb_block
setblock 2 82 357 minecraft:yellow_terracotta
fill 2 82 358 2 85 358 minecraft:honeycomb_block
fill 2 82 363 2 85 363 minecraft:honeycomb_block
setblock 3 82 346 minecraft:yellow_terracotta
fill 3 82 347 3 85 347 minecraft:honeycomb_block
setblock 3 82 351 minecraft:yellow_terracotta
fill 3 82 352 3 85 352 minecraft:honeycomb_block
setblock 3 82 356 minecraft:yellow_terracotta
setblock 4 82 350 minecraft:yellow_terracotta
fill 4 82 351 4 85 351 minecraft:honeycomb_block
setblock 6 82 323 minecraft:yellow_terracotta
setblock 6 82 363 minecraft:yellow_terracotta
setblock 16 82 363 minecraft:honey_block
setblock 21 82 323 minecraft:yellow_terracotta
fill 21 82 324 21 85 324 minecraft:honeycomb_block
setblock 21 82 325 minecraft:ochre_froglight
setblock 21 82 329 minecraft:ochre_froglight
fill 22 82 323 22 85 323 minecraft:honeycomb_block
setblock 23 82 325 minecraft:honeycomb_block
setblock 24 82 325 minecraft:yellow_terracotta
fill 24 82 326 27 88 326 minecraft:honey_block
setblock 25 82 324 minecraft:yellow_terracotta
fill 25 82 325 25 83 325 minecraft:honeycomb_block
setblock 25 82 333 minecraft:ochre_froglight
setblock 26 82 323 minecraft:yellow_terracotta
fill 26 82 324 26 85 324 minecraft:honeycomb_block
fill 27 82 323 27 85 323 minecraft:honeycomb_block
fill 29 82 325 30 87 325 minecraft:honey_block
setblock 29 82 333 minecraft:ochre_froglight
setblock 30 82 324 minecraft:yellow_terracotta
setblock 31 82 323 minecraft:yellow_terracotta
fill 31 82 324 32 84 324 minecraft:honey_block
fill 32 82 323 32 83 323 minecraft:honeycomb_block
fill 32 82 325 32 85 325 minecraft:honey_block
setblock 33 82 325 minecraft:ochre_froglight
setblock 33 82 329 minecraft:ochre_froglight
setblock 36 82 323 minecraft:yellow_terracotta
fill 37 82 323 37 85 323 minecraft:honeycomb_block
fill 38 82 353 38 85 353 minecraft:brown_terracotta
fill 39 82 352 39 85 352 minecraft:brown_terracotta
fill 39 82 354 39 85 354 minecraft:brown_terracotta
setblock 40 82 324 minecraft:yellow_terracotta
fill 40 82 325 40 85 325 minecraft:honeycomb_block
setblock 40 82 329 minecraft:yellow_terracotta
fill 40 82 330 40 84 331 minecraft:honeycomb_block
setblock 40 82 349 minecraft:yellow_terracotta
fill 40 82 350 40 85 350 minecraft:honeycomb_block
setblock 40 82 353 minecraft:honeycomb_block
setblock 40 82 354 minecraft:yellow_terracotta
setblock 41 82 323 minecraft:yellow_terracotta
fill 41 82 324 41 85 324 minecraft:honeycomb_block
fill 41 82 328 42 82 328 minecraft:yellow_terracotta
fill 41 82 329 42 85 329 minecraft:honeycomb_block
setblock 41 82 332 minecraft:honeycomb_block
setblock 41 82 333 minecraft:yellow_terracotta
setblock 41 82 348 minecraft:yellow_terracotta
fill 41 82 349 41 85 349 minecraft:honeycomb_block
setblock 41 82 353 minecraft:yellow_terracotta
fill 41 82 354 41 85 354 minecraft:honeycomb_block
setblock 41 82 358 minecraft:yellow_terracotta
fill 41 82 359 41 85 359 minecraft:honeycomb_block
setblock 41 82 363 minecraft:yellow_terracotta
fill 42 82 327 42 185 327 minecraft:honeycomb_block
fill 42 82 347 42 308 347 minecraft:honeycomb_block
setblock 0 83 334 minecraft:orange_terracotta
fill 0 83 335 0 142 336 minecraft:honeycomb_block
fill 1 83 323 1 84 323 minecraft:honeycomb_block
setblock 1 83 327 minecraft:yellow_terracotta
fill 1 83 328 1 86 328 minecraft:honeycomb_block
setblock 1 83 331 minecraft:honeycomb_block
setblock 1 83 332 minecraft:yellow_terracotta
fill 1 83 333 1 85 334 minecraft:honeycomb_block
setblock 1 83 340 minecraft:honey_block
fill 1 83 343 1 83 346 minecraft:honeycomb_block
setblock 1 83 347 minecraft:yellow_terracotta
fill 1 83 348 1 86 348 minecraft:honeycomb_block
setblock 1 83 352 minecraft:yellow_terracotta
fill 1 83 353 1 86 353 minecraft:honeycomb_block
setblock 1 83 357 minecraft:yellow_terracotta
fill 1 83 358 1 86 358 minecraft:honeycomb_block
setblock 1 83 362 minecraft:yellow_terracotta
fill 1 83 363 1 86 363 minecraft:honeycomb_block
setblock 2 83 327 minecraft:honeycomb_block
setblock 2 83 346 minecraft:yellow_terracotta
fill 2 83 347 2 86 347 minecraft:honeycomb_block
setblock 2 83 351 minecraft:yellow_terracotta
fill 2 83 352 2 86 352 minecraft:honeycomb_block
setblock 2 83 356 minecraft:yellow_terracotta
fill 2 83 357 2 86 357 minecraft:honeycomb_block
setblock 3 83 346 minecraft:honeycomb_block
setblock 3 83 350 minecraft:yellow_terracotta
fill 3 83 351 3 86 351 minecraft:honeycomb_block
setblock 3 83 355 minecraft:yellow_terracotta
fill 3 83 356 3 86 356 minecraft:honeycomb_block
setblock 4 83 349 minecraft:yellow_terracotta
fill 4 83 350 4 84 350 minecraft:honeycomb_block
setblock 20 83 323 minecraft:yellow_terracotta
fill 21 83 323 21 86 323 minecraft:honeycomb_block
fill 22 83 324 22 84 324 minecraft:honeycomb_block
fill 22 83 325 22 85 325 minecraft:honey_block
setblock 22 83 363 minecraft:honey_block
setblock 23 83 325 minecraft:yellow_terracotta
setblock 24 83 324 minecraft:yellow_terracotta
fill 24 83 325 24 84 325 minecraft:honeycomb_block
setblock 25 83 323 minecraft:yellow_terracotta
fill 25 83 324 25 86 324 minecraft:honeycomb_block
fill 26 83 323 26 86 323 minecraft:honeycomb_block
fill 27 83 325 28 88 325 minecraft:honey_block
fill 29 83 324 30 87 324 minecraft:honey_block
setblock 30 83 323 minecraft:yellow_terracotta
setblock 31 83 323 minecraft:honeycomb_block
setblock 35 83 323 minecraft:yellow_terracotta
fill 36 83 323 36 86 323 minecraft:honeycomb_block
setblock 39 83 324 minecraft:yellow_terracotta
setblock 40 83 323 minecraft:yellow_terracotta
fill 40 83 324 40 86 324 minecraft:honeycomb_block
setblock 40 83 328 minecraft:yellow_terracotta
fill 40 83 329 40 86 329 minecraft:honeycomb_block
fill 40 83 349 40 86 349 minecraft:honeycomb_block
setblock 40 83 353 minecraft:yellow_terracotta
fill 40 83 354 40 84 356 minecraft:honeycomb_block
setblock 40 83 363 minecraft:yellow_terracotta
fill 40 83 364 40 130 364 minecraft:honeycomb_block
fill 41 83 323 41 86 323 minecraft:honeycomb_block
setblock 41 83 327 minecraft:yellow_terracotta
fill 41 83 328 42 86 328 minecraft:honeycomb_block
setblock 41 83 332 minecraft:yellow_terracotta
fill 41 83 333 41 85 334 minecraft:honeycomb_block
setblock 41 83 347 minecraft:yellow_terracotta
fill 41 83 348 41 86 348 minecraft:honeycomb_block
setblock 41 83 352 minecraft:yellow_terracotta
fill 41 83 353 41 86 353 minecraft:honeycomb_block
setblock 41 83 357 minecraft:yellow_terracotta
fill 41 83 358 41 86 358 minecraft:honeycomb_block
setblock 41 83 362 minecraft:yellow_terracotta
fill 41 83 363 41 86 363 minecraft:honeycomb_block
setblock 0 84 330 minecraft:orange_terracotta
fill 0 84 334 0 106 334 minecraft:honeycomb_block
fill 0 84 361 0 157 362 minecraft:honeycomb_block
setblock 0 84 363 minecraft:yellow_terracotta
setblock 1 84 326 minecraft:yellow_terracotta
fill 1 84 327 1 87 327 minecraft:honeycomb_block
setblock 1 84 330 minecraft:honeycomb_block
setblock 1 84 331 minecraft:yellow_terracotta
fill 1 84 332 1 87 332 minecraft:honeycomb_block
setblock 1 84 335 minecraft:honeycomb_block
fill 1 84 342 1 84 345 minecraft:honeycomb_block
setblock 1 84 346 minecraft:yellow_terracotta
fill 1 84 347 1 87 347 minecraft:honeycomb_block
setblock 1 84 351 minecraft:yellow_terracotta
fill 1 84 352 1 87 352 minecraft:honeycomb_block
setblock 1 84 356 minecraft:yellow_terracotta
fill 1 84 357 1 87 357 minecraft:honeycomb_block
setblock 1 84 361 minecraft:yellow_terracotta
fill 1 84 362 1 87 362 minecraft:honeycomb_block
setblock 2 84 330 minecraft:yellow_terracotta
fill 2 84 331 2 87 331 minecraft:honeycomb_block
setblock 2 84 345 minecraft:yellow_terracotta
fill 2 84 346 2 87 346 minecraft:honeycomb_block
setblock 2 84 350 minecraft:yellow_terracotta
fill 2 84 351 2 87 351 minecraft:honeycomb_block
setblock 2 84 355 minecraft:yellow_terracotta
fill 2 84 356 2 87 356 minecraft:honeycomb_block
setblock 3 84 349 minecraft:yellow_terracotta
fill 3 84 350 3 87 350 minecraft:honeycomb_block
setblock 3 84 354 minecraft:yellow_terracotta
fill 3 84 355 3 87 355 minecraft:honeycomb_block
setblock 4 84 322 minecraft:orange_terracotta
setblock 4 84 353 minecraft:yellow_terracotta
setblock 4 84 363 minecraft:yellow_terracotta
fill 8 84 323 8 85 323 minecraft:honey_block
setblock 9 84 363 minecraft:honey_block
setblock 14 84 323 minecraft:honey_block
fill 17 84 364 17 109 364 minecraft:honeycomb_block
setblock 18 84 322 minecraft:yellow_concrete
fill 18 84 345 18 119 346 minecraft:yellow_terracotta
setblock 18 84 364 minecraft:orange_terracotta
fill 20 84 323 20 87 323 minecraft:honeycomb_block
setblock 23 84 324 minecraft:yellow_terracotta
setblock 23 84 325 minecraft:honeycomb_block
setblock 24 84 323 minecraft:yellow_terracotta
fill 24 84 324 24 87 324 minecraft:honeycomb_block
fill 25 84 323 25 87 323 minecraft:honeycomb_block
fill 25 84 325 26 88 325 minecraft:honey_block
fill 28 84 324 28 88 324 minecraft:honey_block
setblock 28 84 363 minecraft:honey_block
setblock 29 84 323 minecraft:yellow_terracotta
fill 30 84 323 31 84 323 minecraft:honey_block
fill 32 84 326 32 85 326 minecraft:honey_block
setblock 33 84 323 minecraft:honey_block
setblock 38 84 363 minecraft:honeycomb_block
setblock 39 84 323 minecraft:yellow_terracotta
setblock 39 84 324 minecraft:honeycomb_block
setblock 39 84 363 minecraft:yellow_terracotta
fill 40 84 323 40 87 323 minecraft:honeycomb_block
setblock 40 84 327 minecraft:yellow_terracotta
fill 40 84 328 40 87 328 minecraft:honeycomb_block
setblock 40 84 351 minecraft:honeycomb_block
setblock 40 84 352 minecraft:yellow_terracotta
fill 40 84 353 40 87 353 minecraft:honeycomb_block
setblock 40 84 357 minecraft:yellow_terracotta
fill 40 84 358 40 87 358 minecraft:honeycomb_block
fill 40 84 363 40 87 363 minecraft:honeycomb_block
setblock 41 84 326 minecraft:yellow_terracotta
fill 41 84 327 41 87 327 minecraft:honeycomb_block
setblock 41 84 331 minecraft:yellow_terracotta
fill 41 84 332 41 87 332 minecraft:honeycomb_block
setblock 41 84 335 minecraft:honeycomb_block
setblock 41 84 340 minecraft:honey_block
setblock 41 84 346 minecraft:yellow_terracotta
fill 41 84 347 41 87 347 minecraft:honeycomb_block
setblock 41 84 351 minecraft:yellow_terracotta
fill 41 84 352 41 87 352 minecraft:honeycomb_block
setblock 41 84 356 minecraft:yellow_terracotta
fill 41 84 357 41 87 357 minecraft:honeycomb_block
setblock 41 84 361 minecraft:yellow_terracotta
fill 41 84 362 41 87 362 minecraft:honeycomb_block
fill 0 85 330 0 118 330 minecraft:honeycomb_block
setblock 0 85 344 minecraft:yellow_terracotta
fill 0 85 345 0 103 347 minecraft:honeycomb_block
fill 0 85 363 0 119 363 minecraft:honeycomb_block
setblock 1 85 322 minecraft:orange_terracotta
setblock 1 85 325 minecraft:yellow_terracotta
fill 1 85 326 1 88 326 minecraft:honeycomb_block
setblock 1 85 330 minecraft:yellow_terracotta
fill 1 85 331 1 88 331 minecraft:honeycomb_block
setblock 1 85 335 minecraft:yellow_terracotta
fill 1 85 336 1 86 338 minecraft:honeycomb_block
fill 1 85 341 1 85 344 minecraft:honeycomb_block
setblock 1 85 345 minecraft:yellow_terracotta
fill 1 85 346 1 88 346 minecraft:honeycomb_block
setblock 1 85 350 minecraft:yellow_terracotta
fill 1 85 351 1 88 351 minecraft:honeycomb_block
setblock 1 85 355 minecraft:yellow_terracotta
fill 1 85 356 1 88 356 minecraft:honeycomb_block
setblock 1 85 360 minecraft:yellow_terracotta
fill 1 85 361 1 88 361 minecraft:honeycomb_block
setblock 2 85 323 minecraft:honey_block
setblock 2 85 329 minecraft:yellow_terracotta
fill 2 85 330 2 88 330 minecraft:honeycomb_block
fill 2 85 332 2 85 333 minecraft:honeycomb_block
fill 2 85 345 2 88 345 minecraft:honeycomb_block
setblock 2 85 349 minecraft:yellow_terracotta
fill 2 85 350 2 88 350 minecraft:honeycomb_block
setblock 2 85 354 minecraft:yellow_terracotta
fill 2 85 355 2 88 355 minecraft:honeycomb_block
setblock 2 85 359 minecraft:yellow_terracotta
fill 2 85 360 2 88 360 minecraft:honeycomb_block
setblock 3 85 348 minecraft:yellow_terracotta
fill 3 85 349 3 88 349 minecraft:honeycomb_block
setblock 3 85 353 minecraft:yellow_terracotta
fill 3 85 354 3 88 354 minecraft:honeycomb_block
setblock 3 85 357 minecraft:honeycomb_block
setblock 3 85 363 minecraft:yellow_terracotta
fill 4 85 322 4 149 322 minecraft:honeycomb_block
setblock 4 85 352 minecraft:yellow_terracotta
fill 4 85 353 4 88 353 minecraft:honeycomb_block
fill 5 85 353 5 95 353 minecraft:yellow_terracotta
setblock 12 85 364 minecraft:orange_terracotta
setblock 15 85 363 minecraft:honey_block
fill 18 85 322 18 108 322 minecraft:honeycomb_block
fill 18 85 364 18 130 364 minecraft:honeycomb_block
fill 19 85 323 19 88 323 minecraft:honeycomb_block
setblock 22 85 324 minecraft:yellow_terracotta
fill 22 85 326 22 85 329 minecraft:honey_block
setblock 23 85 323 minecraft:yellow_terracotta
fill 23 85 324 23 88 324 minecraft:honeycomb_block
fill 23 85 325 24 86 325 minecraft:honey_block
fill 24 85 323 24 88 323 minecraft:honeycomb_block
setblock 27 85 322 minecraft:yellow_concrete
fill 27 85 324 27 88 324 minecraft:honey_block
fill 28 85 322 33 85 322 minecraft:honeycomb_block
setblock 28 85 323 minecraft:yellow_terracotta
fill 29 85 323 30 85 323 minecraft:honey_block
setblock 31 85 324 minecraft:honey_block
setblock 34 85 363 minecraft:honey_block
setblock 38 85 323 minecraft:yellow_terracotta
setblock 38 85 352 minecraft:brown_terracotta
setblock 38 85 354 minecraft:brown_terracotta
setblock 38 85 363 minecraft:yellow_terracotta
fill 39 85 323 39 88 323 minecraft:honeycomb_block
fill 39 85 363 39 88 363 minecraft:honeycomb_block
setblock 40 85 326 minecraft:yellow_terracotta
fill 40 85 327 40 88 327 minecraft:honeycomb_block
setblock 40 85 330 minecraft:honeycomb_block
setblock 40 85 331 minecraft:yellow_terracotta
fill 40 85 332 40 88 332 minecraft:honeycomb_block
setblock 40 85 351 minecraft:yellow_terracotta
fill 40 85 352 40 88 352 minecraft:honeycomb_block
fill 40 85 354 40 85 355 minecraft:honeycomb_block
setblock 40 85 356 minecraft:yellow_terracotta
fill 40 85 357 40 88 357 minecraft:honeycomb_block
fill 40 85 359 40 85 360 minecraft:honeycomb_block
setblock 40 85 361 minecraft:yellow_terracotta
setblock 41 85 325 minecraft:yellow_terracotta
fill 41 85 326 41 88 326 minecraft:honeycomb_block
setblock 41 85 330 minecraft:yellow_terracotta
fill 41 85 331 41 88 331 minecraft:honeycomb_block
setblock 41 85 335 minecraft:yellow_terracotta
fill 41 85 346 41 88 346 minecraft:honeycomb_block
setblock 41 85 350 minecraft:yellow_terracotta
fill 41 85 351 41 88 351 minecraft:honeycomb_block
setblock 41 85 355 minecraft:yellow_terracotta
fill 41 85 356 41 88 356 minecraft:honeycomb_block
setblock 41 85 360 minecraft:yellow_terracotta
fill 41 85 361 41 88 361 minecraft:honeycomb_block
fill 0 86 324 0 209 324 minecraft:honeycomb_block
fill 0 86 344 0 197 344 minecraft:honeycomb_block
fill 1 86 322 1 98 322 minecraft:honeycomb_block
setblock 1 86 324 minecraft:yellow_terracotta
fill 1 86 325 1 89 325 minecraft:honeycomb_block
setblock 1 86 329 minecraft:yellow_terracotta
fill 1 86 330 1 89 330 minecraft:honeycomb_block
setblock 1 86 333 minecraft:honeycomb_block
setblock 1 86 334 minecraft:yellow_terracotta
fill 1 86 335 2 88 335 minecraft:honeycomb_block
setblock 1 86 339 minecraft:yellow_terracotta
fill 1 86 340 1 86 343 minecraft:honeycomb_block
setblock 1 86 344 minecraft:yellow_terracotta
fill 1 86 345 1 89 345 minecraft:honeycomb_block
setblock 1 86 349 minecraft:yellow_terracotta
fill 1 86 350 1 89 350 minecraft:honeycomb_block
setblock 1 86 354 minecraft:yellow_terracotta
fill 1 86 355 1 89 355 minecraft:honeycomb_block
setblock 1 86 359 minecraft:yellow_terracotta
fill 1 86 360 1 89 360 minecraft:honeycomb_block
fill 2 86 329 2 89 329 minecraft:honeycomb_block
setblock 2 86 332 minecraft:honeycomb_block
setblock 2 86 333 minecraft:yellow_terracotta
fill 2 86 334 2 89 334 minecraft:honeycomb_block
fill 2 86 344 2 89 344 minecraft:honeycomb_block
setblock 2 86 348 minecraft:yellow_terracotta
fill 2 86 349 2 89 349 minecraft:honeycomb_block
setblock 2 86 353 minecraft:yellow_terracotta
fill 2 86 354 2 89 354 minecraft:honeycomb_block
setblock 2 86 358 minecraft:yellow_terracotta
fill 2 86 359 2 89 359 minecraft:honeycomb_block
setblock 2 86 363 minecraft:yellow_terracotta
setblock 3 86 347 minecraft:yellow_terracotta
fill 3 86 348 3 89 348 minecraft:honeycomb_block
setblock 3 86 352 minecraft:yellow_terracotta
fill 3 86 353 3 89 353 minecraft:honeycomb_block
setblock 3 86 357 minecraft:yellow_terracotta
fill 3 86 363 3 89 363 minecraft:honeycomb_block
setblock 4 86 351 minecraft:yellow_terracotta
fill 4 86 352 4 88 352 minecraft:honeycomb_block
fill 12 86 364 12 192 364 minecraft:honeycomb_block
setblock 20 86 324 minecraft:honeycomb_block
setblock 21 86 324 minecraft:yellow_terracotta
setblock 21 86 363 minecraft:honey_block
setblock 22 86 323 minecraft:yellow_terracotta
fill 22 86 324 22 89 324 minecraft:honeycomb_block
setblock 22 86 327 minecraft:ochre_froglight
fill 22 86 358 23 87 358 minecraft:yellow_concrete
fill 23 86 323 23 89 323 minecraft:honeycomb_block
setblock 23 86 330 minecraft:ochre_froglight
setblock 24 86 331 minecraft:ochre_froglight
fill 26 86 324 26 88 324 minecraft:honey_block
fill 27 86 322 28 116 322 minecraft:honeycomb_block
setblock 27 86 323 minecraft:yellow_terracotta
setblock 27 86 332 minecraft:ochre_froglight
fill 28 86 323 28 89 323 minecraft:honeycomb_block
setblock 29 86 322 minecraft:yellow_concrete
setblock 29 86 323 minecraft:honey_block
fill 30 86 322 33 86 322 minecraft:honeycomb_block
setblock 30 86 323 minecraft:ochre_froglight
setblock 30 86 331 minecraft:ochre_froglight
setblock 31 86 324 minecraft:ochre_froglight
setblock 31 86 330 minecraft:ochre_froglight
setblock 32 86 327 minecraft:ochre_froglight
setblock 37 86 323 minecraft:yellow_terracotta
setblock 37 86 363 minecraft:yellow_terracotta
fill 38 86 323 38 89 323 minecraft:honeycomb_block
fill 38 86 363 38 89 363 minecraft:honeycomb_block
fill 39 86 352 39 86 355 minecraft:honeycomb_block
setblock 39 86 356 minecraft:yellow_terracotta
fill 39 86 357 39 89 357 minecraft:honeycomb_block
fill 39 86 362 40 88 362 minecraft:honeycomb_block
setblock 40 86 325 minecraft:yellow_terracotta
fill 40 86 326 40 89 326 minecraft:honeycomb_block
setblock 40 86 330 minecraft:yellow_terracotta
fill 40 86 331 40 89 331 minecraft:honeycomb_block
fill 40 86 333 40 86 334 minecraft:honeycomb_block
fill 40 86 348 40 87 348 minecraft:honeycomb_block
setblock 40 86 350 minecraft:yellow_terracotta
fill 40 86 351 40 89 351 minecraft:honeycomb_block
setblock 40 86 354 minecraft:honeycomb_block
setblock 40 86 355 minecraft:yellow_terracotta
fill 40 86 356 40 89 356 minecraft:honeycomb_block
setblock 40 86 359 minecraft:honeycomb_block
setblock 40 86 360 minecraft:yellow_terracotta
fill 40 86 361 40 89 361 minecraft:honeycomb_block
setblock 41 86 324 minecraft:yellow_terracotta
fill 41 86 325 41 89 325 minecraft:honeycomb_block
setblock 41 86 329 minecraft:yellow_terracotta
fill 41 86 330 41 89 330 minecraft:honeycomb_block
setblock 41 86 333 minecraft:honeycomb_block
setblock 41 86 334 minecraft:yellow_terracotta
fill 41 86 335 41 87 337 minecraft:honeycomb_block
fill 41 86 345 41 89 345 minecraft:honeycomb_block
setblock 41 86 349 minecraft:yellow_terracotta
fill 41 86 350 41 89 350 minecraft:honeycomb_block
setblock 41 86 354 minecraft:yellow_terracotta
fill 41 86 355 41 89 355 minecraft:honeycomb_block
setblock 41 86 359 minecraft:yellow_terracotta
fill 41 86 360 41 89 360 minecraft:honeycomb_block
fill 42 86 329 42 126 329 minecraft:honeycomb_block
fill 42 86 341 42 93 341 minecraft:honeycomb_block
setblock 42 86 342 minecraft:yellow_terracotta
setblock 1 87 328 minecraft:yellow_terracotta
fill 1 87 329 1 90 329 minecraft:honeycomb_block
setblock 1 87 333 minecraft:yellow_terracotta
fill 1 87 334 1 90 334 minecraft:honeycomb_block
fill 1 87 336 1 87 337 minecraft:honeycomb_block
setblock 1 87 338 minecraft:yellow_terracotta
fill 1 87 339 1 87 342 minecraft:honeycomb_block
setblock 1 87 343 minecraft:yellow_terracotta
fill 1 87 344 1 90 344 minecraft:honeycomb_block
setblock 1 87 348 minecraft:yellow_terracotta
fill 1 87 349 1 90 349 minecraft:honeycomb_block
setblock 1 87 353 minecraft:yellow_terracotta
fill 1 87 354 1 90 354 minecraft:honeycomb_block
setblock 1 87 358 minecraft:yellow_terracotta
fill 1 87 359 1 90 359 minecraft:honeycomb_block
setblock 1 87 363 minecraft:yellow_terracotta
setblock 2 87 332 minecraft:yellow_terracotta
fill 2 87 333 2 90 333 minecraft:honeycomb_block
setblock 2 87 336 minecraft:honeycomb_block
setblock 2 87 337 minecraft:yellow_terracotta
fill 2 87 338 2 90 338 minecraft:honeycomb_block
setblock 2 87 347 minecraft:yellow_terracotta
fill 2 87 348 2 90 348 minecraft:honeycomb_block
setblock 2 87 352 minecraft:yellow_terracotta
fill 2 87 353 2 90 353 minecraft:honeycomb_block
setblock 2 87 357 minecraft:yellow_terracotta
fill 2 87 358 3 89 358 minecraft:honeycomb_block
setblock 2 87 361 minecraft:honeycomb_block
fill 2 87 363 2 90 363 minecraft:honeycomb_block
setblock 3 87 325 minecraft:light[level=15]
setblock 3 87 332 minecraft:light[level=12]
setblock 3 87 333 minecraft:light[level=15]
setblock 3 87 339 minecraft:light[level=12]
setblock 3 87 341 minecraft:light[level=15]
setblock 3 87 346 minecraft:light[level=12]
setblock 3 87 347 minecraft:honeycomb_block
setblock 3 87 351 minecraft:yellow_terracotta
fill 3 87 352 3 90 352 minecraft:honeycomb_block
setblock 3 87 356 minecraft:yellow_terracotta
fill 3 87 357 3 90 357 minecraft:honeycomb_block
setblock 3 87 360 minecraft:light[level=12]
setblock 4 87 354 minecraft:honeycomb_block
setblock 7 87 364 minecraft:orange_terracotta
fill 8 87 363 8 88 363 minecraft:honey_block
setblock 10 87 325 minecraft:light[level=12]
setblock 10 87 332 minecraft:light[level=12]
setblock 10 87 339 minecraft:light[level=12]
setblock 10 87 346 minecraft:light[level=12]
setblock 10 87 353 minecraft:light[level=12]
setblock 10 87 360 minecraft:light[level=12]
setblock 11 87 325 minecraft:light[level=15]
setblock 11 87 333 minecraft:light[level=15]
setblock 11 87 341 minecraft:light[level=15]
setblock 11 87 349 minecraft:light[level=15]
setblock 11 87 357 minecraft:light[level=15]
fill 14 87 334 14 88 335 minecraft:honey_block
setblock 15 87 323 minecraft:honey_block
setblock 17 87 325 minecraft:light[level=12]
setblock 17 87 332 minecraft:light[level=12]
setblock 17 87 339 minecraft:light[level=12]
setblock 17 87 353 minecraft:light[level=12]
setblock 17 87 360 minecraft:light[level=12]
fill 18 87 323 18 89 323 minecraft:honeycomb_block
setblock 19 87 325 minecraft:light[level=15]
setblock 19 87 333 minecraft:light[level=15]
setblock 19 87 349 minecraft:light[level=15]
setblock 19 87 357 minecraft:light[level=15]
setblock 20 87 324 minecraft:yellow_terracotta
setblock 21 87 323 minecraft:yellow_terracotta
fill 21 87 324 21 90 324 minecraft:honeycomb_block
fill 22 87 323 22 90 323 minecraft:honeycomb_block
setblock 24 87 325 minecraft:honey_block
setblock 24 87 332 minecraft:light[level=12]
setblock 24 87 339 minecraft:light[level=12]
setblock 24 87 346 minecraft:light[level=12]
setblock 24 87 353 minecraft:light[level=12]
setblock 24 87 360 minecraft:light[level=12]
setblock 25 87 324 minecraft:yellow_terracotta
setblock 26 87 323 minecraft:yellow_terracotta
fill 27 87 323 27 90 323 minecraft:honeycomb_block
setblock 27 87 333 minecraft:light[level=15]
setblock 27 87 341 minecraft:light[level=15]
setblock 27 87 349 minecraft:light[level=15]
setblock 27 87 357 minecraft:light[level=15]
setblock 27 87 363 minecraft:honey_block
fill 29 87 322 29 132 322 minecraft:honeycomb_block
setblock 30 87 322 minecraft:yellow_terracotta
fill 31 87 322 33 93 322 minecraft:honeycomb_block
setblock 31 87 325 minecraft:light[level=12]
setblock 31 87 332 minecraft:light[level=12]
setblock 31 87 339 minecraft:light[level=12]
setblock 31 87 346 minecraft:light[level=12]
setblock 31 87 353 minecraft:light[level=12]
setblock 31 87 360 minecraft:light[level=12]
setblock 34 87 323 minecraft:honey_block
setblock 35 87 323 minecraft:honeycomb_block
setblock 35 87 325 minecraft:light[level=15]
setblock 35 87 333 minecraft:light[level=15]
setblock 35 87 341 minecraft:light[level=15]
setblock 35 87 349 minecraft:light[level=15]
setblock 35 87 357 minecraft:light[level=15]
setblock 35 87 363 minecraft:honeycomb_block
setblock 36 87 323 minecraft:yellow_terracotta
setblock 36 87 363 minecraft:yellow_terracotta
fill 37 87 323 37 90 323 minecraft:honeycomb_block
fill 37 87 363 37 90 363 minecraft:honeycomb_block
setblock 38 87 325 minecraft:light[level=12]
setblock 38 87 332 minecraft:light[level=12]
setblock 38 87 339 minecraft:light[level=12]
setblock 38 87 346 minecraft:light[level=12]
setblock 38 87 353 minecraft:light[level=12]
setblock 38 87 360 minecraft:light[level=12]
fill 38 87 362 38 90 362 minecraft:honeycomb_block
setblock 39 87 324 minecraft:honeycomb_block
fill 39 87 351 39 87 354 minecraft:honeycomb_block
setblock 39 87 355 minecraft:yellow_terracotta
fill 39 87 356 39 90 356 minecraft:honeycomb_block
fill 39 87 358 39 87 359 minecraft:honeycomb_block
setblock 39 87 360 minecraft:yellow_terracotta
setblock 40 87 324 minecraft:yellow_terracotta
fill 40 87 325 40 90 325 minecraft:honeycomb_block
setblock 40 87 329 minecraft:yellow_terracotta
fill 40 87 330 40 90 330 minecraft:honeycomb_block
setblock 40 87 333 minecraft:honeycomb_block
setblock 40 87 334 minecraft:yellow_terracotta
fill 40 87 335 40 90 335 minecraft:honeycomb_block
setblock 40 87 349 minecraft:yellow_terracotta
fill 40 87 350 40 90 350 minecraft:honeycomb_block
setblock 40 87 354 minecraft:yellow_terracotta
fill 40 87 355 40 90 355 minecraft:honeycomb_block
setblock 40 87 359 minecraft:yellow_terracotta
fill 40 87 360 40 90 360 minecraft:honeycomb_block
setblock 41 87 323 minecraft:yellow_terracotta
fill 41 87 324 41 90 324 minecraft:honeycomb_block
setblock 41 87 328 minecraft:yellow_terracotta
fill 41 87 329 41 90 329 minecraft:honeycomb_block
setblock 41 87 333 minecraft:yellow_terracotta
fill 41 87 334 41 90 334 minecraft:honeycomb_block
setblock 41 87 338 minecraft:yellow_terracotta
fill 41 87 339 41 90 339 minecraft:honeycomb_block
setblock 41 87 341 minecraft:honey_block
fill 41 87 348 42 87 348 minecraft:yellow_terracotta
fill 41 87 349 41 90 349 minecraft:honeycomb_block
setblock 41 87 353 minecraft:yellow_terracotta
fill 41 87 354 41 90 354 minecraft:honeycomb_block
setblock 41 87 358 minecraft:yellow_terracotta
fill 41 87 359 41 90 359 minecraft:honeycomb_block
setblock 41 87 363 minecraft:yellow_terracotta
fill 42 87 323 42 140 323 minecraft:honeycomb_block
setblock 42 87 324 minecraft:yellow_terracotta
setblock 42 87 328 minecraft:honeycomb_block
fill 42 87 342 42 168 342 minecraft:honeycomb_block
setblock 1 88 327 minecraft:yellow_terracotta
fill 1 88 328 1 91 328 minecraft:honeycomb_block
setblock 1 88 332 minecraft:yellow_terracotta
fill 1 88 333 1 91 333 minecraft:honeycomb_block
setblock 1 88 336 minecraft:honeycomb_block
setblock 1 88 337 minecraft:yellow_terracotta
fill 1 88 338 1 88 341 minecraft:honeycomb_block
setblock 1 88 342 minecraft:yellow_terracotta
fill 1 88 343 2 90 343 minecraft:honeycomb_block
setblock 1 88 347 minecraft:yellow_terracotta
fill 1 88 348 1 91 348 minecraft:honeycomb_block
setblock 1 88 352 minecraft:yellow_terracotta
fill 1 88 353 1 91 353 minecraft:honeycomb_block
setblock 1 88 357 minecraft:yellow_terracotta
fill 1 88 358 1 91 358 minecraft:honeycomb_block
setblock 1 88 362 minecraft:yellow_terracotta
fill 1 88 363 1 91 363 minecraft:honeycomb_block
setblock 2 88 331 minecraft:yellow_terracotta
fill 2 88 332 2 91 332 minecraft:honeycomb_block
setblock 2 88 336 minecraft:yellow_terracotta
fill 2 88 337 2 91 337 minecraft:honeycomb_block
fill 2 88 339 2 88 340 minecraft:honeycomb_block
setblock 2 88 341 minecraft:yellow_terracotta
fill 2 88 342 2 91 342 minecraft:honeycomb_block
setblock 2 88 346 minecraft:yellow_terracotta
fill 2 88 347 2 91 347 minecraft:honeycomb_block
setblock 2 88 351 minecraft:yellow_terracotta
fill 2 88 352 2 91 352 minecraft:honeycomb_block
setblock 2 88 356 minecraft:yellow_terracotta
fill 2 88 357 2 91 357 minecraft:honeycomb_block
setblock 2 88 361 minecraft:yellow_terracotta
fill 2 88 362 2 91 362 minecraft:honeycomb_block
setblock 3 88 350 minecraft:yellow_terracotta
fill 3 88 351 3 91 351 minecraft:honeycomb_block
setblock 3 88 355 minecraft:yellow_terracotta
fill 3 88 356 3 91 356 minecraft:honeycomb_block
setblock 3 88 359 minecraft:honeycomb_block
setblock 4 88 354 minecraft:yellow_terracotta
fill 7 88 364 7 117 364 minecraft:honeycomb_block
setblock 9 88 323 minecraft:honey_block
setblock 14 88 363 minecraft:honey_block
fill 17 88 323 17 90 323 minecraft:honeycomb_block
setblock 19 88 324 minecraft:yellow_terracotta
setblock 20 88 323 minecraft:yellow_terracotta
fill 20 88 324 20 91 324 minecraft:honeycomb_block
setblock 20 88 363 minecraft:yellow_terracotta
fill 21 88 323 21 91 323 minecraft:honeycomb_block
fill 21 88 363 24 88 363 minecraft:honeycomb_block
setblock 24 88 324 minecraft:yellow_terracotta
setblock 25 88 323 minecraft:yellow_terracotta
setblock 25 88 324 minecraft:honeycomb_block
fill 26 88 323 26 91 323 minecraft:honeycomb_block
fill 28 88 327 30 88 328 minecraft:honey_block
setblock 29 88 325 minecraft:honey_block
fill 30 88 322 30 308 322 minecraft:honeycomb_block
setblock 33 88 363 minecraft:honey_block
setblock 34 88 323 minecraft:honeycomb_block
setblock 34 88 363 minecraft:honeycomb_block
setblock 35 88 323 minecraft:yellow_terracotta
fill 35 88 346 35 89 346 minecraft:ochre_froglight
setblock 35 88 363 minecraft:yellow_terracotta
fill 36 88 323 36 91 323 minecraft:honeycomb_block
setblock 36 88 362 minecraft:yellow_terracotta
fill 36 88 363 36 91 363 minecraft:honeycomb_block
fill 37 88 362 37 91 362 minecraft:honeycomb_block
setblock 38 88 324 minecraft:honeycomb_block
setblock 38 88 354 minecraft:honeycomb_block
setblock 38 88 355 minecraft:yellow_terracotta
fill 38 88 356 38 90 357 minecraft:honeycomb_block
fill 38 88 361 39 90 361 minecraft:honeycomb_block
setblock 39 88 324 minecraft:yellow_terracotta
fill 39 88 331 39 89 332 minecraft:honeycomb_block
fill 39 88 350 39 88 353 minecraft:honeycomb_block
setblock 39 88 354 minecraft:yellow_terracotta
fill 39 88 355 39 91 355 minecraft:honeycomb_block
setblock 39 88 358 minecraft:honeycomb_block
setblock 39 88 359 minecraft:yellow_terracotta
fill 39 88 360 39 91 360 minecraft:honeycomb_block
setblock 40 88 323 minecraft:yellow_terracotta
fill 40 88 324 40 90 324 minecraft:honeycomb_block
setblock 40 88 328 minecraft:yellow_terracotta
fill 40 88 329 40 91 329 minecraft:honeycomb_block
setblock 40 88 333 minecraft:yellow_terracotta
fill 40 88 334 40 91 334 minecraft:honeycomb_block
fill 40 88 336 40 88 337 minecraft:honeycomb_block
setblock 40 88 347 minecraft:honeycomb_block
setblock 40 88 348 minecraft:yellow_terracotta
fill 40 88 349 40 91 349 minecraft:honeycomb_block
setblock 40 88 353 minecraft:yellow_terracotta
fill 40 88 354 40 91 354 minecraft:honeycomb_block
setblock 40 88 358 minecraft:yellow_terracotta
fill 40 88 359 40 91 359 minecraft:honeycomb_block
setblock 40 88 363 minecraft:yellow_terracotta
fill 41 88 323 41 91 323 minecraft:honeycomb_block
setblock 41 88 327 minecraft:yellow_terracotta
fill 41 88 328 41 91 328 minecraft:honeycomb_block
setblock 41 88 332 minecraft:yellow_terracotta
fill 41 88 333 41 91 333 minecraft:honeycomb_block
fill 41 88 335 41 88 336 minecraft:honeycomb_block
setblock 41 88 337 minecraft:yellow_terracotta
fill 41 88 338 41 91 338 minecraft:honeycomb_block
fill 41 88 340 41 88 341 minecraft:honeycomb_block
setblock 41 88 342 minecraft:yellow_terracotta
fill 41 88 343 41 90 344 minecraft:honeycomb_block
setblock 41 88 347 minecraft:yellow_terracotta
fill 41 88 348 42 91 348 minecraft:honeycomb_block
setblock 41 88 352 minecraft:yellow_terracotta
fill 41 88 353 41 91 353 minecraft:honeycomb_block
setblock 41 88 357 minecraft:yellow_terracotta
fill 41 88 358 41 91 358 minecraft:honeycomb_block
setblock 41 88 362 minecraft:yellow_terracotta
fill 41 88 363 41 91 363 minecraft:honeycomb_block
fill 42 88 324 42 153 324 minecraft:honeycomb_block
setblock 42 88 325 minecraft:orange_terracotta
setblock 42 88 328 minecraft:yellow_terracotta
setblock 1 89 326 minecraft:yellow_terracotta
fill 1 89 327 1 91 327 minecraft:honeycomb_block
setblock 1 89 331 minecraft:yellow_terracotta
fill 1 89 332 1 92 332 minecraft:honeycomb_block
setblock 1 89 335 minecraft:honeycomb_block
setblock 1 89 336 minecraft:yellow_terracotta
fill 1 89 337 1 89 340 minecraft:honeycomb_block
setblock 1 89 341 minecraft:yellow_terracotta
fill 1 89 342 1 92 342 minecraft:honeycomb_block
setblock 1 89 346 minecraft:yellow_terracotta
fill 1 89 347 1 92 347 minecraft:honeycomb_block
setblock 1 89 351 minecraft:yellow_terracotta
fill 1 89 352 1 92 352 minecraft:honeycomb_block
setblock 1 89 356 minecraft:yellow_terracotta
fill 1 89 357 1 92 357 minecraft:honeycomb_block
setblock 1 89 361 minecraft:yellow_terracotta
fill 1 89 362 1 92 362 minecraft:honeycomb_block
setblock 2 89 330 minecraft:yellow_terracotta
fill 2 89 331 2 92 331 minecraft:honeycomb_block
setblock 2 89 335 minecraft:yellow_terracotta
fill 2 89 336 3 91 336 minecraft:honeycomb_block
setblock 2 89 339 minecraft:honeycomb_block
setblock 2 89 340 minecraft:yellow_terracotta
fill 2 89 341 2 92 341 minecraft:honeycomb_block
setblock 2 89 345 minecraft:yellow_terracotta
fill 2 89 346 2 92 346 minecraft:honeycomb_block
setblock 2 89 350 minecraft:yellow_terracotta
fill 2 89 351 2 92 351 minecraft:honeycomb_block
setblock 2 89 355 minecraft:yellow_terracotta
fill 2 89 356 2 92 356 minecraft:honeycomb_block
setblock 2 89 360 minecraft:yellow_terracotta
fill 2 89 361 2 92 361 minecraft:honeycomb_block
setblock 3 89 323 minecraft:honey_block
setblock 3 89 333 minecraft:honeycomb_block
setblock 3 89 334 minecraft:yellow_terracotta
fill 3 89 335 3 92 335 minecraft:honeycomb_block
setblock 3 89 349 minecraft:yellow_terracotta
fill 3 89 350 3 91 350 minecraft:honeycomb_block
setblock 3 89 354 minecraft:yellow_terracotta
fill 3 89 355 3 92 355 minecraft:honeycomb_block
setblock 3 89 359 minecraft:yellow_terracotta
setblock 4 89 354 minecraft:honeycomb_block
setblock 10 89 322 minecraft:yellow_terracotta
fill 16 89 323 16 91 323 minecraft:honeycomb_block
setblock 18 89 324 minecraft:yellow_terracotta
setblock 18 89 363 minecraft:honeycomb_block
setblock 19 89 323 minecraft:yellow_terracotta
fill 19 89 324 19 92 324 minecraft:honeycomb_block
setblock 19 89 363 minecraft:yellow_terracotta
fill 20 89 323 20 92 323 minecraft:honeycomb_block
fill 20 89 363 23 89 363 minecraft:honeycomb_block
setblock 23 89 324 minecraft:yellow_terracotta
setblock 24 89 323 minecraft:yellow_terracotta
fill 24 89 324 24 91 324 minecraft:honeycomb_block
setblock 24 89 363 minecraft:yellow_terracotta
fill 25 89 323 25 92 323 minecraft:honeycomb_block
fill 25 89 363 25 92 363 minecraft:honeycomb_block
fill 26 89 326 27 89 326 minecraft:honey_block
fill 27 89 329 27 94 329 minecraft:brown_terracotta
fill 28 89 327 28 89 328 minecraft:honey_block
fill 32 89 323 33 89 323 minecraft:honeycomb_block
fill 32 89 363 33 89 363 minecraft:honeycomb_block
setblock 34 89 323 minecraft:yellow_terracotta
setblock 34 89 362 minecraft:honeycomb_block
setblock 34 89 363 minecraft:yellow_terracotta
fill 35 89 323 35 92 323 minecraft:honeycomb_block
setblock 35 89 362 minecraft:yellow_terracotta
fill 35 89 363 35 92 363 minecraft:honeycomb_block
setblock 36 89 361 minecraft:yellow_terracotta
fill 36 89 362 36 92 362 minecraft:honeycomb_block
setblock 37 89 324 minecraft:honeycomb_block
fill 37 89 361 37 92 361 minecraft:honeycomb_block
setblock 38 89 324 minecraft:yellow_terracotta
setblock 38 89 353 minecraft:honeycomb_block
setblock 38 89 354 minecraft:yellow_terracotta
fill 38 89 355 38 92 355 minecraft:honeycomb_block
setblock 38 89 358 minecraft:honeycomb_block
setblock 38 89 359 minecraft:yellow_terracotta
setblock 39 89 323 minecraft:yellow_terracotta
fill 39 89 324 39 91 324 minecraft:honeycomb_block
setblock 39 89 333 minecraft:yellow_terracotta
fill 39 89 334 39 92 334 minecraft:honeycomb_block
fill 39 89 350 39 89 352 minecraft:honeycomb_block
setblock 39 89 353 minecraft:yellow_terracotta
fill 39 89 354 39 92 354 minecraft:honeycomb_block
setblock 39 89 358 minecraft:yellow_terracotta
fill 39 89 359 39 92 359 minecraft:honeycomb_block
setblock 39 89 362 minecraft:honeycomb_block
setblock 39 89 363 minecraft:yellow_terracotta
fill 40 89 323 40 92 323 minecraft:honeycomb_block
setblock 40 89 327 minecraft:yellow_terracotta
fill 40 89 328 40 91 328 minecraft:honeycomb_block
setblock 40 89 332 minecraft:yellow_terracotta
fill 40 89 333 40 92 333 minecraft:honeycomb_block
setblock 40 89 336 minecraft:honeycomb_block
setblock 40 89 337 minecraft:yellow_terracotta
fill 40 89 338 40 92 338 minecraft:honeycomb_block
setblock 40 89 347 minecraft:yellow_terracotta
fill 40 89 348 40 92 348 minecraft:honeycomb_block
setblock 40 89 352 minecraft:yellow_terracotta
fill 40 89 353 40 92 353 minecraft:honeycomb_block
setblock 40 89 357 minecraft:yellow_terracotta
fill 40 89 358 40 92 358 minecraft:honeycomb_block
setblock 40 89 362 minecraft:yellow_terracotta
fill 40 89 363 40 92 363 minecraft:honeycomb_block
setblock 41 89 326 minecraft:yellow_terracotta
fill 41 89 327 41 92 327 minecraft:honeycomb_block
setblock 41 89 331 minecraft:yellow_terracotta
fill 41 89 332 41 92 332 minecraft:honeycomb_block
setblock 41 89 335 minecraft:honeycomb_block
setblock 41 89 336 minecraft:yellow_terracotta
fill 41 89 337 41 92 337 minecraft:honeycomb_block
setblock 41 89 340 minecraft:honeycomb_block
setblock 41 89 341 minecraft:yellow_terracotta
fill 41 89 342 41 92 342 minecraft:honeycomb_block
setblock 41 89 346 minecraft:yellow_terracotta
fill 41 89 347 41 92 347 minecraft:honeycomb_block
setblock 41 89 351 minecraft:yellow_terracotta
fill 41 89 352 41 92 352 minecraft:honeycomb_block
setblock 41 89 356 minecraft:yellow_terracotta
fill 41 89 357 41 92 357 minecraft:honeycomb_block
setblock 41 89 361 minecraft:yellow_terracotta
fill 41 89 362 41 92 362 minecraft:honeycomb_block
fill 42 89 325 42 308 325 minecraft:honeycomb_block
fill 42 89 328 42 115 328 minecraft:honeycomb_block
setblock 0 90 333 minecraft:orange_terracotta
setblock 0 90 359 minecraft:orange_terracotta
setblock 1 90 326 minecraft:honeycomb_block
setblock 1 90 330 minecraft:yellow_terracotta
fill 1 90 331 1 93 331 minecraft:honeycomb_block
setblock 1 90 335 minecraft:yellow_terracotta
fill 1 90 336 1 90 339 minecraft:honeycomb_block
setblock 1 90 340 minecraft:yellow_terracotta
fill 1 90 341 1 93 341 minecraft:honeycomb_block
setblock 1 90 345 minecraft:yellow_terracotta
fill 1 90 346 1 93 346 minecraft:honeycomb_block
setblock 1 90 350 minecraft:yellow_terracotta
fill 1 90 351 1 93 351 minecraft:honeycomb_block
setblock 1 90 355 minecraft:yellow_terracotta
fill 1 90 356 1 93 356 minecraft:honeycomb_block
setblock 1 90 360 minecraft:yellow_terracotta
fill 1 90 361 1 93 361 minecraft:honeycomb_block
fill 2 90 330 2 91 330 minecraft:honeycomb_block
setblock 2 90 334 minecraft:yellow_terracotta
fill 2 90 335 2 93 335 minecraft:honeycomb_block
setblock 2 90 339 minecraft:yellow_terracotta
fill 2 90 340 2 93 340 minecraft:honeycomb_block
setblock 2 90 344 minecraft:yellow_terracotta
fill 2 90 345 2 93 345 minecraft:honeycomb_block
setblock 2 90 349 minecraft:yellow_terracotta
fill 2 90 350 2 93 350 minecraft:honeycomb_block
setblock 2 90 354 minecraft:yellow_terracotta
fill 2 90 355 2 93 355 minecraft:honeycomb_block
setblock 2 90 358 minecraft:honeycomb_block
setblock 2 90 359 minecraft:yellow_terracotta
fill 2 90 360 2 93 360 minecraft:honeycomb_block
setblock 3 90 333 minecraft:yellow_terracotta
fill 3 90 334 3 91 334 minecraft:honeycomb_block
setblock 3 90 337 minecraft:honeycomb_block
setblock 3 90 338 minecraft:yellow_terracotta
setblock 3 90 349 minecraft:honeycomb_block
setblock 3 90 353 minecraft:yellow_terracotta
fill 3 90 354 3 92 354 minecraft:honeycomb_block
setblock 3 90 358 minecraft:yellow_terracotta
fill 3 90 359 3 92 359 minecraft:honeycomb_block
setblock 3 90 363 minecraft:yellow_terracotta
fill 4 90 363 4 91 363 minecraft:honeycomb_block
fill 10 90 322 10 147 322 minecraft:honeycomb_block
fill 15 90 323 15 92 323 minecraft:honeycomb_block
fill 16 90 363 17 90 363 minecraft:honeycomb_block
setblock 17 90 324 minecraft:yellow_terracotta
setblock 18 90 323 minecraft:yellow_terracotta
fill 18 90 324 18 93 324 minecraft:honeycomb_block
setblock 18 90 363 minecraft:yellow_terracotta
fill 19 90 323 19 93 323 minecraft:honeycomb_block
setblock 19 90 362 minecraft:yellow_terracotta
fill 19 90 363 22 90 363 minecraft:honeycomb_block
fill 20 90 362 22 91 362 minecraft:honeycomb_block
setblock 22 90 324 minecraft:yellow_terracotta
setblock 23 90 323 minecraft:yellow_terracotta
fill 23 90 324 23 92 324 minecraft:honeycomb_block
setblock 23 90 363 minecraft:yellow_terracotta
fill 24 90 323 24 93 323 minecraft:honeycomb_block
fill 24 90 363 24 93 363 minecraft:honeycomb_block
fill 26 90 328 26 94 329 minecraft:brown_terracotta
fill 26 90 363 27 90 363 minecraft:honeycomb_block
fill 27 90 327 28 94 328 minecraft:brown_terracotta
setblock 28 90 323 minecraft:yellow_terracotta
fill 28 90 329 28 94 329 minecraft:brown_terracotta
fill 29 90 323 29 93 323 minecraft:honeycomb_block
fill 29 90 363 32 90 363 minecraft:honeycomb_block
fill 31 90 323 32 90 323 minecraft:honeycomb_block
setblock 33 90 323 minecraft:yellow_terracotta
setblock 33 90 362 minecraft:honeycomb_block
setblock 33 90 363 minecraft:yellow_terracotta
fill 34 90 323 34 93 323 minecraft:honeycomb_block
setblock 34 90 362 minecraft:yellow_terracotta
fill 34 90 363 34 93 363 minecraft:honeycomb_block
setblock 34 90 364 minecraft:orange_terracotta
fill 35 90 346 35 98 346 minecraft:brown_terracotta
setblock 35 90 361 minecraft:yellow_terracotta
fill 35 90 362 35 93 362 minecraft:honeycomb_block
setblock 36 90 324 minecraft:honeycomb_block
fill 36 90 361 36 93 361 minecraft:honeycomb_block
setblock 37 90 324 minecraft:yellow_terracotta
fill 37 90 360 38 92 360 minecraft:honeycomb_block
setblock 38 90 323 minecraft:yellow_terracotta
fill 38 90 324 38 92 324 minecraft:honeycomb_block
setblock 38 90 353 minecraft:yellow_terracotta
fill 38 90 354 38 93 354 minecraft:honeycomb_block
setblock 38 90 358 minecraft:yellow_terracotta
fill 38 90 359 38 93 359 minecraft:honeycomb_block
setblock 38 90 363 minecraft:yellow_terracotta
fill 39 90 323 39 93 323 minecraft:honeycomb_block
setblock 39 90 331 minecraft:honeycomb_block
setblock 39 90 332 minecraft:yellow_terracotta
fill 39 90 333 39 91 333 minecraft:honeycomb_block
fill 39 90 335 39 91 335 minecraft:honeycomb_block
fill 39 90 350 39 90 351 minecraft:honeycomb_block
setblock 39 90 352 minecraft:yellow_terracotta
fill 39 90 353 39 93 353 minecraft:honeycomb_block
setblock 39 90 357 minecraft:yellow_terracotta
fill 39 90 358 39 93 358 minecraft:honeycomb_block
setblock 39 90 362 minecraft:yellow_terracotta
fill 39 90 363 39 93 363 minecraft:honeycomb_block
setblock 40 90 326 minecraft:yellow_terracotta
setblock 40 90 327 minecraft:honeycomb_block
setblock 40 90 331 minecraft:yellow_terracotta
fill 40 90 332 40 93 332 minecraft:honeycomb_block
setblock 40 90 336 minecraft:yellow_terracotta
fill 40 90 337 40 93 337 minecraft:honeycomb_block
fill 40 90 339 40 90 340 minecraft:honeycomb_block
fill 40 90 347 40 92 347 minecraft:honeycomb_block
setblock 40 90 351 minecraft:yellow_terracotta
fill 40 90 352 40 93 352 minecraft:honeycomb_block
setblock 40 90 356 minecraft:yellow_terracotta
fill 40 90 357 40 93 357 minecraft:honeycomb_block
setblock 40 90 361 minecraft:yellow_terracotta
fill 40 90 362 40 93 362 minecraft:honeycomb_block
setblock 41 90 325 minecraft:yellow_terracotta
fill 41 90 326 41 92 326 minecraft:honeycomb_block
setblock 41 90 330 minecraft:yellow_terracotta
fill 41 90 331 41 93 331 minecraft:honeycomb_block
setblock 41 90 335 minecraft:yellow_terracotta
fill 41 90 336 41 93 336 minecraft:honeycomb_block
setblock 41 90 340 minecraft:yellow_terracotta
fill 41 90 341 41 93 341 minecraft:honeycomb_block
setblock 41 90 345 minecraft:yellow_terracotta
fill 41 90 346 41 93 346 minecraft:honeycomb_block
setblock 41 90 350 minecraft:yellow_terracotta
fill 41 90 351 41 93 351 minecraft:honeycomb_block
setblock 41 90 355 minecraft:yellow_terracotta
fill 41 90 356 41 93 356 minecraft:honeycomb_block
setblock 41 90 360 minecraft:yellow_terracotta
fill 41 90 361 41 93 361 minecraft:honeycomb_block
fill 0 91 333 0 93 333 minecraft:honeycomb_block
fill 0 91 359 0 276 359 minecraft:honeycomb_block
setblock 1 91 325 minecraft:honey_block
setblock 1 91 329 minecraft:yellow_terracotta
fill 1 91 330 1 93 330 minecraft:honeycomb_block
setblock 1 91 334 minecraft:yellow_terracotta
fill 1 91 335 1 91 338 minecraft:honeycomb_block
setblock 1 91 339 minecraft:yellow_terracotta
fill 1 91 340 1 94 340 minecraft:honeycomb_block
setblock 1 91 343 minecraft:honeycomb_block
setblock 1 91 344 minecraft:yellow_terracotta
fill 1 91 345 1 94 345 minecraft:honeycomb_block
setblock 1 91 349 minecraft:yellow_terracotta
fill 1 91 350 1 94 350 minecraft:honeycomb_block
setblock 1 91 354 minecraft:yellow_terracotta
fill 1 91 355 1 94 355 minecraft:honeycomb_block
setblock 1 91 359 minecraft:yellow_terracotta
fill 1 91 360 1 94 360 minecraft:honeycomb_block
setblock 2 91 333 minecraft:yellow_terracotta
fill 2 91 334 2 94 334 minecraft:honeycomb_block
setblock 2 91 338 minecraft:yellow_terracotta
fill 2 91 339 3 93 339 minecraft:honeycomb_block
setblock 2 91 343 minecraft:yellow_terracotta
fill 2 91 344 2 94 344 minecraft:honeycomb_block
setblock 2 91 348 minecraft:yellow_terracotta
fill 2 91 349 2 93 349 minecraft:honeycomb_block
setblock 2 91 353 minecraft:yellow_terracotta
fill 2 91 354 2 94 354 minecraft:honeycomb_block
setblock 2 91 358 minecraft:yellow_terracotta
fill 2 91 359 2 94 359 minecraft:honeycomb_block
setblock 2 91 363 minecraft:yellow_terracotta
setblock 3 91 337 minecraft:yellow_terracotta
fill 3 91 338 3 94 338 minecraft:honeycomb_block
setblock 3 91 352 minecraft:yellow_terracotta
fill 3 91 353 3 92 353 minecraft:honeycomb_block
setblock 3 91 357 minecraft:yellow_terracotta
fill 3 91 358 3 92 358 minecraft:honeycomb_block
fill 3 91 363 3 93 363 minecraft:honeycomb_block
fill 4 91 353 4 95 353 minecraft:yellow_terracotta
fill 5 91 352 5 95 352 minecraft:yellow_terracotta
fill 5 91 354 5 95 354 minecraft:yellow_terracotta
fill 6 91 353 6 95 353 minecraft:yellow_terracotta
setblock 7 91 363 minecraft:honey_block
setblock 10 91 323 minecraft:honey_block
fill 15 91 363 16 91 363 minecraft:honeycomb_block
setblock 17 91 323 minecraft:yellow_terracotta
fill 17 91 324 17 94 324 minecraft:honeycomb_block
setblock 17 91 362 minecraft:honeycomb_block
setblock 17 91 363 minecraft:yellow_terracotta
fill 18 91 323 18 94 323 minecraft:honeycomb_block
setblock 18 91 362 minecraft:yellow_terracotta
fill 18 91 363 21 91 363 minecraft:honeycomb_block
fill 19 91 362 19 94 362 minecraft:honeycomb_block
setblock 21 91 324 minecraft:yellow_terracotta
setblock 22 91 323 minecraft:yellow_terracotta
fill 22 91 324 22 93 324 minecraft:honeycomb_block
setblock 22 91 363 minecraft:yellow_terracotta
fill 23 91 323 23 94 323 minecraft:honeycomb_block
setblock 23 91 362 minecraft:yellow_terracotta
fill 23 91 363 23 94 363 minecraft:honeycomb_block
fill 25 91 364 26 102 364 minecraft:honeycomb_block
fill 26 91 327 26 94 327 minecraft:brown_terracotta
setblock 26 91 363 minecraft:honeycomb_block
setblock 27 91 323 minecraft:yellow_terracotta
setblock 27 91 363 minecraft:yellow_terracotta
setblock 27 91 364 minecraft:orange_terracotta
fill 28 91 323 28 94 323 minecraft:honeycomb_block
fill 28 91 363 30 92 364 minecraft:honeycomb_block
fill 29 91 328 29 94 328 minecraft:brown_terracotta
fill 30 91 323 31 91 323 minecraft:honeycomb_block
setblock 31 91 363 minecraft:honeycomb_block
setblock 32 91 323 minecraft:yellow_terracotta
setblock 32 91 362 minecraft:honeycomb_block
setblock 32 91 363 minecraft:yellow_terracotta
fill 33 91 323 33 94 323 minecraft:honeycomb_block
setblock 33 91 362 minecraft:yellow_terracotta
fill 33 91 363 33 94 363 minecraft:honeycomb_block
setblock 34 91 361 minecraft:yellow_terracotta
fill 34 91 362 34 94 362 minecraft:honeycomb_block
fill 34 91 364 34 106 364 minecraft:honeycomb_block
fill 35 91 345 36 98 345 minecraft:brown_terracotta
setblock 35 91 360 minecraft:yellow_terracotta
fill 35 91 361 35 94 361 minecraft:honeycomb_block
setblock 36 91 324 minecraft:yellow_terracotta
fill 36 91 346 36 98 346 minecraft:brown_terracotta
fill 36 91 360 36 94 360 minecraft:honeycomb_block
setblock 37 91 323 minecraft:yellow_terracotta
fill 37 91 324 37 93 324 minecraft:honeycomb_block
setblock 37 91 357 minecraft:honeycomb_block
setblock 37 91 363 minecraft:yellow_terracotta
fill 38 91 323 38 94 323 minecraft:honeycomb_block
fill 38 91 353 38 92 353 minecraft:honeycomb_block
setblock 38 91 356 minecraft:honeycomb_block
setblock 38 91 357 minecraft:yellow_terracotta
fill 38 91 358 38 94 358 minecraft:honeycomb_block
setblock 38 91 361 minecraft:honeycomb_block
setblock 38 91 362 minecraft:yellow_terracotta
fill 38 91 363 38 94 363 minecraft:honeycomb_block
setblock 39 91 332 minecraft:honeycomb_block
setblock 39 91 336 minecraft:yellow_terracotta
fill 39 91 337 39 93 337 minecraft:honeycomb_block
setblock 39 91 350 minecraft:honeycomb_block
setblock 39 91 351 minecraft:yellow_terracotta
fill 39 91 352 39 94 352 minecraft:honeycomb_block
setblock 39 91 356 minecraft:yellow_terracotta
fill 39 91 357 39 94 357 minecraft:honeycomb_block
setblock 39 91 361 minecraft:yellow_terracotta
fill 39 91 362 39 94 362 minecraft:honeycomb_block
setblock 40 91 330 minecraft:yellow_terracotta
fill 40 91 331 40 92 331 minecraft:honeycomb_block
setblock 40 91 335 minecraft:yellow_terracotta
fill 40 91 336 40 94 336 minecraft:honeycomb_block
setblock 40 91 339 minecraft:honeycomb_block
setblock 40 91 340 minecraft:yellow_terracotta
fill 40 91 341 40 94 341 minecraft:honeycomb_block
setblock 40 91 350 minecraft:yellow_terracotta
fill 40 91 351 40 94 351 minecraft:honeycomb_block
setblock 40 91 355 minecraft:yellow_terracotta
fill 40 91 356 40 94 356 minecraft:honeycomb_block
setblock 40 91 360 minecraft:yellow_terracotta
fill 40 91 361 40 94 361 minecraft:honeycomb_block
setblock 41 91 324 minecraft:yellow_terracotta
fill 41 91 325 41 92 325 minecraft:honeycomb_block
setblock 41 91 329 minecraft:yellow_terracotta
fill 41 91 330 41 93 330 minecraft:honeycomb_block
setblock 41 91 334 minecraft:yellow_terracotta
fill 41 91 335 41 94 335 minecraft:honeycomb_block
setblock 41 91 339 minecraft:yellow_terracotta
fill 41 91 340 41 94 340 minecraft:honeycomb_block
setblock 41 91 343 minecraft:honeycomb_block
setblock 41 91 344 minecraft:yellow_terracotta
fill 41 91 345 41 94 345 minecraft:honeycomb_block
setblock 41 91 349 minecraft:yellow_terracotta
fill 41 91 350 41 94 350 minecraft:honeycomb_block
setblock 41 91 354 minecraft:yellow_terracotta
fill 41 91 355 41 94 355 minecraft:honeycomb_block
setblock 41 91 359 minecraft:yellow_terracotta
fill 41 91 360 41 94 360 minecraft:honeycomb_block
setblock 0 92 337 minecraft:yellow_terracotta
setblock 1 92 328 minecraft:yellow_terracotta
fill 1 92 329 1 93 329 minecraft:honeycomb_block
setblock 1 92 333 minecraft:yellow_terracotta
fill 1 92 334 1 92 337 minecraft:honeycomb_block
setblock 1 92 338 minecraft:yellow_terracotta
fill 1 92 339 1 95 339 minecraft:honeycomb_block
setblock 1 92 343 minecraft:yellow_terracotta
fill 1 92 344 1 95 344 minecraft:honeycomb_block
setblock 1 92 348 minecraft:yellow_terracotta
fill 1 92 349 1 95 349 minecraft:honeycomb_block
setblock 1 92 353 minecraft:yellow_terracotta
fill 1 92 354 1 95 354 minecraft:honeycomb_block
setblock 1 92 358 minecraft:yellow_terracotta
fill 1 92 359 1 95 359 minecraft:honeycomb_block
setblock 1 92 363 minecraft:yellow_terracotta
setblock 2 92 332 minecraft:yellow_terracotta
fill 2 92 333 2 93 333 minecraft:honeycomb_block
setblock 2 92 336 minecraft:honeycomb_block
setblock 2 92 337 minecraft:yellow_terracotta
fill 2 92 338 2 95 338 minecraft:honeycomb_block
setblock 2 92 342 minecraft:yellow_terracotta
fill 2 92 343 2 95 343 minecraft:honeycomb_block
setblock 2 92 347 minecraft:yellow_terracotta
fill 2 92 348 2 93 348 minecraft:honeycomb_block
setblock 2 92 352 minecraft:yellow_terracotta
fill 2 92 353 2 94 353 minecraft:honeycomb_block
setblock 2 92 357 minecraft:yellow_terracotta
fill 2 92 358 2 95 358 minecraft:honeycomb_block
setblock 2 92 362 minecraft:yellow_terracotta
fill 2 92 363 2 95 363 minecraft:honeycomb_block
setblock 3 92 336 minecraft:yellow_terracotta
fill 3 92 337 3 93 337 minecraft:honeycomb_block
setblock 3 92 340 minecraft:honeycomb_block
setblock 3 92 352 minecraft:honeycomb_block
setblock 3 92 356 minecraft:yellow_terracotta
fill 3 92 357 3 93 357 minecraft:honeycomb_block
setblock 4 92 323 minecraft:honey_block
setblock 13 92 363 minecraft:honey_block
fill 14 92 323 14 93 323 minecraft:honeycomb_block
fill 14 92 363 15 92 363 minecraft:honeycomb_block
setblock 16 92 323 minecraft:yellow_terracotta
fill 16 92 324 16 95 324 minecraft:honeycomb_block
setblock 16 92 362 minecraft:honeycomb_block
setblock 16 92 363 minecraft:yellow_terracotta
fill 17 92 323 17 95 323 minecraft:honeycomb_block
setblock 17 92 362 minecraft:yellow_terracotta
fill 17 92 363 20 92 363 minecraft:honeycomb_block
fill 18 92 362 18 95 362 minecraft:honeycomb_block
setblock 20 92 324 minecraft:yellow_terracotta
fill 20 92 362 21 92 362 minecraft:honeycomb_block
setblock 21 92 323 minecraft:yellow_terracotta
fill 21 92 324 21 94 324 minecraft:honeycomb_block
setblock 21 92 363 minecraft:yellow_terracotta
fill 22 92 323 22 95 323 minecraft:honeycomb_block
setblock 22 92 362 minecraft:yellow_terracotta
fill 22 92 363 22 95 363 minecraft:honeycomb_block
fill 23 92 362 23 94 362 minecraft:honeycomb_block
fill 25 92 327 25 94 329 minecraft:brown_terracotta
setblock 26 92 323 minecraft:yellow_terracotta
fill 26 92 326 28 94 326 minecraft:brown_terracotta
fill 26 92 330 28 94 330 minecraft:brown_terracotta
setblock 26 92 363 minecraft:yellow_terracotta
fill 27 92 323 27 94 323 minecraft:honeycomb_block
fill 27 92 363 27 95 364 minecraft:honeycomb_block
fill 29 92 327 29 94 327 minecraft:brown_terracotta
fill 29 92 329 29 94 329 minecraft:brown_terracotta
setblock 30 92 323 minecraft:honeycomb_block
fill 30 92 362 31 92 362 minecraft:honeycomb_block
setblock 31 92 323 minecraft:yellow_terracotta
setblock 31 92 363 minecraft:yellow_terracotta
fill 32 92 323 32 95 323 minecraft:honeycomb_block
setblock 32 92 362 minecraft:yellow_terracotta
fill 32 92 363 32 95 363 minecraft:honeycomb_block
setblock 33 92 361 minecraft:yellow_terracotta
fill 33 92 362 33 95 362 minecraft:honeycomb_block
fill 34 92 345 34 98 346 minecraft:brown_terracotta
fill 34 92 361 34 95 361 minecraft:honeycomb_block
fill 35 92 347 35 98 347 minecraft:brown_terracotta
fill 35 92 360 35 95 360 minecraft:honeycomb_block
setblock 36 92 323 minecraft:yellow_terracotta
fill 36 92 324 36 93 324 minecraft:honeycomb_block
fill 36 92 332 37 93 333 minecraft:honey_block
setblock 36 92 363 minecraft:yellow_terracotta
fill 37 92 323 37 95 323 minecraft:honeycomb_block
setblock 37 92 357 minecraft:yellow_terracotta
fill 37 92 358 37 94 359 minecraft:honeycomb_block
setblock 37 92 362 minecraft:yellow_terracotta
fill 37 92 363 37 95 363 minecraft:honeycomb_block
setblock 38 92 356 minecraft:yellow_terracotta
fill 38 92 357 38 95 357 minecraft:honeycomb_block
setblock 38 92 361 minecraft:yellow_terracotta
fill 38 92 362 38 95 362 minecraft:honeycomb_block
setblock 39 92 335 minecraft:yellow_terracotta
fill 39 92 336 39 93 336 minecraft:honeycomb_block
setblock 39 92 350 minecraft:yellow_terracotta
fill 39 92 351 39 93 351 minecraft:honeycomb_block
setblock 39 92 355 minecraft:yellow_terracotta
fill 39 92 356 39 95 356 minecraft:honeycomb_block
setblock 39 92 360 minecraft:yellow_terracotta
fill 39 92 361 39 95 361 minecraft:honeycomb_block
setblock 40 92 330 minecraft:honeycomb_block
setblock 40 92 334 minecraft:yellow_terracotta
fill 40 92 335 40 94 335 minecraft:honeycomb_block
setblock 40 92 339 minecraft:yellow_terracotta
fill 40 92 340 40 95 340 minecraft:honeycomb_block
fill 40 92 342 40 93 342 minecraft:honeycomb_block
setblock 40 92 349 minecraft:yellow_terracotta
fill 40 92 350 40 94 350 minecraft:honeycomb_block
setblock 40 92 354 minecraft:yellow_terracotta
fill 40 92 355 40 95 355 minecraft:honeycomb_block
setblock 40 92 359 minecraft:yellow_terracotta
fill 40 92 360 40 95 360 minecraft:honeycomb_block
setblock 41 92 323 minecraft:yellow_terracotta
fill 41 92 324 41 93 324 minecraft:honeycomb_block
setblock 41 92 328 minecraft:yellow_terracotta
fill 41 92 329 41 93 329 minecraft:honeycomb_block
setblock 41 92 333 minecraft:yellow_terracotta
fill 41 92 334 41 95 334 minecraft:honeycomb_block
setblock 41 92 338 minecraft:yellow_terracotta
fill 41 92 339 41 95 339 minecraft:honeycomb_block
setblock 41 92 343 minecraft:yellow_terracotta
fill 41 92 344 41 95 344 minecraft:honeycomb_block
setblock 41 92 348 minecraft:yellow_terracotta
fill 41 92 349 41 95 349 minecraft:honeycomb_block
setblock 41 92 353 minecraft:yellow_terracotta
fill 41 92 354 41 95 354 minecraft:honeycomb_block
setblock 41 92 358 minecraft:yellow_terracotta
fill 41 92 359 41 95 359 minecraft:honeycomb_block
setblock 41 92 363 minecraft:yellow_terracotta
setblock 42 92 326 minecraft:orange_terracotta
fill 42 92 348 42 144 348 minecraft:honeycomb_block
fill 0 93 337 0 308 337 minecraft:honeycomb_block
fill 0 93 348 0 132 349 minecraft:honeycomb_block
setblock 0 93 350 minecraft:yellow_concrete
setblock 1 93 332 minecraft:yellow_terracotta
fill 1 93 333 1 93 336 minecraft:honeycomb_block
setblock 1 93 337 minecraft:yellow_terracotta
fill 1 93 338 1 96 338 minecraft:honeycomb_block
setblock 1 93 342 minecraft:yellow_terracotta
fill 1 93 343 1 96 343 minecraft:honeycomb_block
setblock 1 93 347 minecraft:yellow_terracotta
fill 1 93 348 1 96 348 minecraft:honeycomb_block
setblock 1 93 352 minecraft:yellow_terracotta
fill 1 93 353 1 96 353 minecraft:honeycomb_block
setblock 1 93 357 minecraft:yellow_terracotta
fill 1 93 358 1 96 358 minecraft:honeycomb_block
setblock 1 93 362 minecraft:yellow_terracotta
fill 1 93 363 1 96 363 minecraft:honeycomb_block
setblock 2 93 332 minecraft:honeycomb_block
setblock 2 93 336 minecraft:yellow_terracotta
fill 2 93 337 2 96 337 minecraft:honeycomb_block
setblock 2 93 341 minecraft:yellow_terracotta
fill 2 93 342 2 96 342 minecraft:honeycomb_block
setblock 2 93 346 minecraft:yellow_terracotta
setblock 2 93 347 minecraft:honeycomb_block
setblock 2 93 351 minecraft:yellow_terracotta
fill 2 93 352 2 94 352 minecraft:honeycomb_block
setblock 2 93 356 minecraft:yellow_terracotta
fill 2 93 357 2 95 357 minecraft:honeycomb_block
setblock 2 93 361 minecraft:yellow_terracotta
setblock 2 93 362 minecraft:honeycomb_block
setblock 3 93 325 minecraft:light[level=12]
setblock 3 93 332 minecraft:light[level=12]
setblock 3 93 336 minecraft:honeycomb_block
setblock 3 93 346 minecraft:light[level=12]
setblock 3 93 353 minecraft:light[level=12]
setblock 3 93 356 minecraft:honeycomb_block
setblock 3 93 360 minecraft:light[level=12]
setblock 10 93 325 minecraft:light[level=12]
setblock 10 93 332 minecraft:light[level=12]
setblock 10 93 339 minecraft:light[level=12]
setblock 10 93 346 minecraft:light[level=12]
setblock 10 93 353 minecraft:light[level=12]
setblock 10 93 360 minecraft:light[level=12]
fill 13 93 323 13 94 323 minecraft:honeycomb_block
fill 13 93 363 14 93 363 minecraft:honeycomb_block
setblock 15 93 323 minecraft:yellow_terracotta
setblock 15 93 362 minecraft:honeycomb_block
setblock 15 93 363 minecraft:yellow_terracotta
fill 16 93 323 16 96 323 minecraft:honeycomb_block
setblock 16 93 362 minecraft:yellow_terracotta
fill 16 93 363 19 93 363 minecraft:honeycomb_block
setblock 17 93 325 minecraft:light[level=12]
setblock 17 93 332 minecraft:light[level=12]
setblock 17 93 339 minecraft:light[level=12]
setblock 17 93 353 minecraft:light[level=12]
setblock 17 93 360 minecraft:light[level=12]
fill 17 93 362 17 96 362 minecraft:honeycomb_block
setblock 19 93 324 minecraft:yellow_terracotta
setblock 20 93 323 minecraft:yellow_terracotta
fill 20 93 324 20 96 324 minecraft:honeycomb_block
setblock 20 93 362 minecraft:honeycomb_block
setblock 20 93 363 minecraft:yellow_terracotta
setblock 21 93 322 minecraft:orange_terracotta
fill 21 93 323 21 96 323 minecraft:honeycomb_block
setblock 21 93 362 minecraft:yellow_terracotta
fill 21 93 363 21 96 363 minecraft:honeycomb_block
fill 22 93 362 22 95 362 minecraft:honeycomb_block
setblock 24 93 325 minecraft:light[level=12]
setblock 24 93 332 minecraft:light[level=12]
setblock 24 93 339 minecraft:light[level=12]
setblock 24 93 346 minecraft:light[level=12]
setblock 24 93 353 minecraft:light[level=12]
setblock 24 93 360 minecraft:light[level=12]
setblock 25 93 323 minecraft:yellow_terracotta
setblock 25 93 363 minecraft:yellow_terracotta
fill 26 93 323 26 95 323 minecraft:honeycomb_block
fill 26 93 363 26 96 363 minecraft:honeycomb_block
fill 28 93 363 29 93 364 minecraft:honeycomb_block
fill 29 93 326 29 94 326 minecraft:brown_terracotta
fill 29 93 330 29 94 330 minecraft:brown_terracotta
fill 29 93 362 30 93 362 minecraft:honeycomb_block
setblock 30 93 323 minecraft:yellow_terracotta
setblock 30 93 363 minecraft:yellow_terracotta
fill 30 93 364 30 160 364 minecraft:honeycomb_block
fill 31 93 323 31 96 323 minecraft:honeycomb_block
setblock 31 93 325 minecraft:light[level=12]
setblock 31 93 332 minecraft:light[level=12]
setblock 31 93 339 minecraft:light[level=12]
setblock 31 93 346 minecraft:light[level=12]
setblock 31 93 353 minecraft:light[level=12]
setblock 31 93 360 minecraft:light[level=12]
setblock 31 93 362 minecraft:yellow_terracotta
fill 31 93 363 31 96 363 minecraft:honeycomb_block
setblock 32 93 361 minecraft:yellow_terracotta
fill 32 93 362 32 96 362 minecraft:honeycomb_block
fill 33 93 361 33 96 361 minecraft:honeycomb_block
fill 34 93 347 34 98 347 minecraft:brown_terracotta
fill 34 93 360 34 96 360 minecraft:honeycomb_block
setblock 35 93 323 minecraft:yellow_terracotta
fill 35 93 344 36 98 344 minecraft:brown_terracotta
setblock 35 93 363 minecraft:yellow_terracotta
fill 36 93 323 36 96 323 minecraft:honeycomb_block
fill 36 93 347 36 98 347 minecraft:brown_terracotta
setblock 36 93 362 minecraft:yellow_terracotta
fill 36 93 363 36 96 363 minecraft:honeycomb_block
fill 37 93 345 37 98 346 minecraft:brown_terracotta
setblock 37 93 357 minecraft:honeycomb_block
setblock 37 93 360 minecraft:honeycomb_block
setblock 37 93 361 minecraft:yellow_terracotta
fill 37 93 362 37 96 362 minecraft:honeycomb_block
setblock 38 93 325 minecraft:light[level=12]
setblock 38 93 332 minecraft:light[level=12]
setblock 38 93 339 minecraft:light[level=12]
setblock 38 93 346 minecraft:light[level=12]
setblock 38 93 353 minecraft:light[level=12]
setblock 38 93 355 minecraft:yellow_terracotta
fill 38 93 356 38 95 356 minecraft:honeycomb_block
setblock 38 93 360 minecraft:yellow_terracotta
fill 38 93 361 38 96 361 minecraft:honeycomb_block
setblock 39 93 354 minecraft:yellow_terracotta
fill 39 93 355 39 96 355 minecraft:honeycomb_block
setblock 39 93 359 minecraft:yellow_terracotta
fill 39 93 360 39 96 360 minecraft:honeycomb_block
setblock 40 93 323 minecraft:yellow_terracotta
setblock 40 93 333 minecraft:yellow_terracotta
fill 40 93 334 40 94 334 minecraft:honeycomb_block
setblock 40 93 338 minecraft:yellow_terracotta
fill 40 93 339 40 96 339 minecraft:honeycomb_block
setblock 40 93 343 minecraft:yellow_terracotta
setblock 40 93 348 minecraft:yellow_terracotta
fill 40 93 349 40 94 349 minecraft:honeycomb_block
setblock 40 93 353 minecraft:yellow_terracotta
fill 40 93 354 40 96 354 minecraft:honeycomb_block
setblock 40 93 358 minecraft:yellow_terracotta
fill 40 93 359 40 96 359 minecraft:honeycomb_block
setblock 40 93 363 minecraft:yellow_terracotta
fill 41 93 323 41 94 323 minecraft:honeycomb_block
setblock 41 93 332 minecraft:yellow_terracotta
fill 41 93 333 41 95 333 minecraft:honeycomb_block
setblock 41 93 337 minecraft:yellow_terracotta
fill 41 93 338 41 96 338 minecraft:honeycomb_block
setblock 41 93 342 minecraft:yellow_terracotta
fill 41 93 343 41 96 343 minecraft:honeycomb_block
setblock 41 93 347 minecraft:yellow_terracotta
fill 41 93 348 41 96 348 minecraft:honeycomb_block
setblock 41 93 352 minecraft:yellow_terracotta
fill 41 93 353 41 96 353 minecraft:honeycomb_block
setblock 41 93 357 minecraft:yellow_terracotta
fill 41 93 358 41 96 358 minecraft:honeycomb_block
setblock 41 93 362 minecraft:yellow_terracotta
fill 41 93 363 41 96 363 minecraft:honeycomb_block
fill 42 93 326 42 129 326 minecraft:honeycomb_block
setblock 0 94 329 minecraft:yellow_terracotta
setblock 0 94 333 minecraft:orange_terracotta
fill 0 94 350 0 104 350 minecraft:honeycomb_block
setblock 1 94 324 minecraft:honey_block
setblock 1 94 331 minecraft:yellow_terracotta
fill 1 94 332 1 94 335 minecraft:honeycomb_block
setblock 1 94 336 minecraft:yellow_terracotta
fill 1 94 337 1 97 337 minecraft:honeycomb_block
setblock 1 94 341 minecraft:yellow_terracotta
fill 1 94 342 1 97 342 minecraft:honeycomb_block
setblock 1 94 346 minecraft:yellow_terracotta
fill 1 94 347 1 97 347 minecraft:honeycomb_block
setblock 1 94 351 minecraft:yellow_terracotta
fill 1 94 352 1 96 352 minecraft:honeycomb_block
setblock 1 94 356 minecraft:yellow_terracotta
fill 1 94 357 1 97 357 minecraft:honeycomb_block
setblock 1 94 361 minecraft:yellow_terracotta
fill 1 94 362 1 97 362 minecraft:honeycomb_block
setblock 2 94 335 minecraft:yellow_terracotta
fill 2 94 336 2 96 336 minecraft:honeycomb_block
setblock 2 94 339 minecraft:honeycomb_block
setblock 2 94 340 minecraft:yellow_terracotta
fill 2 94 341 2 97 341 minecraft:honeycomb_block
setblock 2 94 345 minecraft:yellow_terracotta
setblock 2 94 351 minecraft:honeycomb_block
setblock 2 94 355 minecraft:yellow_terracotta
fill 2 94 356 2 95 356 minecraft:honeycomb_block
setblock 2 94 360 minecraft:yellow_terracotta
setblock 2 94 361 minecraft:honeycomb_block
fill 4 94 352 4 95 352 minecraft:yellow_terracotta
fill 4 94 354 4 95 354 minecraft:yellow_terracotta
fill 6 94 352 6 95 352 minecraft:yellow_terracotta
fill 6 94 354 6 95 354 minecraft:yellow_terracotta
setblock 6 94 363 minecraft:honey_block
fill 11 94 323 11 95 323 minecraft:honey_block
setblock 13 94 363 minecraft:honeycomb_block
setblock 14 94 323 minecraft:yellow_terracotta
setblock 14 94 363 minecraft:yellow_terracotta
fill 15 94 323 15 96 324 minecraft:honeycomb_block
setblock 15 94 362 minecraft:yellow_terracotta
fill 15 94 363 18 94 363 minecraft:honeycomb_block
fill 16 94 362 16 97 362 minecraft:honeycomb_block
setblock 18 94 324 minecraft:yellow_terracotta
setblock 19 94 323 minecraft:yellow_terracotta
fill 19 94 324 19 97 324 minecraft:honeycomb_block
setblock 19 94 363 minecraft:yellow_terracotta
fill 20 94 323 20 97 323 minecraft:honeycomb_block
setblock 20 94 362 minecraft:yellow_terracotta
fill 20 94 363 20 97 363 minecraft:honeycomb_block
fill 21 94 322 21 222 322 minecraft:honeycomb_block
fill 21 94 362 21 97 362 minecraft:honeycomb_block
setblock 24 94 323 minecraft:yellow_terracotta
fill 24 94 327 24 94 329 minecraft:brown_terracotta
setblock 24 94 363 minecraft:yellow_terracotta
fill 25 94 323 25 97 323 minecraft:honeycomb_block
setblock 25 94 326 minecraft:brown_terracotta
setblock 25 94 330 minecraft:brown_terracotta
fill 25 94 363 25 97 363 minecraft:honeycomb_block
fill 26 94 325 28 94 325 minecraft:brown_terracotta
fill 26 94 331 28 94 331 minecraft:brown_terracotta
fill 28 94 363 28 94 364 minecraft:honeycomb_block
setblock 29 94 323 minecraft:yellow_terracotta
setblock 29 94 362 minecraft:honeycomb_block
setblock 29 94 363 minecraft:yellow_terracotta
fill 29 94 364 29 308 364 minecraft:honeycomb_block
fill 30 94 323 30 97 323 minecraft:honeycomb_block
fill 30 94 327 30 94 329 minecraft:brown_terracotta
setblock 30 94 362 minecraft:yellow_terracotta
fill 30 94 363 30 97 363 minecraft:honeycomb_block
fill 31 94 322 32 156 322 minecraft:honeycomb_block
setblock 31 94 361 minecraft:yellow_terracotta
fill 31 94 362 31 97 362 minecraft:honeycomb_block
fill 32 94 361 32 97 361 minecraft:honeycomb_block
setblock 33 94 322 minecraft:orange_terracotta
fill 33 94 345 33 98 346 minecraft:brown_terracotta
setblock 34 94 323 minecraft:yellow_terracotta
fill 34 94 344 34 98 344 minecraft:brown_terracotta
setblock 34 94 363 minecraft:yellow_terracotta
fill 35 94 323 35 97 323 minecraft:honeycomb_block
fill 35 94 348 35 98 348 minecraft:brown_terracotta
setblock 35 94 362 minecraft:yellow_terracotta
fill 35 94 363 35 97 363 minecraft:honeycomb_block
setblock 36 94 361 minecraft:yellow_terracotta
fill 36 94 362 36 97 362 minecraft:honeycomb_block
fill 37 94 344 37 98 344 minecraft:brown_terracotta
fill 37 94 347 37 98 347 minecraft:brown_terracotta
setblock 37 94 360 minecraft:yellow_terracotta
fill 37 94 361 37 97 361 minecraft:honeycomb_block
setblock 38 94 354 minecraft:yellow_terracotta
setblock 38 94 355 minecraft:honeycomb_block
setblock 38 94 359 minecraft:yellow_terracotta
fill 38 94 360 38 97 360 minecraft:honeycomb_block
setblock 39 94 323 minecraft:yellow_terracotta
setblock 39 94 353 minecraft:yellow_terracotta
fill 39 94 354 39 95 354 minecraft:honeycomb_block
setblock 39 94 358 minecraft:yellow_terracotta
fill 39 94 359 39 97 359 minecraft:honeycomb_block
setblock 39 94 363 minecraft:yellow_terracotta
fill 40 94 323 40 95 323 minecraft:honeycomb_block
setblock 40 94 337 minecraft:yellow_terracotta
fill 40 94 338 40 96 338 minecraft:honeycomb_block
setblock 40 94 342 minecraft:yellow_terracotta
setblock 40 94 343 minecraft:honeycomb_block
setblock 40 94 352 minecraft:yellow_terracotta
fill 40 94 353 40 96 353 minecraft:honeycomb_block
setblock 40 94 357 minecraft:yellow_terracotta
fill 40 94 358 40 97 358 minecraft:honeycomb_block
setblock 40 94 362 minecraft:yellow_terracotta
fill 40 94 363 40 97 363 minecraft:honeycomb_block
setblock 41 94 332 minecraft:honeycomb_block
setblock 41 94 336 minecraft:yellow_terracotta
fill 41 94 337 41 97 337 minecraft:honeycomb_block
setblock 41 94 341 minecraft:yellow_terracotta
fill 41 94 342 41 97 342 minecraft:honeycomb_block
setblock 41 94 346 minecraft:yellow_terracotta
fill 41 94 347 41 97 347 minecraft:honeycomb_block
setblock 41 94 351 minecraft:yellow_terracotta
fill 41 94 352 41 97 352 minecraft:honeycomb_block
setblock 41 94 356 minecraft:yellow_terracotta
fill 41 94 357 41 97 357 minecraft:honeycomb_block
setblock 41 94 361 minecraft:yellow_terracotta
fill 41 94 362 41 97 362 minecraft:honeycomb_block
setblock 42 94 341 minecraft:yellow_concrete
fill 0 95 329 0 116 329 minecraft:honeycomb_block
fill 0 95 333 1 96 333 minecraft:honeycomb_block
fill 0 95 338 0 163 338 minecraft:honeycomb_block
setblock 0 95 339 minecraft:yellow_terracotta
fill 0 95 340 0 96 340 minecraft:honeycomb_block
setblock 1 95 330 minecraft:honey_block
setblock 1 95 332 minecraft:honeycomb_block
setblock 1 95 334 minecraft:honeycomb_block
setblock 1 95 335 minecraft:yellow_terracotta
fill 1 95 336 1 98 336 minecraft:honeycomb_block
setblock 1 95 340 minecraft:yellow_terracotta
fill 1 95 341 1 98 341 minecraft:honeycomb_block
setblock 1 95 345 minecraft:yellow_terracotta
fill 1 95 346 1 98 346 minecraft:honeycomb_block
setblock 1 95 350 minecraft:yellow_terracotta
fill 1 95 351 1 96 351 minecraft:honeycomb_block
setblock 1 95 355 minecraft:yellow_terracotta
fill 1 95 356 1 97 356 minecraft:honeycomb_block
setblock 1 95 360 minecraft:yellow_terracotta
fill 1 95 361 1 98 361 minecraft:honeycomb_block
setblock 2 95 335 minecraft:honeycomb_block
setblock 2 95 339 minecraft:yellow_terracotta
fill 2 95 340 2 98 340 minecraft:honeycomb_block
setblock 2 95 344 minecraft:yellow_terracotta
setblock 2 95 355 minecraft:honeycomb_block
setblock 2 95 359 minecraft:yellow_terracotta
setblock 2 95 360 minecraft:honeycomb_block
setblock 3 95 325 minecraft:light[level=15]
setblock 3 95 333 minecraft:light[level=15]
setblock 3 95 341 minecraft:light[level=15]
setblock 3 95 349 minecraft:light[level=15]
setblock 3 95 357 minecraft:light[level=15]
fill 5 95 322 7 164 322 minecraft:honeycomb_block
setblock 5 95 323 minecraft:honey_block
setblock 8 95 322 minecraft:yellow_concrete
fill 9 95 322 9 106 322 minecraft:honeycomb_block
setblock 11 95 325 minecraft:light[level=15]
setblock 11 95 333 minecraft:light[level=15]
setblock 11 95 341 minecraft:light[level=15]
setblock 11 95 349 minecraft:light[level=15]
setblock 11 95 357 minecraft:light[level=15]
setblock 12 95 323 minecraft:honeycomb_block
setblock 12 95 363 minecraft:honeycomb_block
setblock 13 95 323 minecraft:yellow_terracotta
setblock 13 95 363 minecraft:yellow_terracotta
fill 14 95 323 14 98 323 minecraft:honeycomb_block
setblock 14 95 362 minecraft:yellow_terracotta
fill 14 95 363 17 95 363 minecraft:honeycomb_block
fill 15 95 362 15 98 362 minecraft:honeycomb_block
setblock 17 95 324 minecraft:yellow_terracotta
setblock 18 95 323 minecraft:yellow_terracotta
fill 18 95 324 18 98 324 minecraft:honeycomb_block
setblock 18 95 363 minecraft:yellow_terracotta
fill 19 95 323 19 98 323 minecraft:honeycomb_block
setblock 19 95 325 minecraft:light[level=15]
setblock 19 95 333 minecraft:light[level=15]
setblock 19 95 349 minecraft:light[level=15]
setblock 19 95 357 minecraft:light[level=15]
setblock 19 95 362 minecraft:yellow_terracotta
fill 19 95 363 19 98 363 minecraft:honeycomb_block
fill 20 95 362 20 98 362 minecraft:honeycomb_block
setblock 23 95 323 minecraft:yellow_terracotta
setblock 23 95 363 minecraft:yellow_terracotta
fill 24 95 323 24 98 323 minecraft:honeycomb_block
fill 24 95 363 24 98 363 minecraft:honeycomb_block
fill 25 95 359 26 96 359 minecraft:yellow_concrete
setblock 27 95 325 minecraft:light[level=15]
fill 27 95 328 27 98 328 minecraft:yellow_terracotta
setblock 27 95 333 minecraft:light[level=15]
setblock 27 95 341 minecraft:light[level=15]
setblock 27 95 349 minecraft:light[level=15]
setblock 27 95 357 minecraft:light[level=15]
setblock 28 95 323 minecraft:yellow_terracotta
setblock 28 95 362 minecraft:honeycomb_block
setblock 28 95 363 minecraft:yellow_terracotta
fill 28 95 364 28 194 364 minecraft:honeycomb_block
fill 29 95 323 29 98 323 minecraft:honeycomb_block
setblock 29 95 362 minecraft:yellow_terracotta
fill 29 95 363 29 98 363 minecraft:honeycomb_block
fill 30 95 362 30 98 362 minecraft:honeycomb_block
fill 31 95 361 31 98 361 minecraft:honeycomb_block
fill 33 95 322 33 299 322 minecraft:honeycomb_block
setblock 33 95 323 minecraft:yellow_terracotta
fill 33 95 344 33 98 344 minecraft:brown_terracotta
fill 33 95 347 33 98 347 minecraft:brown_terracotta
fill 33 95 360 33 97 360 minecraft:honeycomb_block
setblock 33 95 363 minecraft:yellow_terracotta
fill 34 95 323 34 98 323 minecraft:honeycomb_block
fill 34 95 343 36 98 343 minecraft:brown_terracotta
fill 34 95 348 34 98 348 minecraft:brown_terracotta
setblock 34 95 362 minecraft:yellow_terracotta
fill 34 95 363 34 98 363 minecraft:honeycomb_block
setblock 35 95 325 minecraft:light[level=15]
setblock 35 95 333 minecraft:light[level=15]
setblock 35 95 341 minecraft:light[level=15]
setblock 35 95 349 minecraft:light[level=15]
setblock 35 95 357 minecraft:light[level=15]
setblock 35 95 361 minecraft:yellow_terracotta
fill 35 95 362 35 98 362 minecraft:honeycomb_block
fill 36 95 348 37 98 348 minecraft:brown_terracotta
setblock 36 95 360 minecraft:yellow_terracotta
fill 36 95 361 36 98 361 minecraft:honeycomb_block
fill 37 95 360 37 98 360 minecraft:honeycomb_block
setblock 38 95 323 minecraft:yellow_terracotta
fill 38 95 345 38 98 346 minecraft:brown_terracotta
setblock 38 95 358 minecraft:yellow_terracotta
fill 38 95 359 38 96 359 minecraft:honeycomb_block
setblock 38 95 363 minecraft:yellow_terracotta
fill 39 95 323 39 98 323 minecraft:honeycomb_block
setblock 39 95 353 minecraft:honeycomb_block
setblock 39 95 357 minecraft:yellow_terracotta
fill 39 95 358 39 98 358 minecraft:honeycomb_block
setblock 39 95 362 minecraft:yellow_terracotta
fill 39 95 363 39 98 363 minecraft:honeycomb_block
setblock 40 95 336 minecraft:yellow_terracotta
setblock 40 95 337 minecraft:honeycomb_block
setblock 40 95 341 minecraft:yellow_terracotta
fill 40 95 342 40 97 342 minecraft:honeycomb_block
setblock 40 95 351 minecraft:yellow_terracotta
setblock 40 95 352 minecraft:honeycomb_block
setblock 40 95 356 minecraft:yellow_terracotta
fill 40 95 357 40 98 357 minecraft:honeycomb_block
setblock 40 95 361 minecraft:yellow_terracotta
fill 40 95 362 40 98 362 minecraft:honeycomb_block
fill 41 95 331 41 96 331 minecraft:honey_block
setblock 41 95 335 minecraft:yellow_terracotta
fill 41 95 336 41 97 336 minecraft:honeycomb_block
setblock 41 95 340 minecraft:yellow_terracotta
fill 41 95 341 42 98 341 minecraft:honeycomb_block
setblock 41 95 345 minecraft:yellow_terracotta
fill 41 95 346 41 98 346 minecraft:honeycomb_block
setblock 41 95 350 minecraft:yellow_terracotta
fill 41 95 351 41 97 351 minecraft:honeycomb_block
setblock 41 95 355 minecraft:yellow_terracotta
fill 41 95 356 41 98 356 minecraft:honeycomb_block
setblock 41 95 360 minecraft:yellow_terracotta
fill 41 95 361 41 98 361 minecraft:honeycomb_block
fill 0 96 339 0 126 339 minecraft:honeycomb_block
setblock 1 96 334 minecraft:yellow_terracotta
fill 1 96 335 1 98 335 minecraft:honeycomb_block
setblock 1 96 339 minecraft:yellow_terracotta
fill 1 96 340 1 99 340 minecraft:honeycomb_block
setblock 1 96 344 minecraft:yellow_terracotta
fill 1 96 345 1 99 345 minecraft:honeycomb_block
setblock 1 96 349 minecraft:yellow_terracotta
setblock 1 96 350 minecraft:honeycomb_block
setblock 1 96 354 minecraft:yellow_terracotta
fill 1 96 355 1 97 355 minecraft:honeycomb_block
setblock 1 96 359 minecraft:yellow_terracotta
fill 1 96 360 1 98 360 minecraft:honeycomb_block
setblock 2 96 338 minecraft:yellow_terracotta
fill 2 96 339 2 99 339 minecraft:honeycomb_block
setblock 2 96 343 minecraft:yellow_terracotta
fill 8 96 322 8 240 322 minecraft:honeycomb_block
setblock 10 96 364 minecraft:yellow_concrete
setblock 12 96 323 minecraft:yellow_terracotta
setblock 12 96 363 minecraft:yellow_terracotta
fill 13 96 323 13 99 323 minecraft:honeycomb_block
fill 13 96 363 16 96 363 minecraft:honeycomb_block
fill 14 96 324 14 97 324 minecraft:honeycomb_block
fill 14 96 362 14 99 362 minecraft:honeycomb_block
setblock 16 96 324 minecraft:yellow_terracotta
setblock 17 96 323 minecraft:yellow_terracotta
fill 17 96 324 17 99 324 minecraft:honeycomb_block
setblock 17 96 363 minecraft:yellow_terracotta
fill 18 96 323 18 99 323 minecraft:honeycomb_block
setblock 18 96 362 minecraft:yellow_terracotta
fill 18 96 363 18 99 363 minecraft:honeycomb_block
fill 19 96 362 19 99 362 minecraft:honeycomb_block
setblock 22 96 323 minecraft:yellow_terracotta
setblock 22 96 363 minecraft:yellow_terracotta
fill 23 96 323 23 99 323 minecraft:honeycomb_block
fill 23 96 363 23 99 363 minecraft:honeycomb_block
setblock 27 96 363 minecraft:yellow_terracotta
fill 27 96 364 27 307 364 minecraft:honeycomb_block
fill 28 96 323 28 99 323 minecraft:honeycomb_block
setblock 28 96 362 minecraft:yellow_terracotta
fill 28 96 363 28 99 363 minecraft:honeycomb_block
fill 29 96 362 29 99 362 minecraft:honeycomb_block
setblock 32 96 323 minecraft:yellow_terracotta
fill 32 96 345 32 98 346 minecraft:brown_terracotta
setblock 32 96 363 minecraft:yellow_terracotta
fill 33 96 323 33 99 323 minecraft:honeycomb_block
fill 33 96 348 33 98 348 minecraft:brown_terracotta
setblock 33 96 362 minecraft:yellow_terracotta
fill 33 96 363 33 99 363 minecraft:honeycomb_block
setblock 34 96 361 minecraft:yellow_terracotta
fill 34 96 362 34 99 362 minecraft:honeycomb_block
fill 35 96 349 35 98 349 minecraft:brown_terracotta
setblock 35 96 360 minecraft:yellow_terracotta
fill 35 96 361 35 99 361 minecraft:honeycomb_block
fill 36 96 360 36 99 360 minecraft:honeycomb_block
setblock 37 96 323 minecraft:yellow_terracotta
fill 37 96 343 37 98 343 minecraft:brown_terracotta
setblock 37 96 363 minecraft:yellow_terracotta
fill 38 96 323 38 99 323 minecraft:honeycomb_block
fill 38 96 344 38 98 344 minecraft:brown_terracotta
fill 38 96 347 38 98 347 minecraft:brown_terracotta
setblock 38 96 357 minecraft:yellow_terracotta
setblock 38 96 358 minecraft:honeycomb_block
setblock 38 96 362 minecraft:yellow_terracotta
fill 38 96 363 38 99 363 minecraft:honeycomb_block
setblock 39 96 356 minecraft:yellow_terracotta
fill 39 96 357 39 97 357 minecraft:honeycomb_block
setblock 39 96 361 minecraft:yellow_terracotta
fill 39 96 362 39 99 362 minecraft:honeycomb_block
setblock 40 96 340 minecraft:yellow_terracotta
fill 40 96 341 40 99 341 minecraft:honeycomb_block
setblock 40 96 355 minecraft:yellow_terracotta
fill 40 96 356 40 98 356 minecraft:honeycomb_block
setblock 40 96 360 minecraft:yellow_terracotta
fill 40 96 361 40 99 361 minecraft:honeycomb_block
setblock 41 96 325 minecraft:honey_block
setblock 41 96 335 minecraft:honeycomb_block
setblock 41 96 339 minecraft:yellow_terracotta
fill 41 96 340 41 99 340 minecraft:honeycomb_block
setblock 41 96 344 minecraft:yellow_terracotta
fill 41 96 345 41 99 345 minecraft:honeycomb_block
setblock 41 96 349 minecraft:yellow_terracotta
setblock 41 96 350 minecraft:honeycomb_block
setblock 41 96 354 minecraft:yellow_terracotta
fill 41 96 355 41 99 355 minecraft:honeycomb_block
setblock 41 96 359 minecraft:yellow_terracotta
fill 41 96 360 41 99 360 minecraft:honeycomb_block
setblock 42 96 346 minecraft:yellow_terracotta
fill 0 97 333 0 128 333 minecraft:honeycomb_block
setblock 0 97 340 minecraft:yellow_concrete
setblock 1 97 334 minecraft:honeycomb_block
setblock 1 97 338 minecraft:yellow_terracotta
fill 1 97 339 1 100 339 minecraft:honeycomb_block
setblock 1 97 343 minecraft:yellow_terracotta
fill 1 97 344 1 100 344 minecraft:honeycomb_block
setblock 1 97 358 minecraft:yellow_terracotta
fill 1 97 359 1 98 359 minecraft:honeycomb_block
setblock 1 97 363 minecraft:yellow_terracotta
setblock 2 97 337 minecraft:yellow_terracotta
fill 2 97 338 2 98 338 minecraft:honeycomb_block
setblock 2 97 342 minecraft:yellow_terracotta
fill 2 97 343 2 100 343 minecraft:honeycomb_block
fill 5 97 363 5 98 363 minecraft:honey_block
fill 10 97 364 10 220 364 minecraft:honeycomb_block
setblock 11 97 323 minecraft:yellow_terracotta
setblock 11 97 363 minecraft:yellow_terracotta
setblock 12 97 322 minecraft:yellow_concrete
fill 12 97 323 12 100 323 minecraft:honeycomb_block
fill 12 97 363 15 97 363 minecraft:honeycomb_block
fill 13 97 362 13 100 362 minecraft:honeycomb_block
setblock 15 97 323 minecraft:honeycomb_block
setblock 15 97 324 minecraft:yellow_terracotta
setblock 16 97 323 minecraft:yellow_terracotta
fill 16 97 324 16 100 324 minecraft:honeycomb_block
setblock 16 97 363 minecraft:yellow_terracotta
fill 17 97 323 17 100 323 minecraft:honeycomb_block
setblock 17 97 362 minecraft:yellow_terracotta
fill 17 97 363 17 100 363 minecraft:honeycomb_block
fill 18 97 362 18 100 362 minecraft:honeycomb_block
setblock 19 97 364 minecraft:yellow_concrete
setblock 21 97 323 minecraft:yellow_terracotta
setblock 21 97 363 minecraft:yellow_terracotta
fill 22 97 323 22 100 323 minecraft:honeycomb_block
fill 22 97 363 22 100 363 minecraft:honeycomb_block
setblock 26 97 323 minecraft:yellow_terracotta
setblock 26 97 363 minecraft:yellow_terracotta
fill 27 97 323 27 100 323 minecraft:honeycomb_block
fill 27 97 363 27 100 363 minecraft:honeycomb_block
fill 28 97 362 28 100 362 minecraft:honeycomb_block
setblock 31 97 323 minecraft:yellow_terracotta
setblock 31 97 363 minecraft:yellow_terracotta
fill 32 97 323 32 100 323 minecraft:honeycomb_block
fill 32 97 344 32 98 344 minecraft:brown_terracotta
fill 32 97 347 32 98 347 minecraft:brown_terracotta
setblock 32 97 362 minecraft:yellow_terracotta
fill 32 97 363 32 100 363 minecraft:honeycomb_block
fill 33 97 343 33 98 343 minecraft:brown_terracotta
setblock 33 97 361 minecraft:yellow_terracotta
fill 33 97 362 33 100 362 minecraft:honeycomb_block
fill 34 97 342 36 98 342 minecraft:brown_terracotta
fill 34 97 349 34 98 349 minecraft:brown_terracotta
setblock 34 97 360 minecraft:yellow_terracotta
fill 34 97 361 34 100 361 minecraft:honeycomb_block
fill 35 97 360 35 100 360 minecraft:honeycomb_block
setblock 36 97 323 minecraft:yellow_terracotta
fill 36 97 349 37 98 349 minecraft:brown_terracotta
setblock 36 97 363 minecraft:yellow_terracotta
fill 37 97 323 37 100 323 minecraft:honeycomb_block
setblock 37 97 362 minecraft:yellow_terracotta
fill 37 97 363 37 100 363 minecraft:honeycomb_block
fill 38 97 343 38 98 343 minecraft:brown_terracotta
fill 38 97 348 38 98 348 minecraft:brown_terracotta
setblock 38 97 361 minecraft:yellow_terracotta
fill 38 97 362 38 100 362 minecraft:honeycomb_block
fill 39 97 345 39 98 346 minecraft:brown_terracotta
setblock 39 97 356 minecraft:honeycomb_block
setblock 39 97 360 minecraft:yellow_terracotta
fill 39 97 361 39 99 361 minecraft:honeycomb_block
setblock 40 97 340 minecraft:honeycomb_block
setblock 40 97 354 minecraft:yellow_terracotta
setblock 40 97 355 minecraft:honeycomb_block
setblock 40 97 359 minecraft:yellow_terracotta
fill 40 97 360 40 100 360 minecraft:honeycomb_block
setblock 41 97 338 minecraft:yellow_terracotta
fill 41 97 339 41 100 339 minecraft:honeycomb_block
setblock 41 97 343 minecraft:yellow_terracotta
fill 41 97 344 41 100 344 minecraft:honeycomb_block
setblock 41 97 353 minecraft:yellow_terracotta
fill 41 97 354 41 98 354 minecraft:honeycomb_block
setblock 41 97 358 minecraft:yellow_terracotta
fill 41 97 359 41 100 359 minecraft:honeycomb_block
setblock 41 97 363 minecraft:yellow_terracotta
fill 42 97 346 42 209 346 minecraft:honeycomb_block
fill 0 98 340 0 248 340 minecraft:honeycomb_block
setblock 0 98 355 minecraft:yellow_concrete
setblock 1 98 323 minecraft:honey_block
fill 1 98 329 1 99 329 minecraft:honey_block
setblock 1 98 337 minecraft:yellow_terracotta
fill 1 98 338 1 101 338 minecraft:honeycomb_block
setblock 1 98 342 minecraft:yellow_terracotta
fill 1 98 343 1 101 343 minecraft:honeycomb_block
setblock 1 98 347 minecraft:yellow_terracotta
setblock 1 98 348 minecraft:honey_block
setblock 1 98 358 minecraft:honeycomb_block
setblock 1 98 362 minecraft:yellow_terracotta
setblock 2 98 341 minecraft:yellow_terracotta
fill 2 98 342 2 101 342 minecraft:honeycomb_block
setblock 10 98 323 minecraft:yellow_terracotta
setblock 10 98 363 minecraft:yellow_terracotta
fill 11 98 323 11 101 323 minecraft:honeycomb_block
fill 11 98 363 14 98 363 minecraft:honeycomb_block
setblock 11 98 364 minecraft:yellow_concrete
fill 12 98 322 12 135 322 minecraft:honeycomb_block
setblock 13 98 324 minecraft:honeycomb_block
setblock 14 98 324 minecraft:yellow_terracotta
setblock 15 98 323 minecraft:yellow_terracotta
fill 15 98 324 15 101 324 minecraft:honeycomb_block
setblock 15 98 363 minecraft:yellow_terracotta
fill 16 98 323 16 101 323 minecraft:honeycomb_block
setblock 16 98 362 minecraft:yellow_terracotta
fill 16 98 363 16 101 363 minecraft:honeycomb_block
fill 17 98 362 17 101 362 minecraft:honeycomb_block
setblock 19 98 324 minecraft:yellow_terracotta
fill 19 98 364 19 151 364 minecraft:honeycomb_block
setblock 20 98 323 minecraft:yellow_terracotta
setblock 20 98 363 minecraft:yellow_terracotta
fill 21 98 323 21 101 323 minecraft:honeycomb_block
fill 21 98 363 21 101 363 minecraft:honeycomb_block
setblock 25 98 323 minecraft:yellow_terracotta
fill 25 98 328 26 100 328 minecraft:flowering_azalea_leaves[persistent=true]
setblock 25 98 363 minecraft:yellow_terracotta
fill 26 98 323 26 101 323 minecraft:honeycomb_block
fill 26 98 327 28 100 327 minecraft:flowering_azalea_leaves[persistent=true]
fill 26 98 329 28 100 329 minecraft:flowering_azalea_leaves[persistent=true]
fill 26 98 363 26 101 363 minecraft:honeycomb_block
fill 27 98 330 27 100 330 minecraft:flowering_azalea_leaves[persistent=true]
fill 27 98 362 27 101 362 minecraft:honeycomb_block
fill 28 98 328 29 100 328 minecraft:flowering_azalea_leaves[persistent=true]
setblock 30 98 323 minecraft:yellow_terracotta
fill 30 98 361 30 99 361 minecraft:honeycomb_block
setblock 30 98 363 minecraft:yellow_terracotta
fill 31 98 323 31 101 323 minecraft:honeycomb_block
fill 31 98 345 31 98 346 minecraft:brown_terracotta
setblock 31 98 362 minecraft:yellow_terracotta
fill 31 98 363 31 101 363 minecraft:honeycomb_block
setblock 32 98 343 minecraft:brown_terracotta
setblock 32 98 348 minecraft:brown_terracotta
setblock 32 98 361 minecraft:yellow_terracotta
fill 32 98 362 32 101 362 minecraft:honeycomb_block
setblock 33 98 342 minecraft:brown_terracotta
setblock 33 98 349 minecraft:brown_terracotta
setblock 33 98 360 minecraft:yellow_terracotta
fill 33 98 361 33 101 361 minecraft:honeycomb_block
fill 34 98 360 34 101 360 minecraft:honeycomb_block
setblock 35 98 323 minecraft:yellow_terracotta
setblock 35 98 363 minecraft:yellow_terracotta
fill 36 98 323 36 101 323 minecraft:honeycomb_block
setblock 36 98 362 minecraft:yellow_terracotta
fill 36 98 363 36 101 363 minecraft:honeycomb_block
setblock 37 98 342 minecraft:brown_terracotta
setblock 37 98 361 minecraft:yellow_terracotta
fill 37 98 362 37 101 362 minecraft:honeycomb_block
setblock 38 98 349 minecraft:brown_terracotta
fill 38 98 361 38 101 361 minecraft:honeycomb_block
setblock 39 98 344 minecraft:brown_terracotta
setblock 39 98 347 minecraft:brown_terracotta
setblock 39 98 359 minecraft:yellow_terracotta
fill 39 98 360 39 99 360 minecraft:honeycomb_block
setblock 40 98 358 minecraft:yellow_terracotta
fill 40 98 359 40 100 359 minecraft:honeycomb_block
setblock 40 98 363 minecraft:yellow_terracotta
setblock 41 98 337 minecraft:yellow_terracotta
fill 41 98 338 41 100 338 minecraft:honeycomb_block
setblock 41 98 342 minecraft:yellow_terracotta
fill 41 98 343 41 101 343 minecraft:honeycomb_block
setblock 41 98 347 minecraft:yellow_terracotta
setblock 41 98 353 minecraft:honeycomb_block
setblock 41 98 357 minecraft:yellow_terracotta
fill 41 98 358 41 101 358 minecraft:honeycomb_block
setblock 41 98 362 minecraft:yellow_terracotta
fill 41 98 363 41 101 363 minecraft:honeycomb_block
fill 0 99 355 0 190 355 minecraft:honeycomb_block
setblock 1 99 322 minecraft:yellow_terracotta
setblock 1 99 335 minecraft:honey_block
setblock 1 99 336 minecraft:yellow_terracotta
fill 1 99 337 1 102 337 minecraft:honeycomb_block
setblock 1 99 341 minecraft:yellow_terracotta
fill 1 99 342 1 102 342 minecraft:honeycomb_block
setblock 1 99 346 minecraft:yellow_terracotta
fill 1 99 347 1 102 347 minecraft:honeycomb_block
setblock 1 99 354 minecraft:honey_block
fill 1 99 364 4 189 364 minecraft:honeycomb_block
setblock 2 99 340 minecraft:yellow_terracotta
fill 2 99 341 2 102 341 minecraft:honeycomb_block
setblock 3 99 325 minecraft:light[level=12]
setblock 3 99 332 minecraft:light[level=12]
setblock 3 99 339 minecraft:light[level=12]
setblock 3 99 346 minecraft:light[level=12]
setblock 3 99 353 minecraft:light[level=12]
setblock 3 99 360 minecraft:light[level=12]
setblock 5 99 364 minecraft:yellow_concrete
setblock 6 99 323 minecraft:honey_block
fill 6 99 364 6 252 364 minecraft:honeycomb_block
setblock 9 99 323 minecraft:yellow_terracotta
setblock 9 99 363 minecraft:yellow_terracotta
fill 10 99 323 10 102 323 minecraft:honeycomb_block
setblock 10 99 325 minecraft:light[level=12]
schedule function dropper:buildpart/72_3 1t
