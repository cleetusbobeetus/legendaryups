fill 471 184 307 471 185 307 minecraft:deepslate_tiles
setblock 471 184 314 minecraft:cobbled_deepslate
fill 471 184 315 471 187 315 minecraft:deepslate_tiles
setblock 472 184 298 minecraft:cobbled_deepslate
fill 472 184 299 473 186 299 minecraft:deepslate_tiles
setblock 472 184 303 minecraft:cobbled_deepslate
fill 472 184 304 472 187 304 minecraft:deepslate_tiles
fill 473 184 300 473 184 301 minecraft:deepslate_tiles
setblock 473 184 302 minecraft:cobbled_deepslate
setblock 474 184 276 minecraft:cobbled_deepslate
setblock 474 184 316 minecraft:cobbled_deepslate
fill 475 184 276 475 187 276 minecraft:deepslate_tiles
setblock 475 184 315 minecraft:cobbled_deepslate
fill 475 184 316 475 187 316 minecraft:deepslate_tiles
setblock 476 184 315 minecraft:deepslate_tiles
setblock 478 184 277 minecraft:cobbled_deepslate
setblock 479 184 276 minecraft:cobbled_deepslate
setblock 479 184 316 minecraft:cobbled_deepslate
fill 480 184 276 480 186 276 minecraft:deepslate_tiles
setblock 480 184 316 minecraft:deepslate_tiles
fill 490 184 276 490 187 276 minecraft:deepslate_tiles
setblock 493 184 277 minecraft:cobbled_deepslate
setblock 494 184 276 minecraft:cobbled_deepslate
fill 494 184 277 494 186 278 minecraft:deepslate_tiles
setblock 494 184 316 minecraft:cobbled_deepslate
fill 495 184 276 495 187 276 minecraft:deepslate_tiles
fill 495 184 278 496 184 278 minecraft:deepslate_tiles
fill 495 184 316 495 187 316 minecraft:deepslate_tiles
setblock 497 184 278 minecraft:cobbled_deepslate
fill 497 184 279 497 187 279 minecraft:deepslate_tiles
setblock 498 184 277 minecraft:cobbled_deepslate
fill 498 184 278 498 187 278 minecraft:deepslate_tiles
setblock 499 184 276 minecraft:cobbled_deepslate
fill 499 184 277 499 187 277 minecraft:deepslate_tiles
setblock 499 184 316 minecraft:cobbled_deepslate
fill 500 184 276 500 187 276 minecraft:deepslate_tiles
fill 500 184 316 500 187 316 minecraft:deepslate_tiles
setblock 502 184 278 minecraft:cobbled_deepslate
setblock 503 184 277 minecraft:cobbled_deepslate
setblock 504 184 276 minecraft:cobbled_deepslate
fill 504 184 277 504 187 277 minecraft:deepslate_tiles
setblock 504 184 316 minecraft:cobbled_deepslate
fill 505 184 276 505 187 276 minecraft:deepslate_tiles
setblock 505 184 316 minecraft:deepslate_tiles
fill 508 184 299 508 202 299 minecraft:white_wool
setblock 509 184 276 minecraft:cobbled_deepslate
setblock 509 184 277 minecraft:deepslate_tiles
setblock 509 184 316 minecraft:cobbled_deepslate
fill 510 184 276 510 187 276 minecraft:deepslate_tiles
fill 510 184 316 510 187 316 minecraft:deepslate_tiles
setblock 511 184 279 minecraft:cobbled_deepslate
fill 511 184 280 511 187 280 minecraft:deepslate_tiles
setblock 511 184 314 minecraft:cobbled_deepslate
fill 511 184 315 511 187 315 minecraft:deepslate_tiles
fill 512 184 289 512 199 291 minecraft:black_concrete
setblock 512 184 292 minecraft:white_wool
fill 512 184 293 512 184 295 minecraft:black_concrete
fill 471 185 276 472 185 276 minecraft:deepslate_tiles
setblock 471 185 278 minecraft:cobbled_deepslate
fill 471 185 279 471 187 280 minecraft:deepslate_tiles
setblock 471 185 298 minecraft:cobbled_deepslate
fill 471 185 299 471 188 299 minecraft:deepslate_tiles
setblock 471 185 302 minecraft:deepslate_tiles
setblock 471 185 303 minecraft:cobbled_deepslate
fill 471 185 304 471 188 304 minecraft:deepslate_tiles
setblock 471 185 308 minecraft:cobbled_deepslate
fill 471 185 309 471 188 309 minecraft:deepslate_tiles
setblock 471 185 313 minecraft:cobbled_deepslate
fill 471 185 314 471 188 314 minecraft:deepslate_tiles
setblock 472 185 297 minecraft:cobbled_deepslate
fill 472 185 298 473 187 298 minecraft:deepslate_tiles
setblock 472 185 302 minecraft:cobbled_deepslate
fill 472 185 303 473 187 303 minecraft:deepslate_tiles
setblock 472 185 306 minecraft:deepslate_tiles
setblock 473 185 276 minecraft:cobbled_deepslate
setblock 473 185 300 minecraft:deepslate_tiles
setblock 473 185 301 minecraft:cobbled_deepslate
fill 473 185 302 473 188 302 minecraft:deepslate_tiles
fill 473 185 304 473 186 304 minecraft:deepslate_tiles
setblock 473 185 316 minecraft:cobbled_deepslate
fill 474 185 276 474 188 276 minecraft:deepslate_tiles
fill 474 185 316 474 188 316 minecraft:deepslate_tiles
setblock 477 185 277 minecraft:cobbled_deepslate
setblock 478 185 276 minecraft:cobbled_deepslate
setblock 478 185 316 minecraft:cobbled_deepslate
fill 479 185 276 479 187 276 minecraft:deepslate_tiles
setblock 479 185 316 minecraft:deepslate_tiles
setblock 492 185 277 minecraft:cobbled_deepslate
setblock 493 185 276 minecraft:cobbled_deepslate
fill 493 185 277 493 187 278 minecraft:deepslate_tiles
fill 494 185 276 494 188 276 minecraft:deepslate_tiles
fill 494 185 316 494 188 316 minecraft:deepslate_tiles
setblock 495 185 278 minecraft:deepslate_tiles
setblock 496 185 278 minecraft:cobbled_deepslate
fill 496 185 279 496 188 279 minecraft:deepslate_tiles
setblock 497 185 277 minecraft:cobbled_deepslate
fill 497 185 278 497 188 278 minecraft:deepslate_tiles
setblock 498 185 276 minecraft:cobbled_deepslate
fill 498 185 277 498 188 277 minecraft:deepslate_tiles
setblock 498 185 316 minecraft:cobbled_deepslate
fill 499 185 276 499 188 276 minecraft:deepslate_tiles
fill 499 185 316 499 188 316 minecraft:deepslate_tiles
setblock 501 185 278 minecraft:cobbled_deepslate
setblock 502 185 277 minecraft:cobbled_deepslate
setblock 502 185 278 minecraft:deepslate_tiles
setblock 503 185 276 minecraft:cobbled_deepslate
fill 503 185 277 503 188 277 minecraft:deepslate_tiles
fill 504 185 276 504 188 276 minecraft:deepslate_tiles
setblock 508 185 276 minecraft:cobbled_deepslate
fill 509 185 276 509 188 276 minecraft:deepslate_tiles
fill 509 185 316 509 188 316 minecraft:deepslate_tiles
setblock 511 185 278 minecraft:cobbled_deepslate
fill 511 185 279 511 188 279 minecraft:deepslate_tiles
setblock 511 185 282 minecraft:deepslate_tiles
fill 511 185 299 511 185 302 minecraft:deepslate_tiles
setblock 511 185 303 minecraft:cobbled_deepslate
fill 511 185 304 511 188 304 minecraft:deepslate_tiles
fill 511 185 314 511 188 314 minecraft:deepslate_tiles
fill 512 185 292 512 201 294 minecraft:black_concrete
setblock 512 185 295 minecraft:redstone_block
setblock 471 186 276 minecraft:deepslate_tiles
setblock 471 186 277 minecraft:cobbled_deepslate
fill 471 186 278 471 189 278 minecraft:deepslate_tiles
setblock 471 186 281 minecraft:deepslate_tiles
fill 471 186 295 471 187 295 minecraft:deepslate_tiles
setblock 471 186 297 minecraft:cobbled_deepslate
fill 471 186 298 471 189 298 minecraft:deepslate_tiles
setblock 471 186 302 minecraft:cobbled_deepslate
fill 471 186 303 471 189 303 minecraft:deepslate_tiles
setblock 471 186 307 minecraft:cobbled_deepslate
fill 471 186 308 472 188 308 minecraft:deepslate_tiles
fill 471 186 310 471 186 311 minecraft:deepslate_tiles
setblock 471 186 312 minecraft:cobbled_deepslate
fill 471 186 313 471 189 313 minecraft:deepslate_tiles
setblock 472 186 276 minecraft:cobbled_deepslate
fill 472 186 297 472 189 297 minecraft:deepslate_tiles
setblock 472 186 301 minecraft:cobbled_deepslate
fill 472 186 302 472 189 302 minecraft:deepslate_tiles
setblock 472 186 306 minecraft:cobbled_deepslate
fill 472 186 307 472 189 307 minecraft:deepslate_tiles
setblock 472 186 316 minecraft:cobbled_deepslate
fill 473 186 276 473 189 276 minecraft:deepslate_tiles
setblock 473 186 300 minecraft:cobbled_deepslate
fill 473 186 301 474 188 301 minecraft:deepslate_tiles
setblock 473 186 305 minecraft:cobbled_deepslate
fill 473 186 316 473 189 316 minecraft:deepslate_tiles
fill 474 186 277 474 187 277 minecraft:deepslate_tiles
fill 474 186 300 474 189 300 minecraft:deepslate_tiles
fill 474 186 302 474 186 303 minecraft:deepslate_tiles
setblock 476 186 277 minecraft:cobbled_deepslate
setblock 477 186 276 minecraft:cobbled_deepslate
setblock 477 186 316 minecraft:cobbled_deepslate
fill 478 186 276 478 189 276 minecraft:deepslate_tiles
setblock 478 186 316 minecraft:deepslate_tiles
setblock 485 186 317 minecraft:redstone_block
fill 486 186 317 487 197 317 minecraft:black_concrete
setblock 491 186 277 minecraft:cobbled_deepslate
setblock 492 186 276 minecraft:cobbled_deepslate
fill 492 186 277 492 189 277 minecraft:deepslate_tiles
fill 493 186 276 493 189 276 minecraft:deepslate_tiles
setblock 495 186 278 minecraft:cobbled_deepslate
fill 495 186 279 495 189 279 minecraft:deepslate_tiles
setblock 496 186 275 minecraft:redstone_block
setblock 496 186 277 minecraft:cobbled_deepslate
fill 496 186 278 496 189 278 minecraft:deepslate_tiles
setblock 497 186 276 minecraft:cobbled_deepslate
fill 497 186 277 497 189 277 minecraft:deepslate_tiles
setblock 497 186 316 minecraft:cobbled_deepslate
fill 498 186 276 498 189 276 minecraft:deepslate_tiles
fill 498 186 316 498 189 316 minecraft:deepslate_tiles
setblock 500 186 278 minecraft:cobbled_deepslate
setblock 501 186 277 minecraft:cobbled_deepslate
fill 501 186 278 501 188 278 minecraft:deepslate_tiles
setblock 502 186 276 minecraft:cobbled_deepslate
fill 502 186 277 502 189 277 minecraft:deepslate_tiles
fill 503 186 276 503 189 276 minecraft:deepslate_tiles
setblock 507 186 276 minecraft:cobbled_deepslate
fill 508 186 276 508 189 276 minecraft:deepslate_tiles
fill 509 186 277 509 187 277 minecraft:deepslate_tiles
setblock 510 186 278 minecraft:cobbled_deepslate
fill 510 186 279 510 189 279 minecraft:deepslate_tiles
setblock 511 186 277 minecraft:cobbled_deepslate
fill 511 186 278 511 189 278 minecraft:deepslate_tiles
setblock 511 186 282 minecraft:cobbled_deepslate
fill 511 186 283 511 189 283 minecraft:deepslate_tiles
fill 511 186 298 511 186 301 minecraft:deepslate_tiles
setblock 511 186 302 minecraft:cobbled_deepslate
fill 511 186 303 511 189 303 minecraft:deepslate_tiles
fill 511 186 305 511 186 306 minecraft:deepslate_tiles
setblock 511 186 307 minecraft:cobbled_deepslate
fill 511 186 308 511 189 308 minecraft:deepslate_tiles
fill 511 186 313 511 189 313 minecraft:deepslate_tiles
fill 512 186 295 512 201 295 minecraft:black_concrete
setblock 470 187 300 minecraft:redstone_block
fill 470 187 301 470 199 301 minecraft:black_concrete
setblock 471 187 276 minecraft:cobbled_deepslate
fill 471 187 277 471 190 277 minecraft:deepslate_tiles
setblock 471 187 281 minecraft:cobbled_deepslate
fill 471 187 282 471 189 283 minecraft:deepslate_tiles
setblock 471 187 296 minecraft:cobbled_deepslate
fill 471 187 297 471 190 297 minecraft:deepslate_tiles
setblock 471 187 301 minecraft:cobbled_deepslate
fill 471 187 302 471 190 302 minecraft:deepslate_tiles
setblock 471 187 305 minecraft:deepslate_tiles
setblock 471 187 306 minecraft:cobbled_deepslate
fill 471 187 307 471 190 307 minecraft:deepslate_tiles
setblock 471 187 310 minecraft:deepslate_tiles
setblock 471 187 311 minecraft:cobbled_deepslate
fill 471 187 312 471 190 312 minecraft:deepslate_tiles
setblock 471 187 316 minecraft:cobbled_deepslate
fill 472 187 276 472 190 276 minecraft:deepslate_tiles
fill 472 187 296 472 190 296 minecraft:deepslate_tiles
setblock 472 187 299 minecraft:deepslate_tiles
setblock 472 187 300 minecraft:cobbled_deepslate
fill 472 187 301 472 190 301 minecraft:deepslate_tiles
setblock 472 187 305 minecraft:cobbled_deepslate
fill 472 187 306 473 189 306 minecraft:deepslate_tiles
setblock 472 187 309 minecraft:deepslate_tiles
fill 472 187 316 472 190 316 minecraft:deepslate_tiles
setblock 473 187 278 minecraft:light[level=12]
setblock 473 187 285 minecraft:light[level=12]
setblock 473 187 292 minecraft:light[level=12]
fill 473 187 297 473 188 297 minecraft:deepslate_tiles
setblock 473 187 299 minecraft:cobbled_deepslate
fill 473 187 300 473 190 300 minecraft:deepslate_tiles
setblock 473 187 304 minecraft:cobbled_deepslate
fill 473 187 305 473 190 305 minecraft:deepslate_tiles
fill 473 187 307 473 188 307 minecraft:deepslate_tiles
setblock 473 187 313 minecraft:light[level=12]
fill 474 187 299 474 190 299 minecraft:deepslate_tiles
setblock 474 187 302 minecraft:deepslate_tiles
setblock 474 187 303 minecraft:cobbled_deepslate
fill 474 187 304 474 190 304 minecraft:deepslate_tiles
setblock 475 187 277 minecraft:cobbled_deepslate
setblock 476 187 276 minecraft:cobbled_deepslate
fill 476 187 277 476 188 277 minecraft:deepslate_tiles
setblock 476 187 316 minecraft:cobbled_deepslate
fill 477 187 276 477 190 276 minecraft:deepslate_tiles
fill 477 187 316 477 189 316 minecraft:deepslate_tiles
setblock 480 187 278 minecraft:light[level=12]
setblock 480 187 285 minecraft:light[level=12]
setblock 480 187 292 minecraft:light[level=12]
setblock 480 187 299 minecraft:light[level=12]
setblock 480 187 306 minecraft:light[level=12]
setblock 480 187 313 minecraft:light[level=12]
fill 485 187 317 485 201 317 minecraft:black_concrete
setblock 487 187 278 minecraft:light[level=12]
setblock 487 187 285 minecraft:light[level=12]
setblock 487 187 292 minecraft:light[level=12]
setblock 487 187 299 minecraft:light[level=12]
setblock 487 187 306 minecraft:light[level=12]
setblock 487 187 313 minecraft:light[level=12]
fill 489 187 276 489 188 276 minecraft:deepslate_tiles
setblock 490 187 277 minecraft:cobbled_deepslate
setblock 491 187 276 minecraft:cobbled_deepslate
fill 491 187 277 491 190 277 minecraft:deepslate_tiles
fill 492 187 276 492 190 276 minecraft:deepslate_tiles
fill 492 187 278 492 188 278 minecraft:deepslate_tiles
setblock 494 187 277 minecraft:deepslate_tiles
setblock 494 187 278 minecraft:cobbled_deepslate
fill 494 187 279 494 190 279 minecraft:deepslate_tiles
setblock 494 187 285 minecraft:light[level=12]
setblock 494 187 292 minecraft:light[level=12]
setblock 494 187 299 minecraft:light[level=12]
setblock 494 187 306 minecraft:light[level=12]
setblock 494 187 313 minecraft:light[level=12]
setblock 495 187 277 minecraft:cobbled_deepslate
fill 495 187 278 495 190 278 minecraft:deepslate_tiles
fill 496 187 275 496 199 275 minecraft:black_concrete
setblock 496 187 276 minecraft:cobbled_deepslate
fill 496 187 277 496 190 277 minecraft:deepslate_tiles
setblock 496 187 316 minecraft:cobbled_deepslate
fill 497 187 276 497 190 276 minecraft:deepslate_tiles
fill 497 187 316 497 190 316 minecraft:deepslate_tiles
setblock 498 187 279 minecraft:cobbled_deepslate
setblock 499 187 278 minecraft:cobbled_deepslate
setblock 500 187 277 minecraft:cobbled_deepslate
fill 500 187 278 500 190 278 minecraft:deepslate_tiles
setblock 501 187 276 minecraft:cobbled_deepslate
fill 501 187 277 501 190 277 minecraft:deepslate_tiles
setblock 501 187 285 minecraft:light[level=12]
setblock 501 187 292 minecraft:light[level=12]
setblock 501 187 299 minecraft:light[level=12]
setblock 501 187 306 minecraft:light[level=12]
setblock 501 187 313 minecraft:light[level=12]
fill 502 187 276 502 190 276 minecraft:deepslate_tiles
setblock 506 187 276 minecraft:cobbled_deepslate
fill 507 187 276 507 190 276 minecraft:deepslate_tiles
setblock 508 187 278 minecraft:light[level=12]
setblock 508 187 285 minecraft:light[level=12]
setblock 508 187 292 minecraft:light[level=12]
setblock 508 187 306 minecraft:light[level=12]
setblock 508 187 313 minecraft:light[level=12]
fill 508 187 316 508 189 316 minecraft:deepslate_tiles
setblock 510 187 277 minecraft:cobbled_deepslate
fill 510 187 278 510 190 278 minecraft:deepslate_tiles
fill 510 187 280 510 188 280 minecraft:deepslate_tiles
setblock 511 187 276 minecraft:cobbled_deepslate
fill 511 187 277 511 190 277 minecraft:deepslate_tiles
setblock 511 187 281 minecraft:cobbled_deepslate
fill 511 187 282 511 190 282 minecraft:deepslate_tiles
fill 511 187 284 511 188 284 minecraft:deepslate_tiles
fill 511 187 298 511 187 300 minecraft:deepslate_tiles
setblock 511 187 301 minecraft:cobbled_deepslate
fill 511 187 302 511 190 302 minecraft:deepslate_tiles
setblock 511 187 305 minecraft:deepslate_tiles
setblock 511 187 306 minecraft:cobbled_deepslate
fill 511 187 307 511 190 307 minecraft:deepslate_tiles
fill 511 187 309 511 187 310 minecraft:deepslate_tiles
setblock 511 187 311 minecraft:cobbled_deepslate
fill 511 187 312 511 190 312 minecraft:deepslate_tiles
setblock 511 187 316 minecraft:cobbled_deepslate
fill 470 188 300 470 201 300 minecraft:black_concrete
setblock 470 188 305 minecraft:white_wool
fill 471 188 276 471 191 276 minecraft:deepslate_tiles
setblock 471 188 279 minecraft:deepslate_tiles
setblock 471 188 280 minecraft:cobbled_deepslate
fill 471 188 281 472 190 281 minecraft:deepslate_tiles
setblock 471 188 284 minecraft:deepslate_tiles
setblock 471 188 285 minecraft:cobbled_deepslate
setblock 471 188 294 minecraft:deepslate_tiles
setblock 471 188 295 minecraft:cobbled_deepslate
fill 471 188 296 471 191 296 minecraft:deepslate_tiles
setblock 471 188 300 minecraft:cobbled_deepslate
fill 471 188 301 471 191 301 minecraft:deepslate_tiles
setblock 471 188 305 minecraft:cobbled_deepslate
fill 471 188 306 471 191 306 minecraft:deepslate_tiles
setblock 471 188 310 minecraft:cobbled_deepslate
fill 471 188 311 472 190 311 minecraft:deepslate_tiles
setblock 471 188 315 minecraft:cobbled_deepslate
fill 471 188 316 471 191 316 minecraft:deepslate_tiles
setblock 472 188 278 minecraft:deepslate_tiles
setblock 472 188 279 minecraft:cobbled_deepslate
fill 472 188 280 472 191 280 minecraft:deepslate_tiles
fill 472 188 282 472 188 283 minecraft:deepslate_tiles
setblock 472 188 298 minecraft:deepslate_tiles
setblock 472 188 299 minecraft:cobbled_deepslate
fill 472 188 300 472 191 300 minecraft:deepslate_tiles
setblock 472 188 303 minecraft:deepslate_tiles
setblock 472 188 304 minecraft:cobbled_deepslate
fill 472 188 305 472 191 305 minecraft:deepslate_tiles
setblock 472 188 309 minecraft:cobbled_deepslate
fill 472 188 310 472 191 310 minecraft:deepslate_tiles
setblock 473 188 277 minecraft:deepslate_tiles
setblock 473 188 298 minecraft:cobbled_deepslate
fill 473 188 299 473 191 299 minecraft:deepslate_tiles
setblock 473 188 303 minecraft:cobbled_deepslate
fill 473 188 304 473 191 304 minecraft:deepslate_tiles
setblock 473 188 308 minecraft:cobbled_deepslate
setblock 474 188 277 minecraft:cobbled_deepslate
setblock 474 188 302 minecraft:cobbled_deepslate
fill 474 188 303 474 191 303 minecraft:deepslate_tiles
fill 474 188 305 474 188 306 minecraft:deepslate_tiles
setblock 475 188 276 minecraft:cobbled_deepslate
fill 475 188 277 475 190 277 minecraft:deepslate_tiles
setblock 475 188 316 minecraft:cobbled_deepslate
fill 476 188 276 476 191 276 minecraft:deepslate_tiles
fill 476 188 316 476 191 316 minecraft:deepslate_tiles
fill 488 188 276 488 189 276 minecraft:deepslate_tiles
setblock 490 188 276 minecraft:cobbled_deepslate
fill 490 188 277 490 191 277 minecraft:deepslate_tiles
fill 491 188 276 491 191 276 minecraft:deepslate_tiles
fill 491 188 278 491 189 278 minecraft:deepslate_tiles
setblock 493 188 277 minecraft:deepslate_tiles
setblock 493 188 278 minecraft:cobbled_deepslate
fill 493 188 279 493 191 279 minecraft:deepslate_tiles
fill 493 188 316 493 189 316 minecraft:deepslate_tiles
setblock 494 188 277 minecraft:cobbled_deepslate
fill 494 188 278 494 191 278 minecraft:deepslate_tiles
setblock 495 188 276 minecraft:cobbled_deepslate
fill 495 188 277 495 191 277 minecraft:deepslate_tiles
setblock 495 188 316 minecraft:cobbled_deepslate
fill 496 188 276 496 191 276 minecraft:deepslate_tiles
fill 496 188 316 496 191 316 minecraft:deepslate_tiles
setblock 496 188 317 minecraft:redstone_block
setblock 497 188 279 minecraft:cobbled_deepslate
setblock 498 188 278 minecraft:cobbled_deepslate
fill 498 188 279 498 190 279 minecraft:deepslate_tiles
setblock 499 188 277 minecraft:cobbled_deepslate
fill 499 188 278 499 191 278 minecraft:deepslate_tiles
setblock 500 188 276 minecraft:cobbled_deepslate
fill 500 188 277 500 191 277 minecraft:deepslate_tiles
setblock 500 188 316 minecraft:cobbled_deepslate
fill 501 188 276 501 191 276 minecraft:deepslate_tiles
setblock 504 188 277 minecraft:cobbled_deepslate
setblock 505 188 276 minecraft:cobbled_deepslate
fill 506 188 276 506 191 276 minecraft:deepslate_tiles
setblock 508 188 277 minecraft:deepslate_tiles
setblock 509 188 277 minecraft:cobbled_deepslate
setblock 510 188 276 minecraft:cobbled_deepslate
fill 510 188 277 510 191 277 minecraft:deepslate_tiles
setblock 510 188 281 minecraft:cobbled_deepslate
fill 510 188 282 510 191 282 minecraft:deepslate_tiles
setblock 510 188 301 minecraft:cobbled_deepslate
fill 510 188 302 510 188 305 minecraft:deepslate_tiles
setblock 510 188 306 minecraft:cobbled_deepslate
fill 510 188 307 510 191 307 minecraft:deepslate_tiles
setblock 510 188 316 minecraft:cobbled_deepslate
fill 511 188 276 511 191 276 minecraft:deepslate_tiles
setblock 511 188 280 minecraft:cobbled_deepslate
fill 511 188 281 511 191 281 minecraft:deepslate_tiles
setblock 511 188 285 minecraft:cobbled_deepslate
fill 511 188 297 511 188 299 minecraft:deepslate_tiles
setblock 511 188 300 minecraft:cobbled_deepslate
fill 511 188 301 511 191 301 minecraft:deepslate_tiles
setblock 511 188 305 minecraft:cobbled_deepslate
fill 511 188 306 511 191 306 minecraft:deepslate_tiles
setblock 511 188 309 minecraft:deepslate_tiles
setblock 511 188 310 minecraft:cobbled_deepslate
fill 511 188 311 511 191 311 minecraft:deepslate_tiles
setblock 511 188 315 minecraft:cobbled_deepslate
fill 511 188 316 511 191 316 minecraft:deepslate_tiles
setblock 512 188 299 minecraft:redstone_block
fill 470 189 305 470 198 305 minecraft:black_concrete
setblock 470 189 313 minecraft:redstone_block
setblock 471 189 279 minecraft:cobbled_deepslate
fill 471 189 280 471 192 280 minecraft:deepslate_tiles
setblock 471 189 284 minecraft:cobbled_deepslate
fill 471 189 285 471 189 288 minecraft:deepslate_tiles
setblock 471 189 289 minecraft:cobbled_deepslate
fill 471 189 292 471 189 293 minecraft:deepslate_tiles
setblock 471 189 294 minecraft:cobbled_deepslate
fill 471 189 295 472 191 295 minecraft:deepslate_tiles
setblock 471 189 299 minecraft:cobbled_deepslate
fill 471 189 300 471 192 300 minecraft:deepslate_tiles
setblock 471 189 304 minecraft:cobbled_deepslate
fill 471 189 305 471 192 305 minecraft:deepslate_tiles
setblock 471 189 308 minecraft:deepslate_tiles
setblock 471 189 309 minecraft:cobbled_deepslate
fill 471 189 310 471 192 310 minecraft:deepslate_tiles
setblock 471 189 314 minecraft:cobbled_deepslate
fill 471 189 315 471 192 315 minecraft:deepslate_tiles
setblock 472 189 277 minecraft:deepslate_tiles
setblock 472 189 278 minecraft:cobbled_deepslate
fill 472 189 279 472 192 279 minecraft:deepslate_tiles
setblock 472 189 282 minecraft:deepslate_tiles
setblock 472 189 283 minecraft:cobbled_deepslate
fill 472 189 284 472 191 285 minecraft:deepslate_tiles
setblock 472 189 298 minecraft:cobbled_deepslate
fill 472 189 299 472 192 299 minecraft:deepslate_tiles
setblock 472 189 303 minecraft:cobbled_deepslate
fill 472 189 304 472 192 304 minecraft:deepslate_tiles
setblock 472 189 308 minecraft:cobbled_deepslate
fill 472 189 309 473 191 309 minecraft:deepslate_tiles
setblock 472 189 312 minecraft:deepslate_tiles
setblock 472 189 313 minecraft:cobbled_deepslate
setblock 473 189 277 minecraft:cobbled_deepslate
setblock 473 189 278 minecraft:light[level=13]
setblock 473 189 286 minecraft:light[level=13]
setblock 473 189 294 minecraft:light[level=13]
setblock 473 189 297 minecraft:cobbled_deepslate
fill 473 189 298 473 192 298 minecraft:deepslate_tiles
setblock 473 189 301 minecraft:deepslate_tiles
setblock 473 189 302 minecraft:cobbled_deepslate
fill 473 189 303 473 192 303 minecraft:deepslate_tiles
setblock 473 189 307 minecraft:cobbled_deepslate
fill 473 189 308 473 192 308 minecraft:deepslate_tiles
fill 473 189 310 473 190 310 minecraft:deepslate_tiles
setblock 474 189 276 minecraft:cobbled_deepslate
fill 474 189 277 474 190 277 minecraft:deepslate_tiles
setblock 474 189 301 minecraft:cobbled_deepslate
fill 474 189 302 474 192 302 minecraft:deepslate_tiles
setblock 474 189 305 minecraft:deepslate_tiles
setblock 474 189 306 minecraft:cobbled_deepslate
fill 474 189 307 474 192 307 minecraft:deepslate_tiles
setblock 474 189 316 minecraft:cobbled_deepslate
fill 475 189 276 475 192 276 minecraft:deepslate_tiles
fill 475 189 316 475 192 316 minecraft:deepslate_tiles
fill 477 189 300 477 192 301 minecraft:white_terracotta
fill 478 189 301 478 192 301 minecraft:white_terracotta
setblock 481 189 278 minecraft:light[level=13]
setblock 481 189 286 minecraft:light[level=13]
setblock 481 189 294 minecraft:light[level=13]
setblock 481 189 302 minecraft:light[level=13]
setblock 481 189 310 minecraft:light[level=13]
setblock 489 189 276 minecraft:cobbled_deepslate
fill 489 189 277 489 192 277 minecraft:deepslate_tiles
setblock 489 189 278 minecraft:light[level=13]
setblock 489 189 286 minecraft:light[level=13]
setblock 489 189 294 minecraft:light[level=13]
setblock 489 189 302 minecraft:light[level=13]
setblock 489 189 310 minecraft:light[level=13]
fill 490 189 276 490 192 276 minecraft:deepslate_tiles
fill 490 189 278 490 190 278 minecraft:deepslate_tiles
setblock 492 189 278 minecraft:cobbled_deepslate
fill 492 189 279 492 192 279 minecraft:deepslate_tiles
fill 492 189 316 492 190 316 minecraft:deepslate_tiles
setblock 493 189 277 minecraft:cobbled_deepslate
fill 493 189 278 493 192 278 minecraft:deepslate_tiles
setblock 494 189 276 minecraft:cobbled_deepslate
fill 494 189 277 494 192 277 minecraft:deepslate_tiles
setblock 494 189 316 minecraft:cobbled_deepslate
fill 495 189 276 495 192 276 minecraft:deepslate_tiles
fill 495 189 316 495 192 316 minecraft:deepslate_tiles
setblock 496 189 279 minecraft:cobbled_deepslate
fill 496 189 317 496 198 317 minecraft:black_concrete
setblock 497 189 278 minecraft:cobbled_deepslate
fill 497 189 279 497 191 279 minecraft:deepslate_tiles
setblock 497 189 286 minecraft:light[level=13]
setblock 497 189 294 minecraft:light[level=13]
setblock 497 189 302 minecraft:light[level=13]
setblock 497 189 310 minecraft:light[level=13]
setblock 498 189 277 minecraft:cobbled_deepslate
fill 498 189 278 498 192 278 minecraft:deepslate_tiles
setblock 499 189 276 minecraft:cobbled_deepslate
fill 499 189 277 499 192 277 minecraft:deepslate_tiles
setblock 499 189 316 minecraft:cobbled_deepslate
fill 500 189 276 500 192 276 minecraft:deepslate_tiles
fill 500 189 316 500 192 316 minecraft:deepslate_tiles
setblock 503 189 277 minecraft:cobbled_deepslate
setblock 504 189 276 minecraft:cobbled_deepslate
fill 505 189 276 505 192 276 minecraft:deepslate_tiles
setblock 505 189 278 minecraft:light[level=13]
setblock 505 189 286 minecraft:light[level=13]
setblock 505 189 294 minecraft:light[level=13]
setblock 505 189 302 minecraft:light[level=13]
setblock 505 189 310 minecraft:light[level=13]
setblock 507 189 277 minecraft:deepslate_tiles
fill 507 189 316 507 190 316 minecraft:deepslate_tiles
setblock 508 189 277 minecraft:cobbled_deepslate
setblock 509 189 276 minecraft:cobbled_deepslate
fill 509 189 277 509 192 277 minecraft:deepslate_tiles
setblock 509 189 316 minecraft:cobbled_deepslate
fill 510 189 276 510 192 276 minecraft:deepslate_tiles
setblock 510 189 280 minecraft:cobbled_deepslate
fill 510 189 281 510 192 281 minecraft:deepslate_tiles
fill 510 189 283 510 190 283 minecraft:deepslate_tiles
setblock 510 189 300 minecraft:cobbled_deepslate
fill 510 189 301 510 189 304 minecraft:deepslate_tiles
setblock 510 189 305 minecraft:cobbled_deepslate
fill 510 189 306 510 192 306 minecraft:deepslate_tiles
fill 510 189 308 510 189 309 minecraft:deepslate_tiles
setblock 510 189 310 minecraft:cobbled_deepslate
fill 510 189 311 510 192 311 minecraft:deepslate_tiles
fill 510 189 316 510 192 316 minecraft:deepslate_tiles
setblock 511 189 279 minecraft:cobbled_deepslate
fill 511 189 280 511 192 280 minecraft:deepslate_tiles
setblock 511 189 284 minecraft:cobbled_deepslate
fill 511 189 285 511 190 287 minecraft:deepslate_tiles
fill 511 189 296 511 189 298 minecraft:deepslate_tiles
setblock 511 189 299 minecraft:cobbled_deepslate
fill 511 189 300 511 192 300 minecraft:deepslate_tiles
setblock 511 189 304 minecraft:cobbled_deepslate
fill 511 189 305 511 192 305 minecraft:deepslate_tiles
setblock 511 189 309 minecraft:cobbled_deepslate
fill 511 189 310 511 192 310 minecraft:deepslate_tiles
setblock 511 189 314 minecraft:cobbled_deepslate
fill 511 189 315 511 192 315 minecraft:deepslate_tiles
fill 512 189 299 512 201 299 minecraft:black_concrete
setblock 470 190 288 minecraft:white_wool
setblock 470 190 307 minecraft:white_wool
fill 470 190 313 470 201 313 minecraft:black_concrete
setblock 471 190 278 minecraft:cobbled_deepslate
fill 471 190 279 471 193 279 minecraft:deepslate_tiles
setblock 471 190 282 minecraft:deepslate_tiles
setblock 471 190 283 minecraft:cobbled_deepslate
fill 471 190 284 471 190 287 minecraft:deepslate_tiles
setblock 471 190 288 minecraft:cobbled_deepslate
fill 471 190 289 471 190 292 minecraft:deepslate_tiles
setblock 471 190 293 minecraft:cobbled_deepslate
fill 471 190 294 472 192 294 minecraft:deepslate_tiles
setblock 471 190 298 minecraft:cobbled_deepslate
fill 471 190 299 471 193 299 minecraft:deepslate_tiles
setblock 471 190 303 minecraft:cobbled_deepslate
fill 471 190 304 471 193 304 minecraft:deepslate_tiles
setblock 471 190 308 minecraft:cobbled_deepslate
fill 471 190 309 471 193 309 minecraft:deepslate_tiles
setblock 471 190 313 minecraft:cobbled_deepslate
fill 471 190 314 472 192 314 minecraft:deepslate_tiles
setblock 472 190 277 minecraft:cobbled_deepslate
fill 472 190 278 472 192 278 minecraft:deepslate_tiles
setblock 472 190 282 minecraft:cobbled_deepslate
fill 472 190 283 473 192 283 minecraft:deepslate_tiles
setblock 472 190 286 minecraft:deepslate_tiles
setblock 472 190 287 minecraft:cobbled_deepslate
fill 472 190 288 472 193 288 minecraft:deepslate_tiles
setblock 472 190 297 minecraft:cobbled_deepslate
fill 472 190 298 472 193 298 minecraft:deepslate_tiles
setblock 472 190 302 minecraft:cobbled_deepslate
fill 472 190 303 472 193 303 minecraft:deepslate_tiles
setblock 472 190 306 minecraft:deepslate_tiles
setblock 472 190 307 minecraft:cobbled_deepslate
fill 472 190 308 472 193 308 minecraft:deepslate_tiles
setblock 472 190 312 minecraft:cobbled_deepslate
fill 472 190 313 472 193 313 minecraft:deepslate_tiles
fill 472 190 315 472 191 315 minecraft:deepslate_tiles
setblock 473 190 276 minecraft:cobbled_deepslate
fill 473 190 277 473 191 277 minecraft:deepslate_tiles
setblock 473 190 281 minecraft:cobbled_deepslate
fill 473 190 282 473 193 282 minecraft:deepslate_tiles
fill 473 190 284 473 191 284 minecraft:deepslate_tiles
setblock 473 190 296 minecraft:cobbled_deepslate
fill 473 190 297 473 193 297 minecraft:deepslate_tiles
setblock 473 190 301 minecraft:cobbled_deepslate
fill 473 190 302 473 193 302 minecraft:deepslate_tiles
setblock 473 190 306 minecraft:cobbled_deepslate
fill 473 190 307 473 193 307 minecraft:deepslate_tiles
setblock 473 190 311 minecraft:cobbled_deepslate
setblock 473 190 316 minecraft:cobbled_deepslate
fill 474 190 276 474 193 276 minecraft:deepslate_tiles
setblock 474 190 300 minecraft:cobbled_deepslate
fill 474 190 301 474 193 301 minecraft:deepslate_tiles
setblock 474 190 305 minecraft:cobbled_deepslate
fill 474 190 306 474 193 306 minecraft:deepslate_tiles
fill 474 190 308 474 191 308 minecraft:deepslate_tiles
fill 474 190 316 474 193 316 minecraft:deepslate_tiles
fill 475 190 302 475 190 303 minecraft:deepslate_tiles
setblock 475 190 304 minecraft:cobbled_deepslate
fill 476 190 300 476 191 301 minecraft:white_terracotta
fill 477 190 302 477 191 302 minecraft:white_terracotta
fill 478 190 300 478 191 300 minecraft:white_terracotta
setblock 487 190 276 minecraft:deepslate_tiles
setblock 488 190 276 minecraft:cobbled_deepslate
fill 488 190 277 488 193 277 minecraft:deepslate_tiles
fill 489 190 276 489 193 276 minecraft:deepslate_tiles
setblock 491 190 278 minecraft:cobbled_deepslate
fill 491 190 279 491 193 279 minecraft:deepslate_tiles
setblock 492 190 277 minecraft:cobbled_deepslate
fill 492 190 278 492 193 278 minecraft:deepslate_tiles
setblock 493 190 276 minecraft:cobbled_deepslate
fill 493 190 277 493 193 277 minecraft:deepslate_tiles
setblock 493 190 316 minecraft:cobbled_deepslate
fill 494 190 276 494 193 276 minecraft:deepslate_tiles
setblock 494 190 280 minecraft:cobbled_deepslate
fill 494 190 316 494 193 316 minecraft:deepslate_tiles
setblock 495 190 279 minecraft:cobbled_deepslate
setblock 495 190 280 minecraft:deepslate_tiles
setblock 496 190 278 minecraft:cobbled_deepslate
fill 496 190 279 496 192 279 minecraft:deepslate_tiles
setblock 497 190 277 minecraft:cobbled_deepslate
fill 497 190 278 497 193 278 minecraft:deepslate_tiles
setblock 498 190 276 minecraft:cobbled_deepslate
fill 498 190 277 498 193 277 minecraft:deepslate_tiles
setblock 498 190 316 minecraft:cobbled_deepslate
fill 499 190 276 499 193 276 minecraft:deepslate_tiles
fill 499 190 316 499 193 316 minecraft:deepslate_tiles
setblock 502 190 277 minecraft:cobbled_deepslate
setblock 503 190 276 minecraft:cobbled_deepslate
setblock 503 190 277 minecraft:deepslate_tiles
fill 504 190 276 504 193 276 minecraft:deepslate_tiles
fill 506 190 316 506 191 316 minecraft:deepslate_tiles
setblock 507 190 277 minecraft:cobbled_deepslate
setblock 508 190 276 minecraft:cobbled_deepslate
fill 508 190 277 508 192 277 minecraft:deepslate_tiles
setblock 508 190 316 minecraft:cobbled_deepslate
fill 509 190 276 509 193 276 minecraft:deepslate_tiles
setblock 509 190 304 minecraft:deepslate_tiles
setblock 509 190 305 minecraft:cobbled_deepslate
fill 509 190 306 509 192 307 minecraft:deepslate_tiles
fill 509 190 316 509 193 316 minecraft:deepslate_tiles
setblock 510 190 279 minecraft:cobbled_deepslate
fill 510 190 280 510 193 280 minecraft:deepslate_tiles
setblock 510 190 284 minecraft:cobbled_deepslate
fill 510 190 285 510 193 285 minecraft:deepslate_tiles
setblock 510 190 299 minecraft:cobbled_deepslate
fill 510 190 300 510 190 303 minecraft:deepslate_tiles
setblock 510 190 304 minecraft:cobbled_deepslate
fill 510 190 305 510 193 305 minecraft:deepslate_tiles
setblock 510 190 308 minecraft:deepslate_tiles
setblock 510 190 309 minecraft:cobbled_deepslate
fill 510 190 310 510 193 310 minecraft:deepslate_tiles
fill 510 190 312 510 190 313 minecraft:deepslate_tiles
setblock 510 190 314 minecraft:cobbled_deepslate
fill 510 190 315 510 193 315 minecraft:deepslate_tiles
setblock 511 190 278 minecraft:cobbled_deepslate
fill 511 190 279 511 193 279 minecraft:deepslate_tiles
setblock 511 190 283 minecraft:cobbled_deepslate
fill 511 190 284 511 193 284 minecraft:deepslate_tiles
setblock 511 190 288 minecraft:cobbled_deepslate
fill 511 190 296 511 190 297 minecraft:deepslate_tiles
setblock 511 190 298 minecraft:cobbled_deepslate
fill 511 190 299 511 193 299 minecraft:deepslate_tiles
setblock 511 190 303 minecraft:cobbled_deepslate
fill 511 190 304 511 193 304 minecraft:deepslate_tiles
setblock 511 190 308 minecraft:cobbled_deepslate
fill 511 190 309 511 193 309 minecraft:deepslate_tiles
setblock 511 190 313 minecraft:cobbled_deepslate
fill 511 190 314 511 193 314 minecraft:deepslate_tiles
fill 470 191 288 470 201 288 minecraft:black_concrete
fill 470 191 307 470 202 307 minecraft:black_concrete
setblock 471 191 277 minecraft:cobbled_deepslate
fill 471 191 278 471 194 278 minecraft:deepslate_tiles
setblock 471 191 281 minecraft:deepslate_tiles
setblock 471 191 282 minecraft:cobbled_deepslate
fill 471 191 283 471 191 286 minecraft:deepslate_tiles
setblock 471 191 287 minecraft:cobbled_deepslate
fill 471 191 288 471 191 291 minecraft:deepslate_tiles
setblock 471 191 292 minecraft:cobbled_deepslate
fill 471 191 293 472 193 293 minecraft:deepslate_tiles
setblock 471 191 297 minecraft:cobbled_deepslate
fill 471 191 298 471 194 298 minecraft:deepslate_tiles
setblock 471 191 302 minecraft:cobbled_deepslate
fill 471 191 303 471 194 303 minecraft:deepslate_tiles
setblock 471 191 307 minecraft:cobbled_deepslate
fill 471 191 308 471 194 308 minecraft:deepslate_tiles
setblock 471 191 311 minecraft:deepslate_tiles
setblock 471 191 312 minecraft:cobbled_deepslate
fill 471 191 313 471 194 313 minecraft:deepslate_tiles
setblock 472 191 276 minecraft:cobbled_deepslate
setblock 472 191 277 minecraft:deepslate_tiles
setblock 472 191 281 minecraft:cobbled_deepslate
fill 472 191 282 472 194 282 minecraft:deepslate_tiles
setblock 472 191 286 minecraft:cobbled_deepslate
fill 472 191 287 473 193 287 minecraft:deepslate_tiles
fill 472 191 289 472 191 290 minecraft:deepslate_tiles
setblock 472 191 291 minecraft:cobbled_deepslate
fill 472 191 292 472 194 292 minecraft:deepslate_tiles
setblock 472 191 296 minecraft:cobbled_deepslate
fill 472 191 297 472 194 297 minecraft:deepslate_tiles
setblock 472 191 301 minecraft:cobbled_deepslate
fill 472 191 302 472 194 302 minecraft:deepslate_tiles
setblock 472 191 306 minecraft:cobbled_deepslate
fill 472 191 307 472 194 307 minecraft:deepslate_tiles
setblock 472 191 311 minecraft:cobbled_deepslate
fill 472 191 312 472 194 312 minecraft:deepslate_tiles
setblock 472 191 316 minecraft:cobbled_deepslate
fill 473 191 276 473 193 276 minecraft:deepslate_tiles
fill 473 191 281 473 192 281 minecraft:deepslate_tiles
setblock 473 191 285 minecraft:cobbled_deepslate
fill 473 191 286 473 194 286 minecraft:deepslate_tiles
fill 473 191 296 473 192 296 minecraft:deepslate_tiles
setblock 473 191 300 minecraft:cobbled_deepslate
fill 473 191 301 473 194 301 minecraft:deepslate_tiles
setblock 473 191 305 minecraft:cobbled_deepslate
fill 473 191 306 473 194 306 minecraft:deepslate_tiles
setblock 473 191 310 minecraft:cobbled_deepslate
fill 473 191 311 473 194 311 minecraft:deepslate_tiles
setblock 473 191 315 minecraft:cobbled_deepslate
fill 473 191 316 473 194 316 minecraft:deepslate_tiles
setblock 474 191 299 minecraft:cobbled_deepslate
fill 474 191 300 474 192 300 minecraft:deepslate_tiles
setblock 474 191 304 minecraft:cobbled_deepslate
fill 474 191 305 474 194 305 minecraft:deepslate_tiles
setblock 475 191 303 minecraft:cobbled_deepslate
setblock 475 191 304 minecraft:deepslate_tiles
setblock 477 191 276 minecraft:cobbled_deepslate
setblock 487 191 276 minecraft:cobbled_deepslate
fill 488 191 276 488 194 276 minecraft:deepslate_tiles
setblock 488 191 317 minecraft:white_wool
setblock 489 191 278 minecraft:deepslate_tiles
setblock 490 191 278 minecraft:cobbled_deepslate
setblock 491 191 277 minecraft:cobbled_deepslate
fill 491 191 278 491 194 278 minecraft:deepslate_tiles
setblock 491 191 316 minecraft:deepslate_tiles
setblock 492 191 276 minecraft:cobbled_deepslate
fill 492 191 277 492 194 277 minecraft:deepslate_tiles
setblock 492 191 316 minecraft:cobbled_deepslate
fill 493 191 276 493 194 276 minecraft:deepslate_tiles
setblock 493 191 280 minecraft:cobbled_deepslate
fill 493 191 316 493 194 316 minecraft:deepslate_tiles
setblock 494 191 279 minecraft:cobbled_deepslate
setblock 494 191 280 minecraft:deepslate_tiles
setblock 495 191 278 minecraft:cobbled_deepslate
fill 495 191 279 495 193 279 minecraft:deepslate_tiles
setblock 496 191 277 minecraft:cobbled_deepslate
fill 496 191 278 496 193 278 minecraft:deepslate_tiles
setblock 497 191 276 minecraft:cobbled_deepslate
fill 497 191 277 497 194 277 minecraft:deepslate_tiles
setblock 497 191 316 minecraft:cobbled_deepslate
fill 498 191 276 498 194 276 minecraft:deepslate_tiles
fill 498 191 316 498 194 316 minecraft:deepslate_tiles
setblock 501 191 277 minecraft:cobbled_deepslate
setblock 502 191 276 minecraft:cobbled_deepslate
setblock 502 191 277 minecraft:deepslate_tiles
fill 503 191 276 503 193 276 minecraft:deepslate_tiles
fill 505 191 316 505 192 316 minecraft:deepslate_tiles
setblock 507 191 276 minecraft:cobbled_deepslate
setblock 507 191 277 minecraft:deepslate_tiles
setblock 507 191 316 minecraft:cobbled_deepslate
fill 508 191 276 508 194 276 minecraft:deepslate_tiles
fill 508 191 316 508 194 316 minecraft:deepslate_tiles
fill 509 191 302 509 191 303 minecraft:deepslate_tiles
setblock 509 191 304 minecraft:cobbled_deepslate
fill 509 191 305 509 194 305 minecraft:deepslate_tiles
setblock 509 191 308 minecraft:deepslate_tiles
setblock 509 191 309 minecraft:cobbled_deepslate
fill 509 191 310 509 194 310 minecraft:deepslate_tiles
fill 509 191 315 509 194 315 minecraft:deepslate_tiles
setblock 510 191 278 minecraft:cobbled_deepslate
fill 510 191 279 510 194 279 minecraft:deepslate_tiles
setblock 510 191 283 minecraft:cobbled_deepslate
fill 510 191 284 510 194 284 minecraft:deepslate_tiles
fill 510 191 286 511 191 286 minecraft:deepslate_tiles
fill 510 191 299 510 191 302 minecraft:deepslate_tiles
setblock 510 191 303 minecraft:cobbled_deepslate
fill 510 191 304 510 194 304 minecraft:deepslate_tiles
setblock 510 191 308 minecraft:cobbled_deepslate
fill 510 191 309 510 194 309 minecraft:deepslate_tiles
setblock 510 191 312 minecraft:deepslate_tiles
setblock 510 191 313 minecraft:cobbled_deepslate
fill 510 191 314 510 194 314 minecraft:deepslate_tiles
setblock 511 191 277 minecraft:cobbled_deepslate
fill 511 191 278 511 194 278 minecraft:deepslate_tiles
setblock 511 191 282 minecraft:cobbled_deepslate
fill 511 191 283 511 194 283 minecraft:deepslate_tiles
fill 511 191 285 511 192 285 minecraft:deepslate_tiles
setblock 511 191 287 minecraft:cobbled_deepslate
fill 511 191 288 511 192 290 minecraft:deepslate_tiles
fill 511 191 295 511 191 296 minecraft:deepslate_tiles
setblock 511 191 297 minecraft:cobbled_deepslate
fill 511 191 298 511 194 298 minecraft:deepslate_tiles
setblock 511 191 302 minecraft:cobbled_deepslate
fill 511 191 303 511 194 303 minecraft:deepslate_tiles
setblock 511 191 307 minecraft:cobbled_deepslate
fill 511 191 308 511 194 308 minecraft:deepslate_tiles
setblock 511 191 312 minecraft:cobbled_deepslate
fill 511 191 313 511 194 313 minecraft:deepslate_tiles
setblock 471 192 276 minecraft:cobbled_deepslate
fill 471 192 277 471 194 277 minecraft:deepslate_tiles
setblock 471 192 281 minecraft:cobbled_deepslate
fill 471 192 282 471 192 285 minecraft:deepslate_tiles
setblock 471 192 286 minecraft:cobbled_deepslate
fill 471 192 287 471 192 290 minecraft:deepslate_tiles
setblock 471 192 291 minecraft:cobbled_deepslate
fill 471 192 292 471 195 292 minecraft:deepslate_tiles
setblock 471 192 295 minecraft:deepslate_tiles
setblock 471 192 296 minecraft:cobbled_deepslate
fill 471 192 297 471 195 297 minecraft:deepslate_tiles
setblock 471 192 301 minecraft:cobbled_deepslate
fill 471 192 302 471 195 302 minecraft:deepslate_tiles
setblock 471 192 306 minecraft:cobbled_deepslate
fill 471 192 307 471 195 307 minecraft:deepslate_tiles
setblock 471 192 311 minecraft:cobbled_deepslate
fill 471 192 312 471 195 312 minecraft:deepslate_tiles
setblock 471 192 316 minecraft:cobbled_deepslate
fill 472 192 276 472 194 276 minecraft:deepslate_tiles
setblock 472 192 280 minecraft:cobbled_deepslate
fill 472 192 281 472 195 281 minecraft:deepslate_tiles
setblock 472 192 284 minecraft:deepslate_tiles
setblock 472 192 285 minecraft:cobbled_deepslate
fill 472 192 286 472 195 286 minecraft:deepslate_tiles
setblock 472 192 289 minecraft:deepslate_tiles
setblock 472 192 290 minecraft:cobbled_deepslate
fill 472 192 291 472 195 291 minecraft:deepslate_tiles
setblock 472 192 295 minecraft:cobbled_deepslate
fill 472 192 296 472 195 296 minecraft:deepslate_tiles
setblock 472 192 300 minecraft:cobbled_deepslate
fill 472 192 301 472 195 301 minecraft:deepslate_tiles
setblock 472 192 305 minecraft:cobbled_deepslate
fill 472 192 306 472 195 306 minecraft:deepslate_tiles
setblock 472 192 309 minecraft:deepslate_tiles
setblock 472 192 310 minecraft:cobbled_deepslate
fill 472 192 311 472 195 311 minecraft:deepslate_tiles
setblock 472 192 315 minecraft:cobbled_deepslate
fill 472 192 316 472 195 316 minecraft:deepslate_tiles
setblock 473 192 284 minecraft:cobbled_deepslate
fill 473 192 285 473 195 285 minecraft:deepslate_tiles
setblock 473 192 288 minecraft:deepslate_tiles
setblock 473 192 289 minecraft:cobbled_deepslate
setblock 473 192 299 minecraft:cobbled_deepslate
fill 473 192 300 473 195 300 minecraft:deepslate_tiles
setblock 473 192 304 minecraft:cobbled_deepslate
fill 473 192 305 473 195 305 minecraft:deepslate_tiles
setblock 473 192 309 minecraft:cobbled_deepslate
fill 473 192 310 473 195 310 minecraft:deepslate_tiles
fill 473 192 312 473 193 312 minecraft:deepslate_tiles
setblock 474 192 299 minecraft:deepslate_tiles
setblock 474 192 303 minecraft:cobbled_deepslate
fill 474 192 304 474 194 304 minecraft:deepslate_tiles
setblock 474 192 308 minecraft:cobbled_deepslate
fill 474 192 309 474 193 309 minecraft:deepslate_tiles
fill 487 192 276 487 195 276 minecraft:deepslate_tiles
fill 488 192 317 488 197 317 minecraft:black_concrete
setblock 489 192 278 minecraft:cobbled_deepslate
setblock 490 192 277 minecraft:cobbled_deepslate
fill 490 192 278 490 192 279 minecraft:deepslate_tiles
setblock 490 192 316 minecraft:deepslate_tiles
setblock 491 192 276 minecraft:cobbled_deepslate
fill 491 192 277 491 195 277 minecraft:deepslate_tiles
setblock 491 192 316 minecraft:cobbled_deepslate
fill 492 192 276 492 195 276 minecraft:deepslate_tiles
fill 492 192 316 492 195 316 minecraft:deepslate_tiles
setblock 493 192 279 minecraft:cobbled_deepslate
setblock 494 192 278 minecraft:cobbled_deepslate
fill 494 192 279 494 193 279 minecraft:deepslate_tiles
setblock 495 192 277 minecraft:cobbled_deepslate
fill 495 192 278 495 194 278 minecraft:deepslate_tiles
setblock 496 192 276 minecraft:cobbled_deepslate
fill 496 192 277 496 195 277 minecraft:deepslate_tiles
setblock 496 192 316 minecraft:cobbled_deepslate
fill 497 192 276 497 195 276 minecraft:deepslate_tiles
fill 497 192 316 497 195 316 minecraft:deepslate_tiles
setblock 500 192 277 minecraft:cobbled_deepslate
setblock 501 192 276 minecraft:cobbled_deepslate
fill 502 192 276 502 193 276 minecraft:deepslate_tiles
fill 504 192 316 504 193 316 minecraft:deepslate_tiles
setblock 506 192 276 minecraft:cobbled_deepslate
setblock 506 192 316 minecraft:cobbled_deepslate
fill 507 192 276 507 195 276 minecraft:deepslate_tiles
fill 507 192 316 507 195 316 minecraft:deepslate_tiles
fill 508 192 315 508 195 315 minecraft:deepslate_tiles
setblock 509 192 302 minecraft:deepslate_tiles
setblock 509 192 303 minecraft:cobbled_deepslate
fill 509 192 304 509 195 304 minecraft:deepslate_tiles
setblock 509 192 308 minecraft:cobbled_deepslate
fill 509 192 309 509 195 309 minecraft:deepslate_tiles
fill 509 192 311 509 192 312 minecraft:deepslate_tiles
setblock 510 192 277 minecraft:cobbled_deepslate
fill 510 192 278 510 194 278 minecraft:deepslate_tiles
setblock 510 192 282 minecraft:cobbled_deepslate
fill 510 192 283 510 195 283 minecraft:deepslate_tiles
setblock 510 192 286 minecraft:deepslate_tiles
setblock 510 192 287 minecraft:cobbled_deepslate
fill 510 192 299 510 192 301 minecraft:deepslate_tiles
setblock 510 192 302 minecraft:cobbled_deepslate
fill 510 192 303 510 195 303 minecraft:deepslate_tiles
setblock 510 192 307 minecraft:cobbled_deepslate
fill 510 192 308 510 195 308 minecraft:deepslate_tiles
setblock 510 192 312 minecraft:cobbled_deepslate
fill 510 192 313 510 195 313 minecraft:deepslate_tiles
setblock 511 192 276 minecraft:cobbled_deepslate
fill 511 192 277 511 195 277 minecraft:deepslate_tiles
setblock 511 192 281 minecraft:cobbled_deepslate
fill 511 192 282 511 195 282 minecraft:deepslate_tiles
setblock 511 192 286 minecraft:cobbled_deepslate
fill 511 192 287 511 195 287 minecraft:deepslate_tiles
setblock 511 192 291 minecraft:cobbled_deepslate
fill 511 192 292 511 192 295 minecraft:deepslate_tiles
setblock 511 192 296 minecraft:cobbled_deepslate
fill 511 192 297 511 195 297 minecraft:deepslate_tiles
setblock 511 192 301 minecraft:cobbled_deepslate
fill 511 192 302 511 195 302 minecraft:deepslate_tiles
setblock 511 192 306 minecraft:cobbled_deepslate
fill 511 192 307 511 195 307 minecraft:deepslate_tiles
setblock 511 192 311 minecraft:cobbled_deepslate
fill 511 192 312 511 195 312 minecraft:deepslate_tiles
setblock 511 192 316 minecraft:cobbled_deepslate
fill 471 193 276 471 194 276 minecraft:deepslate_tiles
setblock 471 193 280 minecraft:cobbled_deepslate
fill 471 193 281 471 193 284 minecraft:deepslate_tiles
setblock 471 193 285 minecraft:cobbled_deepslate
fill 471 193 286 471 193 289 minecraft:deepslate_tiles
setblock 471 193 290 minecraft:cobbled_deepslate
fill 471 193 291 471 196 291 minecraft:deepslate_tiles
setblock 471 193 294 minecraft:deepslate_tiles
setblock 471 193 295 minecraft:cobbled_deepslate
fill 471 193 296 471 196 296 minecraft:deepslate_tiles
setblock 471 193 300 minecraft:cobbled_deepslate
fill 471 193 301 471 196 301 minecraft:deepslate_tiles
setblock 471 193 305 minecraft:cobbled_deepslate
fill 471 193 306 471 196 306 minecraft:deepslate_tiles
setblock 471 193 310 minecraft:cobbled_deepslate
fill 471 193 311 471 196 311 minecraft:deepslate_tiles
setblock 471 193 314 minecraft:deepslate_tiles
setblock 471 193 315 minecraft:cobbled_deepslate
fill 471 193 316 471 196 316 minecraft:deepslate_tiles
setblock 472 193 279 minecraft:cobbled_deepslate
fill 472 193 280 472 194 280 minecraft:deepslate_tiles
setblock 472 193 283 minecraft:deepslate_tiles
setblock 472 193 284 minecraft:cobbled_deepslate
fill 472 193 285 472 196 285 minecraft:deepslate_tiles
setblock 472 193 289 minecraft:cobbled_deepslate
fill 472 193 290 473 195 290 minecraft:deepslate_tiles
setblock 472 193 294 minecraft:cobbled_deepslate
fill 472 193 295 472 196 295 minecraft:deepslate_tiles
setblock 472 193 299 minecraft:cobbled_deepslate
fill 472 193 300 472 196 300 minecraft:deepslate_tiles
setblock 472 193 304 minecraft:cobbled_deepslate
fill 472 193 305 472 196 305 minecraft:deepslate_tiles
setblock 472 193 309 minecraft:cobbled_deepslate
fill 472 193 310 472 196 310 minecraft:deepslate_tiles
setblock 472 193 314 minecraft:cobbled_deepslate
setblock 472 193 315 minecraft:deepslate_tiles
setblock 473 193 278 minecraft:light[level=12]
setblock 473 193 283 minecraft:cobbled_deepslate
fill 473 193 284 473 195 284 minecraft:deepslate_tiles
setblock 473 193 288 minecraft:cobbled_deepslate
fill 473 193 289 473 196 289 minecraft:deepslate_tiles
setblock 473 193 292 minecraft:light[level=12]
setblock 473 193 298 minecraft:cobbled_deepslate
fill 473 193 299 473 194 299 minecraft:deepslate_tiles
setblock 473 193 303 minecraft:cobbled_deepslate
fill 473 193 304 473 196 304 minecraft:deepslate_tiles
setblock 473 193 308 minecraft:cobbled_deepslate
fill 473 193 309 473 196 309 minecraft:deepslate_tiles
setblock 473 193 313 minecraft:light[level=12]
setblock 474 193 302 minecraft:cobbled_deepslate
fill 474 193 303 474 194 303 minecraft:deepslate_tiles
setblock 474 193 307 minecraft:cobbled_deepslate
fill 474 193 308 474 194 308 minecraft:deepslate_tiles
setblock 475 193 317 minecraft:redstone_block
fill 477 193 301 477 196 301 minecraft:white_wool
setblock 480 193 278 minecraft:light[level=12]
setblock 480 193 285 minecraft:light[level=12]
setblock 480 193 292 minecraft:light[level=12]
setblock 480 193 299 minecraft:light[level=12]
setblock 480 193 306 minecraft:light[level=12]
setblock 480 193 313 minecraft:light[level=12]
setblock 487 193 278 minecraft:light[level=12]
setblock 487 193 285 minecraft:light[level=12]
setblock 487 193 292 minecraft:light[level=12]
setblock 487 193 299 minecraft:light[level=12]
setblock 487 193 306 minecraft:light[level=12]
setblock 487 193 313 minecraft:light[level=12]
setblock 489 193 277 minecraft:cobbled_deepslate
fill 489 193 278 490 194 278 minecraft:deepslate_tiles
setblock 490 193 276 minecraft:cobbled_deepslate
fill 490 193 277 490 196 277 minecraft:deepslate_tiles
setblock 490 193 316 minecraft:cobbled_deepslate
fill 491 193 276 491 196 276 minecraft:deepslate_tiles
fill 491 193 316 491 196 316 minecraft:deepslate_tiles
setblock 492 193 279 minecraft:cobbled_deepslate
setblock 493 193 278 minecraft:cobbled_deepslate
setblock 493 193 279 minecraft:deepslate_tiles
setblock 494 193 277 minecraft:cobbled_deepslate
fill 494 193 278 494 194 278 minecraft:deepslate_tiles
setblock 494 193 285 minecraft:light[level=12]
setblock 494 193 292 minecraft:light[level=12]
setblock 494 193 299 minecraft:light[level=12]
setblock 494 193 306 minecraft:light[level=12]
setblock 494 193 313 minecraft:light[level=12]
setblock 495 193 276 minecraft:cobbled_deepslate
fill 495 193 277 495 195 277 minecraft:deepslate_tiles
setblock 495 193 316 minecraft:cobbled_deepslate
fill 496 193 276 496 196 276 minecraft:deepslate_tiles
fill 496 193 316 496 196 316 minecraft:deepslate_tiles
setblock 499 193 277 minecraft:cobbled_deepslate
fill 499 193 308 500 194 308 minecraft:white_wool
setblock 500 193 276 minecraft:cobbled_deepslate
setblock 501 193 276 minecraft:deepslate_tiles
setblock 501 193 278 minecraft:light[level=12]
setblock 501 193 285 minecraft:light[level=12]
setblock 501 193 292 minecraft:light[level=12]
setblock 501 193 299 minecraft:light[level=12]
setblock 501 193 306 minecraft:light[level=12]
setblock 501 193 313 minecraft:light[level=12]
setblock 505 193 276 minecraft:cobbled_deepslate
setblock 505 193 316 minecraft:cobbled_deepslate
fill 506 193 276 506 195 276 minecraft:deepslate_tiles
fill 506 193 316 506 196 316 minecraft:deepslate_tiles
fill 507 193 315 507 196 315 minecraft:deepslate_tiles
setblock 508 193 278 minecraft:light[level=12]
setblock 508 193 285 minecraft:light[level=12]
setblock 508 193 292 minecraft:light[level=12]
setblock 508 193 306 minecraft:light[level=12]
setblock 508 193 313 minecraft:light[level=12]
setblock 509 193 277 minecraft:cobbled_deepslate
setblock 509 193 302 minecraft:cobbled_deepslate
fill 509 193 303 509 196 303 minecraft:deepslate_tiles
setblock 509 193 306 minecraft:deepslate_tiles
setblock 509 193 307 minecraft:cobbled_deepslate
fill 509 193 308 509 196 308 minecraft:deepslate_tiles
setblock 509 193 311 minecraft:deepslate_tiles
setblock 509 193 312 minecraft:cobbled_deepslate
fill 509 193 313 509 196 313 minecraft:deepslate_tiles
setblock 510 193 276 minecraft:cobbled_deepslate
setblock 510 193 277 minecraft:deepslate_tiles
setblock 510 193 281 minecraft:cobbled_deepslate
fill 510 193 282 510 196 282 minecraft:deepslate_tiles
setblock 510 193 286 minecraft:cobbled_deepslate
fill 510 193 287 510 195 288 minecraft:deepslate_tiles
fill 510 193 299 510 193 300 minecraft:deepslate_tiles
setblock 510 193 301 minecraft:cobbled_deepslate
fill 510 193 302 510 196 302 minecraft:deepslate_tiles
setblock 510 193 306 minecraft:cobbled_deepslate
fill 510 193 307 510 196 307 minecraft:deepslate_tiles
setblock 510 193 311 minecraft:cobbled_deepslate
fill 510 193 312 510 196 312 minecraft:deepslate_tiles
setblock 510 193 316 minecraft:cobbled_deepslate
fill 511 193 276 511 196 276 minecraft:deepslate_tiles
setblock 511 193 280 minecraft:cobbled_deepslate
fill 511 193 281 511 196 281 minecraft:deepslate_tiles
setblock 511 193 285 minecraft:cobbled_deepslate
fill 511 193 286 511 196 286 minecraft:deepslate_tiles
fill 511 193 288 511 193 289 minecraft:deepslate_tiles
setblock 511 193 290 minecraft:cobbled_deepslate
fill 511 193 291 511 193 294 minecraft:deepslate_tiles
setblock 511 193 295 minecraft:cobbled_deepslate
fill 511 193 296 511 196 296 minecraft:deepslate_tiles
setblock 511 193 300 minecraft:cobbled_deepslate
fill 511 193 301 511 196 301 minecraft:deepslate_tiles
setblock 511 193 305 minecraft:cobbled_deepslate
fill 511 193 306 511 196 306 minecraft:deepslate_tiles
setblock 511 193 310 minecraft:cobbled_deepslate
fill 511 193 311 511 196 311 minecraft:deepslate_tiles
setblock 511 193 315 minecraft:cobbled_deepslate
fill 511 193 316 511 196 316 minecraft:deepslate_tiles
setblock 512 193 279 minecraft:redstone_block
fill 512 193 280 512 201 280 minecraft:black_concrete
setblock 471 194 279 minecraft:cobbled_deepslate
fill 471 194 280 471 194 283 minecraft:deepslate_tiles
setblock 471 194 284 minecraft:cobbled_deepslate
fill 471 194 285 471 194 288 minecraft:deepslate_tiles
setblock 471 194 289 minecraft:cobbled_deepslate
fill 471 194 290 471 197 290 minecraft:deepslate_tiles
setblock 471 194 293 minecraft:deepslate_tiles
setblock 471 194 294 minecraft:cobbled_deepslate
fill 471 194 295 471 197 295 minecraft:deepslate_tiles
setblock 471 194 299 minecraft:cobbled_deepslate
fill 471 194 300 471 197 300 minecraft:deepslate_tiles
setblock 471 194 304 minecraft:cobbled_deepslate
fill 471 194 305 471 197 305 minecraft:deepslate_tiles
setblock 471 194 309 minecraft:cobbled_deepslate
fill 471 194 310 471 197 310 minecraft:deepslate_tiles
setblock 471 194 314 minecraft:cobbled_deepslate
fill 471 194 315 471 197 315 minecraft:deepslate_tiles
setblock 472 194 283 minecraft:cobbled_deepslate
fill 472 194 284 472 197 284 minecraft:deepslate_tiles
setblock 472 194 287 minecraft:deepslate_tiles
setblock 472 194 288 minecraft:cobbled_deepslate
fill 472 194 289 472 197 289 minecraft:deepslate_tiles
setblock 472 194 293 minecraft:cobbled_deepslate
fill 472 194 294 472 197 294 minecraft:deepslate_tiles
setblock 472 194 298 minecraft:cobbled_deepslate
fill 472 194 299 472 197 299 minecraft:deepslate_tiles
setblock 472 194 303 minecraft:cobbled_deepslate
fill 472 194 304 472 197 304 minecraft:deepslate_tiles
setblock 472 194 308 minecraft:cobbled_deepslate
fill 472 194 309 472 197 309 minecraft:deepslate_tiles
setblock 472 194 313 minecraft:cobbled_deepslate
fill 472 194 314 472 195 314 minecraft:deepslate_tiles
setblock 473 194 283 minecraft:deepslate_tiles
setblock 473 194 287 minecraft:cobbled_deepslate
fill 473 194 288 473 197 288 minecraft:deepslate_tiles
setblock 473 194 291 minecraft:deepslate_tiles
setblock 473 194 298 minecraft:deepslate_tiles
setblock 473 194 302 minecraft:cobbled_deepslate
fill 473 194 303 473 196 303 minecraft:deepslate_tiles
setblock 473 194 307 minecraft:cobbled_deepslate
fill 473 194 308 473 197 308 minecraft:deepslate_tiles
setblock 474 194 302 minecraft:deepslate_tiles
setblock 474 194 306 minecraft:cobbled_deepslate
setblock 474 194 307 minecraft:deepslate_tiles
setblock 474 194 316 minecraft:cobbled_deepslate
fill 475 194 317 475 201 317 minecraft:black_concrete
setblock 488 194 277 minecraft:cobbled_deepslate
setblock 489 194 276 minecraft:cobbled_deepslate
fill 489 194 277 489 197 277 minecraft:deepslate_tiles
setblock 489 194 316 minecraft:cobbled_deepslate
fill 490 194 276 490 197 276 minecraft:deepslate_tiles
fill 490 194 316 490 197 316 minecraft:deepslate_tiles
setblock 492 194 278 minecraft:cobbled_deepslate
setblock 493 194 277 minecraft:cobbled_deepslate
fill 493 194 278 493 195 278 minecraft:deepslate_tiles
setblock 494 194 276 minecraft:cobbled_deepslate
fill 494 194 277 494 196 277 minecraft:deepslate_tiles
setblock 494 194 316 minecraft:cobbled_deepslate
fill 495 194 276 495 197 276 minecraft:deepslate_tiles
fill 495 194 316 495 197 316 minecraft:deepslate_tiles
fill 498 194 290 498 195 291 minecraft:white_wool
setblock 499 194 276 minecraft:cobbled_deepslate
setblock 500 194 276 minecraft:deepslate_tiles
setblock 504 194 316 minecraft:cobbled_deepslate
setblock 505 194 276 minecraft:deepslate_tiles
fill 505 194 316 505 197 316 minecraft:deepslate_tiles
setblock 508 194 306 minecraft:deepslate_tiles
setblock 508 194 307 minecraft:cobbled_deepslate
fill 508 194 308 508 196 309 minecraft:deepslate_tiles
setblock 509 194 276 minecraft:cobbled_deepslate
setblock 509 194 302 minecraft:deepslate_tiles
setblock 509 194 306 minecraft:cobbled_deepslate
fill 509 194 307 509 197 307 minecraft:deepslate_tiles
setblock 509 194 311 minecraft:cobbled_deepslate
fill 509 194 312 509 197 312 minecraft:deepslate_tiles
fill 509 194 314 509 195 314 minecraft:deepslate_tiles
setblock 509 194 316 minecraft:cobbled_deepslate
fill 510 194 276 510 196 276 minecraft:deepslate_tiles
setblock 510 194 280 minecraft:cobbled_deepslate
fill 510 194 281 510 195 281 minecraft:deepslate_tiles
setblock 510 194 285 minecraft:cobbled_deepslate
fill 510 194 286 510 197 286 minecraft:deepslate_tiles
setblock 510 194 289 minecraft:deepslate_tiles
setblock 510 194 299 minecraft:deepslate_tiles
setblock 510 194 300 minecraft:cobbled_deepslate
fill 510 194 301 510 197 301 minecraft:deepslate_tiles
setblock 510 194 305 minecraft:cobbled_deepslate
fill 510 194 306 510 197 306 minecraft:deepslate_tiles
setblock 510 194 310 minecraft:cobbled_deepslate
fill 510 194 311 510 197 311 minecraft:deepslate_tiles
setblock 510 194 315 minecraft:cobbled_deepslate
fill 510 194 316 510 197 316 minecraft:deepslate_tiles
setblock 511 194 279 minecraft:cobbled_deepslate
fill 511 194 280 511 196 280 minecraft:deepslate_tiles
setblock 511 194 284 minecraft:cobbled_deepslate
fill 511 194 285 511 197 285 minecraft:deepslate_tiles
setblock 511 194 288 minecraft:deepslate_tiles
setblock 511 194 289 minecraft:cobbled_deepslate
fill 511 194 290 511 194 293 minecraft:deepslate_tiles
setblock 511 194 294 minecraft:cobbled_deepslate
fill 511 194 295 511 197 295 minecraft:deepslate_tiles
setblock 511 194 299 minecraft:cobbled_deepslate
fill 511 194 300 511 197 300 minecraft:deepslate_tiles
setblock 511 194 304 minecraft:cobbled_deepslate
fill 511 194 305 511 197 305 minecraft:deepslate_tiles
setblock 511 194 309 minecraft:cobbled_deepslate
fill 511 194 310 511 197 310 minecraft:deepslate_tiles
setblock 511 194 314 minecraft:cobbled_deepslate
fill 511 194 315 511 197 315 minecraft:deepslate_tiles
fill 512 194 279 512 201 279 minecraft:black_concrete
setblock 471 195 278 minecraft:cobbled_deepslate
fill 471 195 279 471 195 282 minecraft:deepslate_tiles
setblock 471 195 283 minecraft:cobbled_deepslate
fill 471 195 284 471 195 287 minecraft:deepslate_tiles
setblock 471 195 288 minecraft:cobbled_deepslate
fill 471 195 289 471 198 289 minecraft:deepslate_tiles
setblock 471 195 293 minecraft:cobbled_deepslate
fill 471 195 294 471 198 294 minecraft:deepslate_tiles
setblock 471 195 298 minecraft:cobbled_deepslate
fill 471 195 299 471 198 299 minecraft:deepslate_tiles
setblock 471 195 303 minecraft:cobbled_deepslate
fill 471 195 304 471 198 304 minecraft:deepslate_tiles
setblock 471 195 308 minecraft:cobbled_deepslate
fill 471 195 309 471 198 309 minecraft:deepslate_tiles
setblock 471 195 313 minecraft:cobbled_deepslate
fill 471 195 314 471 198 314 minecraft:deepslate_tiles
setblock 472 195 282 minecraft:cobbled_deepslate
fill 472 195 283 472 197 283 minecraft:deepslate_tiles
setblock 472 195 287 minecraft:cobbled_deepslate
fill 472 195 288 472 198 288 minecraft:deepslate_tiles
setblock 472 195 292 minecraft:cobbled_deepslate
fill 472 195 293 472 198 293 minecraft:deepslate_tiles
setblock 472 195 297 minecraft:cobbled_deepslate
fill 472 195 298 472 197 298 minecraft:deepslate_tiles
setblock 472 195 302 minecraft:cobbled_deepslate
fill 472 195 303 472 198 303 minecraft:deepslate_tiles
setblock 472 195 307 minecraft:cobbled_deepslate
fill 472 195 308 472 198 308 minecraft:deepslate_tiles
setblock 472 195 312 minecraft:cobbled_deepslate
fill 472 195 313 472 198 313 minecraft:deepslate_tiles
setblock 473 195 286 minecraft:cobbled_deepslate
fill 473 195 287 473 197 287 minecraft:deepslate_tiles
setblock 473 195 291 minecraft:cobbled_deepslate
setblock 473 195 301 minecraft:cobbled_deepslate
fill 473 195 302 473 196 302 minecraft:deepslate_tiles
setblock 473 195 306 minecraft:cobbled_deepslate
fill 473 195 307 473 197 307 minecraft:deepslate_tiles
setblock 473 195 311 minecraft:cobbled_deepslate
setblock 473 195 316 minecraft:cobbled_deepslate
setblock 474 195 306 minecraft:deepslate_tiles
setblock 488 195 276 minecraft:cobbled_deepslate
setblock 488 195 277 minecraft:deepslate_tiles
fill 489 195 276 489 198 276 minecraft:deepslate_tiles
fill 489 195 316 489 198 316 minecraft:deepslate_tiles
setblock 490 195 278 minecraft:deepslate_tiles
setblock 491 195 278 minecraft:cobbled_deepslate
setblock 492 195 277 minecraft:cobbled_deepslate
setblock 492 195 278 minecraft:deepslate_tiles
setblock 493 195 276 minecraft:cobbled_deepslate
fill 493 195 277 493 196 277 minecraft:deepslate_tiles
setblock 493 195 316 minecraft:cobbled_deepslate
fill 494 195 276 494 198 276 minecraft:deepslate_tiles
fill 494 195 316 494 198 316 minecraft:deepslate_tiles
setblock 498 195 276 minecraft:cobbled_deepslate
setblock 502 195 317 minecraft:redstone_block
fill 504 195 316 504 198 316 minecraft:deepslate_tiles
fill 506 195 315 506 197 315 minecraft:deepslate_tiles
setblock 508 195 276 minecraft:cobbled_deepslate
setblock 508 195 306 minecraft:cobbled_deepslate
fill 508 195 307 508 197 307 minecraft:deepslate_tiles
setblock 508 195 310 minecraft:deepslate_tiles
setblock 508 195 316 minecraft:cobbled_deepslate
fill 509 195 276 509 196 276 minecraft:deepslate_tiles
setblock 509 195 305 minecraft:cobbled_deepslate
fill 509 195 306 509 198 306 minecraft:deepslate_tiles
setblock 509 195 310 minecraft:cobbled_deepslate
fill 509 195 311 509 198 311 minecraft:deepslate_tiles
setblock 509 195 315 minecraft:cobbled_deepslate
fill 509 195 316 509 198 316 minecraft:deepslate_tiles
setblock 510 195 280 minecraft:deepslate_tiles
setblock 510 195 284 minecraft:cobbled_deepslate
fill 510 195 285 510 197 285 minecraft:deepslate_tiles
setblock 510 195 289 minecraft:cobbled_deepslate
fill 510 195 290 511 197 290 minecraft:deepslate_tiles
fill 510 195 300 510 196 300 minecraft:deepslate_tiles
setblock 510 195 304 minecraft:cobbled_deepslate
fill 510 195 305 510 198 305 minecraft:deepslate_tiles
setblock 510 195 309 minecraft:cobbled_deepslate
fill 510 195 310 510 198 310 minecraft:deepslate_tiles
setblock 510 195 314 minecraft:cobbled_deepslate
fill 510 195 315 510 198 315 minecraft:deepslate_tiles
setblock 511 195 278 minecraft:cobbled_deepslate
fill 511 195 279 511 196 279 minecraft:deepslate_tiles
setblock 511 195 283 minecraft:cobbled_deepslate
fill 511 195 284 511 198 284 minecraft:deepslate_tiles
setblock 511 195 288 minecraft:cobbled_deepslate
fill 511 195 289 511 198 289 minecraft:deepslate_tiles
fill 511 195 291 511 195 292 minecraft:deepslate_tiles
setblock 511 195 293 minecraft:cobbled_deepslate
fill 511 195 294 511 198 294 minecraft:deepslate_tiles
setblock 511 195 298 minecraft:cobbled_deepslate
fill 511 195 299 511 198 299 minecraft:deepslate_tiles
setblock 511 195 303 minecraft:cobbled_deepslate
fill 511 195 304 511 198 304 minecraft:deepslate_tiles
setblock 511 195 308 minecraft:cobbled_deepslate
fill 511 195 309 511 198 309 minecraft:deepslate_tiles
setblock 511 195 313 minecraft:cobbled_deepslate
fill 511 195 314 511 198 314 minecraft:deepslate_tiles
fill 471 196 280 471 196 281 minecraft:deepslate_tiles
setblock 471 196 282 minecraft:cobbled_deepslate
fill 471 196 283 471 196 286 minecraft:deepslate_tiles
setblock 471 196 287 minecraft:cobbled_deepslate
fill 471 196 288 471 199 288 minecraft:deepslate_tiles
setblock 471 196 292 minecraft:cobbled_deepslate
fill 471 196 293 471 199 293 minecraft:deepslate_tiles
setblock 471 196 297 minecraft:cobbled_deepslate
fill 471 196 298 471 199 298 minecraft:deepslate_tiles
setblock 471 196 302 minecraft:cobbled_deepslate
fill 471 196 303 471 199 303 minecraft:deepslate_tiles
setblock 471 196 307 minecraft:cobbled_deepslate
fill 471 196 308 471 199 308 minecraft:deepslate_tiles
setblock 471 196 312 minecraft:cobbled_deepslate
fill 471 196 313 471 199 313 minecraft:deepslate_tiles
setblock 472 196 282 minecraft:deepslate_tiles
setblock 472 196 286 minecraft:cobbled_deepslate
fill 472 196 287 472 199 287 minecraft:deepslate_tiles
setblock 472 196 290 minecraft:deepslate_tiles
setblock 472 196 291 minecraft:cobbled_deepslate
fill 472 196 292 472 199 292 minecraft:deepslate_tiles
setblock 472 196 296 minecraft:cobbled_deepslate
fill 472 196 297 472 197 297 minecraft:deepslate_tiles
setblock 472 196 301 minecraft:cobbled_deepslate
fill 472 196 302 472 198 302 minecraft:deepslate_tiles
setblock 472 196 306 minecraft:cobbled_deepslate
fill 472 196 307 472 199 307 minecraft:deepslate_tiles
setblock 472 196 311 minecraft:cobbled_deepslate
fill 472 196 312 472 199 312 minecraft:deepslate_tiles
setblock 472 196 316 minecraft:cobbled_deepslate
setblock 473 196 285 minecraft:cobbled_deepslate
setblock 473 196 286 minecraft:deepslate_tiles
setblock 473 196 290 minecraft:cobbled_deepslate
setblock 473 196 291 minecraft:deepslate_tiles
setblock 473 196 305 minecraft:cobbled_deepslate
fill 473 196 306 473 197 306 minecraft:deepslate_tiles
setblock 473 196 310 minecraft:cobbled_deepslate
setblock 487 196 276 minecraft:cobbled_deepslate
fill 488 196 276 488 199 276 minecraft:deepslate_tiles
setblock 490 196 317 minecraft:redstone_block
setblock 491 196 277 minecraft:cobbled_deepslate
setblock 492 196 276 minecraft:cobbled_deepslate
fill 492 196 277 492 197 277 minecraft:deepslate_tiles
setblock 492 196 316 minecraft:cobbled_deepslate
fill 493 196 276 493 199 276 minecraft:deepslate_tiles
fill 493 196 316 493 199 316 minecraft:deepslate_tiles
setblock 497 196 276 minecraft:cobbled_deepslate
fill 502 196 317 502 201 317 minecraft:black_concrete
fill 503 196 316 503 199 316 minecraft:deepslate_tiles
setblock 507 196 276 minecraft:cobbled_deepslate
setblock 507 196 316 minecraft:cobbled_deepslate
setblock 508 196 276 minecraft:deepslate_tiles
setblock 508 196 310 minecraft:cobbled_deepslate
setblock 508 196 314 minecraft:deepslate_tiles
setblock 508 196 315 minecraft:cobbled_deepslate
fill 508 196 316 508 199 316 minecraft:deepslate_tiles
setblock 509 196 304 minecraft:cobbled_deepslate
fill 509 196 305 509 199 305 minecraft:deepslate_tiles
setblock 509 196 309 minecraft:cobbled_deepslate
fill 509 196 310 509 199 310 minecraft:deepslate_tiles
setblock 509 196 314 minecraft:cobbled_deepslate
fill 509 196 315 509 199 315 minecraft:deepslate_tiles
setblock 510 196 283 minecraft:cobbled_deepslate
fill 510 196 284 510 197 284 minecraft:deepslate_tiles
setblock 510 196 287 minecraft:deepslate_tiles
setblock 510 196 288 minecraft:cobbled_deepslate
fill 510 196 289 510 199 289 minecraft:deepslate_tiles
setblock 510 196 303 minecraft:cobbled_deepslate
fill 510 196 304 510 199 304 minecraft:deepslate_tiles
setblock 510 196 308 minecraft:cobbled_deepslate
fill 510 196 309 510 199 309 minecraft:deepslate_tiles
setblock 510 196 313 minecraft:cobbled_deepslate
fill 510 196 314 510 199 314 minecraft:deepslate_tiles
setblock 511 196 277 minecraft:cobbled_deepslate
setblock 511 196 278 minecraft:deepslate_tiles
setblock 511 196 282 minecraft:cobbled_deepslate
fill 511 196 283 511 198 283 minecraft:deepslate_tiles
setblock 511 196 287 minecraft:cobbled_deepslate
fill 511 196 288 511 199 288 minecraft:deepslate_tiles
setblock 511 196 291 minecraft:deepslate_tiles
setblock 511 196 292 minecraft:cobbled_deepslate
fill 511 196 293 511 199 293 minecraft:deepslate_tiles
setblock 511 196 297 minecraft:cobbled_deepslate
fill 511 196 298 511 199 298 minecraft:deepslate_tiles
setblock 511 196 302 minecraft:cobbled_deepslate
fill 511 196 303 511 199 303 minecraft:deepslate_tiles
setblock 511 196 307 minecraft:cobbled_deepslate
fill 511 196 308 511 199 308 minecraft:deepslate_tiles
setblock 511 196 312 minecraft:cobbled_deepslate
fill 511 196 313 511 199 313 minecraft:deepslate_tiles
setblock 471 197 281 minecraft:cobbled_deepslate
fill 471 197 282 471 197 285 minecraft:deepslate_tiles
setblock 471 197 286 minecraft:cobbled_deepslate
fill 471 197 287 471 200 287 minecraft:deepslate_tiles
setblock 471 197 291 minecraft:cobbled_deepslate
fill 471 197 292 471 200 292 minecraft:deepslate_tiles
setblock 471 197 296 minecraft:cobbled_deepslate
fill 471 197 297 471 200 297 minecraft:deepslate_tiles
setblock 471 197 301 minecraft:cobbled_deepslate
fill 471 197 302 471 200 302 minecraft:deepslate_tiles
setblock 471 197 306 minecraft:cobbled_deepslate
fill 471 197 307 471 200 307 minecraft:deepslate_tiles
setblock 471 197 311 minecraft:cobbled_deepslate
fill 471 197 312 471 200 312 minecraft:deepslate_tiles
setblock 471 197 316 minecraft:cobbled_deepslate
setblock 472 197 285 minecraft:cobbled_deepslate
fill 472 197 286 472 200 286 minecraft:deepslate_tiles
setblock 472 197 290 minecraft:cobbled_deepslate
fill 472 197 291 472 200 291 minecraft:deepslate_tiles
setblock 472 197 295 minecraft:cobbled_deepslate
fill 472 197 296 472 200 296 minecraft:deepslate_tiles
setblock 472 197 300 minecraft:cobbled_deepslate
fill 472 197 301 472 198 301 minecraft:deepslate_tiles
setblock 472 197 305 minecraft:cobbled_deepslate
fill 472 197 306 472 200 306 minecraft:deepslate_tiles
setblock 472 197 310 minecraft:cobbled_deepslate
fill 472 197 311 472 200 311 minecraft:deepslate_tiles
setblock 473 197 278 minecraft:light[level=13]
setblock 473 197 286 minecraft:light[level=13]
setblock 473 197 289 minecraft:cobbled_deepslate
fill 473 197 290 473 198 290 minecraft:deepslate_tiles
setblock 473 197 294 minecraft:light[level=13]
setblock 473 197 302 minecraft:light[level=13]
setblock 473 197 305 minecraft:deepslate_tiles
setblock 473 197 309 minecraft:cobbled_deepslate
setblock 473 197 310 minecraft:light[level=13]
setblock 481 197 278 minecraft:light[level=13]
setblock 481 197 286 minecraft:light[level=13]
setblock 481 197 294 minecraft:light[level=13]
setblock 481 197 302 minecraft:light[level=13]
setblock 481 197 310 minecraft:light[level=13]
fill 487 197 276 487 200 276 minecraft:deepslate_tiles
fill 488 197 316 488 199 316 minecraft:deepslate_tiles
setblock 489 197 278 minecraft:light[level=13]
setblock 489 197 286 minecraft:light[level=13]
setblock 489 197 294 minecraft:light[level=13]
setblock 489 197 302 minecraft:light[level=13]
setblock 489 197 310 minecraft:light[level=13]
setblock 490 197 277 minecraft:cobbled_deepslate
fill 490 197 317 490 198 317 minecraft:black_concrete
setblock 491 197 276 minecraft:cobbled_deepslate
fill 491 197 277 491 198 277 minecraft:deepslate_tiles
setblock 491 197 316 minecraft:cobbled_deepslate
fill 492 197 276 492 200 276 minecraft:deepslate_tiles
fill 492 197 316 492 200 316 minecraft:deepslate_tiles
setblock 497 197 278 minecraft:light[level=13]
setblock 497 197 286 minecraft:light[level=13]
setblock 497 197 294 minecraft:light[level=13]
setblock 497 197 302 minecraft:light[level=13]
setblock 497 197 310 minecraft:light[level=13]
setblock 505 197 278 minecraft:light[level=13]
setblock 505 197 286 minecraft:light[level=13]
setblock 505 197 294 minecraft:light[level=13]
setblock 505 197 302 minecraft:light[level=13]
setblock 505 197 310 minecraft:light[level=13]
fill 505 197 315 505 198 315 minecraft:deepslate_tiles
setblock 506 197 316 minecraft:cobbled_deepslate
setblock 507 197 315 minecraft:cobbled_deepslate
fill 507 197 316 507 200 316 minecraft:deepslate_tiles
setblock 508 197 308 minecraft:deepslate_tiles
setblock 508 197 309 minecraft:cobbled_deepslate
fill 508 197 310 508 199 311 minecraft:deepslate_tiles
setblock 508 197 314 minecraft:cobbled_deepslate
fill 508 197 315 508 200 315 minecraft:deepslate_tiles
fill 509 197 304 509 198 304 minecraft:deepslate_tiles
setblock 509 197 308 minecraft:cobbled_deepslate
fill 509 197 309 509 200 309 minecraft:deepslate_tiles
setblock 509 197 313 minecraft:cobbled_deepslate
fill 509 197 314 509 200 314 minecraft:deepslate_tiles
setblock 510 197 287 minecraft:cobbled_deepslate
fill 510 197 288 510 200 288 minecraft:deepslate_tiles
setblock 510 197 302 minecraft:cobbled_deepslate
fill 510 197 303 510 200 303 minecraft:deepslate_tiles
setblock 510 197 307 minecraft:cobbled_deepslate
fill 510 197 308 510 200 308 minecraft:deepslate_tiles
setblock 510 197 312 minecraft:cobbled_deepslate
fill 510 197 313 510 200 313 minecraft:deepslate_tiles
setblock 511 197 281 minecraft:cobbled_deepslate
setblock 511 197 282 minecraft:deepslate_tiles
setblock 511 197 286 minecraft:cobbled_deepslate
fill 511 197 287 511 200 287 minecraft:deepslate_tiles
setblock 511 197 291 minecraft:cobbled_deepslate
fill 511 197 292 511 200 292 minecraft:deepslate_tiles
setblock 511 197 296 minecraft:cobbled_deepslate
fill 511 197 297 511 200 297 minecraft:deepslate_tiles
setblock 511 197 301 minecraft:cobbled_deepslate
fill 511 197 302 511 200 302 minecraft:deepslate_tiles
setblock 511 197 306 minecraft:cobbled_deepslate
fill 511 197 307 511 200 307 minecraft:deepslate_tiles
setblock 511 197 311 minecraft:cobbled_deepslate
fill 511 197 312 511 200 312 minecraft:deepslate_tiles
setblock 511 197 316 minecraft:cobbled_deepslate
setblock 470 198 276 minecraft:deepslate_tiles
setblock 470 198 292 minecraft:deepslate_tiles
setblock 470 198 308 minecraft:deepslate_tiles
setblock 470 198 310 minecraft:deepslate_tiles
setblock 471 198 275 minecraft:deepslate_tiles
fill 471 198 282 471 198 284 minecraft:deepslate_tiles
setblock 471 198 285 minecraft:cobbled_deepslate
fill 471 198 286 471 201 286 minecraft:deepslate_tiles
setblock 471 198 290 minecraft:cobbled_deepslate
fill 471 198 291 471 201 291 minecraft:deepslate_tiles
setblock 471 198 295 minecraft:cobbled_deepslate
fill 471 198 296 471 201 296 minecraft:deepslate_tiles
setblock 471 198 300 minecraft:cobbled_deepslate
fill 471 198 301 471 201 301 minecraft:deepslate_tiles
setblock 471 198 305 minecraft:cobbled_deepslate
fill 471 198 306 471 201 306 minecraft:deepslate_tiles
setblock 471 198 310 minecraft:cobbled_deepslate
fill 471 198 311 471 201 311 minecraft:deepslate_tiles
setblock 471 198 315 minecraft:cobbled_deepslate
fill 471 198 316 471 201 316 minecraft:deepslate_tiles
setblock 472 198 284 minecraft:cobbled_deepslate
fill 472 198 285 472 199 285 minecraft:deepslate_tiles
setblock 472 198 289 minecraft:cobbled_deepslate
fill 472 198 290 472 201 290 minecraft:deepslate_tiles
setblock 472 198 294 minecraft:cobbled_deepslate
fill 472 198 295 472 201 295 minecraft:deepslate_tiles
setblock 472 198 304 minecraft:cobbled_deepslate
fill 472 198 305 472 199 305 minecraft:deepslate_tiles
setblock 472 198 309 minecraft:cobbled_deepslate
fill 472 198 310 472 201 310 minecraft:deepslate_tiles
setblock 473 198 289 minecraft:deepslate_tiles
setblock 476 198 275 minecraft:deepslate_tiles
fill 477 198 275 477 199 275 minecraft:black_concrete
setblock 478 198 275 minecraft:deepslate_tiles
fill 478 198 317 478 201 317 minecraft:black_concrete
fill 479 198 317 480 198 317 minecraft:deepslate_tiles
fill 482 198 298 483 199 299 minecraft:white_wool
fill 486 198 276 486 201 276 minecraft:deepslate_tiles
fill 486 198 317 487 198 317 minecraft:deepslate_tiles
fill 487 198 280 487 206 280 minecraft:black_concrete
fill 487 198 316 487 200 316 minecraft:deepslate_tiles
setblock 488 198 317 minecraft:redstone_block
setblock 489 198 277 minecraft:cobbled_deepslate
setblock 490 198 276 minecraft:cobbled_deepslate
fill 490 198 277 490 201 277 minecraft:deepslate_tiles
setblock 490 198 316 minecraft:cobbled_deepslate
fill 491 198 276 491 201 276 minecraft:deepslate_tiles
fill 491 198 316 491 198 317 minecraft:deepslate_tiles
setblock 493 198 317 minecraft:deepslate_tiles
setblock 494 198 275 minecraft:deepslate_tiles
fill 495 198 275 495 201 275 minecraft:black_concrete
setblock 495 198 316 minecraft:cobbled_deepslate
fill 497 198 275 500 198 275 minecraft:black_concrete
setblock 498 198 317 minecraft:deepslate_tiles
fill 500 198 317 500 199 317 minecraft:deepslate_tiles
setblock 501 198 275 minecraft:deepslate_tiles
fill 502 198 275 504 201 275 minecraft:black_concrete
fill 502 198 316 502 200 316 minecraft:deepslate_tiles
fill 504 198 317 504 199 317 minecraft:deepslate_tiles
setblock 505 198 316 minecraft:cobbled_deepslate
setblock 506 198 315 minecraft:cobbled_deepslate
fill 506 198 316 506 201 316 minecraft:deepslate_tiles
setblock 507 198 314 minecraft:cobbled_deepslate
fill 507 198 315 507 201 315 minecraft:deepslate_tiles
setblock 508 198 308 minecraft:cobbled_deepslate
fill 508 198 309 508 201 309 minecraft:deepslate_tiles
fill 508 198 314 508 201 314 minecraft:deepslate_tiles
fill 509 198 275 509 201 275 minecraft:black_concrete
setblock 509 198 307 minecraft:cobbled_deepslate
fill 509 198 308 509 201 308 minecraft:deepslate_tiles
setblock 509 198 312 minecraft:cobbled_deepslate
fill 509 198 313 509 201 313 minecraft:deepslate_tiles
setblock 510 198 275 minecraft:deepslate_tiles
setblock 510 198 286 minecraft:cobbled_deepslate
fill 510 198 287 510 199 287 minecraft:deepslate_tiles
setblock 510 198 290 minecraft:deepslate_tiles
setblock 510 198 291 minecraft:cobbled_deepslate
fill 510 198 302 510 199 302 minecraft:deepslate_tiles
setblock 510 198 306 minecraft:cobbled_deepslate
fill 510 198 307 510 201 307 minecraft:deepslate_tiles
setblock 510 198 311 minecraft:cobbled_deepslate
fill 510 198 312 510 201 312 minecraft:deepslate_tiles
setblock 510 198 316 minecraft:cobbled_deepslate
fill 511 198 275 512 201 275 minecraft:black_concrete
setblock 511 198 285 minecraft:cobbled_deepslate
fill 511 198 286 511 201 286 minecraft:deepslate_tiles
setblock 511 198 290 minecraft:cobbled_deepslate
fill 511 198 291 511 201 291 minecraft:deepslate_tiles
setblock 511 198 295 minecraft:cobbled_deepslate
fill 511 198 296 511 201 296 minecraft:deepslate_tiles
setblock 511 198 300 minecraft:cobbled_deepslate
fill 511 198 301 511 201 301 minecraft:deepslate_tiles
setblock 511 198 305 minecraft:cobbled_deepslate
fill 511 198 306 512 198 306 minecraft:deepslate_tiles
setblock 511 198 310 minecraft:cobbled_deepslate
fill 511 198 311 512 198 311 minecraft:deepslate_tiles
setblock 511 198 315 minecraft:cobbled_deepslate
fill 511 198 316 511 201 316 minecraft:deepslate_tiles
fill 512 198 281 512 198 283 minecraft:black_concrete
setblock 512 198 284 minecraft:deepslate_tiles
setblock 512 198 303 minecraft:deepslate_tiles
fill 512 198 308 512 199 308 minecraft:black_concrete
setblock 512 198 309 minecraft:deepslate_tiles
fill 512 198 312 512 201 312 minecraft:black_concrete
fill 470 199 276 470 201 276 minecraft:black_concrete
setblock 470 199 291 minecraft:deepslate_tiles
fill 470 199 292 470 201 292 minecraft:black_concrete
setblock 470 199 294 minecraft:deepslate_tiles
setblock 470 199 305 minecraft:white_wool
fill 470 199 308 470 201 308 minecraft:black_concrete
fill 470 199 310 470 201 310 minecraft:black_concrete
fill 470 199 311 470 199 312 minecraft:deepslate_tiles
setblock 471 199 275 minecraft:black_concrete
setblock 471 199 283 minecraft:deepslate_tiles
setblock 471 199 284 minecraft:cobbled_deepslate
fill 471 199 285 471 202 285 minecraft:deepslate_tiles
setblock 471 199 289 minecraft:cobbled_deepslate
fill 471 199 290 471 202 290 minecraft:deepslate_tiles
setblock 471 199 294 minecraft:cobbled_deepslate
fill 471 199 295 471 202 295 minecraft:deepslate_tiles
setblock 471 199 299 minecraft:cobbled_deepslate
fill 471 199 300 471 202 300 minecraft:deepslate_tiles
setblock 471 199 304 minecraft:cobbled_deepslate
fill 471 199 305 471 202 305 minecraft:deepslate_tiles
setblock 471 199 309 minecraft:cobbled_deepslate
fill 471 199 310 471 202 310 minecraft:deepslate_tiles
setblock 471 199 314 minecraft:cobbled_deepslate
fill 471 199 315 471 202 315 minecraft:deepslate_tiles
setblock 471 199 317 minecraft:deepslate_tiles
setblock 472 199 275 minecraft:deepslate_tiles
setblock 472 199 288 minecraft:cobbled_deepslate
fill 472 199 289 472 202 289 minecraft:deepslate_tiles
setblock 472 199 293 minecraft:cobbled_deepslate
fill 472 199 294 472 202 294 minecraft:deepslate_tiles
setblock 472 199 304 minecraft:deepslate_tiles
setblock 472 199 308 minecraft:cobbled_deepslate
fill 472 199 309 472 201 309 minecraft:deepslate_tiles
fill 472 199 317 472 201 317 minecraft:black_concrete
setblock 473 199 275 minecraft:redstone_block
setblock 473 199 278 minecraft:light[level=12]
setblock 473 199 285 minecraft:light[level=12]
setblock 473 199 292 minecraft:light[level=12]
setblock 473 199 299 minecraft:light[level=12]
setblock 473 199 306 minecraft:light[level=12]
setblock 473 199 313 minecraft:light[level=12]
fill 476 199 275 476 201 275 minecraft:black_concrete
fill 478 199 275 478 201 275 minecraft:black_concrete
setblock 479 199 317 minecraft:deepslate_tiles
setblock 480 199 278 minecraft:light[level=12]
setblock 480 199 285 minecraft:light[level=12]
setblock 480 199 292 minecraft:light[level=12]
setblock 480 199 299 minecraft:light[level=12]
setblock 480 199 306 minecraft:light[level=12]
setblock 480 199 313 minecraft:light[level=12]
fill 480 199 317 480 201 317 minecraft:black_concrete
fill 482 199 275 483 201 275 minecraft:black_concrete
fill 484 199 275 484 200 275 minecraft:deepslate_tiles
fill 486 199 316 486 201 316 minecraft:deepslate_tiles
fill 486 199 317 488 201 317 minecraft:black_concrete
setblock 487 199 278 minecraft:light[level=12]
setblock 487 199 285 minecraft:light[level=12]
setblock 487 199 292 minecraft:light[level=12]
setblock 487 199 299 minecraft:light[level=12]
setblock 487 199 306 minecraft:light[level=12]
setblock 487 199 313 minecraft:light[level=12]
setblock 489 199 276 minecraft:cobbled_deepslate
fill 489 199 277 489 202 277 minecraft:deepslate_tiles
setblock 489 199 315 minecraft:deepslate_tiles
setblock 489 199 316 minecraft:cobbled_deepslate
fill 490 199 276 490 202 276 minecraft:deepslate_tiles
setblock 490 199 315 minecraft:cobbled_deepslate
fill 490 199 316 490 200 317 minecraft:deepslate_tiles
fill 491 199 315 491 201 316 minecraft:deepslate_tiles
fill 491 199 317 491 201 317 minecraft:black_concrete
fill 493 199 317 493 201 317 minecraft:black_concrete
fill 494 199 275 494 201 275 minecraft:black_concrete
setblock 494 199 276 minecraft:cobbled_deepslate
setblock 494 199 278 minecraft:light[level=12]
setblock 494 199 285 minecraft:light[level=12]
setblock 494 199 292 minecraft:light[level=12]
setblock 494 199 299 minecraft:light[level=12]
setblock 494 199 306 minecraft:light[level=12]
setblock 494 199 313 minecraft:light[level=12]
setblock 494 199 316 minecraft:cobbled_deepslate
setblock 494 199 317 minecraft:deepslate_tiles
fill 495 199 316 496 201 316 minecraft:deepslate_tiles
setblock 496 199 317 minecraft:deepslate_tiles
setblock 497 199 275 minecraft:deepslate_tiles
fill 498 199 275 501 199 275 minecraft:black_concrete
fill 498 199 317 498 201 317 minecraft:black_concrete
setblock 501 199 278 minecraft:light[level=12]
setblock 501 199 285 minecraft:light[level=12]
setblock 501 199 292 minecraft:light[level=12]
setblock 501 199 299 minecraft:light[level=12]
setblock 501 199 306 minecraft:light[level=12]
setblock 501 199 313 minecraft:light[level=12]
fill 501 199 316 501 200 317 minecraft:deepslate_tiles
setblock 503 199 276 minecraft:white_wool
fill 503 199 289 503 202 290 minecraft:white_terracotta
setblock 504 199 277 minecraft:white_wool
fill 504 199 290 504 202 290 minecraft:white_terracotta
setblock 504 199 315 minecraft:deepslate_tiles
setblock 504 199 316 minecraft:cobbled_deepslate
setblock 505 199 275 minecraft:deepslate_tiles
setblock 505 199 278 minecraft:white_wool
setblock 505 199 315 minecraft:cobbled_deepslate
fill 505 199 316 505 202 316 minecraft:deepslate_tiles
setblock 506 199 279 minecraft:white_wool
setblock 506 199 314 minecraft:cobbled_deepslate
fill 506 199 315 506 202 315 minecraft:deepslate_tiles
setblock 506 199 317 minecraft:deepslate_tiles
fill 507 199 314 507 202 314 minecraft:deepslate_tiles
setblock 508 199 278 minecraft:light[level=12]
setblock 508 199 285 minecraft:light[level=12]
setblock 508 199 292 minecraft:light[level=12]
setblock 508 199 306 minecraft:light[level=12]
setblock 508 199 308 minecraft:deepslate_tiles
setblock 508 199 312 minecraft:cobbled_deepslate
setblock 508 199 313 minecraft:light[level=12]
setblock 509 199 306 minecraft:cobbled_deepslate
fill 509 199 307 509 202 307 minecraft:deepslate_tiles
setblock 509 199 311 minecraft:cobbled_deepslate
fill 509 199 312 509 202 312 minecraft:deepslate_tiles
setblock 509 199 316 minecraft:cobbled_deepslate
fill 509 199 317 510 199 317 minecraft:deepslate_tiles
fill 510 199 275 510 201 275 minecraft:black_concrete
setblock 510 199 290 minecraft:cobbled_deepslate
fill 510 199 291 510 201 292 minecraft:deepslate_tiles
setblock 510 199 305 minecraft:cobbled_deepslate
fill 510 199 306 511 201 306 minecraft:deepslate_tiles
setblock 510 199 310 minecraft:cobbled_deepslate
fill 510 199 311 511 201 311 minecraft:deepslate_tiles
setblock 510 199 315 minecraft:cobbled_deepslate
fill 510 199 316 510 202 316 minecraft:deepslate_tiles
setblock 511 199 284 minecraft:cobbled_deepslate
fill 511 199 285 511 201 285 minecraft:deepslate_tiles
setblock 511 199 289 minecraft:cobbled_deepslate
fill 511 199 290 511 202 290 minecraft:deepslate_tiles
setblock 511 199 294 minecraft:cobbled_deepslate
fill 511 199 295 511 202 295 minecraft:deepslate_tiles
setblock 511 199 299 minecraft:cobbled_deepslate
fill 511 199 300 511 202 300 minecraft:deepslate_tiles
setblock 511 199 304 minecraft:cobbled_deepslate
fill 511 199 305 511 202 305 minecraft:deepslate_tiles
setblock 511 199 309 minecraft:cobbled_deepslate
fill 511 199 310 511 202 310 minecraft:deepslate_tiles
setblock 511 199 314 minecraft:cobbled_deepslate
fill 511 199 315 511 202 315 minecraft:deepslate_tiles
fill 512 199 281 512 201 281 minecraft:black_concrete
setblock 512 199 282 minecraft:deepslate_tiles
fill 512 199 283 512 199 284 minecraft:black_concrete
fill 512 199 303 512 201 303 minecraft:black_concrete
fill 512 199 306 512 201 306 minecraft:black_concrete
fill 512 199 309 512 201 309 minecraft:black_concrete
fill 512 199 311 512 201 311 minecraft:black_concrete
fill 470 200 284 471 200 284 minecraft:deepslate_tiles
fill 470 200 289 471 200 289 minecraft:deepslate_tiles
fill 470 200 291 470 201 291 minecraft:black_concrete
fill 470 200 294 470 202 294 minecraft:black_concrete
setblock 470 200 301 minecraft:deepslate_tiles
fill 470 200 305 470 201 305 minecraft:black_concrete
fill 470 200 311 470 201 312 minecraft:black_concrete
setblock 470 200 317 minecraft:deepslate_tiles
setblock 471 200 275 minecraft:deepslate_tiles
setblock 471 200 283 minecraft:cobbled_deepslate
setblock 471 200 288 minecraft:cobbled_deepslate
setblock 471 200 293 minecraft:cobbled_deepslate
fill 471 200 294 471 203 294 minecraft:deepslate_tiles
setblock 471 200 298 minecraft:cobbled_deepslate
fill 471 200 299 471 203 299 minecraft:deepslate_tiles
setblock 471 200 303 minecraft:cobbled_deepslate
fill 471 200 304 471 203 304 minecraft:deepslate_tiles
setblock 471 200 308 minecraft:cobbled_deepslate
fill 471 200 309 471 203 309 minecraft:deepslate_tiles
setblock 471 200 313 minecraft:cobbled_deepslate
fill 471 200 314 471 203 314 minecraft:deepslate_tiles
fill 471 200 317 471 201 317 minecraft:black_concrete
fill 472 200 275 473 201 275 minecraft:black_concrete
setblock 472 200 287 minecraft:cobbled_deepslate
fill 472 200 288 472 203 288 minecraft:deepslate_tiles
setblock 472 200 292 minecraft:cobbled_deepslate
fill 472 200 293 472 203 293 minecraft:deepslate_tiles
setblock 472 200 307 minecraft:cobbled_deepslate
fill 472 200 308 472 201 308 minecraft:deepslate_tiles
setblock 472 200 312 minecraft:cobbled_deepslate
setblock 474 200 317 minecraft:deepslate_tiles
setblock 477 200 275 minecraft:deepslate_tiles
fill 479 200 275 480 200 275 minecraft:deepslate_tiles
fill 479 200 317 479 201 317 minecraft:black_concrete
setblock 482 200 317 minecraft:deepslate_tiles
fill 485 200 276 485 202 276 minecraft:deepslate_tiles
fill 485 200 316 485 202 316 minecraft:deepslate_tiles
setblock 488 200 276 minecraft:cobbled_deepslate
fill 488 200 277 488 203 277 minecraft:deepslate_tiles
setblock 488 200 315 minecraft:deepslate_tiles
setblock 488 200 316 minecraft:cobbled_deepslate
fill 489 200 276 489 203 276 minecraft:deepslate_tiles
setblock 489 200 315 minecraft:cobbled_deepslate
fill 489 200 316 489 203 316 minecraft:deepslate_tiles
fill 490 200 315 490 203 315 minecraft:deepslate_tiles
setblock 491 200 275 minecraft:deepslate_tiles
fill 492 200 275 492 202 275 minecraft:black_concrete
fill 492 200 315 492 201 315 minecraft:deepslate_tiles
setblock 493 200 276 minecraft:cobbled_deepslate
setblock 493 200 316 minecraft:cobbled_deepslate
fill 494 200 276 494 203 276 minecraft:deepslate_tiles
fill 494 200 316 494 203 316 minecraft:deepslate_tiles
fill 494 200 317 494 201 317 minecraft:black_concrete
setblock 496 200 275 minecraft:deepslate_tiles
fill 496 200 317 496 201 317 minecraft:black_concrete
fill 497 200 275 498 201 275 minecraft:black_concrete
setblock 497 200 316 minecraft:deepslate_tiles
setblock 498 200 316 minecraft:cobbled_deepslate
setblock 499 200 275 minecraft:deepslate_tiles
fill 499 200 316 500 202 316 minecraft:deepslate_tiles
fill 500 200 275 501 201 275 minecraft:black_concrete
fill 500 200 317 500 202 317 minecraft:black_concrete
fill 502 200 290 502 201 290 minecraft:white_terracotta
fill 502 200 315 503 200 315 minecraft:deepslate_tiles
fill 503 200 291 503 201 291 minecraft:white_terracotta
setblock 503 200 316 minecraft:cobbled_deepslate
fill 504 200 289 504 201 289 minecraft:white_terracotta
setblock 504 200 315 minecraft:cobbled_deepslate
fill 504 200 316 504 203 316 minecraft:deepslate_tiles
fill 504 200 317 504 202 317 minecraft:black_concrete
fill 505 200 275 505 201 275 minecraft:black_concrete
setblock 505 200 314 minecraft:cobbled_deepslate
fill 505 200 315 505 203 315 minecraft:deepslate_tiles
setblock 506 200 275 minecraft:deepslate_tiles
fill 506 200 314 506 203 314 minecraft:deepslate_tiles
fill 506 200 317 506 201 317 minecraft:black_concrete
setblock 507 200 280 minecraft:white_wool
setblock 508 200 281 minecraft:white_wool
setblock 508 200 310 minecraft:deepslate_tiles
setblock 508 200 311 minecraft:cobbled_deepslate
fill 508 200 312 508 202 313 minecraft:deepslate_tiles
setblock 508 200 316 minecraft:cobbled_deepslate
setblock 509 200 282 minecraft:white_wool
setblock 509 200 305 minecraft:cobbled_deepslate
fill 509 200 306 509 203 306 minecraft:deepslate_tiles
setblock 509 200 310 minecraft:cobbled_deepslate
fill 509 200 311 509 203 311 minecraft:deepslate_tiles
setblock 509 200 315 minecraft:cobbled_deepslate
fill 509 200 316 509 203 316 minecraft:deepslate_tiles
fill 509 200 317 510 201 317 minecraft:black_concrete
setblock 510 200 283 minecraft:white_wool
setblock 510 200 289 minecraft:cobbled_deepslate
fill 510 200 290 510 203 290 minecraft:deepslate_tiles
setblock 510 200 293 minecraft:deepslate_tiles
setblock 510 200 294 minecraft:cobbled_deepslate
setblock 510 200 304 minecraft:cobbled_deepslate
fill 510 200 305 510 203 305 minecraft:deepslate_tiles
setblock 510 200 309 minecraft:cobbled_deepslate
fill 510 200 310 510 203 310 minecraft:deepslate_tiles
setblock 510 200 314 minecraft:cobbled_deepslate
fill 510 200 315 510 203 315 minecraft:deepslate_tiles
setblock 511 200 288 minecraft:cobbled_deepslate
fill 511 200 289 512 200 289 minecraft:deepslate_tiles
setblock 511 200 293 minecraft:cobbled_deepslate
fill 511 200 294 511 203 294 minecraft:deepslate_tiles
setblock 511 200 298 minecraft:cobbled_deepslate
fill 511 200 299 511 203 299 minecraft:deepslate_tiles
setblock 511 200 303 minecraft:cobbled_deepslate
fill 511 200 304 511 203 304 minecraft:deepslate_tiles
setblock 511 200 308 minecraft:cobbled_deepslate
fill 511 200 309 511 203 309 minecraft:deepslate_tiles
setblock 511 200 313 minecraft:cobbled_deepslate
fill 511 200 314 512 200 314 minecraft:deepslate_tiles
setblock 512 200 277 minecraft:deepslate_tiles
fill 512 200 282 512 201 282 minecraft:black_concrete
setblock 512 200 283 minecraft:deepslate_tiles
fill 512 200 284 512 201 284 minecraft:black_concrete
fill 512 200 290 512 201 291 minecraft:black_concrete
setblock 512 200 308 minecraft:deepslate_tiles
fill 512 200 313 512 201 313 minecraft:black_concrete
setblock 470 201 284 minecraft:black_concrete
setblock 470 201 289 minecraft:black_concrete
fill 470 201 301 470 202 301 minecraft:black_concrete
setblock 470 201 317 minecraft:black_concrete
setblock 471 201 275 minecraft:black_concrete
fill 471 201 284 471 203 284 minecraft:deepslate_tiles
setblock 471 201 287 minecraft:cobbled_deepslate
fill 471 201 288 471 203 289 minecraft:deepslate_tiles
setblock 471 201 292 minecraft:cobbled_deepslate
fill 471 201 293 471 204 293 minecraft:deepslate_tiles
setblock 471 201 297 minecraft:cobbled_deepslate
fill 471 201 298 471 204 298 minecraft:deepslate_tiles
setblock 471 201 302 minecraft:cobbled_deepslate
fill 471 201 303 471 204 303 minecraft:deepslate_tiles
setblock 471 201 307 minecraft:cobbled_deepslate
fill 471 201 308 471 204 308 minecraft:deepslate_tiles
setblock 471 201 312 minecraft:cobbled_deepslate
fill 471 201 313 471 204 313 minecraft:deepslate_tiles
setblock 472 201 286 minecraft:cobbled_deepslate
fill 472 201 287 472 204 287 minecraft:deepslate_tiles
setblock 472 201 291 minecraft:cobbled_deepslate
fill 472 201 292 472 204 292 minecraft:deepslate_tiles
setblock 472 201 296 minecraft:cobbled_deepslate
setblock 472 201 311 minecraft:cobbled_deepslate
setblock 472 201 312 minecraft:deepslate_tiles
fill 473 201 291 473 204 291 minecraft:deepslate_tiles
setblock 474 201 317 minecraft:black_concrete
setblock 477 201 275 minecraft:black_concrete
fill 479 201 275 480 201 275 minecraft:black_concrete
setblock 482 201 317 minecraft:black_concrete
setblock 484 201 275 minecraft:black_concrete
fill 484 201 276 484 203 276 minecraft:deepslate_tiles
fill 484 201 316 484 203 316 minecraft:deepslate_tiles
setblock 486 201 277 minecraft:cobbled_deepslate
fill 486 201 315 487 201 315 minecraft:deepslate_tiles
setblock 487 201 276 minecraft:cobbled_deepslate
fill 487 201 277 487 204 277 minecraft:deepslate_tiles
setblock 487 201 316 minecraft:cobbled_deepslate
fill 488 201 276 488 204 276 minecraft:deepslate_tiles
setblock 488 201 315 minecraft:cobbled_deepslate
fill 488 201 316 488 204 316 minecraft:deepslate_tiles
fill 489 201 315 489 204 315 minecraft:deepslate_tiles
fill 490 201 316 490 202 316 minecraft:deepslate_tiles
setblock 490 201 317 minecraft:black_concrete
setblock 491 201 275 minecraft:black_concrete
setblock 492 201 276 minecraft:cobbled_deepslate
setblock 492 201 316 minecraft:cobbled_deepslate
fill 493 201 276 493 204 276 minecraft:deepslate_tiles
setblock 493 201 315 minecraft:cobbled_deepslate
fill 493 201 316 493 204 316 minecraft:deepslate_tiles
setblock 496 201 275 minecraft:black_concrete
setblock 497 201 316 minecraft:cobbled_deepslate
fill 498 201 316 498 204 316 minecraft:deepslate_tiles
setblock 499 201 275 minecraft:black_concrete
fill 501 201 315 501 201 316 minecraft:deepslate_tiles
setblock 501 201 317 minecraft:black_concrete
setblock 502 201 315 minecraft:deepslate_tiles
setblock 502 201 316 minecraft:cobbled_deepslate
setblock 503 201 314 minecraft:deepslate_tiles
setblock 503 201 315 minecraft:cobbled_deepslate
fill 503 201 316 503 204 316 minecraft:deepslate_tiles
setblock 504 201 314 minecraft:cobbled_deepslate
fill 504 201 315 504 204 315 minecraft:deepslate_tiles
fill 505 201 276 506 201 276 minecraft:deepslate_tiles
fill 505 201 314 505 204 314 minecraft:deepslate_tiles
setblock 506 201 275 minecraft:black_concrete
fill 506 201 313 507 203 313 minecraft:deepslate_tiles
setblock 507 201 276 minecraft:cobbled_deepslate
setblock 507 201 316 minecraft:cobbled_deepslate
fill 508 201 276 508 204 276 minecraft:deepslate_tiles
setblock 508 201 310 minecraft:cobbled_deepslate
fill 508 201 311 508 204 311 minecraft:deepslate_tiles
setblock 508 201 315 minecraft:cobbled_deepslate
fill 508 201 316 508 204 316 minecraft:deepslate_tiles
setblock 509 201 309 minecraft:cobbled_deepslate
fill 509 201 310 509 204 310 minecraft:deepslate_tiles
setblock 509 201 314 minecraft:cobbled_deepslate
fill 509 201 315 509 204 315 minecraft:deepslate_tiles
setblock 510 201 288 minecraft:cobbled_deepslate
fill 510 201 289 511 203 289 minecraft:deepslate_tiles
setblock 510 201 293 minecraft:cobbled_deepslate
fill 510 201 294 510 202 296 minecraft:deepslate_tiles
setblock 510 201 303 minecraft:cobbled_deepslate
fill 510 201 304 510 204 304 minecraft:deepslate_tiles
setblock 510 201 308 minecraft:cobbled_deepslate
fill 510 201 309 510 204 309 minecraft:deepslate_tiles
setblock 510 201 313 minecraft:cobbled_deepslate
fill 510 201 314 511 203 314 minecraft:deepslate_tiles
setblock 511 201 287 minecraft:cobbled_deepslate
fill 511 201 288 511 204 288 minecraft:deepslate_tiles
setblock 511 201 292 minecraft:cobbled_deepslate
fill 511 201 293 511 204 293 minecraft:deepslate_tiles
setblock 511 201 297 minecraft:cobbled_deepslate
fill 511 201 298 511 204 298 minecraft:deepslate_tiles
setblock 511 201 302 minecraft:cobbled_deepslate
fill 511 201 303 511 204 303 minecraft:deepslate_tiles
setblock 511 201 307 minecraft:cobbled_deepslate
fill 511 201 308 511 204 308 minecraft:deepslate_tiles
setblock 511 201 312 minecraft:cobbled_deepslate
fill 511 201 313 511 204 313 minecraft:deepslate_tiles
setblock 512 201 277 minecraft:black_concrete
setblock 512 201 283 minecraft:black_concrete
setblock 512 201 289 minecraft:black_concrete
setblock 512 201 308 minecraft:black_concrete
setblock 512 201 314 minecraft:black_concrete
fill 470 202 275 470 202 279 minecraft:deepslate_tiles
setblock 470 202 280 minecraft:black_concrete
fill 470 202 281 470 203 284 minecraft:deepslate_tiles
fill 470 202 286 470 202 293 minecraft:deepslate_tiles
fill 470 202 295 470 246 300 minecraft:deepslate_tiles
fill 470 202 302 470 217 306 minecraft:deepslate_tiles
fill 470 202 308 470 306 310 minecraft:deepslate_tiles
setblock 470 202 311 minecraft:black_concrete
fill 470 202 312 470 202 317 minecraft:deepslate_tiles
fill 471 202 275 479 202 275 minecraft:deepslate_tiles
setblock 471 202 286 minecraft:cobbled_deepslate
fill 471 202 287 471 205 287 minecraft:deepslate_tiles
setblock 471 202 291 minecraft:cobbled_deepslate
fill 471 202 292 471 205 292 minecraft:deepslate_tiles
setblock 471 202 296 minecraft:cobbled_deepslate
fill 471 202 297 472 204 297 minecraft:deepslate_tiles
setblock 471 202 301 minecraft:cobbled_deepslate
fill 471 202 302 471 205 302 minecraft:deepslate_tiles
setblock 471 202 306 minecraft:cobbled_deepslate
fill 471 202 307 471 205 307 minecraft:deepslate_tiles
setblock 471 202 311 minecraft:cobbled_deepslate
fill 471 202 312 471 205 312 minecraft:deepslate_tiles
setblock 471 202 316 minecraft:cobbled_deepslate
fill 471 202 317 476 202 317 minecraft:deepslate_tiles
setblock 472 202 290 minecraft:cobbled_deepslate
fill 472 202 291 472 205 291 minecraft:deepslate_tiles
setblock 472 202 295 minecraft:cobbled_deepslate
fill 472 202 296 472 205 296 minecraft:deepslate_tiles
fill 473 202 290 473 205 290 minecraft:deepslate_tiles
fill 473 202 292 473 203 292 minecraft:deepslate_tiles
fill 477 202 317 477 203 317 minecraft:black_concrete
fill 478 202 317 480 271 317 minecraft:deepslate_tiles
fill 480 202 275 480 203 275 minecraft:black_concrete
fill 481 202 275 491 211 275 minecraft:deepslate_tiles
fill 482 202 276 483 204 276 minecraft:deepslate_tiles
fill 482 202 316 483 204 317 minecraft:deepslate_tiles
fill 484 202 315 486 202 315 minecraft:deepslate_tiles
fill 484 202 317 491 202 317 minecraft:deepslate_tiles
setblock 485 202 277 minecraft:cobbled_deepslate
setblock 486 202 276 minecraft:cobbled_deepslate
fill 486 202 277 486 205 277 minecraft:deepslate_tiles
fill 486 202 280 486 206 280 minecraft:black_concrete
setblock 486 202 316 minecraft:cobbled_deepslate
fill 487 202 276 487 205 276 minecraft:deepslate_tiles
fill 487 202 279 487 206 279 minecraft:black_concrete
fill 487 202 281 487 206 281 minecraft:black_concrete
setblock 487 202 314 minecraft:deepslate_tiles
setblock 487 202 315 minecraft:cobbled_deepslate
fill 487 202 316 487 205 316 minecraft:deepslate_tiles
fill 488 202 280 488 206 280 minecraft:black_concrete
setblock 488 202 314 minecraft:cobbled_deepslate
fill 488 202 315 488 205 315 minecraft:deepslate_tiles
fill 489 202 314 490 204 314 minecraft:deepslate_tiles
setblock 490 202 277 minecraft:cobbled_deepslate
setblock 491 202 276 minecraft:cobbled_deepslate
fill 491 202 277 491 205 277 minecraft:deepslate_tiles
setblock 491 202 315 minecraft:deepslate_tiles
setblock 491 202 316 minecraft:cobbled_deepslate
fill 492 202 276 492 205 276 minecraft:deepslate_tiles
setblock 492 202 315 minecraft:cobbled_deepslate
fill 492 202 316 492 205 316 minecraft:deepslate_tiles
fill 493 202 275 507 202 275 minecraft:deepslate_tiles
fill 493 202 315 496 202 315 minecraft:deepslate_tiles
fill 493 202 317 494 202 317 minecraft:deepslate_tiles
setblock 495 202 276 minecraft:deepslate_tiles
setblock 495 202 316 minecraft:deepslate_tiles
setblock 496 202 316 minecraft:cobbled_deepslate
fill 496 202 317 499 227 317 minecraft:deepslate_tiles
setblock 497 202 315 minecraft:cobbled_deepslate
fill 497 202 316 497 205 316 minecraft:deepslate_tiles
fill 498 202 315 501 202 315 minecraft:deepslate_tiles
setblock 501 202 316 minecraft:cobbled_deepslate
fill 501 202 317 503 270 317 minecraft:deepslate_tiles
setblock 502 202 314 minecraft:deepslate_tiles
setblock 502 202 315 minecraft:cobbled_deepslate
fill 502 202 316 502 205 316 minecraft:deepslate_tiles
fill 503 202 276 505 202 276 minecraft:deepslate_tiles
setblock 503 202 314 minecraft:cobbled_deepslate
fill 503 202 315 503 205 315 minecraft:deepslate_tiles
setblock 504 202 313 minecraft:cobbled_deepslate
fill 504 202 314 504 205 314 minecraft:deepslate_tiles
fill 505 202 313 505 205 313 minecraft:deepslate_tiles
fill 505 202 317 512 202 317 minecraft:deepslate_tiles
setblock 506 202 276 minecraft:cobbled_deepslate
setblock 506 202 316 minecraft:cobbled_deepslate
fill 507 202 276 507 205 276 minecraft:deepslate_tiles
setblock 507 202 315 minecraft:cobbled_deepslate
fill 507 202 316 507 205 316 minecraft:deepslate_tiles
setblock 508 202 309 minecraft:cobbled_deepslate
fill 508 202 310 508 205 310 minecraft:deepslate_tiles
setblock 508 202 314 minecraft:cobbled_deepslate
fill 508 202 315 508 205 315 minecraft:deepslate_tiles
fill 509 202 275 509 203 276 minecraft:deepslate_tiles
setblock 509 202 308 minecraft:cobbled_deepslate
fill 509 202 309 509 205 309 minecraft:deepslate_tiles
setblock 509 202 313 minecraft:cobbled_deepslate
fill 509 202 314 509 205 314 minecraft:deepslate_tiles
fill 510 202 275 512 252 275 minecraft:deepslate_tiles
fill 510 202 288 510 205 288 minecraft:deepslate_tiles
setblock 510 202 291 minecraft:deepslate_tiles
setblock 510 202 292 minecraft:cobbled_deepslate
fill 510 202 293 510 205 293 minecraft:deepslate_tiles
setblock 510 202 297 minecraft:cobbled_deepslate
fill 510 202 298 510 205 298 minecraft:deepslate_tiles
setblock 510 202 302 minecraft:cobbled_deepslate
fill 510 202 303 510 205 303 minecraft:deepslate_tiles
setblock 510 202 306 minecraft:deepslate_tiles
setblock 510 202 307 minecraft:cobbled_deepslate
fill 510 202 308 510 205 308 minecraft:deepslate_tiles
setblock 510 202 311 minecraft:deepslate_tiles
setblock 510 202 312 minecraft:cobbled_deepslate
fill 510 202 313 510 205 313 minecraft:deepslate_tiles
setblock 511 202 286 minecraft:cobbled_deepslate
fill 511 202 287 512 205 287 minecraft:deepslate_tiles
setblock 511 202 291 minecraft:cobbled_deepslate
fill 511 202 292 512 205 292 minecraft:deepslate_tiles
setblock 511 202 296 minecraft:cobbled_deepslate
fill 511 202 297 512 205 297 minecraft:deepslate_tiles
setblock 511 202 301 minecraft:cobbled_deepslate
fill 511 202 302 512 205 302 minecraft:deepslate_tiles
setblock 511 202 306 minecraft:cobbled_deepslate
fill 511 202 307 512 205 307 minecraft:deepslate_tiles
setblock 511 202 311 minecraft:cobbled_deepslate
fill 511 202 312 512 205 312 minecraft:deepslate_tiles
setblock 511 202 316 minecraft:cobbled_deepslate
fill 512 202 276 512 202 285 minecraft:deepslate_tiles
setblock 512 202 286 minecraft:white_wool
fill 512 202 289 512 202 291 minecraft:deepslate_tiles
fill 512 202 293 512 202 296 minecraft:deepslate_tiles
fill 512 202 298 512 205 301 minecraft:deepslate_tiles
fill 512 202 303 512 203 306 minecraft:deepslate_tiles
fill 512 202 308 512 244 311 minecraft:deepslate_tiles
fill 512 202 313 512 202 315 minecraft:deepslate_tiles
setblock 512 202 316 minecraft:black_concrete
fill 470 203 275 470 236 278 minecraft:deepslate_tiles
setblock 470 203 279 minecraft:black_concrete
fill 470 203 280 470 222 280 minecraft:deepslate_tiles
fill 470 203 285 470 271 285 minecraft:deepslate_tiles
fill 470 203 286 470 203 287 minecraft:black_concrete
fill 470 203 288 470 293 289 minecraft:deepslate_tiles
setblock 470 203 290 minecraft:black_concrete
fill 470 203 291 470 224 294 minecraft:deepslate_tiles
fill 470 203 301 471 206 301 minecraft:deepslate_tiles
fill 470 203 307 470 216 307 minecraft:deepslate_tiles
fill 470 203 311 470 239 316 minecraft:deepslate_tiles
setblock 470 203 317 minecraft:black_concrete
fill 471 203 275 475 203 275 minecraft:deepslate_tiles
setblock 471 203 285 minecraft:cobbled_deepslate
fill 471 203 286 471 206 286 minecraft:deepslate_tiles
setblock 471 203 290 minecraft:cobbled_deepslate
fill 471 203 291 471 206 291 minecraft:deepslate_tiles
setblock 471 203 295 minecraft:cobbled_deepslate
fill 471 203 296 471 206 296 minecraft:deepslate_tiles
setblock 471 203 300 minecraft:cobbled_deepslate
setblock 471 203 305 minecraft:cobbled_deepslate
fill 471 203 306 471 205 306 minecraft:deepslate_tiles
setblock 471 203 310 minecraft:cobbled_deepslate
fill 471 203 311 471 206 311 minecraft:deepslate_tiles
setblock 471 203 315 minecraft:cobbled_deepslate
fill 471 203 316 472 205 317 minecraft:deepslate_tiles
setblock 472 203 289 minecraft:cobbled_deepslate
fill 472 203 290 472 206 290 minecraft:deepslate_tiles
setblock 472 203 294 minecraft:cobbled_deepslate
fill 472 203 295 472 206 295 minecraft:deepslate_tiles
setblock 472 203 298 minecraft:deepslate_tiles
setblock 473 203 293 minecraft:cobbled_deepslate
fill 473 203 317 475 258 317 minecraft:deepslate_tiles
setblock 476 203 275 minecraft:black_concrete
setblock 476 203 317 minecraft:black_concrete
fill 477 203 275 478 308 275 minecraft:deepslate_tiles
setblock 479 203 275 minecraft:black_concrete
fill 481 203 276 481 206 276 minecraft:deepslate_tiles
fill 481 203 316 481 206 317 minecraft:deepslate_tiles
setblock 483 203 277 minecraft:deepslate_tiles
fill 483 203 315 485 203 315 minecraft:deepslate_tiles
setblock 484 203 277 minecraft:cobbled_deepslate
fill 484 203 317 484 295 317 minecraft:deepslate_tiles
setblock 485 203 276 minecraft:cobbled_deepslate
fill 485 203 277 485 206 277 minecraft:deepslate_tiles
fill 485 203 314 486 203 314 minecraft:deepslate_tiles
setblock 485 203 316 minecraft:cobbled_deepslate
setblock 485 203 317 minecraft:black_concrete
fill 486 203 276 486 206 276 minecraft:deepslate_tiles
setblock 486 203 315 minecraft:cobbled_deepslate
fill 486 203 316 486 206 317 minecraft:deepslate_tiles
setblock 487 203 314 minecraft:cobbled_deepslate
fill 487 203 315 487 206 315 minecraft:deepslate_tiles
fill 487 203 317 493 244 317 minecraft:deepslate_tiles
fill 488 203 314 488 206 314 minecraft:deepslate_tiles
setblock 489 203 277 minecraft:cobbled_deepslate
setblock 490 203 276 minecraft:cobbled_deepslate
fill 490 203 277 490 206 277 minecraft:deepslate_tiles
setblock 490 203 316 minecraft:cobbled_deepslate
fill 491 203 276 491 206 276 minecraft:deepslate_tiles
setblock 491 203 314 minecraft:deepslate_tiles
setblock 491 203 315 minecraft:cobbled_deepslate
fill 491 203 316 491 206 316 minecraft:deepslate_tiles
fill 492 203 275 495 263 275 minecraft:deepslate_tiles
fill 492 203 277 492 204 277 minecraft:deepslate_tiles
fill 492 203 315 495 203 315 minecraft:deepslate_tiles
setblock 494 203 317 minecraft:black_concrete
setblock 495 203 276 minecraft:cobbled_deepslate
setblock 495 203 316 minecraft:cobbled_deepslate
fill 495 203 317 495 249 317 minecraft:deepslate_tiles
setblock 496 203 275 minecraft:black_concrete
fill 496 203 276 497 205 276 minecraft:deepslate_tiles
setblock 496 203 315 minecraft:cobbled_deepslate
fill 496 203 316 496 206 316 minecraft:deepslate_tiles
fill 497 203 275 499 214 275 minecraft:deepslate_tiles
fill 497 203 315 500 203 315 minecraft:deepslate_tiles
setblock 499 203 276 minecraft:deepslate_tiles
setblock 499 203 316 minecraft:deepslate_tiles
setblock 500 203 275 minecraft:black_concrete
setblock 500 203 276 minecraft:cobbled_deepslate
fill 500 203 314 501 203 314 minecraft:deepslate_tiles
setblock 500 203 316 minecraft:cobbled_deepslate
fill 500 203 317 500 210 317 minecraft:deepslate_tiles
fill 501 203 275 502 203 276 minecraft:deepslate_tiles
setblock 501 203 315 minecraft:cobbled_deepslate
fill 501 203 316 501 206 316 minecraft:deepslate_tiles
setblock 502 203 314 minecraft:cobbled_deepslate
fill 502 203 315 502 206 315 minecraft:deepslate_tiles
fill 503 203 275 505 308 275 minecraft:deepslate_tiles
setblock 503 203 276 minecraft:white_wool
fill 503 203 290 503 206 290 minecraft:white_wool
setblock 503 203 313 minecraft:cobbled_deepslate
fill 503 203 314 503 206 314 minecraft:deepslate_tiles
setblock 504 203 276 minecraft:deepslate_tiles
setblock 504 203 277 minecraft:white_wool
fill 504 203 313 504 206 313 minecraft:deepslate_tiles
fill 504 203 317 505 308 317 minecraft:deepslate_tiles
setblock 505 203 276 minecraft:cobbled_deepslate
setblock 505 203 278 minecraft:white_wool
setblock 505 203 316 minecraft:cobbled_deepslate
setblock 506 203 275 minecraft:black_concrete
fill 506 203 276 506 206 276 minecraft:deepslate_tiles
setblock 506 203 279 minecraft:white_wool
setblock 506 203 315 minecraft:cobbled_deepslate
fill 506 203 316 506 206 316 minecraft:deepslate_tiles
fill 506 203 317 506 204 317 minecraft:black_concrete
fill 507 203 275 508 203 275 minecraft:deepslate_tiles
setblock 507 203 314 minecraft:cobbled_deepslate
fill 507 203 315 507 206 315 minecraft:deepslate_tiles
fill 507 203 317 512 203 317 minecraft:deepslate_tiles
fill 508 203 309 508 204 309 minecraft:deepslate_tiles
setblock 508 203 312 minecraft:deepslate_tiles
setblock 508 203 313 minecraft:cobbled_deepslate
fill 508 203 314 508 206 314 minecraft:deepslate_tiles
setblock 509 203 291 minecraft:deepslate_tiles
setblock 509 203 292 minecraft:cobbled_deepslate
fill 509 203 293 509 204 295 minecraft:deepslate_tiles
setblock 509 203 307 minecraft:cobbled_deepslate
fill 509 203 308 509 206 308 minecraft:deepslate_tiles
setblock 509 203 312 minecraft:cobbled_deepslate
fill 509 203 313 509 206 313 minecraft:deepslate_tiles
setblock 510 203 276 minecraft:cobbled_deepslate
setblock 510 203 291 minecraft:cobbled_deepslate
fill 510 203 292 510 206 292 minecraft:deepslate_tiles
fill 510 203 294 510 203 295 minecraft:deepslate_tiles
setblock 510 203 296 minecraft:cobbled_deepslate
fill 510 203 297 510 206 297 minecraft:deepslate_tiles
fill 510 203 299 510 203 300 minecraft:deepslate_tiles
setblock 510 203 301 minecraft:cobbled_deepslate
fill 510 203 302 510 206 302 minecraft:deepslate_tiles
setblock 510 203 306 minecraft:cobbled_deepslate
fill 510 203 307 510 206 307 minecraft:deepslate_tiles
setblock 510 203 311 minecraft:cobbled_deepslate
fill 510 203 312 510 206 312 minecraft:deepslate_tiles
setblock 510 203 316 minecraft:cobbled_deepslate
fill 511 203 286 512 204 286 minecraft:deepslate_tiles
setblock 511 203 290 minecraft:cobbled_deepslate
fill 511 203 291 512 203 291 minecraft:deepslate_tiles
setblock 511 203 295 minecraft:cobbled_deepslate
fill 511 203 296 511 206 296 minecraft:deepslate_tiles
setblock 511 203 300 minecraft:cobbled_deepslate
fill 511 203 301 511 206 301 minecraft:deepslate_tiles
setblock 511 203 305 minecraft:cobbled_deepslate
fill 511 203 306 511 206 306 minecraft:deepslate_tiles
setblock 511 203 310 minecraft:cobbled_deepslate
fill 511 203 311 511 206 311 minecraft:deepslate_tiles
setblock 511 203 315 minecraft:cobbled_deepslate
fill 511 203 316 512 206 316 minecraft:deepslate_tiles
fill 512 203 276 512 215 277 minecraft:deepslate_tiles
setblock 512 203 278 minecraft:black_concrete
fill 512 203 279 512 285 279 minecraft:deepslate_tiles
setblock 512 203 280 minecraft:black_concrete
fill 512 203 281 512 203 285 minecraft:deepslate_tiles
fill 512 203 288 512 259 289 minecraft:deepslate_tiles
setblock 512 203 290 minecraft:black_concrete
fill 512 203 293 512 209 295 minecraft:deepslate_tiles
setblock 512 203 296 minecraft:black_concrete
fill 512 203 313 512 278 314 minecraft:deepslate_tiles
setblock 512 203 315 minecraft:black_concrete
fill 470 204 279 470 214 279 minecraft:deepslate_tiles
setblock 470 204 281 minecraft:black_concrete
fill 470 204 282 470 308 283 minecraft:deepslate_tiles
setblock 470 204 284 minecraft:black_concrete
fill 470 204 286 470 308 287 minecraft:deepslate_tiles
fill 470 204 290 471 207 290 minecraft:deepslate_tiles
fill 470 204 317 470 308 317 minecraft:deepslate_tiles
fill 471 204 275 473 215 275 minecraft:deepslate_tiles
setblock 471 204 284 minecraft:cobbled_deepslate
fill 471 204 285 471 207 285 minecraft:deepslate_tiles
setblock 471 204 288 minecraft:deepslate_tiles
setblock 471 204 289 minecraft:cobbled_deepslate
setblock 471 204 294 minecraft:cobbled_deepslate
fill 471 204 295 471 207 295 minecraft:deepslate_tiles
setblock 471 204 299 minecraft:cobbled_deepslate
fill 471 204 300 471 207 300 minecraft:deepslate_tiles
setblock 471 204 304 minecraft:cobbled_deepslate
fill 471 204 305 471 205 305 minecraft:deepslate_tiles
setblock 471 204 309 minecraft:cobbled_deepslate
fill 471 204 310 471 206 310 minecraft:deepslate_tiles
setblock 471 204 314 minecraft:cobbled_deepslate
fill 471 204 315 471 207 315 minecraft:deepslate_tiles
setblock 472 204 288 minecraft:cobbled_deepslate
fill 472 204 289 472 207 289 minecraft:deepslate_tiles
setblock 472 204 293 minecraft:cobbled_deepslate
fill 472 204 294 473 206 294 minecraft:deepslate_tiles
setblock 472 204 298 minecraft:cobbled_deepslate
setblock 473 204 292 minecraft:cobbled_deepslate
fill 473 204 293 473 207 293 minecraft:deepslate_tiles
setblock 474 204 275 minecraft:black_concrete
fill 475 204 275 476 308 275 minecraft:deepslate_tiles
fill 476 204 317 477 207 317 minecraft:deepslate_tiles
fill 479 204 275 480 308 275 minecraft:deepslate_tiles
setblock 479 204 276 minecraft:cobbled_deepslate
setblock 479 204 316 minecraft:cobbled_deepslate
fill 480 204 276 480 207 276 minecraft:deepslate_tiles
fill 480 204 316 480 207 316 minecraft:deepslate_tiles
fill 481 204 315 484 204 315 minecraft:deepslate_tiles
setblock 482 204 277 minecraft:deepslate_tiles
setblock 483 204 277 minecraft:cobbled_deepslate
setblock 484 204 276 minecraft:cobbled_deepslate
fill 484 204 277 484 207 277 minecraft:deepslate_tiles
fill 484 204 314 485 204 314 minecraft:deepslate_tiles
setblock 484 204 316 minecraft:cobbled_deepslate
fill 485 204 276 485 207 276 minecraft:deepslate_tiles
fill 485 204 278 486 204 278 minecraft:deepslate_tiles
setblock 485 204 315 minecraft:cobbled_deepslate
fill 485 204 316 485 207 317 minecraft:deepslate_tiles
fill 486 204 279 486 206 279 minecraft:black_concrete
fill 486 204 281 486 206 281 minecraft:black_concrete
setblock 486 204 314 minecraft:cobbled_deepslate
fill 486 204 315 486 207 315 minecraft:deepslate_tiles
setblock 487 204 278 minecraft:cobbled_deepslate
fill 487 204 314 487 207 314 minecraft:deepslate_tiles
setblock 488 204 277 minecraft:cobbled_deepslate
fill 488 204 278 488 207 278 minecraft:deepslate_tiles
fill 488 204 279 488 206 279 minecraft:black_concrete
fill 488 204 281 488 206 281 minecraft:black_concrete
setblock 489 204 276 minecraft:cobbled_deepslate
fill 489 204 277 489 207 277 minecraft:deepslate_tiles
setblock 489 204 316 minecraft:cobbled_deepslate
fill 490 204 276 490 207 276 minecraft:deepslate_tiles
setblock 490 204 315 minecraft:cobbled_deepslate
fill 490 204 316 490 207 316 minecraft:deepslate_tiles
setblock 491 204 314 minecraft:cobbled_deepslate
fill 491 204 315 494 204 315 minecraft:deepslate_tiles
fill 492 204 314 492 207 314 minecraft:deepslate_tiles
setblock 494 204 276 minecraft:cobbled_deepslate
setblock 494 204 316 minecraft:cobbled_deepslate
fill 494 204 317 494 308 317 minecraft:deepslate_tiles
fill 495 204 276 495 207 276 minecraft:deepslate_tiles
setblock 495 204 315 minecraft:cobbled_deepslate
fill 495 204 316 495 207 316 minecraft:deepslate_tiles
fill 496 204 275 496 308 275 minecraft:deepslate_tiles
fill 496 204 315 499 204 315 minecraft:deepslate_tiles
setblock 498 204 276 minecraft:deepslate_tiles
fill 498 204 314 500 204 314 minecraft:deepslate_tiles
setblock 499 204 276 minecraft:cobbled_deepslate
setblock 499 204 316 minecraft:cobbled_deepslate
fill 500 204 275 500 207 276 minecraft:deepslate_tiles
setblock 500 204 315 minecraft:cobbled_deepslate
fill 500 204 316 500 207 316 minecraft:deepslate_tiles
setblock 501 204 275 minecraft:black_concrete
fill 501 204 276 503 204 276 minecraft:deepslate_tiles
setblock 501 204 314 minecraft:cobbled_deepslate
fill 501 204 315 501 207 315 minecraft:deepslate_tiles
fill 502 204 275 502 293 275 minecraft:deepslate_tiles
setblock 502 204 313 minecraft:cobbled_deepslate
fill 502 204 314 502 207 314 minecraft:deepslate_tiles
fill 503 204 313 503 207 313 minecraft:deepslate_tiles
setblock 504 204 276 minecraft:cobbled_deepslate
fill 504 204 293 508 205 297 minecraft:black_concrete
setblock 504 204 316 minecraft:cobbled_deepslate
fill 505 204 276 505 207 276 minecraft:deepslate_tiles
setblock 505 204 315 minecraft:cobbled_deepslate
fill 505 204 316 505 207 316 minecraft:deepslate_tiles
fill 506 204 275 506 308 275 minecraft:deepslate_tiles
setblock 506 204 313 minecraft:deepslate_tiles
setblock 506 204 314 minecraft:cobbled_deepslate
fill 506 204 315 506 207 315 minecraft:deepslate_tiles
setblock 507 204 275 minecraft:redstone_block
setblock 507 204 280 minecraft:white_wool
setblock 507 204 313 minecraft:cobbled_deepslate
fill 507 204 314 507 207 314 minecraft:deepslate_tiles
fill 507 204 317 510 222 317 minecraft:deepslate_tiles
fill 508 204 275 509 297 275 minecraft:deepslate_tiles
setblock 508 204 281 minecraft:white_wool
setblock 508 204 312 minecraft:cobbled_deepslate
fill 508 204 313 508 206 313 minecraft:deepslate_tiles
setblock 509 204 276 minecraft:cobbled_deepslate
setblock 509 204 282 minecraft:white_wool
setblock 509 204 290 minecraft:deepslate_tiles
setblock 509 204 291 minecraft:cobbled_deepslate
fill 509 204 292 509 207 292 minecraft:deepslate_tiles
setblock 509 204 296 minecraft:cobbled_deepslate
fill 509 204 297 509 206 298 minecraft:deepslate_tiles
setblock 509 204 306 minecraft:cobbled_deepslate
fill 509 204 307 509 205 307 minecraft:deepslate_tiles
setblock 509 204 311 minecraft:cobbled_deepslate
fill 509 204 312 509 207 312 minecraft:deepslate_tiles
setblock 509 204 316 minecraft:cobbled_deepslate
fill 510 204 276 510 207 276 minecraft:deepslate_tiles
setblock 510 204 283 minecraft:white_wool
setblock 510 204 289 minecraft:deepslate_tiles
setblock 510 204 290 minecraft:cobbled_deepslate
fill 510 204 291 511 206 291 minecraft:deepslate_tiles
setblock 510 204 294 minecraft:deepslate_tiles
setblock 510 204 295 minecraft:cobbled_deepslate
fill 510 204 296 510 207 296 minecraft:deepslate_tiles
setblock 510 204 299 minecraft:deepslate_tiles
setblock 510 204 300 minecraft:cobbled_deepslate
fill 510 204 301 510 207 301 minecraft:deepslate_tiles
setblock 510 204 305 minecraft:cobbled_deepslate
fill 510 204 306 510 207 306 minecraft:deepslate_tiles
setblock 510 204 310 minecraft:cobbled_deepslate
fill 510 204 311 510 207 311 minecraft:deepslate_tiles
setblock 510 204 314 minecraft:deepslate_tiles
setblock 510 204 315 minecraft:cobbled_deepslate
fill 510 204 316 510 207 316 minecraft:deepslate_tiles
setblock 511 204 289 minecraft:cobbled_deepslate
fill 511 204 290 512 207 290 minecraft:deepslate_tiles
setblock 511 204 294 minecraft:cobbled_deepslate
fill 511 204 295 511 207 295 minecraft:deepslate_tiles
setblock 511 204 299 minecraft:cobbled_deepslate
fill 511 204 300 511 207 300 minecraft:deepslate_tiles
setblock 511 204 304 minecraft:cobbled_deepslate
fill 511 204 305 512 207 305 minecraft:deepslate_tiles
setblock 511 204 309 minecraft:cobbled_deepslate
fill 511 204 310 511 207 310 minecraft:deepslate_tiles
setblock 511 204 314 minecraft:cobbled_deepslate
fill 511 204 315 512 207 315 minecraft:deepslate_tiles
setblock 511 204 317 minecraft:black_concrete
fill 512 204 278 512 245 278 minecraft:deepslate_tiles
fill 512 204 280 512 308 280 minecraft:deepslate_tiles
setblock 512 204 281 minecraft:black_concrete
fill 512 204 282 512 308 285 minecraft:deepslate_tiles
setblock 512 204 291 minecraft:black_concrete
fill 512 204 296 512 284 296 minecraft:deepslate_tiles
setblock 512 204 303 minecraft:black_concrete
fill 512 204 304 512 308 304 minecraft:deepslate_tiles
fill 512 204 306 512 268 306 minecraft:deepslate_tiles
fill 512 204 317 512 308 317 minecraft:deepslate_tiles
fill 470 205 281 470 253 281 minecraft:deepslate_tiles
fill 470 205 284 471 206 284 minecraft:deepslate_tiles
fill 471 205 276 471 206 276 minecraft:deepslate_tiles
setblock 471 205 288 minecraft:cobbled_deepslate
fill 471 205 289 471 208 289 minecraft:deepslate_tiles
setblock 471 205 293 minecraft:cobbled_deepslate
fill 471 205 294 471 208 294 minecraft:deepslate_tiles
setblock 471 205 297 minecraft:deepslate_tiles
setblock 471 205 298 minecraft:cobbled_deepslate
fill 471 205 299 472 207 299 minecraft:deepslate_tiles
setblock 471 205 303 minecraft:cobbled_deepslate
setblock 471 205 304 minecraft:deepslate_tiles
setblock 471 205 308 minecraft:cobbled_deepslate
fill 471 205 309 471 206 309 minecraft:deepslate_tiles
setblock 471 205 313 minecraft:cobbled_deepslate
fill 471 205 314 471 208 314 minecraft:deepslate_tiles
setblock 472 205 287 minecraft:cobbled_deepslate
fill 472 205 288 472 207 288 minecraft:deepslate_tiles
setblock 472 205 292 minecraft:cobbled_deepslate
fill 472 205 293 472 208 293 minecraft:deepslate_tiles
setblock 472 205 297 minecraft:cobbled_deepslate
fill 472 205 298 472 208 298 minecraft:deepslate_tiles
setblock 473 205 278 minecraft:light[level=13]
setblock 473 205 285 minecraft:light[level=12]
setblock 473 205 286 minecraft:light[level=13]
setblock 473 205 291 minecraft:cobbled_deepslate
fill 473 205 292 473 207 292 minecraft:deepslate_tiles
setblock 473 205 295 minecraft:deepslate_tiles
fill 473 205 296 473 207 296 minecraft:black_concrete
setblock 473 205 299 minecraft:light[level=12]
setblock 473 205 302 minecraft:light[level=13]
setblock 473 205 306 minecraft:light[level=12]
setblock 473 205 310 minecraft:light[level=13]
setblock 473 205 313 minecraft:light[level=12]
setblock 473 205 316 minecraft:cobbled_deepslate
fill 474 205 275 474 253 275 minecraft:deepslate_tiles
setblock 477 205 276 minecraft:deepslate_tiles
setblock 477 205 316 minecraft:deepslate_tiles
setblock 478 205 276 minecraft:cobbled_deepslate
setblock 478 205 316 minecraft:cobbled_deepslate
fill 479 205 276 479 208 276 minecraft:deepslate_tiles
fill 479 205 316 479 208 316 minecraft:deepslate_tiles
fill 480 205 277 481 205 277 minecraft:deepslate_tiles
setblock 480 205 278 minecraft:light[level=12]
setblock 480 205 285 minecraft:light[level=12]
setblock 480 205 292 minecraft:light[level=12]
setblock 480 205 299 minecraft:light[level=12]
setblock 480 205 306 minecraft:light[level=12]
setblock 480 205 313 minecraft:light[level=12]
fill 480 205 315 483 205 315 minecraft:deepslate_tiles
setblock 481 205 278 minecraft:light[level=13]
setblock 481 205 286 minecraft:light[level=13]
setblock 481 205 294 minecraft:light[level=13]
setblock 481 205 302 minecraft:light[level=13]
setblock 481 205 310 minecraft:light[level=13]
setblock 482 205 276 minecraft:deepslate_tiles
setblock 482 205 277 minecraft:cobbled_deepslate
fill 482 205 316 482 205 317 minecraft:deepslate_tiles
setblock 483 205 276 minecraft:cobbled_deepslate
fill 483 205 277 483 207 278 minecraft:deepslate_tiles
fill 483 205 314 484 205 314 minecraft:deepslate_tiles
setblock 483 205 316 minecraft:cobbled_deepslate
fill 483 205 317 483 308 317 minecraft:deepslate_tiles
fill 484 205 276 484 208 276 minecraft:deepslate_tiles
fill 484 205 278 485 205 278 minecraft:deepslate_tiles
setblock 484 205 315 minecraft:cobbled_deepslate
fill 484 205 316 484 208 316 minecraft:deepslate_tiles
setblock 485 205 314 minecraft:cobbled_deepslate
fill 485 205 315 485 208 315 minecraft:deepslate_tiles
setblock 486 205 278 minecraft:cobbled_deepslate
fill 486 205 314 486 208 314 minecraft:deepslate_tiles
setblock 487 205 277 minecraft:cobbled_deepslate
fill 487 205 278 487 208 278 minecraft:deepslate_tiles
setblock 487 205 285 minecraft:light[level=12]
setblock 487 205 292 minecraft:light[level=12]
setblock 487 205 299 minecraft:light[level=12]
setblock 487 205 306 minecraft:light[level=12]
setblock 487 205 313 minecraft:light[level=12]
setblock 488 205 276 minecraft:cobbled_deepslate
fill 488 205 277 488 208 277 minecraft:deepslate_tiles
setblock 488 205 316 minecraft:cobbled_deepslate
fill 489 205 276 489 208 276 minecraft:deepslate_tiles
fill 489 205 278 489 206 278 minecraft:deepslate_tiles
setblock 489 205 286 minecraft:light[level=13]
setblock 489 205 294 minecraft:light[level=13]
setblock 489 205 302 minecraft:light[level=13]
schedule function dropper:buildpart/70_9 1t
