fill 403 150 184 403 151 184 minecraft:mossy_cobblestone
setblock 404 150 182 minecraft:stone_bricks
fill 404 150 183 404 152 183 minecraft:mossy_cobblestone
setblock 404 150 222 minecraft:stone_bricks
fill 405 150 182 407 150 182 minecraft:mossy_cobblestone
fill 405 150 222 406 152 222 minecraft:mossy_cobblestone
fill 415 150 207 415 150 210 minecraft:mossy_cobblestone
setblock 415 150 211 minecraft:stone_bricks
fill 415 150 222 415 153 222 minecraft:mossy_cobblestone
fill 416 150 203 416 150 204 minecraft:mossy_cobblestone
setblock 416 150 205 minecraft:stone_bricks
fill 416 150 206 416 150 209 minecraft:mossy_cobblestone
setblock 416 150 210 minecraft:stone_bricks
fill 416 150 211 416 150 214 minecraft:mossy_cobblestone
setblock 416 150 215 minecraft:stone_bricks
setblock 417 150 184 minecraft:stone_bricks
fill 417 150 185 417 153 185 minecraft:mossy_cobblestone
setblock 417 150 189 minecraft:stone_bricks
fill 417 150 190 417 151 192 minecraft:mossy_cobblestone
setblock 417 150 199 minecraft:stone_bricks
fill 417 150 200 417 150 203 minecraft:mossy_cobblestone
setblock 417 150 204 minecraft:stone_bricks
fill 417 150 205 417 150 208 minecraft:mossy_cobblestone
setblock 417 150 209 minecraft:stone_bricks
fill 417 150 210 417 153 210 minecraft:mossy_cobblestone
fill 417 150 212 417 150 213 minecraft:mossy_cobblestone
setblock 417 150 214 minecraft:stone_bricks
fill 417 150 215 417 153 215 minecraft:mossy_cobblestone
setblock 417 150 219 minecraft:stone_bricks
fill 417 150 220 417 153 220 minecraft:mossy_cobblestone
fill 418 150 201 418 186 204 minecraft:mossy_cobblestone
setblock 377 151 182 minecraft:mossy_cobblestone
setblock 377 151 183 minecraft:stone_bricks
fill 377 151 184 377 154 184 minecraft:mossy_cobblestone
setblock 377 151 187 minecraft:mossy_cobblestone
setblock 377 151 188 minecraft:stone_bricks
fill 377 151 189 377 154 189 minecraft:mossy_cobblestone
setblock 377 151 192 minecraft:mossy_cobblestone
setblock 377 151 193 minecraft:stone_bricks
fill 377 151 194 377 151 197 minecraft:mossy_cobblestone
setblock 377 151 198 minecraft:stone_bricks
fill 377 151 199 377 151 202 minecraft:mossy_cobblestone
setblock 377 151 203 minecraft:stone_bricks
fill 377 151 204 377 151 207 minecraft:mossy_cobblestone
setblock 377 151 208 minecraft:stone_bricks
fill 377 151 209 377 154 209 minecraft:mossy_cobblestone
setblock 377 151 213 minecraft:stone_bricks
fill 377 151 214 377 154 214 minecraft:mossy_cobblestone
setblock 377 151 217 minecraft:mossy_cobblestone
setblock 378 151 182 minecraft:stone_bricks
fill 378 151 183 381 151 183 minecraft:mossy_cobblestone
setblock 378 151 187 minecraft:stone_bricks
fill 378 151 188 378 154 188 minecraft:mossy_cobblestone
setblock 378 151 192 minecraft:stone_bricks
fill 378 151 193 378 151 196 minecraft:mossy_cobblestone
setblock 378 151 197 minecraft:stone_bricks
fill 378 151 198 378 151 201 minecraft:mossy_cobblestone
setblock 378 151 202 minecraft:stone_bricks
fill 378 151 203 378 151 206 minecraft:mossy_cobblestone
setblock 378 151 207 minecraft:stone_bricks
fill 378 151 208 378 154 208 minecraft:mossy_cobblestone
setblock 378 151 212 minecraft:stone_bricks
fill 378 151 213 378 154 213 minecraft:mossy_cobblestone
fill 378 151 215 378 152 215 minecraft:mossy_cobblestone
fill 379 151 182 382 151 182 minecraft:mossy_cobblestone
setblock 379 151 185 minecraft:mossy_cobblestone
setblock 379 151 186 minecraft:stone_bricks
fill 379 151 187 379 154 187 minecraft:mossy_cobblestone
setblock 379 151 190 minecraft:mossy_cobblestone
setblock 379 151 191 minecraft:stone_bricks
fill 379 151 192 379 152 194 minecraft:mossy_cobblestone
fill 379 151 202 379 153 202 minecraft:mossy_cobblestone
setblock 379 151 206 minecraft:stone_bricks
fill 379 151 207 379 154 207 minecraft:mossy_cobblestone
setblock 379 151 211 minecraft:stone_bricks
fill 379 151 212 379 154 212 minecraft:mossy_cobblestone
setblock 380 151 208 minecraft:mossy_cobblestone
setblock 382 151 183 minecraft:stone_bricks
setblock 383 151 182 minecraft:stone_bricks
fill 384 151 182 384 154 182 minecraft:mossy_cobblestone
fill 390 151 182 392 151 182 minecraft:mossy_cobblestone
setblock 392 151 183 minecraft:stone_bricks
setblock 393 151 182 minecraft:stone_bricks
fill 393 151 183 396 151 183 minecraft:mossy_cobblestone
fill 394 151 182 397 151 182 minecraft:mossy_cobblestone
fill 394 151 184 395 151 184 minecraft:mossy_cobblestone
fill 395 151 222 397 151 222 minecraft:mossy_cobblestone
setblock 396 151 184 minecraft:stone_bricks
fill 396 151 185 399 151 185 minecraft:mossy_cobblestone
setblock 397 151 183 minecraft:stone_bricks
fill 397 151 184 397 154 184 minecraft:mossy_cobblestone
setblock 398 151 182 minecraft:stone_bricks
fill 398 151 183 401 151 183 minecraft:mossy_cobblestone
setblock 398 151 221 minecraft:mossy_cobblestone
setblock 398 151 222 minecraft:stone_bricks
fill 399 151 182 402 151 182 minecraft:mossy_cobblestone
setblock 399 151 221 minecraft:stone_bricks
fill 399 151 222 402 151 222 minecraft:mossy_cobblestone
setblock 400 151 185 minecraft:stone_bricks
fill 400 151 221 400 154 221 minecraft:mossy_cobblestone
setblock 401 151 184 minecraft:stone_bricks
setblock 402 151 183 minecraft:stone_bricks
fill 402 151 184 402 153 184 minecraft:mossy_cobblestone
setblock 403 151 182 minecraft:stone_bricks
fill 403 151 183 403 153 183 minecraft:mossy_cobblestone
setblock 403 151 222 minecraft:stone_bricks
fill 404 151 182 406 152 182 minecraft:mossy_cobblestone
fill 404 151 222 404 154 222 minecraft:mossy_cobblestone
fill 414 151 222 414 154 222 minecraft:mossy_cobblestone
fill 415 151 182 415 153 182 minecraft:mossy_cobblestone
fill 415 151 206 415 151 209 minecraft:mossy_cobblestone
setblock 415 151 210 minecraft:stone_bricks
fill 415 151 211 416 151 213 minecraft:mossy_cobblestone
fill 416 151 186 416 151 188 minecraft:mossy_cobblestone
setblock 416 151 203 minecraft:mossy_cobblestone
setblock 416 151 204 minecraft:stone_bricks
fill 416 151 205 416 151 208 minecraft:mossy_cobblestone
setblock 416 151 209 minecraft:stone_bricks
fill 416 151 210 416 154 210 minecraft:mossy_cobblestone
setblock 416 151 214 minecraft:stone_bricks
fill 416 151 215 416 152 217 minecraft:mossy_cobblestone
setblock 417 151 183 minecraft:stone_bricks
fill 417 151 184 417 154 184 minecraft:mossy_cobblestone
setblock 417 151 187 minecraft:mossy_cobblestone
setblock 417 151 188 minecraft:stone_bricks
fill 417 151 189 417 154 189 minecraft:mossy_cobblestone
setblock 417 151 193 minecraft:stone_bricks
fill 417 151 194 417 151 197 minecraft:mossy_cobblestone
setblock 417 151 198 minecraft:stone_bricks
fill 417 151 199 417 151 202 minecraft:mossy_cobblestone
setblock 417 151 203 minecraft:stone_bricks
fill 417 151 204 417 151 207 minecraft:mossy_cobblestone
setblock 417 151 208 minecraft:stone_bricks
fill 417 151 209 417 154 209 minecraft:mossy_cobblestone
setblock 417 151 212 minecraft:mossy_cobblestone
setblock 417 151 213 minecraft:stone_bricks
fill 417 151 214 417 154 214 minecraft:mossy_cobblestone
setblock 417 151 218 minecraft:stone_bricks
fill 417 151 219 417 154 219 minecraft:mossy_cobblestone
setblock 377 152 182 minecraft:stone_bricks
fill 377 152 183 380 152 183 minecraft:mossy_cobblestone
setblock 377 152 187 minecraft:stone_bricks
fill 377 152 188 377 155 188 minecraft:mossy_cobblestone
setblock 377 152 191 minecraft:mossy_cobblestone
setblock 377 152 192 minecraft:stone_bricks
fill 377 152 193 377 152 196 minecraft:mossy_cobblestone
setblock 377 152 197 minecraft:stone_bricks
fill 377 152 198 377 152 201 minecraft:mossy_cobblestone
setblock 377 152 202 minecraft:stone_bricks
fill 377 152 203 377 152 206 minecraft:mossy_cobblestone
setblock 377 152 207 minecraft:stone_bricks
fill 377 152 208 377 155 208 minecraft:mossy_cobblestone
setblock 377 152 212 minecraft:stone_bricks
fill 377 152 213 377 155 213 minecraft:mossy_cobblestone
setblock 377 152 217 minecraft:stone_bricks
fill 377 152 218 377 154 219 minecraft:mossy_cobblestone
fill 378 152 182 381 152 182 minecraft:mossy_cobblestone
setblock 378 152 186 minecraft:stone_bricks
fill 378 152 187 378 155 187 minecraft:mossy_cobblestone
setblock 378 152 191 minecraft:stone_bricks
fill 378 152 192 378 152 195 minecraft:mossy_cobblestone
setblock 378 152 196 minecraft:stone_bricks
fill 378 152 197 378 152 200 minecraft:mossy_cobblestone
setblock 378 152 201 minecraft:stone_bricks
fill 378 152 202 378 152 205 minecraft:mossy_cobblestone
setblock 378 152 206 minecraft:stone_bricks
fill 378 152 207 378 155 207 minecraft:mossy_cobblestone
setblock 378 152 211 minecraft:stone_bricks
fill 378 152 212 378 155 212 minecraft:mossy_cobblestone
setblock 378 152 216 minecraft:stone_bricks
setblock 379 152 185 minecraft:stone_bricks
fill 379 152 186 379 155 186 minecraft:mossy_cobblestone
setblock 379 152 190 minecraft:stone_bricks
fill 379 152 191 380 154 191 minecraft:mossy_cobblestone
setblock 379 152 195 minecraft:stone_bricks
fill 379 152 196 379 155 196 minecraft:mossy_cobblestone
setblock 379 152 205 minecraft:stone_bricks
fill 379 152 206 379 155 206 minecraft:mossy_cobblestone
setblock 379 152 210 minecraft:stone_bricks
fill 379 152 211 379 155 211 minecraft:mossy_cobblestone
fill 379 152 213 379 153 213 minecraft:mossy_cobblestone
setblock 380 152 188 minecraft:mossy_cobblestone
setblock 380 152 189 minecraft:stone_bricks
fill 380 152 190 380 155 190 minecraft:mossy_cobblestone
setblock 381 152 183 minecraft:stone_bricks
setblock 382 152 182 minecraft:stone_bricks
fill 382 152 183 382 153 183 minecraft:mossy_cobblestone
fill 383 152 182 383 155 182 minecraft:mossy_cobblestone
fill 385 152 182 385 153 182 minecraft:mossy_cobblestone
fill 389 152 182 391 152 182 minecraft:mossy_cobblestone
setblock 391 152 183 minecraft:stone_bricks
setblock 392 152 182 minecraft:stone_bricks
fill 392 152 183 395 152 183 minecraft:mossy_cobblestone
fill 393 152 182 396 152 182 minecraft:mossy_cobblestone
fill 393 152 184 394 152 184 minecraft:mossy_cobblestone
fill 394 152 222 396 152 222 minecraft:mossy_cobblestone
setblock 395 152 184 minecraft:stone_bricks
fill 395 152 185 398 152 185 minecraft:mossy_cobblestone
setblock 396 152 183 minecraft:stone_bricks
fill 396 152 184 396 155 184 minecraft:mossy_cobblestone
setblock 397 152 182 minecraft:stone_bricks
fill 397 152 183 400 152 183 minecraft:mossy_cobblestone
setblock 397 152 221 minecraft:mossy_cobblestone
setblock 397 152 222 minecraft:stone_bricks
fill 398 152 182 401 152 182 minecraft:mossy_cobblestone
setblock 398 152 221 minecraft:stone_bricks
fill 398 152 222 401 152 222 minecraft:mossy_cobblestone
setblock 399 152 185 minecraft:stone_bricks
fill 399 152 221 399 155 221 minecraft:mossy_cobblestone
setblock 400 152 184 minecraft:stone_bricks
setblock 400 152 185 minecraft:mossy_cobblestone
setblock 401 152 183 minecraft:stone_bricks
fill 401 152 184 401 154 184 minecraft:mossy_cobblestone
setblock 402 152 182 minecraft:stone_bricks
fill 402 152 183 402 155 183 minecraft:mossy_cobblestone
setblock 402 152 222 minecraft:stone_bricks
fill 403 152 182 403 155 182 minecraft:mossy_cobblestone
fill 403 152 222 403 155 222 minecraft:mossy_cobblestone
fill 413 152 222 413 155 222 minecraft:mossy_cobblestone
fill 415 152 205 415 152 208 minecraft:mossy_cobblestone
setblock 415 152 209 minecraft:stone_bricks
fill 415 152 210 415 152 213 minecraft:mossy_cobblestone
setblock 415 152 214 minecraft:stone_bricks
fill 415 152 215 415 155 215 minecraft:mossy_cobblestone
fill 416 152 185 416 152 187 minecraft:mossy_cobblestone
setblock 416 152 188 minecraft:stone_bricks
fill 416 152 189 416 152 192 minecraft:mossy_cobblestone
setblock 416 152 202 minecraft:mossy_cobblestone
setblock 416 152 203 minecraft:stone_bricks
fill 416 152 204 416 152 207 minecraft:mossy_cobblestone
setblock 416 152 208 minecraft:stone_bricks
fill 416 152 209 416 155 209 minecraft:mossy_cobblestone
fill 416 152 211 416 152 212 minecraft:mossy_cobblestone
setblock 416 152 213 minecraft:stone_bricks
fill 416 152 214 416 155 214 minecraft:mossy_cobblestone
setblock 416 152 218 minecraft:stone_bricks
fill 416 152 219 416 155 219 minecraft:mossy_cobblestone
setblock 417 152 182 minecraft:stone_bricks
fill 417 152 183 417 155 183 minecraft:mossy_cobblestone
setblock 417 152 187 minecraft:stone_bricks
fill 417 152 188 417 155 188 minecraft:mossy_cobblestone
fill 417 152 190 417 152 191 minecraft:mossy_cobblestone
setblock 417 152 192 minecraft:stone_bricks
fill 417 152 193 417 152 196 minecraft:mossy_cobblestone
setblock 417 152 197 minecraft:stone_bricks
fill 417 152 198 417 152 201 minecraft:mossy_cobblestone
setblock 417 152 202 minecraft:stone_bricks
fill 417 152 203 417 152 206 minecraft:mossy_cobblestone
setblock 417 152 207 minecraft:stone_bricks
fill 417 152 208 417 155 208 minecraft:mossy_cobblestone
setblock 417 152 212 minecraft:stone_bricks
fill 417 152 213 417 155 213 minecraft:mossy_cobblestone
setblock 417 152 217 minecraft:stone_bricks
fill 417 152 218 417 155 218 minecraft:mossy_cobblestone
setblock 417 152 222 minecraft:stone_bricks
fill 377 153 182 379 153 183 minecraft:mossy_cobblestone
setblock 377 153 186 minecraft:stone_bricks
fill 377 153 187 377 156 187 minecraft:mossy_cobblestone
setblock 377 153 191 minecraft:stone_bricks
fill 377 153 192 377 153 195 minecraft:mossy_cobblestone
setblock 377 153 196 minecraft:stone_bricks
fill 377 153 197 377 153 200 minecraft:mossy_cobblestone
setblock 377 153 201 minecraft:stone_bricks
fill 377 153 202 377 153 205 minecraft:mossy_cobblestone
setblock 377 153 206 minecraft:stone_bricks
fill 377 153 207 377 156 207 minecraft:mossy_cobblestone
setblock 377 153 211 minecraft:stone_bricks
fill 377 153 212 377 156 212 minecraft:mossy_cobblestone
setblock 377 153 215 minecraft:mossy_cobblestone
setblock 377 153 216 minecraft:stone_bricks
fill 377 153 217 378 155 217 minecraft:mossy_cobblestone
setblock 377 153 220 minecraft:mossy_cobblestone
setblock 378 153 185 minecraft:stone_bricks
fill 378 153 186 378 156 186 minecraft:mossy_cobblestone
setblock 378 153 189 minecraft:mossy_cobblestone
setblock 378 153 190 minecraft:stone_bricks
fill 378 153 191 378 153 194 minecraft:mossy_cobblestone
setblock 378 153 195 minecraft:stone_bricks
fill 378 153 196 378 153 199 minecraft:mossy_cobblestone
setblock 378 153 200 minecraft:stone_bricks
fill 378 153 201 378 153 204 minecraft:mossy_cobblestone
setblock 378 153 205 minecraft:stone_bricks
fill 378 153 206 378 156 206 minecraft:mossy_cobblestone
setblock 378 153 210 minecraft:stone_bricks
fill 378 153 211 378 156 211 minecraft:mossy_cobblestone
setblock 378 153 215 minecraft:stone_bricks
fill 378 153 216 378 156 216 minecraft:mossy_cobblestone
setblock 379 153 184 minecraft:light[level=12]
fill 379 153 185 379 154 185 minecraft:mossy_cobblestone
setblock 379 153 189 minecraft:stone_bricks
fill 379 153 190 379 156 190 minecraft:mossy_cobblestone
fill 379 153 192 379 153 193 minecraft:mossy_cobblestone
setblock 379 153 194 minecraft:stone_bricks
fill 379 153 195 379 156 195 minecraft:mossy_cobblestone
fill 379 153 197 379 153 198 minecraft:mossy_cobblestone
setblock 379 153 200 minecraft:light[level=12]
setblock 379 153 201 minecraft:mossy_cobblestone
setblock 379 153 204 minecraft:stone_bricks
fill 379 153 205 379 155 205 minecraft:mossy_cobblestone
setblock 379 153 209 minecraft:stone_bricks
fill 379 153 210 379 156 210 minecraft:mossy_cobblestone
setblock 379 153 214 minecraft:stone_bricks
setblock 379 153 216 minecraft:light[level=12]
setblock 380 153 182 minecraft:mossy_cobblestone
setblock 380 153 183 minecraft:stone_bricks
setblock 380 153 188 minecraft:stone_bricks
fill 380 153 189 380 156 189 minecraft:mossy_cobblestone
setblock 380 153 192 minecraft:mossy_cobblestone
setblock 380 153 193 minecraft:stone_bricks
setblock 381 153 182 minecraft:stone_bricks
fill 381 153 183 381 154 183 minecraft:mossy_cobblestone
fill 382 153 182 382 155 182 minecraft:mossy_cobblestone
setblock 387 153 184 minecraft:light[level=12]
setblock 387 153 192 minecraft:light[level=12]
setblock 387 153 200 minecraft:light[level=12]
setblock 387 153 208 minecraft:light[level=12]
setblock 387 153 216 minecraft:light[level=12]
fill 388 153 182 390 153 182 minecraft:mossy_cobblestone
setblock 391 153 182 minecraft:stone_bricks
fill 391 153 183 394 153 183 minecraft:mossy_cobblestone
fill 392 153 182 395 153 182 minecraft:mossy_cobblestone
setblock 393 153 184 minecraft:mossy_cobblestone
fill 393 153 222 395 153 222 minecraft:mossy_cobblestone
setblock 394 153 184 minecraft:stone_bricks
setblock 395 153 183 minecraft:stone_bricks
fill 395 153 184 395 155 185 minecraft:mossy_cobblestone
setblock 395 153 192 minecraft:light[level=12]
setblock 395 153 200 minecraft:light[level=12]
setblock 395 153 208 minecraft:light[level=12]
setblock 395 153 216 minecraft:light[level=12]
setblock 396 153 182 minecraft:stone_bricks
fill 396 153 183 399 153 183 minecraft:mossy_cobblestone
fill 396 153 185 397 153 185 minecraft:mossy_cobblestone
setblock 396 153 221 minecraft:mossy_cobblestone
setblock 396 153 222 minecraft:stone_bricks
fill 397 153 182 400 153 182 minecraft:mossy_cobblestone
setblock 397 153 221 minecraft:stone_bricks
fill 397 153 222 400 153 222 minecraft:mossy_cobblestone
setblock 398 153 185 minecraft:stone_bricks
fill 398 153 221 398 156 221 minecraft:mossy_cobblestone
setblock 399 153 184 minecraft:stone_bricks
fill 399 153 185 399 154 185 minecraft:mossy_cobblestone
setblock 400 153 183 minecraft:stone_bricks
fill 400 153 184 400 155 184 minecraft:mossy_cobblestone
setblock 401 153 182 minecraft:stone_bricks
fill 401 153 183 401 155 183 minecraft:mossy_cobblestone
setblock 401 153 222 minecraft:stone_bricks
fill 402 153 182 402 156 182 minecraft:mossy_cobblestone
setblock 402 153 221 minecraft:stone_bricks
fill 402 153 222 402 156 222 minecraft:mossy_cobblestone
setblock 403 153 184 minecraft:light[level=12]
setblock 403 153 192 minecraft:light[level=12]
setblock 403 153 200 minecraft:light[level=12]
setblock 403 153 208 minecraft:light[level=12]
setblock 403 153 216 minecraft:light[level=12]
fill 404 153 182 405 153 182 minecraft:mossy_cobblestone
setblock 405 153 222 minecraft:mossy_cobblestone
setblock 406 153 222 minecraft:stone_bricks
setblock 411 153 184 minecraft:light[level=12]
setblock 411 153 192 minecraft:light[level=12]
setblock 411 153 200 minecraft:light[level=12]
setblock 411 153 208 minecraft:light[level=12]
setblock 411 153 216 minecraft:light[level=12]
fill 412 153 222 412 156 222 minecraft:mossy_cobblestone
fill 414 153 182 414 154 182 minecraft:mossy_cobblestone
setblock 414 153 208 minecraft:mossy_cobblestone
setblock 414 153 209 minecraft:stone_bricks
fill 414 153 210 414 153 213 minecraft:mossy_cobblestone
fill 415 153 205 415 153 207 minecraft:mossy_cobblestone
setblock 415 153 208 minecraft:stone_bricks
fill 415 153 209 415 153 212 minecraft:mossy_cobblestone
setblock 415 153 213 minecraft:stone_bricks
fill 415 153 214 415 156 214 minecraft:mossy_cobblestone
fill 415 153 216 416 153 216 minecraft:mossy_cobblestone
setblock 416 153 182 minecraft:stone_bricks
fill 416 153 185 416 153 186 minecraft:mossy_cobblestone
setblock 416 153 187 minecraft:stone_bricks
fill 416 153 188 416 153 191 minecraft:mossy_cobblestone
setblock 416 153 192 minecraft:stone_bricks
fill 416 153 193 416 153 196 minecraft:mossy_cobblestone
fill 416 153 200 416 153 201 minecraft:mossy_cobblestone
setblock 416 153 202 minecraft:stone_bricks
fill 416 153 203 416 153 206 minecraft:mossy_cobblestone
setblock 416 153 207 minecraft:stone_bricks
fill 416 153 208 416 156 208 minecraft:mossy_cobblestone
setblock 416 153 211 minecraft:mossy_cobblestone
setblock 416 153 212 minecraft:stone_bricks
fill 416 153 213 416 156 213 minecraft:mossy_cobblestone
fill 416 153 215 416 154 215 minecraft:mossy_cobblestone
setblock 416 153 217 minecraft:stone_bricks
fill 416 153 218 416 156 218 minecraft:mossy_cobblestone
fill 416 153 220 416 154 220 minecraft:mossy_cobblestone
setblock 416 153 222 minecraft:stone_bricks
fill 417 153 182 417 156 182 minecraft:mossy_cobblestone
setblock 417 153 186 minecraft:stone_bricks
fill 417 153 187 417 156 187 minecraft:mossy_cobblestone
setblock 417 153 190 minecraft:mossy_cobblestone
setblock 417 153 191 minecraft:stone_bricks
fill 417 153 192 417 153 195 minecraft:mossy_cobblestone
setblock 417 153 196 minecraft:stone_bricks
fill 417 153 197 417 153 200 minecraft:mossy_cobblestone
setblock 417 153 201 minecraft:stone_bricks
fill 417 153 202 417 153 205 minecraft:mossy_cobblestone
setblock 417 153 206 minecraft:stone_bricks
fill 417 153 207 417 156 207 minecraft:mossy_cobblestone
setblock 417 153 211 minecraft:stone_bricks
fill 417 153 212 417 156 212 minecraft:mossy_cobblestone
setblock 417 153 216 minecraft:stone_bricks
fill 417 153 217 417 156 217 minecraft:mossy_cobblestone
setblock 417 153 221 minecraft:stone_bricks
fill 417 153 222 417 156 222 minecraft:mossy_cobblestone
fill 377 154 182 378 154 183 minecraft:mossy_cobblestone
setblock 377 154 185 minecraft:stone_bricks
fill 377 154 186 377 157 186 minecraft:mossy_cobblestone
setblock 377 154 190 minecraft:stone_bricks
fill 377 154 191 377 154 194 minecraft:mossy_cobblestone
setblock 377 154 195 minecraft:stone_bricks
fill 377 154 196 377 154 199 minecraft:mossy_cobblestone
setblock 377 154 200 minecraft:stone_bricks
fill 377 154 201 377 154 204 minecraft:mossy_cobblestone
setblock 377 154 205 minecraft:stone_bricks
fill 377 154 206 377 157 206 minecraft:mossy_cobblestone
setblock 377 154 210 minecraft:stone_bricks
fill 377 154 211 377 157 211 minecraft:mossy_cobblestone
setblock 377 154 215 minecraft:stone_bricks
fill 377 154 216 377 157 216 minecraft:mossy_cobblestone
setblock 377 154 220 minecraft:stone_bricks
fill 377 154 221 377 156 222 minecraft:mossy_cobblestone
setblock 378 154 184 minecraft:stone_bricks
fill 378 154 185 378 157 185 minecraft:mossy_cobblestone
setblock 378 154 189 minecraft:stone_bricks
fill 378 154 190 378 154 193 minecraft:mossy_cobblestone
setblock 378 154 194 minecraft:stone_bricks
fill 378 154 195 378 154 198 minecraft:mossy_cobblestone
setblock 378 154 199 minecraft:stone_bricks
fill 378 154 200 378 154 203 minecraft:mossy_cobblestone
setblock 378 154 204 minecraft:stone_bricks
fill 378 154 205 378 157 205 minecraft:mossy_cobblestone
setblock 378 154 209 minecraft:stone_bricks
fill 378 154 210 378 157 210 minecraft:mossy_cobblestone
setblock 378 154 214 minecraft:stone_bricks
fill 378 154 215 378 157 215 minecraft:mossy_cobblestone
setblock 379 154 182 minecraft:mossy_cobblestone
setblock 379 154 183 minecraft:stone_bricks
setblock 379 154 188 minecraft:stone_bricks
fill 379 154 189 379 157 189 minecraft:mossy_cobblestone
setblock 379 154 192 minecraft:mossy_cobblestone
setblock 379 154 193 minecraft:stone_bricks
fill 379 154 194 380 156 194 minecraft:mossy_cobblestone
setblock 379 154 197 minecraft:mossy_cobblestone
setblock 379 154 198 minecraft:stone_bricks
fill 379 154 199 379 156 199 minecraft:mossy_cobblestone
setblock 379 154 203 minecraft:stone_bricks
setblock 379 154 204 minecraft:mossy_cobblestone
setblock 379 154 208 minecraft:stone_bricks
fill 379 154 209 379 156 209 minecraft:mossy_cobblestone
setblock 379 154 213 minecraft:stone_bricks
fill 379 154 214 379 156 214 minecraft:mossy_cobblestone
setblock 380 154 182 minecraft:stone_bricks
setblock 380 154 183 minecraft:mossy_cobblestone
fill 380 154 188 380 155 188 minecraft:mossy_cobblestone
setblock 380 154 192 minecraft:stone_bricks
fill 380 154 193 380 157 193 minecraft:mossy_cobblestone
fill 381 154 182 381 156 182 minecraft:mossy_cobblestone
fill 388 154 182 389 154 182 minecraft:mossy_cobblestone
setblock 390 154 182 minecraft:stone_bricks
fill 391 154 182 393 154 183 minecraft:mossy_cobblestone
setblock 392 154 184 minecraft:mossy_cobblestone
setblock 393 154 184 minecraft:stone_bricks
fill 393 154 222 394 154 222 minecraft:mossy_cobblestone
setblock 394 154 182 minecraft:mossy_cobblestone
setblock 394 154 183 minecraft:stone_bricks
fill 394 154 184 394 157 184 minecraft:mossy_cobblestone
setblock 395 154 182 minecraft:stone_bricks
fill 395 154 183 398 154 183 minecraft:mossy_cobblestone
setblock 395 154 221 minecraft:mossy_cobblestone
setblock 395 154 222 minecraft:stone_bricks
fill 396 154 182 399 154 182 minecraft:mossy_cobblestone
setblock 396 154 185 minecraft:mossy_cobblestone
setblock 396 154 221 minecraft:stone_bricks
fill 396 154 222 399 154 222 minecraft:mossy_cobblestone
setblock 397 154 185 minecraft:stone_bricks
fill 397 154 221 397 157 221 minecraft:mossy_cobblestone
setblock 398 154 184 minecraft:stone_bricks
setblock 398 154 185 minecraft:mossy_cobblestone
setblock 399 154 183 minecraft:stone_bricks
fill 399 154 184 399 155 184 minecraft:mossy_cobblestone
setblock 400 154 182 minecraft:stone_bricks
fill 400 154 183 400 156 183 minecraft:mossy_cobblestone
setblock 400 154 222 minecraft:stone_bricks
fill 401 154 182 401 157 182 minecraft:mossy_cobblestone
setblock 401 154 221 minecraft:stone_bricks
fill 401 154 222 401 157 222 minecraft:mossy_cobblestone
fill 402 154 221 402 157 221 minecraft:mossy_cobblestone
setblock 404 154 182 minecraft:mossy_cobblestone
setblock 405 154 222 minecraft:stone_bricks
fill 406 154 222 406 155 222 minecraft:mossy_cobblestone
fill 411 154 222 411 157 222 minecraft:mossy_cobblestone
setblock 414 154 208 minecraft:stone_bricks
fill 414 154 209 414 154 212 minecraft:mossy_cobblestone
setblock 414 154 213 minecraft:stone_bricks
fill 414 154 214 414 156 215 minecraft:mossy_cobblestone
setblock 415 154 182 minecraft:stone_bricks
fill 415 154 204 415 154 206 minecraft:mossy_cobblestone
setblock 415 154 207 minecraft:stone_bricks
fill 415 154 208 415 154 211 minecraft:mossy_cobblestone
setblock 415 154 212 minecraft:stone_bricks
fill 415 154 213 415 157 213 minecraft:mossy_cobblestone
setblock 415 154 216 minecraft:mossy_cobblestone
setblock 415 154 217 minecraft:stone_bricks
fill 415 154 218 415 157 218 minecraft:mossy_cobblestone
setblock 415 154 222 minecraft:stone_bricks
fill 416 154 182 416 156 182 minecraft:mossy_cobblestone
setblock 416 154 185 minecraft:mossy_cobblestone
setblock 416 154 186 minecraft:stone_bricks
fill 416 154 187 416 154 190 minecraft:mossy_cobblestone
setblock 416 154 191 minecraft:stone_bricks
fill 416 154 192 416 154 195 minecraft:mossy_cobblestone
setblock 416 154 196 minecraft:stone_bricks
fill 416 154 197 416 154 200 minecraft:mossy_cobblestone
setblock 416 154 201 minecraft:stone_bricks
fill 416 154 202 416 154 205 minecraft:mossy_cobblestone
setblock 416 154 206 minecraft:stone_bricks
fill 416 154 207 416 157 207 minecraft:mossy_cobblestone
setblock 416 154 211 minecraft:stone_bricks
fill 416 154 212 416 157 212 minecraft:mossy_cobblestone
setblock 416 154 216 minecraft:stone_bricks
fill 416 154 217 416 157 217 minecraft:mossy_cobblestone
setblock 416 154 221 minecraft:stone_bricks
fill 416 154 222 416 157 222 minecraft:mossy_cobblestone
setblock 417 154 185 minecraft:stone_bricks
fill 417 154 186 417 157 186 minecraft:mossy_cobblestone
setblock 417 154 190 minecraft:stone_bricks
fill 417 154 191 417 154 194 minecraft:mossy_cobblestone
setblock 417 154 195 minecraft:stone_bricks
fill 417 154 196 417 154 199 minecraft:mossy_cobblestone
setblock 417 154 200 minecraft:stone_bricks
fill 417 154 201 417 154 204 minecraft:mossy_cobblestone
setblock 417 154 205 minecraft:stone_bricks
fill 417 154 206 417 157 206 minecraft:mossy_cobblestone
setblock 417 154 210 minecraft:stone_bricks
fill 417 154 211 417 157 211 minecraft:mossy_cobblestone
setblock 417 154 215 minecraft:stone_bricks
fill 417 154 216 417 157 216 minecraft:mossy_cobblestone
setblock 417 154 220 minecraft:stone_bricks
fill 417 154 221 417 157 221 minecraft:mossy_cobblestone
fill 377 155 182 377 155 183 minecraft:mossy_cobblestone
setblock 377 155 184 minecraft:stone_bricks
fill 377 155 185 377 158 185 minecraft:mossy_cobblestone
setblock 377 155 189 minecraft:stone_bricks
fill 377 155 190 377 155 193 minecraft:mossy_cobblestone
setblock 377 155 194 minecraft:stone_bricks
fill 377 155 195 377 155 198 minecraft:mossy_cobblestone
setblock 377 155 199 minecraft:stone_bricks
fill 377 155 200 377 155 203 minecraft:mossy_cobblestone
setblock 377 155 204 minecraft:stone_bricks
fill 377 155 205 377 158 205 minecraft:mossy_cobblestone
setblock 377 155 209 minecraft:stone_bricks
fill 377 155 210 377 158 210 minecraft:mossy_cobblestone
setblock 377 155 214 minecraft:stone_bricks
fill 377 155 215 377 158 215 minecraft:mossy_cobblestone
setblock 377 155 218 minecraft:mossy_cobblestone
setblock 377 155 219 minecraft:stone_bricks
fill 377 155 220 377 158 220 minecraft:mossy_cobblestone
setblock 378 155 182 minecraft:mossy_cobblestone
setblock 378 155 183 minecraft:stone_bricks
fill 378 155 184 378 156 184 minecraft:mossy_cobblestone
setblock 378 155 188 minecraft:stone_bricks
fill 378 155 189 378 155 192 minecraft:mossy_cobblestone
setblock 378 155 193 minecraft:stone_bricks
fill 378 155 194 378 155 197 minecraft:mossy_cobblestone
setblock 378 155 198 minecraft:stone_bricks
fill 378 155 199 378 155 202 minecraft:mossy_cobblestone
setblock 378 155 203 minecraft:stone_bricks
fill 378 155 204 378 157 204 minecraft:mossy_cobblestone
setblock 378 155 208 minecraft:stone_bricks
fill 378 155 209 378 158 209 minecraft:mossy_cobblestone
setblock 378 155 213 minecraft:stone_bricks
fill 378 155 214 378 158 214 minecraft:mossy_cobblestone
setblock 378 155 218 minecraft:stone_bricks
setblock 379 155 182 minecraft:stone_bricks
setblock 379 155 183 minecraft:mossy_cobblestone
setblock 379 155 187 minecraft:stone_bricks
fill 379 155 188 379 158 188 minecraft:mossy_cobblestone
setblock 379 155 191 minecraft:mossy_cobblestone
setblock 379 155 192 minecraft:stone_bricks
fill 379 155 193 379 158 193 minecraft:mossy_cobblestone
setblock 379 155 197 minecraft:stone_bricks
fill 379 155 198 379 158 198 minecraft:mossy_cobblestone
setblock 379 155 207 minecraft:stone_bricks
fill 379 155 208 379 156 208 minecraft:mossy_cobblestone
setblock 379 155 212 minecraft:stone_bricks
fill 379 155 213 379 156 213 minecraft:mossy_cobblestone
fill 380 155 182 380 156 182 minecraft:mossy_cobblestone
setblock 380 155 191 minecraft:stone_bricks
fill 380 155 192 380 157 192 minecraft:mossy_cobblestone
setblock 388 155 182 minecraft:mossy_cobblestone
setblock 389 155 182 minecraft:stone_bricks
fill 390 155 182 392 155 183 minecraft:mossy_cobblestone
setblock 392 155 184 minecraft:stone_bricks
fill 392 155 222 393 155 222 minecraft:mossy_cobblestone
setblock 393 155 182 minecraft:mossy_cobblestone
setblock 393 155 183 minecraft:stone_bricks
fill 393 155 184 393 157 184 minecraft:mossy_cobblestone
setblock 394 155 182 minecraft:stone_bricks
fill 394 155 183 397 155 183 minecraft:mossy_cobblestone
setblock 394 155 221 minecraft:mossy_cobblestone
setblock 394 155 222 minecraft:stone_bricks
fill 395 155 182 398 155 182 minecraft:mossy_cobblestone
setblock 395 155 221 minecraft:stone_bricks
fill 395 155 222 398 155 222 minecraft:mossy_cobblestone
setblock 396 155 185 minecraft:stone_bricks
fill 396 155 221 396 158 221 minecraft:mossy_cobblestone
setblock 397 155 184 minecraft:stone_bricks
setblock 397 155 185 minecraft:mossy_cobblestone
fill 397 155 220 399 156 220 minecraft:mossy_cobblestone
setblock 398 155 183 minecraft:stone_bricks
fill 398 155 184 398 156 184 minecraft:mossy_cobblestone
setblock 399 155 182 minecraft:stone_bricks
fill 399 155 183 399 157 183 minecraft:mossy_cobblestone
setblock 399 155 222 minecraft:stone_bricks
fill 400 155 182 400 158 182 minecraft:mossy_cobblestone
setblock 400 155 221 minecraft:stone_bricks
fill 400 155 222 400 158 222 minecraft:mossy_cobblestone
fill 401 155 221 401 158 221 minecraft:mossy_cobblestone
setblock 404 155 182 minecraft:stone_bricks
setblock 404 155 222 minecraft:stone_bricks
fill 405 155 222 405 156 222 minecraft:mossy_cobblestone
fill 410 155 222 410 158 222 minecraft:mossy_cobblestone
setblock 414 155 182 minecraft:stone_bricks
fill 414 155 208 414 155 211 minecraft:mossy_cobblestone
setblock 414 155 212 minecraft:stone_bricks
fill 414 155 213 414 158 213 minecraft:mossy_cobblestone
setblock 414 155 216 minecraft:mossy_cobblestone
setblock 414 155 221 minecraft:mossy_cobblestone
setblock 414 155 222 minecraft:stone_bricks
fill 415 155 182 415 156 182 minecraft:mossy_cobblestone
fill 415 155 189 415 155 190 minecraft:mossy_cobblestone
setblock 415 155 191 minecraft:stone_bricks
fill 415 155 192 416 155 194 minecraft:mossy_cobblestone
fill 415 155 204 415 155 205 minecraft:mossy_cobblestone
setblock 415 155 206 minecraft:stone_bricks
fill 415 155 207 415 155 210 minecraft:mossy_cobblestone
setblock 415 155 211 minecraft:stone_bricks
fill 415 155 212 415 158 212 minecraft:mossy_cobblestone
setblock 415 155 216 minecraft:stone_bricks
fill 415 155 217 415 158 217 minecraft:mossy_cobblestone
setblock 415 155 221 minecraft:stone_bricks
fill 415 155 222 415 158 222 minecraft:mossy_cobblestone
setblock 416 155 185 minecraft:stone_bricks
fill 416 155 186 416 155 189 minecraft:mossy_cobblestone
setblock 416 155 190 minecraft:stone_bricks
fill 416 155 191 417 157 191 minecraft:mossy_cobblestone
setblock 416 155 195 minecraft:stone_bricks
fill 416 155 196 416 155 199 minecraft:mossy_cobblestone
setblock 416 155 200 minecraft:stone_bricks
fill 416 155 201 416 155 204 minecraft:mossy_cobblestone
setblock 416 155 205 minecraft:stone_bricks
fill 416 155 206 416 158 206 minecraft:mossy_cobblestone
setblock 416 155 210 minecraft:stone_bricks
fill 416 155 211 416 158 211 minecraft:mossy_cobblestone
setblock 416 155 215 minecraft:stone_bricks
fill 416 155 216 416 158 216 minecraft:mossy_cobblestone
setblock 416 155 220 minecraft:stone_bricks
fill 416 155 221 416 158 221 minecraft:mossy_cobblestone
setblock 417 155 184 minecraft:stone_bricks
fill 417 155 185 417 158 185 minecraft:mossy_cobblestone
setblock 417 155 189 minecraft:stone_bricks
fill 417 155 190 417 158 190 minecraft:mossy_cobblestone
fill 417 155 192 417 155 193 minecraft:mossy_cobblestone
setblock 417 155 194 minecraft:stone_bricks
fill 417 155 195 417 155 198 minecraft:mossy_cobblestone
setblock 417 155 199 minecraft:stone_bricks
fill 417 155 200 417 155 203 minecraft:mossy_cobblestone
setblock 417 155 204 minecraft:stone_bricks
fill 417 155 205 417 158 205 minecraft:mossy_cobblestone
setblock 417 155 209 minecraft:stone_bricks
fill 417 155 210 417 158 210 minecraft:mossy_cobblestone
setblock 417 155 214 minecraft:stone_bricks
fill 417 155 215 417 158 215 minecraft:mossy_cobblestone
setblock 417 155 219 minecraft:stone_bricks
fill 417 155 220 417 158 220 minecraft:mossy_cobblestone
setblock 377 156 182 minecraft:mossy_cobblestone
setblock 377 156 183 minecraft:stone_bricks
fill 377 156 184 377 159 184 minecraft:mossy_cobblestone
setblock 377 156 188 minecraft:stone_bricks
fill 377 156 189 377 156 192 minecraft:mossy_cobblestone
setblock 377 156 193 minecraft:stone_bricks
fill 377 156 194 377 156 197 minecraft:mossy_cobblestone
setblock 377 156 198 minecraft:stone_bricks
fill 377 156 199 377 156 202 minecraft:mossy_cobblestone
setblock 377 156 203 minecraft:stone_bricks
fill 377 156 204 377 159 204 minecraft:mossy_cobblestone
setblock 377 156 208 minecraft:stone_bricks
fill 377 156 209 377 159 209 minecraft:mossy_cobblestone
setblock 377 156 213 minecraft:stone_bricks
fill 377 156 214 377 159 214 minecraft:mossy_cobblestone
setblock 377 156 217 minecraft:mossy_cobblestone
setblock 377 156 218 minecraft:stone_bricks
fill 377 156 219 377 159 219 minecraft:mossy_cobblestone
setblock 378 156 182 minecraft:stone_bricks
setblock 378 156 187 minecraft:stone_bricks
fill 378 156 188 378 156 191 minecraft:mossy_cobblestone
setblock 378 156 192 minecraft:stone_bricks
fill 378 156 193 378 156 196 minecraft:mossy_cobblestone
setblock 378 156 197 minecraft:stone_bricks
fill 378 156 198 378 156 201 minecraft:mossy_cobblestone
setblock 378 156 202 minecraft:stone_bricks
fill 378 156 203 378 157 203 minecraft:mossy_cobblestone
setblock 378 156 207 minecraft:stone_bricks
fill 378 156 208 378 158 208 minecraft:mossy_cobblestone
setblock 378 156 212 minecraft:stone_bricks
fill 378 156 213 378 159 213 minecraft:mossy_cobblestone
setblock 378 156 217 minecraft:stone_bricks
setblock 378 156 218 minecraft:mossy_cobblestone
fill 379 156 182 379 157 182 minecraft:mossy_cobblestone
setblock 379 156 186 minecraft:stone_bricks
fill 379 156 187 379 157 187 minecraft:mossy_cobblestone
setblock 379 156 191 minecraft:stone_bricks
fill 379 156 192 379 159 192 minecraft:mossy_cobblestone
setblock 379 156 196 minecraft:stone_bricks
fill 379 156 197 379 159 197 minecraft:mossy_cobblestone
setblock 379 156 211 minecraft:stone_bricks
setblock 379 156 212 minecraft:mossy_cobblestone
setblock 380 156 190 minecraft:stone_bricks
fill 380 156 191 380 157 191 minecraft:mossy_cobblestone
setblock 388 156 182 minecraft:stone_bricks
fill 389 156 182 392 156 182 minecraft:mossy_cobblestone
setblock 391 156 183 minecraft:mossy_cobblestone
fill 391 156 222 392 156 222 minecraft:mossy_cobblestone
setblock 392 156 183 minecraft:stone_bricks
setblock 393 156 182 minecraft:stone_bricks
fill 393 156 183 396 156 183 minecraft:mossy_cobblestone
setblock 393 156 221 minecraft:mossy_cobblestone
setblock 393 156 222 minecraft:stone_bricks
fill 394 156 182 397 156 182 minecraft:mossy_cobblestone
setblock 394 156 221 minecraft:stone_bricks
fill 394 156 222 397 156 222 minecraft:mossy_cobblestone
setblock 395 156 184 minecraft:mossy_cobblestone
fill 395 156 221 395 159 221 minecraft:mossy_cobblestone
setblock 396 156 184 minecraft:stone_bricks
fill 396 156 220 396 159 220 minecraft:mossy_cobblestone
setblock 397 156 183 minecraft:stone_bricks
fill 397 156 184 397 157 184 minecraft:mossy_cobblestone
setblock 398 156 182 minecraft:stone_bricks
fill 398 156 183 398 158 183 minecraft:mossy_cobblestone
setblock 398 156 222 minecraft:stone_bricks
fill 399 156 182 399 159 182 minecraft:mossy_cobblestone
setblock 399 156 221 minecraft:stone_bricks
fill 399 156 222 399 159 222 minecraft:mossy_cobblestone
fill 400 156 221 400 159 221 minecraft:mossy_cobblestone
setblock 403 156 222 minecraft:stone_bricks
fill 404 156 222 404 158 222 minecraft:mossy_cobblestone
setblock 413 156 221 minecraft:mossy_cobblestone
setblock 413 156 222 minecraft:stone_bricks
fill 414 156 208 414 156 210 minecraft:mossy_cobblestone
setblock 414 156 211 minecraft:stone_bricks
fill 414 156 212 414 159 212 minecraft:mossy_cobblestone
setblock 414 156 216 minecraft:stone_bricks
setblock 414 156 221 minecraft:stone_bricks
fill 414 156 222 414 159 222 minecraft:mossy_cobblestone
setblock 415 156 189 minecraft:mossy_cobblestone
setblock 415 156 190 minecraft:stone_bricks
fill 415 156 191 415 156 194 minecraft:mossy_cobblestone
setblock 415 156 195 minecraft:stone_bricks
fill 415 156 196 417 157 196 minecraft:mossy_cobblestone
setblock 415 156 204 minecraft:mossy_cobblestone
setblock 415 156 205 minecraft:stone_bricks
fill 415 156 206 415 156 209 minecraft:mossy_cobblestone
setblock 415 156 210 minecraft:stone_bricks
fill 415 156 211 415 159 211 minecraft:mossy_cobblestone
setblock 415 156 215 minecraft:stone_bricks
fill 415 156 216 415 159 216 minecraft:mossy_cobblestone
setblock 415 156 219 minecraft:mossy_cobblestone
fill 415 156 221 415 159 221 minecraft:mossy_cobblestone
fill 416 156 186 416 156 188 minecraft:mossy_cobblestone
setblock 416 156 189 minecraft:stone_bricks
fill 416 156 190 416 159 190 minecraft:mossy_cobblestone
fill 416 156 192 416 156 193 minecraft:mossy_cobblestone
setblock 416 156 194 minecraft:stone_bricks
fill 416 156 195 417 158 195 minecraft:mossy_cobblestone
fill 416 156 197 416 156 198 minecraft:mossy_cobblestone
setblock 416 156 199 minecraft:stone_bricks
fill 416 156 200 416 156 203 minecraft:mossy_cobblestone
setblock 416 156 204 minecraft:stone_bricks
fill 416 156 205 416 159 205 minecraft:mossy_cobblestone
setblock 416 156 209 minecraft:stone_bricks
fill 416 156 210 416 159 210 minecraft:mossy_cobblestone
setblock 416 156 214 minecraft:stone_bricks
fill 416 156 215 416 159 215 minecraft:mossy_cobblestone
setblock 416 156 219 minecraft:stone_bricks
fill 416 156 220 416 159 220 minecraft:mossy_cobblestone
setblock 417 156 183 minecraft:stone_bricks
fill 417 156 184 417 157 184 minecraft:mossy_cobblestone
setblock 417 156 188 minecraft:stone_bricks
fill 417 156 189 417 159 189 minecraft:mossy_cobblestone
setblock 417 156 192 minecraft:mossy_cobblestone
setblock 417 156 193 minecraft:stone_bricks
fill 417 156 194 417 159 194 minecraft:mossy_cobblestone
setblock 417 156 197 minecraft:mossy_cobblestone
setblock 417 156 198 minecraft:stone_bricks
fill 417 156 199 417 156 202 minecraft:mossy_cobblestone
setblock 417 156 203 minecraft:stone_bricks
fill 417 156 204 417 159 204 minecraft:mossy_cobblestone
setblock 417 156 208 minecraft:stone_bricks
fill 417 156 209 417 159 209 minecraft:mossy_cobblestone
setblock 417 156 213 minecraft:stone_bricks
fill 417 156 214 417 159 214 minecraft:mossy_cobblestone
setblock 417 156 218 minecraft:stone_bricks
fill 417 156 219 417 159 219 minecraft:mossy_cobblestone
setblock 377 157 182 minecraft:stone_bricks
fill 377 157 183 377 158 183 minecraft:mossy_cobblestone
setblock 377 157 187 minecraft:stone_bricks
fill 377 157 188 377 157 191 minecraft:mossy_cobblestone
setblock 377 157 192 minecraft:stone_bricks
fill 377 157 193 377 157 196 minecraft:mossy_cobblestone
setblock 377 157 197 minecraft:stone_bricks
fill 377 157 198 377 157 201 minecraft:mossy_cobblestone
setblock 377 157 202 minecraft:stone_bricks
fill 377 157 203 377 160 203 minecraft:mossy_cobblestone
setblock 377 157 207 minecraft:stone_bricks
fill 377 157 208 377 160 208 minecraft:mossy_cobblestone
setblock 377 157 212 minecraft:stone_bricks
fill 377 157 213 377 160 213 minecraft:mossy_cobblestone
setblock 377 157 217 minecraft:stone_bricks
fill 377 157 218 377 160 218 minecraft:mossy_cobblestone
setblock 377 157 221 minecraft:mossy_cobblestone
fill 378 157 182 378 158 182 minecraft:mossy_cobblestone
setblock 378 157 186 minecraft:stone_bricks
fill 378 157 187 378 157 190 minecraft:mossy_cobblestone
setblock 378 157 191 minecraft:stone_bricks
fill 378 157 192 378 157 195 minecraft:mossy_cobblestone
setblock 378 157 196 minecraft:stone_bricks
fill 378 157 197 378 157 200 minecraft:mossy_cobblestone
setblock 378 157 201 minecraft:stone_bricks
fill 378 157 202 378 158 202 minecraft:mossy_cobblestone
setblock 378 157 206 minecraft:stone_bricks
fill 378 157 207 378 158 207 minecraft:mossy_cobblestone
setblock 378 157 211 minecraft:stone_bricks
fill 378 157 212 378 159 212 minecraft:mossy_cobblestone
setblock 378 157 216 minecraft:stone_bricks
fill 378 157 217 378 158 217 minecraft:mossy_cobblestone
setblock 379 157 190 minecraft:stone_bricks
fill 379 157 191 379 160 191 minecraft:mossy_cobblestone
setblock 379 157 194 minecraft:mossy_cobblestone
setblock 379 157 195 minecraft:stone_bricks
fill 379 157 196 379 160 196 minecraft:mossy_cobblestone
setblock 380 157 194 minecraft:stone_bricks
fill 389 157 182 391 157 182 minecraft:mossy_cobblestone
setblock 391 157 183 minecraft:stone_bricks
setblock 391 157 222 minecraft:mossy_cobblestone
setblock 392 157 182 minecraft:stone_bricks
fill 392 157 183 395 157 183 minecraft:mossy_cobblestone
setblock 392 157 221 minecraft:mossy_cobblestone
setblock 392 157 222 minecraft:stone_bricks
fill 393 157 182 396 157 182 minecraft:mossy_cobblestone
setblock 393 157 221 minecraft:stone_bricks
fill 393 157 222 396 157 222 minecraft:mossy_cobblestone
fill 394 157 221 394 160 221 minecraft:mossy_cobblestone
setblock 395 157 184 minecraft:stone_bricks
fill 395 157 220 395 160 220 minecraft:mossy_cobblestone
setblock 396 157 183 minecraft:stone_bricks
setblock 396 157 184 minecraft:mossy_cobblestone
setblock 397 157 182 minecraft:stone_bricks
fill 397 157 183 397 158 183 minecraft:mossy_cobblestone
fill 397 157 220 398 157 220 minecraft:mossy_cobblestone
setblock 397 157 222 minecraft:stone_bricks
fill 398 157 182 398 160 182 minecraft:mossy_cobblestone
setblock 398 157 221 minecraft:stone_bricks
fill 398 157 222 398 160 222 minecraft:mossy_cobblestone
setblock 399 157 220 minecraft:stone_bricks
fill 399 157 221 399 160 221 minecraft:mossy_cobblestone
setblock 402 157 222 minecraft:stone_bricks
fill 403 157 222 403 159 222 minecraft:mossy_cobblestone
fill 409 157 222 409 159 222 minecraft:mossy_cobblestone
setblock 412 157 222 minecraft:stone_bricks
setblock 413 157 221 minecraft:stone_bricks
fill 413 157 222 413 160 222 minecraft:mossy_cobblestone
setblock 414 157 209 minecraft:mossy_cobblestone
setblock 414 157 210 minecraft:stone_bricks
fill 414 157 211 414 159 211 minecraft:mossy_cobblestone
setblock 414 157 214 minecraft:mossy_cobblestone
setblock 414 157 215 minecraft:stone_bricks
fill 414 157 216 414 159 216 minecraft:mossy_cobblestone
fill 414 157 221 414 160 221 minecraft:mossy_cobblestone
fill 415 157 190 415 157 193 minecraft:mossy_cobblestone
setblock 415 157 194 minecraft:stone_bricks
fill 415 157 195 415 160 195 minecraft:mossy_cobblestone
fill 415 157 197 416 157 197 minecraft:mossy_cobblestone
fill 415 157 205 415 157 208 minecraft:mossy_cobblestone
setblock 415 157 209 minecraft:stone_bricks
fill 415 157 210 415 160 210 minecraft:mossy_cobblestone
setblock 415 157 214 minecraft:stone_bricks
fill 415 157 215 415 160 215 minecraft:mossy_cobblestone
setblock 415 157 219 minecraft:stone_bricks
setblock 416 157 187 minecraft:mossy_cobblestone
setblock 416 157 188 minecraft:stone_bricks
fill 416 157 189 416 159 189 minecraft:mossy_cobblestone
setblock 416 157 192 minecraft:mossy_cobblestone
setblock 416 157 193 minecraft:stone_bricks
fill 416 157 194 416 160 194 minecraft:mossy_cobblestone
setblock 416 157 198 minecraft:stone_bricks
fill 416 157 199 416 157 202 minecraft:mossy_cobblestone
setblock 416 157 203 minecraft:stone_bricks
fill 416 157 204 416 160 204 minecraft:mossy_cobblestone
setblock 416 157 208 minecraft:stone_bricks
fill 416 157 209 416 160 209 minecraft:mossy_cobblestone
setblock 416 157 213 minecraft:stone_bricks
fill 416 157 214 416 160 214 minecraft:mossy_cobblestone
setblock 416 157 218 minecraft:stone_bricks
fill 416 157 219 416 160 219 minecraft:mossy_cobblestone
setblock 417 157 183 minecraft:mossy_cobblestone
setblock 417 157 187 minecraft:stone_bricks
fill 417 157 188 417 160 188 minecraft:mossy_cobblestone
setblock 417 157 192 minecraft:stone_bricks
fill 417 157 193 417 160 193 minecraft:mossy_cobblestone
setblock 417 157 197 minecraft:stone_bricks
fill 417 157 198 417 157 201 minecraft:mossy_cobblestone
setblock 417 157 202 minecraft:stone_bricks
fill 417 157 203 417 160 203 minecraft:mossy_cobblestone
setblock 417 157 207 minecraft:stone_bricks
fill 417 157 208 417 160 208 minecraft:mossy_cobblestone
setblock 417 157 212 minecraft:stone_bricks
fill 417 157 213 417 160 213 minecraft:mossy_cobblestone
setblock 417 157 217 minecraft:stone_bricks
fill 417 157 218 417 160 218 minecraft:mossy_cobblestone
setblock 417 157 222 minecraft:stone_bricks
setblock 377 158 182 minecraft:mossy_cobblestone
setblock 377 158 186 minecraft:stone_bricks
fill 377 158 187 377 158 190 minecraft:mossy_cobblestone
setblock 377 158 191 minecraft:stone_bricks
fill 377 158 192 377 158 195 minecraft:mossy_cobblestone
setblock 377 158 196 minecraft:stone_bricks
fill 377 158 197 377 158 200 minecraft:mossy_cobblestone
setblock 377 158 201 minecraft:stone_bricks
fill 377 158 202 377 161 202 minecraft:mossy_cobblestone
setblock 377 158 206 minecraft:stone_bricks
fill 377 158 207 377 160 207 minecraft:mossy_cobblestone
setblock 377 158 211 minecraft:stone_bricks
fill 377 158 212 377 161 212 minecraft:mossy_cobblestone
setblock 377 158 216 minecraft:stone_bricks
fill 377 158 217 377 161 217 minecraft:mossy_cobblestone
setblock 377 158 221 minecraft:stone_bricks
fill 378 158 186 378 158 189 minecraft:mossy_cobblestone
setblock 378 158 190 minecraft:stone_bricks
fill 378 158 191 378 158 194 minecraft:mossy_cobblestone
setblock 378 158 195 minecraft:stone_bricks
fill 378 158 196 378 158 199 minecraft:mossy_cobblestone
setblock 378 158 200 minecraft:stone_bricks
fill 378 158 201 378 159 201 minecraft:mossy_cobblestone
setblock 378 158 210 minecraft:stone_bricks
fill 378 158 211 378 159 211 minecraft:mossy_cobblestone
setblock 378 158 215 minecraft:stone_bricks
fill 378 158 216 378 159 216 minecraft:mossy_cobblestone
setblock 379 158 189 minecraft:stone_bricks
fill 379 158 190 379 159 190 minecraft:mossy_cobblestone
setblock 379 158 194 minecraft:stone_bricks
fill 379 158 195 379 161 195 minecraft:mossy_cobblestone
fill 389 158 182 390 158 182 minecraft:mossy_cobblestone
setblock 390 158 222 minecraft:mossy_cobblestone
setblock 391 158 182 minecraft:stone_bricks
fill 391 158 183 394 158 183 minecraft:mossy_cobblestone
setblock 391 158 222 minecraft:stone_bricks
fill 392 158 182 395 158 182 minecraft:mossy_cobblestone
setblock 392 158 221 minecraft:stone_bricks
fill 392 158 222 395 158 222 minecraft:mossy_cobblestone
fill 393 158 221 393 161 221 minecraft:mossy_cobblestone
fill 394 158 220 394 161 220 minecraft:mossy_cobblestone
setblock 395 158 183 minecraft:stone_bricks
setblock 396 158 182 minecraft:stone_bricks
fill 396 158 183 396 159 183 minecraft:mossy_cobblestone
setblock 396 158 222 minecraft:stone_bricks
fill 397 158 182 397 161 182 minecraft:mossy_cobblestone
setblock 397 158 220 minecraft:mossy_cobblestone
setblock 397 158 221 minecraft:stone_bricks
fill 397 158 222 397 161 222 minecraft:mossy_cobblestone
setblock 398 158 220 minecraft:stone_bricks
fill 398 158 221 398 161 221 minecraft:mossy_cobblestone
setblock 399 158 220 minecraft:mossy_cobblestone
setblock 401 158 222 minecraft:stone_bricks
fill 402 158 222 402 161 222 minecraft:mossy_cobblestone
setblock 411 158 222 minecraft:stone_bricks
setblock 412 158 221 minecraft:stone_bricks
fill 412 158 222 412 161 222 minecraft:mossy_cobblestone
fill 413 158 221 413 161 221 minecraft:mossy_cobblestone
setblock 414 158 210 minecraft:mossy_cobblestone
setblock 414 158 214 minecraft:stone_bricks
fill 414 158 215 414 160 215 minecraft:mossy_cobblestone
fill 415 158 191 415 158 192 minecraft:mossy_cobblestone
setblock 415 158 193 minecraft:stone_bricks
fill 415 158 194 415 161 194 minecraft:mossy_cobblestone
fill 415 158 196 415 158 197 minecraft:mossy_cobblestone
setblock 415 158 198 minecraft:stone_bricks
fill 415 158 206 415 158 207 minecraft:mossy_cobblestone
setblock 415 158 208 minecraft:stone_bricks
fill 415 158 209 415 160 209 minecraft:mossy_cobblestone
setblock 415 158 213 minecraft:stone_bricks
fill 415 158 214 415 161 214 minecraft:mossy_cobblestone
setblock 415 158 218 minecraft:stone_bricks
setblock 415 158 219 minecraft:mossy_cobblestone
setblock 416 158 188 minecraft:mossy_cobblestone
setblock 416 158 191 minecraft:mossy_cobblestone
setblock 416 158 192 minecraft:stone_bricks
fill 416 158 193 416 161 193 minecraft:mossy_cobblestone
setblock 416 158 196 minecraft:mossy_cobblestone
setblock 416 158 197 minecraft:stone_bricks
fill 416 158 198 416 158 201 minecraft:mossy_cobblestone
setblock 416 158 202 minecraft:stone_bricks
fill 416 158 203 416 161 203 minecraft:mossy_cobblestone
setblock 416 158 207 minecraft:stone_bricks
fill 416 158 208 416 161 208 minecraft:mossy_cobblestone
setblock 416 158 212 minecraft:stone_bricks
fill 416 158 213 416 161 213 minecraft:mossy_cobblestone
setblock 416 158 217 minecraft:stone_bricks
fill 416 158 218 416 161 218 minecraft:mossy_cobblestone
setblock 416 158 222 minecraft:stone_bricks
setblock 417 158 186 minecraft:stone_bricks
fill 417 158 187 417 159 187 minecraft:mossy_cobblestone
setblock 417 158 191 minecraft:stone_bricks
fill 417 158 192 417 161 192 minecraft:mossy_cobblestone
setblock 417 158 196 minecraft:stone_bricks
fill 417 158 197 417 158 200 minecraft:mossy_cobblestone
setblock 417 158 201 minecraft:stone_bricks
fill 417 158 202 417 161 202 minecraft:mossy_cobblestone
setblock 417 158 206 minecraft:stone_bricks
fill 417 158 207 417 161 207 minecraft:mossy_cobblestone
setblock 417 158 211 minecraft:stone_bricks
fill 417 158 212 417 161 212 minecraft:mossy_cobblestone
setblock 417 158 216 minecraft:stone_bricks
fill 417 158 217 417 161 217 minecraft:mossy_cobblestone
setblock 417 158 221 minecraft:stone_bricks
fill 417 158 222 417 159 222 minecraft:mossy_cobblestone
setblock 377 159 185 minecraft:stone_bricks
fill 377 159 186 377 159 189 minecraft:mossy_cobblestone
setblock 377 159 190 minecraft:stone_bricks
fill 377 159 191 377 159 194 minecraft:mossy_cobblestone
setblock 377 159 195 minecraft:stone_bricks
fill 377 159 196 377 159 199 minecraft:mossy_cobblestone
setblock 377 159 200 minecraft:stone_bricks
fill 377 159 201 377 162 201 minecraft:mossy_cobblestone
setblock 377 159 205 minecraft:stone_bricks
fill 377 159 206 377 160 206 minecraft:mossy_cobblestone
setblock 377 159 210 minecraft:stone_bricks
fill 377 159 211 377 161 211 minecraft:mossy_cobblestone
setblock 377 159 215 minecraft:stone_bricks
fill 377 159 216 377 162 216 minecraft:mossy_cobblestone
setblock 377 159 220 minecraft:stone_bricks
fill 378 159 187 378 159 188 minecraft:mossy_cobblestone
setblock 378 159 189 minecraft:stone_bricks
fill 378 159 190 378 159 193 minecraft:mossy_cobblestone
setblock 378 159 194 minecraft:stone_bricks
fill 378 159 195 378 159 198 minecraft:mossy_cobblestone
setblock 378 159 199 minecraft:stone_bricks
fill 378 159 200 378 161 200 minecraft:mossy_cobblestone
setblock 378 159 214 minecraft:stone_bricks
setblock 378 159 215 minecraft:mossy_cobblestone
setblock 379 159 193 minecraft:stone_bricks
fill 379 159 194 379 161 194 minecraft:mossy_cobblestone
setblock 389 159 182 minecraft:mossy_cobblestone
setblock 390 159 182 minecraft:stone_bricks
setblock 390 159 222 minecraft:stone_bricks
fill 391 159 182 393 159 183 minecraft:mossy_cobblestone
setblock 391 159 221 minecraft:stone_bricks
fill 391 159 222 394 159 222 minecraft:mossy_cobblestone
fill 392 159 221 392 162 221 minecraft:mossy_cobblestone
fill 393 159 220 393 162 220 minecraft:mossy_cobblestone
setblock 394 159 182 minecraft:mossy_cobblestone
setblock 394 159 183 minecraft:stone_bricks
setblock 395 159 182 minecraft:stone_bricks
fill 395 159 183 395 160 183 minecraft:mossy_cobblestone
setblock 395 159 222 minecraft:stone_bricks
fill 396 159 182 396 162 182 minecraft:mossy_cobblestone
setblock 396 159 221 minecraft:stone_bricks
fill 396 159 222 396 162 222 minecraft:mossy_cobblestone
setblock 397 159 220 minecraft:stone_bricks
fill 397 159 221 397 162 221 minecraft:mossy_cobblestone
fill 398 159 220 398 160 220 minecraft:mossy_cobblestone
setblock 400 159 222 minecraft:stone_bricks
fill 401 159 222 401 162 222 minecraft:mossy_cobblestone
setblock 410 159 222 minecraft:stone_bricks
fill 411 159 222 411 162 222 minecraft:mossy_cobblestone
fill 412 159 221 412 162 221 minecraft:mossy_cobblestone
setblock 414 159 213 minecraft:stone_bricks
fill 414 159 214 414 160 214 minecraft:mossy_cobblestone
setblock 415 159 192 minecraft:stone_bricks
fill 415 159 193 415 161 193 minecraft:mossy_cobblestone
setblock 415 159 196 minecraft:mossy_cobblestone
setblock 415 159 197 minecraft:stone_bricks
fill 415 159 198 417 159 199 minecraft:mossy_cobblestone
setblock 415 159 207 minecraft:stone_bricks
setblock 415 159 208 minecraft:mossy_cobblestone
setblock 415 159 212 minecraft:stone_bricks
fill 415 159 213 415 161 213 minecraft:mossy_cobblestone
setblock 415 159 217 minecraft:stone_bricks
fill 415 159 218 415 161 218 minecraft:mossy_cobblestone
setblock 415 159 222 minecraft:stone_bricks
setblock 416 159 191 minecraft:stone_bricks
fill 416 159 192 416 162 192 minecraft:mossy_cobblestone
setblock 416 159 195 minecraft:mossy_cobblestone
setblock 416 159 196 minecraft:stone_bricks
fill 416 159 197 417 161 197 minecraft:mossy_cobblestone
setblock 416 159 200 minecraft:mossy_cobblestone
setblock 416 159 201 minecraft:stone_bricks
fill 416 159 202 416 162 202 minecraft:mossy_cobblestone
setblock 416 159 206 minecraft:stone_bricks
fill 416 159 207 416 161 207 minecraft:mossy_cobblestone
setblock 416 159 211 minecraft:stone_bricks
fill 416 159 212 416 162 212 minecraft:mossy_cobblestone
setblock 416 159 216 minecraft:stone_bricks
fill 416 159 217 416 162 217 minecraft:mossy_cobblestone
fill 416 159 222 416 162 222 minecraft:mossy_cobblestone
setblock 417 159 186 minecraft:mossy_cobblestone
setblock 417 159 190 minecraft:stone_bricks
fill 417 159 191 417 162 191 minecraft:mossy_cobblestone
setblock 417 159 195 minecraft:stone_bricks
fill 417 159 196 417 162 196 minecraft:mossy_cobblestone
setblock 417 159 200 minecraft:stone_bricks
fill 417 159 201 417 162 201 minecraft:mossy_cobblestone
setblock 417 159 205 minecraft:stone_bricks
fill 417 159 206 417 162 206 minecraft:mossy_cobblestone
setblock 417 159 210 minecraft:stone_bricks
fill 417 159 211 417 162 211 minecraft:mossy_cobblestone
setblock 417 159 215 minecraft:stone_bricks
fill 417 159 216 417 162 216 minecraft:mossy_cobblestone
setblock 417 159 220 minecraft:stone_bricks
fill 417 159 221 417 162 221 minecraft:mossy_cobblestone
fill 377 160 185 377 160 188 minecraft:mossy_cobblestone
setblock 377 160 189 minecraft:stone_bricks
fill 377 160 190 377 160 193 minecraft:mossy_cobblestone
setblock 377 160 194 minecraft:stone_bricks
fill 377 160 195 377 160 198 minecraft:mossy_cobblestone
setblock 377 160 199 minecraft:stone_bricks
fill 377 160 200 377 163 200 minecraft:mossy_cobblestone
setblock 377 160 204 minecraft:stone_bricks
setblock 377 160 205 minecraft:mossy_cobblestone
setblock 377 160 209 minecraft:stone_bricks
setblock 377 160 210 minecraft:mossy_cobblestone
setblock 377 160 214 minecraft:stone_bricks
fill 377 160 215 377 162 215 minecraft:mossy_cobblestone
setblock 377 160 219 minecraft:stone_bricks
fill 377 160 220 377 161 220 minecraft:mossy_cobblestone
setblock 378 160 188 minecraft:stone_bricks
fill 378 160 189 378 160 192 minecraft:mossy_cobblestone
setblock 378 160 193 minecraft:stone_bricks
fill 378 160 194 378 160 197 minecraft:mossy_cobblestone
setblock 378 160 198 minecraft:stone_bricks
fill 378 160 199 378 163 199 minecraft:mossy_cobblestone
setblock 379 160 192 minecraft:stone_bricks
setblock 379 160 193 minecraft:mossy_cobblestone
setblock 389 160 182 minecraft:stone_bricks
setblock 389 160 222 minecraft:stone_bricks
fill 390 160 182 393 160 182 minecraft:mossy_cobblestone
fill 390 160 222 393 160 222 minecraft:mossy_cobblestone
fill 391 160 221 391 163 221 minecraft:mossy_cobblestone
setblock 392 160 183 minecraft:mossy_cobblestone
setblock 393 160 183 minecraft:stone_bricks
setblock 394 160 182 minecraft:stone_bricks
fill 394 160 183 394 161 183 minecraft:mossy_cobblestone
setblock 394 160 222 minecraft:stone_bricks
fill 395 160 182 395 163 182 minecraft:mossy_cobblestone
setblock 395 160 221 minecraft:stone_bricks
fill 395 160 222 395 163 222 minecraft:mossy_cobblestone
setblock 396 160 220 minecraft:stone_bricks
fill 396 160 221 396 163 221 minecraft:mossy_cobblestone
fill 397 160 220 397 163 220 minecraft:mossy_cobblestone
setblock 399 160 222 minecraft:stone_bricks
setblock 400 160 221 minecraft:stone_bricks
fill 400 160 222 400 163 222 minecraft:mossy_cobblestone
setblock 409 160 222 minecraft:stone_bricks
fill 410 160 222 410 163 222 minecraft:mossy_cobblestone
fill 411 160 221 411 163 221 minecraft:mossy_cobblestone
setblock 414 160 213 minecraft:mossy_cobblestone
setblock 414 160 222 minecraft:stone_bricks
setblock 415 160 192 minecraft:mossy_cobblestone
setblock 415 160 196 minecraft:stone_bricks
fill 415 160 197 415 161 199 minecraft:mossy_cobblestone
setblock 415 160 211 minecraft:stone_bricks
fill 415 160 212 415 161 212 minecraft:mossy_cobblestone
setblock 415 160 216 minecraft:stone_bricks
fill 415 160 217 415 162 217 minecraft:mossy_cobblestone
fill 415 160 222 415 163 222 minecraft:mossy_cobblestone
setblock 416 160 190 minecraft:stone_bricks
fill 416 160 191 416 162 191 minecraft:mossy_cobblestone
setblock 416 160 195 minecraft:stone_bricks
fill 416 160 196 416 163 196 minecraft:mossy_cobblestone
fill 416 160 198 416 160 199 minecraft:mossy_cobblestone
setblock 416 160 200 minecraft:stone_bricks
fill 416 160 201 416 163 201 minecraft:mossy_cobblestone
setblock 416 160 205 minecraft:stone_bricks
setblock 416 160 206 minecraft:mossy_cobblestone
setblock 416 160 210 minecraft:stone_bricks
fill 416 160 211 416 162 211 minecraft:mossy_cobblestone
setblock 416 160 215 minecraft:stone_bricks
fill 416 160 216 416 163 216 minecraft:mossy_cobblestone
setblock 416 160 220 minecraft:stone_bricks
setblock 417 160 189 minecraft:stone_bricks
fill 417 160 190 417 163 190 minecraft:mossy_cobblestone
setblock 417 160 194 minecraft:stone_bricks
fill 417 160 195 417 163 195 minecraft:mossy_cobblestone
setblock 417 160 198 minecraft:mossy_cobblestone
setblock 417 160 199 minecraft:stone_bricks
fill 417 160 200 417 163 200 minecraft:mossy_cobblestone
setblock 417 160 204 minecraft:stone_bricks
fill 417 160 205 417 163 205 minecraft:mossy_cobblestone
setblock 417 160 209 minecraft:stone_bricks
fill 417 160 210 417 163 210 minecraft:mossy_cobblestone
setblock 417 160 214 minecraft:stone_bricks
fill 417 160 215 417 163 215 minecraft:mossy_cobblestone
setblock 417 160 219 minecraft:stone_bricks
fill 417 160 220 417 163 220 minecraft:mossy_cobblestone
fill 377 161 186 377 161 187 minecraft:mossy_cobblestone
setblock 377 161 188 minecraft:stone_bricks
fill 377 161 189 377 161 192 minecraft:mossy_cobblestone
setblock 377 161 193 minecraft:stone_bricks
fill 377 161 194 377 161 197 minecraft:mossy_cobblestone
setblock 377 161 198 minecraft:stone_bricks
fill 377 161 199 377 164 199 minecraft:mossy_cobblestone
setblock 377 161 203 minecraft:stone_bricks
setblock 377 161 204 minecraft:mossy_cobblestone
setblock 377 161 213 minecraft:stone_bricks
fill 377 161 214 377 162 214 minecraft:mossy_cobblestone
setblock 377 161 218 minecraft:stone_bricks
fill 377 161 219 377 164 219 minecraft:mossy_cobblestone
fill 378 161 189 378 161 191 minecraft:mossy_cobblestone
setblock 378 161 192 minecraft:stone_bricks
fill 378 161 193 378 161 196 minecraft:mossy_cobblestone
setblock 378 161 197 minecraft:stone_bricks
fill 378 161 198 378 164 198 minecraft:mossy_cobblestone
setblock 379 161 184 minecraft:light[level=12]
setblock 379 161 192 minecraft:light[level=12]
setblock 379 161 200 minecraft:light[level=12]
setblock 379 161 208 minecraft:light[level=12]
setblock 379 161 216 minecraft:light[level=12]
setblock 387 161 184 minecraft:light[level=12]
setblock 387 161 192 minecraft:light[level=12]
setblock 387 161 200 minecraft:light[level=12]
setblock 387 161 208 minecraft:light[level=12]
setblock 387 161 216 minecraft:light[level=12]
setblock 388 161 182 minecraft:stone_bricks
setblock 388 161 222 minecraft:stone_bricks
fill 389 161 182 392 161 182 minecraft:mossy_cobblestone
fill 389 161 222 392 161 222 minecraft:mossy_cobblestone
fill 390 161 221 390 164 221 minecraft:mossy_cobblestone
setblock 392 161 183 minecraft:stone_bricks
fill 392 161 220 392 163 220 minecraft:mossy_cobblestone
setblock 393 161 182 minecraft:stone_bricks
fill 393 161 183 393 164 183 minecraft:mossy_cobblestone
setblock 393 161 222 minecraft:stone_bricks
fill 394 161 182 394 164 182 minecraft:mossy_cobblestone
setblock 394 161 221 minecraft:stone_bricks
fill 394 161 222 394 164 222 minecraft:mossy_cobblestone
setblock 395 161 184 minecraft:light[level=12]
setblock 395 161 192 minecraft:light[level=12]
setblock 395 161 200 minecraft:light[level=12]
setblock 395 161 208 minecraft:light[level=12]
setblock 395 161 216 minecraft:light[level=12]
setblock 395 161 220 minecraft:stone_bricks
fill 395 161 221 395 164 221 minecraft:mossy_cobblestone
fill 396 161 220 396 164 220 minecraft:mossy_cobblestone
setblock 398 161 222 minecraft:stone_bricks
setblock 399 161 221 minecraft:stone_bricks
fill 399 161 222 399 164 222 minecraft:mossy_cobblestone
setblock 403 161 184 minecraft:light[level=12]
setblock 403 161 192 minecraft:light[level=12]
setblock 403 161 200 minecraft:light[level=12]
setblock 403 161 208 minecraft:light[level=12]
setblock 403 161 216 minecraft:light[level=12]
setblock 408 161 222 minecraft:stone_bricks
fill 409 161 222 409 164 222 minecraft:mossy_cobblestone
setblock 411 161 184 minecraft:light[level=12]
setblock 411 161 192 minecraft:light[level=12]
setblock 411 161 200 minecraft:light[level=12]
setblock 411 161 208 minecraft:light[level=12]
setblock 411 161 216 minecraft:light[level=12]
setblock 413 161 222 minecraft:stone_bricks
setblock 414 161 221 minecraft:stone_bricks
fill 414 161 222 414 164 222 minecraft:mossy_cobblestone
setblock 415 161 195 minecraft:stone_bricks
fill 415 161 196 415 164 196 minecraft:mossy_cobblestone
setblock 415 161 200 minecraft:stone_bricks
setblock 415 161 211 minecraft:mossy_cobblestone
setblock 415 161 215 minecraft:stone_bricks
fill 415 161 216 415 162 216 minecraft:mossy_cobblestone
setblock 416 161 194 minecraft:stone_bricks
fill 416 161 195 416 164 195 minecraft:mossy_cobblestone
setblock 416 161 198 minecraft:mossy_cobblestone
setblock 416 161 199 minecraft:stone_bricks
fill 416 161 200 416 164 200 minecraft:mossy_cobblestone
setblock 416 161 204 minecraft:stone_bricks
setblock 416 161 205 minecraft:mossy_cobblestone
setblock 416 161 209 minecraft:stone_bricks
fill 416 161 210 416 162 210 minecraft:mossy_cobblestone
setblock 416 161 214 minecraft:stone_bricks
fill 416 161 215 416 164 215 minecraft:mossy_cobblestone
setblock 416 161 219 minecraft:stone_bricks
setblock 416 161 220 minecraft:mossy_cobblestone
setblock 417 161 189 minecraft:mossy_cobblestone
setblock 417 161 193 minecraft:stone_bricks
fill 417 161 194 417 164 194 minecraft:mossy_cobblestone
setblock 417 161 198 minecraft:stone_bricks
fill 417 161 199 417 164 199 minecraft:mossy_cobblestone
setblock 417 161 203 minecraft:stone_bricks
fill 417 161 204 417 164 204 minecraft:mossy_cobblestone
setblock 417 161 208 minecraft:stone_bricks
fill 417 161 209 417 163 209 minecraft:mossy_cobblestone
setblock 417 161 213 minecraft:stone_bricks
fill 417 161 214 417 164 214 minecraft:mossy_cobblestone
setblock 417 161 218 minecraft:stone_bricks
fill 417 161 219 417 164 219 minecraft:mossy_cobblestone
setblock 377 162 187 minecraft:stone_bricks
fill 377 162 188 377 162 191 minecraft:mossy_cobblestone
setblock 377 162 192 minecraft:stone_bricks
fill 377 162 193 377 162 196 minecraft:mossy_cobblestone
setblock 377 162 197 minecraft:stone_bricks
fill 377 162 198 377 165 198 minecraft:mossy_cobblestone
setblock 377 162 202 minecraft:stone_bricks
fill 377 162 203 377 165 203 minecraft:mossy_cobblestone
setblock 377 162 217 minecraft:stone_bricks
fill 377 162 218 377 165 218 minecraft:mossy_cobblestone
setblock 378 162 190 minecraft:mossy_cobblestone
setblock 378 162 191 minecraft:stone_bricks
fill 378 162 192 378 162 195 minecraft:mossy_cobblestone
setblock 378 162 196 minecraft:stone_bricks
fill 378 162 197 378 165 197 minecraft:mossy_cobblestone
setblock 387 162 222 minecraft:stone_bricks
fill 388 162 182 391 162 182 minecraft:mossy_cobblestone
fill 388 162 222 391 162 222 minecraft:mossy_cobblestone
fill 389 162 221 389 165 221 minecraft:mossy_cobblestone
fill 391 162 220 391 164 220 minecraft:mossy_cobblestone
setblock 392 162 182 minecraft:stone_bricks
fill 392 162 183 392 165 183 minecraft:mossy_cobblestone
setblock 392 162 222 minecraft:stone_bricks
fill 393 162 182 393 165 182 minecraft:mossy_cobblestone
setblock 393 162 221 minecraft:stone_bricks
fill 393 162 222 393 165 222 minecraft:mossy_cobblestone
setblock 394 162 220 minecraft:stone_bricks
fill 394 162 221 394 165 221 minecraft:mossy_cobblestone
fill 395 162 220 395 165 220 minecraft:mossy_cobblestone
setblock 397 162 182 minecraft:stone_bricks
setblock 397 162 222 minecraft:stone_bricks
setblock 398 162 221 minecraft:stone_bricks
fill 398 162 222 398 165 222 minecraft:mossy_cobblestone
fill 399 162 221 399 165 221 minecraft:mossy_cobblestone
setblock 402 162 222 minecraft:stone_bricks
setblock 406 162 222 minecraft:mossy_cobblestone
setblock 407 162 222 minecraft:stone_bricks
fill 408 162 222 408 165 222 minecraft:mossy_cobblestone
fill 409 162 221 410 164 221 minecraft:mossy_cobblestone
setblock 412 162 222 minecraft:stone_bricks
setblock 413 162 221 minecraft:stone_bricks
fill 413 162 222 413 165 222 minecraft:mossy_cobblestone
fill 414 162 221 414 165 221 minecraft:mossy_cobblestone
setblock 415 162 194 minecraft:stone_bricks
fill 415 162 195 415 165 195 minecraft:mossy_cobblestone
fill 415 162 197 415 162 198 minecraft:mossy_cobblestone
setblock 415 162 199 minecraft:stone_bricks
fill 415 162 200 415 165 200 minecraft:mossy_cobblestone
setblock 415 162 214 minecraft:stone_bricks
setblock 415 162 215 minecraft:mossy_cobblestone
setblock 416 162 193 minecraft:stone_bricks
fill 416 162 194 416 165 194 minecraft:mossy_cobblestone
setblock 416 162 197 minecraft:mossy_cobblestone
setblock 416 162 198 minecraft:stone_bricks
fill 416 162 199 416 165 199 minecraft:mossy_cobblestone
setblock 416 162 203 minecraft:stone_bricks
setblock 416 162 213 minecraft:stone_bricks
fill 416 162 214 416 163 214 minecraft:mossy_cobblestone
setblock 416 162 218 minecraft:stone_bricks
fill 416 162 219 416 165 219 minecraft:mossy_cobblestone
setblock 417 162 192 minecraft:stone_bricks
fill 417 162 193 417 165 193 minecraft:mossy_cobblestone
setblock 417 162 197 minecraft:stone_bricks
fill 417 162 198 417 165 198 minecraft:mossy_cobblestone
setblock 417 162 202 minecraft:stone_bricks
fill 417 162 203 417 165 203 minecraft:mossy_cobblestone
setblock 417 162 207 minecraft:stone_bricks
fill 417 162 208 417 163 208 minecraft:mossy_cobblestone
setblock 417 162 212 minecraft:stone_bricks
fill 417 162 213 417 165 213 minecraft:mossy_cobblestone
setblock 417 162 217 minecraft:stone_bricks
fill 417 162 218 417 165 218 minecraft:mossy_cobblestone
fill 377 163 188 377 163 190 minecraft:mossy_cobblestone
setblock 377 163 191 minecraft:stone_bricks
fill 377 163 192 377 163 195 minecraft:mossy_cobblestone
setblock 377 163 196 minecraft:stone_bricks
fill 377 163 197 377 166 197 minecraft:mossy_cobblestone
setblock 377 163 201 minecraft:stone_bricks
fill 377 163 202 377 166 202 minecraft:mossy_cobblestone
setblock 377 163 216 minecraft:stone_bricks
setblock 377 163 217 minecraft:mossy_cobblestone
fill 378 163 191 378 163 194 minecraft:mossy_cobblestone
setblock 378 163 195 minecraft:stone_bricks
fill 378 163 196 378 166 196 minecraft:mossy_cobblestone
setblock 386 163 222 minecraft:stone_bricks
fill 387 163 182 390 163 182 minecraft:mossy_cobblestone
fill 387 163 222 390 163 222 minecraft:mossy_cobblestone
fill 388 163 221 388 166 221 minecraft:mossy_cobblestone
setblock 390 163 183 minecraft:stone_bricks
fill 390 163 220 390 165 220 minecraft:mossy_cobblestone
setblock 391 163 182 minecraft:stone_bricks
fill 391 163 183 391 166 183 minecraft:mossy_cobblestone
setblock 391 163 222 minecraft:stone_bricks
fill 392 163 182 392 166 182 minecraft:mossy_cobblestone
setblock 392 163 221 minecraft:stone_bricks
fill 392 163 222 392 166 222 minecraft:mossy_cobblestone
setblock 393 163 220 minecraft:stone_bricks
fill 393 163 221 393 166 221 minecraft:mossy_cobblestone
fill 394 163 220 394 166 220 minecraft:mossy_cobblestone
setblock 396 163 182 minecraft:stone_bricks
setblock 396 163 222 minecraft:stone_bricks
fill 397 163 182 397 166 182 minecraft:mossy_cobblestone
setblock 397 163 221 minecraft:stone_bricks
fill 397 163 222 397 166 222 minecraft:mossy_cobblestone
fill 398 163 221 398 166 221 minecraft:mossy_cobblestone
fill 400 163 221 400 164 221 minecraft:mossy_cobblestone
setblock 401 163 222 minecraft:stone_bricks
fill 402 163 222 405 163 222 minecraft:mossy_cobblestone
setblock 406 163 222 minecraft:stone_bricks
fill 407 163 222 407 166 222 minecraft:mossy_cobblestone
fill 408 163 221 408 166 221 minecraft:mossy_cobblestone
setblock 411 163 222 minecraft:stone_bricks
setblock 412 163 221 minecraft:stone_bricks
fill 412 163 222 412 166 222 minecraft:mossy_cobblestone
fill 413 163 221 413 166 221 minecraft:mossy_cobblestone
fill 415 163 194 415 164 194 minecraft:mossy_cobblestone
setblock 415 163 197 minecraft:mossy_cobblestone
setblock 415 163 198 minecraft:stone_bricks
fill 415 163 199 415 166 199 minecraft:mossy_cobblestone
fill 415 163 201 415 164 201 minecraft:mossy_cobblestone
setblock 416 163 192 minecraft:stone_bricks
fill 416 163 193 416 166 193 minecraft:mossy_cobblestone
setblock 416 163 197 minecraft:stone_bricks
fill 416 163 198 416 166 198 minecraft:mossy_cobblestone
setblock 416 163 202 minecraft:stone_bricks
fill 416 163 203 416 165 204 minecraft:mossy_cobblestone
setblock 416 163 213 minecraft:mossy_cobblestone
setblock 416 163 217 minecraft:stone_bricks
fill 416 163 218 416 165 218 minecraft:mossy_cobblestone
setblock 416 163 222 minecraft:stone_bricks
setblock 417 163 191 minecraft:stone_bricks
fill 417 163 192 417 166 192 minecraft:mossy_cobblestone
setblock 417 163 196 minecraft:stone_bricks
fill 417 163 197 417 166 197 minecraft:mossy_cobblestone
setblock 417 163 201 minecraft:stone_bricks
fill 417 163 202 417 166 202 minecraft:mossy_cobblestone
setblock 417 163 206 minecraft:stone_bricks
fill 417 163 207 417 166 207 minecraft:mossy_cobblestone
setblock 417 163 211 minecraft:stone_bricks
fill 417 163 212 417 164 212 minecraft:mossy_cobblestone
setblock 417 163 216 minecraft:stone_bricks
fill 417 163 217 417 166 217 minecraft:mossy_cobblestone
setblock 417 163 221 minecraft:stone_bricks
fill 377 164 188 377 164 189 minecraft:mossy_cobblestone
setblock 377 164 190 minecraft:stone_bricks
fill 377 164 191 377 164 194 minecraft:mossy_cobblestone
setblock 377 164 195 minecraft:stone_bricks
fill 377 164 196 377 167 196 minecraft:mossy_cobblestone
setblock 377 164 200 minecraft:stone_bricks
fill 377 164 201 377 167 201 minecraft:mossy_cobblestone
setblock 377 164 220 minecraft:stone_bricks
fill 378 164 192 378 164 193 minecraft:mossy_cobblestone
setblock 378 164 194 minecraft:stone_bricks
fill 378 164 195 378 167 195 minecraft:mossy_cobblestone
setblock 378 164 199 minecraft:stone_bricks
setblock 385 164 182 minecraft:stone_bricks
setblock 385 164 222 minecraft:stone_bricks
fill 386 164 182 389 164 182 minecraft:mossy_cobblestone
fill 386 164 222 389 164 222 minecraft:mossy_cobblestone
fill 387 164 221 387 167 221 minecraft:mossy_cobblestone
setblock 389 164 183 minecraft:stone_bricks
fill 389 164 220 389 166 220 minecraft:mossy_cobblestone
setblock 390 164 182 minecraft:stone_bricks
fill 390 164 183 390 167 183 minecraft:mossy_cobblestone
setblock 390 164 222 minecraft:stone_bricks
fill 391 164 182 391 167 182 minecraft:mossy_cobblestone
setblock 391 164 221 minecraft:stone_bricks
fill 391 164 222 391 167 222 minecraft:mossy_cobblestone
setblock 392 164 219 minecraft:mossy_cobblestone
setblock 392 164 220 minecraft:stone_bricks
fill 392 164 221 392 167 221 minecraft:mossy_cobblestone
setblock 393 164 219 minecraft:stone_bricks
fill 393 164 220 393 167 220 minecraft:mossy_cobblestone
setblock 394 164 183 minecraft:stone_bricks
setblock 395 164 182 minecraft:stone_bricks
setblock 395 164 222 minecraft:stone_bricks
fill 396 164 182 396 167 182 minecraft:mossy_cobblestone
setblock 396 164 221 minecraft:stone_bricks
fill 396 164 222 396 167 222 minecraft:mossy_cobblestone
setblock 397 164 220 minecraft:stone_bricks
fill 397 164 221 397 167 221 minecraft:mossy_cobblestone
setblock 400 164 222 minecraft:stone_bricks
fill 401 164 222 404 164 222 minecraft:mossy_cobblestone
setblock 405 164 222 minecraft:stone_bricks
setblock 406 164 221 minecraft:stone_bricks
fill 406 164 222 406 167 222 minecraft:mossy_cobblestone
fill 407 164 221 407 167 221 minecraft:mossy_cobblestone
fill 410 164 220 411 164 220 minecraft:mossy_cobblestone
setblock 410 164 222 minecraft:stone_bricks
setblock 411 164 221 minecraft:stone_bricks
fill 411 164 222 411 167 222 minecraft:mossy_cobblestone
setblock 412 164 220 minecraft:stone_bricks
fill 412 164 221 412 167 221 minecraft:mossy_cobblestone
setblock 415 164 197 minecraft:stone_bricks
fill 415 164 198 415 167 198 minecraft:mossy_cobblestone
setblock 415 164 202 minecraft:stone_bricks
setblock 415 164 222 minecraft:stone_bricks
setblock 416 164 192 minecraft:mossy_cobblestone
setblock 416 164 196 minecraft:stone_bricks
fill 416 164 197 416 167 197 minecraft:mossy_cobblestone
setblock 416 164 201 minecraft:stone_bricks
fill 416 164 202 416 167 202 minecraft:mossy_cobblestone
setblock 416 164 216 minecraft:stone_bricks
fill 416 164 217 416 165 217 minecraft:mossy_cobblestone
fill 416 164 222 416 167 222 minecraft:mossy_cobblestone
fill 417 164 191 417 167 191 minecraft:mossy_cobblestone
setblock 417 164 195 minecraft:stone_bricks
fill 417 164 196 417 167 196 minecraft:mossy_cobblestone
setblock 417 164 200 minecraft:stone_bricks
fill 417 164 201 417 167 201 minecraft:mossy_cobblestone
setblock 417 164 205 minecraft:stone_bricks
fill 417 164 206 417 167 206 minecraft:mossy_cobblestone
setblock 417 164 211 minecraft:mossy_cobblestone
setblock 417 164 215 minecraft:stone_bricks
fill 417 164 216 417 167 216 minecraft:mossy_cobblestone
setblock 417 164 220 minecraft:stone_bricks
fill 417 164 221 417 167 221 minecraft:mossy_cobblestone
fill 377 165 182 377 166 182 minecraft:mossy_cobblestone
setblock 377 165 188 minecraft:mossy_cobblestone
setblock 377 165 189 minecraft:stone_bricks
fill 377 165 190 377 165 193 minecraft:mossy_cobblestone
setblock 377 165 194 minecraft:stone_bricks
fill 377 165 195 377 168 195 minecraft:mossy_cobblestone
setblock 377 165 199 minecraft:stone_bricks
fill 377 165 200 378 167 200 minecraft:mossy_cobblestone
setblock 377 165 219 minecraft:stone_bricks
fill 377 165 220 377 166 222 minecraft:mossy_cobblestone
setblock 378 165 193 minecraft:stone_bricks
fill 378 165 194 378 167 194 minecraft:mossy_cobblestone
setblock 378 165 198 minecraft:stone_bricks
fill 378 165 199 378 168 199 minecraft:mossy_cobblestone
setblock 383 165 182 minecraft:mossy_cobblestone
setblock 383 165 222 minecraft:mossy_cobblestone
setblock 384 165 182 minecraft:stone_bricks
setblock 384 165 222 minecraft:stone_bricks
fill 385 165 182 388 165 182 minecraft:mossy_cobblestone
fill 385 165 222 388 165 222 minecraft:mossy_cobblestone
fill 386 165 221 386 168 221 minecraft:mossy_cobblestone
setblock 387 165 183 minecraft:mossy_cobblestone
setblock 388 165 183 minecraft:stone_bricks
fill 388 165 220 388 167 220 minecraft:mossy_cobblestone
setblock 389 165 182 minecraft:stone_bricks
fill 389 165 183 389 168 183 minecraft:mossy_cobblestone
setblock 389 165 222 minecraft:stone_bricks
fill 390 165 182 390 168 182 minecraft:mossy_cobblestone
setblock 390 165 221 minecraft:stone_bricks
fill 390 165 222 390 168 222 minecraft:mossy_cobblestone
setblock 391 165 219 minecraft:mossy_cobblestone
setblock 391 165 220 minecraft:stone_bricks
fill 391 165 221 391 168 221 minecraft:mossy_cobblestone
setblock 392 165 219 minecraft:stone_bricks
fill 392 165 220 392 168 220 minecraft:mossy_cobblestone
setblock 393 165 183 minecraft:stone_bricks
fill 393 165 219 394 167 219 minecraft:mossy_cobblestone
setblock 394 165 182 minecraft:stone_bricks
fill 394 165 183 394 168 183 minecraft:mossy_cobblestone
setblock 394 165 222 minecraft:stone_bricks
fill 395 165 182 395 168 182 minecraft:mossy_cobblestone
setblock 395 165 221 minecraft:stone_bricks
fill 395 165 222 395 168 222 minecraft:mossy_cobblestone
setblock 396 165 220 minecraft:stone_bricks
fill 396 165 221 396 168 221 minecraft:mossy_cobblestone
fill 397 165 220 398 167 220 minecraft:mossy_cobblestone
setblock 399 165 222 minecraft:stone_bricks
setblock 400 165 221 minecraft:stone_bricks
fill 400 165 222 403 165 222 minecraft:mossy_cobblestone
fill 401 165 221 404 165 221 minecraft:mossy_cobblestone
setblock 404 165 222 minecraft:stone_bricks
setblock 405 165 221 minecraft:stone_bricks
fill 405 165 222 405 168 222 minecraft:mossy_cobblestone
fill 406 165 221 406 168 221 minecraft:mossy_cobblestone
fill 408 165 220 410 165 220 minecraft:mossy_cobblestone
setblock 409 165 221 minecraft:mossy_cobblestone
setblock 409 165 222 minecraft:stone_bricks
fill 410 165 182 413 165 182 minecraft:mossy_cobblestone
setblock 410 165 221 minecraft:stone_bricks
fill 410 165 222 410 168 222 minecraft:mossy_cobblestone
setblock 411 165 220 minecraft:stone_bricks
fill 411 165 221 411 168 221 minecraft:mossy_cobblestone
fill 412 165 220 413 167 220 minecraft:mossy_cobblestone
fill 414 165 198 414 167 199 minecraft:mossy_cobblestone
setblock 414 165 222 minecraft:stone_bricks
setblock 415 165 196 minecraft:stone_bricks
fill 415 165 197 415 168 197 minecraft:mossy_cobblestone
setblock 415 165 201 minecraft:stone_bricks
fill 415 165 202 415 167 203 minecraft:mossy_cobblestone
setblock 415 165 221 minecraft:stone_bricks
fill 415 165 222 415 168 222 minecraft:mossy_cobblestone
setblock 416 165 195 minecraft:stone_bricks
fill 416 165 196 416 168 196 minecraft:mossy_cobblestone
setblock 416 165 200 minecraft:stone_bricks
fill 416 165 201 416 168 201 minecraft:mossy_cobblestone
setblock 417 165 194 minecraft:stone_bricks
fill 417 165 195 417 168 195 minecraft:mossy_cobblestone
setblock 417 165 199 minecraft:stone_bricks
fill 417 165 200 417 168 200 minecraft:mossy_cobblestone
setblock 417 165 204 minecraft:stone_bricks
fill 417 165 205 417 168 205 minecraft:mossy_cobblestone
setblock 417 165 214 minecraft:stone_bricks
fill 417 165 215 417 166 215 minecraft:mossy_cobblestone
setblock 417 165 219 minecraft:stone_bricks
fill 417 165 220 417 168 220 minecraft:mossy_cobblestone
fill 417 165 222 417 166 222 minecraft:mossy_cobblestone
setblock 377 166 183 minecraft:stone_bricks
fill 377 166 184 377 168 185 minecraft:mossy_cobblestone
setblock 377 166 188 minecraft:stone_bricks
fill 377 166 189 377 166 192 minecraft:mossy_cobblestone
setblock 377 166 193 minecraft:stone_bricks
fill 377 166 194 377 169 194 minecraft:mossy_cobblestone
setblock 377 166 198 minecraft:stone_bricks
fill 377 166 199 377 169 199 minecraft:mossy_cobblestone
setblock 377 166 203 minecraft:stone_bricks
fill 377 166 204 377 169 204 minecraft:mossy_cobblestone
setblock 377 166 218 minecraft:stone_bricks
fill 377 166 219 377 169 219 minecraft:mossy_cobblestone
setblock 378 166 182 minecraft:stone_bricks
setblock 378 166 197 minecraft:stone_bricks
fill 378 166 198 378 169 198 minecraft:mossy_cobblestone
setblock 378 166 222 minecraft:stone_bricks
fill 379 166 182 382 166 182 minecraft:mossy_cobblestone
fill 379 166 222 382 166 222 minecraft:mossy_cobblestone
setblock 383 166 182 minecraft:stone_bricks
setblock 383 166 222 minecraft:stone_bricks
fill 384 166 182 387 166 182 minecraft:mossy_cobblestone
setblock 384 166 221 minecraft:stone_bricks
fill 384 166 222 387 166 222 minecraft:mossy_cobblestone
fill 385 166 183 386 166 183 minecraft:mossy_cobblestone
fill 385 166 221 385 169 221 minecraft:mossy_cobblestone
setblock 387 166 183 minecraft:stone_bricks
fill 387 166 220 387 168 220 minecraft:mossy_cobblestone
setblock 388 166 182 minecraft:stone_bricks
fill 388 166 183 388 169 183 minecraft:mossy_cobblestone
setblock 388 166 222 minecraft:stone_bricks
fill 389 166 182 389 169 182 minecraft:mossy_cobblestone
fill 389 166 219 390 166 219 minecraft:mossy_cobblestone
setblock 389 166 221 minecraft:stone_bricks
fill 389 166 222 389 169 222 minecraft:mossy_cobblestone
setblock 390 166 220 minecraft:stone_bricks
fill 390 166 221 390 169 221 minecraft:mossy_cobblestone
setblock 391 166 219 minecraft:stone_bricks
fill 391 166 220 391 169 220 minecraft:mossy_cobblestone
setblock 392 166 183 minecraft:stone_bricks
fill 392 166 219 392 169 219 minecraft:mossy_cobblestone
setblock 393 166 182 minecraft:stone_bricks
fill 393 166 183 393 169 183 minecraft:mossy_cobblestone
setblock 393 166 222 minecraft:stone_bricks
fill 394 166 182 394 169 182 minecraft:mossy_cobblestone
setblock 394 166 221 minecraft:stone_bricks
fill 394 166 222 394 169 222 minecraft:mossy_cobblestone
setblock 395 166 220 minecraft:stone_bricks
fill 395 166 221 395 169 221 minecraft:mossy_cobblestone
fill 396 166 220 396 169 220 minecraft:mossy_cobblestone
setblock 398 166 182 minecraft:stone_bricks
setblock 398 166 222 minecraft:stone_bricks
setblock 399 166 221 minecraft:stone_bricks
fill 399 166 222 402 166 222 minecraft:mossy_cobblestone
fill 400 166 221 403 166 221 minecraft:mossy_cobblestone
setblock 403 166 222 minecraft:stone_bricks
setblock 404 166 221 minecraft:stone_bricks
fill 404 166 222 404 169 222 minecraft:mossy_cobblestone
fill 405 166 221 405 169 221 minecraft:mossy_cobblestone
fill 406 166 220 409 166 220 minecraft:mossy_cobblestone
setblock 408 166 182 minecraft:stone_bricks
setblock 408 166 222 minecraft:stone_bricks
fill 409 166 182 412 166 182 minecraft:mossy_cobblestone
setblock 409 166 221 minecraft:stone_bricks
fill 409 166 222 409 169 222 minecraft:mossy_cobblestone
setblock 410 166 220 minecraft:stone_bricks
fill 410 166 221 410 169 221 minecraft:mossy_cobblestone
fill 411 166 220 411 169 220 minecraft:mossy_cobblestone
setblock 413 166 182 minecraft:stone_bricks
setblock 413 166 222 minecraft:stone_bricks
fill 414 166 182 415 168 182 minecraft:mossy_cobblestone
fill 414 166 197 414 168 197 minecraft:mossy_cobblestone
setblock 414 166 200 minecraft:mossy_cobblestone
setblock 414 166 201 minecraft:stone_bricks
setblock 414 166 221 minecraft:stone_bricks
fill 414 166 222 414 169 222 minecraft:mossy_cobblestone
setblock 415 166 195 minecraft:stone_bricks
fill 415 166 196 415 169 196 minecraft:mossy_cobblestone
setblock 415 166 200 minecraft:stone_bricks
fill 415 166 201 415 169 201 minecraft:mossy_cobblestone
fill 415 166 221 415 168 221 minecraft:mossy_cobblestone
setblock 416 166 194 minecraft:stone_bricks
fill 416 166 195 416 169 195 minecraft:mossy_cobblestone
setblock 416 166 199 minecraft:stone_bricks
fill 416 166 200 416 169 200 minecraft:mossy_cobblestone
setblock 416 166 203 minecraft:mossy_cobblestone
setblock 416 166 204 minecraft:stone_bricks
fill 416 166 205 416 169 205 minecraft:mossy_cobblestone
setblock 417 166 193 minecraft:stone_bricks
fill 417 166 194 417 169 194 minecraft:mossy_cobblestone
setblock 417 166 198 minecraft:stone_bricks
fill 417 166 199 417 169 199 minecraft:mossy_cobblestone
setblock 417 166 203 minecraft:stone_bricks
fill 417 166 204 417 169 204 minecraft:mossy_cobblestone
setblock 417 166 218 minecraft:stone_bricks
fill 417 166 219 417 169 219 minecraft:mossy_cobblestone
setblock 377 167 182 minecraft:stone_bricks
fill 377 167 183 377 170 183 minecraft:mossy_cobblestone
setblock 377 167 186 minecraft:mossy_cobblestone
setblock 377 167 187 minecraft:stone_bricks
fill 377 167 188 377 167 191 minecraft:mossy_cobblestone
setblock 377 167 192 minecraft:stone_bricks
fill 377 167 193 377 170 193 minecraft:mossy_cobblestone
setblock 377 167 197 minecraft:stone_bricks
fill 377 167 198 377 170 198 minecraft:mossy_cobblestone
setblock 377 167 202 minecraft:stone_bricks
fill 377 167 203 377 170 203 minecraft:mossy_cobblestone
fill 377 167 220 377 167 221 minecraft:mossy_cobblestone
setblock 377 167 222 minecraft:stone_bricks
fill 378 167 182 381 167 182 minecraft:mossy_cobblestone
setblock 378 167 196 minecraft:stone_bricks
fill 378 167 197 378 169 197 minecraft:mossy_cobblestone
setblock 378 167 201 minecraft:stone_bricks
fill 378 167 222 381 167 222 minecraft:mossy_cobblestone
setblock 382 167 182 minecraft:stone_bricks
setblock 382 167 222 minecraft:stone_bricks
fill 383 167 182 385 167 183 minecraft:mossy_cobblestone
setblock 383 167 221 minecraft:stone_bricks
fill 383 167 222 386 167 222 minecraft:mossy_cobblestone
fill 384 167 221 384 170 221 minecraft:mossy_cobblestone
setblock 386 167 182 minecraft:mossy_cobblestone
setblock 386 167 183 minecraft:stone_bricks
fill 386 167 220 386 169 220 minecraft:mossy_cobblestone
setblock 387 167 182 minecraft:stone_bricks
fill 387 167 183 387 169 184 minecraft:mossy_cobblestone
setblock 387 167 222 minecraft:stone_bricks
fill 388 167 182 388 170 182 minecraft:mossy_cobblestone
fill 388 167 184 389 167 184 minecraft:mossy_cobblestone
fill 388 167 219 389 167 219 minecraft:mossy_cobblestone
setblock 388 167 221 minecraft:stone_bricks
fill 388 167 222 388 170 222 minecraft:mossy_cobblestone
setblock 389 167 220 minecraft:stone_bricks
fill 389 167 221 389 170 221 minecraft:mossy_cobblestone
setblock 390 167 184 minecraft:stone_bricks
setblock 390 167 219 minecraft:stone_bricks
fill 390 167 220 390 170 220 minecraft:mossy_cobblestone
setblock 391 167 183 minecraft:stone_bricks
fill 391 167 184 391 170 184 minecraft:mossy_cobblestone
fill 391 167 219 391 170 219 minecraft:mossy_cobblestone
setblock 392 167 182 minecraft:stone_bricks
fill 392 167 183 392 170 183 minecraft:mossy_cobblestone
setblock 392 167 222 minecraft:stone_bricks
fill 393 167 182 393 170 182 minecraft:mossy_cobblestone
setblock 393 167 221 minecraft:stone_bricks
fill 393 167 222 393 170 222 minecraft:mossy_cobblestone
setblock 394 167 220 minecraft:stone_bricks
fill 394 167 221 394 170 221 minecraft:mossy_cobblestone
setblock 395 167 183 minecraft:mossy_cobblestone
fill 395 167 220 395 170 220 minecraft:mossy_cobblestone
setblock 397 167 182 minecraft:stone_bricks
setblock 397 167 222 minecraft:stone_bricks
fill 398 167 182 398 170 182 minecraft:mossy_cobblestone
setblock 398 167 221 minecraft:stone_bricks
fill 398 167 222 401 167 222 minecraft:mossy_cobblestone
fill 399 167 221 402 167 221 minecraft:mossy_cobblestone
setblock 402 167 222 minecraft:stone_bricks
setblock 403 167 221 minecraft:stone_bricks
fill 403 167 222 403 170 222 minecraft:mossy_cobblestone
setblock 404 167 220 minecraft:stone_bricks
fill 404 167 221 404 170 221 minecraft:mossy_cobblestone
fill 405 167 182 406 167 182 minecraft:mossy_cobblestone
fill 405 167 220 408 167 220 minecraft:mossy_cobblestone
setblock 407 167 182 minecraft:stone_bricks
setblock 407 167 222 minecraft:stone_bricks
fill 408 167 182 411 167 182 minecraft:mossy_cobblestone
setblock 408 167 221 minecraft:stone_bricks
fill 408 167 222 408 170 222 minecraft:mossy_cobblestone
setblock 409 167 220 minecraft:stone_bricks
fill 409 167 221 409 170 221 minecraft:mossy_cobblestone
fill 410 167 220 410 170 220 minecraft:mossy_cobblestone
setblock 412 167 182 minecraft:stone_bricks
setblock 412 167 222 minecraft:stone_bricks
fill 413 167 182 413 170 182 minecraft:mossy_cobblestone
setblock 413 167 221 minecraft:stone_bricks
fill 413 167 222 413 170 222 minecraft:mossy_cobblestone
setblock 414 167 200 minecraft:stone_bricks
fill 414 167 201 414 169 202 minecraft:mossy_cobblestone
fill 414 167 221 414 170 221 minecraft:mossy_cobblestone
fill 415 167 195 415 168 195 minecraft:mossy_cobblestone
setblock 415 167 199 minecraft:stone_bricks
fill 415 167 200 415 170 200 minecraft:mossy_cobblestone
setblock 415 167 204 minecraft:stone_bricks
setblock 416 167 182 minecraft:mossy_cobblestone
setblock 416 167 193 minecraft:stone_bricks
fill 416 167 194 416 169 194 minecraft:mossy_cobblestone
setblock 416 167 198 minecraft:stone_bricks
fill 416 167 199 416 170 199 minecraft:mossy_cobblestone
setblock 416 167 203 minecraft:stone_bricks
fill 416 167 204 416 170 204 minecraft:mossy_cobblestone
fill 416 167 206 416 168 206 minecraft:mossy_cobblestone
setblock 417 167 192 minecraft:stone_bricks
fill 417 167 193 417 170 193 minecraft:mossy_cobblestone
setblock 417 167 197 minecraft:stone_bricks
fill 417 167 198 417 170 198 minecraft:mossy_cobblestone
setblock 417 167 202 minecraft:stone_bricks
fill 417 167 203 417 170 203 minecraft:mossy_cobblestone
setblock 417 167 207 minecraft:stone_bricks
setblock 417 167 217 minecraft:stone_bricks
fill 417 167 218 417 168 218 minecraft:mossy_cobblestone
setblock 417 167 222 minecraft:stone_bricks
fill 377 168 182 380 168 182 minecraft:mossy_cobblestone
setblock 377 168 186 minecraft:stone_bricks
fill 377 168 187 377 168 190 minecraft:mossy_cobblestone
setblock 377 168 191 minecraft:stone_bricks
fill 377 168 192 377 170 192 minecraft:mossy_cobblestone
setblock 377 168 196 minecraft:stone_bricks
fill 377 168 197 377 171 197 minecraft:mossy_cobblestone
setblock 377 168 200 minecraft:mossy_cobblestone
setblock 377 168 201 minecraft:stone_bricks
fill 377 168 202 377 171 202 minecraft:mossy_cobblestone
setblock 377 168 220 minecraft:mossy_cobblestone
setblock 377 168 221 minecraft:stone_bricks
fill 377 168 222 380 168 222 minecraft:mossy_cobblestone
setblock 378 168 195 minecraft:stone_bricks
fill 378 168 196 378 169 196 minecraft:mossy_cobblestone
setblock 378 168 200 minecraft:stone_bricks
fill 378 168 201 378 170 201 minecraft:mossy_cobblestone
setblock 380 168 183 minecraft:stone_bricks
setblock 381 168 182 minecraft:stone_bricks
fill 381 168 183 384 168 183 minecraft:mossy_cobblestone
setblock 381 168 222 minecraft:stone_bricks
fill 382 168 182 385 168 182 minecraft:mossy_cobblestone
setblock 382 168 221 minecraft:stone_bricks
fill 382 168 222 385 168 222 minecraft:mossy_cobblestone
fill 383 168 221 383 171 221 minecraft:mossy_cobblestone
setblock 385 168 183 minecraft:stone_bricks
fill 385 168 184 386 170 184 minecraft:mossy_cobblestone
fill 385 168 220 385 170 220 minecraft:mossy_cobblestone
setblock 386 168 182 minecraft:stone_bricks
fill 386 168 183 386 171 183 minecraft:mossy_cobblestone
setblock 386 168 222 minecraft:stone_bricks
fill 387 168 182 387 171 182 minecraft:mossy_cobblestone
setblock 387 168 221 minecraft:stone_bricks
fill 387 168 222 387 171 222 minecraft:mossy_cobblestone
setblock 388 168 184 minecraft:mossy_cobblestone
setblock 388 168 219 minecraft:mossy_cobblestone
setblock 388 168 220 minecraft:stone_bricks
fill 388 168 221 388 171 221 minecraft:mossy_cobblestone
setblock 389 168 184 minecraft:stone_bricks
setblock 389 168 219 minecraft:stone_bricks
fill 389 168 220 389 171 220 minecraft:mossy_cobblestone
setblock 390 168 183 minecraft:stone_bricks
fill 390 168 184 390 171 184 minecraft:mossy_cobblestone
fill 390 168 219 390 171 219 minecraft:mossy_cobblestone
setblock 391 168 182 minecraft:stone_bricks
fill 391 168 183 391 171 183 minecraft:mossy_cobblestone
setblock 391 168 222 minecraft:stone_bricks
fill 392 168 182 392 171 182 minecraft:mossy_cobblestone
fill 392 168 184 392 169 184 minecraft:mossy_cobblestone
setblock 392 168 221 minecraft:stone_bricks
fill 392 168 222 392 171 222 minecraft:mossy_cobblestone
setblock 393 168 219 minecraft:mossy_cobblestone
setblock 393 168 220 minecraft:stone_bricks
fill 393 168 221 393 171 221 minecraft:mossy_cobblestone
setblock 394 168 219 minecraft:stone_bricks
fill 394 168 220 394 171 220 minecraft:mossy_cobblestone
setblock 395 168 183 minecraft:stone_bricks
setblock 396 168 182 minecraft:stone_bricks
setblock 396 168 222 minecraft:stone_bricks
fill 397 168 182 397 171 182 minecraft:mossy_cobblestone
setblock 397 168 220 minecraft:mossy_cobblestone
setblock 397 168 221 minecraft:stone_bricks
fill 397 168 222 400 168 222 minecraft:mossy_cobblestone
setblock 398 168 220 minecraft:stone_bricks
fill 398 168 221 401 168 221 minecraft:mossy_cobblestone
fill 399 168 182 399 169 182 minecraft:mossy_cobblestone
setblock 401 168 222 minecraft:stone_bricks
setblock 402 168 221 minecraft:stone_bricks
fill 402 168 222 402 171 222 minecraft:mossy_cobblestone
fill 403 168 182 405 168 182 minecraft:mossy_cobblestone
setblock 403 168 220 minecraft:stone_bricks
fill 403 168 221 403 171 221 minecraft:mossy_cobblestone
fill 404 168 220 407 168 220 minecraft:mossy_cobblestone
setblock 406 168 182 minecraft:stone_bricks
setblock 406 168 222 minecraft:stone_bricks
fill 407 168 182 410 168 182 minecraft:mossy_cobblestone
setblock 407 168 221 minecraft:stone_bricks
fill 407 168 222 407 171 222 minecraft:mossy_cobblestone
setblock 408 168 220 minecraft:stone_bricks
fill 408 168 221 408 171 221 minecraft:mossy_cobblestone
setblock 409 168 183 minecraft:mossy_cobblestone
fill 409 168 220 409 171 220 minecraft:mossy_cobblestone
setblock 410 168 183 minecraft:stone_bricks
setblock 411 168 182 minecraft:stone_bricks
fill 411 168 183 412 170 183 minecraft:mossy_cobblestone
setblock 411 168 222 minecraft:stone_bricks
fill 412 168 182 412 171 182 minecraft:mossy_cobblestone
setblock 412 168 220 minecraft:mossy_cobblestone
setblock 412 168 221 minecraft:stone_bricks
fill 412 168 222 412 171 222 minecraft:mossy_cobblestone
fill 413 168 221 413 171 221 minecraft:mossy_cobblestone
setblock 414 168 198 minecraft:mossy_cobblestone
setblock 414 168 199 minecraft:stone_bricks
fill 414 168 200 414 170 200 minecraft:mossy_cobblestone
setblock 414 168 203 minecraft:mossy_cobblestone
setblock 415 168 198 minecraft:stone_bricks
fill 415 168 199 415 171 199 minecraft:mossy_cobblestone
setblock 415 168 202 minecraft:mossy_cobblestone
setblock 415 168 203 minecraft:stone_bricks
fill 415 168 204 415 171 204 minecraft:mossy_cobblestone
setblock 416 168 182 minecraft:stone_bricks
setblock 416 168 193 minecraft:mossy_cobblestone
setblock 416 168 197 minecraft:stone_bricks
fill 416 168 198 416 171 198 minecraft:mossy_cobblestone
setblock 416 168 202 minecraft:stone_bricks
fill 416 168 203 416 171 203 minecraft:mossy_cobblestone
setblock 416 168 222 minecraft:stone_bricks
fill 417 168 182 417 170 183 minecraft:mossy_cobblestone
setblock 417 168 191 minecraft:stone_bricks
fill 417 168 192 417 170 192 minecraft:mossy_cobblestone
setblock 417 168 196 minecraft:stone_bricks
fill 417 168 197 417 171 197 minecraft:mossy_cobblestone
setblock 417 168 201 minecraft:stone_bricks
fill 417 168 202 417 171 202 minecraft:mossy_cobblestone
setblock 417 168 206 minecraft:stone_bricks
fill 417 168 207 417 171 207 minecraft:mossy_cobblestone
setblock 417 168 221 minecraft:stone_bricks
fill 417 168 222 417 170 222 minecraft:mossy_cobblestone
fill 377 169 182 379 169 182 minecraft:mossy_cobblestone
setblock 377 169 184 minecraft:mossy_cobblestone
setblock 377 169 185 minecraft:stone_bricks
fill 377 169 186 377 169 189 minecraft:mossy_cobblestone
setblock 377 169 190 minecraft:stone_bricks
fill 377 169 191 377 170 191 minecraft:mossy_cobblestone
setblock 377 169 195 minecraft:stone_bricks
fill 377 169 196 377 171 196 minecraft:mossy_cobblestone
setblock 377 169 200 minecraft:stone_bricks
fill 377 169 201 377 172 201 minecraft:mossy_cobblestone
setblock 377 169 205 minecraft:stone_bricks
setblock 377 169 220 minecraft:stone_bricks
fill 377 169 221 377 171 222 minecraft:mossy_cobblestone
setblock 378 169 183 minecraft:mossy_cobblestone
setblock 378 169 184 minecraft:stone_bricks
setblock 378 169 199 minecraft:stone_bricks
fill 378 169 200 378 170 200 minecraft:mossy_cobblestone
fill 378 169 222 379 169 222 minecraft:mossy_cobblestone
setblock 379 169 183 minecraft:stone_bricks
setblock 379 169 184 minecraft:light[level=12]
setblock 379 169 192 minecraft:light[level=12]
setblock 379 169 200 minecraft:light[level=12]
setblock 379 169 208 minecraft:light[level=12]
setblock 379 169 216 minecraft:light[level=12]
setblock 380 169 182 minecraft:stone_bricks
fill 380 169 183 383 169 183 minecraft:mossy_cobblestone
setblock 380 169 222 minecraft:stone_bricks
fill 381 169 182 384 169 182 minecraft:mossy_cobblestone
setblock 381 169 221 minecraft:stone_bricks
fill 381 169 222 384 169 222 minecraft:mossy_cobblestone
fill 382 169 221 382 172 221 minecraft:mossy_cobblestone
setblock 384 169 183 minecraft:stone_bricks
fill 384 169 184 384 172 184 minecraft:mossy_cobblestone
fill 384 169 220 384 171 220 minecraft:mossy_cobblestone
setblock 385 169 182 minecraft:stone_bricks
fill 385 169 183 385 172 183 minecraft:mossy_cobblestone
setblock 385 169 222 minecraft:stone_bricks
fill 386 169 182 386 172 182 minecraft:mossy_cobblestone
setblock 386 169 221 minecraft:stone_bricks
fill 386 169 222 386 172 222 minecraft:mossy_cobblestone
setblock 387 169 192 minecraft:light[level=12]
setblock 387 169 200 minecraft:light[level=12]
setblock 387 169 208 minecraft:light[level=12]
setblock 387 169 216 minecraft:light[level=12]
setblock 387 169 219 minecraft:mossy_cobblestone
setblock 387 169 220 minecraft:stone_bricks
fill 387 169 221 387 172 221 minecraft:mossy_cobblestone
setblock 388 169 184 minecraft:stone_bricks
setblock 388 169 219 minecraft:stone_bricks
fill 388 169 220 388 172 220 minecraft:mossy_cobblestone
setblock 389 169 183 minecraft:stone_bricks
fill 389 169 184 389 172 184 minecraft:mossy_cobblestone
fill 389 169 219 389 171 219 minecraft:mossy_cobblestone
setblock 390 169 182 minecraft:stone_bricks
fill 390 169 183 390 172 183 minecraft:mossy_cobblestone
setblock 390 169 222 minecraft:stone_bricks
fill 391 169 182 391 172 182 minecraft:mossy_cobblestone
setblock 391 169 221 minecraft:stone_bricks
fill 391 169 222 391 172 222 minecraft:mossy_cobblestone
setblock 392 169 220 minecraft:stone_bricks
fill 392 169 221 392 172 221 minecraft:mossy_cobblestone
setblock 393 169 219 minecraft:stone_bricks
fill 393 169 220 393 172 220 minecraft:mossy_cobblestone
setblock 394 169 183 minecraft:stone_bricks
setblock 395 169 182 minecraft:stone_bricks
fill 395 169 183 395 171 183 minecraft:mossy_cobblestone
setblock 395 169 184 minecraft:light[level=12]
setblock 395 169 192 minecraft:light[level=12]
setblock 395 169 200 minecraft:light[level=12]
setblock 395 169 208 minecraft:light[level=12]
setblock 395 169 216 minecraft:light[level=12]
setblock 395 169 222 minecraft:stone_bricks
fill 396 169 182 396 172 182 minecraft:mossy_cobblestone
setblock 396 169 221 minecraft:stone_bricks
fill 396 169 222 399 169 222 minecraft:mossy_cobblestone
setblock 397 169 220 minecraft:stone_bricks
fill 397 169 221 400 169 221 minecraft:mossy_cobblestone
setblock 398 169 220 minecraft:mossy_cobblestone
setblock 400 169 182 minecraft:stone_bricks
setblock 400 169 222 minecraft:stone_bricks
fill 401 169 182 404 169 182 minecraft:mossy_cobblestone
setblock 401 169 221 minecraft:stone_bricks
fill 401 169 222 401 172 222 minecraft:mossy_cobblestone
fill 402 169 221 402 172 221 minecraft:mossy_cobblestone
setblock 403 169 184 minecraft:light[level=12]
setblock 403 169 192 minecraft:light[level=12]
setblock 403 169 200 minecraft:light[level=12]
setblock 403 169 208 minecraft:light[level=12]
setblock 403 169 216 minecraft:light[level=12]
fill 403 169 220 406 169 220 minecraft:mossy_cobblestone
setblock 405 169 182 minecraft:stone_bricks
setblock 405 169 222 minecraft:stone_bricks
fill 406 169 182 409 169 182 minecraft:mossy_cobblestone
setblock 406 169 221 minecraft:stone_bricks
fill 406 169 222 406 172 222 minecraft:mossy_cobblestone
fill 407 169 183 408 169 183 minecraft:mossy_cobblestone
setblock 407 169 220 minecraft:stone_bricks
fill 407 169 221 407 172 221 minecraft:mossy_cobblestone
fill 408 169 220 408 171 220 minecraft:mossy_cobblestone
setblock 409 169 183 minecraft:stone_bricks
setblock 410 169 182 minecraft:stone_bricks
fill 410 169 183 410 172 183 minecraft:mossy_cobblestone
setblock 410 169 222 minecraft:stone_bricks
fill 411 169 182 411 172 182 minecraft:mossy_cobblestone
setblock 411 169 184 minecraft:light[level=12]
setblock 411 169 192 minecraft:light[level=12]
setblock 411 169 200 minecraft:light[level=12]
setblock 411 169 208 minecraft:light[level=12]
setblock 411 169 216 minecraft:light[level=12]
setblock 411 169 221 minecraft:stone_bricks
fill 411 169 222 411 172 222 minecraft:mossy_cobblestone
setblock 412 169 220 minecraft:stone_bricks
fill 412 169 221 412 171 221 minecraft:mossy_cobblestone
setblock 413 169 183 minecraft:mossy_cobblestone
setblock 414 169 182 minecraft:mossy_cobblestone
setblock 414 169 198 minecraft:stone_bricks
fill 414 169 199 414 170 199 minecraft:mossy_cobblestone
setblock 414 169 203 minecraft:stone_bricks
setblock 415 169 182 minecraft:stone_bricks
setblock 415 169 197 minecraft:stone_bricks
fill 415 169 198 415 171 198 minecraft:mossy_cobblestone
setblock 415 169 202 minecraft:stone_bricks
fill 415 169 203 415 172 203 minecraft:mossy_cobblestone
fill 415 169 205 415 170 205 minecraft:mossy_cobblestone
setblock 415 169 222 minecraft:stone_bricks
fill 416 169 182 416 172 182 minecraft:mossy_cobblestone
setblock 416 169 196 minecraft:stone_bricks
fill 416 169 197 416 172 197 minecraft:mossy_cobblestone
setblock 416 169 201 minecraft:stone_bricks
fill 416 169 202 416 172 202 minecraft:mossy_cobblestone
setblock 416 169 206 minecraft:stone_bricks
fill 416 169 222 416 171 222 minecraft:mossy_cobblestone
setblock 417 169 184 minecraft:mossy_cobblestone
setblock 417 169 191 minecraft:mossy_cobblestone
setblock 417 169 195 minecraft:stone_bricks
fill 417 169 196 417 172 196 minecraft:mossy_cobblestone
setblock 417 169 200 minecraft:stone_bricks
fill 417 169 201 417 172 201 minecraft:mossy_cobblestone
setblock 417 169 205 minecraft:stone_bricks
fill 417 169 206 417 172 206 minecraft:mossy_cobblestone
setblock 417 169 220 minecraft:stone_bricks
fill 417 169 221 417 170 221 minecraft:mossy_cobblestone
fill 377 170 182 378 170 182 minecraft:mossy_cobblestone
setblock 377 170 184 minecraft:stone_bricks
fill 377 170 185 377 170 188 minecraft:mossy_cobblestone
setblock 377 170 189 minecraft:stone_bricks
fill 377 170 190 377 171 190 minecraft:mossy_cobblestone
setblock 377 170 194 minecraft:stone_bricks
fill 377 170 195 377 171 195 minecraft:mossy_cobblestone
setblock 377 170 199 minecraft:stone_bricks
fill 377 170 200 377 173 200 minecraft:mossy_cobblestone
setblock 377 170 204 minecraft:stone_bricks
fill 377 170 205 377 171 205 minecraft:mossy_cobblestone
setblock 377 170 220 minecraft:mossy_cobblestone
setblock 378 170 183 minecraft:stone_bricks
fill 378 170 184 378 172 185 minecraft:mossy_cobblestone
setblock 378 170 198 minecraft:stone_bricks
setblock 378 170 199 minecraft:mossy_cobblestone
setblock 378 170 222 minecraft:mossy_cobblestone
setblock 379 170 182 minecraft:stone_bricks
fill 379 170 183 382 170 183 minecraft:mossy_cobblestone
setblock 379 170 222 minecraft:stone_bricks
fill 380 170 182 383 170 182 minecraft:mossy_cobblestone
fill 380 170 222 383 170 222 minecraft:mossy_cobblestone
fill 381 170 221 381 173 221 minecraft:mossy_cobblestone
setblock 382 170 184 minecraft:stone_bricks
setblock 383 170 183 minecraft:stone_bricks
fill 383 170 184 383 173 184 minecraft:mossy_cobblestone
setblock 384 170 182 minecraft:stone_bricks
fill 384 170 183 384 173 183 minecraft:mossy_cobblestone
setblock 384 170 222 minecraft:stone_bricks
fill 385 170 182 385 173 182 minecraft:mossy_cobblestone
setblock 385 170 221 minecraft:stone_bricks
fill 385 170 222 385 173 222 minecraft:mossy_cobblestone
setblock 386 170 220 minecraft:stone_bricks
fill 386 170 221 386 173 221 minecraft:mossy_cobblestone
setblock 387 170 183 minecraft:mossy_cobblestone
setblock 387 170 184 minecraft:stone_bricks
setblock 387 170 219 minecraft:stone_bricks
fill 387 170 220 387 173 220 minecraft:mossy_cobblestone
setblock 388 170 183 minecraft:stone_bricks
fill 388 170 184 388 173 184 minecraft:mossy_cobblestone
fill 388 170 219 388 171 219 minecraft:mossy_cobblestone
setblock 389 170 182 minecraft:stone_bricks
fill 389 170 183 389 173 183 minecraft:mossy_cobblestone
setblock 389 170 222 minecraft:stone_bricks
fill 390 170 182 390 173 182 minecraft:mossy_cobblestone
setblock 390 170 221 minecraft:stone_bricks
fill 390 170 222 390 173 222 minecraft:mossy_cobblestone
setblock 391 170 220 minecraft:stone_bricks
fill 391 170 221 391 173 221 minecraft:mossy_cobblestone
setblock 392 170 184 minecraft:stone_bricks
setblock 392 170 219 minecraft:stone_bricks
fill 392 170 220 392 172 220 minecraft:mossy_cobblestone
setblock 393 170 183 minecraft:stone_bricks
setblock 394 170 182 minecraft:stone_bricks
fill 394 170 183 394 172 183 minecraft:mossy_cobblestone
setblock 394 170 222 minecraft:stone_bricks
fill 395 170 182 395 173 182 minecraft:mossy_cobblestone
setblock 395 170 221 minecraft:stone_bricks
fill 395 170 222 398 170 222 minecraft:mossy_cobblestone
setblock 396 170 220 minecraft:stone_bricks
fill 396 170 221 399 170 221 minecraft:mossy_cobblestone
setblock 399 170 182 minecraft:stone_bricks
setblock 399 170 222 minecraft:stone_bricks
fill 400 170 182 403 170 182 minecraft:mossy_cobblestone
setblock 400 170 221 minecraft:stone_bricks
fill 400 170 222 400 173 222 minecraft:mossy_cobblestone
fill 401 170 221 401 173 221 minecraft:mossy_cobblestone
fill 403 170 220 405 170 220 minecraft:mossy_cobblestone
setblock 404 170 182 minecraft:stone_bricks
setblock 404 170 222 minecraft:stone_bricks
fill 405 170 182 407 170 183 minecraft:mossy_cobblestone
setblock 405 170 221 minecraft:stone_bricks
fill 405 170 222 405 173 222 minecraft:mossy_cobblestone
setblock 406 170 220 minecraft:stone_bricks
fill 406 170 221 406 173 221 minecraft:mossy_cobblestone
fill 407 170 220 407 172 220 minecraft:mossy_cobblestone
setblock 408 170 182 minecraft:mossy_cobblestone
setblock 408 170 183 minecraft:stone_bricks
setblock 409 170 182 minecraft:stone_bricks
fill 409 170 183 409 173 183 minecraft:mossy_cobblestone
setblock 409 170 222 minecraft:stone_bricks
fill 410 170 182 410 173 182 minecraft:mossy_cobblestone
setblock 410 170 221 minecraft:stone_bricks
fill 410 170 222 410 173 222 minecraft:mossy_cobblestone
setblock 411 170 220 minecraft:stone_bricks
fill 411 170 221 411 172 221 minecraft:mossy_cobblestone
setblock 413 170 183 minecraft:stone_bricks
setblock 414 170 182 minecraft:stone_bricks
fill 414 170 183 414 171 183 minecraft:mossy_cobblestone
setblock 414 170 201 minecraft:mossy_cobblestone
setblock 414 170 202 minecraft:stone_bricks
setblock 414 170 203 minecraft:mossy_cobblestone
setblock 414 170 222 minecraft:stone_bricks
fill 415 170 182 415 173 182 minecraft:mossy_cobblestone
setblock 415 170 197 minecraft:mossy_cobblestone
setblock 415 170 201 minecraft:stone_bricks
fill 415 170 202 415 172 202 minecraft:mossy_cobblestone
fill 415 170 222 415 171 222 minecraft:mossy_cobblestone
setblock 416 170 195 minecraft:stone_bricks
fill 416 170 196 416 171 196 minecraft:mossy_cobblestone
setblock 416 170 200 minecraft:stone_bricks
fill 416 170 201 416 173 201 minecraft:mossy_cobblestone
setblock 416 170 205 minecraft:stone_bricks
fill 416 170 206 416 171 206 minecraft:mossy_cobblestone
setblock 417 170 184 minecraft:stone_bricks
fill 417 170 185 417 172 186 minecraft:mossy_cobblestone
setblock 417 170 194 minecraft:stone_bricks
fill 417 170 195 417 172 195 minecraft:mossy_cobblestone
setblock 417 170 199 minecraft:stone_bricks
fill 417 170 200 417 173 200 minecraft:mossy_cobblestone
setblock 417 170 204 minecraft:stone_bricks
fill 417 170 205 417 173 205 minecraft:mossy_cobblestone
setblock 377 171 182 minecraft:mossy_cobblestone
setblock 377 171 183 minecraft:stone_bricks
fill 377 171 184 377 171 187 minecraft:mossy_cobblestone
setblock 377 171 188 minecraft:stone_bricks
fill 377 171 189 377 173 189 minecraft:mossy_cobblestone
setblock 377 171 194 minecraft:mossy_cobblestone
setblock 377 171 198 minecraft:stone_bricks
fill 377 171 199 377 172 199 minecraft:mossy_cobblestone
setblock 377 171 203 minecraft:stone_bricks
fill 377 171 204 377 172 204 minecraft:mossy_cobblestone
setblock 378 171 182 minecraft:stone_bricks
fill 378 171 183 381 171 183 minecraft:mossy_cobblestone
setblock 378 171 222 minecraft:stone_bricks
fill 379 171 182 382 171 182 minecraft:mossy_cobblestone
fill 379 171 222 382 171 222 minecraft:mossy_cobblestone
setblock 381 171 184 minecraft:stone_bricks
setblock 382 171 183 minecraft:stone_bricks
fill 382 171 184 382 174 184 minecraft:mossy_cobblestone
setblock 383 171 182 minecraft:stone_bricks
fill 383 171 183 383 174 183 minecraft:mossy_cobblestone
setblock 383 171 222 minecraft:stone_bricks
fill 384 171 182 384 174 182 minecraft:mossy_cobblestone
setblock 384 171 221 minecraft:stone_bricks
fill 384 171 222 384 174 222 minecraft:mossy_cobblestone
setblock 385 171 184 minecraft:mossy_cobblestone
setblock 385 171 220 minecraft:stone_bricks
fill 385 171 221 385 174 221 minecraft:mossy_cobblestone
setblock 386 171 184 minecraft:stone_bricks
fill 386 171 220 386 174 220 minecraft:mossy_cobblestone
setblock 387 171 183 minecraft:stone_bricks
fill 387 171 184 387 174 184 minecraft:mossy_cobblestone
setblock 388 171 182 minecraft:stone_bricks
fill 388 171 183 388 174 183 minecraft:mossy_cobblestone
setblock 388 171 222 minecraft:stone_bricks
fill 389 171 182 389 174 182 minecraft:mossy_cobblestone
setblock 389 171 221 minecraft:stone_bricks
fill 389 171 222 389 174 222 minecraft:mossy_cobblestone
setblock 390 171 220 minecraft:stone_bricks
fill 390 171 221 390 174 221 minecraft:mossy_cobblestone
setblock 391 171 184 minecraft:stone_bricks
setblock 391 171 219 minecraft:stone_bricks
fill 391 171 220 391 173 220 minecraft:mossy_cobblestone
setblock 392 171 183 minecraft:stone_bricks
setblock 392 171 184 minecraft:mossy_cobblestone
setblock 393 171 182 minecraft:stone_bricks
fill 393 171 183 393 173 183 minecraft:mossy_cobblestone
setblock 393 171 222 minecraft:stone_bricks
fill 394 171 182 394 174 182 minecraft:mossy_cobblestone
setblock 394 171 221 minecraft:stone_bricks
fill 394 171 222 397 171 222 minecraft:mossy_cobblestone
setblock 395 171 220 minecraft:stone_bricks
fill 395 171 221 398 171 221 minecraft:mossy_cobblestone
setblock 398 171 182 minecraft:stone_bricks
setblock 398 171 222 minecraft:stone_bricks
fill 399 171 182 402 171 182 minecraft:mossy_cobblestone
setblock 399 171 221 minecraft:stone_bricks
fill 399 171 222 399 174 222 minecraft:mossy_cobblestone
fill 400 171 221 400 172 221 minecraft:mossy_cobblestone
setblock 403 171 182 minecraft:stone_bricks
setblock 403 171 222 minecraft:stone_bricks
fill 404 171 182 406 171 183 minecraft:mossy_cobblestone
setblock 404 171 220 minecraft:mossy_cobblestone
setblock 404 171 221 minecraft:stone_bricks
fill 404 171 222 404 174 222 minecraft:mossy_cobblestone
setblock 405 171 220 minecraft:stone_bricks
fill 405 171 221 405 174 221 minecraft:mossy_cobblestone
fill 406 171 220 406 172 220 minecraft:mossy_cobblestone
setblock 407 171 182 minecraft:mossy_cobblestone
setblock 407 171 183 minecraft:stone_bricks
setblock 408 171 182 minecraft:stone_bricks
fill 408 171 183 408 174 183 minecraft:mossy_cobblestone
setblock 408 171 222 minecraft:stone_bricks
fill 409 171 182 409 174 182 minecraft:mossy_cobblestone
setblock 409 171 221 minecraft:stone_bricks
fill 409 171 222 409 174 222 minecraft:mossy_cobblestone
fill 410 171 221 410 172 221 minecraft:mossy_cobblestone
setblock 411 171 183 minecraft:mossy_cobblestone
setblock 412 171 183 minecraft:stone_bricks
setblock 413 171 182 minecraft:stone_bricks
fill 413 171 183 413 172 183 minecraft:mossy_cobblestone
setblock 413 171 222 minecraft:stone_bricks
fill 414 171 182 414 174 182 minecraft:mossy_cobblestone
setblock 414 171 201 minecraft:stone_bricks
fill 414 171 222 414 172 222 minecraft:mossy_cobblestone
setblock 415 171 200 minecraft:stone_bricks
fill 415 171 201 415 172 201 minecraft:mossy_cobblestone
setblock 416 171 199 minecraft:stone_bricks
fill 416 171 200 416 173 200 minecraft:mossy_cobblestone
setblock 416 171 204 minecraft:stone_bricks
fill 416 171 205 416 173 205 minecraft:mossy_cobblestone
setblock 417 171 182 minecraft:mossy_cobblestone
setblock 417 171 183 minecraft:stone_bricks
fill 417 171 184 417 174 184 minecraft:mossy_cobblestone
setblock 417 171 193 minecraft:stone_bricks
fill 417 171 194 417 172 194 minecraft:mossy_cobblestone
setblock 417 171 198 minecraft:stone_bricks
fill 417 171 199 417 174 199 minecraft:mossy_cobblestone
setblock 417 171 203 minecraft:stone_bricks
fill 417 171 204 417 174 204 minecraft:mossy_cobblestone
setblock 377 172 182 minecraft:stone_bricks
fill 377 172 183 377 172 186 minecraft:mossy_cobblestone
setblock 377 172 187 minecraft:stone_bricks
fill 377 172 188 377 175 188 minecraft:mossy_cobblestone
setblock 377 172 197 minecraft:stone_bricks
setblock 377 172 198 minecraft:mossy_cobblestone
setblock 377 172 202 minecraft:stone_bricks
fill 377 172 203 377 173 203 minecraft:mossy_cobblestone
setblock 377 172 221 minecraft:mossy_cobblestone
setblock 377 172 222 minecraft:stone_bricks
fill 378 172 182 380 172 183 minecraft:mossy_cobblestone
setblock 378 172 186 minecraft:stone_bricks
fill 378 172 222 381 172 222 minecraft:mossy_cobblestone
setblock 381 172 182 minecraft:mossy_cobblestone
setblock 381 172 183 minecraft:stone_bricks
fill 381 172 184 381 175 184 minecraft:mossy_cobblestone
setblock 382 172 182 minecraft:stone_bricks
fill 382 172 183 382 175 183 minecraft:mossy_cobblestone
setblock 382 172 222 minecraft:stone_bricks
fill 383 172 182 383 175 182 minecraft:mossy_cobblestone
setblock 383 172 221 minecraft:stone_bricks
fill 383 172 222 383 175 222 minecraft:mossy_cobblestone
setblock 384 172 220 minecraft:stone_bricks
fill 384 172 221 384 175 221 minecraft:mossy_cobblestone
setblock 385 172 184 minecraft:stone_bricks
fill 385 172 220 385 174 220 minecraft:mossy_cobblestone
setblock 386 172 183 minecraft:stone_bricks
fill 386 172 184 386 172 185 minecraft:mossy_cobblestone
setblock 387 172 182 minecraft:stone_bricks
fill 387 172 183 387 175 183 minecraft:mossy_cobblestone
setblock 387 172 222 minecraft:stone_bricks
fill 388 172 182 388 175 182 minecraft:mossy_cobblestone
setblock 388 172 221 minecraft:stone_bricks
fill 388 172 222 388 175 222 minecraft:mossy_cobblestone
setblock 389 172 220 minecraft:stone_bricks
fill 389 172 221 389 175 221 minecraft:mossy_cobblestone
setblock 390 172 184 minecraft:stone_bricks
fill 390 172 220 390 173 220 minecraft:mossy_cobblestone
setblock 391 172 183 minecraft:stone_bricks
setblock 391 172 184 minecraft:mossy_cobblestone
setblock 392 172 182 minecraft:stone_bricks
fill 392 172 183 392 174 183 minecraft:mossy_cobblestone
setblock 392 172 222 minecraft:stone_bricks
fill 393 172 182 393 175 182 minecraft:mossy_cobblestone
setblock 393 172 221 minecraft:stone_bricks
fill 393 172 222 396 172 222 minecraft:mossy_cobblestone
fill 394 172 221 397 172 221 minecraft:mossy_cobblestone
setblock 397 172 182 minecraft:stone_bricks
setblock 397 172 222 minecraft:stone_bricks
fill 398 172 182 401 172 182 minecraft:mossy_cobblestone
setblock 398 172 221 minecraft:stone_bricks
fill 398 172 222 398 175 222 minecraft:mossy_cobblestone
setblock 399 172 221 minecraft:mossy_cobblestone
setblock 402 172 182 minecraft:stone_bricks
setblock 402 172 222 minecraft:stone_bricks
fill 403 172 182 406 172 182 minecraft:mossy_cobblestone
setblock 403 172 221 minecraft:stone_bricks
fill 403 172 222 403 175 222 minecraft:mossy_cobblestone
fill 404 172 183 405 172 183 minecraft:mossy_cobblestone
fill 404 172 221 404 174 221 minecraft:mossy_cobblestone
setblock 406 172 183 minecraft:stone_bricks
setblock 407 172 182 minecraft:stone_bricks
fill 407 172 183 407 175 183 minecraft:mossy_cobblestone
setblock 407 172 222 minecraft:stone_bricks
fill 408 172 182 408 175 182 minecraft:mossy_cobblestone
setblock 408 172 221 minecraft:stone_bricks
fill 408 172 222 408 175 222 minecraft:mossy_cobblestone
fill 409 172 221 409 173 221 minecraft:mossy_cobblestone
setblock 411 172 183 minecraft:stone_bricks
setblock 412 172 182 minecraft:stone_bricks
fill 412 172 183 412 173 183 minecraft:mossy_cobblestone
setblock 412 172 222 minecraft:stone_bricks
fill 413 172 182 413 175 182 minecraft:mossy_cobblestone
fill 413 172 222 413 173 222 minecraft:mossy_cobblestone
setblock 415 172 200 minecraft:mossy_cobblestone
setblock 416 172 198 minecraft:stone_bricks
fill 416 172 199 416 173 199 minecraft:mossy_cobblestone
setblock 416 172 203 minecraft:stone_bricks
fill 416 172 204 416 173 204 minecraft:mossy_cobblestone
setblock 417 172 182 minecraft:stone_bricks
fill 417 172 183 417 175 183 minecraft:mossy_cobblestone
setblock 417 172 187 minecraft:stone_bricks
setblock 417 172 197 minecraft:stone_bricks
fill 417 172 198 417 174 198 minecraft:mossy_cobblestone
setblock 417 172 202 minecraft:stone_bricks
fill 417 172 203 417 175 203 minecraft:mossy_cobblestone
setblock 417 172 207 minecraft:stone_bricks
fill 377 173 182 377 173 185 minecraft:mossy_cobblestone
setblock 377 173 186 minecraft:stone_bricks
fill 377 173 187 377 176 187 minecraft:mossy_cobblestone
setblock 377 173 201 minecraft:stone_bricks
setblock 377 173 202 minecraft:mossy_cobblestone
fill 377 173 222 380 173 222 minecraft:mossy_cobblestone
fill 378 173 182 378 173 184 minecraft:mossy_cobblestone
setblock 378 173 185 minecraft:stone_bricks
fill 378 173 186 378 176 186 minecraft:mossy_cobblestone
fill 379 173 182 379 173 183 minecraft:mossy_cobblestone
setblock 380 173 182 minecraft:mossy_cobblestone
setblock 380 173 183 minecraft:stone_bricks
setblock 381 173 182 minecraft:stone_bricks
fill 381 173 183 381 176 183 minecraft:mossy_cobblestone
setblock 381 173 222 minecraft:stone_bricks
fill 382 173 182 382 176 182 minecraft:mossy_cobblestone
setblock 382 173 221 minecraft:stone_bricks
fill 382 173 222 382 176 222 minecraft:mossy_cobblestone
fill 383 173 221 383 176 221 minecraft:mossy_cobblestone
setblock 384 173 184 minecraft:stone_bricks
setblock 384 173 220 minecraft:mossy_cobblestone
setblock 385 173 183 minecraft:stone_bricks
fill 385 173 184 386 175 184 minecraft:mossy_cobblestone
setblock 386 173 182 minecraft:stone_bricks
fill 386 173 183 386 176 183 minecraft:mossy_cobblestone
setblock 386 173 222 minecraft:stone_bricks
fill 387 173 182 387 176 182 minecraft:mossy_cobblestone
setblock 387 173 221 minecraft:stone_bricks
fill 387 173 222 387 176 222 minecraft:mossy_cobblestone
setblock 388 173 220 minecraft:stone_bricks
fill 388 173 221 388 176 221 minecraft:mossy_cobblestone
setblock 389 173 184 minecraft:stone_bricks
fill 389 173 220 389 174 220 minecraft:mossy_cobblestone
setblock 390 173 183 minecraft:stone_bricks
fill 390 173 184 390 174 184 minecraft:mossy_cobblestone
setblock 391 173 182 minecraft:stone_bricks
fill 391 173 183 391 175 183 minecraft:mossy_cobblestone
setblock 391 173 222 minecraft:stone_bricks
fill 392 173 182 392 176 182 minecraft:mossy_cobblestone
setblock 392 173 221 minecraft:stone_bricks
fill 392 173 222 395 173 222 minecraft:mossy_cobblestone
fill 393 173 221 395 173 221 minecraft:mossy_cobblestone
setblock 396 173 182 minecraft:stone_bricks
setblock 396 173 222 minecraft:stone_bricks
fill 397 173 182 400 173 182 minecraft:mossy_cobblestone
fill 397 173 222 397 175 222 minecraft:mossy_cobblestone
setblock 401 173 182 minecraft:stone_bricks
setblock 401 173 222 minecraft:stone_bricks
fill 402 173 182 405 173 182 minecraft:mossy_cobblestone
setblock 402 173 221 minecraft:stone_bricks
fill 402 173 222 402 176 222 minecraft:mossy_cobblestone
fill 403 173 221 403 174 221 minecraft:mossy_cobblestone
setblock 404 173 183 minecraft:mossy_cobblestone
setblock 405 173 183 minecraft:stone_bricks
setblock 406 173 182 minecraft:stone_bricks
fill 406 173 183 406 176 183 minecraft:mossy_cobblestone
setblock 406 173 222 minecraft:stone_bricks
fill 407 173 182 407 176 182 minecraft:mossy_cobblestone
setblock 407 173 221 minecraft:stone_bricks
fill 407 173 222 407 176 222 minecraft:mossy_cobblestone
setblock 408 173 221 minecraft:mossy_cobblestone
setblock 410 173 183 minecraft:stone_bricks
setblock 411 173 182 minecraft:stone_bricks
fill 411 173 183 411 174 183 minecraft:mossy_cobblestone
setblock 411 173 222 minecraft:stone_bricks
fill 412 173 182 412 176 182 minecraft:mossy_cobblestone
setblock 412 173 222 minecraft:mossy_cobblestone
setblock 416 173 182 minecraft:stone_bricks
setblock 416 173 202 minecraft:stone_bricks
fill 416 173 203 416 174 203 minecraft:mossy_cobblestone
fill 417 173 182 417 176 182 minecraft:mossy_cobblestone
setblock 417 173 185 minecraft:mossy_cobblestone
setblock 417 173 186 minecraft:stone_bricks
fill 417 173 187 417 176 187 minecraft:mossy_cobblestone
setblock 417 173 196 minecraft:stone_bricks
setblock 417 173 197 minecraft:mossy_cobblestone
setblock 417 173 201 minecraft:stone_bricks
fill 417 173 202 417 176 202 minecraft:mossy_cobblestone
setblock 417 173 206 minecraft:stone_bricks
setblock 417 173 207 minecraft:mossy_cobblestone
fill 377 174 182 377 174 184 minecraft:mossy_cobblestone
setblock 377 174 185 minecraft:stone_bricks
fill 377 174 186 377 177 186 minecraft:mossy_cobblestone
fill 378 174 182 378 174 183 minecraft:mossy_cobblestone
setblock 378 174 184 minecraft:stone_bricks
fill 378 174 185 378 177 185 minecraft:mossy_cobblestone
fill 378 174 222 379 174 222 minecraft:mossy_cobblestone
setblock 379 174 182 minecraft:mossy_cobblestone
setblock 379 174 183 minecraft:stone_bricks
setblock 380 174 182 minecraft:stone_bricks
fill 380 174 183 380 176 184 minecraft:mossy_cobblestone
setblock 380 174 222 minecraft:stone_bricks
fill 381 174 182 381 177 182 minecraft:mossy_cobblestone
fill 381 174 222 381 177 222 minecraft:mossy_cobblestone
fill 382 174 221 382 177 221 minecraft:mossy_cobblestone
setblock 383 174 184 minecraft:stone_bricks
setblock 384 174 183 minecraft:stone_bricks
fill 384 174 184 384 177 184 minecraft:mossy_cobblestone
setblock 385 174 182 minecraft:stone_bricks
fill 385 174 183 385 177 183 minecraft:mossy_cobblestone
setblock 385 174 222 minecraft:stone_bricks
fill 386 174 182 386 177 182 minecraft:mossy_cobblestone
setblock 386 174 221 minecraft:stone_bricks
fill 386 174 222 386 177 222 minecraft:mossy_cobblestone
setblock 387 174 220 minecraft:stone_bricks
fill 387 174 221 387 177 221 minecraft:mossy_cobblestone
setblock 388 174 184 minecraft:stone_bricks
setblock 388 174 220 minecraft:mossy_cobblestone
setblock 389 174 183 minecraft:stone_bricks
fill 389 174 184 389 175 184 minecraft:mossy_cobblestone
setblock 390 174 182 minecraft:stone_bricks
fill 390 174 183 390 177 183 minecraft:mossy_cobblestone
setblock 390 174 222 minecraft:stone_bricks
fill 391 174 182 391 177 182 minecraft:mossy_cobblestone
setblock 391 174 221 minecraft:stone_bricks
fill 391 174 222 394 174 222 minecraft:mossy_cobblestone
fill 392 174 221 393 174 221 minecraft:mossy_cobblestone
setblock 395 174 182 minecraft:stone_bricks
setblock 395 174 222 minecraft:stone_bricks
setblock 396 174 182 minecraft:mossy_cobblestone
fill 396 174 222 396 175 222 minecraft:mossy_cobblestone
setblock 400 174 182 minecraft:stone_bricks
setblock 400 174 222 minecraft:stone_bricks
fill 401 174 182 404 174 182 minecraft:mossy_cobblestone
fill 401 174 222 401 177 222 minecraft:mossy_cobblestone
setblock 404 174 183 minecraft:stone_bricks
setblock 405 174 182 minecraft:stone_bricks
fill 405 174 183 405 177 183 minecraft:mossy_cobblestone
setblock 405 174 222 minecraft:stone_bricks
fill 406 174 182 406 177 182 minecraft:mossy_cobblestone
setblock 406 174 221 minecraft:stone_bricks
schedule function dropper:buildpart/44_8 1t
