setblock 348 102 623 minecraft:light[level=12]
setblock 348 102 631 minecraft:light[level=12]
setblock 348 102 639 minecraft:light[level=12]
fill 349 102 604 349 108 604 minecraft:black_concrete
setblock 356 102 607 minecraft:light[level=12]
setblock 356 102 615 minecraft:light[level=12]
setblock 356 102 623 minecraft:light[level=12]
setblock 356 102 631 minecraft:light[level=12]
setblock 356 102 639 minecraft:light[level=12]
fill 358 102 646 360 106 646 minecraft:black_concrete
setblock 364 102 607 minecraft:light[level=12]
setblock 364 102 615 minecraft:light[level=12]
setblock 364 102 623 minecraft:light[level=12]
setblock 364 102 631 minecraft:light[level=12]
setblock 364 102 639 minecraft:light[level=12]
fill 365 102 604 365 108 604 minecraft:black_concrete
fill 371 102 607 371 135 607 minecraft:black_concrete
fill 371 102 614 371 108 614 minecraft:black_concrete
setblock 371 102 627 minecraft:crying_obsidian
fill 371 102 630 371 108 630 minecraft:black_concrete
setblock 371 102 633 minecraft:white_concrete
setblock 371 102 641 minecraft:white_concrete
fill 329 103 611 329 126 611 minecraft:black_concrete
setblock 329 103 632 minecraft:white_concrete
setblock 340 103 646 minecraft:white_concrete
fill 371 103 627 371 139 627 minecraft:black_concrete
fill 371 103 633 371 112 633 minecraft:black_concrete
fill 371 103 641 371 139 641 minecraft:black_concrete
setblock 329 104 621 minecraft:magenta_stained_glass
fill 329 104 632 329 139 632 minecraft:black_concrete
fill 340 104 646 340 133 646 minecraft:black_concrete
setblock 348 104 604 minecraft:magenta_stained_glass
setblock 349 104 646 minecraft:magenta_stained_glass
setblock 329 105 610 minecraft:crying_obsidian
fill 329 105 621 329 113 621 minecraft:black_concrete
setblock 337 105 604 minecraft:white_concrete
fill 348 105 604 348 131 604 minecraft:black_concrete
fill 349 105 646 349 119 646 minecraft:black_concrete
fill 365 105 631 367 106 631 minecraft:gold_block
fill 366 105 630 366 106 630 minecraft:gold_block
fill 366 105 632 366 106 632 minecraft:gold_block
fill 329 106 610 329 135 610 minecraft:black_concrete
fill 337 106 604 337 139 604 minecraft:black_concrete
setblock 361 106 646 minecraft:white_concrete
setblock 371 106 623 minecraft:white_concrete
fill 332 107 626 332 108 627 minecraft:obsidian
setblock 358 107 646 minecraft:white_concrete
fill 359 107 646 361 108 646 minecraft:black_concrete
fill 371 107 623 371 135 623 minecraft:black_concrete
setblock 371 107 625 minecraft:magenta_stained_glass
fill 358 108 646 358 139 646 minecraft:black_concrete
setblock 371 108 618 minecraft:magenta_stained_glass
setblock 371 108 619 minecraft:white_concrete
fill 371 108 625 371 139 625 minecraft:black_concrete
setblock 371 108 634 minecraft:white_concrete
fill 329 109 612 329 110 612 minecraft:magenta_concrete
fill 329 109 628 329 110 628 minecraft:magenta_concrete
setblock 329 109 634 minecraft:magenta_stained_glass
fill 329 109 644 329 110 644 minecraft:magenta_concrete
fill 333 109 604 333 110 604 minecraft:magenta_concrete
fill 343 109 646 343 110 646 minecraft:magenta_concrete
fill 349 109 604 349 110 604 minecraft:magenta_concrete
fill 359 109 646 359 110 646 minecraft:magenta_concrete
fill 360 109 646 361 115 646 minecraft:black_concrete
fill 365 109 604 365 110 604 minecraft:magenta_concrete
fill 371 109 614 371 110 614 minecraft:magenta_concrete
fill 371 109 618 371 132 619 minecraft:black_concrete
fill 371 109 630 371 110 630 minecraft:magenta_concrete
fill 371 109 634 371 134 634 minecraft:black_concrete
fill 329 110 634 329 136 634 minecraft:black_concrete
setblock 332 110 607 minecraft:light[level=12]
setblock 332 110 615 minecraft:light[level=12]
setblock 332 110 623 minecraft:light[level=12]
setblock 332 110 631 minecraft:light[level=12]
setblock 332 110 639 minecraft:light[level=12]
setblock 340 110 607 minecraft:light[level=12]
setblock 340 110 615 minecraft:light[level=12]
setblock 340 110 623 minecraft:light[level=12]
setblock 340 110 631 minecraft:light[level=12]
setblock 340 110 639 minecraft:light[level=12]
setblock 348 110 607 minecraft:light[level=12]
setblock 348 110 615 minecraft:light[level=12]
setblock 348 110 623 minecraft:light[level=12]
setblock 348 110 631 minecraft:light[level=12]
setblock 348 110 639 minecraft:light[level=12]
setblock 356 110 607 minecraft:light[level=12]
setblock 356 110 615 minecraft:light[level=12]
setblock 356 110 623 minecraft:light[level=12]
setblock 356 110 631 minecraft:light[level=12]
setblock 356 110 639 minecraft:light[level=12]
setblock 364 110 607 minecraft:light[level=12]
setblock 364 110 615 minecraft:light[level=12]
setblock 364 110 623 minecraft:light[level=12]
setblock 364 110 631 minecraft:light[level=12]
setblock 364 110 639 minecraft:light[level=12]
fill 329 111 612 329 117 612 minecraft:black_concrete
fill 329 111 628 329 117 628 minecraft:black_concrete
fill 329 111 644 329 117 644 minecraft:black_concrete
fill 333 111 604 333 117 604 minecraft:black_concrete
fill 340 111 632 340 112 632 minecraft:magenta_stained_glass
fill 343 111 646 343 117 646 minecraft:black_concrete
fill 349 111 604 349 117 604 minecraft:black_concrete
setblock 355 111 604 minecraft:crying_obsidian
fill 359 111 646 359 117 646 minecraft:black_concrete
fill 365 111 604 365 117 604 minecraft:black_concrete
fill 371 111 614 371 117 614 minecraft:black_concrete
setblock 371 111 630 minecraft:black_concrete
setblock 329 112 620 minecraft:crying_obsidian
setblock 329 112 627 minecraft:magenta_stained_glass
setblock 345 112 604 minecraft:white_concrete
fill 355 112 604 355 116 604 minecraft:black_concrete
setblock 358 112 604 minecraft:crying_obsidian
setblock 371 112 630 minecraft:magenta_stained_glass
fill 329 113 620 329 131 620 minecraft:black_concrete
fill 329 113 627 329 136 627 minecraft:black_concrete
setblock 329 113 631 minecraft:magenta_stained_glass
fill 340 113 632 341 123 632 minecraft:black_concrete
fill 345 113 604 345 138 604 minecraft:black_concrete
fill 358 113 604 358 136 604 minecraft:black_concrete
fill 371 113 630 371 117 630 minecraft:black_concrete
setblock 371 113 633 minecraft:crying_obsidian
setblock 371 113 642 minecraft:white_concrete
setblock 329 114 621 minecraft:white_concrete
fill 329 114 631 329 137 631 minecraft:black_concrete
setblock 336 114 646 minecraft:crying_obsidian
fill 371 114 633 371 139 633 minecraft:black_concrete
fill 371 114 642 371 134 642 minecraft:black_concrete
fill 329 115 621 329 139 621 minecraft:black_concrete
fill 336 115 646 336 139 646 minecraft:black_concrete
fill 340 115 631 341 123 631 minecraft:black_concrete
fill 340 115 633 341 123 633 minecraft:black_concrete
setblock 371 115 615 minecraft:crying_obsidian
setblock 371 115 632 minecraft:crying_obsidian
setblock 329 116 608 minecraft:white_concrete
fill 339 116 631 339 123 633 minecraft:black_concrete
fill 342 116 631 342 123 633 minecraft:black_concrete
fill 360 116 646 360 139 646 minecraft:black_concrete
setblock 361 116 646 minecraft:magenta_stained_glass
fill 371 116 615 371 130 615 minecraft:black_concrete
fill 371 116 632 371 139 632 minecraft:black_concrete
fill 329 117 608 329 139 608 minecraft:black_concrete
fill 340 117 630 341 123 630 minecraft:black_concrete
fill 340 117 634 341 123 634 minecraft:black_concrete
setblock 355 117 604 minecraft:crying_obsidian
fill 360 117 635 360 118 635 minecraft:magenta_stained_glass
fill 361 117 646 361 139 646 minecraft:black_concrete
setblock 371 117 605 minecraft:magenta_stained_glass
setblock 371 117 624 minecraft:white_concrete
fill 329 118 612 329 119 612 minecraft:magenta_concrete
fill 329 118 628 329 119 628 minecraft:magenta_concrete
setblock 329 118 643 minecraft:crying_obsidian
fill 329 118 644 329 119 644 minecraft:magenta_concrete
setblock 332 118 607 minecraft:light[level=12]
setblock 332 118 615 minecraft:light[level=12]
setblock 332 118 623 minecraft:light[level=12]
setblock 332 118 631 minecraft:light[level=12]
setblock 332 118 639 minecraft:light[level=12]
fill 333 118 604 333 119 604 minecraft:magenta_concrete
fill 338 118 631 338 123 633 minecraft:black_concrete
fill 339 118 630 339 123 630 minecraft:black_concrete
fill 339 118 634 339 123 634 minecraft:black_concrete
setblock 340 118 607 minecraft:light[level=12]
setblock 340 118 615 minecraft:light[level=12]
setblock 340 118 623 minecraft:light[level=12]
setblock 340 118 639 minecraft:light[level=12]
fill 342 118 630 342 123 630 minecraft:black_concrete
fill 342 118 634 342 123 634 minecraft:black_concrete
fill 343 118 631 343 123 633 minecraft:black_concrete
fill 343 118 646 343 119 646 minecraft:magenta_concrete
setblock 348 118 607 minecraft:light[level=12]
setblock 348 118 615 minecraft:light[level=12]
setblock 348 118 623 minecraft:light[level=12]
setblock 348 118 631 minecraft:light[level=12]
setblock 348 118 639 minecraft:light[level=12]
fill 349 118 604 349 119 604 minecraft:magenta_concrete
fill 352 118 634 353 119 635 minecraft:magenta_concrete
fill 355 118 604 355 140 604 minecraft:black_concrete
setblock 356 118 607 minecraft:light[level=12]
setblock 356 118 615 minecraft:light[level=12]
setblock 356 118 623 minecraft:light[level=12]
setblock 356 118 631 minecraft:light[level=12]
setblock 356 118 639 minecraft:light[level=12]
fill 359 118 646 359 119 646 minecraft:magenta_concrete
setblock 364 118 607 minecraft:light[level=12]
setblock 364 118 615 minecraft:light[level=12]
setblock 364 118 623 minecraft:light[level=12]
setblock 364 118 631 minecraft:light[level=12]
setblock 364 118 639 minecraft:light[level=12]
fill 365 118 604 365 119 604 minecraft:magenta_concrete
setblock 368 118 604 minecraft:magenta_stained_glass
fill 371 118 605 371 133 605 minecraft:black_concrete
fill 371 118 614 371 119 614 minecraft:magenta_concrete
fill 371 118 624 371 136 624 minecraft:black_concrete
fill 371 118 630 371 119 630 minecraft:magenta_concrete
fill 329 119 643 329 139 643 minecraft:black_concrete
fill 338 119 630 338 123 630 minecraft:black_concrete
fill 338 119 634 338 123 634 minecraft:black_concrete
fill 339 119 635 342 123 635 minecraft:black_concrete
fill 340 119 629 341 123 629 minecraft:black_concrete
fill 343 119 630 343 123 630 minecraft:black_concrete
fill 343 119 634 343 123 634 minecraft:black_concrete
fill 360 119 635 360 127 635 minecraft:black_concrete
fill 368 119 604 368 139 604 minecraft:black_concrete
setblock 371 119 637 minecraft:magenta_stained_glass
setblock 371 119 640 minecraft:magenta_stained_glass
fill 329 120 612 329 126 612 minecraft:black_concrete
fill 329 120 628 329 126 628 minecraft:black_concrete
fill 329 120 644 329 126 644 minecraft:black_concrete
fill 333 120 604 333 126 604 minecraft:black_concrete
fill 337 120 631 337 123 633 minecraft:black_concrete
fill 339 120 629 339 123 629 minecraft:black_concrete
fill 342 120 629 342 123 629 minecraft:black_concrete
fill 343 120 646 343 126 646 minecraft:black_concrete
fill 344 120 631 344 123 633 minecraft:black_concrete
fill 349 120 604 349 126 604 minecraft:black_concrete
setblock 349 120 646 minecraft:magenta_stained_glass
fill 359 120 635 359 127 635 minecraft:black_concrete
fill 359 120 646 359 126 646 minecraft:black_concrete
fill 365 120 604 365 121 604 minecraft:black_concrete
fill 371 120 614 371 126 614 minecraft:black_concrete
fill 371 120 630 371 126 630 minecraft:black_concrete
fill 371 120 637 371 139 637 minecraft:black_concrete
fill 371 120 640 371 140 640 minecraft:black_concrete
setblock 332 121 646 minecraft:crying_obsidian
fill 337 121 630 337 123 630 minecraft:black_concrete
fill 337 121 634 337 123 634 minecraft:black_concrete
fill 338 121 629 338 123 629 minecraft:black_concrete
fill 338 121 635 338 123 635 minecraft:black_concrete
fill 339 121 628 342 123 628 minecraft:black_concrete
fill 339 121 636 342 123 636 minecraft:black_concrete
fill 343 121 629 343 123 629 minecraft:black_concrete
fill 343 121 635 343 123 635 minecraft:black_concrete
fill 344 121 630 344 123 630 minecraft:black_concrete
fill 344 121 634 344 123 634 minecraft:black_concrete
fill 349 121 646 349 139 646 minecraft:black_concrete
setblock 350 121 646 minecraft:white_concrete
fill 359 121 634 360 127 634 minecraft:black_concrete
fill 359 121 636 360 127 636 minecraft:black_concrete
fill 332 122 646 332 137 646 minecraft:black_concrete
fill 336 122 631 336 123 633 minecraft:black_concrete
fill 337 122 629 337 123 629 minecraft:black_concrete
fill 337 122 635 337 123 635 minecraft:black_concrete
fill 338 122 628 338 123 628 minecraft:black_concrete
fill 338 122 636 338 123 636 minecraft:black_concrete
fill 343 122 628 343 123 628 minecraft:black_concrete
fill 343 122 636 343 123 636 minecraft:black_concrete
fill 344 122 629 344 123 629 minecraft:black_concrete
fill 344 122 635 344 123 635 minecraft:black_concrete
fill 345 122 631 345 123 633 minecraft:black_concrete
fill 350 122 646 350 137 646 minecraft:black_concrete
fill 358 122 635 358 127 635 minecraft:black_concrete
fill 361 122 635 361 127 636 minecraft:black_concrete
setblock 365 122 604 minecraft:white_concrete
setblock 371 122 609 minecraft:white_concrete
setblock 336 123 630 minecraft:black_concrete
setblock 336 123 634 minecraft:black_concrete
setblock 337 123 628 minecraft:black_concrete
setblock 337 123 636 minecraft:black_concrete
setblock 338 123 646 minecraft:white_concrete
fill 339 123 627 342 123 627 minecraft:black_concrete
fill 339 123 637 342 123 637 minecraft:black_concrete
setblock 344 123 636 minecraft:black_concrete
setblock 345 123 630 minecraft:black_concrete
setblock 345 123 634 minecraft:black_concrete
fill 353 123 633 353 124 633 minecraft:gold_block
fill 358 123 634 358 127 634 minecraft:black_concrete
fill 358 123 636 358 127 636 minecraft:black_concrete
fill 359 123 633 360 127 633 minecraft:black_concrete
fill 359 123 637 360 127 637 minecraft:black_concrete
fill 361 123 634 361 127 634 minecraft:black_concrete
fill 365 123 604 365 126 604 minecraft:black_concrete
fill 371 123 609 371 139 609 minecraft:black_concrete
fill 338 124 646 338 140 646 minecraft:black_concrete
fill 340 124 631 341 124 633 minecraft:magenta_stained_glass
fill 357 124 635 357 127 635 minecraft:black_concrete
fill 358 124 633 358 127 633 minecraft:black_concrete
fill 358 124 637 358 127 637 minecraft:black_concrete
fill 361 124 633 361 127 633 minecraft:black_concrete
fill 361 124 637 361 127 637 minecraft:black_concrete
fill 362 124 634 362 127 636 minecraft:black_concrete
fill 340 125 632 341 127 632 minecraft:magenta_stained_glass
fill 357 125 634 357 127 634 minecraft:black_concrete
fill 357 125 636 357 127 636 minecraft:black_concrete
fill 359 125 638 360 127 638 minecraft:black_concrete
fill 360 125 632 360 127 632 minecraft:black_concrete
fill 362 125 637 362 127 637 minecraft:black_concrete
setblock 371 125 631 minecraft:magenta_stained_glass
setblock 329 126 615 minecraft:crying_obsidian
setblock 329 126 635 minecraft:white_concrete
setblock 332 126 607 minecraft:light[level=12]
setblock 332 126 615 minecraft:light[level=12]
setblock 332 126 623 minecraft:light[level=12]
setblock 332 126 631 minecraft:light[level=12]
setblock 332 126 639 minecraft:light[level=12]
setblock 335 126 604 minecraft:crying_obsidian
setblock 340 126 607 minecraft:light[level=12]
setblock 340 126 615 minecraft:light[level=12]
setblock 340 126 623 minecraft:light[level=12]
setblock 340 126 631 minecraft:light[level=12]
setblock 340 126 639 minecraft:light[level=12]
setblock 346 126 604 minecraft:magenta_stained_glass
setblock 348 126 607 minecraft:light[level=12]
setblock 348 126 615 minecraft:light[level=12]
setblock 348 126 623 minecraft:light[level=12]
setblock 348 126 631 minecraft:light[level=12]
setblock 348 126 639 minecraft:light[level=12]
setblock 356 126 607 minecraft:light[level=12]
setblock 356 126 615 minecraft:light[level=12]
setblock 356 126 623 minecraft:light[level=12]
setblock 356 126 631 minecraft:light[level=12]
setblock 356 126 639 minecraft:light[level=12]
fill 357 126 633 357 127 633 minecraft:black_concrete
fill 357 126 637 357 127 637 minecraft:black_concrete
fill 358 126 632 359 127 632 minecraft:black_concrete
fill 358 126 638 358 127 638 minecraft:black_concrete
fill 361 126 632 361 127 632 minecraft:black_concrete
fill 361 126 638 361 127 638 minecraft:black_concrete
fill 362 126 633 362 127 633 minecraft:black_concrete
fill 363 126 634 363 127 636 minecraft:black_concrete
setblock 364 126 607 minecraft:light[level=12]
setblock 364 126 615 minecraft:light[level=12]
setblock 364 126 623 minecraft:light[level=12]
setblock 364 126 631 minecraft:light[level=12]
setblock 364 126 639 minecraft:light[level=12]
fill 371 126 631 371 137 631 minecraft:black_concrete
setblock 329 127 605 minecraft:white_concrete
setblock 329 127 611 minecraft:magenta_stained_glass
fill 329 127 612 329 128 612 minecraft:magenta_concrete
fill 329 127 615 329 129 615 minecraft:black_concrete
setblock 329 127 618 minecraft:crying_obsidian
fill 329 127 628 329 128 628 minecraft:magenta_concrete
fill 329 127 635 329 139 635 minecraft:black_concrete
fill 329 127 644 329 128 644 minecraft:magenta_concrete
fill 333 127 604 333 128 604 minecraft:magenta_concrete
fill 335 127 604 335 140 604 minecraft:black_concrete
fill 343 127 646 343 128 646 minecraft:magenta_concrete
fill 346 127 604 346 139 604 minecraft:black_concrete
fill 349 127 604 349 128 604 minecraft:magenta_concrete
setblock 354 127 646 minecraft:crying_obsidian
fill 356 127 634 356 127 636 minecraft:black_concrete
setblock 357 127 632 minecraft:black_concrete
setblock 357 127 638 minecraft:black_concrete
fill 359 127 639 360 127 639 minecraft:black_concrete
fill 359 127 646 359 128 646 minecraft:magenta_concrete
setblock 362 127 632 minecraft:black_concrete
setblock 362 127 638 minecraft:black_concrete
setblock 363 127 633 minecraft:black_concrete
setblock 363 127 637 minecraft:black_concrete
fill 365 127 604 365 128 604 minecraft:magenta_concrete
fill 371 127 614 371 128 614 minecraft:magenta_concrete
fill 371 127 630 371 128 630 minecraft:magenta_concrete
fill 329 128 605 329 140 605 minecraft:black_concrete
fill 329 128 611 329 139 611 minecraft:black_concrete
fill 329 128 618 329 139 618 minecraft:black_concrete
fill 354 128 646 354 137 646 minecraft:black_concrete
fill 359 128 634 360 128 636 minecraft:magenta_stained_glass
setblock 371 128 639 minecraft:white_concrete
fill 329 129 612 329 135 612 minecraft:black_concrete
fill 329 129 628 329 135 628 minecraft:black_concrete
fill 329 129 644 329 135 644 minecraft:black_concrete
fill 333 129 604 333 135 604 minecraft:black_concrete
fill 343 129 646 343 135 646 minecraft:black_concrete
fill 349 129 604 349 135 604 minecraft:black_concrete
fill 359 129 635 360 130 635 minecraft:magenta_stained_glass
fill 359 129 646 359 135 646 minecraft:black_concrete
setblock 360 129 636 minecraft:magenta_stained_glass
setblock 364 129 646 minecraft:crying_obsidian
fill 365 129 604 365 135 604 minecraft:black_concrete
fill 371 129 614 371 135 614 minecraft:black_concrete
setblock 371 129 617 minecraft:crying_obsidian
fill 371 129 630 371 135 630 minecraft:black_concrete
fill 371 129 639 371 135 639 minecraft:black_concrete
setblock 329 130 615 minecraft:white_concrete
fill 364 130 646 364 139 646 minecraft:black_concrete
fill 371 130 617 371 139 617 minecraft:black_concrete
setblock 371 130 636 minecraft:white_concrete
fill 329 131 615 329 139 615 minecraft:black_concrete
setblock 360 131 635 minecraft:magenta_stained_glass
setblock 366 131 646 minecraft:crying_obsidian
setblock 371 131 615 minecraft:magenta_stained_glass
setblock 371 131 628 minecraft:crying_obsidian
fill 371 131 636 371 136 636 minecraft:black_concrete
setblock 329 132 620 minecraft:crying_obsidian
setblock 348 132 604 minecraft:magenta_stained_glass
fill 363 132 635 363 133 635 minecraft:magenta_concrete
fill 366 132 646 366 139 646 minecraft:black_concrete
setblock 371 132 612 minecraft:magenta_stained_glass
fill 371 132 615 371 139 615 minecraft:black_concrete
fill 371 132 628 371 138 628 minecraft:black_concrete
fill 329 133 620 329 139 620 minecraft:black_concrete
setblock 344 133 604 minecraft:magenta_stained_glass
fill 348 133 604 348 139 604 minecraft:black_concrete
fill 371 133 612 371 140 612 minecraft:black_concrete
fill 371 133 618 371 136 618 minecraft:black_concrete
setblock 371 133 619 minecraft:crying_obsidian
setblock 371 133 621 minecraft:white_concrete
setblock 331 134 604 minecraft:crying_obsidian
setblock 332 134 607 minecraft:light[level=12]
setblock 332 134 615 minecraft:light[level=12]
setblock 332 134 623 minecraft:light[level=12]
setblock 332 134 631 minecraft:light[level=12]
setblock 332 134 639 minecraft:light[level=12]
setblock 340 134 607 minecraft:light[level=12]
setblock 340 134 615 minecraft:light[level=12]
setblock 340 134 623 minecraft:light[level=12]
setblock 340 134 631 minecraft:light[level=12]
setblock 340 134 639 minecraft:light[level=12]
setblock 340 134 646 minecraft:magenta_stained_glass
fill 344 134 604 344 139 604 minecraft:black_concrete
fill 345 134 607 346 135 608 minecraft:magenta_concrete
setblock 348 134 607 minecraft:light[level=12]
setblock 348 134 615 minecraft:light[level=12]
setblock 348 134 623 minecraft:light[level=12]
setblock 348 134 631 minecraft:light[level=12]
setblock 348 134 639 minecraft:light[level=12]
setblock 356 134 607 minecraft:light[level=12]
setblock 356 134 615 minecraft:light[level=12]
setblock 356 134 623 minecraft:light[level=12]
setblock 356 134 631 minecraft:light[level=12]
setblock 356 134 639 minecraft:light[level=12]
setblock 364 134 607 minecraft:light[level=12]
setblock 364 134 615 minecraft:light[level=12]
setblock 364 134 623 minecraft:light[level=12]
setblock 364 134 631 minecraft:light[level=12]
setblock 364 134 639 minecraft:light[level=12]
setblock 370 134 604 minecraft:magenta_stained_glass
setblock 371 134 605 minecraft:crying_obsidian
fill 371 134 619 371 135 619 minecraft:black_concrete
fill 371 134 621 371 139 621 minecraft:black_concrete
fill 331 135 604 331 136 604 minecraft:black_concrete
fill 340 135 646 340 137 646 minecraft:black_concrete
setblock 346 135 646 minecraft:white_concrete
setblock 357 135 604 minecraft:magenta_stained_glass
fill 370 135 604 370 137 604 minecraft:black_concrete
fill 371 135 605 371 140 605 minecraft:black_concrete
setblock 371 135 634 minecraft:crying_obsidian
setblock 371 135 642 minecraft:crying_obsidian
setblock 329 136 610 minecraft:magenta_concrete
fill 329 136 612 329 138 612 minecraft:magenta_concrete
setblock 329 136 614 minecraft:magenta_concrete
setblock 329 136 622 minecraft:crying_obsidian
setblock 329 136 625 minecraft:magenta_concrete
fill 329 136 628 329 137 628 minecraft:magenta_concrete
fill 329 136 644 329 137 644 minecraft:magenta_concrete
setblock 330 136 604 minecraft:magenta_concrete
setblock 330 136 646 minecraft:magenta_concrete
fill 333 136 604 333 137 604 minecraft:magenta_concrete
setblock 341 136 646 minecraft:magenta_concrete
fill 343 136 646 343 137 646 minecraft:magenta_concrete
fill 346 136 646 346 139 646 minecraft:black_concrete
fill 349 136 604 349 137 604 minecraft:magenta_concrete
fill 357 136 604 357 137 604 minecraft:black_concrete
fill 359 136 646 359 137 646 minecraft:magenta_concrete
fill 365 136 604 365 137 604 minecraft:magenta_concrete
setblock 371 136 607 minecraft:magenta_concrete
fill 371 136 613 371 136 614 minecraft:magenta_concrete
setblock 371 136 619 minecraft:magenta_concrete
setblock 371 136 623 minecraft:magenta_concrete
fill 371 136 630 371 138 630 minecraft:magenta_concrete
fill 371 136 634 371 139 634 minecraft:black_concrete
setblock 371 136 639 minecraft:magenta_concrete
fill 371 136 642 371 139 642 minecraft:black_concrete
setblock 329 137 609 minecraft:magenta_concrete
fill 329 137 610 329 139 610 minecraft:black_concrete
fill 329 137 614 329 139 614 minecraft:black_concrete
fill 329 137 622 329 139 622 minecraft:black_concrete
fill 329 137 625 329 139 625 minecraft:black_concrete
setblock 329 137 627 minecraft:magenta_concrete
setblock 329 137 634 minecraft:magenta_concrete
setblock 329 137 637 minecraft:magenta_concrete
fill 330 137 604 330 139 604 minecraft:black_concrete
fill 330 137 646 330 139 646 minecraft:black_concrete
setblock 331 137 604 minecraft:magenta_concrete
setblock 335 137 646 minecraft:magenta_concrete
setblock 337 137 646 minecraft:magenta_concrete
setblock 341 137 604 minecraft:magenta_concrete
fill 341 137 646 341 139 646 minecraft:black_concrete
setblock 355 137 646 minecraft:magenta_concrete
setblock 357 137 646 minecraft:magenta_concrete
setblock 358 137 604 minecraft:magenta_concrete
setblock 362 137 646 minecraft:magenta_concrete
setblock 367 137 646 minecraft:magenta_concrete
setblock 371 137 607 minecraft:magenta_stained_glass
fill 371 137 613 371 139 613 minecraft:black_concrete
setblock 371 137 614 minecraft:magenta_concrete
setblock 371 137 618 minecraft:magenta_concrete
fill 371 137 619 371 139 619 minecraft:black_concrete
fill 371 137 623 371 139 623 minecraft:black_concrete
setblock 371 137 624 minecraft:white_concrete
setblock 371 137 626 minecraft:magenta_concrete
setblock 371 137 636 minecraft:magenta_concrete
fill 371 137 639 371 139 639 minecraft:black_concrete
fill 329 138 609 329 139 609 minecraft:black_concrete
fill 329 138 627 329 139 628 minecraft:black_concrete
setblock 329 138 631 minecraft:magenta_concrete
fill 329 138 634 329 139 634 minecraft:black_concrete
setblock 329 138 636 minecraft:magenta_concrete
fill 329 138 637 329 139 637 minecraft:black_concrete
setblock 329 138 638 minecraft:magenta_concrete
fill 329 138 642 329 139 642 minecraft:magenta_stained_glass
fill 329 138 644 329 140 644 minecraft:black_concrete
fill 331 138 604 331 139 604 minecraft:black_concrete
setblock 332 138 604 minecraft:magenta_concrete
setblock 332 138 646 minecraft:magenta_concrete
fill 333 138 604 333 139 604 minecraft:black_concrete
fill 335 138 646 335 139 646 minecraft:black_concrete
fill 337 138 646 337 139 646 minecraft:black_concrete
setblock 339 138 604 minecraft:magenta_concrete
setblock 340 138 646 minecraft:magenta_concrete
fill 341 138 604 341 139 604 minecraft:black_concrete
setblock 343 138 604 minecraft:magenta_stained_glass
fill 343 138 646 343 139 646 minecraft:black_concrete
setblock 345 138 646 minecraft:magenta_concrete
setblock 348 138 646 minecraft:magenta_concrete
fill 349 138 604 349 139 604 minecraft:black_concrete
setblock 350 138 646 minecraft:magenta_concrete
setblock 354 138 604 minecraft:white_concrete
setblock 354 138 646 minecraft:magenta_concrete
fill 355 138 646 355 139 646 minecraft:black_concrete
setblock 357 138 604 minecraft:magenta_concrete
fill 357 138 646 357 140 646 minecraft:black_concrete
fill 358 138 604 358 140 604 minecraft:black_concrete
fill 359 138 646 359 139 646 minecraft:black_concrete
fill 362 138 646 362 139 646 minecraft:black_concrete
setblock 363 138 604 minecraft:white_concrete
setblock 364 138 604 minecraft:magenta_concrete
fill 365 138 604 365 139 604 minecraft:black_concrete
fill 367 138 646 367 139 646 minecraft:black_concrete
setblock 370 138 604 minecraft:magenta_concrete
setblock 371 138 607 minecraft:black_concrete
fill 371 138 614 371 139 614 minecraft:black_concrete
fill 371 138 618 371 139 618 minecraft:black_concrete
fill 371 138 624 371 139 624 minecraft:black_concrete
fill 371 138 626 371 139 626 minecraft:black_concrete
setblock 371 138 631 minecraft:magenta_concrete
setblock 371 138 635 minecraft:white_concrete
fill 371 138 636 371 139 636 minecraft:black_concrete
fill 371 138 645 371 138 646 minecraft:magenta_concrete
setblock 329 139 612 minecraft:black_concrete
setblock 329 139 619 minecraft:crying_obsidian
setblock 329 139 631 minecraft:black_concrete
setblock 329 139 636 minecraft:black_concrete
fill 329 139 638 329 141 638 minecraft:black_concrete
setblock 332 139 604 minecraft:black_concrete
setblock 332 139 646 minecraft:black_concrete
fill 339 139 604 339 140 604 minecraft:black_concrete
setblock 340 139 646 minecraft:black_concrete
setblock 343 139 604 minecraft:black_concrete
setblock 345 139 604 minecraft:white_concrete
setblock 345 139 646 minecraft:black_concrete
setblock 348 139 646 minecraft:black_concrete
setblock 350 139 646 minecraft:black_concrete
setblock 354 139 604 minecraft:black_concrete
setblock 354 139 646 minecraft:black_concrete
setblock 357 139 604 minecraft:black_concrete
fill 363 139 604 364 139 604 minecraft:black_concrete
setblock 370 139 604 minecraft:black_concrete
setblock 371 139 607 minecraft:white_concrete
setblock 371 139 628 minecraft:magenta_stained_glass
fill 371 139 630 371 139 631 minecraft:black_concrete
setblock 371 139 635 minecraft:black_concrete
fill 371 139 645 371 139 646 minecraft:black_concrete
fill 329 140 604 334 141 604 minecraft:magenta_concrete
fill 329 140 606 329 140 637 minecraft:magenta_concrete
fill 329 140 640 329 141 640 minecraft:magenta_concrete
setblock 329 140 641 minecraft:black_concrete
fill 329 140 642 329 141 643 minecraft:magenta_concrete
fill 329 140 645 329 150 645 minecraft:magenta_concrete
fill 329 140 646 329 141 646 minecraft:black_concrete
fill 330 140 646 337 148 646 minecraft:magenta_concrete
fill 336 140 604 337 174 604 minecraft:magenta_concrete
fill 339 140 646 356 140 646 minecraft:magenta_concrete
fill 340 140 604 346 140 604 minecraft:magenta_concrete
fill 348 140 604 350 146 604 minecraft:magenta_concrete
fill 352 140 604 354 146 604 minecraft:magenta_concrete
fill 356 140 604 357 165 604 minecraft:magenta_concrete
fill 358 140 646 371 140 646 minecraft:magenta_concrete
fill 362 140 604 371 140 604 minecraft:magenta_concrete
fill 371 140 606 371 140 611 minecraft:magenta_concrete
fill 371 140 613 371 140 615 minecraft:magenta_concrete
setblock 371 140 616 minecraft:magenta_stained_glass
fill 371 140 617 371 141 621 minecraft:magenta_concrete
fill 371 140 623 371 173 628 minecraft:magenta_concrete
fill 371 140 630 371 140 639 minecraft:magenta_concrete
fill 371 140 641 371 141 645 minecraft:magenta_concrete
fill 329 141 605 329 141 617 minecraft:magenta_concrete
setblock 329 141 618 minecraft:black_concrete
fill 329 141 619 329 141 637 minecraft:magenta_concrete
fill 329 141 639 329 154 639 minecraft:magenta_concrete
fill 329 141 641 329 223 641 minecraft:magenta_concrete
setblock 329 141 644 minecraft:magenta_concrete
fill 335 141 604 335 161 604 minecraft:magenta_concrete
fill 338 141 604 343 141 604 minecraft:magenta_concrete
fill 338 141 646 339 182 646 minecraft:magenta_concrete
fill 340 141 646 342 141 646 minecraft:black_concrete
fill 343 141 646 346 178 646 minecraft:magenta_concrete
setblock 344 141 604 minecraft:white_concrete
fill 345 141 604 347 141 604 minecraft:magenta_concrete
setblock 347 141 646 minecraft:black_concrete
fill 348 141 646 351 144 646 minecraft:magenta_concrete
setblock 352 141 646 minecraft:white_concrete
fill 353 141 646 360 141 646 minecraft:magenta_concrete
fill 355 141 604 355 188 604 minecraft:magenta_concrete
fill 358 141 604 367 141 604 minecraft:magenta_concrete
fill 361 141 646 362 141 646 minecraft:black_concrete
fill 363 141 646 363 223 646 minecraft:magenta_concrete
setblock 364 141 646 minecraft:black_concrete
fill 365 141 646 371 141 646 minecraft:magenta_concrete
setblock 368 141 604 minecraft:black_concrete
fill 369 141 604 371 175 604 minecraft:magenta_concrete
fill 371 141 605 371 219 608 minecraft:magenta_concrete
fill 371 141 609 371 141 611 minecraft:black_concrete
fill 371 141 612 371 170 612 minecraft:magenta_concrete
setblock 371 141 613 minecraft:black_concrete
fill 371 141 614 371 153 616 minecraft:magenta_concrete
fill 371 141 622 371 158 622 minecraft:magenta_concrete
fill 371 141 629 371 141 634 minecraft:magenta_concrete
setblock 371 141 635 minecraft:black_concrete
fill 371 141 636 371 141 640 minecraft:magenta_concrete
fill 329 142 604 329 142 605 minecraft:black_concrete
fill 329 142 606 329 155 613 minecraft:magenta_concrete
setblock 329 142 614 minecraft:black_concrete
fill 329 142 615 329 142 622 minecraft:magenta_concrete
fill 329 142 623 329 142 624 minecraft:black_concrete
fill 329 142 625 329 143 626 minecraft:magenta_concrete
setblock 329 142 627 minecraft:black_concrete
fill 329 142 628 329 147 632 minecraft:magenta_concrete
setblock 329 142 633 minecraft:black_concrete
fill 329 142 634 329 156 638 minecraft:magenta_concrete
setblock 329 142 640 minecraft:black_concrete
fill 329 142 642 329 142 644 minecraft:black_concrete
fill 329 142 646 329 223 646 minecraft:magenta_concrete
fill 330 142 604 334 149 604 minecraft:magenta_concrete
setblock 332 142 607 minecraft:light[level=12]
setblock 332 142 615 minecraft:light[level=12]
setblock 332 142 623 minecraft:light[level=12]
setblock 332 142 631 minecraft:light[level=12]
setblock 332 142 639 minecraft:light[level=12]
setblock 338 142 604 minecraft:black_concrete
fill 339 142 604 344 153 604 minecraft:magenta_concrete
setblock 340 142 607 minecraft:light[level=12]
setblock 340 142 615 minecraft:light[level=12]
setblock 340 142 623 minecraft:light[level=12]
setblock 340 142 631 minecraft:light[level=12]
setblock 340 142 639 minecraft:light[level=12]
fill 340 142 646 342 163 646 minecraft:magenta_concrete
setblock 345 142 604 minecraft:black_concrete
fill 346 142 604 347 171 604 minecraft:magenta_concrete
fill 347 142 646 347 221 646 minecraft:magenta_concrete
setblock 348 142 607 minecraft:light[level=12]
setblock 348 142 615 minecraft:light[level=12]
setblock 348 142 623 minecraft:light[level=12]
setblock 348 142 631 minecraft:light[level=12]
setblock 348 142 639 minecraft:light[level=12]
fill 351 142 604 351 162 604 minecraft:magenta_concrete
fill 352 142 646 352 197 646 minecraft:magenta_concrete
setblock 353 142 646 minecraft:black_concrete
fill 354 142 646 357 148 646 minecraft:magenta_concrete
setblock 356 142 607 minecraft:light[level=12]
setblock 356 142 615 minecraft:light[level=12]
setblock 356 142 623 minecraft:light[level=12]
setblock 356 142 631 minecraft:light[level=12]
setblock 356 142 639 minecraft:light[level=12]
fill 358 142 604 358 145 604 minecraft:magenta_concrete
fill 358 142 646 359 142 646 minecraft:black_concrete
setblock 359 142 604 minecraft:black_concrete
fill 360 142 604 361 156 604 minecraft:magenta_concrete
fill 360 142 646 362 164 646 minecraft:magenta_concrete
setblock 362 142 604 minecraft:black_concrete
fill 363 142 604 368 143 604 minecraft:magenta_concrete
setblock 364 142 607 minecraft:light[level=12]
setblock 364 142 615 minecraft:light[level=12]
setblock 364 142 623 minecraft:light[level=12]
setblock 364 142 631 minecraft:light[level=12]
setblock 364 142 639 minecraft:light[level=12]
fill 364 142 646 365 156 646 minecraft:magenta_concrete
setblock 366 142 646 minecraft:magenta_stained_glass
fill 367 142 646 371 162 646 minecraft:magenta_concrete
fill 371 142 609 371 223 610 minecraft:magenta_concrete
setblock 371 142 611 minecraft:black_concrete
fill 371 142 613 371 223 613 minecraft:magenta_concrete
fill 371 142 617 371 211 619 minecraft:magenta_concrete
setblock 371 142 620 minecraft:black_concrete
fill 371 142 621 371 174 621 minecraft:magenta_concrete
fill 371 142 629 371 152 631 minecraft:magenta_concrete
fill 371 142 632 371 142 633 minecraft:black_concrete
fill 371 142 634 371 143 635 minecraft:magenta_concrete
setblock 371 142 636 minecraft:black_concrete
fill 371 142 637 371 152 643 minecraft:magenta_concrete
setblock 371 142 644 minecraft:black_concrete
fill 371 142 645 371 172 645 minecraft:magenta_concrete
fill 329 143 604 329 148 605 minecraft:magenta_concrete
fill 329 143 614 329 146 615 minecraft:magenta_concrete
setblock 329 143 616 minecraft:white_concrete
fill 329 143 617 329 160 617 minecraft:magenta_concrete
setblock 329 143 618 minecraft:magenta_stained_glass
fill 329 143 619 329 150 624 minecraft:magenta_concrete
fill 329 143 627 329 223 627 minecraft:magenta_concrete
fill 329 143 633 329 180 633 minecraft:magenta_concrete
fill 329 143 640 329 176 640 minecraft:magenta_concrete
fill 329 143 642 329 193 644 minecraft:magenta_concrete
fill 338 143 604 338 171 604 minecraft:magenta_concrete
fill 345 143 604 345 199 604 minecraft:magenta_concrete
fill 353 143 646 353 223 646 minecraft:magenta_concrete
fill 358 143 646 359 148 646 minecraft:magenta_concrete
fill 359 143 604 359 223 604 minecraft:magenta_concrete
fill 362 143 604 362 177 604 minecraft:magenta_concrete
setblock 366 143 646 minecraft:magenta_concrete
fill 371 143 611 371 202 611 minecraft:magenta_concrete
fill 371 143 620 371 183 620 minecraft:magenta_concrete
fill 371 143 632 371 149 633 minecraft:magenta_concrete
fill 371 143 636 371 224 636 minecraft:magenta_concrete
fill 371 143 644 371 193 644 minecraft:magenta_concrete
fill 329 144 616 329 146 616 minecraft:magenta_concrete
fill 329 144 618 329 178 618 minecraft:magenta_concrete
fill 329 144 625 329 196 625 minecraft:magenta_concrete
setblock 329 144 626 minecraft:white_concrete
fill 363 144 604 367 148 604 minecraft:magenta_concrete
setblock 366 144 646 minecraft:white_concrete
setblock 368 144 604 minecraft:crying_obsidian
setblock 371 144 634 minecraft:white_concrete
fill 371 144 635 371 148 635 minecraft:magenta_concrete
setblock 329 145 626 minecraft:magenta_concrete
fill 348 145 646 350 205 646 minecraft:magenta_concrete
setblock 351 145 646 minecraft:magenta_stained_glass
fill 366 145 646 366 223 646 minecraft:magenta_concrete
fill 368 145 604 368 223 604 minecraft:magenta_concrete
fill 371 145 634 371 208 634 minecraft:magenta_concrete
setblock 329 146 626 minecraft:white_concrete
fill 347 146 616 349 147 617 minecraft:obsidian
fill 351 146 646 351 223 646 minecraft:magenta_concrete
setblock 358 146 604 minecraft:crying_obsidian
setblock 329 147 614 minecraft:magenta_stained_glass
fill 329 147 615 329 223 615 minecraft:magenta_concrete
setblock 329 147 616 minecraft:white_concrete
fill 329 147 626 329 223 626 minecraft:magenta_concrete
fill 348 147 604 349 223 604 minecraft:magenta_concrete
setblock 350 147 604 minecraft:magenta_stained_glass
setblock 352 147 604 minecraft:crying_obsidian
fill 353 147 604 354 150 604 minecraft:magenta_concrete
fill 358 147 604 358 162 604 minecraft:magenta_concrete
fill 329 148 614 329 158 614 minecraft:magenta_concrete
fill 329 148 616 329 205 616 minecraft:magenta_concrete
fill 329 148 628 329 150 629 minecraft:magenta_concrete
setblock 329 148 630 minecraft:magenta_stained_glass
fill 329 148 631 329 198 632 minecraft:magenta_concrete
fill 350 148 604 350 223 604 minecraft:magenta_concrete
fill 352 148 604 352 216 604 minecraft:magenta_concrete
fill 329 149 604 329 220 604 minecraft:magenta_concrete
setblock 329 149 605 minecraft:crying_obsidian
fill 329 149 630 329 167 630 minecraft:magenta_concrete
fill 330 149 646 332 191 646 minecraft:magenta_concrete
setblock 333 149 646 minecraft:crying_obsidian
fill 334 149 646 337 160 646 minecraft:magenta_concrete
fill 354 149 646 355 184 646 minecraft:magenta_concrete
setblock 356 149 646 minecraft:magenta_stained_glass
fill 357 149 646 357 182 646 minecraft:magenta_concrete
setblock 358 149 646 minecraft:white_concrete
fill 359 149 646 359 220 646 minecraft:magenta_concrete
fill 363 149 604 364 164 604 minecraft:magenta_concrete
setblock 365 149 604 minecraft:crying_obsidian
fill 366 149 604 367 219 604 minecraft:magenta_concrete
setblock 371 149 635 minecraft:crying_obsidian
fill 329 150 605 329 192 605 minecraft:magenta_concrete
fill 330 150 604 333 193 604 minecraft:magenta_concrete
setblock 332 150 607 minecraft:light[level=12]
setblock 332 150 615 minecraft:light[level=12]
setblock 332 150 623 minecraft:light[level=12]
setblock 332 150 631 minecraft:light[level=12]
setblock 332 150 639 minecraft:light[level=12]
fill 333 150 646 333 219 646 minecraft:magenta_concrete
setblock 334 150 604 minecraft:crying_obsidian
setblock 340 150 607 minecraft:light[level=12]
setblock 340 150 615 minecraft:light[level=12]
setblock 340 150 623 minecraft:light[level=12]
setblock 340 150 631 minecraft:light[level=12]
setblock 340 150 639 minecraft:light[level=12]
setblock 348 150 607 minecraft:light[level=12]
setblock 348 150 615 minecraft:light[level=12]
setblock 348 150 623 minecraft:light[level=12]
setblock 348 150 631 minecraft:light[level=12]
setblock 348 150 639 minecraft:light[level=12]
setblock 356 150 607 minecraft:light[level=12]
setblock 356 150 615 minecraft:light[level=12]
setblock 356 150 623 minecraft:light[level=12]
setblock 356 150 631 minecraft:light[level=12]
setblock 356 150 639 minecraft:light[level=12]
fill 356 150 646 356 168 646 minecraft:magenta_concrete
fill 358 150 646 358 223 646 minecraft:magenta_concrete
setblock 364 150 607 minecraft:light[level=12]
setblock 364 150 615 minecraft:light[level=12]
setblock 364 150 623 minecraft:light[level=12]
setblock 364 150 631 minecraft:light[level=12]
setblock 364 150 639 minecraft:light[level=12]
fill 365 150 604 365 223 604 minecraft:magenta_concrete
setblock 371 150 632 minecraft:white_concrete
fill 371 150 633 371 204 633 minecraft:magenta_concrete
fill 371 150 635 371 155 635 minecraft:magenta_concrete
fill 329 151 619 329 166 620 minecraft:magenta_concrete
setblock 329 151 621 minecraft:crying_obsidian
fill 329 151 622 329 167 624 minecraft:magenta_concrete
fill 329 151 628 329 203 628 minecraft:magenta_concrete
setblock 329 151 629 minecraft:crying_obsidian
setblock 329 151 645 minecraft:magenta_stained_glass
fill 334 151 604 334 156 604 minecraft:magenta_concrete
fill 349 151 623 354 151 623 minecraft:shroomlight
fill 350 151 621 351 151 622 minecraft:shroomlight
fill 350 151 624 353 151 625 minecraft:shroomlight
setblock 352 151 622 minecraft:shroomlight
setblock 353 151 604 minecraft:crying_obsidian
fill 354 151 604 354 177 604 minecraft:magenta_concrete
fill 371 151 632 371 158 632 minecraft:magenta_concrete
fill 329 152 621 329 203 621 minecraft:magenta_concrete
fill 329 152 629 329 221 629 minecraft:magenta_concrete
fill 329 152 645 329 220 645 minecraft:magenta_concrete
fill 348 152 621 348 152 625 minecraft:shroomlight
fill 349 152 620 349 152 622 minecraft:shroomlight
fill 349 152 623 354 159 623 minecraft:orange_concrete
fill 349 152 624 349 152 626 minecraft:shroomlight
fill 350 152 619 351 152 620 minecraft:shroomlight
fill 350 152 621 351 161 622 minecraft:orange_concrete
fill 350 152 624 353 159 625 minecraft:orange_concrete
fill 350 152 626 353 152 627 minecraft:shroomlight
fill 352 152 619 353 152 619 minecraft:shroomlight
fill 353 152 604 353 178 604 minecraft:magenta_concrete
fill 354 152 624 354 152 626 minecraft:shroomlight
fill 355 152 621 355 152 625 minecraft:shroomlight
fill 347 153 621 347 153 625 minecraft:shroomlight
fill 348 153 619 348 153 620 minecraft:shroomlight
fill 348 153 621 348 159 625 minecraft:orange_concrete
fill 348 153 626 348 153 627 minecraft:shroomlight
setblock 349 153 619 minecraft:shroomlight
fill 349 153 620 349 161 622 minecraft:orange_concrete
fill 349 153 624 349 159 626 minecraft:orange_concrete
setblock 349 153 627 minecraft:shroomlight
fill 350 153 618 353 153 618 minecraft:shroomlight
fill 350 153 619 351 159 620 minecraft:orange_concrete
fill 350 153 626 353 161 627 minecraft:orange_concrete
fill 350 153 628 353 153 628 minecraft:shroomlight
fill 352 153 619 353 161 619 minecraft:orange_concrete
fill 354 153 619 355 153 619 minecraft:shroomlight
fill 354 153 624 354 161 626 minecraft:orange_concrete
fill 354 153 627 355 153 627 minecraft:shroomlight
setblock 355 153 620 minecraft:shroomlight
fill 355 153 621 355 159 625 minecraft:orange_concrete
setblock 355 153 626 minecraft:shroomlight
fill 356 153 621 356 153 625 minecraft:shroomlight
setblock 371 153 629 minecraft:magenta_stained_glass
fill 371 153 630 371 220 631 minecraft:magenta_concrete
fill 371 153 637 371 224 637 minecraft:magenta_concrete
setblock 371 153 638 minecraft:crying_obsidian
fill 371 153 639 371 159 643 minecraft:magenta_concrete
fill 339 154 604 342 173 604 minecraft:magenta_concrete
setblock 343 154 604 minecraft:crying_obsidian
fill 344 154 604 344 201 604 minecraft:magenta_concrete
fill 346 154 621 346 154 625 minecraft:shroomlight
fill 347 154 619 347 154 620 minecraft:shroomlight
fill 347 154 621 347 161 625 minecraft:orange_concrete
fill 347 154 626 347 154 627 minecraft:shroomlight
setblock 348 154 619 minecraft:shroomlight
fill 348 154 620 348 161 620 minecraft:orange_concrete
fill 348 154 626 348 161 626 minecraft:orange_concrete
setblock 348 154 627 minecraft:shroomlight
fill 349 154 618 350 154 618 minecraft:shroomlight
fill 349 154 619 349 159 619 minecraft:orange_concrete
fill 349 154 627 349 161 627 minecraft:orange_concrete
fill 349 154 628 350 154 628 minecraft:shroomlight
fill 351 154 617 352 161 617 minecraft:shroomlight
fill 351 154 618 352 161 618 minecraft:orange_concrete
fill 351 154 628 352 161 628 minecraft:orange_concrete
fill 351 154 629 352 161 629 minecraft:shroomlight
fill 353 154 618 354 154 618 minecraft:shroomlight
fill 353 154 628 354 154 628 minecraft:shroomlight
fill 354 154 619 354 161 619 minecraft:orange_concrete
fill 354 154 627 354 161 627 minecraft:orange_concrete
fill 355 154 619 356 154 619 minecraft:shroomlight
fill 355 154 620 355 161 620 minecraft:orange_concrete
fill 355 154 626 355 159 626 minecraft:orange_concrete
fill 355 154 627 356 154 627 minecraft:shroomlight
setblock 356 154 620 minecraft:shroomlight
fill 356 154 621 356 159 625 minecraft:orange_concrete
setblock 356 154 626 minecraft:shroomlight
fill 357 154 621 357 154 625 minecraft:shroomlight
fill 371 154 614 371 206 615 minecraft:magenta_concrete
setblock 371 154 616 minecraft:white_concrete
fill 371 154 629 371 191 629 minecraft:magenta_concrete
fill 371 154 638 371 223 638 minecraft:magenta_concrete
setblock 329 155 639 minecraft:white_concrete
fill 343 155 604 343 223 604 minecraft:magenta_concrete
fill 345 155 623 345 160 623 minecraft:shroomlight
fill 346 155 620 346 155 622 minecraft:shroomlight
fill 346 155 623 346 160 623 minecraft:orange_concrete
fill 346 155 624 346 155 626 minecraft:shroomlight
setblock 347 155 619 minecraft:shroomlight
fill 347 155 620 347 160 620 minecraft:orange_concrete
fill 347 155 626 347 160 626 minecraft:orange_concrete
setblock 347 155 627 minecraft:shroomlight
fill 348 155 618 348 156 618 minecraft:shroomlight
fill 348 155 619 348 159 619 minecraft:orange_concrete
fill 348 155 627 348 160 627 minecraft:orange_concrete
fill 348 155 628 348 156 628 minecraft:shroomlight
fill 349 155 617 350 159 617 minecraft:shroomlight
fill 349 155 618 350 159 618 minecraft:orange_concrete
fill 349 155 628 350 160 628 minecraft:orange_concrete
fill 349 155 629 350 160 629 minecraft:shroomlight
fill 353 155 617 354 160 617 minecraft:shroomlight
fill 353 155 618 354 160 618 minecraft:orange_concrete
fill 353 155 628 354 160 628 minecraft:orange_concrete
fill 353 155 629 354 160 629 minecraft:shroomlight
fill 355 155 618 355 156 618 minecraft:shroomlight
fill 355 155 619 355 160 619 minecraft:orange_concrete
fill 355 155 627 355 160 627 minecraft:orange_concrete
fill 355 155 628 355 156 628 minecraft:shroomlight
setblock 356 155 619 minecraft:shroomlight
fill 356 155 620 356 160 620 minecraft:orange_concrete
fill 356 155 626 356 159 626 minecraft:orange_concrete
setblock 356 155 627 minecraft:shroomlight
fill 357 155 620 357 155 622 minecraft:shroomlight
fill 357 155 623 357 160 623 minecraft:orange_concrete
fill 357 155 624 357 155 626 minecraft:shroomlight
fill 358 155 623 358 160 623 minecraft:shroomlight
fill 371 155 616 371 223 616 minecraft:magenta_concrete
fill 329 156 606 329 174 610 minecraft:magenta_concrete
setblock 329 156 611 minecraft:crying_obsidian
fill 329 156 612 329 192 613 minecraft:magenta_concrete
fill 329 156 639 329 217 639 minecraft:magenta_concrete
fill 345 156 621 345 159 622 minecraft:shroomlight
fill 345 156 624 345 159 625 minecraft:shroomlight
fill 346 156 619 346 159 620 minecraft:shroomlight
fill 346 156 621 346 159 622 minecraft:orange_concrete
fill 346 156 624 346 159 625 minecraft:orange_concrete
fill 346 156 626 346 159 627 minecraft:shroomlight
fill 347 156 618 347 159 618 minecraft:shroomlight
fill 347 156 619 347 159 619 minecraft:orange_concrete
fill 347 156 627 347 159 627 minecraft:orange_concrete
fill 347 156 628 347 159 628 minecraft:shroomlight
fill 356 156 618 356 159 618 minecraft:shroomlight
fill 356 156 619 356 159 619 minecraft:orange_concrete
fill 356 156 627 356 159 627 minecraft:orange_concrete
fill 356 156 628 356 159 628 minecraft:shroomlight
fill 357 156 619 357 159 620 minecraft:shroomlight
fill 357 156 621 357 159 622 minecraft:orange_concrete
fill 357 156 624 357 159 625 minecraft:orange_concrete
fill 357 156 626 357 159 627 minecraft:shroomlight
fill 358 156 621 358 159 622 minecraft:shroomlight
fill 358 156 624 358 159 625 minecraft:shroomlight
setblock 371 156 635 minecraft:crying_obsidian
fill 329 157 611 329 203 611 minecraft:magenta_concrete
setblock 329 157 634 minecraft:crying_obsidian
fill 329 157 635 329 177 638 minecraft:magenta_concrete
setblock 334 157 604 minecraft:crying_obsidian
fill 348 157 617 348 158 617 minecraft:shroomlight
fill 348 157 618 348 158 618 minecraft:orange_concrete
fill 348 157 628 348 158 628 minecraft:orange_concrete
fill 348 157 629 348 158 629 minecraft:shroomlight
fill 355 157 617 355 158 617 minecraft:shroomlight
fill 355 157 618 355 158 618 minecraft:orange_concrete
fill 355 157 628 355 158 628 minecraft:orange_concrete
fill 355 157 629 355 158 629 minecraft:shroomlight
setblock 360 157 604 minecraft:crying_obsidian
fill 361 157 604 361 172 604 minecraft:magenta_concrete
setblock 364 157 646 minecraft:magenta_stained_glass
setblock 365 157 646 minecraft:white_concrete
fill 371 157 635 371 199 635 minecraft:magenta_concrete
fill 329 158 634 329 223 634 minecraft:magenta_concrete
setblock 332 158 607 minecraft:light[level=12]
setblock 332 158 615 minecraft:light[level=12]
setblock 332 158 623 minecraft:light[level=12]
setblock 332 158 631 minecraft:light[level=12]
setblock 332 158 639 minecraft:light[level=12]
fill 334 158 604 334 160 604 minecraft:magenta_concrete
setblock 340 158 607 minecraft:light[level=12]
setblock 340 158 615 minecraft:light[level=12]
setblock 340 158 623 minecraft:light[level=12]
setblock 340 158 631 minecraft:light[level=12]
setblock 340 158 639 minecraft:light[level=12]
setblock 348 158 607 minecraft:light[level=12]
setblock 348 158 615 minecraft:light[level=12]
setblock 348 158 631 minecraft:light[level=12]
setblock 348 158 639 minecraft:light[level=12]
setblock 356 158 607 minecraft:light[level=12]
setblock 356 158 615 minecraft:light[level=12]
setblock 356 158 631 minecraft:light[level=12]
setblock 356 158 639 minecraft:light[level=12]
fill 360 158 604 360 163 604 minecraft:magenta_concrete
setblock 364 158 607 minecraft:light[level=12]
setblock 364 158 615 minecraft:light[level=12]
setblock 364 158 623 minecraft:light[level=12]
setblock 364 158 631 minecraft:light[level=12]
setblock 364 158 639 minecraft:light[level=12]
fill 364 158 646 365 165 646 minecraft:magenta_concrete
setblock 329 159 614 minecraft:magenta_stained_glass
setblock 348 159 618 minecraft:shroomlight
fill 348 159 628 348 160 628 minecraft:shroomlight
setblock 355 159 618 minecraft:shroomlight
fill 355 159 628 355 160 628 minecraft:shroomlight
setblock 371 159 622 minecraft:magenta_stained_glass
setblock 371 159 632 minecraft:magenta_stained_glass
fill 329 160 614 329 171 614 minecraft:magenta_concrete
fill 346 160 620 346 160 622 minecraft:shroomlight
fill 346 160 624 346 160 626 minecraft:shroomlight
fill 347 160 619 347 161 619 minecraft:shroomlight
fill 347 160 627 347 161 627 minecraft:shroomlight
fill 348 160 617 350 160 619 minecraft:redstone_block
fill 348 160 621 348 161 622 minecraft:orange_concrete
fill 348 160 623 350 160 625 minecraft:redstone_block
fill 349 160 626 349 161 626 minecraft:orange_concrete
fill 350 160 620 351 161 620 minecraft:orange_concrete
fill 351 160 619 351 161 619 minecraft:orange_concrete
fill 351 160 623 353 161 625 minecraft:orange_concrete
fill 354 160 623 356 161 623 minecraft:orange_concrete
fill 355 160 616 357 160 618 minecraft:redstone_block
fill 355 160 621 356 161 622 minecraft:orange_concrete
fill 355 160 624 357 160 626 minecraft:redstone_block
fill 356 160 619 356 161 619 minecraft:shroomlight
fill 356 160 627 356 161 627 minecraft:shroomlight
fill 357 160 620 357 160 622 minecraft:shroomlight
fill 371 160 622 371 178 622 minecraft:magenta_concrete
fill 371 160 632 371 168 632 minecraft:magenta_concrete
fill 371 160 639 371 175 639 minecraft:magenta_concrete
setblock 371 160 640 minecraft:magenta_stained_glass
fill 371 160 641 371 180 643 minecraft:magenta_concrete
setblock 329 161 617 minecraft:white_concrete
setblock 334 161 604 minecraft:white_concrete
fill 334 161 646 334 223 646 minecraft:magenta_concrete
setblock 335 161 646 minecraft:magenta_stained_glass
fill 336 161 646 337 164 646 minecraft:magenta_concrete
fill 346 161 621 346 161 625 minecraft:shroomlight
setblock 347 161 620 minecraft:shroomlight
setblock 347 161 626 minecraft:shroomlight
fill 348 161 627 348 162 627 minecraft:shroomlight
fill 349 161 628 350 161 628 minecraft:shroomlight
fill 353 161 618 354 161 618 minecraft:shroomlight
fill 353 161 628 354 161 628 minecraft:shroomlight
setblock 355 161 619 minecraft:shroomlight
setblock 355 161 627 minecraft:shroomlight
setblock 356 161 620 minecraft:shroomlight
fill 357 161 621 357 161 623 minecraft:shroomlight
fill 371 161 640 371 211 640 minecraft:magenta_concrete
fill 329 162 617 329 223 617 minecraft:magenta_concrete
fill 330 162 605 346 162 645 minecraft:black_concrete
fill 334 162 604 334 193 604 minecraft:magenta_concrete
setblock 335 162 604 minecraft:white_concrete
fill 335 162 646 335 213 646 minecraft:magenta_concrete
fill 347 162 605 353 162 615 minecraft:black_concrete
fill 347 162 616 347 162 620 minecraft:crying_obsidian
setblock 347 162 621 minecraft:shroomlight
fill 347 162 622 347 162 626 minecraft:crying_obsidian
fill 347 162 627 347 162 645 minecraft:black_concrete
fill 348 162 616 351 162 616 minecraft:crying_obsidian
fill 348 162 617 350 162 619 minecraft:black_concrete
fill 348 162 620 350 162 620 minecraft:crying_obsidian
fill 348 162 621 350 162 621 minecraft:orange_concrete
fill 348 162 622 350 162 622 minecraft:crying_obsidian
fill 348 162 623 350 162 625 minecraft:black_concrete
fill 348 162 626 351 162 626 minecraft:crying_obsidian
fill 348 162 628 349 162 645 minecraft:black_concrete
setblock 349 162 627 minecraft:shroomlight
fill 350 162 627 353 162 627 minecraft:orange_concrete
fill 350 162 628 353 162 628 minecraft:shroomlight
fill 350 162 629 370 162 645 minecraft:black_concrete
fill 351 162 617 351 162 619 minecraft:crying_obsidian
fill 351 162 620 351 162 622 minecraft:ochre_froglight
fill 351 162 623 351 162 625 minecraft:crying_obsidian
fill 352 162 616 353 162 617 minecraft:black_concrete
fill 352 162 618 353 162 618 minecraft:shroomlight
fill 352 162 619 354 162 619 minecraft:ochre_froglight
fill 352 162 623 354 162 623 minecraft:ochre_froglight
fill 352 162 624 353 162 626 minecraft:orange_concrete
fill 354 162 605 370 162 614 minecraft:black_concrete
fill 354 162 615 354 162 618 minecraft:crying_obsidian
fill 354 162 624 354 162 627 minecraft:crying_obsidian
fill 354 162 628 370 162 628 minecraft:black_concrete
fill 355 162 615 358 162 615 minecraft:crying_obsidian
fill 355 162 616 357 162 618 minecraft:black_concrete
fill 355 162 619 358 162 619 minecraft:crying_obsidian
fill 355 162 620 355 162 622 minecraft:ochre_froglight
fill 355 162 623 358 162 623 minecraft:crying_obsidian
fill 355 162 624 357 162 626 minecraft:black_concrete
fill 355 162 627 358 162 627 minecraft:crying_obsidian
fill 356 162 620 370 162 620 minecraft:black_concrete
fill 356 162 621 356 162 622 minecraft:shroomlight
fill 357 162 621 370 162 622 minecraft:black_concrete
fill 358 162 616 358 162 618 minecraft:crying_obsidian
fill 358 162 624 358 162 626 minecraft:crying_obsidian
fill 359 162 615 370 162 619 minecraft:black_concrete
fill 359 162 623 370 162 627 minecraft:black_concrete
fill 335 163 604 335 173 604 minecraft:magenta_concrete
fill 340 163 612 349 171 630 minecraft:smooth_stone
fill 350 163 612 350 171 630 minecraft:oak_planks
setblock 351 163 604 minecraft:magenta_stained_glass
fill 351 163 619 351 163 620 minecraft:shroomlight
fill 351 163 621 351 163 625 minecraft:orange_concrete
fill 351 163 626 353 163 627 minecraft:shroomlight
fill 352 163 619 353 163 619 minecraft:shroomlight
fill 352 163 623 353 163 625 minecraft:orange_concrete
setblock 354 163 623 minecraft:orange_concrete
fill 354 163 624 354 163 626 minecraft:shroomlight
fill 355 163 621 355 163 625 minecraft:shroomlight
fill 357 163 612 357 171 630 minecraft:oak_planks
setblock 358 163 604 minecraft:magenta_stained_glass
fill 358 163 612 366 171 630 minecraft:smooth_stone
setblock 367 163 646 minecraft:white_concrete
fill 368 163 646 371 167 646 minecraft:magenta_concrete
setblock 340 164 646 minecraft:magenta_stained_glass
fill 341 164 646 342 178 646 minecraft:magenta_concrete
fill 351 164 604 351 221 604 minecraft:magenta_concrete
fill 351 164 621 351 164 625 minecraft:shroomlight
fill 352 164 623 353 164 625 minecraft:shroomlight
setblock 354 164 623 minecraft:shroomlight
fill 358 164 604 358 179 604 minecraft:magenta_concrete
setblock 360 164 604 minecraft:white_concrete
fill 367 164 646 367 196 646 minecraft:magenta_concrete
setblock 336 165 646 minecraft:magenta_stained_glass
fill 337 165 646 337 220 646 minecraft:magenta_concrete
fill 340 165 646 340 223 646 minecraft:magenta_concrete
fill 360 165 604 360 221 604 minecraft:magenta_concrete
setblock 360 165 646 minecraft:crying_obsidian
fill 361 165 646 362 169 646 minecraft:magenta_concrete
setblock 363 165 604 minecraft:magenta_stained_glass
fill 364 165 604 364 216 604 minecraft:magenta_concrete
setblock 332 166 607 minecraft:light[level=12]
setblock 332 166 615 minecraft:light[level=12]
setblock 332 166 623 minecraft:light[level=12]
setblock 332 166 631 minecraft:light[level=12]
setblock 332 166 639 minecraft:light[level=12]
fill 336 166 646 336 182 646 minecraft:magenta_concrete
setblock 340 166 607 minecraft:light[level=12]
setblock 340 166 631 minecraft:light[level=12]
setblock 340 166 639 minecraft:light[level=12]
fill 344 166 610 351 168 611 minecraft:black_concrete
fill 345 166 609 350 168 609 minecraft:black_concrete
fill 347 166 608 349 168 608 minecraft:black_concrete
setblock 348 166 607 minecraft:light[level=12]
setblock 348 166 631 minecraft:light[level=12]
setblock 348 166 639 minecraft:light[level=12]
fill 351 166 612 351 168 615 minecraft:black_concrete
fill 352 166 612 352 168 613 minecraft:black_concrete
fill 356 166 604 356 187 604 minecraft:magenta_concrete
setblock 356 166 607 minecraft:light[level=12]
setblock 356 166 615 minecraft:light[level=12]
setblock 356 166 623 minecraft:light[level=12]
setblock 356 166 631 minecraft:light[level=12]
setblock 356 166 639 minecraft:light[level=12]
setblock 357 166 604 minecraft:white_concrete
fill 360 166 646 360 220 646 minecraft:magenta_concrete
fill 363 166 604 363 219 604 minecraft:magenta_concrete
setblock 364 166 607 minecraft:light[level=12]
setblock 364 166 631 minecraft:light[level=12]
setblock 364 166 639 minecraft:light[level=12]
fill 364 166 646 364 173 646 minecraft:magenta_concrete
setblock 365 166 646 minecraft:crying_obsidian
setblock 329 167 619 minecraft:magenta_stained_glass
fill 329 167 620 329 215 620 minecraft:magenta_concrete
fill 343 167 611 343 168 611 minecraft:black_concrete
fill 344 167 609 344 168 609 minecraft:black_concrete
fill 346 167 608 346 168 608 minecraft:black_concrete
fill 350 167 608 350 168 608 minecraft:black_concrete
fill 351 167 609 351 168 609 minecraft:black_concrete
fill 352 167 610 352 168 611 minecraft:black_concrete
fill 352 167 614 352 168 614 minecraft:black_concrete
fill 357 167 604 357 187 604 minecraft:magenta_concrete
fill 365 167 646 365 223 646 minecraft:magenta_concrete
fill 329 168 619 329 220 619 minecraft:magenta_concrete
fill 329 168 622 329 180 623 minecraft:magenta_concrete
setblock 329 168 624 minecraft:crying_obsidian
setblock 329 168 630 minecraft:white_concrete
setblock 343 168 610 minecraft:black_concrete
setblock 345 168 608 minecraft:black_concrete
fill 347 168 607 349 168 607 minecraft:black_concrete
setblock 351 168 608 minecraft:black_concrete
setblock 351 168 616 minecraft:black_concrete
setblock 352 168 609 minecraft:black_concrete
setblock 352 168 615 minecraft:black_concrete
fill 353 168 611 353 168 613 minecraft:black_concrete
fill 368 168 646 369 205 646 minecraft:magenta_concrete
setblock 370 168 646 minecraft:crying_obsidian
fill 371 168 646 371 223 646 minecraft:magenta_concrete
fill 329 169 624 329 184 624 minecraft:magenta_concrete
fill 329 169 630 329 181 630 minecraft:magenta_concrete
setblock 348 169 611 minecraft:magenta_stained_glass
setblock 356 169 646 minecraft:white_concrete
fill 370 169 646 370 209 646 minecraft:magenta_concrete
setblock 371 169 632 minecraft:white_concrete
fill 356 170 646 356 219 646 minecraft:magenta_concrete
fill 361 170 646 361 223 646 minecraft:magenta_concrete
setblock 362 170 646 minecraft:white_concrete
fill 371 170 632 371 198 632 minecraft:magenta_concrete
fill 345 171 631 346 172 632 minecraft:gold_block
fill 362 171 646 362 223 646 minecraft:magenta_concrete
setblock 371 171 612 minecraft:crying_obsidian
setblock 329 172 614 minecraft:crying_obsidian
setblock 338 172 604 minecraft:white_concrete
fill 344 172 617 345 172 618 minecraft:gold_block
fill 346 172 604 346 219 604 minecraft:magenta_concrete
setblock 347 172 604 minecraft:magenta_stained_glass
setblock 348 172 612 minecraft:magenta_stained_glass
fill 371 172 612 371 223 612 minecraft:magenta_concrete
fill 329 173 614 329 220 614 minecraft:magenta_concrete
fill 338 173 604 338 182 604 minecraft:magenta_concrete
fill 347 173 604 347 176 604 minecraft:magenta_concrete
setblock 361 173 604 minecraft:crying_obsidian
setblock 371 173 645 minecraft:crying_obsidian
setblock 332 174 607 minecraft:light[level=12]
setblock 332 174 615 minecraft:light[level=12]
setblock 332 174 623 minecraft:light[level=12]
setblock 332 174 631 minecraft:light[level=12]
setblock 332 174 639 minecraft:light[level=12]
setblock 335 174 604 minecraft:white_concrete
setblock 339 174 604 minecraft:crying_obsidian
fill 340 174 604 342 178 604 minecraft:magenta_concrete
setblock 340 174 607 minecraft:light[level=12]
setblock 340 174 615 minecraft:light[level=12]
fill 340 174 619 352 175 620 minecraft:iron_block
setblock 340 174 623 minecraft:light[level=12]
setblock 340 174 631 minecraft:light[level=12]
setblock 340 174 639 minecraft:light[level=12]
setblock 348 174 607 minecraft:light[level=12]
setblock 348 174 615 minecraft:light[level=12]
setblock 348 174 623 minecraft:light[level=12]
setblock 348 174 631 minecraft:light[level=12]
setblock 348 174 639 minecraft:light[level=12]
fill 353 174 619 366 175 619 minecraft:iron_block
fill 354 174 620 366 175 620 minecraft:iron_block
setblock 356 174 607 minecraft:light[level=12]
setblock 356 174 615 minecraft:light[level=12]
setblock 356 174 623 minecraft:light[level=12]
setblock 356 174 631 minecraft:light[level=12]
setblock 356 174 639 minecraft:light[level=12]
fill 361 174 604 361 205 604 minecraft:magenta_concrete
setblock 364 174 607 minecraft:light[level=12]
setblock 364 174 615 minecraft:light[level=12]
setblock 364 174 623 minecraft:light[level=12]
setblock 364 174 631 minecraft:light[level=12]
setblock 364 174 639 minecraft:light[level=12]
setblock 364 174 646 minecraft:crying_obsidian
fill 371 174 623 371 223 624 minecraft:magenta_concrete
setblock 371 174 625 minecraft:white_concrete
fill 371 174 626 371 197 628 minecraft:magenta_concrete
fill 371 174 645 371 177 645 minecraft:magenta_concrete
fill 329 175 606 329 217 608 minecraft:magenta_concrete
setblock 329 175 609 minecraft:white_concrete
fill 329 175 610 329 221 610 minecraft:magenta_concrete
fill 335 175 604 335 210 604 minecraft:magenta_concrete
setblock 336 175 604 minecraft:magenta_stained_glass
fill 337 175 604 337 199 604 minecraft:magenta_concrete
fill 339 175 604 339 185 604 minecraft:magenta_concrete
fill 364 175 646 364 196 646 minecraft:magenta_concrete
setblock 371 175 621 minecraft:magenta_stained_glass
fill 371 175 625 371 191 625 minecraft:magenta_concrete
setblock 329 176 609 minecraft:magenta_concrete
fill 336 176 604 336 219 604 minecraft:magenta_concrete
fill 369 176 604 369 223 604 minecraft:magenta_concrete
setblock 370 176 604 minecraft:magenta_stained_glass
fill 371 176 604 371 221 604 minecraft:magenta_concrete
fill 371 176 621 371 223 621 minecraft:magenta_concrete
setblock 371 176 639 minecraft:crying_obsidian
setblock 329 177 609 minecraft:magenta_stained_glass
setblock 329 177 640 minecraft:crying_obsidian
setblock 347 177 604 minecraft:crying_obsidian
fill 361 177 611 363 178 611 minecraft:obsidian
fill 362 177 612 362 178 612 minecraft:obsidian
fill 370 177 604 370 223 604 minecraft:magenta_concrete
fill 371 177 639 371 223 639 minecraft:magenta_concrete
fill 329 178 609 329 220 609 minecraft:magenta_concrete
fill 329 178 635 329 188 636 minecraft:magenta_concrete
setblock 329 178 637 minecraft:crying_obsidian
fill 329 178 638 329 223 638 minecraft:magenta_concrete
setblock 329 178 640 minecraft:magenta_stained_glass
fill 347 178 604 347 181 604 minecraft:magenta_concrete
setblock 354 178 604 minecraft:crying_obsidian
setblock 362 178 604 minecraft:magenta_stained_glass
setblock 371 178 645 minecraft:magenta_stained_glass
setblock 329 179 618 minecraft:crying_obsidian
fill 329 179 637 329 223 637 minecraft:magenta_concrete
fill 329 179 640 329 186 640 minecraft:magenta_concrete
fill 340 179 604 341 197 604 minecraft:magenta_concrete
fill 340 179 616 341 180 616 minecraft:crying_obsidian
fill 341 179 646 341 198 646 minecraft:magenta_concrete
setblock 342 179 604 minecraft:magenta_stained_glass
fill 342 179 646 343 179 646 minecraft:magenta_stained_glass
fill 344 179 646 346 206 646 minecraft:magenta_concrete
setblock 353 179 604 minecraft:white_concrete
fill 354 179 604 354 219 604 minecraft:magenta_concrete
fill 362 179 604 362 219 604 minecraft:magenta_concrete
setblock 371 179 622 minecraft:white_concrete
fill 371 179 645 371 219 645 minecraft:magenta_concrete
fill 329 180 618 329 219 618 minecraft:magenta_concrete
fill 339 180 616 339 180 617 minecraft:crying_obsidian
setblock 340 180 617 minecraft:crying_obsidian
fill 342 180 604 342 200 604 minecraft:magenta_concrete
fill 342 180 646 343 223 646 minecraft:magenta_concrete
fill 353 180 604 353 223 604 minecraft:magenta_concrete
setblock 358 180 604 minecraft:magenta_stained_glass
fill 371 180 622 371 223 622 minecraft:magenta_concrete
setblock 329 181 622 minecraft:magenta_stained_glass
fill 329 181 623 329 223 623 minecraft:magenta_concrete
setblock 329 181 633 minecraft:magenta_stained_glass
fill 337 181 617 339 181 617 minecraft:crying_obsidian
fill 358 181 604 358 191 604 minecraft:magenta_concrete
setblock 371 181 641 minecraft:crying_obsidian
fill 371 181 642 371 188 643 minecraft:magenta_concrete
fill 329 182 622 329 213 622 minecraft:magenta_concrete
setblock 329 182 630 minecraft:white_concrete
fill 329 182 633 329 223 633 minecraft:magenta_concrete
setblock 332 182 607 minecraft:light[level=12]
setblock 332 182 615 minecraft:light[level=12]
setblock 332 182 623 minecraft:light[level=12]
setblock 332 182 631 minecraft:light[level=12]
setblock 332 182 639 minecraft:light[level=12]
fill 335 182 618 336 182 618 minecraft:crying_obsidian
fill 336 182 617 337 182 617 minecraft:crying_obsidian
setblock 340 182 607 minecraft:light[level=12]
setblock 340 182 615 minecraft:light[level=12]
setblock 340 182 623 minecraft:light[level=12]
setblock 340 182 631 minecraft:light[level=12]
setblock 340 182 639 minecraft:light[level=12]
setblock 347 182 604 minecraft:white_concrete
setblock 348 182 607 minecraft:light[level=12]
setblock 348 182 615 minecraft:light[level=12]
setblock 348 182 623 minecraft:light[level=12]
setblock 348 182 631 minecraft:light[level=12]
setblock 348 182 639 minecraft:light[level=12]
setblock 356 182 607 minecraft:light[level=12]
setblock 356 182 615 minecraft:light[level=12]
setblock 356 182 623 minecraft:light[level=12]
setblock 356 182 631 minecraft:light[level=12]
setblock 356 182 639 minecraft:light[level=12]
setblock 364 182 607 minecraft:light[level=12]
setblock 364 182 615 minecraft:light[level=12]
setblock 364 182 623 minecraft:light[level=12]
setblock 364 182 631 minecraft:light[level=12]
setblock 364 182 639 minecraft:light[level=12]
fill 371 182 641 371 223 641 minecraft:magenta_concrete
fill 329 183 630 329 223 630 minecraft:magenta_concrete
fill 334 183 618 335 183 618 minecraft:crying_obsidian
setblock 336 183 646 minecraft:magenta_stained_glass
setblock 338 183 604 minecraft:crying_obsidian
setblock 338 183 646 minecraft:crying_obsidian
fill 339 183 646 339 223 646 minecraft:magenta_concrete
fill 347 183 604 347 217 604 minecraft:magenta_concrete
setblock 357 183 646 minecraft:crying_obsidian
fill 332 184 618 333 184 619 minecraft:crying_obsidian
fill 334 184 614 334 185 616 minecraft:obsidian
setblock 334 184 618 minecraft:crying_obsidian
fill 335 184 614 335 185 615 minecraft:obsidian
fill 336 184 646 336 221 646 minecraft:magenta_concrete
fill 338 184 604 338 223 604 minecraft:magenta_concrete
fill 338 184 646 338 208 646 minecraft:magenta_concrete
fill 357 184 646 357 203 646 minecraft:magenta_concrete
fill 362 184 630 362 185 631 minecraft:crying_obsidian
setblock 371 184 620 minecraft:crying_obsidian
setblock 329 185 624 minecraft:white_concrete
setblock 332 185 619 minecraft:crying_obsidian
fill 354 185 646 354 223 646 minecraft:magenta_concrete
setblock 355 185 646 minecraft:crying_obsidian
fill 363 185 629 363 186 630 minecraft:crying_obsidian
fill 371 185 620 371 223 620 minecraft:magenta_concrete
setblock 329 186 624 minecraft:magenta_concrete
setblock 339 186 604 minecraft:magenta_stained_glass
fill 355 186 646 355 223 646 minecraft:magenta_concrete
fill 364 186 629 365 186 629 minecraft:crying_obsidian
setblock 329 187 624 minecraft:white_concrete
setblock 329 187 640 minecraft:magenta_stained_glass
fill 339 187 604 339 202 604 minecraft:magenta_concrete
fill 365 187 628 365 187 629 minecraft:crying_obsidian
fill 366 187 628 366 188 628 minecraft:crying_obsidian
fill 329 188 624 329 223 624 minecraft:magenta_concrete
fill 329 188 640 329 198 640 minecraft:magenta_concrete
fill 356 188 604 357 188 604 minecraft:white_concrete
fill 366 188 627 368 188 627 minecraft:crying_obsidian
setblock 367 188 628 minecraft:crying_obsidian
setblock 329 189 635 minecraft:white_concrete
fill 329 189 636 329 192 636 minecraft:magenta_concrete
setblock 355 189 604 minecraft:white_concrete
fill 356 189 604 357 194 604 minecraft:magenta_concrete
fill 367 189 627 368 189 627 minecraft:crying_obsidian
fill 368 189 626 369 189 626 minecraft:crying_obsidian
setblock 371 189 642 minecraft:crying_obsidian
fill 371 189 643 371 219 643 minecraft:magenta_concrete
fill 329 190 635 329 195 635 minecraft:magenta_concrete
setblock 332 190 607 minecraft:light[level=12]
setblock 332 190 615 minecraft:light[level=12]
setblock 332 190 623 minecraft:light[level=12]
setblock 332 190 631 minecraft:light[level=12]
setblock 332 190 639 minecraft:light[level=12]
setblock 340 190 607 minecraft:light[level=12]
setblock 340 190 615 minecraft:light[level=12]
setblock 340 190 623 minecraft:light[level=12]
setblock 340 190 631 minecraft:light[level=12]
setblock 340 190 639 minecraft:light[level=12]
setblock 348 190 607 minecraft:light[level=12]
setblock 348 190 615 minecraft:light[level=12]
setblock 348 190 623 minecraft:light[level=12]
setblock 348 190 631 minecraft:light[level=12]
setblock 348 190 639 minecraft:light[level=12]
fill 355 190 604 355 197 604 minecraft:magenta_concrete
setblock 356 190 607 minecraft:light[level=12]
setblock 356 190 615 minecraft:light[level=12]
setblock 356 190 623 minecraft:light[level=12]
setblock 356 190 631 minecraft:light[level=12]
setblock 356 190 639 minecraft:light[level=12]
setblock 364 190 607 minecraft:light[level=12]
setblock 364 190 615 minecraft:light[level=12]
setblock 364 190 623 minecraft:light[level=12]
setblock 364 190 631 minecraft:light[level=12]
setblock 364 190 639 minecraft:light[level=12]
setblock 369 190 626 minecraft:crying_obsidian
fill 371 190 642 371 221 642 minecraft:magenta_concrete
fill 330 192 646 330 219 646 minecraft:magenta_concrete
setblock 331 192 646 minecraft:magenta_stained_glass
fill 332 192 646 332 202 646 minecraft:magenta_concrete
setblock 358 192 604 minecraft:white_concrete
setblock 371 192 625 minecraft:crying_obsidian
setblock 371 192 629 minecraft:crying_obsidian
setblock 329 193 605 minecraft:magenta_stained_glass
setblock 329 193 612 minecraft:magenta_stained_glass
fill 329 193 613 329 223 613 minecraft:magenta_concrete
setblock 329 193 636 minecraft:crying_obsidian
fill 331 193 646 331 199 646 minecraft:magenta_concrete
fill 358 193 604 358 219 604 minecraft:magenta_concrete
fill 371 193 625 371 195 625 minecraft:magenta_concrete
fill 371 193 629 371 223 629 minecraft:magenta_concrete
fill 329 194 605 329 224 605 minecraft:magenta_concrete
fill 329 194 612 329 219 612 minecraft:magenta_concrete
fill 329 194 636 329 223 636 minecraft:magenta_concrete
setblock 329 194 642 minecraft:crying_obsidian
fill 329 194 643 329 220 644 minecraft:magenta_concrete
fill 330 194 604 331 206 604 minecraft:magenta_concrete
setblock 332 194 604 minecraft:white_concrete
fill 333 194 604 333 223 604 minecraft:magenta_concrete
setblock 334 194 604 minecraft:crying_obsidian
fill 361 194 619 362 195 619 minecraft:crying_obsidian
setblock 371 194 644 minecraft:magenta_stained_glass
fill 329 195 642 329 197 642 minecraft:magenta_concrete
fill 332 195 604 332 223 604 minecraft:magenta_concrete
fill 334 195 604 334 223 604 minecraft:magenta_concrete
setblock 356 195 604 minecraft:white_concrete
fill 357 195 604 357 223 604 minecraft:magenta_concrete
fill 361 195 617 362 195 618 minecraft:crying_obsidian
fill 371 195 644 371 221 644 minecraft:magenta_concrete
setblock 329 196 635 minecraft:magenta_stained_glass
fill 356 196 604 356 205 604 minecraft:magenta_concrete
fill 361 196 616 362 196 617 minecraft:crying_obsidian
fill 361 196 620 362 197 621 minecraft:magenta_concrete
fill 362 196 615 362 197 615 minecraft:crying_obsidian
setblock 371 196 625 minecraft:white_concrete
setblock 329 197 625 minecraft:white_concrete
fill 329 197 635 329 201 635 minecraft:magenta_concrete
fill 361 197 614 361 197 615 minecraft:crying_obsidian
fill 362 197 613 362 198 614 minecraft:crying_obsidian
setblock 364 197 646 minecraft:white_concrete
setblock 367 197 646 minecraft:white_concrete
fill 371 197 625 371 220 625 minecraft:magenta_concrete
fill 329 198 625 329 203 625 minecraft:magenta_concrete
setblock 329 198 642 minecraft:crying_obsidian
setblock 332 198 607 minecraft:light[level=12]
setblock 332 198 615 minecraft:light[level=12]
setblock 332 198 623 minecraft:light[level=12]
setblock 332 198 631 minecraft:light[level=12]
setblock 332 198 639 minecraft:light[level=12]
fill 340 198 604 340 220 604 minecraft:magenta_concrete
setblock 340 198 607 minecraft:light[level=12]
setblock 340 198 615 minecraft:light[level=12]
setblock 340 198 623 minecraft:light[level=12]
setblock 340 198 631 minecraft:light[level=12]
setblock 340 198 639 minecraft:light[level=12]
setblock 341 198 604 minecraft:magenta_stained_glass
setblock 348 198 607 minecraft:light[level=12]
setblock 348 198 615 minecraft:light[level=12]
setblock 348 198 623 minecraft:light[level=12]
setblock 348 198 631 minecraft:light[level=12]
setblock 348 198 639 minecraft:light[level=12]
setblock 352 198 646 minecraft:crying_obsidian
setblock 355 198 604 minecraft:magenta_stained_glass
setblock 356 198 607 minecraft:light[level=12]
setblock 356 198 615 minecraft:light[level=12]
setblock 356 198 623 minecraft:light[level=12]
setblock 356 198 631 minecraft:light[level=12]
setblock 356 198 639 minecraft:light[level=12]
setblock 361 198 613 minecraft:crying_obsidian
fill 362 198 612 362 199 612 minecraft:crying_obsidian
setblock 364 198 607 minecraft:light[level=12]
setblock 364 198 615 minecraft:light[level=12]
setblock 364 198 623 minecraft:light[level=12]
setblock 364 198 631 minecraft:light[level=12]
setblock 364 198 639 minecraft:light[level=12]
fill 364 198 646 364 223 646 minecraft:magenta_concrete
fill 367 198 646 367 223 646 minecraft:magenta_concrete
setblock 371 198 626 minecraft:magenta_stained_glass
fill 371 198 627 371 219 628 minecraft:magenta_concrete
setblock 329 199 631 minecraft:white_concrete
fill 329 199 632 329 218 632 minecraft:magenta_concrete
setblock 329 199 640 minecraft:white_concrete
fill 329 199 642 329 223 642 minecraft:magenta_concrete
fill 341 199 604 341 224 604 minecraft:magenta_concrete
setblock 341 199 646 minecraft:white_concrete
fill 352 199 646 352 219 646 minecraft:magenta_concrete
fill 355 199 604 355 213 604 minecraft:magenta_concrete
fill 362 199 610 362 199 611 minecraft:crying_obsidian
fill 371 199 626 371 202 626 minecraft:magenta_concrete
setblock 371 199 632 minecraft:white_concrete
fill 329 200 631 329 221 631 minecraft:magenta_concrete
fill 329 200 640 329 224 640 minecraft:magenta_concrete
setblock 331 200 646 minecraft:magenta_stained_glass
setblock 337 200 604 minecraft:magenta_stained_glass
fill 341 200 646 341 219 646 minecraft:magenta_concrete
setblock 345 200 604 minecraft:magenta_stained_glass
setblock 362 200 610 minecraft:crying_obsidian
fill 371 200 632 371 223 632 minecraft:magenta_concrete
setblock 371 200 635 minecraft:magenta_stained_glass
fill 331 201 646 331 213 646 minecraft:magenta_concrete
fill 337 201 604 337 221 604 minecraft:magenta_concrete
setblock 342 201 604 minecraft:white_concrete
fill 345 201 604 345 219 604 minecraft:magenta_concrete
fill 371 201 635 371 223 635 minecraft:magenta_concrete
setblock 329 202 635 minecraft:crying_obsidian
fill 342 202 604 342 220 604 minecraft:magenta_concrete
setblock 344 202 604 minecraft:crying_obsidian
fill 329 203 635 329 223 635 minecraft:magenta_concrete
setblock 332 203 646 minecraft:crying_obsidian
setblock 339 203 604 minecraft:white_concrete
fill 344 203 604 344 220 604 minecraft:magenta_concrete
setblock 371 203 611 minecraft:crying_obsidian
setblock 371 203 626 minecraft:white_concrete
setblock 329 204 611 minecraft:magenta_stained_glass
setblock 329 204 621 minecraft:magenta_stained_glass
setblock 329 204 625 minecraft:magenta_stained_glass
setblock 329 204 628 minecraft:white_concrete
fill 332 204 646 332 224 646 minecraft:magenta_concrete
fill 339 204 604 339 223 604 minecraft:magenta_concrete
setblock 357 204 646 minecraft:white_concrete
fill 371 204 611 371 213 611 minecraft:magenta_concrete
fill 371 204 626 371 221 626 minecraft:magenta_concrete
fill 329 205 611 329 223 611 minecraft:magenta_concrete
fill 329 205 621 329 220 621 minecraft:magenta_concrete
fill 329 205 625 329 221 625 minecraft:magenta_concrete
fill 329 205 628 329 210 628 minecraft:magenta_concrete
fill 357 205 646 357 223 646 minecraft:magenta_concrete
fill 359 205 625 359 206 626 minecraft:obsidian
setblock 371 205 633 minecraft:magenta_stained_glass
setblock 329 206 616 minecraft:white_concrete
setblock 332 206 607 minecraft:light[level=12]
setblock 332 206 615 minecraft:light[level=12]
setblock 332 206 623 minecraft:light[level=12]
setblock 332 206 631 minecraft:light[level=12]
setblock 332 206 639 minecraft:light[level=12]
setblock 340 206 607 minecraft:light[level=12]
setblock 340 206 615 minecraft:light[level=12]
setblock 340 206 623 minecraft:light[level=12]
setblock 340 206 631 minecraft:light[level=12]
setblock 340 206 639 minecraft:light[level=12]
setblock 348 206 607 minecraft:light[level=12]
setblock 348 206 615 minecraft:light[level=12]
setblock 348 206 623 minecraft:light[level=12]
setblock 348 206 631 minecraft:light[level=12]
setblock 348 206 639 minecraft:light[level=12]
setblock 348 206 646 minecraft:magenta_stained_glass
fill 349 206 646 350 216 646 minecraft:magenta_concrete
setblock 356 206 604 minecraft:magenta_stained_glass
setblock 356 206 607 minecraft:light[level=12]
setblock 356 206 615 minecraft:light[level=12]
setblock 356 206 623 minecraft:light[level=12]
setblock 356 206 631 minecraft:light[level=12]
setblock 356 206 639 minecraft:light[level=12]
setblock 361 206 604 minecraft:magenta_stained_glass
setblock 364 206 607 minecraft:light[level=12]
setblock 364 206 615 minecraft:light[level=12]
setblock 364 206 623 minecraft:light[level=12]
setblock 364 206 631 minecraft:light[level=12]
setblock 364 206 639 minecraft:light[level=12]
setblock 368 206 646 minecraft:magenta_stained_glass
fill 369 206 646 369 223 646 minecraft:magenta_concrete
fill 371 206 633 371 211 633 minecraft:magenta_concrete
fill 329 207 616 329 223 616 minecraft:magenta_concrete
setblock 330 207 604 minecraft:crying_obsidian
fill 331 207 604 331 223 604 minecraft:magenta_concrete
fill 336 207 622 337 207 623 minecraft:crying_obsidian
setblock 337 207 621 minecraft:crying_obsidian
fill 344 207 646 344 220 646 minecraft:magenta_concrete
setblock 345 207 646 minecraft:magenta_stained_glass
fill 346 207 646 346 223 646 minecraft:magenta_concrete
fill 348 207 646 348 223 646 minecraft:magenta_concrete
fill 356 207 604 356 223 604 minecraft:magenta_concrete
fill 361 207 604 361 223 604 minecraft:magenta_concrete
fill 368 207 646 368 221 646 minecraft:magenta_concrete
fill 371 207 614 371 219 614 minecraft:magenta_concrete
setblock 371 207 615 minecraft:white_concrete
fill 330 208 604 330 220 604 minecraft:magenta_concrete
fill 335 208 623 336 208 624 minecraft:crying_obsidian
fill 337 208 622 337 208 623 minecraft:crying_obsidian
fill 345 208 646 345 223 646 minecraft:magenta_concrete
fill 371 208 615 371 224 615 minecraft:magenta_concrete
fill 334 209 624 336 209 625 minecraft:crying_obsidian
setblock 338 209 646 minecraft:white_concrete
setblock 371 209 634 minecraft:magenta_stained_glass
fill 332 210 626 335 210 626 minecraft:crying_obsidian
fill 333 210 625 335 210 625 minecraft:crying_obsidian
fill 338 210 646 338 223 646 minecraft:magenta_concrete
setblock 370 210 646 minecraft:magenta_stained_glass
fill 371 210 634 371 223 634 minecraft:magenta_concrete
setblock 329 211 628 minecraft:magenta_stained_glass
fill 331 211 627 334 211 627 minecraft:crying_obsidian
fill 332 211 626 334 211 626 minecraft:crying_obsidian
fill 332 211 628 333 212 628 minecraft:crying_obsidian
setblock 335 211 604 minecraft:white_concrete
fill 370 211 646 370 223 646 minecraft:magenta_concrete
fill 329 212 628 329 223 628 minecraft:magenta_concrete
setblock 331 212 627 minecraft:crying_obsidian
fill 331 212 629 332 213 629 minecraft:crying_obsidian
setblock 335 212 604 minecraft:magenta_concrete
fill 343 212 638 343 213 639 minecraft:gold_block
fill 344 212 638 344 213 638 minecraft:gold_block
setblock 371 212 617 minecraft:crying_obsidian
fill 371 212 618 371 219 619 minecraft:magenta_concrete
setblock 371 212 633 minecraft:magenta_stained_glass
setblock 371 212 640 minecraft:magenta_stained_glass
setblock 335 213 604 minecraft:white_concrete
fill 371 213 617 371 223 617 minecraft:magenta_concrete
fill 371 213 633 371 223 633 minecraft:magenta_concrete
fill 371 213 640 371 220 640 minecraft:magenta_concrete
setblock 329 214 622 minecraft:white_concrete
setblock 331 214 646 minecraft:magenta_stained_glass
setblock 332 214 607 minecraft:light[level=12]
setblock 332 214 615 minecraft:light[level=12]
setblock 332 214 623 minecraft:light[level=12]
setblock 332 214 631 minecraft:light[level=12]
setblock 332 214 639 minecraft:light[level=12]
fill 335 214 604 335 223 604 minecraft:magenta_concrete
setblock 335 214 646 minecraft:magenta_stained_glass
setblock 340 214 607 minecraft:light[level=12]
setblock 340 214 615 minecraft:light[level=12]
setblock 340 214 623 minecraft:light[level=12]
setblock 340 214 631 minecraft:light[level=12]
setblock 340 214 639 minecraft:light[level=12]
setblock 348 214 607 minecraft:light[level=12]
setblock 348 214 615 minecraft:light[level=12]
setblock 348 214 623 minecraft:light[level=12]
setblock 348 214 631 minecraft:light[level=12]
setblock 348 214 639 minecraft:light[level=12]
setblock 355 214 604 minecraft:white_concrete
setblock 356 214 607 minecraft:light[level=12]
setblock 356 214 615 minecraft:light[level=12]
setblock 356 214 623 minecraft:light[level=12]
setblock 356 214 631 minecraft:light[level=12]
setblock 356 214 639 minecraft:light[level=12]
setblock 364 214 607 minecraft:light[level=12]
setblock 364 214 615 minecraft:light[level=12]
setblock 364 214 623 minecraft:light[level=12]
setblock 364 214 631 minecraft:light[level=12]
setblock 364 214 639 minecraft:light[level=12]
setblock 371 214 611 minecraft:crying_obsidian
fill 329 215 622 329 219 622 minecraft:magenta_concrete
fill 331 215 646 331 223 646 minecraft:magenta_concrete
fill 335 215 646 335 224 646 minecraft:magenta_concrete
fill 355 215 604 355 224 604 minecraft:magenta_concrete
fill 371 215 611 371 219 611 minecraft:magenta_concrete
setblock 329 216 620 minecraft:magenta_stained_glass
fill 329 217 620 329 223 620 minecraft:magenta_concrete
fill 349 217 646 349 223 646 minecraft:magenta_concrete
setblock 350 217 646 minecraft:magenta_stained_glass
setblock 352 217 604 minecraft:white_concrete
setblock 364 217 604 minecraft:crying_obsidian
fill 329 218 606 329 224 607 minecraft:magenta_concrete
setblock 329 218 608 minecraft:magenta_stained_glass
setblock 329 218 639 minecraft:magenta_stained_glass
fill 337 218 638 338 219 639 minecraft:gold_block
setblock 347 218 604 minecraft:crying_obsidian
fill 350 218 646 350 223 646 minecraft:magenta_concrete
fill 352 218 604 352 223 604 minecraft:magenta_concrete
fill 364 218 604 364 220 604 minecraft:magenta_concrete
fill 329 219 608 329 223 608 minecraft:magenta_concrete
setblock 329 219 632 minecraft:magenta_stained_glass
fill 329 219 639 329 223 639 minecraft:magenta_concrete
fill 343 219 632 343 220 632 minecraft:magenta_concrete
setblock 347 219 604 minecraft:magenta_concrete
setblock 329 220 612 minecraft:purple_concrete
fill 329 220 618 329 221 618 minecraft:purple_concrete
setblock 329 220 622 minecraft:purple_concrete
fill 329 220 632 329 223 632 minecraft:magenta_concrete
setblock 330 220 646 minecraft:purple_concrete
setblock 333 220 646 minecraft:purple_concrete
setblock 336 220 604 minecraft:magenta_stained_glass
setblock 341 220 646 minecraft:purple_concrete
fill 345 220 604 347 220 604 minecraft:purple_concrete
setblock 352 220 646 minecraft:crying_obsidian
setblock 354 220 604 minecraft:purple_concrete
setblock 356 220 646 minecraft:purple_concrete
setblock 358 220 604 minecraft:purple_concrete
setblock 362 220 604 minecraft:purple_concrete
setblock 363 220 604 minecraft:crying_obsidian
setblock 366 220 604 minecraft:purple_concrete
setblock 367 220 604 minecraft:magenta_concrete
setblock 371 220 605 minecraft:magenta_stained_glass
fill 371 220 606 371 223 608 minecraft:magenta_concrete
setblock 371 220 611 minecraft:purple_concrete
fill 371 220 614 371 221 614 minecraft:purple_concrete
setblock 371 220 618 minecraft:purple_concrete
fill 371 220 619 371 223 619 minecraft:magenta_concrete
fill 371 220 627 371 223 627 minecraft:magenta_concrete
setblock 371 220 628 minecraft:purple_concrete
setblock 371 220 643 minecraft:purple_concrete
setblock 371 220 645 minecraft:purple_concrete
fill 329 221 604 330 221 604 minecraft:purple_concrete
setblock 329 221 609 minecraft:purple_concrete
fill 329 221 612 329 223 612 minecraft:magenta_concrete
setblock 329 221 614 minecraft:white_concrete
setblock 329 221 619 minecraft:purple_concrete
setblock 329 221 621 minecraft:purple_concrete
fill 329 221 622 329 223 622 minecraft:magenta_concrete
fill 329 221 643 329 223 643 minecraft:magenta_concrete
setblock 329 221 644 minecraft:magenta_stained_glass
setblock 329 221 645 minecraft:crying_obsidian
fill 330 221 646 330 223 646 minecraft:magenta_concrete
fill 333 221 646 333 223 646 minecraft:magenta_concrete
fill 336 221 604 336 223 604 minecraft:magenta_concrete
setblock 337 221 646 minecraft:crying_obsidian
setblock 340 221 604 minecraft:purple_concrete
fill 341 221 646 341 223 646 minecraft:magenta_concrete
setblock 342 221 604 minecraft:purple_concrete
setblock 344 221 604 minecraft:purple_concrete
setblock 344 221 646 minecraft:purple_concrete
fill 345 221 604 346 223 604 minecraft:magenta_concrete
setblock 347 221 604 minecraft:purple_concrete
setblock 352 221 646 minecraft:purple_concrete
fill 354 221 604 354 223 604 minecraft:magenta_concrete
fill 356 221 646 356 223 646 minecraft:magenta_concrete
setblock 358 221 604 minecraft:magenta_concrete
fill 359 221 646 360 221 646 minecraft:purple_concrete
fill 362 221 604 363 223 604 minecraft:magenta_concrete
setblock 364 221 604 minecraft:purple_concrete
fill 366 221 604 366 223 604 minecraft:magenta_concrete
setblock 367 221 604 minecraft:purple_concrete
fill 371 221 605 371 223 605 minecraft:magenta_concrete
fill 371 221 611 371 223 611 minecraft:magenta_concrete
fill 371 221 618 371 223 618 minecraft:magenta_concrete
setblock 371 221 625 minecraft:purple_concrete
setblock 371 221 628 minecraft:magenta_concrete
setblock 371 221 630 minecraft:purple_concrete
fill 371 221 631 371 223 631 minecraft:magenta_concrete
setblock 371 221 640 minecraft:crying_obsidian
fill 371 221 643 371 224 643 minecraft:magenta_concrete
fill 371 221 645 371 223 645 minecraft:magenta_concrete
fill 329 222 604 330 223 604 minecraft:magenta_concrete
fill 329 222 609 329 223 609 minecraft:magenta_concrete
setblock 329 222 610 minecraft:purple_concrete
fill 329 222 614 329 223 614 minecraft:magenta_concrete
fill 329 222 618 329 223 619 minecraft:magenta_concrete
fill 329 222 621 329 223 621 minecraft:magenta_concrete
setblock 329 222 625 minecraft:purple_concrete
setblock 329 222 629 minecraft:purple_concrete
setblock 329 222 631 minecraft:magenta_stained_glass
fill 329 222 644 329 223 645 minecraft:magenta_concrete
setblock 332 222 607 minecraft:light[level=12]
setblock 332 222 615 minecraft:light[level=12]
setblock 332 222 623 minecraft:light[level=12]
setblock 332 222 631 minecraft:light[level=12]
setblock 332 222 639 minecraft:light[level=12]
fill 336 222 646 337 222 646 minecraft:purple_concrete
setblock 337 222 604 minecraft:purple_concrete
fill 340 222 604 340 223 604 minecraft:magenta_concrete
setblock 340 222 607 minecraft:light[level=12]
setblock 340 222 615 minecraft:light[level=12]
setblock 340 222 623 minecraft:light[level=12]
setblock 340 222 631 minecraft:light[level=12]
setblock 340 222 639 minecraft:light[level=12]
fill 342 222 604 342 223 604 minecraft:magenta_concrete
fill 344 222 604 344 223 604 minecraft:magenta_concrete
fill 344 222 646 344 223 646 minecraft:magenta_concrete
fill 347 222 604 347 223 604 minecraft:magenta_concrete
setblock 347 222 646 minecraft:purple_concrete
setblock 348 222 607 minecraft:light[level=12]
setblock 348 222 615 minecraft:light[level=12]
setblock 348 222 623 minecraft:light[level=12]
setblock 348 222 631 minecraft:light[level=12]
setblock 348 222 639 minecraft:light[level=12]
setblock 351 222 604 minecraft:purple_concrete
fill 352 222 646 352 223 646 minecraft:magenta_concrete
setblock 356 222 607 minecraft:light[level=12]
setblock 356 222 615 minecraft:light[level=12]
setblock 356 222 623 minecraft:light[level=12]
setblock 356 222 631 minecraft:light[level=12]
setblock 356 222 639 minecraft:light[level=12]
setblock 358 222 604 minecraft:purple_concrete
fill 359 222 646 360 223 646 minecraft:magenta_concrete
setblock 360 222 604 minecraft:purple_concrete
fill 364 222 604 364 223 604 minecraft:magenta_concrete
setblock 364 222 607 minecraft:light[level=12]
setblock 364 222 615 minecraft:light[level=12]
setblock 364 222 623 minecraft:light[level=12]
setblock 364 222 631 minecraft:light[level=12]
setblock 364 222 639 minecraft:light[level=12]
fill 367 222 604 367 223 604 minecraft:magenta_concrete
setblock 368 222 646 minecraft:purple_concrete
setblock 371 222 604 minecraft:purple_concrete
fill 371 222 614 371 223 614 minecraft:magenta_concrete
fill 371 222 625 371 223 625 minecraft:magenta_concrete
setblock 371 222 626 minecraft:purple_concrete
setblock 371 222 628 minecraft:white_concrete
fill 371 222 630 371 223 630 minecraft:magenta_concrete
fill 371 222 640 371 223 640 minecraft:magenta_concrete
setblock 371 222 642 minecraft:purple_concrete
setblock 371 222 644 minecraft:purple_concrete
setblock 329 223 610 minecraft:magenta_concrete
setblock 329 223 625 minecraft:magenta_concrete
setblock 329 223 629 minecraft:magenta_concrete
setblock 329 223 631 minecraft:magenta_concrete
fill 336 223 646 337 223 646 minecraft:magenta_concrete
setblock 337 223 604 minecraft:magenta_concrete
setblock 347 223 646 minecraft:magenta_concrete
setblock 351 223 604 minecraft:magenta_concrete
setblock 358 223 604 minecraft:magenta_concrete
setblock 360 223 604 minecraft:magenta_concrete
setblock 368 223 646 minecraft:magenta_concrete
setblock 371 223 604 minecraft:magenta_concrete
setblock 371 223 626 minecraft:magenta_concrete
setblock 371 223 628 minecraft:magenta_concrete
fill 371 223 642 371 224 642 minecraft:magenta_concrete
setblock 371 223 644 minecraft:magenta_concrete
fill 329 224 604 340 225 604 minecraft:purple_concrete
fill 329 224 608 329 224 639 minecraft:purple_concrete
fill 329 224 641 329 224 646 minecraft:purple_concrete
fill 330 224 646 331 238 646 minecraft:purple_concrete
fill 333 224 646 334 242 646 minecraft:purple_concrete
fill 336 224 646 371 224 646 minecraft:purple_concrete
fill 342 224 604 354 224 604 minecraft:purple_concrete
fill 356 224 604 362 224 604 minecraft:purple_concrete
setblock 363 224 604 minecraft:magenta_concrete
fill 364 224 604 371 224 604 minecraft:purple_concrete
fill 371 224 605 371 224 614 minecraft:purple_concrete
fill 371 224 616 371 224 617 minecraft:purple_concrete
setblock 371 224 618 minecraft:magenta_stained_glass
fill 371 224 619 371 241 629 minecraft:purple_concrete
setblock 371 224 630 minecraft:white_concrete
fill 371 224 631 371 227 635 minecraft:purple_concrete
fill 371 224 638 371 225 641 minecraft:purple_concrete
fill 371 224 644 371 224 645 minecraft:purple_concrete
fill 329 225 605 329 227 625 minecraft:purple_concrete
setblock 329 225 626 minecraft:magenta_concrete
fill 329 225 627 329 225 640 minecraft:purple_concrete
fill 329 225 641 329 225 643 minecraft:magenta_concrete
fill 329 225 644 329 233 645 minecraft:purple_concrete
setblock 329 225 646 minecraft:magenta_concrete
fill 332 225 646 332 263 646 minecraft:purple_concrete
fill 335 225 646 336 225 646 minecraft:purple_concrete
setblock 337 225 646 minecraft:magenta_concrete
fill 338 225 646 345 225 646 minecraft:purple_concrete
fill 341 225 604 347 225 604 minecraft:purple_concrete
setblock 346 225 646 minecraft:magenta_concrete
fill 347 225 646 349 225 646 minecraft:purple_concrete
setblock 348 225 604 minecraft:magenta_concrete
fill 349 225 604 356 228 604 minecraft:purple_concrete
setblock 350 225 646 minecraft:magenta_concrete
fill 351 225 646 351 226 646 minecraft:purple_concrete
setblock 352 225 646 minecraft:magenta_concrete
fill 353 225 646 371 225 646 minecraft:purple_concrete
setblock 357 225 604 minecraft:magenta_concrete
setblock 358 225 604 minecraft:purple_concrete
setblock 359 225 604 minecraft:magenta_concrete
fill 360 225 604 366 225 604 minecraft:purple_concrete
setblock 367 225 604 minecraft:magenta_concrete
fill 368 225 604 371 225 604 minecraft:purple_concrete
fill 371 225 605 371 225 608 minecraft:purple_concrete
setblock 371 225 609 minecraft:magenta_concrete
fill 371 225 610 371 227 612 minecraft:purple_concrete
setblock 371 225 613 minecraft:magenta_concrete
fill 371 225 614 371 225 615 minecraft:purple_concrete
fill 371 225 616 371 226 616 minecraft:magenta_concrete
fill 371 225 617 371 230 618 minecraft:purple_concrete
setblock 371 225 630 minecraft:purple_concrete
fill 371 225 636 371 225 637 minecraft:purple_concrete
fill 371 225 642 371 284 643 minecraft:purple_concrete
setblock 371 225 644 minecraft:magenta_concrete
fill 371 225 645 371 291 645 minecraft:purple_concrete
fill 329 226 604 339 228 604 minecraft:purple_concrete
fill 329 226 626 329 233 629 minecraft:purple_concrete
setblock 329 226 630 minecraft:magenta_concrete
fill 329 226 631 329 227 643 minecraft:purple_concrete
fill 329 226 646 329 307 646 minecraft:purple_concrete
fill 335 226 646 335 243 646 minecraft:purple_concrete
setblock 336 226 646 minecraft:magenta_concrete
fill 337 226 646 337 236 646 minecraft:purple_concrete
setblock 338 226 646 minecraft:magenta_concrete
fill 339 226 646 343 233 646 minecraft:purple_concrete
setblock 340 226 604 minecraft:white_concrete
fill 341 226 604 341 234 604 minecraft:purple_concrete
fill 342 226 604 343 226 604 minecraft:magenta_concrete
fill 344 226 604 348 246 604 minecraft:purple_concrete
setblock 344 226 646 minecraft:magenta_concrete
fill 345 226 646 347 251 646 minecraft:purple_concrete
setblock 348 226 646 minecraft:magenta_concrete
fill 349 226 646 350 256 646 minecraft:purple_concrete
fill 352 226 646 363 226 646 minecraft:purple_concrete
fill 357 226 604 357 307 604 minecraft:purple_concrete
setblock 358 226 604 minecraft:magenta_concrete
fill 359 226 604 361 240 604 minecraft:purple_concrete
setblock 362 226 604 minecraft:magenta_concrete
fill 363 226 604 364 238 604 minecraft:purple_concrete
setblock 364 226 646 minecraft:magenta_concrete
setblock 365 226 604 minecraft:magenta_concrete
fill 365 226 646 368 228 646 minecraft:purple_concrete
fill 366 226 604 369 268 604 minecraft:purple_concrete
setblock 369 226 646 minecraft:magenta_concrete
setblock 370 226 604 minecraft:magenta_concrete
fill 370 226 646 371 295 646 minecraft:purple_concrete
fill 371 226 604 371 284 605 minecraft:purple_concrete
setblock 371 226 606 minecraft:magenta_concrete
fill 371 226 607 371 295 607 minecraft:purple_concrete
setblock 371 226 608 minecraft:magenta_concrete
fill 371 226 609 371 237 609 minecraft:purple_concrete
fill 371 226 613 371 233 614 minecraft:purple_concrete
setblock 371 226 615 minecraft:magenta_concrete
setblock 371 226 630 minecraft:magenta_concrete
setblock 371 226 636 minecraft:magenta_concrete
fill 371 226 637 371 258 638 minecraft:purple_concrete
setblock 371 226 639 minecraft:magenta_concrete
fill 371 226 640 371 244 641 minecraft:purple_concrete
fill 371 226 644 371 237 644 minecraft:purple_concrete
fill 329 227 630 329 233 630 minecraft:purple_concrete
fill 336 227 646 336 248 646 minecraft:purple_concrete
fill 338 227 646 338 242 646 minecraft:purple_concrete
fill 340 227 604 340 249 604 minecraft:purple_concrete
fill 342 227 604 343 288 604 minecraft:purple_concrete
fill 344 227 646 344 240 646 minecraft:purple_concrete
fill 345 227 620 347 227 622 minecraft:redstone_block
fill 348 227 646 348 282 646 minecraft:purple_concrete
fill 349 227 615 351 227 617 minecraft:redstone_block
fill 350 227 625 352 227 627 minecraft:redstone_block
setblock 351 227 646 minecraft:magenta_stained_glass
fill 352 227 646 359 228 646 minecraft:purple_concrete
fill 354 227 617 356 227 619 minecraft:redstone_block
fill 358 227 604 358 277 604 minecraft:purple_concrete
setblock 360 227 646 minecraft:crying_obsidian
fill 361 227 646 364 240 646 minecraft:purple_concrete
fill 362 227 604 362 234 604 minecraft:purple_concrete
fill 365 227 604 365 233 604 minecraft:purple_concrete
fill 369 227 646 369 262 646 minecraft:purple_concrete
fill 370 227 604 370 267 604 minecraft:purple_concrete
setblock 371 227 606 minecraft:purple_concrete
fill 371 227 608 371 270 608 minecraft:purple_concrete
fill 371 227 615 371 245 616 minecraft:purple_concrete
fill 371 227 630 371 233 630 minecraft:purple_concrete
fill 371 227 636 371 307 636 minecraft:purple_concrete
fill 371 227 639 371 293 639 minecraft:purple_concrete
fill 329 228 605 329 233 617 minecraft:purple_concrete
setblock 329 228 618 minecraft:crying_obsidian
fill 329 228 619 329 228 625 minecraft:purple_concrete
fill 329 228 631 329 238 633 minecraft:purple_concrete
setblock 329 228 634 minecraft:crying_obsidian
fill 329 228 635 329 229 643 minecraft:purple_concrete
fill 335 228 621 340 228 621 minecraft:black_concrete
fill 336 228 616 336 229 617 minecraft:magenta_concrete
fill 336 228 618 341 228 620 minecraft:black_concrete
fill 336 228 622 337 229 626 minecraft:black_concrete
fill 337 228 614 337 229 616 minecraft:magenta_concrete
fill 337 228 617 348 228 617 minecraft:black_concrete
fill 337 228 627 337 229 628 minecraft:black_concrete
fill 338 228 612 338 229 615 minecraft:magenta_concrete
fill 338 228 616 348 228 616 minecraft:black_concrete
fill 338 228 622 338 229 625 minecraft:black_concrete
fill 338 228 626 341 228 630 minecraft:magenta_concrete
fill 339 228 611 340 229 614 minecraft:magenta_concrete
fill 339 228 615 348 228 615 minecraft:black_concrete
setblock 339 228 622 minecraft:black_concrete
fill 339 228 623 341 228 625 minecraft:magenta_concrete
fill 339 228 631 341 229 631 minecraft:magenta_concrete
fill 340 228 610 342 229 610 minecraft:black_concrete
fill 340 228 622 343 228 622 minecraft:magenta_concrete
fill 340 228 632 341 229 632 minecraft:magenta_concrete
fill 341 228 609 354 228 609 minecraft:black_concrete
fill 341 228 611 348 228 613 minecraft:magenta_concrete
fill 341 228 614 347 228 614 minecraft:black_concrete
fill 341 228 621 344 228 621 minecraft:magenta_concrete
fill 341 228 633 342 229 633 minecraft:magenta_concrete
fill 342 228 608 353 229 608 minecraft:black_concrete
fill 342 228 618 342 228 619 minecraft:black_concrete
fill 342 228 620 344 228 620 minecraft:magenta_concrete
fill 342 228 623 342 228 624 minecraft:magenta_concrete
fill 342 228 625 346 228 632 minecraft:black_concrete
fill 342 228 634 342 229 634 minecraft:magenta_concrete
fill 343 228 610 344 229 610 minecraft:magenta_concrete
fill 343 228 618 345 228 618 minecraft:black_concrete
fill 343 228 619 348 228 619 minecraft:magenta_concrete
fill 343 228 623 346 228 624 minecraft:black_concrete
fill 343 228 633 349 228 634 minecraft:black_concrete
fill 344 228 607 352 229 607 minecraft:black_concrete
setblock 344 228 622 minecraft:black_concrete
fill 344 228 635 351 229 635 minecraft:black_concrete
fill 345 228 610 355 228 610 minecraft:black_concrete
fill 346 228 606 350 229 606 minecraft:black_concrete
setblock 346 228 618 minecraft:magenta_concrete
fill 346 228 636 353 229 636 minecraft:black_concrete
fill 347 228 618 349 228 618 minecraft:black_concrete
setblock 347 228 623 minecraft:black_concrete
fill 347 228 624 348 228 629 minecraft:magenta_concrete
fill 347 228 630 347 228 632 minecraft:black_concrete
fill 348 228 614 351 228 614 minecraft:magenta_concrete
fill 348 228 620 349 228 622 minecraft:gold_block
setblock 348 228 623 minecraft:magenta_concrete
fill 348 228 630 350 228 631 minecraft:magenta_concrete
setblock 348 228 632 minecraft:black_concrete
fill 349 228 611 355 228 611 minecraft:black_concrete
fill 349 228 612 349 228 613 minecraft:magenta_concrete
fill 349 228 619 353 228 619 minecraft:gold_block
fill 349 228 623 353 228 623 minecraft:gold_block
fill 349 228 624 349 228 626 minecraft:black_concrete
fill 349 228 627 349 228 629 minecraft:magenta_concrete
fill 349 228 632 353 228 632 minecraft:magenta_concrete
fill 350 228 612 356 228 612 minecraft:black_concrete
setblock 350 228 613 minecraft:magenta_concrete
fill 350 228 618 352 228 618 minecraft:gold_block
fill 350 228 624 352 228 624 minecraft:gold_block
fill 350 228 628 364 228 629 minecraft:black_concrete
fill 350 228 633 356 228 633 minecraft:magenta_concrete
fill 350 228 634 350 229 634 minecraft:black_concrete
fill 351 228 605 351 229 606 minecraft:magenta_concrete
fill 351 228 613 356 228 613 minecraft:black_concrete
fill 351 228 630 364 228 630 minecraft:black_concrete
setblock 351 228 631 minecraft:magenta_concrete
fill 351 228 634 360 229 634 minecraft:magenta_concrete
fill 351 228 637 351 229 637 minecraft:black_concrete
fill 351 228 646 351 247 646 minecraft:purple_concrete
fill 352 228 606 356 229 606 minecraft:magenta_concrete
fill 352 228 614 356 228 614 minecraft:black_concrete
fill 352 228 615 352 228 617 minecraft:magenta_concrete
fill 352 228 631 363 228 631 minecraft:black_concrete
fill 352 228 635 358 229 635 minecraft:magenta_concrete
fill 353 228 607 357 229 607 minecraft:magenta_concrete
fill 353 228 615 353 228 618 minecraft:black_concrete
fill 353 228 620 354 228 622 minecraft:gold_block
fill 353 228 624 353 228 626 minecraft:magenta_concrete
fill 353 228 627 354 228 627 minecraft:black_concrete
fill 354 228 608 358 229 608 minecraft:magenta_concrete
fill 354 228 615 356 228 616 minecraft:black_concrete
fill 354 228 623 359 228 624 minecraft:black_concrete
fill 354 228 625 362 228 626 minecraft:magenta_concrete
fill 354 228 632 362 228 632 minecraft:black_concrete
fill 354 228 636 356 229 636 minecraft:magenta_concrete
fill 355 228 609 358 229 609 minecraft:magenta_concrete
fill 355 228 620 356 228 621 minecraft:magenta_concrete
fill 355 228 622 362 228 622 minecraft:black_concrete
fill 355 228 627 360 228 627 minecraft:magenta_concrete
fill 356 228 610 359 228 611 minecraft:magenta_concrete
fill 357 228 612 357 228 620 minecraft:magenta_concrete
fill 357 228 621 363 228 621 minecraft:black_concrete
fill 357 228 633 360 229 633 minecraft:black_concrete
fill 358 228 607 358 229 607 minecraft:black_concrete
fill 358 228 612 358 228 619 minecraft:magenta_concrete
fill 358 228 620 363 228 620 minecraft:black_concrete
fill 359 228 608 360 229 609 minecraft:black_concrete
fill 359 228 612 359 228 617 minecraft:magenta_concrete
fill 359 228 618 364 228 619 minecraft:black_concrete
fill 360 228 610 362 228 617 minecraft:black_concrete
fill 360 228 623 361 228 623 minecraft:black_concrete
fill 360 228 624 365 228 624 minecraft:magenta_concrete
fill 360 228 646 360 292 646 minecraft:purple_concrete
fill 361 228 609 361 229 609 minecraft:black_concrete
fill 361 228 627 365 228 627 minecraft:black_concrete
fill 361 228 633 361 229 633 minecraft:magenta_concrete
fill 362 228 623 366 229 623 minecraft:magenta_concrete
fill 363 228 611 363 228 617 minecraft:black_concrete
fill 363 228 622 366 228 622 minecraft:magenta_concrete
fill 363 228 625 364 229 625 minecraft:magenta_concrete
fill 363 228 626 366 228 626 minecraft:black_concrete
fill 364 228 612 364 229 617 minecraft:black_concrete
fill 364 228 620 366 228 621 minecraft:magenta_concrete
fill 365 228 614 365 229 617 minecraft:black_concrete
fill 365 228 618 366 229 619 minecraft:magenta_concrete
fill 365 228 625 366 229 625 minecraft:black_concrete
fill 365 228 628 365 229 628 minecraft:black_concrete
fill 366 228 616 366 229 617 minecraft:magenta_concrete
fill 366 228 624 366 229 624 minecraft:black_concrete
fill 367 228 621 367 229 621 minecraft:magenta_concrete
setblock 371 228 606 minecraft:white_concrete
fill 371 228 610 371 265 611 minecraft:purple_concrete
setblock 371 228 612 minecraft:crying_obsidian
setblock 371 228 631 minecraft:magenta_stained_glass
fill 371 228 632 371 231 635 minecraft:purple_concrete
fill 329 229 604 337 231 604 minecraft:purple_concrete
fill 329 229 618 329 260 620 minecraft:purple_concrete
setblock 329 229 621 minecraft:white_concrete
fill 329 229 622 329 256 625 minecraft:purple_concrete
fill 329 229 634 329 260 634 minecraft:purple_concrete
fill 330 229 605 334 229 645 minecraft:obsidian
fill 335 229 605 335 229 620 minecraft:obsidian
fill 335 229 621 337 229 621 minecraft:black_concrete
fill 335 229 622 335 229 645 minecraft:obsidian
fill 336 229 605 336 229 615 minecraft:obsidian
fill 336 229 618 338 229 620 minecraft:black_concrete
fill 336 229 627 336 229 645 minecraft:obsidian
fill 337 229 605 337 229 613 minecraft:obsidian
fill 337 229 617 339 229 617 minecraft:black_concrete
fill 337 229 629 337 229 645 minecraft:obsidian
setblock 338 229 604 minecraft:crying_obsidian
fill 338 229 605 338 229 611 minecraft:obsidian
setblock 338 229 616 minecraft:black_concrete
fill 338 229 621 347 230 621 minecraft:iron_block
fill 338 229 626 338 229 630 minecraft:magenta_concrete
fill 338 229 631 338 229 645 minecraft:obsidian
fill 339 229 604 339 256 604 minecraft:purple_concrete
fill 339 229 605 339 229 610 minecraft:obsidian
setblock 339 229 615 minecraft:black_concrete
fill 339 229 616 363 230 616 minecraft:iron_block
fill 339 229 618 340 229 619 minecraft:black_concrete
fill 339 229 620 339 230 620 minecraft:iron_block
fill 339 229 622 339 230 622 minecraft:iron_block
fill 339 229 623 339 229 625 minecraft:magenta_concrete
fill 339 229 626 363 230 626 minecraft:iron_block
fill 339 229 627 339 229 630 minecraft:magenta_concrete
fill 339 229 632 339 229 645 minecraft:obsidian
fill 340 229 605 340 229 609 minecraft:obsidian
fill 340 229 615 362 230 615 minecraft:iron_block
fill 340 229 617 362 230 617 minecraft:iron_block
setblock 340 229 620 minecraft:black_concrete
fill 340 229 622 340 229 624 minecraft:magenta_concrete
fill 340 229 625 362 230 625 minecraft:iron_block
fill 340 229 627 362 230 627 minecraft:iron_block
fill 340 229 628 341 229 630 minecraft:magenta_concrete
fill 340 229 633 340 229 645 minecraft:obsidian
fill 341 229 605 341 229 608 minecraft:obsidian
fill 341 229 609 347 229 609 minecraft:black_concrete
fill 341 229 611 342 229 613 minecraft:magenta_concrete
fill 341 229 614 342 229 614 minecraft:black_concrete
fill 341 229 618 348 230 620 minecraft:iron_block
fill 341 229 622 348 230 624 minecraft:iron_block
fill 341 229 634 341 229 645 minecraft:obsidian
fill 342 229 605 343 229 607 minecraft:obsidian
fill 342 229 628 342 229 632 minecraft:black_concrete
fill 342 229 635 343 229 645 minecraft:obsidian
fill 343 229 611 344 230 612 minecraft:iron_block
setblock 343 229 613 minecraft:magenta_concrete
fill 343 229 614 359 230 614 minecraft:iron_block
fill 343 229 628 359 230 628 minecraft:iron_block
setblock 343 229 629 minecraft:black_concrete
fill 343 229 630 344 230 631 minecraft:iron_block
fill 343 229 632 347 229 634 minecraft:black_concrete
fill 344 229 605 345 229 606 minecraft:obsidian
fill 344 229 613 358 230 613 minecraft:iron_block
fill 344 229 629 358 230 629 minecraft:iron_block
fill 344 229 636 345 229 645 minecraft:obsidian
fill 345 229 610 347 229 610 minecraft:black_concrete
fill 345 229 611 346 229 611 minecraft:magenta_concrete
fill 345 229 612 359 230 612 minecraft:iron_block
fill 345 229 630 359 230 630 minecraft:iron_block
fill 345 229 631 346 229 631 minecraft:black_concrete
fill 346 229 605 350 229 605 minecraft:obsidian
fill 346 229 637 350 229 645 minecraft:obsidian
fill 347 229 611 355 230 611 minecraft:iron_block
fill 347 229 631 355 230 631 minecraft:iron_block
fill 348 229 609 349 230 610 minecraft:iron_block
fill 348 229 621 349 229 621 minecraft:waxed_copper_block
fill 348 229 632 349 230 633 minecraft:iron_block
fill 348 229 634 349 229 634 minecraft:black_concrete
fill 349 229 604 352 233 604 minecraft:purple_concrete
fill 349 229 618 350 230 618 minecraft:iron_block
fill 349 229 619 349 230 620 minecraft:waxed_copper_block
fill 349 229 622 349 230 623 minecraft:waxed_copper_block
fill 349 229 624 350 230 624 minecraft:iron_block
fill 350 229 609 350 229 610 minecraft:black_concrete
fill 350 229 619 353 229 619 minecraft:waxed_copper_block
fill 350 229 623 353 229 623 minecraft:waxed_copper_block
fill 350 229 632 350 229 633 minecraft:magenta_concrete
fill 351 229 609 352 229 609 minecraft:black_concrete
fill 351 229 610 351 230 610 minecraft:iron_block
fill 351 229 618 351 231 618 minecraft:waxed_copper_block
fill 351 229 624 351 231 624 minecraft:waxed_copper_block
fill 351 229 632 351 230 632 minecraft:iron_block
fill 351 229 633 352 229 633 minecraft:magenta_concrete
fill 351 229 638 370 229 645 minecraft:obsidian
fill 352 229 605 370 229 605 minecraft:obsidian
setblock 352 229 610 minecraft:black_concrete
fill 352 229 618 361 230 618 minecraft:iron_block
fill 352 229 624 361 230 624 minecraft:iron_block
setblock 352 229 632 minecraft:magenta_concrete
fill 352 229 637 370 229 637 minecraft:obsidian
fill 352 229 646 353 241 646 minecraft:purple_concrete
setblock 353 229 604 minecraft:white_concrete
fill 353 229 609 354 230 610 minecraft:iron_block
fill 353 229 620 353 229 622 minecraft:waxed_copper_block
fill 353 229 632 354 230 633 minecraft:iron_block
fill 354 229 604 356 245 604 minecraft:purple_concrete
fill 354 229 619 361 230 620 minecraft:iron_block
fill 354 229 621 354 231 621 minecraft:waxed_copper_block
fill 354 229 622 361 230 623 minecraft:iron_block
setblock 354 229 646 minecraft:white_concrete
setblock 355 229 610 minecraft:black_concrete
fill 355 229 621 364 230 621 minecraft:iron_block
fill 355 229 632 362 229 632 minecraft:black_concrete
fill 355 229 633 356 229 633 minecraft:magenta_concrete
fill 355 229 646 359 233 646 minecraft:purple_concrete
fill 356 229 610 357 229 611 minecraft:magenta_concrete
fill 356 229 631 357 229 631 minecraft:black_concrete
fill 357 229 606 370 229 606 minecraft:obsidian
fill 357 229 636 370 229 636 minecraft:obsidian
fill 358 229 610 359 229 610 minecraft:magenta_concrete
fill 358 229 611 359 230 611 minecraft:iron_block
fill 358 229 631 359 230 631 minecraft:iron_block
fill 359 229 607 370 229 607 minecraft:obsidian
setblock 359 229 613 minecraft:magenta_concrete
fill 359 229 629 364 229 629 minecraft:black_concrete
fill 359 229 635 370 229 635 minecraft:obsidian
fill 360 229 610 362 229 614 minecraft:black_concrete
fill 360 229 628 364 229 628 minecraft:black_concrete
fill 360 229 630 363 229 631 minecraft:black_concrete
fill 361 229 608 370 229 608 minecraft:obsidian
fill 361 229 634 370 229 634 minecraft:obsidian
fill 362 229 609 370 229 609 minecraft:obsidian
fill 362 229 618 362 229 620 minecraft:black_concrete
setblock 362 229 622 minecraft:black_concrete
fill 362 229 624 365 229 624 minecraft:magenta_concrete
fill 362 229 633 370 229 633 minecraft:obsidian
fill 363 229 610 370 229 610 minecraft:obsidian
fill 363 229 611 363 229 615 minecraft:black_concrete
fill 363 229 617 363 229 619 minecraft:black_concrete
fill 363 229 620 363 230 620 minecraft:iron_block
fill 363 229 622 363 230 622 minecraft:iron_block
fill 363 229 627 365 229 627 minecraft:black_concrete
fill 363 229 632 370 229 632 minecraft:obsidian
fill 364 229 611 370 229 611 minecraft:obsidian
fill 364 229 618 364 229 619 minecraft:black_concrete
fill 364 229 620 366 229 620 minecraft:magenta_concrete
fill 364 229 622 366 229 622 minecraft:magenta_concrete
fill 364 229 626 366 229 626 minecraft:black_concrete
setblock 364 229 630 minecraft:black_concrete
fill 364 229 631 370 229 631 minecraft:obsidian
fill 365 229 612 370 229 613 minecraft:obsidian
fill 365 229 621 366 229 621 minecraft:magenta_concrete
fill 365 229 629 370 229 630 minecraft:obsidian
fill 365 229 646 367 271 646 minecraft:purple_concrete
fill 366 229 614 370 229 615 minecraft:obsidian
fill 366 229 627 370 229 628 minecraft:obsidian
fill 367 229 616 370 229 620 minecraft:obsidian
fill 367 229 622 370 229 626 minecraft:obsidian
fill 368 229 621 370 229 621 minecraft:obsidian
setblock 368 229 646 minecraft:white_concrete
setblock 371 229 606 minecraft:purple_concrete
fill 371 229 612 371 285 612 minecraft:purple_concrete
fill 371 229 631 371 307 631 minecraft:purple_concrete
fill 329 230 621 329 244 621 minecraft:purple_concrete
fill 329 230 635 329 246 638 minecraft:purple_concrete
setblock 329 230 639 minecraft:magenta_stained_glass
fill 329 230 640 329 244 643 minecraft:purple_concrete
setblock 332 230 607 minecraft:light[level=12]
setblock 332 230 615 minecraft:light[level=12]
setblock 332 230 623 minecraft:light[level=12]
setblock 332 230 631 minecraft:light[level=12]
setblock 332 230 639 minecraft:light[level=12]
fill 338 230 604 338 247 604 minecraft:purple_concrete
setblock 340 230 607 minecraft:light[level=12]
setblock 340 230 623 minecraft:light[level=12]
setblock 340 230 631 minecraft:light[level=12]
setblock 340 230 639 minecraft:light[level=12]
setblock 348 230 607 minecraft:light[level=12]
fill 348 230 621 348 231 621 minecraft:waxed_copper_block
setblock 348 230 639 minecraft:light[level=12]
setblock 350 230 619 minecraft:waxed_copper_block
setblock 350 230 623 minecraft:waxed_copper_block
fill 352 230 619 353 230 619 minecraft:waxed_copper_block
fill 352 230 623 353 230 623 minecraft:waxed_copper_block
setblock 353 230 604 minecraft:purple_concrete
setblock 353 230 620 minecraft:waxed_copper_block
setblock 353 230 622 minecraft:waxed_copper_block
fill 354 230 646 354 247 646 minecraft:purple_concrete
setblock 356 230 607 minecraft:light[level=12]
setblock 356 230 631 minecraft:light[level=12]
setblock 356 230 639 minecraft:light[level=12]
setblock 364 230 607 minecraft:light[level=12]
setblock 364 230 615 minecraft:light[level=12]
setblock 364 230 623 minecraft:light[level=12]
setblock 364 230 631 minecraft:light[level=12]
setblock 364 230 639 minecraft:light[level=12]
setblock 368 230 646 minecraft:purple_concrete
setblock 371 230 606 minecraft:white_concrete
fill 329 231 639 329 244 639 minecraft:purple_concrete
fill 344 231 619 344 231 623 minecraft:waxed_oxidized_copper
fill 345 231 617 345 231 618 minecraft:waxed_oxidized_copper
fill 345 231 624 345 231 625 minecraft:waxed_oxidized_copper
setblock 346 231 616 minecraft:waxed_oxidized_copper
setblock 346 231 626 minecraft:waxed_oxidized_copper
fill 347 231 615 348 231 615 minecraft:waxed_oxidized_copper
fill 347 231 627 348 231 627 minecraft:waxed_oxidized_copper
fill 349 231 614 353 231 614 minecraft:waxed_oxidized_copper
setblock 349 231 619 minecraft:waxed_copper_block
setblock 349 231 623 minecraft:waxed_copper_block
fill 349 231 628 353 231 628 minecraft:waxed_oxidized_copper
setblock 353 231 604 minecraft:magenta_stained_glass
setblock 353 231 619 minecraft:waxed_copper_block
setblock 353 231 623 minecraft:waxed_copper_block
fill 354 231 615 355 231 615 minecraft:waxed_oxidized_copper
fill 354 231 627 355 231 627 minecraft:waxed_oxidized_copper
setblock 356 231 616 minecraft:waxed_oxidized_copper
setblock 356 231 626 minecraft:waxed_oxidized_copper
fill 357 231 617 357 231 618 minecraft:waxed_oxidized_copper
fill 357 231 624 357 231 625 minecraft:waxed_oxidized_copper
fill 358 231 619 358 231 623 minecraft:waxed_oxidized_copper
setblock 368 231 646 minecraft:white_concrete
fill 371 231 606 371 244 606 minecraft:purple_concrete
setblock 371 231 617 minecraft:crying_obsidian
fill 371 231 618 371 274 618 minecraft:purple_concrete
fill 329 232 604 334 232 604 minecraft:purple_concrete
setblock 335 232 604 minecraft:white_concrete
fill 336 232 604 337 256 604 minecraft:purple_concrete
fill 353 232 604 353 307 604 minecraft:purple_concrete
fill 368 232 646 368 257 646 minecraft:purple_concrete
fill 371 232 617 371 282 617 minecraft:purple_concrete
fill 371 232 632 371 244 632 minecraft:purple_concrete
setblock 371 232 633 minecraft:white_concrete
fill 371 232 634 371 251 635 minecraft:purple_concrete
fill 329 233 604 331 252 604 minecraft:purple_concrete
setblock 332 233 604 minecraft:magenta_stained_glass
fill 333 233 604 335 233 604 minecraft:purple_concrete
fill 360 233 635 361 242 636 minecraft:black_concrete
fill 371 233 633 371 307 633 minecraft:purple_concrete
fill 329 234 605 329 239 611 minecraft:purple_concrete
fill 329 234 612 329 236 612 minecraft:magenta_concrete
fill 329 234 613 329 234 617 minecraft:purple_concrete
fill 329 234 626 329 253 627 minecraft:purple_concrete
fill 329 234 628 329 236 628 minecraft:magenta_concrete
fill 329 234 629 329 260 629 minecraft:purple_concrete
setblock 329 234 630 minecraft:magenta_stained_glass
fill 329 234 644 329 236 644 minecraft:magenta_concrete
fill 329 234 645 329 307 645 minecraft:purple_concrete
fill 332 234 604 332 254 604 minecraft:purple_concrete
fill 333 234 604 333 236 604 minecraft:magenta_concrete
fill 334 234 604 335 307 604 minecraft:purple_concrete
fill 339 234 646 342 234 646 minecraft:purple_concrete
fill 343 234 646 343 236 646 minecraft:magenta_concrete
fill 349 234 604 349 236 604 minecraft:magenta_concrete
fill 350 234 604 352 250 604 minecraft:purple_concrete
fill 355 234 646 358 265 646 minecraft:purple_concrete
fill 359 234 635 359 242 636 minecraft:black_concrete
fill 359 234 646 359 236 646 minecraft:magenta_concrete
fill 360 234 634 360 242 634 minecraft:black_concrete
fill 365 234 604 365 236 604 minecraft:magenta_concrete
fill 371 234 613 371 261 613 minecraft:purple_concrete
fill 371 234 614 371 236 614 minecraft:magenta_concrete
fill 371 234 630 371 236 630 minecraft:magenta_concrete
fill 329 235 613 329 254 614 minecraft:purple_concrete
setblock 329 235 615 minecraft:white_concrete
fill 329 235 616 329 283 617 minecraft:purple_concrete
fill 329 235 630 329 260 630 minecraft:purple_concrete
setblock 339 235 646 minecraft:white_concrete
fill 340 235 646 342 238 646 minecraft:purple_concrete
setblock 341 235 604 minecraft:white_concrete
fill 355 235 618 356 236 624 minecraft:waxed_copper_block
fill 356 235 617 364 236 617 minecraft:waxed_copper_block
fill 356 235 625 364 236 625 minecraft:waxed_copper_block
fill 357 235 616 363 236 616 minecraft:waxed_copper_block
fill 357 235 618 357 236 620 minecraft:waxed_copper_block
fill 357 235 622 357 236 624 minecraft:waxed_copper_block
fill 357 235 626 363 236 626 minecraft:waxed_copper_block
fill 358 235 618 359 236 618 minecraft:waxed_copper_block
fill 358 235 624 359 236 624 minecraft:waxed_copper_block
fill 359 235 634 359 242 634 minecraft:black_concrete
fill 360 235 615 360 236 615 minecraft:waxed_copper_block
fill 360 235 627 360 236 627 minecraft:waxed_copper_block
fill 360 235 637 361 242 637 minecraft:black_concrete
fill 361 235 618 365 236 618 minecraft:waxed_copper_block
fill 361 235 624 365 236 624 minecraft:waxed_copper_block
fill 361 235 634 361 242 634 minecraft:black_concrete
setblock 362 235 604 minecraft:white_concrete
fill 362 235 635 362 242 636 minecraft:black_concrete
fill 363 235 619 365 236 620 minecraft:waxed_copper_block
fill 363 235 622 365 236 623 minecraft:waxed_copper_block
fill 364 235 621 366 236 621 minecraft:waxed_copper_block
fill 329 236 615 329 268 615 minecraft:purple_concrete
fill 339 236 646 339 244 646 minecraft:purple_concrete
fill 341 236 604 341 307 604 minecraft:purple_concrete
fill 341 236 625 342 237 625 minecraft:magenta_concrete
fill 341 236 630 341 237 631 minecraft:gold_block
fill 358 236 635 358 242 636 minecraft:black_concrete
fill 359 236 637 359 242 637 minecraft:black_concrete
fill 360 236 633 361 242 633 minecraft:black_concrete
fill 362 236 604 362 273 604 minecraft:purple_concrete
fill 362 236 634 362 242 634 minecraft:black_concrete
fill 362 236 637 362 242 637 minecraft:black_concrete
fill 329 237 612 329 242 612 minecraft:purple_concrete
setblock 329 237 628 minecraft:white_concrete
fill 329 237 644 329 242 644 minecraft:purple_concrete
fill 333 237 604 333 242 604 minecraft:purple_concrete
setblock 337 237 646 minecraft:crying_obsidian
fill 343 237 646 343 242 646 minecraft:purple_concrete
fill 349 237 604 349 242 604 minecraft:purple_concrete
fill 358 237 634 358 242 634 minecraft:black_concrete
fill 358 237 637 358 242 637 minecraft:black_concrete
fill 359 237 633 359 242 633 minecraft:black_concrete
fill 359 237 646 359 242 646 minecraft:purple_concrete
fill 360 237 638 361 242 638 minecraft:black_concrete
fill 362 237 633 362 242 633 minecraft:black_concrete
fill 363 237 635 363 242 636 minecraft:black_concrete
fill 365 237 604 365 242 604 minecraft:purple_concrete
fill 371 237 614 371 242 614 minecraft:purple_concrete
fill 371 237 630 371 242 630 minecraft:purple_concrete
fill 329 238 628 329 242 628 minecraft:purple_concrete
setblock 332 238 607 minecraft:light[level=12]
setblock 332 238 615 minecraft:light[level=12]
setblock 332 238 623 minecraft:light[level=12]
setblock 332 238 631 minecraft:light[level=12]
setblock 332 238 639 minecraft:light[level=12]
fill 337 238 646 337 253 646 minecraft:purple_concrete
setblock 340 238 607 minecraft:light[level=12]
setblock 340 238 615 minecraft:light[level=12]
setblock 340 238 623 minecraft:light[level=12]
setblock 340 238 631 minecraft:light[level=12]
setblock 340 238 639 minecraft:light[level=12]
setblock 348 238 607 minecraft:light[level=12]
setblock 348 238 615 minecraft:light[level=12]
setblock 348 238 631 minecraft:light[level=12]
setblock 348 238 639 minecraft:light[level=12]
setblock 356 238 607 minecraft:light[level=12]
setblock 356 238 615 minecraft:light[level=12]
setblock 356 238 623 minecraft:light[level=12]
setblock 356 238 631 minecraft:light[level=12]
setblock 356 238 639 minecraft:light[level=12]
fill 357 238 635 357 242 636 minecraft:black_concrete
fill 358 238 633 358 242 633 minecraft:black_concrete
fill 359 238 638 359 242 638 minecraft:black_concrete
fill 360 238 632 361 242 632 minecraft:black_concrete
fill 362 238 638 362 242 638 minecraft:black_concrete
fill 363 238 634 363 242 634 minecraft:black_concrete
fill 363 238 637 363 242 637 minecraft:black_concrete
setblock 364 238 607 minecraft:light[level=12]
setblock 364 238 615 minecraft:light[level=12]
setblock 364 238 623 minecraft:light[level=12]
setblock 364 238 631 minecraft:light[level=12]
setblock 364 238 639 minecraft:light[level=12]
setblock 371 238 609 minecraft:magenta_stained_glass
setblock 371 238 644 minecraft:magenta_stained_glass
setblock 329 239 631 minecraft:purple_concrete
setblock 329 239 632 minecraft:magenta_stained_glass
fill 329 239 633 329 274 633 minecraft:purple_concrete
fill 330 239 646 330 307 646 minecraft:purple_concrete
setblock 331 239 646 minecraft:white_concrete
fill 340 239 646 341 261 646 minecraft:purple_concrete
setblock 342 239 646 minecraft:magenta_stained_glass
fill 357 239 634 357 242 634 minecraft:black_concrete
fill 357 239 637 357 242 637 minecraft:black_concrete
fill 358 239 638 358 242 638 minecraft:black_concrete
fill 359 239 632 359 242 632 minecraft:black_concrete
fill 359 239 639 361 242 639 minecraft:black_concrete
fill 362 239 632 362 242 632 minecraft:black_concrete
setblock 363 239 604 minecraft:white_concrete
fill 363 239 633 363 242 633 minecraft:black_concrete
fill 363 239 638 363 242 638 minecraft:black_concrete
fill 364 239 604 364 275 604 minecraft:purple_concrete
fill 364 239 634 364 242 636 minecraft:black_concrete
fill 371 239 609 371 243 609 minecraft:purple_concrete
fill 371 239 644 371 258 644 minecraft:purple_concrete
fill 329 240 605 329 267 606 minecraft:purple_concrete
setblock 329 240 607 minecraft:magenta_stained_glass
fill 329 240 608 329 244 611 minecraft:purple_concrete
setblock 329 240 631 minecraft:magenta_stained_glass
fill 329 240 632 329 280 632 minecraft:purple_concrete
fill 331 240 646 331 247 646 minecraft:purple_concrete
fill 342 240 646 342 307 646 minecraft:purple_concrete
fill 348 240 633 348 241 633 minecraft:magenta_concrete
fill 356 240 635 356 242 636 minecraft:black_concrete
fill 357 240 633 357 242 633 minecraft:black_concrete
fill 357 240 638 357 242 638 minecraft:black_concrete
fill 358 240 632 358 242 632 minecraft:black_concrete
fill 358 240 639 358 242 639 minecraft:black_concrete
fill 360 240 631 361 242 631 minecraft:black_concrete
fill 362 240 639 362 242 639 minecraft:black_concrete
fill 363 240 604 363 307 604 minecraft:purple_concrete
fill 363 240 632 363 242 632 minecraft:black_concrete
fill 364 240 633 364 242 633 minecraft:black_concrete
fill 364 240 637 364 242 637 minecraft:black_concrete
fill 329 241 607 329 307 607 minecraft:purple_concrete
fill 329 241 631 329 307 631 minecraft:purple_concrete
setblock 344 241 646 minecraft:white_concrete
fill 356 241 633 356 242 634 minecraft:black_concrete
fill 356 241 637 356 242 637 minecraft:black_concrete
fill 357 241 632 357 242 632 minecraft:black_concrete
fill 358 241 631 359 242 631 minecraft:black_concrete
fill 359 241 604 359 307 604 minecraft:purple_concrete
fill 359 241 640 361 242 640 minecraft:black_concrete
setblock 360 241 604 minecraft:white_concrete
fill 361 241 604 361 256 604 minecraft:purple_concrete
fill 361 241 646 361 244 646 minecraft:purple_concrete
fill 362 241 631 362 242 631 minecraft:black_concrete
setblock 362 241 646 minecraft:magenta_stained_glass
fill 363 241 639 363 242 639 minecraft:black_concrete
fill 363 241 646 364 276 646 minecraft:purple_concrete
fill 364 241 638 364 242 638 minecraft:black_concrete
fill 365 241 634 365 242 636 minecraft:black_concrete
fill 344 242 646 344 307 646 minecraft:purple_concrete
fill 352 242 646 352 269 646 minecraft:purple_concrete
setblock 353 242 646 minecraft:crying_obsidian
fill 355 242 635 355 242 636 minecraft:black_concrete
setblock 356 242 638 minecraft:black_concrete
setblock 357 242 639 minecraft:black_concrete
setblock 358 242 640 minecraft:black_concrete
fill 360 242 604 360 244 604 minecraft:purple_concrete
fill 360 242 630 361 242 630 minecraft:black_concrete
fill 362 242 620 362 243 620 minecraft:crying_obsidian
fill 362 242 640 363 242 640 minecraft:black_concrete
fill 362 242 646 362 292 646 minecraft:purple_concrete
setblock 363 242 631 minecraft:black_concrete
setblock 364 242 632 minecraft:black_concrete
setblock 364 242 639 minecraft:black_concrete
schedule function dropper:buildpart/151_2 1t
