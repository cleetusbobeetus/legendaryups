fill 472 157 303 472 158 303 minecraft:deepslate_tiles
fill 472 157 316 475 157 316 minecraft:deepslate_tiles
setblock 473 157 279 minecraft:cobbled_deepslate
fill 473 157 280 473 160 280 minecraft:deepslate_tiles
setblock 473 157 284 minecraft:cobbled_deepslate
setblock 473 157 285 minecraft:light[level=12]
setblock 473 157 286 minecraft:light[level=13]
setblock 473 157 294 minecraft:light[level=13]
setblock 473 157 299 minecraft:light[level=12]
setblock 473 157 302 minecraft:light[level=13]
setblock 473 157 306 minecraft:light[level=12]
setblock 473 157 310 minecraft:light[level=13]
setblock 473 157 313 minecraft:light[level=12]
setblock 474 157 277 minecraft:deepslate_tiles
setblock 474 157 278 minecraft:cobbled_deepslate
setblock 474 157 279 minecraft:deepslate_tiles
setblock 475 157 277 minecraft:cobbled_deepslate
fill 475 157 278 475 160 278 minecraft:deepslate_tiles
setblock 476 157 276 minecraft:cobbled_deepslate
fill 476 157 277 476 160 277 minecraft:deepslate_tiles
setblock 476 157 316 minecraft:cobbled_deepslate
fill 477 157 276 480 157 276 minecraft:deepslate_tiles
fill 477 157 316 478 157 316 minecraft:deepslate_tiles
setblock 480 157 278 minecraft:light[level=12]
setblock 480 157 285 minecraft:light[level=12]
setblock 480 157 292 minecraft:light[level=12]
setblock 480 157 299 minecraft:light[level=12]
setblock 480 157 306 minecraft:light[level=12]
setblock 480 157 313 minecraft:light[level=12]
setblock 481 157 276 minecraft:cobbled_deepslate
setblock 481 157 278 minecraft:light[level=13]
setblock 481 157 286 minecraft:light[level=13]
setblock 481 157 294 minecraft:light[level=13]
setblock 481 157 302 minecraft:light[level=13]
setblock 481 157 310 minecraft:light[level=13]
fill 482 157 276 485 157 276 minecraft:deepslate_tiles
setblock 485 157 316 minecraft:deepslate_tiles
setblock 486 157 276 minecraft:cobbled_deepslate
setblock 486 157 316 minecraft:cobbled_deepslate
fill 487 157 276 490 157 276 minecraft:deepslate_tiles
setblock 487 157 278 minecraft:light[level=12]
setblock 487 157 285 minecraft:light[level=12]
setblock 487 157 292 minecraft:light[level=12]
setblock 487 157 299 minecraft:light[level=12]
setblock 487 157 306 minecraft:light[level=12]
setblock 487 157 313 minecraft:light[level=12]
fill 487 157 316 490 157 316 minecraft:deepslate_tiles
fill 488 157 277 489 157 277 minecraft:deepslate_tiles
setblock 489 157 278 minecraft:light[level=13]
setblock 489 157 286 minecraft:light[level=13]
setblock 489 157 294 minecraft:light[level=13]
setblock 489 157 302 minecraft:light[level=13]
setblock 489 157 310 minecraft:light[level=13]
fill 489 157 315 491 157 315 minecraft:deepslate_tiles
setblock 490 157 275 minecraft:redstone_block
setblock 490 157 277 minecraft:cobbled_deepslate
setblock 491 157 276 minecraft:cobbled_deepslate
fill 491 157 277 491 160 277 minecraft:deepslate_tiles
setblock 491 157 316 minecraft:cobbled_deepslate
fill 492 157 276 495 157 276 minecraft:deepslate_tiles
setblock 492 157 315 minecraft:cobbled_deepslate
fill 492 157 316 495 157 316 minecraft:deepslate_tiles
setblock 494 157 278 minecraft:light[level=12]
setblock 494 157 285 minecraft:light[level=12]
setblock 494 157 292 minecraft:light[level=12]
setblock 494 157 299 minecraft:light[level=12]
setblock 494 157 306 minecraft:light[level=12]
setblock 494 157 313 minecraft:light[level=12]
setblock 497 157 278 minecraft:light[level=13]
setblock 497 157 286 minecraft:light[level=13]
setblock 497 157 294 minecraft:light[level=13]
setblock 497 157 302 minecraft:light[level=13]
setblock 497 157 310 minecraft:light[level=13]
setblock 501 157 278 minecraft:light[level=12]
setblock 501 157 285 minecraft:light[level=12]
setblock 501 157 292 minecraft:light[level=12]
setblock 501 157 299 minecraft:light[level=12]
setblock 501 157 306 minecraft:light[level=12]
setblock 501 157 313 minecraft:light[level=12]
setblock 501 157 317 minecraft:white_wool
setblock 505 157 278 minecraft:light[level=13]
setblock 505 157 286 minecraft:light[level=13]
setblock 505 157 294 minecraft:light[level=13]
setblock 505 157 302 minecraft:light[level=13]
setblock 505 157 310 minecraft:light[level=13]
fill 507 157 276 507 160 276 minecraft:deepslate_tiles
fill 508 157 277 509 157 277 minecraft:deepslate_tiles
setblock 508 157 278 minecraft:light[level=12]
setblock 508 157 285 minecraft:light[level=12]
setblock 508 157 292 minecraft:light[level=12]
setblock 508 157 299 minecraft:light[level=12]
setblock 508 157 306 minecraft:light[level=12]
setblock 508 157 313 minecraft:light[level=12]
fill 509 157 279 509 157 282 minecraft:deepslate_tiles
setblock 509 157 283 minecraft:cobbled_deepslate
setblock 509 157 298 minecraft:cobbled_deepslate
fill 509 157 299 509 160 299 minecraft:deepslate_tiles
fill 509 157 301 509 158 301 minecraft:deepslate_tiles
setblock 510 157 277 minecraft:cobbled_deepslate
fill 510 157 278 510 160 278 minecraft:deepslate_tiles
setblock 510 157 282 minecraft:cobbled_deepslate
fill 510 157 283 510 160 283 minecraft:deepslate_tiles
setblock 510 157 286 minecraft:deepslate_tiles
setblock 510 157 287 minecraft:cobbled_deepslate
fill 510 157 288 510 157 291 minecraft:deepslate_tiles
setblock 510 157 292 minecraft:cobbled_deepslate
fill 510 157 293 510 160 293 minecraft:deepslate_tiles
setblock 510 157 297 minecraft:cobbled_deepslate
fill 510 157 298 510 160 298 minecraft:deepslate_tiles
setblock 510 157 302 minecraft:cobbled_deepslate
fill 510 157 303 510 160 303 minecraft:deepslate_tiles
fill 510 157 305 510 158 305 minecraft:deepslate_tiles
setblock 511 157 276 minecraft:cobbled_deepslate
fill 511 157 277 511 160 277 minecraft:deepslate_tiles
setblock 511 157 281 minecraft:cobbled_deepslate
fill 511 157 282 511 160 282 minecraft:deepslate_tiles
setblock 511 157 286 minecraft:cobbled_deepslate
fill 511 157 287 511 157 290 minecraft:deepslate_tiles
setblock 511 157 291 minecraft:cobbled_deepslate
fill 511 157 292 511 160 292 minecraft:deepslate_tiles
setblock 511 157 296 minecraft:cobbled_deepslate
fill 511 157 297 511 160 297 minecraft:deepslate_tiles
setblock 511 157 301 minecraft:cobbled_deepslate
fill 511 157 302 511 160 302 minecraft:deepslate_tiles
setblock 511 157 306 minecraft:cobbled_deepslate
fill 511 157 307 511 160 307 minecraft:deepslate_tiles
setblock 470 158 303 minecraft:redstone_block
fill 471 158 276 472 158 278 minecraft:deepslate_tiles
setblock 471 158 280 minecraft:cobbled_deepslate
fill 471 158 281 471 161 281 minecraft:deepslate_tiles
setblock 471 158 285 minecraft:cobbled_deepslate
fill 471 158 286 471 158 289 minecraft:deepslate_tiles
setblock 471 158 290 minecraft:cobbled_deepslate
fill 471 158 291 471 161 291 minecraft:deepslate_tiles
fill 471 158 292 482 159 293 minecraft:iron_block
setblock 471 158 294 minecraft:deepslate_tiles
setblock 471 158 295 minecraft:cobbled_deepslate
fill 471 158 296 471 158 299 minecraft:deepslate_tiles
setblock 471 158 300 minecraft:cobbled_deepslate
fill 471 158 301 471 161 301 minecraft:deepslate_tiles
setblock 471 158 304 minecraft:deepslate_tiles
setblock 471 158 305 minecraft:cobbled_deepslate
fill 471 158 306 471 161 306 minecraft:deepslate_tiles
fill 471 158 308 471 158 309 minecraft:deepslate_tiles
setblock 471 158 310 minecraft:cobbled_deepslate
fill 471 158 313 471 158 314 minecraft:deepslate_tiles
setblock 471 158 315 minecraft:cobbled_deepslate
fill 471 158 316 474 158 316 minecraft:deepslate_tiles
setblock 472 158 279 minecraft:cobbled_deepslate
fill 472 158 280 472 161 280 minecraft:deepslate_tiles
setblock 472 158 284 minecraft:cobbled_deepslate
fill 472 158 285 473 160 285 minecraft:deepslate_tiles
setblock 472 158 288 minecraft:deepslate_tiles
setblock 472 158 299 minecraft:cobbled_deepslate
fill 472 158 300 472 160 300 minecraft:deepslate_tiles
setblock 472 158 304 minecraft:cobbled_deepslate
fill 472 158 305 472 161 305 minecraft:deepslate_tiles
fill 473 158 276 473 158 277 minecraft:deepslate_tiles
setblock 473 158 278 minecraft:cobbled_deepslate
fill 473 158 279 473 161 279 minecraft:deepslate_tiles
setblock 473 158 283 minecraft:cobbled_deepslate
fill 473 158 284 473 161 284 minecraft:deepslate_tiles
fill 473 158 291 477 158 291 minecraft:bone_block
setblock 474 158 276 minecraft:deepslate_tiles
setblock 474 158 277 minecraft:cobbled_deepslate
fill 474 158 278 474 161 278 minecraft:deepslate_tiles
setblock 475 158 276 minecraft:cobbled_deepslate
fill 475 158 277 475 161 277 minecraft:deepslate_tiles
setblock 475 158 316 minecraft:cobbled_deepslate
fill 476 158 276 479 158 276 minecraft:deepslate_tiles
fill 476 158 316 477 160 316 minecraft:deepslate_tiles
fill 477 158 277 478 158 277 minecraft:deepslate_tiles
setblock 480 158 276 minecraft:cobbled_deepslate
fill 481 158 276 484 158 276 minecraft:deepslate_tiles
fill 483 158 292 496 159 292 minecraft:iron_block
fill 484 158 293 496 159 293 minecraft:iron_block
setblock 484 158 316 minecraft:deepslate_tiles
setblock 485 158 276 minecraft:cobbled_deepslate
setblock 485 158 316 minecraft:cobbled_deepslate
fill 486 158 276 489 158 276 minecraft:deepslate_tiles
fill 486 158 316 489 158 316 minecraft:deepslate_tiles
fill 487 158 277 488 158 277 minecraft:deepslate_tiles
setblock 489 158 277 minecraft:cobbled_deepslate
fill 489 158 315 490 158 315 minecraft:deepslate_tiles
fill 490 158 275 490 201 275 minecraft:black_concrete
setblock 490 158 276 minecraft:cobbled_deepslate
fill 490 158 277 490 161 277 minecraft:deepslate_tiles
setblock 490 158 316 minecraft:cobbled_deepslate
fill 491 158 276 494 158 276 minecraft:deepslate_tiles
setblock 491 158 315 minecraft:cobbled_deepslate
fill 491 158 316 494 158 316 minecraft:deepslate_tiles
setblock 495 158 276 minecraft:cobbled_deepslate
fill 501 158 317 501 198 317 minecraft:black_concrete
fill 506 158 276 506 161 276 minecraft:deepslate_tiles
setblock 508 158 277 minecraft:deepslate_tiles
setblock 509 158 277 minecraft:cobbled_deepslate
fill 509 158 278 509 158 281 minecraft:deepslate_tiles
setblock 509 158 282 minecraft:cobbled_deepslate
fill 509 158 283 509 158 286 minecraft:deepslate_tiles
fill 509 158 298 509 160 298 minecraft:deepslate_tiles
setblock 509 158 302 minecraft:cobbled_deepslate
setblock 510 158 276 minecraft:cobbled_deepslate
fill 510 158 277 510 161 277 minecraft:deepslate_tiles
setblock 510 158 281 minecraft:cobbled_deepslate
fill 510 158 282 510 161 282 minecraft:deepslate_tiles
setblock 510 158 285 minecraft:deepslate_tiles
setblock 510 158 286 minecraft:cobbled_deepslate
fill 510 158 287 510 158 290 minecraft:deepslate_tiles
setblock 510 158 291 minecraft:cobbled_deepslate
fill 510 158 292 510 161 292 minecraft:deepslate_tiles
setblock 510 158 296 minecraft:cobbled_deepslate
fill 510 158 297 510 161 297 minecraft:deepslate_tiles
setblock 510 158 301 minecraft:cobbled_deepslate
fill 510 158 302 510 161 302 minecraft:deepslate_tiles
setblock 510 158 306 minecraft:cobbled_deepslate
fill 511 158 276 511 161 276 minecraft:deepslate_tiles
setblock 511 158 280 minecraft:cobbled_deepslate
fill 511 158 281 511 161 281 minecraft:deepslate_tiles
setblock 511 158 285 minecraft:cobbled_deepslate
fill 511 158 286 511 158 289 minecraft:deepslate_tiles
setblock 511 158 290 minecraft:cobbled_deepslate
fill 511 158 291 511 161 291 minecraft:deepslate_tiles
setblock 511 158 295 minecraft:cobbled_deepslate
fill 511 158 296 511 161 296 minecraft:deepslate_tiles
setblock 511 158 300 minecraft:cobbled_deepslate
fill 511 158 301 511 161 301 minecraft:deepslate_tiles
setblock 511 158 305 minecraft:cobbled_deepslate
fill 511 158 306 511 161 306 minecraft:deepslate_tiles
fill 511 158 308 511 159 308 minecraft:deepslate_tiles
fill 470 159 303 470 201 303 minecraft:black_concrete
fill 470 159 308 470 174 308 minecraft:black_concrete
setblock 470 159 309 minecraft:white_wool
fill 470 159 310 470 197 310 minecraft:black_concrete
fill 471 159 276 471 159 278 minecraft:deepslate_tiles
setblock 471 159 279 minecraft:cobbled_deepslate
fill 471 159 280 471 162 280 minecraft:deepslate_tiles
setblock 471 159 284 minecraft:cobbled_deepslate
fill 471 159 285 471 159 288 minecraft:deepslate_tiles
setblock 471 159 289 minecraft:cobbled_deepslate
fill 471 159 290 471 162 290 minecraft:deepslate_tiles
setblock 471 159 294 minecraft:cobbled_deepslate
fill 471 159 295 471 159 298 minecraft:deepslate_tiles
setblock 471 159 299 minecraft:cobbled_deepslate
fill 471 159 300 471 162 300 minecraft:deepslate_tiles
setblock 471 159 304 minecraft:cobbled_deepslate
fill 471 159 305 471 162 305 minecraft:deepslate_tiles
setblock 471 159 308 minecraft:deepslate_tiles
setblock 471 159 309 minecraft:cobbled_deepslate
fill 471 159 310 471 159 313 minecraft:deepslate_tiles
setblock 471 159 314 minecraft:cobbled_deepslate
fill 471 159 315 471 161 316 minecraft:deepslate_tiles
fill 472 159 276 472 159 277 minecraft:deepslate_tiles
setblock 472 159 278 minecraft:cobbled_deepslate
fill 472 159 279 472 162 279 minecraft:deepslate_tiles
setblock 472 159 283 minecraft:cobbled_deepslate
fill 472 159 284 472 162 284 minecraft:deepslate_tiles
setblock 472 159 288 minecraft:cobbled_deepslate
setblock 472 159 303 minecraft:cobbled_deepslate
fill 472 159 304 472 162 304 minecraft:deepslate_tiles
fill 472 159 306 472 159 307 minecraft:deepslate_tiles
fill 472 159 316 473 159 316 minecraft:deepslate_tiles
setblock 473 159 276 minecraft:deepslate_tiles
setblock 473 159 277 minecraft:cobbled_deepslate
fill 473 159 278 473 162 278 minecraft:deepslate_tiles
setblock 473 159 282 minecraft:cobbled_deepslate
fill 473 159 283 473 162 283 minecraft:deepslate_tiles
setblock 474 159 276 minecraft:cobbled_deepslate
fill 474 159 277 474 162 277 minecraft:deepslate_tiles
setblock 474 159 316 minecraft:cobbled_deepslate
setblock 474 159 317 minecraft:white_wool
fill 475 159 276 478 159 276 minecraft:deepslate_tiles
fill 475 159 316 475 162 316 minecraft:deepslate_tiles
setblock 477 159 277 minecraft:deepslate_tiles
setblock 479 159 276 minecraft:cobbled_deepslate
fill 480 159 276 483 159 276 minecraft:deepslate_tiles
setblock 483 159 316 minecraft:deepslate_tiles
setblock 484 159 276 minecraft:cobbled_deepslate
setblock 484 159 316 minecraft:cobbled_deepslate
fill 485 159 276 488 159 276 minecraft:deepslate_tiles
fill 485 159 316 488 159 316 minecraft:deepslate_tiles
setblock 487 159 277 minecraft:deepslate_tiles
setblock 488 159 277 minecraft:cobbled_deepslate
fill 488 159 315 489 159 315 minecraft:deepslate_tiles
setblock 489 159 276 minecraft:cobbled_deepslate
fill 489 159 277 489 162 277 minecraft:deepslate_tiles
setblock 489 159 316 minecraft:cobbled_deepslate
fill 490 159 276 493 159 276 minecraft:deepslate_tiles
setblock 490 159 315 minecraft:cobbled_deepslate
fill 490 159 316 493 159 316 minecraft:deepslate_tiles
fill 491 159 315 491 162 315 minecraft:deepslate_tiles
setblock 494 159 276 minecraft:cobbled_deepslate
setblock 494 159 316 minecraft:cobbled_deepslate
setblock 507 159 277 minecraft:deepslate_tiles
setblock 508 159 277 minecraft:cobbled_deepslate
fill 508 159 278 509 161 278 minecraft:deepslate_tiles
setblock 509 159 276 minecraft:cobbled_deepslate
fill 509 159 277 509 162 277 minecraft:deepslate_tiles
fill 509 159 279 509 159 280 minecraft:deepslate_tiles
setblock 509 159 281 minecraft:cobbled_deepslate
fill 509 159 282 509 159 285 minecraft:deepslate_tiles
setblock 509 159 286 minecraft:cobbled_deepslate
fill 509 159 287 511 159 288 minecraft:deepslate_tiles
setblock 509 159 301 minecraft:cobbled_deepslate
fill 509 159 302 509 160 304 minecraft:deepslate_tiles
fill 510 159 276 510 162 276 minecraft:deepslate_tiles
setblock 510 159 280 minecraft:cobbled_deepslate
fill 510 159 281 510 162 281 minecraft:deepslate_tiles
setblock 510 159 285 minecraft:cobbled_deepslate
fill 510 159 286 511 161 286 minecraft:deepslate_tiles
setblock 510 159 289 minecraft:deepslate_tiles
setblock 510 159 290 minecraft:cobbled_deepslate
fill 510 159 291 510 162 291 minecraft:deepslate_tiles
setblock 510 159 295 minecraft:cobbled_deepslate
fill 510 159 296 510 162 296 minecraft:deepslate_tiles
setblock 510 159 300 minecraft:cobbled_deepslate
fill 510 159 301 510 162 301 minecraft:deepslate_tiles
setblock 510 159 305 minecraft:cobbled_deepslate
fill 510 159 306 510 161 307 minecraft:deepslate_tiles
setblock 511 159 279 minecraft:cobbled_deepslate
fill 511 159 280 511 162 280 minecraft:deepslate_tiles
setblock 511 159 284 minecraft:cobbled_deepslate
fill 511 159 285 511 162 285 minecraft:deepslate_tiles
setblock 511 159 289 minecraft:cobbled_deepslate
fill 511 159 290 511 162 290 minecraft:deepslate_tiles
setblock 511 159 294 minecraft:cobbled_deepslate
fill 511 159 295 511 162 295 minecraft:deepslate_tiles
setblock 511 159 299 minecraft:cobbled_deepslate
fill 511 159 300 511 162 300 minecraft:deepslate_tiles
setblock 511 159 304 minecraft:cobbled_deepslate
fill 511 159 305 511 162 305 minecraft:deepslate_tiles
setblock 511 159 309 minecraft:cobbled_deepslate
fill 511 159 310 511 162 310 minecraft:deepslate_tiles
fill 470 160 309 470 201 309 minecraft:black_concrete
fill 471 160 276 471 160 277 minecraft:deepslate_tiles
setblock 471 160 278 minecraft:cobbled_deepslate
fill 471 160 279 471 163 279 minecraft:deepslate_tiles
setblock 471 160 283 minecraft:cobbled_deepslate
fill 471 160 284 471 160 287 minecraft:deepslate_tiles
setblock 471 160 288 minecraft:cobbled_deepslate
fill 471 160 289 472 162 289 minecraft:deepslate_tiles
setblock 471 160 292 minecraft:deepslate_tiles
setblock 471 160 293 minecraft:cobbled_deepslate
fill 471 160 294 471 160 297 minecraft:deepslate_tiles
setblock 471 160 298 minecraft:cobbled_deepslate
fill 471 160 299 471 163 299 minecraft:deepslate_tiles
setblock 471 160 303 minecraft:cobbled_deepslate
fill 471 160 304 471 163 304 minecraft:deepslate_tiles
setblock 471 160 308 minecraft:cobbled_deepslate
fill 471 160 309 471 160 312 minecraft:deepslate_tiles
setblock 471 160 313 minecraft:cobbled_deepslate
fill 471 160 314 471 163 314 minecraft:deepslate_tiles
setblock 472 160 276 minecraft:deepslate_tiles
setblock 472 160 277 minecraft:cobbled_deepslate
fill 472 160 278 472 163 278 minecraft:deepslate_tiles
setblock 472 160 282 minecraft:cobbled_deepslate
fill 472 160 283 472 163 283 minecraft:deepslate_tiles
setblock 472 160 286 minecraft:deepslate_tiles
setblock 472 160 287 minecraft:cobbled_deepslate
fill 472 160 288 472 163 288 minecraft:deepslate_tiles
setblock 472 160 302 minecraft:cobbled_deepslate
fill 472 160 303 472 163 303 minecraft:deepslate_tiles
setblock 472 160 306 minecraft:deepslate_tiles
setblock 472 160 307 minecraft:cobbled_deepslate
fill 472 160 308 472 162 309 minecraft:deepslate_tiles
setblock 472 160 316 minecraft:deepslate_tiles
setblock 473 160 276 minecraft:cobbled_deepslate
fill 473 160 277 473 163 277 minecraft:deepslate_tiles
setblock 473 160 281 minecraft:cobbled_deepslate
fill 473 160 282 473 163 282 minecraft:deepslate_tiles
setblock 473 160 286 minecraft:cobbled_deepslate
fill 473 160 288 473 178 288 minecraft:white_wool
setblock 473 160 316 minecraft:cobbled_deepslate
fill 474 160 276 477 160 276 minecraft:deepslate_tiles
fill 474 160 316 474 163 316 minecraft:deepslate_tiles
fill 474 160 317 474 199 317 minecraft:black_concrete
setblock 477 160 277 minecraft:cobbled_deepslate
setblock 478 160 276 minecraft:cobbled_deepslate
fill 479 160 276 482 160 276 minecraft:deepslate_tiles
setblock 482 160 316 minecraft:deepslate_tiles
setblock 483 160 276 minecraft:cobbled_deepslate
setblock 483 160 316 minecraft:cobbled_deepslate
fill 484 160 276 487 160 276 minecraft:deepslate_tiles
fill 484 160 316 487 160 316 minecraft:deepslate_tiles
setblock 486 160 277 minecraft:deepslate_tiles
fill 486 160 315 488 160 315 minecraft:deepslate_tiles
setblock 487 160 277 minecraft:cobbled_deepslate
setblock 488 160 276 minecraft:cobbled_deepslate
fill 488 160 277 488 162 277 minecraft:deepslate_tiles
setblock 488 160 316 minecraft:cobbled_deepslate
fill 489 160 276 492 160 276 minecraft:deepslate_tiles
setblock 489 160 315 minecraft:cobbled_deepslate
fill 489 160 316 492 160 316 minecraft:deepslate_tiles
fill 490 160 315 490 163 315 minecraft:deepslate_tiles
setblock 493 160 276 minecraft:cobbled_deepslate
setblock 493 160 316 minecraft:cobbled_deepslate
setblock 494 160 316 minecraft:deepslate_tiles
fill 505 160 276 505 162 276 minecraft:deepslate_tiles
setblock 506 160 277 minecraft:deepslate_tiles
setblock 507 160 277 minecraft:cobbled_deepslate
setblock 508 160 276 minecraft:cobbled_deepslate
fill 508 160 277 508 163 277 minecraft:deepslate_tiles
setblock 508 160 280 minecraft:deepslate_tiles
setblock 508 160 281 minecraft:cobbled_deepslate
fill 508 160 282 508 160 285 minecraft:deepslate_tiles
setblock 508 160 286 minecraft:cobbled_deepslate
fill 508 160 314 508 163 314 minecraft:black_concrete
fill 509 160 276 509 163 276 minecraft:deepslate_tiles
setblock 509 160 279 minecraft:deepslate_tiles
setblock 509 160 280 minecraft:cobbled_deepslate
fill 509 160 281 509 160 284 minecraft:deepslate_tiles
setblock 509 160 285 minecraft:cobbled_deepslate
fill 509 160 286 509 160 289 minecraft:deepslate_tiles
setblock 509 160 290 minecraft:cobbled_deepslate
setblock 509 160 300 minecraft:cobbled_deepslate
fill 509 160 301 509 163 301 minecraft:deepslate_tiles
setblock 509 160 305 minecraft:cobbled_deepslate
fill 509 160 313 509 163 313 minecraft:black_concrete
fill 509 160 315 509 163 315 minecraft:black_concrete
setblock 510 160 279 minecraft:cobbled_deepslate
fill 510 160 280 510 163 280 minecraft:deepslate_tiles
setblock 510 160 284 minecraft:cobbled_deepslate
fill 510 160 285 510 163 285 minecraft:deepslate_tiles
fill 510 160 287 510 160 288 minecraft:deepslate_tiles
setblock 510 160 289 minecraft:cobbled_deepslate
fill 510 160 290 510 163 290 minecraft:deepslate_tiles
setblock 510 160 294 minecraft:cobbled_deepslate
fill 510 160 295 510 163 295 minecraft:deepslate_tiles
setblock 510 160 299 minecraft:cobbled_deepslate
fill 510 160 300 510 163 300 minecraft:deepslate_tiles
setblock 510 160 304 minecraft:cobbled_deepslate
fill 510 160 305 510 163 305 minecraft:deepslate_tiles
setblock 510 160 308 minecraft:deepslate_tiles
fill 510 160 314 510 163 314 minecraft:black_concrete
fill 510 160 316 511 161 316 minecraft:deepslate_tiles
setblock 511 160 278 minecraft:cobbled_deepslate
fill 511 160 279 511 163 279 minecraft:deepslate_tiles
setblock 511 160 283 minecraft:cobbled_deepslate
fill 511 160 284 511 163 284 minecraft:deepslate_tiles
setblock 511 160 287 minecraft:deepslate_tiles
setblock 511 160 288 minecraft:cobbled_deepslate
fill 511 160 289 511 163 289 minecraft:deepslate_tiles
setblock 511 160 293 minecraft:cobbled_deepslate
fill 511 160 294 511 163 294 minecraft:deepslate_tiles
setblock 511 160 298 minecraft:cobbled_deepslate
fill 511 160 299 511 163 299 minecraft:deepslate_tiles
setblock 511 160 303 minecraft:cobbled_deepslate
fill 511 160 304 511 163 304 minecraft:deepslate_tiles
setblock 511 160 308 minecraft:cobbled_deepslate
fill 511 160 309 511 163 309 minecraft:deepslate_tiles
fill 511 160 311 511 161 311 minecraft:deepslate_tiles
setblock 471 161 276 minecraft:deepslate_tiles
setblock 471 161 277 minecraft:cobbled_deepslate
fill 471 161 278 471 164 278 minecraft:deepslate_tiles
setblock 471 161 282 minecraft:cobbled_deepslate
fill 471 161 283 471 161 286 minecraft:deepslate_tiles
setblock 471 161 287 minecraft:cobbled_deepslate
fill 471 161 288 471 164 288 minecraft:deepslate_tiles
setblock 471 161 292 minecraft:cobbled_deepslate
fill 471 161 293 471 161 296 minecraft:deepslate_tiles
setblock 471 161 297 minecraft:cobbled_deepslate
fill 471 161 298 471 163 298 minecraft:deepslate_tiles
setblock 471 161 302 minecraft:cobbled_deepslate
fill 471 161 303 471 164 303 minecraft:deepslate_tiles
setblock 471 161 307 minecraft:cobbled_deepslate
fill 471 161 308 471 161 311 minecraft:deepslate_tiles
setblock 471 161 312 minecraft:cobbled_deepslate
fill 471 161 313 471 164 313 minecraft:deepslate_tiles
setblock 472 161 276 minecraft:cobbled_deepslate
fill 472 161 277 472 164 277 minecraft:deepslate_tiles
setblock 472 161 281 minecraft:cobbled_deepslate
fill 472 161 282 472 164 282 minecraft:deepslate_tiles
setblock 472 161 285 minecraft:deepslate_tiles
setblock 472 161 286 minecraft:cobbled_deepslate
fill 472 161 287 472 164 287 minecraft:deepslate_tiles
setblock 472 161 301 minecraft:cobbled_deepslate
fill 472 161 302 472 163 302 minecraft:deepslate_tiles
setblock 472 161 306 minecraft:cobbled_deepslate
fill 472 161 307 472 164 307 minecraft:deepslate_tiles
setblock 472 161 310 minecraft:deepslate_tiles
setblock 472 161 311 minecraft:cobbled_deepslate
setblock 472 161 315 minecraft:deepslate_tiles
setblock 472 161 316 minecraft:cobbled_deepslate
fill 473 161 276 476 161 276 minecraft:deepslate_tiles
setblock 473 161 280 minecraft:cobbled_deepslate
fill 473 161 281 473 163 281 minecraft:deepslate_tiles
setblock 473 161 285 minecraft:cobbled_deepslate
fill 473 161 286 473 163 286 minecraft:deepslate_tiles
fill 473 161 316 473 164 316 minecraft:deepslate_tiles
setblock 476 161 277 minecraft:cobbled_deepslate
setblock 476 161 316 minecraft:deepslate_tiles
setblock 477 161 276 minecraft:cobbled_deepslate
setblock 477 161 316 minecraft:cobbled_deepslate
fill 478 161 276 481 161 276 minecraft:deepslate_tiles
setblock 481 161 316 minecraft:deepslate_tiles
setblock 482 161 276 minecraft:cobbled_deepslate
setblock 482 161 316 minecraft:cobbled_deepslate
fill 483 161 276 486 161 276 minecraft:deepslate_tiles
fill 483 161 316 486 161 316 minecraft:deepslate_tiles
fill 485 161 315 487 161 315 minecraft:deepslate_tiles
setblock 486 161 277 minecraft:cobbled_deepslate
setblock 487 161 276 minecraft:cobbled_deepslate
fill 487 161 277 487 162 277 minecraft:deepslate_tiles
setblock 487 161 316 minecraft:cobbled_deepslate
fill 488 161 276 491 161 276 minecraft:deepslate_tiles
setblock 488 161 315 minecraft:cobbled_deepslate
fill 488 161 316 491 161 316 minecraft:deepslate_tiles
fill 489 161 315 489 164 315 minecraft:deepslate_tiles
setblock 489 161 317 minecraft:white_wool
setblock 492 161 276 minecraft:cobbled_deepslate
setblock 492 161 316 minecraft:cobbled_deepslate
setblock 493 161 276 minecraft:deepslate_tiles
fill 493 161 316 493 162 316 minecraft:deepslate_tiles
setblock 506 161 277 minecraft:cobbled_deepslate
setblock 507 161 276 minecraft:cobbled_deepslate
fill 507 161 277 507 163 278 minecraft:deepslate_tiles
fill 508 161 276 508 164 276 minecraft:deepslate_tiles
setblock 508 161 280 minecraft:cobbled_deepslate
fill 508 161 281 508 161 284 minecraft:deepslate_tiles
setblock 508 161 285 minecraft:cobbled_deepslate
fill 508 161 286 509 161 288 minecraft:deepslate_tiles
setblock 509 161 279 minecraft:cobbled_deepslate
fill 509 161 280 509 161 283 minecraft:deepslate_tiles
setblock 509 161 284 minecraft:cobbled_deepslate
fill 509 161 285 509 164 285 minecraft:deepslate_tiles
setblock 509 161 289 minecraft:cobbled_deepslate
fill 509 161 290 509 163 291 minecraft:deepslate_tiles
setblock 509 161 299 minecraft:cobbled_deepslate
fill 509 161 300 509 162 300 minecraft:deepslate_tiles
fill 509 161 302 509 161 303 minecraft:deepslate_tiles
setblock 509 161 304 minecraft:cobbled_deepslate
fill 509 161 305 509 163 306 minecraft:deepslate_tiles
fill 509 161 316 509 163 316 minecraft:deepslate_tiles
setblock 510 161 278 minecraft:cobbled_deepslate
fill 510 161 279 510 164 279 minecraft:deepslate_tiles
setblock 510 161 283 minecraft:cobbled_deepslate
fill 510 161 284 510 164 284 minecraft:deepslate_tiles
setblock 510 161 287 minecraft:deepslate_tiles
setblock 510 161 288 minecraft:cobbled_deepslate
fill 510 161 289 510 164 289 minecraft:deepslate_tiles
setblock 510 161 293 minecraft:cobbled_deepslate
fill 510 161 294 510 164 294 minecraft:deepslate_tiles
setblock 510 161 298 minecraft:cobbled_deepslate
fill 510 161 299 510 163 299 minecraft:deepslate_tiles
setblock 510 161 303 minecraft:cobbled_deepslate
fill 510 161 304 510 164 304 minecraft:deepslate_tiles
setblock 510 161 308 minecraft:cobbled_deepslate
fill 510 161 309 510 164 309 minecraft:deepslate_tiles
setblock 511 161 277 minecraft:cobbled_deepslate
fill 511 161 278 511 164 278 minecraft:deepslate_tiles
setblock 511 161 282 minecraft:cobbled_deepslate
fill 511 161 283 511 164 283 minecraft:deepslate_tiles
setblock 511 161 287 minecraft:cobbled_deepslate
fill 511 161 288 511 164 288 minecraft:deepslate_tiles
setblock 511 161 292 minecraft:cobbled_deepslate
fill 511 161 293 511 164 293 minecraft:deepslate_tiles
setblock 511 161 297 minecraft:cobbled_deepslate
fill 511 161 298 511 164 298 minecraft:deepslate_tiles
setblock 511 161 302 minecraft:cobbled_deepslate
fill 511 161 303 511 164 303 minecraft:deepslate_tiles
setblock 511 161 307 minecraft:cobbled_deepslate
fill 511 161 308 511 164 308 minecraft:deepslate_tiles
setblock 511 161 312 minecraft:cobbled_deepslate
fill 511 161 313 511 162 315 minecraft:deepslate_tiles
setblock 471 162 276 minecraft:cobbled_deepslate
fill 471 162 277 471 165 277 minecraft:deepslate_tiles
setblock 471 162 281 minecraft:cobbled_deepslate
fill 471 162 282 471 162 285 minecraft:deepslate_tiles
setblock 471 162 286 minecraft:cobbled_deepslate
fill 471 162 287 471 165 287 minecraft:deepslate_tiles
setblock 471 162 291 minecraft:cobbled_deepslate
fill 471 162 292 471 162 295 minecraft:deepslate_tiles
setblock 471 162 296 minecraft:cobbled_deepslate
setblock 471 162 297 minecraft:deepslate_tiles
setblock 471 162 301 minecraft:cobbled_deepslate
fill 471 162 302 471 165 302 minecraft:deepslate_tiles
setblock 471 162 306 minecraft:cobbled_deepslate
fill 471 162 307 471 162 310 minecraft:deepslate_tiles
setblock 471 162 311 minecraft:cobbled_deepslate
fill 471 162 312 472 164 312 minecraft:deepslate_tiles
setblock 471 162 315 minecraft:deepslate_tiles
setblock 471 162 316 minecraft:cobbled_deepslate
fill 472 162 276 475 162 276 minecraft:deepslate_tiles
setblock 472 162 280 minecraft:cobbled_deepslate
fill 472 162 281 472 165 281 minecraft:deepslate_tiles
setblock 472 162 285 minecraft:cobbled_deepslate
fill 472 162 286 472 165 286 minecraft:deepslate_tiles
setblock 472 162 301 minecraft:deepslate_tiles
setblock 472 162 305 minecraft:cobbled_deepslate
fill 472 162 306 472 165 306 minecraft:deepslate_tiles
setblock 472 162 310 minecraft:cobbled_deepslate
fill 472 162 311 472 165 311 minecraft:deepslate_tiles
fill 472 162 313 472 162 314 minecraft:deepslate_tiles
setblock 472 162 315 minecraft:cobbled_deepslate
fill 472 162 316 472 165 316 minecraft:deepslate_tiles
setblock 473 162 279 minecraft:cobbled_deepslate
fill 473 162 280 473 163 280 minecraft:deepslate_tiles
setblock 473 162 284 minecraft:cobbled_deepslate
fill 473 162 285 473 164 285 minecraft:deepslate_tiles
setblock 475 162 277 minecraft:cobbled_deepslate
setblock 476 162 276 minecraft:cobbled_deepslate
setblock 476 162 316 minecraft:cobbled_deepslate
fill 477 162 276 479 162 276 minecraft:deepslate_tiles
fill 477 162 316 480 162 316 minecraft:deepslate_tiles
setblock 481 162 276 minecraft:cobbled_deepslate
setblock 481 162 316 minecraft:cobbled_deepslate
fill 482 162 276 485 162 276 minecraft:deepslate_tiles
fill 482 162 316 485 162 316 minecraft:deepslate_tiles
fill 484 162 315 486 162 315 minecraft:deepslate_tiles
setblock 486 162 276 minecraft:cobbled_deepslate
setblock 486 162 277 minecraft:deepslate_tiles
setblock 486 162 316 minecraft:cobbled_deepslate
fill 487 162 276 490 162 276 minecraft:deepslate_tiles
setblock 487 162 315 minecraft:cobbled_deepslate
fill 487 162 316 490 162 316 minecraft:deepslate_tiles
fill 488 162 315 488 165 315 minecraft:deepslate_tiles
fill 489 162 317 489 201 317 minecraft:black_concrete
setblock 491 162 276 minecraft:cobbled_deepslate
setblock 491 162 316 minecraft:cobbled_deepslate
setblock 492 162 276 minecraft:deepslate_tiles
fill 492 162 316 492 164 316 minecraft:deepslate_tiles
fill 504 162 276 504 163 276 minecraft:deepslate_tiles
setblock 506 162 276 minecraft:cobbled_deepslate
fill 506 162 277 506 165 277 minecraft:deepslate_tiles
fill 507 162 276 507 165 276 minecraft:deepslate_tiles
setblock 508 162 278 minecraft:deepslate_tiles
fill 508 162 280 508 162 283 minecraft:deepslate_tiles
setblock 508 162 284 minecraft:cobbled_deepslate
fill 508 162 285 508 162 288 minecraft:deepslate_tiles
setblock 508 162 289 minecraft:cobbled_deepslate
fill 508 162 313 508 163 313 minecraft:black_concrete
fill 508 162 315 508 163 315 minecraft:black_concrete
fill 508 162 316 508 164 316 minecraft:deepslate_tiles
setblock 509 162 278 minecraft:cobbled_deepslate
fill 509 162 279 509 162 282 minecraft:deepslate_tiles
setblock 509 162 283 minecraft:cobbled_deepslate
fill 509 162 284 509 165 284 minecraft:deepslate_tiles
fill 509 162 286 509 162 287 minecraft:deepslate_tiles
setblock 509 162 288 minecraft:cobbled_deepslate
fill 509 162 289 509 165 289 minecraft:deepslate_tiles
setblock 509 162 292 minecraft:deepslate_tiles
setblock 509 162 302 minecraft:deepslate_tiles
setblock 509 162 303 minecraft:cobbled_deepslate
fill 509 162 304 509 164 304 minecraft:deepslate_tiles
setblock 509 162 307 minecraft:deepslate_tiles
setblock 510 162 277 minecraft:cobbled_deepslate
fill 510 162 278 510 165 278 minecraft:deepslate_tiles
setblock 510 162 282 minecraft:cobbled_deepslate
fill 510 162 283 510 165 283 minecraft:deepslate_tiles
setblock 510 162 286 minecraft:deepslate_tiles
setblock 510 162 287 minecraft:cobbled_deepslate
fill 510 162 288 510 165 288 minecraft:deepslate_tiles
setblock 510 162 292 minecraft:cobbled_deepslate
fill 510 162 293 510 165 293 minecraft:deepslate_tiles
setblock 510 162 297 minecraft:cobbled_deepslate
fill 510 162 298 510 163 298 minecraft:deepslate_tiles
setblock 510 162 302 minecraft:cobbled_deepslate
fill 510 162 303 510 165 303 minecraft:deepslate_tiles
setblock 510 162 306 minecraft:deepslate_tiles
setblock 510 162 307 minecraft:cobbled_deepslate
fill 510 162 308 510 165 308 minecraft:deepslate_tiles
fill 510 162 310 510 163 310 minecraft:deepslate_tiles
fill 510 162 313 510 163 313 minecraft:black_concrete
fill 510 162 315 510 163 315 minecraft:black_concrete
setblock 510 162 316 minecraft:deepslate_tiles
setblock 511 162 276 minecraft:cobbled_deepslate
fill 511 162 277 511 165 277 minecraft:deepslate_tiles
setblock 511 162 281 minecraft:cobbled_deepslate
fill 511 162 282 511 165 282 minecraft:deepslate_tiles
setblock 511 162 286 minecraft:cobbled_deepslate
fill 511 162 287 511 165 287 minecraft:deepslate_tiles
setblock 511 162 291 minecraft:cobbled_deepslate
fill 511 162 292 511 165 292 minecraft:deepslate_tiles
setblock 511 162 296 minecraft:cobbled_deepslate
fill 511 162 297 511 165 297 minecraft:deepslate_tiles
setblock 511 162 301 minecraft:cobbled_deepslate
fill 511 162 302 511 165 302 minecraft:deepslate_tiles
setblock 511 162 306 minecraft:cobbled_deepslate
fill 511 162 307 511 165 307 minecraft:deepslate_tiles
setblock 511 162 311 minecraft:cobbled_deepslate
fill 511 162 312 511 165 312 minecraft:deepslate_tiles
setblock 511 162 316 minecraft:cobbled_deepslate
setblock 512 162 299 minecraft:white_wool
fill 471 163 276 474 163 276 minecraft:deepslate_tiles
setblock 471 163 280 minecraft:cobbled_deepslate
fill 471 163 281 471 163 284 minecraft:deepslate_tiles
setblock 471 163 285 minecraft:cobbled_deepslate
fill 471 163 286 471 166 286 minecraft:deepslate_tiles
setblock 471 163 289 minecraft:deepslate_tiles
setblock 471 163 290 minecraft:cobbled_deepslate
fill 471 163 291 471 164 293 minecraft:deepslate_tiles
setblock 471 163 300 minecraft:cobbled_deepslate
fill 471 163 301 471 165 301 minecraft:deepslate_tiles
setblock 471 163 305 minecraft:cobbled_deepslate
fill 471 163 306 471 163 309 minecraft:deepslate_tiles
setblock 471 163 310 minecraft:cobbled_deepslate
fill 471 163 311 471 166 311 minecraft:deepslate_tiles
setblock 471 163 315 minecraft:cobbled_deepslate
fill 471 163 316 471 166 316 minecraft:deepslate_tiles
setblock 472 163 279 minecraft:cobbled_deepslate
fill 472 163 280 472 165 280 minecraft:deepslate_tiles
setblock 472 163 284 minecraft:cobbled_deepslate
fill 472 163 285 472 166 285 minecraft:deepslate_tiles
setblock 472 163 289 minecraft:cobbled_deepslate
setblock 472 163 304 minecraft:cobbled_deepslate
fill 472 163 305 472 165 305 minecraft:deepslate_tiles
setblock 472 163 308 minecraft:deepslate_tiles
setblock 472 163 309 minecraft:cobbled_deepslate
fill 472 163 310 472 166 310 minecraft:deepslate_tiles
setblock 472 163 313 minecraft:deepslate_tiles
setblock 472 163 314 minecraft:cobbled_deepslate
fill 472 163 315 472 164 315 minecraft:deepslate_tiles
setblock 473 163 278 minecraft:light[level=12]
setblock 473 163 279 minecraft:deepslate_tiles
setblock 473 163 283 minecraft:cobbled_deepslate
fill 473 163 284 473 164 284 minecraft:deepslate_tiles
setblock 473 163 292 minecraft:light[level=12]
setblock 473 163 299 minecraft:light[level=12]
setblock 473 163 306 minecraft:light[level=12]
setblock 473 163 313 minecraft:light[level=12]
setblock 474 163 277 minecraft:cobbled_deepslate
setblock 475 163 276 minecraft:cobbled_deepslate
setblock 475 163 316 minecraft:cobbled_deepslate
fill 476 163 276 477 163 276 minecraft:deepslate_tiles
fill 476 163 316 479 163 316 minecraft:deepslate_tiles
setblock 480 163 278 minecraft:light[level=12]
setblock 480 163 285 minecraft:light[level=12]
setblock 480 163 292 minecraft:light[level=12]
setblock 480 163 299 minecraft:light[level=12]
setblock 480 163 306 minecraft:light[level=12]
setblock 480 163 313 minecraft:light[level=12]
setblock 480 163 316 minecraft:cobbled_deepslate
fill 481 163 316 484 163 316 minecraft:deepslate_tiles
fill 482 163 276 484 163 276 minecraft:deepslate_tiles
fill 483 163 315 485 163 315 minecraft:deepslate_tiles
setblock 485 163 276 minecraft:cobbled_deepslate
setblock 485 163 316 minecraft:cobbled_deepslate
fill 486 163 276 489 163 276 minecraft:deepslate_tiles
setblock 486 163 314 minecraft:deepslate_tiles
setblock 486 163 315 minecraft:cobbled_deepslate
fill 486 163 316 489 163 316 minecraft:deepslate_tiles
setblock 487 163 278 minecraft:light[level=12]
setblock 487 163 285 minecraft:light[level=12]
setblock 487 163 292 minecraft:light[level=12]
setblock 487 163 299 minecraft:light[level=12]
setblock 487 163 306 minecraft:light[level=12]
setblock 487 163 313 minecraft:light[level=12]
setblock 487 163 314 minecraft:cobbled_deepslate
fill 487 163 315 487 166 315 minecraft:deepslate_tiles
fill 488 163 314 488 165 314 minecraft:deepslate_tiles
setblock 490 163 276 minecraft:cobbled_deepslate
setblock 490 163 316 minecraft:cobbled_deepslate
setblock 491 163 276 minecraft:deepslate_tiles
setblock 491 163 315 minecraft:cobbled_deepslate
fill 491 163 316 491 165 316 minecraft:deepslate_tiles
setblock 494 163 278 minecraft:light[level=12]
setblock 494 163 285 minecraft:light[level=12]
setblock 494 163 292 minecraft:light[level=12]
setblock 494 163 299 minecraft:light[level=12]
setblock 494 163 306 minecraft:light[level=12]
setblock 494 163 313 minecraft:light[level=12]
setblock 501 163 278 minecraft:light[level=12]
setblock 501 163 285 minecraft:light[level=12]
setblock 501 163 292 minecraft:light[level=12]
setblock 501 163 299 minecraft:light[level=12]
setblock 501 163 306 minecraft:light[level=12]
setblock 501 163 313 minecraft:light[level=12]
setblock 505 163 276 minecraft:cobbled_deepslate
fill 505 163 277 505 164 277 minecraft:deepslate_tiles
fill 506 163 276 506 166 276 minecraft:deepslate_tiles
setblock 507 163 283 minecraft:deepslate_tiles
setblock 507 163 284 minecraft:cobbled_deepslate
fill 507 163 285 508 164 286 minecraft:deepslate_tiles
fill 507 163 316 507 165 316 minecraft:deepslate_tiles
setblock 508 163 275 minecraft:white_wool
setblock 508 163 278 minecraft:cobbled_deepslate
fill 508 163 280 508 163 282 minecraft:deepslate_tiles
setblock 508 163 283 minecraft:cobbled_deepslate
fill 508 163 284 508 166 284 minecraft:deepslate_tiles
setblock 508 163 287 minecraft:deepslate_tiles
setblock 508 163 288 minecraft:cobbled_deepslate
fill 508 163 289 508 165 290 minecraft:deepslate_tiles
setblock 508 163 292 minecraft:light[level=12]
setblock 508 163 299 minecraft:light[level=12]
setblock 508 163 306 minecraft:light[level=12]
setblock 509 163 277 minecraft:cobbled_deepslate
fill 509 163 278 509 163 281 minecraft:deepslate_tiles
setblock 509 163 282 minecraft:cobbled_deepslate
fill 509 163 283 509 166 283 minecraft:deepslate_tiles
setblock 509 163 286 minecraft:deepslate_tiles
setblock 509 163 287 minecraft:cobbled_deepslate
fill 509 163 288 509 166 288 minecraft:deepslate_tiles
setblock 509 163 292 minecraft:cobbled_deepslate
setblock 509 163 302 minecraft:cobbled_deepslate
setblock 509 163 303 minecraft:deepslate_tiles
setblock 509 163 307 minecraft:cobbled_deepslate
fill 509 163 308 509 164 308 minecraft:deepslate_tiles
setblock 510 163 276 minecraft:cobbled_deepslate
fill 510 163 277 510 166 277 minecraft:deepslate_tiles
setblock 510 163 281 minecraft:cobbled_deepslate
fill 510 163 282 510 166 282 minecraft:deepslate_tiles
setblock 510 163 286 minecraft:cobbled_deepslate
fill 510 163 287 510 166 287 minecraft:deepslate_tiles
setblock 510 163 291 minecraft:cobbled_deepslate
fill 510 163 292 510 166 292 minecraft:deepslate_tiles
setblock 510 163 296 minecraft:cobbled_deepslate
setblock 510 163 297 minecraft:deepslate_tiles
setblock 510 163 301 minecraft:cobbled_deepslate
fill 510 163 302 510 164 302 minecraft:deepslate_tiles
setblock 510 163 306 minecraft:cobbled_deepslate
fill 510 163 307 510 166 307 minecraft:deepslate_tiles
setblock 510 163 311 minecraft:cobbled_deepslate
setblock 510 163 316 minecraft:cobbled_deepslate
fill 511 163 276 511 166 276 minecraft:deepslate_tiles
setblock 511 163 280 minecraft:cobbled_deepslate
fill 511 163 281 511 166 281 minecraft:deepslate_tiles
setblock 511 163 285 minecraft:cobbled_deepslate
fill 511 163 286 511 166 286 minecraft:deepslate_tiles
setblock 511 163 290 minecraft:cobbled_deepslate
fill 511 163 291 511 166 291 minecraft:deepslate_tiles
setblock 511 163 295 minecraft:cobbled_deepslate
fill 511 163 296 511 165 296 minecraft:deepslate_tiles
setblock 511 163 300 minecraft:cobbled_deepslate
fill 511 163 301 511 165 301 minecraft:deepslate_tiles
setblock 511 163 305 minecraft:cobbled_deepslate
fill 511 163 306 511 166 306 minecraft:deepslate_tiles
setblock 511 163 310 minecraft:cobbled_deepslate
fill 511 163 311 511 166 311 minecraft:deepslate_tiles
fill 511 163 313 511 163 314 minecraft:deepslate_tiles
setblock 511 163 315 minecraft:cobbled_deepslate
fill 511 163 316 511 165 316 minecraft:deepslate_tiles
fill 512 163 299 512 187 299 minecraft:black_concrete
fill 471 164 276 473 164 276 minecraft:deepslate_tiles
setblock 471 164 279 minecraft:cobbled_deepslate
fill 471 164 280 471 164 283 minecraft:deepslate_tiles
setblock 471 164 284 minecraft:cobbled_deepslate
fill 471 164 285 471 167 285 minecraft:deepslate_tiles
setblock 471 164 289 minecraft:cobbled_deepslate
fill 471 164 290 471 167 290 minecraft:deepslate_tiles
setblock 471 164 300 minecraft:deepslate_tiles
setblock 471 164 304 minecraft:cobbled_deepslate
fill 471 164 305 471 164 308 minecraft:deepslate_tiles
setblock 471 164 309 minecraft:cobbled_deepslate
fill 471 164 310 471 167 310 minecraft:deepslate_tiles
setblock 471 164 314 minecraft:cobbled_deepslate
fill 471 164 315 471 167 315 minecraft:deepslate_tiles
setblock 472 164 278 minecraft:cobbled_deepslate
fill 472 164 279 472 165 279 minecraft:deepslate_tiles
setblock 472 164 283 minecraft:cobbled_deepslate
fill 472 164 284 472 166 284 minecraft:deepslate_tiles
setblock 472 164 288 minecraft:cobbled_deepslate
setblock 472 164 289 minecraft:deepslate_tiles
setblock 472 164 303 minecraft:cobbled_deepslate
setblock 472 164 304 minecraft:deepslate_tiles
setblock 472 164 308 minecraft:cobbled_deepslate
fill 472 164 309 472 167 309 minecraft:deepslate_tiles
setblock 472 164 313 minecraft:cobbled_deepslate
fill 472 164 314 472 166 314 minecraft:deepslate_tiles
setblock 473 164 277 minecraft:cobbled_deepslate
setblock 473 164 282 minecraft:cobbled_deepslate
setblock 473 164 283 minecraft:deepslate_tiles
setblock 474 164 276 minecraft:cobbled_deepslate
setblock 474 164 316 minecraft:cobbled_deepslate
setblock 475 164 276 minecraft:deepslate_tiles
fill 475 164 316 478 164 316 minecraft:deepslate_tiles
setblock 479 164 316 minecraft:cobbled_deepslate
fill 480 164 316 483 164 316 minecraft:deepslate_tiles
setblock 483 164 276 minecraft:deepslate_tiles
fill 483 164 315 484 164 315 minecraft:deepslate_tiles
setblock 484 164 276 minecraft:cobbled_deepslate
setblock 484 164 316 minecraft:cobbled_deepslate
fill 485 164 276 488 164 276 minecraft:deepslate_tiles
setblock 485 164 314 minecraft:deepslate_tiles
setblock 485 164 315 minecraft:cobbled_deepslate
fill 485 164 316 488 164 316 minecraft:deepslate_tiles
setblock 486 164 314 minecraft:cobbled_deepslate
fill 486 164 315 486 167 315 minecraft:deepslate_tiles
fill 487 164 314 487 166 314 minecraft:deepslate_tiles
setblock 489 164 276 minecraft:cobbled_deepslate
setblock 489 164 316 minecraft:cobbled_deepslate
setblock 490 164 276 minecraft:deepslate_tiles
setblock 490 164 315 minecraft:cobbled_deepslate
fill 490 164 316 490 166 316 minecraft:deepslate_tiles
fill 493 164 310 493 176 310 minecraft:white_wool
setblock 495 164 317 minecraft:white_wool
setblock 504 164 276 minecraft:cobbled_deepslate
fill 505 164 276 505 167 276 minecraft:deepslate_tiles
setblock 507 164 277 minecraft:deepslate_tiles
setblock 507 164 278 minecraft:cobbled_deepslate
setblock 507 164 283 minecraft:cobbled_deepslate
fill 507 164 284 507 165 284 minecraft:deepslate_tiles
setblock 507 164 287 minecraft:deepslate_tiles
fill 508 164 275 508 202 275 minecraft:black_concrete
setblock 508 164 277 minecraft:cobbled_deepslate
fill 508 164 278 509 165 278 minecraft:deepslate_tiles
fill 508 164 280 508 164 281 minecraft:deepslate_tiles
setblock 508 164 282 minecraft:cobbled_deepslate
fill 508 164 283 508 166 283 minecraft:deepslate_tiles
setblock 508 164 287 minecraft:cobbled_deepslate
fill 508 164 288 508 167 288 minecraft:deepslate_tiles
setblock 509 164 276 minecraft:cobbled_deepslate
fill 509 164 277 509 166 277 minecraft:deepslate_tiles
fill 509 164 279 509 164 280 minecraft:deepslate_tiles
setblock 509 164 281 minecraft:cobbled_deepslate
fill 509 164 282 509 167 282 minecraft:deepslate_tiles
setblock 509 164 286 minecraft:cobbled_deepslate
fill 509 164 287 509 167 287 minecraft:deepslate_tiles
setblock 509 164 290 minecraft:deepslate_tiles
setblock 509 164 291 minecraft:cobbled_deepslate
fill 509 164 292 509 165 292 minecraft:deepslate_tiles
setblock 509 164 305 minecraft:deepslate_tiles
setblock 509 164 306 minecraft:cobbled_deepslate
setblock 509 164 307 minecraft:deepslate_tiles
setblock 509 164 316 minecraft:cobbled_deepslate
fill 510 164 276 510 167 276 minecraft:deepslate_tiles
setblock 510 164 280 minecraft:cobbled_deepslate
fill 510 164 281 510 167 281 minecraft:deepslate_tiles
setblock 510 164 285 minecraft:cobbled_deepslate
fill 510 164 286 510 167 286 minecraft:deepslate_tiles
setblock 510 164 290 minecraft:cobbled_deepslate
fill 510 164 291 510 167 291 minecraft:deepslate_tiles
setblock 510 164 295 minecraft:cobbled_deepslate
setblock 510 164 300 minecraft:cobbled_deepslate
setblock 510 164 301 minecraft:deepslate_tiles
setblock 510 164 305 minecraft:cobbled_deepslate
fill 510 164 306 510 166 306 minecraft:deepslate_tiles
setblock 510 164 310 minecraft:cobbled_deepslate
fill 510 164 311 510 166 311 minecraft:deepslate_tiles
fill 510 164 316 510 167 316 minecraft:deepslate_tiles
setblock 511 164 279 minecraft:cobbled_deepslate
fill 511 164 280 511 167 280 minecraft:deepslate_tiles
setblock 511 164 284 minecraft:cobbled_deepslate
fill 511 164 285 511 167 285 minecraft:deepslate_tiles
setblock 511 164 289 minecraft:cobbled_deepslate
fill 511 164 290 511 167 290 minecraft:deepslate_tiles
setblock 511 164 294 minecraft:cobbled_deepslate
fill 511 164 295 511 165 295 minecraft:deepslate_tiles
setblock 511 164 299 minecraft:cobbled_deepslate
fill 511 164 300 511 165 300 minecraft:deepslate_tiles
setblock 511 164 304 minecraft:cobbled_deepslate
fill 511 164 305 511 167 305 minecraft:deepslate_tiles
setblock 511 164 309 minecraft:cobbled_deepslate
fill 511 164 310 511 167 310 minecraft:deepslate_tiles
setblock 511 164 313 minecraft:deepslate_tiles
setblock 511 164 314 minecraft:cobbled_deepslate
fill 511 164 315 511 166 315 minecraft:deepslate_tiles
fill 471 165 276 472 165 276 minecraft:deepslate_tiles
setblock 471 165 278 minecraft:cobbled_deepslate
fill 471 165 279 471 165 282 minecraft:deepslate_tiles
setblock 471 165 283 minecraft:cobbled_deepslate
fill 471 165 284 471 168 284 minecraft:deepslate_tiles
setblock 471 165 288 minecraft:cobbled_deepslate
fill 471 165 289 471 168 289 minecraft:deepslate_tiles
fill 471 165 291 471 165 292 minecraft:deepslate_tiles
setblock 471 165 303 minecraft:cobbled_deepslate
fill 471 165 304 471 165 307 minecraft:deepslate_tiles
setblock 471 165 308 minecraft:cobbled_deepslate
fill 471 165 309 471 168 309 minecraft:deepslate_tiles
setblock 471 165 312 minecraft:deepslate_tiles
setblock 471 165 313 minecraft:cobbled_deepslate
fill 471 165 314 471 168 314 minecraft:deepslate_tiles
setblock 472 165 277 minecraft:cobbled_deepslate
setblock 472 165 278 minecraft:deepslate_tiles
setblock 472 165 282 minecraft:cobbled_deepslate
fill 472 165 283 472 166 283 minecraft:deepslate_tiles
setblock 472 165 287 minecraft:cobbled_deepslate
setblock 472 165 288 minecraft:deepslate_tiles
setblock 472 165 307 minecraft:cobbled_deepslate
fill 472 165 308 472 167 308 minecraft:deepslate_tiles
setblock 472 165 312 minecraft:cobbled_deepslate
fill 472 165 313 472 168 313 minecraft:deepslate_tiles
setblock 473 165 276 minecraft:cobbled_deepslate
setblock 473 165 278 minecraft:light[level=13]
setblock 473 165 286 minecraft:light[level=13]
setblock 473 165 294 minecraft:light[level=13]
setblock 473 165 302 minecraft:light[level=13]
setblock 473 165 310 minecraft:light[level=13]
setblock 473 165 316 minecraft:cobbled_deepslate
setblock 474 165 276 minecraft:deepslate_tiles
fill 474 165 316 476 165 316 minecraft:deepslate_tiles
setblock 478 165 316 minecraft:cobbled_deepslate
fill 479 165 316 482 165 316 minecraft:deepslate_tiles
setblock 481 165 278 minecraft:light[level=13]
setblock 481 165 286 minecraft:light[level=13]
setblock 481 165 294 minecraft:light[level=13]
setblock 481 165 302 minecraft:light[level=13]
setblock 481 165 310 minecraft:light[level=13]
fill 482 165 315 483 165 315 minecraft:deepslate_tiles
setblock 483 165 316 minecraft:cobbled_deepslate
fill 484 165 276 487 165 276 minecraft:deepslate_tiles
setblock 484 165 315 minecraft:cobbled_deepslate
fill 484 165 316 487 165 316 minecraft:deepslate_tiles
setblock 485 165 314 minecraft:cobbled_deepslate
fill 485 165 315 485 168 315 minecraft:deepslate_tiles
fill 486 165 314 486 168 314 minecraft:deepslate_tiles
setblock 488 165 276 minecraft:cobbled_deepslate
setblock 488 165 316 minecraft:cobbled_deepslate
setblock 489 165 278 minecraft:light[level=13]
setblock 489 165 286 minecraft:light[level=13]
setblock 489 165 294 minecraft:light[level=13]
setblock 489 165 302 minecraft:light[level=13]
setblock 489 165 310 minecraft:light[level=13]
setblock 489 165 315 minecraft:cobbled_deepslate
fill 489 165 316 489 168 316 minecraft:deepslate_tiles
fill 495 165 317 495 202 317 minecraft:black_concrete
setblock 497 165 278 minecraft:light[level=13]
setblock 497 165 286 minecraft:light[level=13]
setblock 497 165 294 minecraft:light[level=13]
setblock 497 165 302 minecraft:light[level=13]
setblock 497 165 310 minecraft:light[level=13]
fill 504 165 276 504 168 276 minecraft:deepslate_tiles
fill 504 165 317 504 197 317 minecraft:black_concrete
setblock 505 165 278 minecraft:light[level=13]
setblock 505 165 286 minecraft:light[level=13]
setblock 505 165 294 minecraft:light[level=13]
setblock 505 165 302 minecraft:light[level=13]
setblock 505 165 310 minecraft:light[level=13]
setblock 505 165 317 minecraft:redstone_block
fill 506 165 316 506 166 316 minecraft:deepslate_tiles
setblock 507 165 277 minecraft:cobbled_deepslate
fill 507 165 285 507 165 286 minecraft:deepslate_tiles
setblock 507 165 287 minecraft:cobbled_deepslate
setblock 508 165 276 minecraft:cobbled_deepslate
fill 508 165 277 508 167 277 minecraft:deepslate_tiles
setblock 508 165 281 minecraft:cobbled_deepslate
fill 508 165 282 508 166 282 minecraft:deepslate_tiles
setblock 508 165 285 minecraft:deepslate_tiles
setblock 508 165 286 minecraft:cobbled_deepslate
fill 508 165 287 508 168 287 minecraft:deepslate_tiles
setblock 508 165 316 minecraft:cobbled_deepslate
fill 509 165 276 509 168 276 minecraft:deepslate_tiles
setblock 509 165 279 minecraft:deepslate_tiles
setblock 509 165 280 minecraft:cobbled_deepslate
fill 509 165 281 509 167 281 minecraft:deepslate_tiles
setblock 509 165 285 minecraft:cobbled_deepslate
fill 509 165 286 509 168 286 minecraft:deepslate_tiles
setblock 509 165 290 minecraft:cobbled_deepslate
fill 509 165 291 509 167 291 minecraft:deepslate_tiles
fill 509 165 307 509 175 307 minecraft:white_wool
fill 509 165 316 509 168 316 minecraft:deepslate_tiles
setblock 510 165 279 minecraft:cobbled_deepslate
fill 510 165 280 510 167 280 minecraft:deepslate_tiles
setblock 510 165 284 minecraft:cobbled_deepslate
fill 510 165 285 510 168 285 minecraft:deepslate_tiles
setblock 510 165 289 minecraft:cobbled_deepslate
fill 510 165 290 510 168 290 minecraft:deepslate_tiles
setblock 510 165 294 minecraft:cobbled_deepslate
setblock 510 165 304 minecraft:cobbled_deepslate
fill 510 165 305 510 166 305 minecraft:deepslate_tiles
setblock 510 165 309 minecraft:cobbled_deepslate
fill 510 165 310 510 166 310 minecraft:deepslate_tiles
setblock 511 165 278 minecraft:cobbled_deepslate
fill 511 165 279 511 168 279 minecraft:deepslate_tiles
setblock 511 165 283 minecraft:cobbled_deepslate
fill 511 165 284 511 168 284 minecraft:deepslate_tiles
setblock 511 165 288 minecraft:cobbled_deepslate
fill 511 165 289 511 168 289 minecraft:deepslate_tiles
setblock 511 165 293 minecraft:cobbled_deepslate
fill 511 165 294 511 166 294 minecraft:deepslate_tiles
setblock 511 165 299 minecraft:deepslate_tiles
setblock 511 165 303 minecraft:cobbled_deepslate
fill 511 165 304 511 166 304 minecraft:deepslate_tiles
setblock 511 165 308 minecraft:cobbled_deepslate
fill 511 165 309 511 168 309 minecraft:deepslate_tiles
setblock 511 165 313 minecraft:cobbled_deepslate
fill 511 165 314 511 168 314 minecraft:deepslate_tiles
setblock 470 166 276 minecraft:redstone_block
fill 470 166 277 470 201 277 minecraft:black_concrete
setblock 471 166 276 minecraft:deepslate_tiles
setblock 471 166 277 minecraft:cobbled_deepslate
fill 471 166 278 471 166 281 minecraft:deepslate_tiles
setblock 471 166 282 minecraft:cobbled_deepslate
fill 471 166 283 471 168 283 minecraft:deepslate_tiles
setblock 471 166 287 minecraft:cobbled_deepslate
fill 471 166 288 471 169 288 minecraft:deepslate_tiles
setblock 471 166 291 minecraft:deepslate_tiles
fill 471 166 303 471 166 306 minecraft:deepslate_tiles
setblock 471 166 307 minecraft:cobbled_deepslate
fill 471 166 308 471 169 308 minecraft:deepslate_tiles
setblock 471 166 312 minecraft:cobbled_deepslate
fill 471 166 313 471 169 313 minecraft:deepslate_tiles
setblock 472 166 276 minecraft:cobbled_deepslate
setblock 472 166 281 minecraft:cobbled_deepslate
setblock 472 166 282 minecraft:deepslate_tiles
setblock 472 166 286 minecraft:cobbled_deepslate
setblock 472 166 287 minecraft:deepslate_tiles
setblock 472 166 306 minecraft:cobbled_deepslate
setblock 472 166 307 minecraft:deepslate_tiles
setblock 472 166 311 minecraft:cobbled_deepslate
fill 472 166 312 472 169 312 minecraft:deepslate_tiles
setblock 472 166 316 minecraft:cobbled_deepslate
setblock 473 166 276 minecraft:deepslate_tiles
fill 473 166 316 475 166 316 minecraft:deepslate_tiles
fill 478 166 316 481 166 316 minecraft:deepslate_tiles
setblock 482 166 315 minecraft:deepslate_tiles
setblock 482 166 316 minecraft:cobbled_deepslate
setblock 483 166 315 minecraft:cobbled_deepslate
fill 483 166 316 486 166 316 minecraft:deepslate_tiles
setblock 484 166 314 minecraft:cobbled_deepslate
fill 484 166 315 484 169 315 minecraft:deepslate_tiles
fill 485 166 314 485 169 314 minecraft:deepslate_tiles
setblock 487 166 316 minecraft:cobbled_deepslate
setblock 488 166 275 minecraft:redstone_block
setblock 488 166 315 minecraft:cobbled_deepslate
fill 488 166 316 488 169 316 minecraft:deepslate_tiles
setblock 489 166 315 minecraft:deepslate_tiles
fill 498 166 305 499 169 306 minecraft:white_terracotta
fill 501 166 307 502 169 307 minecraft:white_terracotta
fill 502 166 308 502 169 308 minecraft:white_terracotta
fill 505 166 317 505 201 317 minecraft:black_concrete
setblock 506 166 277 minecraft:cobbled_deepslate
setblock 507 166 276 minecraft:cobbled_deepslate
fill 507 166 277 507 167 277 minecraft:deepslate_tiles
setblock 507 166 316 minecraft:cobbled_deepslate
fill 508 166 276 508 169 276 minecraft:deepslate_tiles
setblock 508 166 285 minecraft:cobbled_deepslate
fill 508 166 286 508 168 286 minecraft:deepslate_tiles
setblock 508 166 289 minecraft:deepslate_tiles
setblock 508 166 290 minecraft:cobbled_deepslate
fill 508 166 316 508 169 316 minecraft:deepslate_tiles
setblock 509 166 280 minecraft:deepslate_tiles
setblock 509 166 284 minecraft:cobbled_deepslate
fill 509 166 285 509 169 285 minecraft:deepslate_tiles
setblock 509 166 289 minecraft:cobbled_deepslate
fill 509 166 290 509 169 290 minecraft:deepslate_tiles
setblock 510 166 278 minecraft:cobbled_deepslate
fill 510 166 279 510 167 279 minecraft:deepslate_tiles
setblock 510 166 283 minecraft:cobbled_deepslate
fill 510 166 284 510 169 284 minecraft:deepslate_tiles
setblock 510 166 288 minecraft:cobbled_deepslate
fill 510 166 289 510 169 289 minecraft:deepslate_tiles
setblock 510 166 293 minecraft:cobbled_deepslate
setblock 510 166 308 minecraft:cobbled_deepslate
fill 510 166 309 510 167 309 minecraft:deepslate_tiles
setblock 511 166 277 minecraft:cobbled_deepslate
fill 511 166 278 511 168 278 minecraft:deepslate_tiles
setblock 511 166 282 minecraft:cobbled_deepslate
fill 511 166 283 511 169 283 minecraft:deepslate_tiles
setblock 511 166 287 minecraft:cobbled_deepslate
fill 511 166 288 511 169 288 minecraft:deepslate_tiles
setblock 511 166 292 minecraft:cobbled_deepslate
fill 511 166 293 511 168 293 minecraft:deepslate_tiles
setblock 511 166 303 minecraft:deepslate_tiles
setblock 511 166 307 minecraft:cobbled_deepslate
fill 511 166 308 511 168 308 minecraft:deepslate_tiles
setblock 511 166 312 minecraft:cobbled_deepslate
fill 511 166 313 511 169 313 minecraft:deepslate_tiles
fill 470 167 276 470 197 276 minecraft:black_concrete
setblock 471 167 276 minecraft:cobbled_deepslate
fill 471 167 277 471 167 280 minecraft:deepslate_tiles
setblock 471 167 281 minecraft:cobbled_deepslate
fill 471 167 282 471 168 282 minecraft:deepslate_tiles
setblock 471 167 286 minecraft:cobbled_deepslate
fill 471 167 287 471 169 287 minecraft:deepslate_tiles
setblock 471 167 291 minecraft:cobbled_deepslate
fill 471 167 304 471 167 305 minecraft:deepslate_tiles
setblock 471 167 306 minecraft:cobbled_deepslate
fill 471 167 307 471 170 307 minecraft:deepslate_tiles
setblock 471 167 311 minecraft:cobbled_deepslate
fill 471 167 312 471 170 312 minecraft:deepslate_tiles
setblock 471 167 316 minecraft:cobbled_deepslate
setblock 472 167 310 minecraft:cobbled_deepslate
fill 472 167 311 472 170 311 minecraft:deepslate_tiles
fill 472 167 316 474 167 316 minecraft:deepslate_tiles
fill 478 167 316 480 167 316 minecraft:deepslate_tiles
fill 479 167 278 479 186 278 minecraft:white_wool
setblock 481 167 315 minecraft:deepslate_tiles
setblock 481 167 316 minecraft:cobbled_deepslate
setblock 482 167 315 minecraft:cobbled_deepslate
fill 482 167 316 485 167 316 minecraft:deepslate_tiles
fill 483 167 315 483 170 315 minecraft:deepslate_tiles
fill 484 167 314 484 170 314 minecraft:deepslate_tiles
setblock 486 167 316 minecraft:cobbled_deepslate
setblock 487 167 315 minecraft:cobbled_deepslate
fill 487 167 316 487 170 316 minecraft:deepslate_tiles
fill 488 167 275 488 201 275 minecraft:black_concrete
fill 488 167 315 488 168 315 minecraft:deepslate_tiles
fill 498 167 307 499 168 307 minecraft:white_terracotta
fill 501 167 308 501 168 308 minecraft:white_terracotta
fill 502 167 306 502 168 306 minecraft:white_terracotta
fill 503 167 307 503 168 308 minecraft:white_terracotta
setblock 506 167 276 minecraft:cobbled_deepslate
setblock 506 167 316 minecraft:cobbled_deepslate
fill 507 167 276 507 170 276 minecraft:deepslate_tiles
fill 507 167 316 507 170 316 minecraft:deepslate_tiles
setblock 508 167 284 minecraft:cobbled_deepslate
setblock 508 167 285 minecraft:deepslate_tiles
setblock 508 167 289 minecraft:cobbled_deepslate
setblock 509 167 283 minecraft:cobbled_deepslate
fill 509 167 284 509 168 284 minecraft:deepslate_tiles
setblock 509 167 288 minecraft:cobbled_deepslate
fill 509 167 289 509 169 289 minecraft:deepslate_tiles
setblock 510 167 282 minecraft:cobbled_deepslate
fill 510 167 283 510 169 283 minecraft:deepslate_tiles
setblock 510 167 287 minecraft:cobbled_deepslate
fill 510 167 288 510 170 288 minecraft:deepslate_tiles
setblock 510 167 292 minecraft:cobbled_deepslate
setblock 511 167 276 minecraft:cobbled_deepslate
fill 511 167 277 511 168 277 minecraft:deepslate_tiles
setblock 511 167 281 minecraft:cobbled_deepslate
fill 511 167 282 511 170 282 minecraft:deepslate_tiles
setblock 511 167 286 minecraft:cobbled_deepslate
fill 511 167 287 511 170 287 minecraft:deepslate_tiles
setblock 511 167 291 minecraft:cobbled_deepslate
fill 511 167 292 511 170 292 minecraft:deepslate_tiles
setblock 511 167 306 minecraft:cobbled_deepslate
fill 511 167 307 511 168 307 minecraft:deepslate_tiles
setblock 511 167 311 minecraft:cobbled_deepslate
fill 511 167 312 511 170 312 minecraft:deepslate_tiles
setblock 471 168 281 minecraft:deepslate_tiles
setblock 471 168 285 minecraft:cobbled_deepslate
fill 471 168 286 471 169 286 minecraft:deepslate_tiles
setblock 471 168 290 minecraft:cobbled_deepslate
setblock 471 168 306 minecraft:deepslate_tiles
setblock 471 168 310 minecraft:cobbled_deepslate
fill 471 168 311 471 171 311 minecraft:deepslate_tiles
setblock 471 168 315 minecraft:cobbled_deepslate
fill 471 168 316 473 169 316 minecraft:deepslate_tiles
setblock 472 168 309 minecraft:cobbled_deepslate
fill 472 168 310 472 169 310 minecraft:deepslate_tiles
fill 478 168 316 479 168 316 minecraft:deepslate_tiles
setblock 480 168 316 minecraft:cobbled_deepslate
setblock 481 168 315 minecraft:cobbled_deepslate
fill 481 168 316 484 168 316 minecraft:deepslate_tiles
fill 482 168 315 482 171 315 minecraft:deepslate_tiles
fill 483 168 314 483 171 314 minecraft:deepslate_tiles
setblock 485 168 316 minecraft:cobbled_deepslate
setblock 486 168 315 minecraft:cobbled_deepslate
fill 486 168 316 486 171 316 minecraft:deepslate_tiles
fill 487 168 315 487 171 315 minecraft:deepslate_tiles
setblock 505 168 276 minecraft:cobbled_deepslate
setblock 505 168 316 minecraft:cobbled_deepslate
fill 506 168 276 506 171 276 minecraft:deepslate_tiles
fill 506 168 316 506 171 316 minecraft:deepslate_tiles
setblock 508 168 288 minecraft:cobbled_deepslate
setblock 509 168 283 minecraft:deepslate_tiles
setblock 509 168 287 minecraft:cobbled_deepslate
fill 509 168 288 509 170 288 minecraft:deepslate_tiles
setblock 510 168 276 minecraft:cobbled_deepslate
setblock 510 168 281 minecraft:cobbled_deepslate
fill 510 168 282 510 169 282 minecraft:deepslate_tiles
setblock 510 168 286 minecraft:cobbled_deepslate
fill 510 168 287 510 171 287 minecraft:deepslate_tiles
setblock 510 168 291 minecraft:cobbled_deepslate
setblock 510 168 292 minecraft:deepslate_tiles
setblock 511 168 276 minecraft:deepslate_tiles
setblock 511 168 280 minecraft:cobbled_deepslate
fill 511 168 281 511 169 281 minecraft:deepslate_tiles
setblock 511 168 285 minecraft:cobbled_deepslate
fill 511 168 286 511 171 286 minecraft:deepslate_tiles
setblock 511 168 290 minecraft:cobbled_deepslate
fill 511 168 291 511 171 291 minecraft:deepslate_tiles
setblock 511 168 310 minecraft:cobbled_deepslate
fill 511 168 311 511 171 311 minecraft:deepslate_tiles
setblock 512 168 288 minecraft:white_wool
setblock 471 169 285 minecraft:deepslate_tiles
setblock 471 169 289 minecraft:cobbled_deepslate
setblock 471 169 309 minecraft:cobbled_deepslate
fill 471 169 310 471 172 310 minecraft:deepslate_tiles
setblock 471 169 314 minecraft:cobbled_deepslate
fill 471 169 315 471 172 315 minecraft:deepslate_tiles
setblock 473 169 278 minecraft:light[level=12]
setblock 473 169 285 minecraft:light[level=12]
setblock 473 169 292 minecraft:light[level=12]
setblock 473 169 299 minecraft:light[level=12]
setblock 473 169 306 minecraft:light[level=12]
setblock 473 169 313 minecraft:light[level=12]
fill 477 169 316 478 169 316 minecraft:deepslate_tiles
setblock 479 169 316 minecraft:cobbled_deepslate
setblock 480 169 278 minecraft:light[level=12]
setblock 480 169 285 minecraft:light[level=12]
setblock 480 169 292 minecraft:light[level=12]
setblock 480 169 299 minecraft:light[level=12]
setblock 480 169 306 minecraft:light[level=12]
setblock 480 169 313 minecraft:light[level=12]
setblock 480 169 315 minecraft:cobbled_deepslate
fill 480 169 316 483 169 316 minecraft:deepslate_tiles
fill 481 169 315 481 172 315 minecraft:deepslate_tiles
fill 482 169 314 482 172 314 minecraft:deepslate_tiles
setblock 484 169 316 minecraft:cobbled_deepslate
setblock 485 169 315 minecraft:cobbled_deepslate
fill 485 169 316 485 172 316 minecraft:deepslate_tiles
fill 486 169 315 486 172 315 minecraft:deepslate_tiles
setblock 487 169 278 minecraft:light[level=12]
setblock 487 169 285 minecraft:light[level=12]
setblock 487 169 292 minecraft:light[level=12]
setblock 487 169 299 minecraft:light[level=12]
setblock 487 169 306 minecraft:light[level=12]
setblock 487 169 313 minecraft:light[level=12]
setblock 494 169 278 minecraft:light[level=12]
setblock 494 169 285 minecraft:light[level=12]
setblock 494 169 292 minecraft:light[level=12]
setblock 494 169 299 minecraft:light[level=12]
setblock 494 169 306 minecraft:light[level=12]
setblock 494 169 313 minecraft:light[level=12]
setblock 501 169 278 minecraft:light[level=12]
setblock 501 169 285 minecraft:light[level=12]
setblock 501 169 292 minecraft:light[level=12]
setblock 501 169 299 minecraft:light[level=12]
setblock 501 169 306 minecraft:light[level=12]
setblock 501 169 313 minecraft:light[level=12]
setblock 504 169 276 minecraft:cobbled_deepslate
setblock 504 169 316 minecraft:cobbled_deepslate
fill 505 169 276 505 172 276 minecraft:deepslate_tiles
fill 505 169 316 505 172 316 minecraft:deepslate_tiles
setblock 508 169 278 minecraft:light[level=12]
setblock 508 169 285 minecraft:light[level=12]
setblock 508 169 292 minecraft:light[level=12]
setblock 508 169 299 minecraft:light[level=12]
setblock 508 169 306 minecraft:light[level=12]
setblock 508 169 313 minecraft:light[level=12]
setblock 509 169 276 minecraft:cobbled_deepslate
setblock 509 169 286 minecraft:cobbled_deepslate
fill 509 169 287 509 170 287 minecraft:deepslate_tiles
setblock 509 169 316 minecraft:cobbled_deepslate
fill 510 169 276 510 172 276 minecraft:deepslate_tiles
setblock 510 169 285 minecraft:cobbled_deepslate
fill 510 169 286 510 171 286 minecraft:deepslate_tiles
setblock 510 169 290 minecraft:cobbled_deepslate
fill 510 169 291 510 170 291 minecraft:deepslate_tiles
setblock 511 169 280 minecraft:deepslate_tiles
setblock 511 169 284 minecraft:cobbled_deepslate
fill 511 169 285 511 172 285 minecraft:deepslate_tiles
setblock 511 169 289 minecraft:cobbled_deepslate
fill 511 169 290 511 172 290 minecraft:deepslate_tiles
setblock 511 169 309 minecraft:cobbled_deepslate
fill 511 169 310 511 170 310 minecraft:deepslate_tiles
setblock 511 169 314 minecraft:cobbled_deepslate
fill 512 169 288 512 202 288 minecraft:black_concrete
setblock 470 170 289 minecraft:redstone_block
fill 470 170 290 470 201 290 minecraft:black_concrete
fill 470 170 292 470 197 292 minecraft:black_concrete
setblock 470 170 293 minecraft:redstone_block
setblock 471 170 308 minecraft:cobbled_deepslate
fill 471 170 309 471 173 309 minecraft:deepslate_tiles
setblock 471 170 313 minecraft:cobbled_deepslate
fill 471 170 314 471 173 314 minecraft:deepslate_tiles
fill 471 170 316 472 170 316 minecraft:deepslate_tiles
setblock 472 170 312 minecraft:cobbled_deepslate
setblock 473 170 316 minecraft:cobbled_deepslate
fill 474 170 316 477 170 316 minecraft:deepslate_tiles
setblock 478 170 316 minecraft:cobbled_deepslate
setblock 479 170 275 minecraft:white_wool
setblock 479 170 315 minecraft:cobbled_deepslate
fill 479 170 316 482 170 316 minecraft:deepslate_tiles
fill 480 170 315 480 173 315 minecraft:deepslate_tiles
fill 481 170 314 481 173 314 minecraft:deepslate_tiles
setblock 483 170 316 minecraft:cobbled_deepslate
setblock 484 170 315 minecraft:cobbled_deepslate
fill 484 170 316 484 173 316 minecraft:deepslate_tiles
setblock 485 170 314 minecraft:cobbled_deepslate
fill 485 170 315 485 173 315 minecraft:deepslate_tiles
setblock 488 170 316 minecraft:cobbled_deepslate
fill 502 170 307 502 173 307 minecraft:white_wool
setblock 503 170 276 minecraft:cobbled_deepslate
setblock 503 170 316 minecraft:cobbled_deepslate
fill 504 170 276 504 173 276 minecraft:deepslate_tiles
fill 504 170 316 504 173 316 minecraft:deepslate_tiles
setblock 508 170 276 minecraft:cobbled_deepslate
setblock 508 170 316 minecraft:cobbled_deepslate
fill 509 170 276 509 173 276 minecraft:deepslate_tiles
fill 509 170 316 510 172 316 minecraft:deepslate_tiles
setblock 510 170 284 minecraft:cobbled_deepslate
setblock 510 170 285 minecraft:deepslate_tiles
setblock 510 170 289 minecraft:cobbled_deepslate
fill 510 170 290 510 171 290 minecraft:deepslate_tiles
setblock 511 170 283 minecraft:cobbled_deepslate
fill 511 170 284 511 171 284 minecraft:deepslate_tiles
setblock 511 170 288 minecraft:cobbled_deepslate
fill 511 170 289 511 173 289 minecraft:deepslate_tiles
setblock 511 170 313 minecraft:cobbled_deepslate
fill 511 170 314 511 172 315 minecraft:deepslate_tiles
fill 470 171 289 470 199 289 minecraft:black_concrete
fill 470 171 293 470 201 293 minecraft:black_concrete
fill 471 171 308 471 174 308 minecraft:deepslate_tiles
setblock 471 171 312 minecraft:cobbled_deepslate
fill 471 171 313 472 173 313 minecraft:deepslate_tiles
setblock 471 171 316 minecraft:deepslate_tiles
setblock 472 171 311 minecraft:cobbled_deepslate
fill 472 171 312 472 174 312 minecraft:deepslate_tiles
setblock 472 171 316 minecraft:cobbled_deepslate
fill 473 171 316 476 171 316 minecraft:deepslate_tiles
setblock 477 171 315 minecraft:deepslate_tiles
setblock 477 171 316 minecraft:cobbled_deepslate
setblock 478 171 315 minecraft:cobbled_deepslate
fill 478 171 316 481 171 316 minecraft:deepslate_tiles
setblock 479 171 275 minecraft:black_concrete
fill 479 171 315 479 174 315 minecraft:deepslate_tiles
fill 480 171 314 480 174 314 minecraft:deepslate_tiles
setblock 482 171 316 minecraft:cobbled_deepslate
setblock 483 171 315 minecraft:cobbled_deepslate
fill 483 171 316 483 174 316 minecraft:deepslate_tiles
setblock 484 171 314 minecraft:cobbled_deepslate
fill 484 171 315 484 174 315 minecraft:deepslate_tiles
fill 485 171 314 485 174 314 minecraft:deepslate_tiles
fill 487 171 278 487 175 278 minecraft:black_concrete
setblock 487 171 316 minecraft:cobbled_deepslate
fill 488 171 316 488 174 316 minecraft:deepslate_tiles
setblock 502 171 276 minecraft:cobbled_deepslate
setblock 502 171 316 minecraft:cobbled_deepslate
fill 503 171 276 503 174 276 minecraft:deepslate_tiles
fill 503 171 316 503 174 316 minecraft:deepslate_tiles
fill 505 171 315 505 173 315 minecraft:deepslate_tiles
setblock 507 171 276 minecraft:cobbled_deepslate
setblock 507 171 316 minecraft:cobbled_deepslate
fill 508 171 276 508 174 276 minecraft:deepslate_tiles
fill 508 171 316 508 174 316 minecraft:deepslate_tiles
setblock 508 171 317 minecraft:white_wool
setblock 510 171 288 minecraft:cobbled_deepslate
fill 510 171 289 510 172 289 minecraft:deepslate_tiles
setblock 511 171 283 minecraft:deepslate_tiles
setblock 511 171 287 minecraft:cobbled_deepslate
fill 511 171 288 511 174 288 minecraft:deepslate_tiles
setblock 511 171 292 minecraft:cobbled_deepslate
setblock 511 171 312 minecraft:cobbled_deepslate
fill 511 171 313 511 174 313 minecraft:deepslate_tiles
setblock 511 171 316 minecraft:deepslate_tiles
setblock 471 172 311 minecraft:cobbled_deepslate
fill 471 172 312 471 175 312 minecraft:deepslate_tiles
setblock 471 172 316 minecraft:cobbled_deepslate
fill 472 172 311 472 175 311 minecraft:deepslate_tiles
setblock 472 172 314 minecraft:deepslate_tiles
setblock 472 172 315 minecraft:cobbled_deepslate
fill 472 172 316 475 172 316 minecraft:deepslate_tiles
fill 474 172 315 476 172 315 minecraft:deepslate_tiles
setblock 476 172 316 minecraft:cobbled_deepslate
setblock 477 172 315 minecraft:cobbled_deepslate
fill 477 172 316 480 172 316 minecraft:deepslate_tiles
setblock 478 172 314 minecraft:cobbled_deepslate
fill 478 172 315 478 175 315 minecraft:deepslate_tiles
setblock 479 172 275 minecraft:redstone_block
fill 479 172 314 479 175 314 minecraft:deepslate_tiles
setblock 481 172 316 minecraft:cobbled_deepslate
fill 482 172 313 483 172 313 minecraft:deepslate_tiles
setblock 482 172 315 minecraft:cobbled_deepslate
fill 482 172 316 482 175 316 minecraft:deepslate_tiles
setblock 483 172 314 minecraft:cobbled_deepslate
fill 483 172 315 483 175 315 minecraft:deepslate_tiles
fill 484 172 314 484 175 314 minecraft:deepslate_tiles
fill 486 172 314 486 173 314 minecraft:deepslate_tiles
setblock 486 172 316 minecraft:cobbled_deepslate
setblock 487 172 315 minecraft:cobbled_deepslate
fill 487 172 316 487 175 316 minecraft:deepslate_tiles
setblock 500 172 276 minecraft:deepslate_tiles
setblock 500 172 316 minecraft:deepslate_tiles
setblock 501 172 276 minecraft:cobbled_deepslate
setblock 501 172 316 minecraft:cobbled_deepslate
fill 502 172 276 502 175 276 minecraft:deepslate_tiles
setblock 502 172 315 minecraft:cobbled_deepslate
fill 502 172 316 502 175 316 minecraft:deepslate_tiles
fill 503 172 277 504 172 277 minecraft:deepslate_tiles
fill 503 172 315 504 174 315 minecraft:deepslate_tiles
setblock 505 172 277 minecraft:cobbled_deepslate
setblock 506 172 276 minecraft:cobbled_deepslate
fill 506 172 277 506 175 277 minecraft:deepslate_tiles
setblock 506 172 315 minecraft:deepslate_tiles
setblock 506 172 316 minecraft:cobbled_deepslate
fill 507 172 276 507 175 276 minecraft:deepslate_tiles
setblock 507 172 315 minecraft:cobbled_deepslate
fill 507 172 316 507 175 316 minecraft:deepslate_tiles
fill 508 172 317 508 201 317 minecraft:black_concrete
setblock 510 172 288 minecraft:deepslate_tiles
setblock 511 172 276 minecraft:cobbled_deepslate
setblock 511 172 286 minecraft:cobbled_deepslate
fill 511 172 287 511 174 287 minecraft:deepslate_tiles
setblock 511 172 291 minecraft:cobbled_deepslate
fill 511 172 292 511 175 292 minecraft:deepslate_tiles
setblock 511 172 311 minecraft:cobbled_deepslate
fill 511 172 312 511 175 312 minecraft:deepslate_tiles
setblock 511 172 316 minecraft:cobbled_deepslate
setblock 471 173 310 minecraft:cobbled_deepslate
fill 471 173 311 471 176 311 minecraft:deepslate_tiles
setblock 471 173 315 minecraft:cobbled_deepslate
fill 471 173 316 474 173 316 minecraft:deepslate_tiles
setblock 472 173 314 minecraft:cobbled_deepslate
fill 472 173 315 475 173 315 minecraft:deepslate_tiles
setblock 473 173 278 minecraft:light[level=13]
setblock 473 173 286 minecraft:light[level=13]
setblock 473 173 294 minecraft:light[level=13]
setblock 473 173 302 minecraft:light[level=13]
setblock 473 173 310 minecraft:light[level=13]
setblock 475 173 316 minecraft:cobbled_deepslate
setblock 476 173 315 minecraft:cobbled_deepslate
fill 476 173 316 479 173 316 minecraft:deepslate_tiles
setblock 477 173 314 minecraft:cobbled_deepslate
fill 477 173 315 477 176 315 minecraft:deepslate_tiles
fill 478 173 314 478 176 314 minecraft:deepslate_tiles
fill 479 173 275 479 199 275 minecraft:black_concrete
setblock 479 173 276 minecraft:deepslate_tiles
setblock 480 173 276 minecraft:cobbled_deepslate
fill 480 173 313 482 173 313 minecraft:deepslate_tiles
setblock 480 173 316 minecraft:cobbled_deepslate
fill 481 173 276 484 173 276 minecraft:deepslate_tiles
setblock 481 173 278 minecraft:light[level=13]
setblock 481 173 286 minecraft:light[level=13]
setblock 481 173 294 minecraft:light[level=13]
setblock 481 173 302 minecraft:light[level=13]
setblock 481 173 310 minecraft:light[level=13]
setblock 481 173 315 minecraft:cobbled_deepslate
fill 481 173 316 481 176 316 minecraft:deepslate_tiles
setblock 482 173 314 minecraft:cobbled_deepslate
fill 482 173 315 482 176 315 minecraft:deepslate_tiles
setblock 483 173 313 minecraft:cobbled_deepslate
fill 483 173 314 483 176 314 minecraft:deepslate_tiles
setblock 485 173 316 minecraft:cobbled_deepslate
setblock 486 173 315 minecraft:cobbled_deepslate
fill 486 173 316 486 176 316 minecraft:deepslate_tiles
fill 487 173 315 487 176 315 minecraft:deepslate_tiles
setblock 489 173 278 minecraft:light[level=13]
setblock 489 173 286 minecraft:light[level=13]
setblock 489 173 294 minecraft:light[level=13]
setblock 489 173 302 minecraft:light[level=13]
setblock 489 173 310 minecraft:light[level=13]
setblock 489 173 316 minecraft:deepslate_tiles
setblock 497 173 278 minecraft:light[level=13]
setblock 497 173 286 minecraft:light[level=13]
setblock 497 173 294 minecraft:light[level=13]
setblock 497 173 302 minecraft:light[level=13]
setblock 497 173 310 minecraft:light[level=13]
fill 498 173 316 499 173 316 minecraft:deepslate_tiles
setblock 499 173 276 minecraft:deepslate_tiles
setblock 500 173 276 minecraft:cobbled_deepslate
setblock 500 173 316 minecraft:cobbled_deepslate
fill 501 173 276 501 175 277 minecraft:deepslate_tiles
setblock 501 173 315 minecraft:cobbled_deepslate
fill 501 173 316 501 176 316 minecraft:deepslate_tiles
fill 502 173 277 503 173 277 minecraft:deepslate_tiles
fill 502 173 315 502 176 315 minecraft:deepslate_tiles
setblock 504 173 277 minecraft:cobbled_deepslate
setblock 505 173 276 minecraft:cobbled_deepslate
fill 505 173 277 505 176 277 minecraft:deepslate_tiles
setblock 505 173 278 minecraft:light[level=13]
setblock 505 173 286 minecraft:light[level=13]
setblock 505 173 294 minecraft:light[level=13]
setblock 505 173 302 minecraft:light[level=13]
setblock 505 173 310 minecraft:light[level=13]
setblock 505 173 316 minecraft:cobbled_deepslate
fill 506 173 276 506 176 276 minecraft:deepslate_tiles
setblock 506 173 315 minecraft:cobbled_deepslate
fill 506 173 316 506 176 316 minecraft:deepslate_tiles
fill 507 173 277 507 174 277 minecraft:deepslate_tiles
fill 507 173 315 509 174 315 minecraft:deepslate_tiles
setblock 509 173 316 minecraft:deepslate_tiles
setblock 510 173 276 minecraft:cobbled_deepslate
setblock 510 173 316 minecraft:cobbled_deepslate
fill 511 173 276 511 175 277 minecraft:deepslate_tiles
setblock 511 173 286 minecraft:deepslate_tiles
setblock 511 173 290 minecraft:cobbled_deepslate
fill 511 173 291 511 176 291 minecraft:deepslate_tiles
fill 511 173 293 511 174 293 minecraft:deepslate_tiles
fill 511 173 311 511 176 311 minecraft:deepslate_tiles
setblock 511 173 314 minecraft:deepslate_tiles
setblock 511 173 315 minecraft:cobbled_deepslate
fill 511 173 316 511 176 316 minecraft:deepslate_tiles
fill 470 174 300 470 186 301 minecraft:black_concrete
setblock 470 174 302 minecraft:white_wool
fill 471 174 276 471 176 276 minecraft:deepslate_tiles
setblock 471 174 309 minecraft:cobbled_deepslate
fill 471 174 310 471 177 310 minecraft:deepslate_tiles
setblock 471 174 313 minecraft:deepslate_tiles
setblock 471 174 314 minecraft:cobbled_deepslate
fill 471 174 315 473 174 316 minecraft:deepslate_tiles
setblock 472 174 313 minecraft:cobbled_deepslate
fill 472 174 314 472 177 314 minecraft:deepslate_tiles
setblock 474 174 315 minecraft:deepslate_tiles
setblock 474 174 316 minecraft:cobbled_deepslate
setblock 475 174 314 minecraft:deepslate_tiles
setblock 475 174 315 minecraft:cobbled_deepslate
fill 475 174 316 478 174 316 minecraft:deepslate_tiles
fill 476 174 276 478 174 276 minecraft:deepslate_tiles
setblock 476 174 314 minecraft:cobbled_deepslate
fill 476 174 315 476 177 315 minecraft:deepslate_tiles
fill 477 174 314 477 177 314 minecraft:deepslate_tiles
setblock 479 174 276 minecraft:cobbled_deepslate
fill 479 174 313 481 174 313 minecraft:deepslate_tiles
setblock 479 174 316 minecraft:cobbled_deepslate
fill 480 174 276 483 174 276 minecraft:deepslate_tiles
setblock 480 174 315 minecraft:cobbled_deepslate
fill 480 174 316 480 177 316 minecraft:deepslate_tiles
setblock 481 174 314 minecraft:cobbled_deepslate
fill 481 174 315 481 177 315 minecraft:deepslate_tiles
setblock 482 174 313 minecraft:cobbled_deepslate
fill 482 174 314 482 177 314 minecraft:deepslate_tiles
fill 483 174 313 484 174 313 minecraft:deepslate_tiles
setblock 484 174 276 minecraft:cobbled_deepslate
setblock 484 174 316 minecraft:cobbled_deepslate
fill 485 174 276 485 177 276 minecraft:deepslate_tiles
setblock 485 174 315 minecraft:cobbled_deepslate
fill 485 174 316 485 177 316 minecraft:deepslate_tiles
fill 486 174 278 486 175 278 minecraft:black_concrete
setblock 486 174 314 minecraft:cobbled_deepslate
fill 486 174 315 486 177 315 minecraft:deepslate_tiles
fill 487 174 277 487 175 277 minecraft:black_concrete
fill 487 174 279 487 175 279 minecraft:black_concrete
fill 488 174 278 488 175 278 minecraft:black_concrete
setblock 489 174 316 minecraft:cobbled_deepslate
fill 497 174 276 498 174 276 minecraft:deepslate_tiles
fill 497 174 316 498 174 316 minecraft:deepslate_tiles
setblock 499 174 276 minecraft:cobbled_deepslate
setblock 499 174 315 minecraft:deepslate_tiles
setblock 499 174 316 minecraft:cobbled_deepslate
fill 500 174 276 500 176 277 minecraft:deepslate_tiles
setblock 500 174 315 minecraft:cobbled_deepslate
fill 500 174 316 500 177 316 minecraft:deepslate_tiles
fill 501 174 315 501 177 315 minecraft:deepslate_tiles
setblock 502 174 277 minecraft:deepslate_tiles
setblock 503 174 277 minecraft:cobbled_deepslate
fill 503 174 314 504 175 314 minecraft:deepslate_tiles
setblock 504 174 276 minecraft:cobbled_deepslate
fill 504 174 277 504 177 277 minecraft:deepslate_tiles
setblock 504 174 316 minecraft:cobbled_deepslate
fill 505 174 276 505 177 276 minecraft:deepslate_tiles
setblock 505 174 315 minecraft:cobbled_deepslate
fill 505 174 316 505 177 316 minecraft:deepslate_tiles
fill 506 174 315 506 177 315 minecraft:deepslate_tiles
setblock 508 174 277 minecraft:cobbled_deepslate
setblock 509 174 276 minecraft:cobbled_deepslate
setblock 509 174 316 minecraft:cobbled_deepslate
fill 510 174 276 510 177 276 minecraft:deepslate_tiles
setblock 510 174 314 minecraft:deepslate_tiles
setblock 510 174 315 minecraft:cobbled_deepslate
fill 510 174 316 510 177 316 minecraft:deepslate_tiles
setblock 511 174 278 minecraft:deepslate_tiles
setblock 511 174 289 minecraft:cobbled_deepslate
fill 511 174 290 511 176 290 minecraft:deepslate_tiles
setblock 511 174 314 minecraft:cobbled_deepslate
fill 511 174 315 511 177 315 minecraft:deepslate_tiles
fill 470 175 302 470 201 302 minecraft:black_concrete
setblock 470 175 304 minecraft:redstone_block
setblock 470 175 308 minecraft:white_wool
setblock 471 175 308 minecraft:cobbled_deepslate
fill 471 175 309 471 178 309 minecraft:deepslate_tiles
setblock 471 175 313 minecraft:cobbled_deepslate
fill 471 175 314 471 176 316 minecraft:deepslate_tiles
setblock 472 175 276 minecraft:deepslate_tiles
fill 472 175 310 472 176 310 minecraft:deepslate_tiles
setblock 472 175 312 minecraft:cobbled_deepslate
fill 472 175 313 472 178 313 minecraft:deepslate_tiles
fill 472 175 315 472 175 316 minecraft:deepslate_tiles
setblock 473 175 276 minecraft:cobbled_deepslate
setblock 473 175 278 minecraft:light[level=12]
setblock 473 175 285 minecraft:light[level=12]
setblock 473 175 292 minecraft:light[level=12]
setblock 473 175 299 minecraft:light[level=12]
setblock 473 175 306 minecraft:light[level=12]
setblock 473 175 313 minecraft:light[level=12]
fill 473 175 314 473 175 315 minecraft:deepslate_tiles
setblock 473 175 316 minecraft:cobbled_deepslate
fill 474 175 276 477 175 276 minecraft:deepslate_tiles
setblock 474 175 314 minecraft:deepslate_tiles
setblock 474 175 315 minecraft:cobbled_deepslate
fill 474 175 316 477 175 316 minecraft:deepslate_tiles
setblock 475 175 314 minecraft:cobbled_deepslate
fill 475 175 315 475 178 315 minecraft:deepslate_tiles
fill 476 175 314 476 178 314 minecraft:deepslate_tiles
setblock 478 175 276 minecraft:cobbled_deepslate
fill 478 175 313 480 175 313 minecraft:deepslate_tiles
setblock 478 175 316 minecraft:cobbled_deepslate
fill 479 175 276 482 175 276 minecraft:deepslate_tiles
setblock 479 175 315 minecraft:cobbled_deepslate
fill 479 175 316 479 178 316 minecraft:deepslate_tiles
setblock 480 175 278 minecraft:light[level=12]
setblock 480 175 285 minecraft:light[level=12]
setblock 480 175 292 minecraft:light[level=12]
setblock 480 175 299 minecraft:light[level=12]
setblock 480 175 306 minecraft:light[level=12]
setblock 480 175 314 minecraft:cobbled_deepslate
fill 480 175 315 480 178 315 minecraft:deepslate_tiles
setblock 481 175 313 minecraft:cobbled_deepslate
fill 481 175 314 481 178 314 minecraft:deepslate_tiles
fill 482 175 313 483 176 313 minecraft:deepslate_tiles
setblock 483 175 276 minecraft:cobbled_deepslate
setblock 483 175 316 minecraft:cobbled_deepslate
fill 484 175 276 484 178 276 minecraft:deepslate_tiles
setblock 484 175 315 minecraft:cobbled_deepslate
fill 484 175 316 484 178 316 minecraft:deepslate_tiles
setblock 485 175 314 minecraft:cobbled_deepslate
fill 485 175 315 485 178 315 minecraft:deepslate_tiles
fill 486 175 276 486 176 276 minecraft:deepslate_tiles
setblock 486 175 277 minecraft:black_concrete
setblock 486 175 279 minecraft:black_concrete
setblock 486 175 314 minecraft:deepslate_tiles
setblock 487 175 285 minecraft:light[level=12]
setblock 487 175 292 minecraft:light[level=12]
setblock 487 175 299 minecraft:light[level=12]
setblock 487 175 306 minecraft:light[level=12]
setblock 487 175 313 minecraft:light[level=12]
setblock 488 175 277 minecraft:black_concrete
setblock 488 175 279 minecraft:black_concrete
setblock 488 175 316 minecraft:cobbled_deepslate
fill 489 175 316 490 177 316 minecraft:deepslate_tiles
setblock 494 175 278 minecraft:light[level=12]
setblock 494 175 285 minecraft:light[level=12]
setblock 494 175 292 minecraft:light[level=12]
setblock 494 175 299 minecraft:light[level=12]
setblock 494 175 306 minecraft:light[level=12]
setblock 494 175 313 minecraft:light[level=12]
fill 495 175 316 497 175 316 minecraft:deepslate_tiles
fill 496 175 276 497 175 276 minecraft:deepslate_tiles
setblock 498 175 276 minecraft:cobbled_deepslate
fill 498 175 277 499 177 277 minecraft:deepslate_tiles
setblock 498 175 315 minecraft:deepslate_tiles
setblock 498 175 316 minecraft:cobbled_deepslate
fill 499 175 276 499 178 276 minecraft:deepslate_tiles
setblock 499 175 315 minecraft:cobbled_deepslate
fill 499 175 316 499 178 316 minecraft:deepslate_tiles
fill 500 175 315 500 178 315 minecraft:deepslate_tiles
setblock 501 175 278 minecraft:cobbled_deepslate
setblock 501 175 285 minecraft:light[level=12]
setblock 501 175 292 minecraft:light[level=12]
setblock 501 175 299 minecraft:light[level=12]
setblock 501 175 306 minecraft:light[level=12]
setblock 501 175 313 minecraft:light[level=12]
fill 501 175 314 502 177 314 minecraft:deepslate_tiles
setblock 502 175 277 minecraft:cobbled_deepslate
fill 502 175 278 505 175 278 minecraft:deepslate_tiles
setblock 503 175 276 minecraft:cobbled_deepslate
fill 503 175 277 503 178 277 minecraft:deepslate_tiles
setblock 503 175 315 minecraft:deepslate_tiles
setblock 503 175 316 minecraft:cobbled_deepslate
fill 504 175 276 504 178 276 minecraft:deepslate_tiles
setblock 504 175 315 minecraft:cobbled_deepslate
fill 504 175 316 504 178 316 minecraft:deepslate_tiles
setblock 505 175 314 minecraft:cobbled_deepslate
fill 505 175 315 505 178 315 minecraft:deepslate_tiles
setblock 507 175 277 minecraft:cobbled_deepslate
fill 507 175 315 508 175 315 minecraft:deepslate_tiles
setblock 508 175 276 minecraft:cobbled_deepslate
fill 508 175 277 509 177 277 minecraft:deepslate_tiles
setblock 508 175 278 minecraft:light[level=12]
setblock 508 175 285 minecraft:light[level=12]
setblock 508 175 292 minecraft:light[level=12]
setblock 508 175 299 minecraft:light[level=12]
setblock 508 175 306 minecraft:light[level=12]
setblock 508 175 313 minecraft:light[level=12]
setblock 508 175 316 minecraft:cobbled_deepslate
fill 509 175 276 509 178 276 minecraft:deepslate_tiles
setblock 509 175 315 minecraft:cobbled_deepslate
fill 509 175 316 509 178 316 minecraft:deepslate_tiles
setblock 510 175 313 minecraft:deepslate_tiles
setblock 510 175 314 minecraft:cobbled_deepslate
fill 510 175 315 510 178 315 minecraft:deepslate_tiles
setblock 511 175 278 minecraft:cobbled_deepslate
fill 511 175 279 511 178 279 minecraft:deepslate_tiles
setblock 511 175 288 minecraft:cobbled_deepslate
setblock 511 175 289 minecraft:deepslate_tiles
setblock 511 175 293 minecraft:cobbled_deepslate
fill 511 175 294 511 178 294 minecraft:deepslate_tiles
setblock 511 175 313 minecraft:cobbled_deepslate
fill 511 175 314 511 178 314 minecraft:deepslate_tiles
fill 470 176 304 470 201 304 minecraft:black_concrete
fill 470 176 308 470 197 308 minecraft:black_concrete
setblock 471 176 277 minecraft:cobbled_deepslate
fill 471 176 293 471 177 295 minecraft:deepslate_tiles
fill 471 176 308 471 178 308 minecraft:deepslate_tiles
setblock 471 176 312 minecraft:cobbled_deepslate
fill 471 176 313 471 179 313 minecraft:deepslate_tiles
setblock 472 176 276 minecraft:cobbled_deepslate
setblock 472 176 311 minecraft:cobbled_deepslate
fill 472 176 312 472 179 312 minecraft:deepslate_tiles
setblock 472 176 315 minecraft:deepslate_tiles
setblock 472 176 316 minecraft:cobbled_deepslate
fill 473 176 276 476 176 276 minecraft:deepslate_tiles
fill 473 176 313 473 176 314 minecraft:deepslate_tiles
setblock 473 176 315 minecraft:cobbled_deepslate
fill 473 176 316 476 176 316 minecraft:deepslate_tiles
setblock 474 176 314 minecraft:cobbled_deepslate
fill 474 176 315 474 179 315 minecraft:deepslate_tiles
fill 475 176 314 475 179 314 minecraft:deepslate_tiles
setblock 477 176 276 minecraft:cobbled_deepslate
fill 477 176 313 479 176 313 minecraft:deepslate_tiles
setblock 477 176 316 minecraft:cobbled_deepslate
fill 478 176 276 481 176 276 minecraft:deepslate_tiles
setblock 478 176 315 minecraft:cobbled_deepslate
fill 478 176 316 478 179 316 minecraft:deepslate_tiles
fill 479 176 277 480 176 277 minecraft:deepslate_tiles
fill 479 176 284 480 177 286 minecraft:white_wool
setblock 479 176 314 minecraft:cobbled_deepslate
fill 479 176 315 479 179 315 minecraft:deepslate_tiles
setblock 480 176 313 minecraft:cobbled_deepslate
fill 480 176 314 480 179 314 minecraft:deepslate_tiles
setblock 481 176 277 minecraft:cobbled_deepslate
fill 481 176 313 481 178 313 minecraft:deepslate_tiles
setblock 482 176 276 minecraft:cobbled_deepslate
fill 482 176 277 482 179 277 minecraft:deepslate_tiles
setblock 482 176 316 minecraft:cobbled_deepslate
fill 483 176 276 483 179 276 minecraft:deepslate_tiles
setblock 483 176 315 minecraft:cobbled_deepslate
fill 483 176 316 483 179 316 minecraft:deepslate_tiles
setblock 484 176 314 minecraft:cobbled_deepslate
fill 484 176 315 484 179 315 minecraft:deepslate_tiles
fill 485 176 314 485 177 314 minecraft:deepslate_tiles
setblock 487 176 276 minecraft:cobbled_deepslate
setblock 487 176 316 minecraft:cobbled_deepslate
fill 488 176 316 488 179 316 minecraft:deepslate_tiles
setblock 491 176 316 minecraft:deepslate_tiles
fill 493 176 316 496 176 316 minecraft:deepslate_tiles
fill 494 176 276 496 176 276 minecraft:deepslate_tiles
setblock 497 176 276 minecraft:cobbled_deepslate
fill 497 176 277 497 179 277 minecraft:deepslate_tiles
setblock 497 176 315 minecraft:deepslate_tiles
setblock 497 176 316 minecraft:cobbled_deepslate
fill 498 176 276 498 179 276 minecraft:deepslate_tiles
setblock 498 176 315 minecraft:cobbled_deepslate
fill 498 176 316 498 179 316 minecraft:deepslate_tiles
setblock 499 176 278 minecraft:deepslate_tiles
fill 499 176 315 499 179 315 minecraft:deepslate_tiles
setblock 500 176 278 minecraft:cobbled_deepslate
fill 500 176 314 500 178 314 minecraft:deepslate_tiles
setblock 501 176 276 minecraft:deepslate_tiles
setblock 501 176 277 minecraft:cobbled_deepslate
fill 501 176 278 504 176 278 minecraft:deepslate_tiles
setblock 502 176 276 minecraft:cobbled_deepslate
fill 502 176 277 502 179 277 minecraft:deepslate_tiles
setblock 502 176 316 minecraft:cobbled_deepslate
fill 503 176 276 503 179 276 minecraft:deepslate_tiles
setblock 503 176 314 minecraft:deepslate_tiles
setblock 503 176 315 minecraft:cobbled_deepslate
fill 503 176 316 503 179 316 minecraft:deepslate_tiles
setblock 504 176 314 minecraft:cobbled_deepslate
fill 504 176 315 504 179 315 minecraft:deepslate_tiles
setblock 505 176 278 minecraft:cobbled_deepslate
fill 505 176 314 506 176 314 minecraft:deepslate_tiles
setblock 506 176 277 minecraft:cobbled_deepslate
fill 506 176 278 506 179 278 minecraft:deepslate_tiles
setblock 507 176 276 minecraft:cobbled_deepslate
fill 507 176 277 507 179 277 minecraft:deepslate_tiles
setblock 507 176 315 minecraft:deepslate_tiles
setblock 507 176 316 minecraft:cobbled_deepslate
fill 508 176 276 508 179 276 minecraft:deepslate_tiles
setblock 508 176 315 minecraft:cobbled_deepslate
fill 508 176 316 508 179 316 minecraft:deepslate_tiles
fill 509 176 315 509 179 315 minecraft:deepslate_tiles
setblock 510 176 277 minecraft:deepslate_tiles
setblock 510 176 313 minecraft:cobbled_deepslate
fill 510 176 314 510 179 314 minecraft:deepslate_tiles
setblock 511 176 276 minecraft:deepslate_tiles
setblock 511 176 277 minecraft:cobbled_deepslate
fill 511 176 278 511 179 278 minecraft:deepslate_tiles
fill 511 176 280 511 177 280 minecraft:deepslate_tiles
setblock 511 176 292 minecraft:cobbled_deepslate
fill 511 176 293 511 178 293 minecraft:deepslate_tiles
fill 511 176 295 511 177 295 minecraft:deepslate_tiles
setblock 511 176 312 minecraft:cobbled_deepslate
fill 511 176 313 511 179 313 minecraft:deepslate_tiles
setblock 512 176 285 minecraft:redstone_block
setblock 470 177 291 minecraft:white_wool
setblock 471 177 276 minecraft:cobbled_deepslate
fill 471 177 277 471 179 278 minecraft:deepslate_tiles
setblock 471 177 296 minecraft:cobbled_deepslate
fill 471 177 297 471 180 297 minecraft:deepslate_tiles
setblock 471 177 311 minecraft:cobbled_deepslate
fill 471 177 312 471 180 312 minecraft:deepslate_tiles
fill 471 177 314 471 177 315 minecraft:deepslate_tiles
setblock 471 177 316 minecraft:cobbled_deepslate
fill 472 177 276 475 177 276 minecraft:deepslate_tiles
setblock 472 177 310 minecraft:cobbled_deepslate
fill 472 177 311 472 179 311 minecraft:deepslate_tiles
setblock 472 177 315 minecraft:cobbled_deepslate
fill 472 177 316 475 177 316 minecraft:deepslate_tiles
setblock 473 177 313 minecraft:deepslate_tiles
setblock 473 177 314 minecraft:cobbled_deepslate
fill 473 177 315 473 180 315 minecraft:deepslate_tiles
fill 474 177 314 474 180 314 minecraft:deepslate_tiles
setblock 476 177 276 minecraft:cobbled_deepslate
setblock 476 177 316 minecraft:cobbled_deepslate
fill 477 177 276 479 177 277 minecraft:deepslate_tiles
fill 477 177 313 478 177 313 minecraft:deepslate_tiles
setblock 477 177 315 minecraft:cobbled_deepslate
fill 477 177 316 477 180 316 minecraft:deepslate_tiles
setblock 478 177 314 minecraft:cobbled_deepslate
fill 478 177 315 478 178 315 minecraft:deepslate_tiles
setblock 479 177 313 minecraft:cobbled_deepslate
fill 479 177 314 479 180 314 minecraft:deepslate_tiles
setblock 480 177 276 minecraft:deepslate_tiles
setblock 480 177 277 minecraft:cobbled_deepslate
fill 480 177 313 480 178 313 minecraft:deepslate_tiles
setblock 481 177 276 minecraft:cobbled_deepslate
fill 481 177 277 481 180 277 minecraft:deepslate_tiles
setblock 481 177 316 minecraft:cobbled_deepslate
fill 482 177 276 482 180 276 minecraft:deepslate_tiles
setblock 482 177 313 minecraft:deepslate_tiles
setblock 482 177 315 minecraft:cobbled_deepslate
fill 482 177 316 482 180 316 minecraft:deepslate_tiles
fill 483 177 277 483 178 277 minecraft:deepslate_tiles
setblock 483 177 314 minecraft:cobbled_deepslate
fill 483 177 315 483 180 315 minecraft:deepslate_tiles
fill 484 177 314 484 178 314 minecraft:deepslate_tiles
setblock 486 177 276 minecraft:cobbled_deepslate
setblock 486 177 316 minecraft:cobbled_deepslate
fill 487 177 276 487 180 276 minecraft:deepslate_tiles
setblock 487 177 315 minecraft:cobbled_deepslate
fill 487 177 316 487 179 316 minecraft:deepslate_tiles
setblock 491 177 316 minecraft:cobbled_deepslate
fill 492 177 276 495 177 276 minecraft:deepslate_tiles
fill 492 177 316 495 177 316 minecraft:deepslate_tiles
setblock 496 177 276 minecraft:cobbled_deepslate
fill 496 177 277 496 180 277 minecraft:deepslate_tiles
setblock 496 177 315 minecraft:deepslate_tiles
setblock 496 177 316 minecraft:cobbled_deepslate
fill 497 177 276 497 180 276 minecraft:deepslate_tiles
setblock 497 177 315 minecraft:cobbled_deepslate
fill 497 177 316 497 180 316 minecraft:deepslate_tiles
setblock 498 177 278 minecraft:deepslate_tiles
fill 498 177 315 498 180 315 minecraft:deepslate_tiles
setblock 499 177 278 minecraft:cobbled_deepslate
fill 499 177 314 499 178 314 minecraft:deepslate_tiles
setblock 500 177 276 minecraft:deepslate_tiles
setblock 500 177 277 minecraft:cobbled_deepslate
fill 500 177 278 503 177 278 minecraft:deepslate_tiles
setblock 501 177 276 minecraft:cobbled_deepslate
fill 501 177 277 501 180 277 minecraft:deepslate_tiles
setblock 501 177 316 minecraft:cobbled_deepslate
fill 502 177 276 502 180 276 minecraft:deepslate_tiles
setblock 502 177 315 minecraft:cobbled_deepslate
fill 502 177 316 502 180 316 minecraft:deepslate_tiles
setblock 503 177 314 minecraft:cobbled_deepslate
fill 503 177 315 503 180 315 minecraft:deepslate_tiles
setblock 504 177 278 minecraft:cobbled_deepslate
fill 504 177 314 505 177 314 minecraft:deepslate_tiles
setblock 505 177 277 minecraft:cobbled_deepslate
fill 505 177 278 505 180 278 minecraft:deepslate_tiles
setblock 506 177 276 minecraft:cobbled_deepslate
fill 506 177 277 506 180 277 minecraft:deepslate_tiles
setblock 506 177 316 minecraft:cobbled_deepslate
fill 507 177 276 507 180 276 minecraft:deepslate_tiles
setblock 507 177 315 minecraft:cobbled_deepslate
fill 507 177 316 507 180 316 minecraft:deepslate_tiles
fill 508 177 315 508 180 315 minecraft:deepslate_tiles
setblock 510 177 277 minecraft:cobbled_deepslate
fill 510 177 278 510 180 278 minecraft:deepslate_tiles
setblock 510 177 313 minecraft:deepslate_tiles
setblock 511 177 276 minecraft:cobbled_deepslate
fill 511 177 277 511 180 277 minecraft:deepslate_tiles
setblock 511 177 291 minecraft:cobbled_deepslate
setblock 511 177 292 minecraft:deepslate_tiles
setblock 511 177 311 minecraft:cobbled_deepslate
fill 511 177 312 511 180 312 minecraft:deepslate_tiles
setblock 511 177 316 minecraft:cobbled_deepslate
setblock 512 177 276 minecraft:white_wool
fill 512 177 285 512 201 285 minecraft:black_concrete
fill 470 178 279 470 201 280 minecraft:black_concrete
setblock 470 178 281 minecraft:white_wool
fill 470 178 291 470 198 291 minecraft:black_concrete
fill 471 178 276 474 178 276 minecraft:deepslate_tiles
fill 471 178 293 471 178 294 minecraft:deepslate_tiles
setblock 471 178 295 minecraft:cobbled_deepslate
fill 471 178 296 471 181 296 minecraft:deepslate_tiles
fill 471 178 298 471 178 299 minecraft:deepslate_tiles
setblock 471 178 310 minecraft:cobbled_deepslate
fill 471 178 311 471 181 311 minecraft:deepslate_tiles
setblock 471 178 314 minecraft:deepslate_tiles
setblock 471 178 315 minecraft:cobbled_deepslate
fill 471 178 316 474 178 316 minecraft:deepslate_tiles
setblock 472 178 314 minecraft:cobbled_deepslate
fill 472 178 315 472 181 315 minecraft:deepslate_tiles
setblock 473 178 313 minecraft:cobbled_deepslate
fill 473 178 314 473 179 314 minecraft:deepslate_tiles
setblock 475 178 276 minecraft:cobbled_deepslate
fill 475 178 277 478 178 277 minecraft:deepslate_tiles
setblock 475 178 316 minecraft:cobbled_deepslate
fill 476 178 276 479 178 276 minecraft:deepslate_tiles
setblock 476 178 315 minecraft:cobbled_deepslate
fill 476 178 316 476 181 316 minecraft:deepslate_tiles
setblock 477 178 313 minecraft:deepslate_tiles
setblock 477 178 314 minecraft:cobbled_deepslate
fill 477 178 315 477 181 315 minecraft:deepslate_tiles
setblock 478 178 313 minecraft:cobbled_deepslate
fill 478 178 314 478 181 314 minecraft:deepslate_tiles
setblock 479 178 277 minecraft:cobbled_deepslate
setblock 479 178 313 minecraft:deepslate_tiles
setblock 480 178 276 minecraft:cobbled_deepslate
fill 480 178 277 480 181 277 minecraft:deepslate_tiles
setblock 480 178 316 minecraft:cobbled_deepslate
fill 481 178 276 481 181 276 minecraft:deepslate_tiles
setblock 481 178 315 minecraft:cobbled_deepslate
fill 481 178 316 481 181 316 minecraft:deepslate_tiles
setblock 482 178 314 minecraft:cobbled_deepslate
fill 482 178 315 482 181 315 minecraft:deepslate_tiles
fill 483 178 314 483 179 314 minecraft:deepslate_tiles
setblock 485 178 276 minecraft:cobbled_deepslate
setblock 485 178 316 minecraft:cobbled_deepslate
fill 486 178 276 486 180 276 minecraft:deepslate_tiles
setblock 486 178 315 minecraft:cobbled_deepslate
fill 486 178 316 486 180 316 minecraft:deepslate_tiles
fill 488 178 276 488 179 276 minecraft:deepslate_tiles
setblock 489 178 316 minecraft:deepslate_tiles
setblock 490 178 316 minecraft:cobbled_deepslate
fill 491 178 276 494 178 276 minecraft:deepslate_tiles
fill 491 178 316 494 178 316 minecraft:deepslate_tiles
setblock 495 178 276 minecraft:cobbled_deepslate
fill 495 178 277 495 181 277 minecraft:deepslate_tiles
setblock 495 178 316 minecraft:cobbled_deepslate
fill 496 178 276 496 181 276 minecraft:deepslate_tiles
setblock 496 178 315 minecraft:cobbled_deepslate
fill 496 178 316 496 181 316 minecraft:deepslate_tiles
setblock 497 178 278 minecraft:deepslate_tiles
fill 497 178 315 497 181 315 minecraft:deepslate_tiles
setblock 498 178 277 minecraft:deepslate_tiles
setblock 498 178 278 minecraft:cobbled_deepslate
setblock 499 178 277 minecraft:cobbled_deepslate
fill 499 178 278 502 178 278 minecraft:deepslate_tiles
setblock 500 178 276 minecraft:cobbled_deepslate
fill 500 178 277 500 181 277 minecraft:deepslate_tiles
setblock 500 178 316 minecraft:cobbled_deepslate
fill 501 178 276 501 181 276 minecraft:deepslate_tiles
setblock 501 178 279 minecraft:deepslate_tiles
setblock 501 178 314 minecraft:deepslate_tiles
setblock 501 178 315 minecraft:cobbled_deepslate
fill 501 178 316 501 181 316 minecraft:deepslate_tiles
setblock 502 178 314 minecraft:cobbled_deepslate
fill 502 178 315 502 181 315 minecraft:deepslate_tiles
setblock 503 178 278 minecraft:cobbled_deepslate
fill 503 178 314 504 178 314 minecraft:deepslate_tiles
setblock 504 178 277 minecraft:cobbled_deepslate
fill 504 178 278 504 181 278 minecraft:deepslate_tiles
setblock 505 178 276 minecraft:cobbled_deepslate
fill 505 178 277 505 181 277 minecraft:deepslate_tiles
setblock 505 178 316 minecraft:cobbled_deepslate
fill 506 178 276 506 181 276 minecraft:deepslate_tiles
setblock 506 178 315 minecraft:cobbled_deepslate
fill 506 178 316 506 181 316 minecraft:deepslate_tiles
fill 507 178 315 507 180 315 minecraft:deepslate_tiles
setblock 508 178 277 minecraft:deepslate_tiles
setblock 509 178 277 minecraft:cobbled_deepslate
setblock 510 178 276 minecraft:cobbled_deepslate
fill 510 178 277 510 181 277 minecraft:deepslate_tiles
setblock 510 178 316 minecraft:cobbled_deepslate
fill 511 178 276 511 181 276 minecraft:deepslate_tiles
setblock 511 178 280 minecraft:cobbled_deepslate
setblock 511 178 295 minecraft:cobbled_deepslate
setblock 511 178 296 minecraft:deepslate_tiles
setblock 511 178 311 minecraft:deepslate_tiles
setblock 511 178 315 minecraft:cobbled_deepslate
fill 511 178 316 511 181 316 minecraft:deepslate_tiles
fill 512 178 276 512 201 276 minecraft:black_concrete
fill 470 179 281 470 201 281 minecraft:black_concrete
setblock 470 179 316 minecraft:white_wool
fill 471 179 276 473 179 276 minecraft:deepslate_tiles
setblock 471 179 294 minecraft:cobbled_deepslate
fill 471 179 295 471 182 295 minecraft:deepslate_tiles
setblock 471 179 298 minecraft:deepslate_tiles
setblock 471 179 299 minecraft:cobbled_deepslate
fill 471 179 300 471 181 301 minecraft:deepslate_tiles
setblock 471 179 309 minecraft:cobbled_deepslate
fill 471 179 310 471 181 310 minecraft:deepslate_tiles
setblock 471 179 314 minecraft:cobbled_deepslate
fill 471 179 315 471 181 316 minecraft:deepslate_tiles
setblock 472 179 313 minecraft:cobbled_deepslate
fill 472 179 314 472 182 314 minecraft:deepslate_tiles
fill 472 179 316 473 179 316 minecraft:deepslate_tiles
setblock 474 179 276 minecraft:cobbled_deepslate
fill 474 179 277 477 179 277 minecraft:deepslate_tiles
fill 474 179 283 474 190 283 minecraft:white_wool
setblock 474 179 316 minecraft:cobbled_deepslate
fill 475 179 276 478 179 276 minecraft:deepslate_tiles
setblock 475 179 312 minecraft:white_wool
setblock 475 179 315 minecraft:cobbled_deepslate
fill 475 179 316 475 182 316 minecraft:deepslate_tiles
setblock 476 179 313 minecraft:white_wool
setblock 476 179 314 minecraft:cobbled_deepslate
fill 476 179 315 476 182 315 minecraft:deepslate_tiles
setblock 477 179 314 minecraft:white_wool
setblock 478 179 277 minecraft:cobbled_deepslate
setblock 478 179 315 minecraft:white_wool
setblock 479 179 276 minecraft:cobbled_deepslate
fill 479 179 277 479 182 277 minecraft:deepslate_tiles
setblock 479 179 316 minecraft:cobbled_deepslate
fill 480 179 276 480 182 276 minecraft:deepslate_tiles
setblock 480 179 315 minecraft:cobbled_deepslate
fill 480 179 316 480 182 316 minecraft:deepslate_tiles
setblock 481 179 275 minecraft:redstone_block
setblock 481 179 314 minecraft:cobbled_deepslate
fill 481 179 315 481 182 315 minecraft:deepslate_tiles
fill 482 179 275 484 198 275 minecraft:black_concrete
setblock 482 179 314 minecraft:deepslate_tiles
setblock 483 179 277 minecraft:cobbled_deepslate
setblock 484 179 276 minecraft:cobbled_deepslate
setblock 484 179 316 minecraft:cobbled_deepslate
fill 485 179 276 485 181 276 minecraft:deepslate_tiles
setblock 485 179 315 minecraft:cobbled_deepslate
fill 485 179 316 485 181 316 minecraft:deepslate_tiles
setblock 489 179 276 minecraft:cobbled_deepslate
fill 490 179 276 493 179 276 minecraft:deepslate_tiles
fill 492 179 316 493 179 316 minecraft:deepslate_tiles
setblock 494 179 276 minecraft:cobbled_deepslate
fill 494 179 277 494 182 277 minecraft:deepslate_tiles
setblock 494 179 316 minecraft:cobbled_deepslate
fill 495 179 276 495 182 276 minecraft:deepslate_tiles
fill 495 179 316 495 182 316 minecraft:deepslate_tiles
setblock 496 179 278 minecraft:deepslate_tiles
fill 496 179 315 496 180 315 minecraft:deepslate_tiles
setblock 497 179 278 minecraft:cobbled_deepslate
setblock 498 179 277 minecraft:cobbled_deepslate
fill 498 179 278 501 179 278 minecraft:deepslate_tiles
setblock 499 179 276 minecraft:cobbled_deepslate
fill 499 179 277 499 182 277 minecraft:deepslate_tiles
fill 499 179 279 500 179 279 minecraft:deepslate_tiles
setblock 499 179 316 minecraft:cobbled_deepslate
fill 500 179 276 500 182 276 minecraft:deepslate_tiles
setblock 500 179 315 minecraft:cobbled_deepslate
fill 500 179 316 500 182 316 minecraft:deepslate_tiles
setblock 501 179 279 minecraft:cobbled_deepslate
setblock 501 179 314 minecraft:cobbled_deepslate
fill 501 179 315 501 182 315 minecraft:deepslate_tiles
setblock 502 179 278 minecraft:cobbled_deepslate
setblock 502 179 279 minecraft:deepslate_tiles
setblock 503 179 277 minecraft:cobbled_deepslate
fill 503 179 278 503 182 278 minecraft:deepslate_tiles
setblock 504 179 276 minecraft:cobbled_deepslate
fill 504 179 277 504 182 277 minecraft:deepslate_tiles
setblock 504 179 316 minecraft:cobbled_deepslate
fill 505 179 276 505 182 276 minecraft:deepslate_tiles
setblock 505 179 315 minecraft:cobbled_deepslate
fill 505 179 316 505 182 316 minecraft:deepslate_tiles
fill 506 179 315 506 180 315 minecraft:deepslate_tiles
setblock 508 179 277 minecraft:cobbled_deepslate
setblock 509 179 276 minecraft:cobbled_deepslate
fill 509 179 277 509 182 277 minecraft:deepslate_tiles
fill 509 179 311 509 184 311 minecraft:black_concrete
setblock 509 179 316 minecraft:cobbled_deepslate
fill 510 179 276 510 182 276 minecraft:deepslate_tiles
setblock 510 179 315 minecraft:cobbled_deepslate
fill 510 179 316 510 182 316 minecraft:deepslate_tiles
setblock 511 179 279 minecraft:cobbled_deepslate
fill 511 179 280 511 182 280 minecraft:deepslate_tiles
setblock 511 179 314 minecraft:cobbled_deepslate
fill 511 179 315 511 182 315 minecraft:deepslate_tiles
fill 470 180 316 470 201 316 minecraft:black_concrete
fill 471 180 276 471 180 277 minecraft:deepslate_tiles
setblock 471 180 278 minecraft:cobbled_deepslate
setblock 471 180 294 minecraft:deepslate_tiles
setblock 471 180 298 minecraft:cobbled_deepslate
fill 471 180 299 471 183 299 minecraft:deepslate_tiles
setblock 471 180 302 minecraft:deepslate_tiles
setblock 471 180 308 minecraft:white_wool
setblock 471 180 309 minecraft:deepslate_tiles
setblock 471 180 313 minecraft:cobbled_deepslate
fill 471 180 314 471 183 314 minecraft:deepslate_tiles
setblock 472 180 276 minecraft:deepslate_tiles
setblock 472 180 297 minecraft:cobbled_deepslate
fill 472 180 298 472 183 298 minecraft:deepslate_tiles
setblock 472 180 309 minecraft:white_wool
setblock 472 180 312 minecraft:cobbled_deepslate
fill 472 180 313 472 181 313 minecraft:deepslate_tiles
setblock 472 180 316 minecraft:deepslate_tiles
setblock 473 180 276 minecraft:cobbled_deepslate
setblock 473 180 310 minecraft:white_wool
setblock 473 180 316 minecraft:cobbled_deepslate
fill 474 180 276 476 180 277 minecraft:deepslate_tiles
setblock 474 180 311 minecraft:white_wool
setblock 474 180 315 minecraft:cobbled_deepslate
fill 474 180 316 474 183 316 minecraft:deepslate_tiles
setblock 475 180 314 minecraft:cobbled_deepslate
fill 475 180 315 475 183 315 minecraft:deepslate_tiles
fill 476 180 314 477 181 314 minecraft:deepslate_tiles
setblock 477 180 276 minecraft:deepslate_tiles
setblock 477 180 277 minecraft:cobbled_deepslate
setblock 478 180 276 minecraft:cobbled_deepslate
fill 478 180 277 478 183 277 minecraft:deepslate_tiles
setblock 478 180 315 minecraft:deepslate_tiles
setblock 478 180 316 minecraft:cobbled_deepslate
fill 479 180 276 479 183 276 minecraft:deepslate_tiles
setblock 479 180 315 minecraft:cobbled_deepslate
fill 479 180 316 479 183 316 minecraft:deepslate_tiles
setblock 480 180 314 minecraft:cobbled_deepslate
fill 480 180 315 480 182 315 minecraft:deepslate_tiles
fill 481 180 275 481 201 275 minecraft:black_concrete
setblock 481 180 314 minecraft:deepslate_tiles
setblock 482 180 277 minecraft:cobbled_deepslate
setblock 483 180 276 minecraft:cobbled_deepslate
setblock 483 180 316 minecraft:cobbled_deepslate
fill 484 180 276 484 182 276 minecraft:deepslate_tiles
setblock 484 180 315 minecraft:cobbled_deepslate
fill 484 180 316 484 181 316 minecraft:deepslate_tiles
fill 490 180 276 492 180 276 minecraft:deepslate_tiles
setblock 493 180 276 minecraft:cobbled_deepslate
fill 493 180 277 493 183 277 minecraft:deepslate_tiles
setblock 493 180 316 minecraft:cobbled_deepslate
fill 494 180 276 494 183 276 minecraft:deepslate_tiles
fill 494 180 316 494 183 316 minecraft:deepslate_tiles
setblock 495 180 278 minecraft:deepslate_tiles
setblock 496 180 278 minecraft:cobbled_deepslate
setblock 497 180 277 minecraft:cobbled_deepslate
fill 497 180 278 500 180 278 minecraft:deepslate_tiles
setblock 498 180 276 minecraft:cobbled_deepslate
fill 498 180 277 498 183 277 minecraft:deepslate_tiles
setblock 498 180 316 minecraft:cobbled_deepslate
fill 499 180 276 499 183 276 minecraft:deepslate_tiles
setblock 499 180 279 minecraft:deepslate_tiles
setblock 499 180 315 minecraft:cobbled_deepslate
fill 499 180 316 499 183 316 minecraft:deepslate_tiles
setblock 500 180 279 minecraft:cobbled_deepslate
fill 500 180 315 500 182 315 minecraft:deepslate_tiles
setblock 501 180 278 minecraft:cobbled_deepslate
fill 501 180 279 501 181 279 minecraft:deepslate_tiles
setblock 502 180 277 minecraft:cobbled_deepslate
fill 502 180 278 502 183 278 minecraft:deepslate_tiles
setblock 503 180 276 minecraft:cobbled_deepslate
fill 503 180 277 503 183 277 minecraft:deepslate_tiles
setblock 503 180 316 minecraft:cobbled_deepslate
fill 504 180 276 504 183 276 minecraft:deepslate_tiles
setblock 504 180 315 minecraft:cobbled_deepslate
fill 504 180 316 504 183 316 minecraft:deepslate_tiles
setblock 505 180 315 minecraft:deepslate_tiles
fill 506 180 275 506 199 275 minecraft:black_concrete
fill 506 180 278 506 183 278 minecraft:cobbled_deepslate
setblock 507 180 275 minecraft:white_wool
setblock 507 180 277 minecraft:cobbled_deepslate
setblock 508 180 276 minecraft:cobbled_deepslate
fill 508 180 277 508 183 277 minecraft:deepslate_tiles
setblock 508 180 316 minecraft:cobbled_deepslate
fill 509 180 276 509 183 276 minecraft:deepslate_tiles
setblock 509 180 315 minecraft:cobbled_deepslate
fill 509 180 316 509 183 316 minecraft:deepslate_tiles
setblock 510 180 315 minecraft:deepslate_tiles
setblock 511 180 278 minecraft:cobbled_deepslate
fill 511 180 279 511 183 279 minecraft:deepslate_tiles
fill 511 180 281 511 181 281 minecraft:deepslate_tiles
setblock 511 180 313 minecraft:cobbled_deepslate
fill 511 180 314 511 183 314 minecraft:deepslate_tiles
setblock 471 181 276 minecraft:deepslate_tiles
setblock 471 181 277 minecraft:cobbled_deepslate
fill 471 181 278 471 184 278 minecraft:deepslate_tiles
setblock 471 181 297 minecraft:cobbled_deepslate
fill 471 181 298 471 184 298 minecraft:deepslate_tiles
setblock 471 181 302 minecraft:cobbled_deepslate
fill 471 181 303 471 183 304 minecraft:deepslate_tiles
setblock 471 181 312 minecraft:cobbled_deepslate
fill 471 181 313 471 184 313 minecraft:deepslate_tiles
setblock 472 181 276 minecraft:cobbled_deepslate
fill 472 181 297 472 184 297 minecraft:deepslate_tiles
fill 472 181 299 472 181 300 minecraft:deepslate_tiles
setblock 472 181 316 minecraft:cobbled_deepslate
fill 473 181 276 476 181 276 minecraft:deepslate_tiles
setblock 473 181 278 minecraft:light[level=13]
setblock 473 181 285 minecraft:light[level=12]
setblock 473 181 286 minecraft:light[level=13]
setblock 473 181 292 minecraft:light[level=12]
setblock 473 181 294 minecraft:light[level=13]
setblock 473 181 299 minecraft:light[level=12]
setblock 473 181 302 minecraft:light[level=13]
setblock 473 181 306 minecraft:light[level=12]
setblock 473 181 310 minecraft:light[level=13]
setblock 473 181 313 minecraft:light[level=12]
setblock 473 181 315 minecraft:cobbled_deepslate
fill 473 181 316 473 184 316 minecraft:deepslate_tiles
setblock 474 181 275 minecraft:redstone_block
fill 474 181 277 475 181 277 minecraft:deepslate_tiles
fill 474 181 315 474 184 315 minecraft:deepslate_tiles
fill 475 181 275 475 201 275 minecraft:black_concrete
setblock 475 181 314 minecraft:deepslate_tiles
setblock 476 181 277 minecraft:cobbled_deepslate
setblock 477 181 276 minecraft:cobbled_deepslate
fill 477 181 277 477 184 277 minecraft:deepslate_tiles
setblock 477 181 316 minecraft:cobbled_deepslate
fill 478 181 276 478 184 276 minecraft:deepslate_tiles
setblock 478 181 315 minecraft:cobbled_deepslate
fill 478 181 316 478 184 316 minecraft:deepslate_tiles
setblock 479 181 314 minecraft:cobbled_deepslate
fill 479 181 315 479 183 315 minecraft:deepslate_tiles
setblock 480 181 278 minecraft:light[level=12]
setblock 480 181 285 minecraft:light[level=12]
setblock 480 181 292 minecraft:light[level=12]
setblock 480 181 299 minecraft:light[level=12]
setblock 480 181 306 minecraft:light[level=12]
setblock 480 181 313 minecraft:light[level=12]
setblock 481 181 277 minecraft:cobbled_deepslate
setblock 481 181 278 minecraft:light[level=13]
setblock 481 181 286 minecraft:light[level=13]
setblock 481 181 294 minecraft:light[level=13]
setblock 481 181 302 minecraft:light[level=13]
setblock 481 181 310 minecraft:light[level=13]
setblock 482 181 276 minecraft:cobbled_deepslate
setblock 482 181 277 minecraft:deepslate_tiles
setblock 482 181 316 minecraft:cobbled_deepslate
fill 483 181 276 483 183 276 minecraft:deepslate_tiles
fill 483 181 316 483 182 316 minecraft:deepslate_tiles
setblock 487 181 278 minecraft:light[level=12]
setblock 487 181 285 minecraft:light[level=12]
setblock 487 181 292 minecraft:light[level=12]
setblock 487 181 299 minecraft:light[level=12]
setblock 487 181 306 minecraft:light[level=12]
setblock 487 181 313 minecraft:light[level=12]
setblock 489 181 278 minecraft:light[level=13]
setblock 489 181 286 minecraft:light[level=13]
setblock 489 181 294 minecraft:light[level=13]
setblock 489 181 302 minecraft:light[level=13]
setblock 489 181 310 minecraft:light[level=13]
fill 490 181 276 491 181 276 minecraft:deepslate_tiles
setblock 492 181 276 minecraft:cobbled_deepslate
fill 493 181 276 493 184 276 minecraft:deepslate_tiles
setblock 493 181 316 minecraft:deepslate_tiles
setblock 494 181 278 minecraft:light[level=12]
setblock 494 181 285 minecraft:light[level=12]
setblock 494 181 292 minecraft:light[level=12]
setblock 494 181 299 minecraft:light[level=12]
setblock 494 181 306 minecraft:light[level=12]
setblock 494 181 313 minecraft:light[level=12]
setblock 495 181 278 minecraft:cobbled_deepslate
setblock 496 181 277 minecraft:cobbled_deepslate
fill 496 181 278 499 181 278 minecraft:deepslate_tiles
setblock 497 181 276 minecraft:cobbled_deepslate
fill 497 181 277 497 184 277 minecraft:deepslate_tiles
setblock 497 181 286 minecraft:light[level=13]
setblock 497 181 294 minecraft:light[level=13]
setblock 497 181 302 minecraft:light[level=13]
setblock 497 181 310 minecraft:light[level=13]
setblock 497 181 316 minecraft:cobbled_deepslate
fill 498 181 276 498 184 276 minecraft:deepslate_tiles
setblock 498 181 279 minecraft:deepslate_tiles
setblock 498 181 315 minecraft:cobbled_deepslate
fill 498 181 316 498 184 316 minecraft:deepslate_tiles
setblock 499 181 279 minecraft:cobbled_deepslate
fill 499 181 315 499 182 315 minecraft:deepslate_tiles
setblock 500 181 278 minecraft:cobbled_deepslate
fill 500 181 279 500 182 279 minecraft:deepslate_tiles
setblock 501 181 277 minecraft:cobbled_deepslate
fill 501 181 278 501 184 278 minecraft:deepslate_tiles
setblock 501 181 285 minecraft:light[level=12]
setblock 501 181 292 minecraft:light[level=12]
setblock 501 181 299 minecraft:light[level=12]
setblock 501 181 306 minecraft:light[level=12]
setblock 501 181 313 minecraft:light[level=12]
setblock 502 181 276 minecraft:cobbled_deepslate
fill 502 181 277 502 184 277 minecraft:deepslate_tiles
setblock 502 181 316 minecraft:cobbled_deepslate
fill 503 181 276 503 184 276 minecraft:deepslate_tiles
setblock 503 181 315 minecraft:cobbled_deepslate
fill 503 181 316 503 184 316 minecraft:deepslate_tiles
setblock 504 181 315 minecraft:deepslate_tiles
setblock 505 181 278 minecraft:cobbled_deepslate
setblock 505 181 286 minecraft:light[level=13]
setblock 505 181 294 minecraft:light[level=13]
setblock 505 181 302 minecraft:light[level=13]
setblock 505 181 310 minecraft:light[level=13]
setblock 506 181 277 minecraft:cobbled_deepslate
fill 507 181 275 507 201 275 minecraft:black_concrete
setblock 507 181 276 minecraft:cobbled_deepslate
fill 507 181 277 507 184 277 minecraft:deepslate_tiles
setblock 507 181 316 minecraft:cobbled_deepslate
fill 508 181 276 508 184 276 minecraft:deepslate_tiles
setblock 508 181 278 minecraft:light[level=12]
setblock 508 181 285 minecraft:light[level=12]
setblock 508 181 292 minecraft:light[level=12]
setblock 508 181 299 minecraft:light[level=12]
setblock 508 181 306 minecraft:light[level=12]
setblock 508 181 313 minecraft:light[level=12]
fill 508 181 316 508 184 316 minecraft:deepslate_tiles
setblock 510 181 278 minecraft:cobbled_deepslate
setblock 511 181 277 minecraft:cobbled_deepslate
fill 511 181 278 511 184 278 minecraft:deepslate_tiles
fill 511 181 313 511 182 313 minecraft:deepslate_tiles
setblock 471 182 276 minecraft:cobbled_deepslate
fill 471 182 277 471 185 277 minecraft:deepslate_tiles
setblock 471 182 296 minecraft:cobbled_deepslate
fill 471 182 297 471 185 297 minecraft:deepslate_tiles
setblock 471 182 300 minecraft:deepslate_tiles
setblock 471 182 301 minecraft:cobbled_deepslate
fill 471 182 302 472 184 302 minecraft:deepslate_tiles
setblock 471 182 305 minecraft:deepslate_tiles
setblock 471 182 311 minecraft:cobbled_deepslate
fill 471 182 312 471 183 312 minecraft:deepslate_tiles
setblock 471 182 315 minecraft:deepslate_tiles
setblock 471 182 316 minecraft:cobbled_deepslate
fill 472 182 276 475 182 276 minecraft:deepslate_tiles
setblock 472 182 299 minecraft:deepslate_tiles
setblock 472 182 300 minecraft:cobbled_deepslate
fill 472 182 301 472 185 301 minecraft:deepslate_tiles
setblock 472 182 315 minecraft:cobbled_deepslate
fill 472 182 316 472 185 316 minecraft:deepslate_tiles
fill 473 182 315 473 183 315 minecraft:deepslate_tiles
fill 474 182 275 474 201 275 minecraft:black_concrete
setblock 474 182 277 minecraft:deepslate_tiles
setblock 475 182 277 minecraft:cobbled_deepslate
setblock 476 182 276 minecraft:cobbled_deepslate
fill 476 182 277 476 185 277 minecraft:deepslate_tiles
setblock 476 182 316 minecraft:cobbled_deepslate
fill 477 182 276 477 185 276 minecraft:deepslate_tiles
setblock 477 182 315 minecraft:cobbled_deepslate
fill 477 182 316 477 185 316 minecraft:deepslate_tiles
fill 478 182 315 478 183 315 minecraft:deepslate_tiles
setblock 480 182 277 minecraft:cobbled_deepslate
setblock 481 182 276 minecraft:cobbled_deepslate
setblock 481 182 316 minecraft:cobbled_deepslate
fill 482 182 276 482 183 276 minecraft:deepslate_tiles
fill 482 182 316 482 183 316 minecraft:deepslate_tiles
setblock 490 182 276 minecraft:deepslate_tiles
setblock 491 182 276 minecraft:cobbled_deepslate
fill 492 182 276 492 185 276 minecraft:deepslate_tiles
setblock 495 182 277 minecraft:cobbled_deepslate
fill 495 182 278 498 182 278 minecraft:deepslate_tiles
setblock 496 182 275 minecraft:white_wool
setblock 496 182 276 minecraft:cobbled_deepslate
fill 496 182 277 496 185 277 minecraft:deepslate_tiles
setblock 496 182 316 minecraft:cobbled_deepslate
fill 497 182 275 504 197 275 minecraft:black_concrete
fill 497 182 276 497 185 276 minecraft:deepslate_tiles
fill 497 182 316 497 185 316 minecraft:deepslate_tiles
setblock 498 182 279 minecraft:cobbled_deepslate
setblock 498 182 315 minecraft:deepslate_tiles
setblock 499 182 278 minecraft:cobbled_deepslate
fill 499 182 279 499 185 279 minecraft:deepslate_tiles
setblock 500 182 277 minecraft:cobbled_deepslate
fill 500 182 278 500 185 278 minecraft:deepslate_tiles
setblock 501 182 276 minecraft:cobbled_deepslate
fill 501 182 277 501 185 277 minecraft:deepslate_tiles
setblock 501 182 316 minecraft:cobbled_deepslate
fill 502 182 276 502 185 276 minecraft:deepslate_tiles
fill 502 182 316 502 185 316 minecraft:deepslate_tiles
setblock 504 182 278 minecraft:cobbled_deepslate
setblock 505 182 277 minecraft:cobbled_deepslate
setblock 506 182 276 minecraft:cobbled_deepslate
fill 506 182 277 506 184 277 minecraft:deepslate_tiles
setblock 506 182 316 minecraft:cobbled_deepslate
fill 507 182 276 507 185 276 minecraft:deepslate_tiles
fill 507 182 316 507 183 316 minecraft:deepslate_tiles
fill 508 182 311 508 184 311 minecraft:black_concrete
fill 509 182 310 509 184 310 minecraft:black_concrete
fill 509 182 312 509 184 312 minecraft:black_concrete
setblock 510 182 277 minecraft:cobbled_deepslate
fill 510 182 278 510 185 278 minecraft:deepslate_tiles
fill 510 182 311 510 184 311 minecraft:black_concrete
setblock 511 182 276 minecraft:cobbled_deepslate
fill 511 182 277 511 185 277 minecraft:deepslate_tiles
setblock 511 182 281 minecraft:cobbled_deepslate
setblock 511 182 316 minecraft:cobbled_deepslate
fill 471 183 276 474 183 276 minecraft:deepslate_tiles
fill 471 183 296 471 186 296 minecraft:deepslate_tiles
setblock 471 183 300 minecraft:cobbled_deepslate
fill 471 183 301 471 186 301 minecraft:deepslate_tiles
setblock 471 183 305 minecraft:cobbled_deepslate
fill 471 183 306 471 186 306 minecraft:deepslate_tiles
setblock 471 183 315 minecraft:cobbled_deepslate
fill 471 183 316 471 186 316 minecraft:deepslate_tiles
setblock 472 183 299 minecraft:cobbled_deepslate
fill 472 183 300 472 186 300 minecraft:deepslate_tiles
setblock 472 183 303 minecraft:deepslate_tiles
setblock 474 183 277 minecraft:cobbled_deepslate
setblock 475 183 276 minecraft:cobbled_deepslate
fill 475 183 277 475 186 277 minecraft:deepslate_tiles
setblock 475 183 316 minecraft:cobbled_deepslate
fill 476 183 276 476 186 276 minecraft:deepslate_tiles
setblock 476 183 315 minecraft:cobbled_deepslate
fill 476 183 316 476 186 316 minecraft:deepslate_tiles
fill 477 183 315 477 184 315 minecraft:deepslate_tiles
setblock 479 183 277 minecraft:cobbled_deepslate
setblock 480 183 276 minecraft:cobbled_deepslate
setblock 480 183 316 minecraft:cobbled_deepslate
fill 481 183 276 481 184 276 minecraft:deepslate_tiles
setblock 481 183 316 minecraft:deepslate_tiles
setblock 490 183 276 minecraft:cobbled_deepslate
fill 491 183 276 491 186 276 minecraft:deepslate_tiles
fill 492 183 277 492 184 277 minecraft:deepslate_tiles
setblock 494 183 277 minecraft:cobbled_deepslate
fill 494 183 278 497 183 278 minecraft:deepslate_tiles
setblock 495 183 276 minecraft:cobbled_deepslate
fill 495 183 277 495 186 277 minecraft:deepslate_tiles
setblock 495 183 316 minecraft:cobbled_deepslate
fill 496 183 275 496 185 275 minecraft:black_concrete
fill 496 183 276 496 186 276 minecraft:deepslate_tiles
fill 496 183 316 496 186 316 minecraft:deepslate_tiles
setblock 497 183 279 minecraft:cobbled_deepslate
setblock 498 183 278 minecraft:cobbled_deepslate
fill 498 183 279 498 186 279 minecraft:deepslate_tiles
setblock 499 183 277 minecraft:cobbled_deepslate
fill 499 183 278 499 186 278 minecraft:deepslate_tiles
setblock 500 183 276 minecraft:cobbled_deepslate
fill 500 183 277 500 186 277 minecraft:deepslate_tiles
setblock 500 183 316 minecraft:cobbled_deepslate
fill 501 183 276 501 186 276 minecraft:deepslate_tiles
fill 501 183 316 501 186 316 minecraft:deepslate_tiles
setblock 503 183 278 minecraft:cobbled_deepslate
setblock 504 183 277 minecraft:cobbled_deepslate
setblock 505 183 276 minecraft:cobbled_deepslate
fill 505 183 277 505 186 277 minecraft:deepslate_tiles
setblock 505 183 278 minecraft:cobbled_deepslate
setblock 505 183 316 minecraft:cobbled_deepslate
fill 506 183 276 506 186 276 minecraft:deepslate_tiles
setblock 506 183 316 minecraft:deepslate_tiles
setblock 507 183 278 minecraft:cobbled_deepslate
fill 508 183 310 508 184 310 minecraft:black_concrete
fill 508 183 312 508 184 312 minecraft:black_concrete
setblock 509 183 277 minecraft:cobbled_deepslate
setblock 510 183 276 minecraft:cobbled_deepslate
fill 510 183 277 510 186 277 minecraft:deepslate_tiles
fill 510 183 310 510 184 310 minecraft:black_concrete
fill 510 183 312 510 184 312 minecraft:black_concrete
setblock 510 183 316 minecraft:cobbled_deepslate
fill 511 183 276 511 186 276 minecraft:deepslate_tiles
setblock 511 183 280 minecraft:cobbled_deepslate
fill 511 183 281 511 186 281 minecraft:deepslate_tiles
setblock 511 183 315 minecraft:cobbled_deepslate
fill 511 183 316 511 186 316 minecraft:deepslate_tiles
fill 471 184 276 473 184 276 minecraft:deepslate_tiles
setblock 471 184 279 minecraft:cobbled_deepslate
setblock 471 184 299 minecraft:cobbled_deepslate
fill 471 184 300 471 187 300 minecraft:deepslate_tiles
setblock 471 184 303 minecraft:deepslate_tiles
setblock 471 184 304 minecraft:cobbled_deepslate
fill 471 184 305 472 186 305 minecraft:deepslate_tiles
schedule function dropper:buildpart/70_8 1t
