fill 291 287 500 291 288 500 minecraft:polished_blackstone_bricks
fill 291 287 502 291 288 502 minecraft:polished_blackstone_bricks
fill 291 287 504 291 288 504 minecraft:polished_blackstone_bricks
fill 292 287 499 292 288 499 minecraft:polished_blackstone_bricks
fill 292 287 501 292 288 501 minecraft:polished_blackstone_bricks
fill 292 287 503 292 288 503 minecraft:polished_blackstone_bricks
setblock 293 287 466 minecraft:light[level=14]
setblock 293 287 474 minecraft:light[level=14]
setblock 293 287 482 minecraft:light[level=14]
setblock 293 287 490 minecraft:light[level=14]
fill 293 287 500 293 288 500 minecraft:polished_blackstone_bricks
fill 293 287 502 293 288 502 minecraft:polished_blackstone_bricks
fill 293 287 504 293 288 504 minecraft:polished_blackstone_bricks
fill 294 287 499 294 288 499 minecraft:polished_blackstone_bricks
fill 294 287 501 294 288 501 minecraft:polished_blackstone_bricks
fill 294 287 503 294 288 503 minecraft:polished_blackstone_bricks
fill 295 287 500 295 288 500 minecraft:polished_blackstone_bricks
fill 295 287 502 295 288 502 minecraft:polished_blackstone_bricks
fill 295 287 504 295 288 504 minecraft:polished_blackstone_bricks
fill 296 287 499 296 288 499 minecraft:polished_blackstone_bricks
fill 296 287 501 296 288 501 minecraft:polished_blackstone_bricks
fill 296 287 503 296 288 503 minecraft:polished_blackstone_bricks
fill 297 287 500 297 288 500 minecraft:polished_blackstone_bricks
fill 297 287 502 297 288 502 minecraft:polished_blackstone_bricks
fill 297 287 504 297 288 504 minecraft:polished_blackstone_bricks
fill 298 287 499 298 288 499 minecraft:polished_blackstone_bricks
fill 298 287 501 298 288 501 minecraft:polished_blackstone_bricks
fill 298 287 503 298 288 503 minecraft:polished_blackstone_bricks
fill 299 287 500 299 288 500 minecraft:polished_blackstone_bricks
fill 299 287 502 299 288 502 minecraft:polished_blackstone_bricks
fill 299 287 504 299 288 504 minecraft:polished_blackstone_bricks
setblock 301 287 466 minecraft:light[level=14]
setblock 301 287 474 minecraft:light[level=14]
setblock 301 287 482 minecraft:light[level=14]
setblock 301 287 490 minecraft:light[level=14]
setblock 301 287 498 minecraft:light[level=14]
fill 308 287 465 308 288 465 minecraft:polished_blackstone_bricks
fill 308 287 467 308 288 467 minecraft:polished_blackstone_bricks
fill 309 287 464 309 288 464 minecraft:polished_blackstone_bricks
fill 309 287 466 309 288 466 minecraft:polished_blackstone_bricks
fill 309 287 468 309 288 468 minecraft:polished_blackstone_bricks
setblock 309 287 474 minecraft:light[level=14]
setblock 309 287 482 minecraft:light[level=14]
setblock 309 287 490 minecraft:light[level=14]
setblock 309 287 498 minecraft:light[level=14]
fill 310 287 465 310 288 465 minecraft:polished_blackstone_bricks
fill 310 287 467 310 288 467 minecraft:polished_blackstone_bricks
fill 311 287 464 311 288 464 minecraft:polished_blackstone_bricks
fill 311 287 466 311 288 466 minecraft:polished_blackstone_bricks
fill 311 287 468 311 288 468 minecraft:polished_blackstone_bricks
fill 312 287 465 312 288 465 minecraft:polished_blackstone_bricks
fill 312 287 467 312 288 467 minecraft:polished_blackstone_bricks
fill 313 287 463 313 291 463 minecraft:shroomlight
fill 313 287 464 313 288 464 minecraft:polished_blackstone_bricks
fill 313 287 466 313 288 466 minecraft:polished_blackstone_bricks
fill 313 287 468 313 288 468 minecraft:polished_blackstone_bricks
fill 314 287 465 314 288 465 minecraft:polished_blackstone_bricks
fill 314 287 467 314 288 467 minecraft:polished_blackstone_bricks
fill 314 287 469 314 288 469 minecraft:polished_blackstone_bricks
fill 315 287 464 315 288 464 minecraft:polished_blackstone_bricks
fill 315 287 466 315 288 466 minecraft:polished_blackstone_bricks
fill 315 287 468 315 288 468 minecraft:polished_blackstone_bricks
fill 315 287 470 315 288 470 minecraft:polished_blackstone_bricks
fill 316 287 465 316 288 465 minecraft:polished_blackstone_bricks
fill 316 287 467 316 288 467 minecraft:polished_blackstone_bricks
fill 316 287 469 316 288 469 minecraft:polished_blackstone_bricks
fill 317 287 464 317 288 464 minecraft:polished_blackstone_bricks
fill 317 287 466 317 288 466 minecraft:polished_blackstone_bricks
fill 317 287 468 317 288 468 minecraft:polished_blackstone_bricks
fill 317 287 470 317 288 470 minecraft:polished_blackstone_bricks
setblock 317 287 474 minecraft:light[level=14]
setblock 317 287 482 minecraft:light[level=14]
setblock 317 287 490 minecraft:light[level=14]
setblock 317 287 498 minecraft:light[level=14]
fill 318 287 465 318 288 465 minecraft:polished_blackstone_bricks
fill 318 287 467 318 288 467 minecraft:polished_blackstone_bricks
fill 318 287 469 318 288 469 minecraft:polished_blackstone_bricks
fill 319 287 464 319 288 464 minecraft:polished_blackstone_bricks
fill 319 287 466 319 288 466 minecraft:polished_blackstone_bricks
fill 319 287 468 319 288 468 minecraft:polished_blackstone_bricks
fill 319 287 470 319 288 470 minecraft:polished_blackstone_bricks
fill 320 287 465 320 288 465 minecraft:polished_blackstone_bricks
fill 320 287 467 320 288 467 minecraft:polished_blackstone_bricks
fill 320 287 469 320 288 469 minecraft:polished_blackstone_bricks
fill 321 287 464 321 288 464 minecraft:polished_blackstone_bricks
fill 321 287 466 321 288 466 minecraft:polished_blackstone_bricks
fill 321 287 468 321 288 468 minecraft:polished_blackstone_bricks
fill 321 287 470 321 288 470 minecraft:polished_blackstone_bricks
fill 322 287 465 322 288 465 minecraft:polished_blackstone_bricks
fill 322 287 467 322 288 467 minecraft:polished_blackstone_bricks
fill 322 287 469 322 288 469 minecraft:polished_blackstone_bricks
setblock 287 289 500 minecraft:shroomlight
setblock 287 289 502 minecraft:shroomlight
setblock 287 289 504 minecraft:shroomlight
setblock 288 289 499 minecraft:shroomlight
setblock 288 289 501 minecraft:shroomlight
setblock 288 289 503 minecraft:shroomlight
setblock 289 289 500 minecraft:shroomlight
setblock 289 289 502 minecraft:shroomlight
setblock 289 289 504 minecraft:shroomlight
setblock 290 289 499 minecraft:shroomlight
setblock 290 289 501 minecraft:shroomlight
setblock 290 289 503 minecraft:shroomlight
setblock 291 289 500 minecraft:shroomlight
setblock 291 289 502 minecraft:shroomlight
setblock 291 289 504 minecraft:shroomlight
setblock 292 289 499 minecraft:shroomlight
setblock 292 289 501 minecraft:shroomlight
setblock 292 289 503 minecraft:shroomlight
setblock 293 289 500 minecraft:shroomlight
setblock 293 289 502 minecraft:shroomlight
setblock 293 289 504 minecraft:shroomlight
setblock 294 289 499 minecraft:shroomlight
setblock 294 289 501 minecraft:shroomlight
setblock 294 289 503 minecraft:shroomlight
setblock 295 289 500 minecraft:shroomlight
setblock 295 289 502 minecraft:shroomlight
setblock 295 289 504 minecraft:shroomlight
setblock 296 289 499 minecraft:shroomlight
setblock 296 289 501 minecraft:shroomlight
setblock 296 289 503 minecraft:shroomlight
setblock 297 289 500 minecraft:shroomlight
setblock 297 289 502 minecraft:shroomlight
setblock 297 289 504 minecraft:shroomlight
setblock 298 289 499 minecraft:shroomlight
setblock 298 289 501 minecraft:shroomlight
setblock 298 289 503 minecraft:shroomlight
setblock 299 289 500 minecraft:shroomlight
setblock 299 289 502 minecraft:shroomlight
setblock 299 289 504 minecraft:shroomlight
setblock 308 289 465 minecraft:shroomlight
setblock 308 289 467 minecraft:shroomlight
setblock 309 289 464 minecraft:shroomlight
setblock 309 289 466 minecraft:shroomlight
setblock 309 289 468 minecraft:shroomlight
setblock 310 289 465 minecraft:shroomlight
setblock 310 289 467 minecraft:shroomlight
setblock 311 289 464 minecraft:shroomlight
setblock 311 289 466 minecraft:shroomlight
setblock 311 289 468 minecraft:shroomlight
setblock 312 289 465 minecraft:shroomlight
setblock 312 289 467 minecraft:shroomlight
setblock 313 289 464 minecraft:shroomlight
setblock 313 289 466 minecraft:shroomlight
setblock 313 289 468 minecraft:shroomlight
setblock 314 289 465 minecraft:shroomlight
setblock 314 289 467 minecraft:shroomlight
setblock 314 289 469 minecraft:shroomlight
setblock 315 289 464 minecraft:shroomlight
setblock 315 289 466 minecraft:shroomlight
setblock 315 289 468 minecraft:shroomlight
setblock 315 289 470 minecraft:shroomlight
setblock 316 289 465 minecraft:shroomlight
setblock 316 289 467 minecraft:shroomlight
setblock 316 289 469 minecraft:shroomlight
setblock 317 289 464 minecraft:shroomlight
setblock 317 289 466 minecraft:shroomlight
setblock 317 289 468 minecraft:shroomlight
setblock 317 289 470 minecraft:shroomlight
setblock 318 289 465 minecraft:shroomlight
setblock 318 289 467 minecraft:shroomlight
setblock 318 289 469 minecraft:shroomlight
setblock 319 289 464 minecraft:shroomlight
setblock 319 289 466 minecraft:shroomlight
setblock 319 289 468 minecraft:shroomlight
setblock 319 289 470 minecraft:shroomlight
setblock 320 289 465 minecraft:shroomlight
setblock 320 289 467 minecraft:shroomlight
setblock 320 289 469 minecraft:shroomlight
setblock 321 289 464 minecraft:shroomlight
setblock 321 289 466 minecraft:shroomlight
setblock 321 289 468 minecraft:shroomlight
setblock 321 289 470 minecraft:shroomlight
setblock 322 289 465 minecraft:shroomlight
setblock 322 289 467 minecraft:shroomlight
setblock 322 289 469 minecraft:shroomlight
fill 287 290 500 287 291 500 minecraft:polished_blackstone_bricks
fill 287 290 502 287 291 502 minecraft:polished_blackstone_bricks
fill 287 290 504 287 291 504 minecraft:polished_blackstone_bricks
fill 288 290 499 288 291 499 minecraft:polished_blackstone_bricks
fill 288 290 501 288 291 501 minecraft:polished_blackstone_bricks
fill 288 290 503 288 291 503 minecraft:polished_blackstone_bricks
fill 289 290 500 289 291 500 minecraft:polished_blackstone_bricks
fill 289 290 502 289 291 502 minecraft:polished_blackstone_bricks
fill 289 290 504 289 291 504 minecraft:polished_blackstone_bricks
fill 290 290 499 290 291 499 minecraft:polished_blackstone_bricks
fill 290 290 501 290 291 501 minecraft:polished_blackstone_bricks
fill 290 290 503 290 291 503 minecraft:polished_blackstone_bricks
fill 291 290 500 291 291 500 minecraft:polished_blackstone_bricks
fill 291 290 502 291 291 502 minecraft:polished_blackstone_bricks
fill 291 290 504 291 291 504 minecraft:polished_blackstone_bricks
fill 292 290 499 292 291 499 minecraft:polished_blackstone_bricks
fill 292 290 501 292 291 501 minecraft:polished_blackstone_bricks
fill 292 290 503 292 291 503 minecraft:polished_blackstone_bricks
fill 293 290 500 293 291 500 minecraft:polished_blackstone_bricks
fill 293 290 502 293 291 502 minecraft:polished_blackstone_bricks
fill 293 290 504 293 291 504 minecraft:polished_blackstone_bricks
fill 294 290 499 294 291 499 minecraft:polished_blackstone_bricks
fill 294 290 501 294 291 501 minecraft:polished_blackstone_bricks
fill 294 290 503 294 291 503 minecraft:polished_blackstone_bricks
fill 295 290 500 295 291 500 minecraft:polished_blackstone_bricks
fill 295 290 502 295 291 502 minecraft:polished_blackstone_bricks
fill 295 290 504 295 291 504 minecraft:polished_blackstone_bricks
fill 296 290 499 296 291 499 minecraft:polished_blackstone_bricks
fill 296 290 501 296 291 501 minecraft:polished_blackstone_bricks
fill 296 290 503 296 291 503 minecraft:polished_blackstone_bricks
fill 297 290 500 297 291 500 minecraft:polished_blackstone_bricks
fill 297 290 502 297 291 502 minecraft:polished_blackstone_bricks
fill 297 290 504 297 291 504 minecraft:polished_blackstone_bricks
fill 298 290 499 298 291 499 minecraft:polished_blackstone_bricks
fill 298 290 501 298 291 501 minecraft:polished_blackstone_bricks
fill 298 290 503 298 291 503 minecraft:polished_blackstone_bricks
fill 299 290 500 299 291 500 minecraft:polished_blackstone_bricks
fill 299 290 502 299 291 502 minecraft:polished_blackstone_bricks
fill 299 290 504 299 291 504 minecraft:polished_blackstone_bricks
fill 308 290 465 308 291 465 minecraft:polished_blackstone_bricks
fill 308 290 467 308 291 467 minecraft:polished_blackstone_bricks
fill 309 290 464 309 291 464 minecraft:polished_blackstone_bricks
fill 309 290 466 309 291 466 minecraft:polished_blackstone_bricks
fill 309 290 468 309 291 468 minecraft:polished_blackstone_bricks
fill 310 290 465 310 291 465 minecraft:polished_blackstone_bricks
fill 310 290 467 310 291 467 minecraft:polished_blackstone_bricks
fill 311 290 464 311 291 464 minecraft:polished_blackstone_bricks
fill 311 290 466 311 291 466 minecraft:polished_blackstone_bricks
fill 311 290 468 311 291 468 minecraft:polished_blackstone_bricks
fill 312 290 465 312 291 465 minecraft:polished_blackstone_bricks
fill 312 290 467 312 291 467 minecraft:polished_blackstone_bricks
fill 313 290 464 313 291 464 minecraft:polished_blackstone_bricks
fill 313 290 466 313 291 466 minecraft:polished_blackstone_bricks
fill 313 290 468 313 291 468 minecraft:polished_blackstone_bricks
fill 314 290 465 314 291 465 minecraft:polished_blackstone_bricks
fill 314 290 467 314 291 467 minecraft:polished_blackstone_bricks
fill 314 290 469 314 291 469 minecraft:polished_blackstone_bricks
fill 315 290 464 315 291 464 minecraft:polished_blackstone_bricks
fill 315 290 466 315 291 466 minecraft:polished_blackstone_bricks
fill 315 290 468 315 291 468 minecraft:polished_blackstone_bricks
fill 315 290 470 315 291 470 minecraft:polished_blackstone_bricks
fill 316 290 465 316 291 465 minecraft:polished_blackstone_bricks
fill 316 290 467 316 291 467 minecraft:polished_blackstone_bricks
fill 316 290 469 316 291 469 minecraft:polished_blackstone_bricks
fill 317 290 464 317 291 464 minecraft:polished_blackstone_bricks
fill 317 290 466 317 291 466 minecraft:polished_blackstone_bricks
fill 317 290 468 317 291 468 minecraft:polished_blackstone_bricks
fill 317 290 470 317 291 470 minecraft:polished_blackstone_bricks
fill 318 290 465 318 291 465 minecraft:polished_blackstone_bricks
fill 318 290 467 318 291 467 minecraft:polished_blackstone_bricks
fill 318 290 469 318 291 469 minecraft:polished_blackstone_bricks
fill 319 290 464 319 291 464 minecraft:polished_blackstone_bricks
fill 319 290 466 319 291 466 minecraft:polished_blackstone_bricks
fill 319 290 468 319 291 468 minecraft:polished_blackstone_bricks
fill 319 290 470 319 291 470 minecraft:polished_blackstone_bricks
fill 320 290 465 320 291 465 minecraft:polished_blackstone_bricks
fill 320 290 467 320 291 467 minecraft:polished_blackstone_bricks
fill 320 290 469 320 291 469 minecraft:polished_blackstone_bricks
fill 321 290 464 321 291 464 minecraft:polished_blackstone_bricks
fill 321 290 466 321 291 466 minecraft:polished_blackstone_bricks
fill 321 290 468 321 291 468 minecraft:polished_blackstone_bricks
fill 321 290 470 321 291 470 minecraft:polished_blackstone_bricks
fill 322 290 465 322 291 465 minecraft:polished_blackstone_bricks
fill 322 290 467 322 291 467 minecraft:polished_blackstone_bricks
fill 322 290 469 322 291 469 minecraft:polished_blackstone_bricks
fill 282 292 469 282 307 469 minecraft:red_nether_bricks
fill 282 292 470 282 292 471 minecraft:shroomlight
fill 282 292 472 282 307 472 minecraft:red_nether_bricks
fill 282 292 481 282 307 481 minecraft:red_nether_bricks
fill 282 292 482 282 292 483 minecraft:shroomlight
fill 282 292 484 282 307 484 minecraft:red_nether_bricks
fill 282 292 493 282 307 493 minecraft:red_nether_bricks
fill 282 292 494 282 292 495 minecraft:shroomlight
fill 282 292 496 282 307 496 minecraft:red_nether_bricks
fill 282 292 505 282 307 505 minecraft:red_nether_bricks
fill 283 292 505 284 292 505 minecraft:shroomlight
fill 285 292 505 285 307 505 minecraft:red_nether_bricks
setblock 287 292 500 minecraft:shroomlight
setblock 287 292 502 minecraft:shroomlight
setblock 287 292 504 minecraft:shroomlight
setblock 288 292 499 minecraft:shroomlight
setblock 288 292 501 minecraft:shroomlight
setblock 288 292 503 minecraft:shroomlight
fill 289 292 463 289 307 463 minecraft:red_nether_bricks
setblock 289 292 500 minecraft:shroomlight
setblock 289 292 502 minecraft:shroomlight
setblock 289 292 504 minecraft:shroomlight
fill 290 292 463 291 292 463 minecraft:shroomlight
setblock 290 292 499 minecraft:shroomlight
setblock 290 292 501 minecraft:shroomlight
setblock 290 292 503 minecraft:shroomlight
setblock 291 292 500 minecraft:shroomlight
setblock 291 292 502 minecraft:shroomlight
setblock 291 292 504 minecraft:shroomlight
fill 292 292 463 292 307 463 minecraft:red_nether_bricks
setblock 292 292 499 minecraft:shroomlight
setblock 292 292 501 minecraft:shroomlight
setblock 292 292 503 minecraft:shroomlight
setblock 293 292 500 minecraft:shroomlight
setblock 293 292 502 minecraft:shroomlight
setblock 293 292 504 minecraft:shroomlight
setblock 294 292 499 minecraft:shroomlight
setblock 294 292 501 minecraft:shroomlight
setblock 294 292 503 minecraft:shroomlight
fill 294 292 505 294 307 505 minecraft:red_nether_bricks
setblock 295 292 500 minecraft:shroomlight
setblock 295 292 502 minecraft:shroomlight
fill 295 292 504 295 292 505 minecraft:shroomlight
setblock 296 292 499 minecraft:shroomlight
setblock 296 292 501 minecraft:shroomlight
setblock 296 292 503 minecraft:shroomlight
setblock 296 292 505 minecraft:shroomlight
setblock 297 292 500 minecraft:shroomlight
setblock 297 292 502 minecraft:shroomlight
setblock 297 292 504 minecraft:shroomlight
fill 297 292 505 297 307 505 minecraft:red_nether_bricks
setblock 298 292 499 minecraft:shroomlight
setblock 298 292 501 minecraft:shroomlight
setblock 298 292 503 minecraft:shroomlight
setblock 299 292 500 minecraft:shroomlight
setblock 299 292 502 minecraft:shroomlight
setblock 299 292 504 minecraft:shroomlight
fill 301 292 463 301 307 463 minecraft:red_nether_bricks
fill 302 292 463 303 292 463 minecraft:shroomlight
fill 304 292 463 304 307 463 minecraft:red_nether_bricks
fill 306 292 505 306 307 505 minecraft:red_nether_bricks
fill 307 292 505 308 292 505 minecraft:shroomlight
setblock 308 292 465 minecraft:shroomlight
setblock 308 292 467 minecraft:shroomlight
setblock 309 292 464 minecraft:shroomlight
setblock 309 292 466 minecraft:shroomlight
setblock 309 292 468 minecraft:shroomlight
fill 309 292 505 309 307 505 minecraft:red_nether_bricks
setblock 310 292 465 minecraft:shroomlight
setblock 310 292 467 minecraft:shroomlight
setblock 311 292 464 minecraft:shroomlight
setblock 311 292 466 minecraft:shroomlight
setblock 311 292 468 minecraft:shroomlight
setblock 312 292 465 minecraft:shroomlight
setblock 312 292 467 minecraft:shroomlight
fill 313 292 463 313 307 463 minecraft:red_nether_bricks
setblock 313 292 464 minecraft:shroomlight
setblock 313 292 466 minecraft:shroomlight
setblock 313 292 468 minecraft:shroomlight
fill 314 292 463 315 292 463 minecraft:shroomlight
setblock 314 292 465 minecraft:shroomlight
setblock 314 292 467 minecraft:shroomlight
setblock 314 292 469 minecraft:shroomlight
setblock 315 292 464 minecraft:shroomlight
setblock 315 292 466 minecraft:shroomlight
setblock 315 292 468 minecraft:shroomlight
setblock 315 292 470 minecraft:shroomlight
fill 316 292 463 316 307 463 minecraft:red_nether_bricks
setblock 316 292 465 minecraft:shroomlight
setblock 316 292 467 minecraft:shroomlight
setblock 316 292 469 minecraft:shroomlight
setblock 317 292 464 minecraft:shroomlight
setblock 317 292 466 minecraft:shroomlight
setblock 317 292 468 minecraft:shroomlight
setblock 317 292 470 minecraft:shroomlight
setblock 318 292 465 minecraft:shroomlight
setblock 318 292 467 minecraft:shroomlight
setblock 318 292 469 minecraft:shroomlight
fill 318 292 505 318 307 505 minecraft:red_nether_bricks
setblock 319 292 464 minecraft:shroomlight
setblock 319 292 466 minecraft:shroomlight
setblock 319 292 468 minecraft:shroomlight
setblock 319 292 470 minecraft:shroomlight
fill 319 292 505 320 292 505 minecraft:shroomlight
setblock 320 292 465 minecraft:shroomlight
setblock 320 292 467 minecraft:shroomlight
setblock 320 292 469 minecraft:shroomlight
setblock 321 292 464 minecraft:shroomlight
setblock 321 292 466 minecraft:shroomlight
setblock 321 292 468 minecraft:shroomlight
setblock 321 292 470 minecraft:shroomlight
fill 321 292 505 321 307 505 minecraft:red_nether_bricks
setblock 322 292 465 minecraft:shroomlight
setblock 322 292 467 minecraft:shroomlight
setblock 322 292 469 minecraft:shroomlight
fill 324 292 464 324 307 464 minecraft:red_nether_bricks
fill 324 292 465 324 292 466 minecraft:shroomlight
fill 324 292 467 324 307 467 minecraft:red_nether_bricks
fill 324 292 476 324 307 476 minecraft:red_nether_bricks
fill 324 292 477 324 292 478 minecraft:shroomlight
fill 324 292 479 324 307 479 minecraft:red_nether_bricks
fill 324 292 488 324 307 488 minecraft:red_nether_bricks
fill 324 292 489 324 292 490 minecraft:shroomlight
fill 324 292 491 324 307 491 minecraft:red_nether_bricks
fill 324 292 500 324 307 500 minecraft:red_nether_bricks
fill 324 292 501 324 292 502 minecraft:shroomlight
fill 324 292 503 324 307 503 minecraft:red_nether_bricks
fill 282 293 470 282 307 471 minecraft:red_nether_bricks
fill 282 293 482 282 307 483 minecraft:red_nether_bricks
fill 282 293 494 282 307 495 minecraft:red_nether_bricks
fill 283 293 505 284 307 505 minecraft:red_nether_bricks
fill 287 293 500 287 294 500 minecraft:polished_blackstone_bricks
fill 287 293 502 287 294 502 minecraft:polished_blackstone_bricks
fill 287 293 504 287 294 504 minecraft:polished_blackstone_bricks
fill 288 293 499 288 294 499 minecraft:polished_blackstone_bricks
fill 288 293 501 288 294 501 minecraft:polished_blackstone_bricks
fill 288 293 503 288 294 503 minecraft:polished_blackstone_bricks
fill 289 293 500 289 294 500 minecraft:polished_blackstone_bricks
fill 289 293 502 289 294 502 minecraft:polished_blackstone_bricks
fill 289 293 504 289 294 504 minecraft:polished_blackstone_bricks
fill 290 293 463 291 307 463 minecraft:red_nether_bricks
fill 290 293 499 290 294 499 minecraft:polished_blackstone_bricks
fill 290 293 501 290 294 501 minecraft:polished_blackstone_bricks
fill 290 293 503 290 294 503 minecraft:polished_blackstone_bricks
fill 291 293 500 291 294 500 minecraft:polished_blackstone_bricks
fill 291 293 502 291 294 502 minecraft:polished_blackstone_bricks
fill 291 293 504 291 294 504 minecraft:polished_blackstone_bricks
fill 292 293 499 292 294 499 minecraft:polished_blackstone_bricks
fill 292 293 501 292 294 501 minecraft:polished_blackstone_bricks
fill 292 293 503 292 294 503 minecraft:polished_blackstone_bricks
fill 293 293 500 293 294 500 minecraft:polished_blackstone_bricks
fill 293 293 502 293 294 502 minecraft:polished_blackstone_bricks
fill 293 293 504 293 294 504 minecraft:polished_blackstone_bricks
fill 294 293 499 294 294 499 minecraft:polished_blackstone_bricks
fill 294 293 501 294 294 501 minecraft:polished_blackstone_bricks
fill 294 293 503 294 294 503 minecraft:polished_blackstone_bricks
fill 295 293 500 295 294 500 minecraft:polished_blackstone_bricks
fill 295 293 502 295 294 502 minecraft:polished_blackstone_bricks
fill 295 293 504 295 294 504 minecraft:polished_blackstone_bricks
fill 295 293 505 296 307 505 minecraft:red_nether_bricks
fill 296 293 499 296 294 499 minecraft:polished_blackstone_bricks
fill 296 293 501 296 294 501 minecraft:polished_blackstone_bricks
fill 296 293 503 296 294 503 minecraft:polished_blackstone_bricks
fill 297 293 500 297 294 500 minecraft:polished_blackstone_bricks
fill 297 293 502 297 294 502 minecraft:polished_blackstone_bricks
fill 297 293 504 297 294 504 minecraft:polished_blackstone_bricks
fill 298 293 499 298 294 499 minecraft:polished_blackstone_bricks
fill 298 293 501 298 294 501 minecraft:polished_blackstone_bricks
fill 298 293 503 298 294 503 minecraft:polished_blackstone_bricks
fill 299 293 500 299 294 500 minecraft:polished_blackstone_bricks
fill 299 293 502 299 294 502 minecraft:polished_blackstone_bricks
fill 299 293 504 299 294 504 minecraft:polished_blackstone_bricks
fill 302 293 463 303 307 463 minecraft:red_nether_bricks
fill 307 293 505 308 307 505 minecraft:red_nether_bricks
fill 308 293 465 308 294 465 minecraft:polished_blackstone_bricks
fill 308 293 467 308 294 467 minecraft:polished_blackstone_bricks
fill 309 293 464 309 294 464 minecraft:polished_blackstone_bricks
fill 309 293 466 309 294 466 minecraft:polished_blackstone_bricks
fill 309 293 468 309 294 468 minecraft:polished_blackstone_bricks
fill 310 293 465 310 294 465 minecraft:polished_blackstone_bricks
fill 310 293 467 310 294 467 minecraft:polished_blackstone_bricks
fill 311 293 464 311 294 464 minecraft:polished_blackstone_bricks
fill 311 293 466 311 294 466 minecraft:polished_blackstone_bricks
fill 311 293 468 311 294 468 minecraft:polished_blackstone_bricks
fill 312 293 465 312 294 465 minecraft:polished_blackstone_bricks
fill 312 293 467 312 294 467 minecraft:polished_blackstone_bricks
fill 313 293 464 313 294 464 minecraft:polished_blackstone_bricks
fill 313 293 466 313 294 466 minecraft:polished_blackstone_bricks
fill 313 293 468 313 294 468 minecraft:polished_blackstone_bricks
fill 314 293 463 315 307 463 minecraft:red_nether_bricks
fill 314 293 465 314 294 465 minecraft:polished_blackstone_bricks
fill 314 293 467 314 294 467 minecraft:polished_blackstone_bricks
fill 314 293 469 314 294 469 minecraft:polished_blackstone_bricks
fill 315 293 464 315 294 464 minecraft:polished_blackstone_bricks
fill 315 293 466 315 294 466 minecraft:polished_blackstone_bricks
fill 315 293 468 315 294 468 minecraft:polished_blackstone_bricks
fill 315 293 470 315 294 470 minecraft:polished_blackstone_bricks
fill 316 293 465 316 294 465 minecraft:polished_blackstone_bricks
fill 316 293 467 316 294 467 minecraft:polished_blackstone_bricks
fill 316 293 469 316 294 469 minecraft:polished_blackstone_bricks
fill 317 293 464 317 294 464 minecraft:polished_blackstone_bricks
fill 317 293 466 317 294 466 minecraft:polished_blackstone_bricks
fill 317 293 468 317 294 468 minecraft:polished_blackstone_bricks
fill 317 293 470 317 294 470 minecraft:polished_blackstone_bricks
fill 318 293 465 318 294 465 minecraft:polished_blackstone_bricks
fill 318 293 467 318 294 467 minecraft:polished_blackstone_bricks
fill 318 293 469 318 294 469 minecraft:polished_blackstone_bricks
fill 319 293 464 319 294 464 minecraft:polished_blackstone_bricks
fill 319 293 466 319 294 466 minecraft:polished_blackstone_bricks
fill 319 293 468 319 294 468 minecraft:polished_blackstone_bricks
fill 319 293 470 319 294 470 minecraft:polished_blackstone_bricks
fill 319 293 505 320 307 505 minecraft:red_nether_bricks
fill 320 293 465 320 294 465 minecraft:polished_blackstone_bricks
fill 320 293 467 320 294 467 minecraft:polished_blackstone_bricks
fill 320 293 469 320 294 469 minecraft:polished_blackstone_bricks
fill 321 293 464 321 294 464 minecraft:polished_blackstone_bricks
fill 321 293 466 321 294 466 minecraft:polished_blackstone_bricks
fill 321 293 468 321 294 468 minecraft:polished_blackstone_bricks
fill 321 293 470 321 294 470 minecraft:polished_blackstone_bricks
fill 322 293 465 322 294 465 minecraft:polished_blackstone_bricks
fill 322 293 467 322 294 467 minecraft:polished_blackstone_bricks
fill 322 293 469 322 294 469 minecraft:polished_blackstone_bricks
fill 324 293 465 324 307 466 minecraft:red_nether_bricks
fill 324 293 477 324 307 478 minecraft:red_nether_bricks
fill 324 293 489 324 307 490 minecraft:red_nether_bricks
fill 324 293 501 324 307 502 minecraft:red_nether_bricks
setblock 285 295 466 minecraft:light[level=14]
setblock 285 295 474 minecraft:light[level=14]
setblock 285 295 482 minecraft:light[level=14]
setblock 285 295 490 minecraft:light[level=14]
setblock 285 295 498 minecraft:light[level=14]
setblock 287 295 500 minecraft:shroomlight
setblock 287 295 502 minecraft:shroomlight
setblock 287 295 504 minecraft:shroomlight
setblock 288 295 499 minecraft:shroomlight
setblock 288 295 501 minecraft:shroomlight
setblock 288 295 503 minecraft:shroomlight
setblock 289 295 500 minecraft:shroomlight
setblock 289 295 502 minecraft:shroomlight
setblock 289 295 504 minecraft:shroomlight
setblock 290 295 499 minecraft:shroomlight
setblock 290 295 501 minecraft:shroomlight
setblock 290 295 503 minecraft:shroomlight
setblock 291 295 500 minecraft:shroomlight
setblock 291 295 502 minecraft:shroomlight
setblock 291 295 504 minecraft:shroomlight
setblock 292 295 499 minecraft:shroomlight
setblock 292 295 501 minecraft:shroomlight
setblock 292 295 503 minecraft:shroomlight
setblock 293 295 466 minecraft:light[level=14]
setblock 293 295 474 minecraft:light[level=14]
setblock 293 295 482 minecraft:light[level=14]
setblock 293 295 490 minecraft:light[level=14]
setblock 293 295 500 minecraft:shroomlight
setblock 293 295 502 minecraft:shroomlight
setblock 293 295 504 minecraft:shroomlight
setblock 294 295 499 minecraft:shroomlight
setblock 294 295 501 minecraft:shroomlight
setblock 294 295 503 minecraft:shroomlight
setblock 295 295 500 minecraft:shroomlight
setblock 295 295 502 minecraft:shroomlight
setblock 295 295 504 minecraft:shroomlight
setblock 296 295 499 minecraft:shroomlight
setblock 296 295 501 minecraft:shroomlight
setblock 296 295 503 minecraft:shroomlight
setblock 297 295 500 minecraft:shroomlight
setblock 297 295 502 minecraft:shroomlight
setblock 297 295 504 minecraft:shroomlight
setblock 298 295 499 minecraft:shroomlight
setblock 298 295 501 minecraft:shroomlight
setblock 298 295 503 minecraft:shroomlight
setblock 299 295 500 minecraft:shroomlight
setblock 299 295 502 minecraft:shroomlight
setblock 299 295 504 minecraft:shroomlight
setblock 301 295 466 minecraft:light[level=14]
setblock 301 295 474 minecraft:light[level=14]
setblock 301 295 482 minecraft:light[level=14]
setblock 301 295 490 minecraft:light[level=14]
setblock 301 295 498 minecraft:light[level=14]
setblock 308 295 465 minecraft:shroomlight
setblock 308 295 467 minecraft:shroomlight
setblock 309 295 464 minecraft:shroomlight
setblock 309 295 466 minecraft:shroomlight
setblock 309 295 468 minecraft:shroomlight
setblock 309 295 474 minecraft:light[level=14]
setblock 309 295 482 minecraft:light[level=14]
setblock 309 295 490 minecraft:light[level=14]
setblock 309 295 498 minecraft:light[level=14]
setblock 310 295 465 minecraft:shroomlight
setblock 310 295 467 minecraft:shroomlight
setblock 311 295 464 minecraft:shroomlight
setblock 311 295 466 minecraft:shroomlight
setblock 311 295 468 minecraft:shroomlight
setblock 312 295 465 minecraft:shroomlight
setblock 312 295 467 minecraft:shroomlight
setblock 313 295 464 minecraft:shroomlight
setblock 313 295 466 minecraft:shroomlight
setblock 313 295 468 minecraft:shroomlight
setblock 314 295 465 minecraft:shroomlight
setblock 314 295 467 minecraft:shroomlight
setblock 314 295 469 minecraft:shroomlight
setblock 315 295 464 minecraft:shroomlight
setblock 315 295 466 minecraft:shroomlight
setblock 315 295 468 minecraft:shroomlight
setblock 315 295 470 minecraft:shroomlight
setblock 316 295 465 minecraft:shroomlight
setblock 316 295 467 minecraft:shroomlight
setblock 316 295 469 minecraft:shroomlight
setblock 317 295 464 minecraft:shroomlight
setblock 317 295 466 minecraft:shroomlight
setblock 317 295 468 minecraft:shroomlight
setblock 317 295 470 minecraft:shroomlight
setblock 317 295 474 minecraft:light[level=14]
setblock 317 295 482 minecraft:light[level=14]
setblock 317 295 490 minecraft:light[level=14]
setblock 317 295 498 minecraft:light[level=14]
setblock 318 295 465 minecraft:shroomlight
setblock 318 295 467 minecraft:shroomlight
setblock 318 295 469 minecraft:shroomlight
setblock 319 295 464 minecraft:shroomlight
setblock 319 295 466 minecraft:shroomlight
setblock 319 295 468 minecraft:shroomlight
setblock 319 295 470 minecraft:shroomlight
setblock 320 295 465 minecraft:shroomlight
setblock 320 295 467 minecraft:shroomlight
setblock 320 295 469 minecraft:shroomlight
setblock 321 295 464 minecraft:shroomlight
setblock 321 295 466 minecraft:shroomlight
setblock 321 295 468 minecraft:shroomlight
setblock 321 295 470 minecraft:shroomlight
setblock 322 295 465 minecraft:shroomlight
setblock 322 295 467 minecraft:shroomlight
setblock 322 295 469 minecraft:shroomlight
fill 287 296 500 287 299 500 minecraft:polished_blackstone_bricks
fill 287 296 502 287 299 502 minecraft:polished_blackstone_bricks
fill 287 296 504 287 299 504 minecraft:polished_blackstone_bricks
fill 288 296 499 288 299 499 minecraft:polished_blackstone_bricks
setblock 288 296 501 minecraft:polished_blackstone_bricks
setblock 288 296 503 minecraft:polished_blackstone_bricks
setblock 289 296 500 minecraft:polished_blackstone_bricks
setblock 289 296 502 minecraft:polished_blackstone_bricks
fill 289 296 504 289 300 504 minecraft:polished_blackstone_bricks
fill 290 296 499 290 299 499 minecraft:polished_blackstone_bricks
setblock 290 296 501 minecraft:polished_blackstone_bricks
setblock 290 296 503 minecraft:polished_blackstone_bricks
setblock 291 296 500 minecraft:polished_blackstone_bricks
setblock 291 296 502 minecraft:polished_blackstone_bricks
fill 291 296 504 291 300 504 minecraft:polished_blackstone_bricks
fill 292 296 499 292 299 499 minecraft:polished_blackstone_bricks
setblock 292 296 501 minecraft:polished_blackstone_bricks
setblock 292 296 503 minecraft:polished_blackstone_bricks
setblock 293 296 500 minecraft:polished_blackstone_bricks
setblock 293 296 502 minecraft:polished_blackstone_bricks
fill 293 296 504 293 299 504 minecraft:polished_blackstone_bricks
fill 294 296 499 294 299 499 minecraft:polished_blackstone_bricks
setblock 294 296 501 minecraft:polished_blackstone_bricks
setblock 294 296 503 minecraft:polished_blackstone_bricks
setblock 295 296 500 minecraft:polished_blackstone_bricks
setblock 295 296 502 minecraft:polished_blackstone_bricks
fill 295 296 504 295 299 504 minecraft:polished_blackstone_bricks
setblock 296 296 499 minecraft:polished_blackstone_bricks
setblock 296 296 501 minecraft:polished_blackstone_bricks
setblock 296 296 503 minecraft:polished_blackstone_bricks
setblock 297 296 500 minecraft:polished_blackstone_bricks
setblock 297 296 502 minecraft:polished_blackstone_bricks
setblock 297 296 504 minecraft:polished_blackstone_bricks
setblock 298 296 499 minecraft:polished_blackstone_bricks
setblock 298 296 501 minecraft:polished_blackstone_bricks
setblock 298 296 503 minecraft:polished_blackstone_bricks
setblock 299 296 500 minecraft:polished_blackstone_bricks
setblock 299 296 502 minecraft:polished_blackstone_bricks
setblock 299 296 504 minecraft:polished_blackstone_bricks
fill 308 296 465 308 297 465 minecraft:polished_blackstone_bricks
fill 308 296 467 308 297 467 minecraft:polished_blackstone_bricks
fill 309 296 464 309 297 464 minecraft:polished_blackstone_bricks
fill 309 296 466 309 297 466 minecraft:polished_blackstone_bricks
fill 309 296 468 309 297 468 minecraft:polished_blackstone_bricks
fill 310 296 465 310 297 465 minecraft:polished_blackstone_bricks
fill 310 296 467 310 297 467 minecraft:polished_blackstone_bricks
fill 311 296 464 311 297 464 minecraft:polished_blackstone_bricks
fill 311 296 466 311 297 466 minecraft:polished_blackstone_bricks
fill 311 296 468 311 297 468 minecraft:polished_blackstone_bricks
fill 312 296 465 312 297 465 minecraft:polished_blackstone_bricks
fill 312 296 467 312 297 467 minecraft:polished_blackstone_bricks
fill 313 296 464 313 297 464 minecraft:polished_blackstone_bricks
fill 313 296 466 313 297 466 minecraft:polished_blackstone_bricks
fill 313 296 468 313 297 468 minecraft:polished_blackstone_bricks
fill 314 296 465 314 297 465 minecraft:polished_blackstone_bricks
fill 314 296 467 314 297 467 minecraft:polished_blackstone_bricks
fill 314 296 469 314 297 469 minecraft:polished_blackstone_bricks
fill 315 296 464 315 297 464 minecraft:polished_blackstone_bricks
fill 315 296 466 315 297 466 minecraft:polished_blackstone_bricks
fill 315 296 468 315 297 468 minecraft:polished_blackstone_bricks
fill 315 296 470 315 297 470 minecraft:polished_blackstone_bricks
fill 316 296 465 316 297 465 minecraft:polished_blackstone_bricks
fill 316 296 467 316 297 467 minecraft:polished_blackstone_bricks
fill 316 296 469 316 297 469 minecraft:polished_blackstone_bricks
fill 317 296 464 317 297 464 minecraft:polished_blackstone_bricks
fill 317 296 466 317 297 466 minecraft:polished_blackstone_bricks
fill 317 296 468 317 297 468 minecraft:polished_blackstone_bricks
fill 317 296 470 317 297 470 minecraft:polished_blackstone_bricks
fill 318 296 465 318 297 465 minecraft:polished_blackstone_bricks
fill 318 296 467 318 297 467 minecraft:polished_blackstone_bricks
fill 318 296 469 318 297 469 minecraft:polished_blackstone_bricks
fill 319 296 464 319 297 464 minecraft:polished_blackstone_bricks
fill 319 296 466 319 297 466 minecraft:polished_blackstone_bricks
fill 319 296 468 319 297 468 minecraft:polished_blackstone_bricks
fill 319 296 470 319 297 470 minecraft:polished_blackstone_bricks
fill 320 296 465 320 297 465 minecraft:polished_blackstone_bricks
fill 320 296 467 320 297 467 minecraft:polished_blackstone_bricks
fill 320 296 469 320 297 469 minecraft:polished_blackstone_bricks
fill 321 296 464 321 297 464 minecraft:polished_blackstone_bricks
fill 321 296 466 321 297 466 minecraft:polished_blackstone_bricks
fill 321 296 468 321 297 468 minecraft:polished_blackstone_bricks
fill 321 296 470 321 297 470 minecraft:polished_blackstone_bricks
fill 322 296 465 322 297 465 minecraft:polished_blackstone_bricks
fill 322 296 467 322 297 467 minecraft:polished_blackstone_bricks
fill 322 296 469 322 297 469 minecraft:polished_blackstone_bricks
fill 288 297 500 298 297 503 minecraft:gold_block
fill 288 298 500 288 299 503 minecraft:polished_blackstone_bricks
fill 289 298 500 295 299 500 minecraft:polished_blackstone_bricks
fill 289 298 501 297 298 502 minecraft:gold_block
fill 289 298 503 295 299 503 minecraft:polished_blackstone_bricks
setblock 308 298 465 minecraft:shroomlight
setblock 308 298 467 minecraft:shroomlight
setblock 309 298 464 minecraft:shroomlight
setblock 309 298 466 minecraft:shroomlight
setblock 309 298 468 minecraft:shroomlight
setblock 310 298 465 minecraft:shroomlight
setblock 310 298 467 minecraft:shroomlight
setblock 311 298 464 minecraft:shroomlight
setblock 311 298 466 minecraft:shroomlight
setblock 311 298 468 minecraft:shroomlight
setblock 312 298 465 minecraft:shroomlight
setblock 312 298 467 minecraft:shroomlight
setblock 313 298 464 minecraft:shroomlight
setblock 313 298 466 minecraft:shroomlight
setblock 313 298 468 minecraft:shroomlight
setblock 314 298 465 minecraft:shroomlight
setblock 314 298 467 minecraft:shroomlight
setblock 314 298 469 minecraft:shroomlight
setblock 315 298 464 minecraft:shroomlight
setblock 315 298 466 minecraft:shroomlight
setblock 315 298 468 minecraft:shroomlight
setblock 315 298 470 minecraft:shroomlight
setblock 316 298 465 minecraft:shroomlight
setblock 316 298 467 minecraft:shroomlight
setblock 316 298 469 minecraft:shroomlight
setblock 317 298 464 minecraft:shroomlight
setblock 317 298 466 minecraft:shroomlight
setblock 317 298 468 minecraft:shroomlight
setblock 317 298 470 minecraft:shroomlight
setblock 318 298 465 minecraft:shroomlight
setblock 318 298 467 minecraft:shroomlight
setblock 318 298 469 minecraft:shroomlight
setblock 319 298 464 minecraft:shroomlight
setblock 319 298 466 minecraft:shroomlight
setblock 319 298 468 minecraft:shroomlight
setblock 319 298 470 minecraft:shroomlight
setblock 320 298 465 minecraft:shroomlight
setblock 320 298 467 minecraft:shroomlight
setblock 320 298 469 minecraft:shroomlight
setblock 321 298 464 minecraft:shroomlight
setblock 321 298 466 minecraft:shroomlight
setblock 321 298 468 minecraft:shroomlight
setblock 321 298 470 minecraft:shroomlight
setblock 322 298 465 minecraft:shroomlight
setblock 322 298 467 minecraft:shroomlight
setblock 322 298 469 minecraft:shroomlight
fill 289 299 501 289 299 502 minecraft:polished_blackstone_bricks
fill 290 299 501 296 299 502 minecraft:gold_block
fill 308 299 465 308 300 465 minecraft:polished_blackstone_bricks
fill 308 299 467 308 300 467 minecraft:polished_blackstone_bricks
fill 309 299 464 309 300 464 minecraft:polished_blackstone_bricks
fill 309 299 466 309 300 466 minecraft:polished_blackstone_bricks
fill 309 299 468 309 300 468 minecraft:polished_blackstone_bricks
fill 310 299 465 310 300 465 minecraft:polished_blackstone_bricks
fill 310 299 467 310 300 467 minecraft:polished_blackstone_bricks
fill 311 299 464 311 300 464 minecraft:polished_blackstone_bricks
fill 311 299 466 311 300 466 minecraft:polished_blackstone_bricks
fill 311 299 468 311 300 468 minecraft:polished_blackstone_bricks
fill 312 299 465 312 300 465 minecraft:polished_blackstone_bricks
fill 312 299 467 312 300 467 minecraft:polished_blackstone_bricks
fill 313 299 464 313 300 464 minecraft:polished_blackstone_bricks
fill 313 299 466 313 300 466 minecraft:polished_blackstone_bricks
fill 313 299 468 313 300 468 minecraft:polished_blackstone_bricks
fill 314 299 465 314 300 465 minecraft:polished_blackstone_bricks
fill 314 299 467 314 300 467 minecraft:polished_blackstone_bricks
fill 314 299 469 314 300 469 minecraft:polished_blackstone_bricks
fill 315 299 464 315 300 464 minecraft:polished_blackstone_bricks
fill 315 299 466 315 300 466 minecraft:polished_blackstone_bricks
fill 315 299 468 315 300 468 minecraft:polished_blackstone_bricks
fill 315 299 470 315 300 470 minecraft:polished_blackstone_bricks
fill 316 299 465 316 300 465 minecraft:polished_blackstone_bricks
fill 316 299 467 316 300 467 minecraft:polished_blackstone_bricks
fill 316 299 469 316 300 469 minecraft:polished_blackstone_bricks
fill 317 299 464 317 300 464 minecraft:polished_blackstone_bricks
fill 317 299 466 317 300 466 minecraft:polished_blackstone_bricks
fill 317 299 468 317 300 468 minecraft:polished_blackstone_bricks
fill 317 299 470 317 300 470 minecraft:polished_blackstone_bricks
fill 318 299 465 318 300 465 minecraft:polished_blackstone_bricks
fill 318 299 467 318 300 467 minecraft:polished_blackstone_bricks
fill 318 299 469 318 300 469 minecraft:polished_blackstone_bricks
fill 319 299 464 319 300 464 minecraft:polished_blackstone_bricks
fill 319 299 466 319 300 466 minecraft:polished_blackstone_bricks
fill 319 299 468 319 300 468 minecraft:polished_blackstone_bricks
fill 319 299 470 319 300 470 minecraft:polished_blackstone_bricks
fill 320 299 465 320 300 465 minecraft:polished_blackstone_bricks
fill 320 299 467 320 300 467 minecraft:polished_blackstone_bricks
fill 320 299 469 320 300 469 minecraft:polished_blackstone_bricks
fill 321 299 464 321 300 464 minecraft:polished_blackstone_bricks
fill 321 299 466 321 300 466 minecraft:polished_blackstone_bricks
fill 321 299 468 321 300 468 minecraft:polished_blackstone_bricks
fill 321 299 470 321 300 470 minecraft:polished_blackstone_bricks
fill 322 299 465 322 300 465 minecraft:polished_blackstone_bricks
fill 322 299 467 322 300 467 minecraft:polished_blackstone_bricks
fill 322 299 469 322 300 469 minecraft:polished_blackstone_bricks
fill 284 300 473 284 300 475 minecraft:polished_blackstone_bricks
fill 284 300 485 284 300 487 minecraft:polished_blackstone_bricks
fill 284 300 497 284 300 499 minecraft:polished_blackstone_bricks
fill 288 300 497 289 300 503 minecraft:gold_block
fill 290 300 497 294 300 502 minecraft:gold_block
fill 290 300 503 292 300 503 minecraft:polished_blackstone_bricks
fill 293 300 503 295 300 503 minecraft:gold_block
fill 294 300 465 296 300 465 minecraft:polished_blackstone_bricks
fill 295 300 500 295 300 502 minecraft:gold_block
fill 302 300 503 304 300 503 minecraft:polished_blackstone_bricks
fill 306 300 465 307 300 465 minecraft:polished_blackstone_bricks
fill 314 300 503 316 300 503 minecraft:polished_blackstone_bricks
fill 322 300 473 322 300 475 minecraft:polished_blackstone_bricks
fill 322 300 485 322 300 487 minecraft:polished_blackstone_bricks
fill 322 300 497 322 300 499 minecraft:polished_blackstone_bricks
setblock 285 303 466 minecraft:light[level=14]
setblock 285 303 474 minecraft:light[level=14]
setblock 285 303 482 minecraft:light[level=14]
setblock 285 303 490 minecraft:light[level=14]
setblock 285 303 498 minecraft:light[level=14]
setblock 293 303 466 minecraft:light[level=14]
setblock 293 303 474 minecraft:light[level=14]
setblock 293 303 482 minecraft:light[level=14]
setblock 293 303 490 minecraft:light[level=14]
setblock 293 303 498 minecraft:light[level=14]
setblock 301 303 466 minecraft:light[level=14]
setblock 301 303 474 minecraft:light[level=14]
setblock 301 303 482 minecraft:light[level=14]
setblock 301 303 490 minecraft:light[level=14]
setblock 301 303 498 minecraft:light[level=14]
setblock 309 303 466 minecraft:light[level=14]
setblock 309 303 474 minecraft:light[level=14]
setblock 309 303 482 minecraft:light[level=14]
setblock 309 303 490 minecraft:light[level=14]
setblock 309 303 498 minecraft:light[level=14]
setblock 317 303 466 minecraft:light[level=14]
setblock 317 303 474 minecraft:light[level=14]
setblock 317 303 482 minecraft:light[level=14]
setblock 317 303 490 minecraft:light[level=14]
setblock 317 303 498 minecraft:light[level=14]
