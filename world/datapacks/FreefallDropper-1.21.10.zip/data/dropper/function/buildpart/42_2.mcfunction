fill 323 8 202 323 11 202 minecraft:red_nether_bricks
setblock 323 8 206 minecraft:polished_blackstone
fill 323 8 207 323 11 207 minecraft:red_nether_bricks
setblock 323 8 211 minecraft:polished_blackstone
fill 323 8 212 323 11 212 minecraft:red_nether_bricks
fill 323 8 214 323 8 215 minecraft:red_nether_bricks
setblock 323 8 216 minecraft:polished_blackstone
fill 323 8 217 323 11 217 minecraft:red_nether_bricks
setblock 323 8 221 minecraft:polished_blackstone
fill 323 8 222 323 11 222 minecraft:red_nether_bricks
setblock 283 9 185 minecraft:polished_blackstone
fill 283 9 186 283 12 186 minecraft:red_nether_bricks
setblock 283 9 190 minecraft:polished_blackstone
fill 283 9 191 284 11 191 minecraft:red_nether_bricks
setblock 283 9 194 minecraft:red_nether_bricks
setblock 283 9 200 minecraft:polished_blackstone
fill 283 9 201 283 12 201 minecraft:red_nether_bricks
setblock 283 9 205 minecraft:polished_blackstone
fill 283 9 206 283 12 206 minecraft:red_nether_bricks
setblock 283 9 210 minecraft:polished_blackstone
fill 283 9 211 283 12 211 minecraft:red_nether_bricks
setblock 283 9 215 minecraft:polished_blackstone
fill 283 9 216 283 12 216 minecraft:red_nether_bricks
setblock 283 9 220 minecraft:polished_blackstone
fill 283 9 221 283 12 221 minecraft:red_nether_bricks
setblock 284 9 184 minecraft:polished_blackstone
fill 284 9 185 284 12 185 minecraft:red_nether_bricks
setblock 284 9 189 minecraft:polished_blackstone
fill 284 9 190 284 12 190 minecraft:red_nether_bricks
setblock 284 9 204 minecraft:polished_blackstone
fill 284 9 205 284 12 205 minecraft:red_nether_bricks
setblock 284 9 209 minecraft:polished_blackstone
fill 284 9 210 284 12 210 minecraft:red_nether_bricks
setblock 284 9 214 minecraft:polished_blackstone
fill 284 9 215 285 11 215 minecraft:red_nether_bricks
setblock 284 9 219 minecraft:polished_blackstone
fill 284 9 220 284 12 220 minecraft:red_nether_bricks
setblock 285 9 183 minecraft:polished_blackstone
fill 285 9 184 285 10 184 minecraft:red_nether_bricks
setblock 285 9 208 minecraft:polished_blackstone
fill 285 9 209 285 12 209 minecraft:red_nether_bricks
setblock 285 9 212 minecraft:red_nether_bricks
setblock 285 9 213 minecraft:polished_blackstone
fill 285 9 214 285 12 214 minecraft:red_nether_bricks
setblock 286 9 182 minecraft:polished_blackstone
fill 286 9 183 286 11 183 minecraft:red_nether_bricks
setblock 286 9 222 minecraft:polished_blackstone
fill 287 9 182 287 12 182 minecraft:red_nether_bricks
setblock 287 9 221 minecraft:polished_blackstone
fill 287 9 222 287 12 222 minecraft:red_nether_bricks
fill 299 9 182 300 9 182 minecraft:red_nether_bricks
setblock 301 9 182 minecraft:polished_blackstone
fill 301 9 183 301 12 183 minecraft:red_nether_bricks
setblock 301 9 222 minecraft:polished_blackstone
fill 302 9 182 302 12 182 minecraft:red_nether_bricks
fill 302 9 222 302 12 222 minecraft:red_nether_bricks
setblock 303 9 184 minecraft:red_nether_bricks
setblock 304 9 184 minecraft:polished_blackstone
setblock 305 9 183 minecraft:polished_blackstone
fill 305 9 184 305 11 184 minecraft:red_nether_bricks
setblock 306 9 182 minecraft:polished_blackstone
fill 306 9 183 306 12 183 minecraft:red_nether_bricks
fill 307 9 182 307 12 182 minecraft:red_nether_bricks
setblock 310 9 183 minecraft:polished_blackstone
setblock 311 9 182 minecraft:polished_blackstone
fill 312 9 182 312 12 182 minecraft:red_nether_bricks
setblock 315 9 183 minecraft:polished_blackstone
setblock 316 9 182 minecraft:polished_blackstone
fill 316 9 183 316 12 183 minecraft:red_nether_bricks
fill 317 9 182 317 12 182 minecraft:red_nether_bricks
fill 317 9 184 318 9 184 minecraft:red_nether_bricks
setblock 319 9 184 minecraft:polished_blackstone
setblock 320 9 183 minecraft:polished_blackstone
fill 320 9 184 320 9 187 minecraft:red_nether_bricks
setblock 320 9 188 minecraft:polished_blackstone
setblock 321 9 182 minecraft:polished_blackstone
fill 321 9 183 321 12 183 minecraft:red_nether_bricks
setblock 321 9 186 minecraft:red_nether_bricks
setblock 321 9 187 minecraft:polished_blackstone
fill 321 9 188 321 12 188 minecraft:red_nether_bricks
setblock 321 9 191 minecraft:red_nether_bricks
setblock 321 9 222 minecraft:polished_blackstone
fill 322 9 182 322 12 182 minecraft:red_nether_bricks
setblock 322 9 186 minecraft:polished_blackstone
fill 322 9 187 322 12 187 minecraft:red_nether_bricks
setblock 322 9 191 minecraft:polished_blackstone
fill 322 9 192 322 10 194 minecraft:red_nether_bricks
setblock 322 9 206 minecraft:polished_blackstone
fill 322 9 207 322 12 207 minecraft:red_nether_bricks
setblock 322 9 211 minecraft:polished_blackstone
fill 322 9 212 322 11 213 minecraft:red_nether_bricks
setblock 322 9 221 minecraft:polished_blackstone
fill 322 9 222 322 12 222 minecraft:red_nether_bricks
setblock 323 9 185 minecraft:polished_blackstone
fill 323 9 186 323 12 186 minecraft:red_nether_bricks
setblock 323 9 190 minecraft:polished_blackstone
fill 323 9 191 323 12 191 minecraft:red_nether_bricks
setblock 323 9 195 minecraft:polished_blackstone
fill 323 9 196 323 12 196 minecraft:red_nether_bricks
setblock 323 9 200 minecraft:polished_blackstone
fill 323 9 201 323 12 201 minecraft:red_nether_bricks
setblock 323 9 205 minecraft:polished_blackstone
fill 323 9 206 323 12 206 minecraft:red_nether_bricks
setblock 323 9 209 minecraft:red_nether_bricks
setblock 323 9 210 minecraft:polished_blackstone
fill 323 9 211 323 12 211 minecraft:red_nether_bricks
setblock 323 9 214 minecraft:red_nether_bricks
setblock 323 9 215 minecraft:polished_blackstone
fill 323 9 216 323 12 216 minecraft:red_nether_bricks
setblock 323 9 220 minecraft:polished_blackstone
fill 323 9 221 323 12 221 minecraft:red_nether_bricks
setblock 283 10 184 minecraft:polished_blackstone
fill 283 10 185 283 13 185 minecraft:red_nether_bricks
setblock 283 10 189 minecraft:polished_blackstone
fill 283 10 190 283 13 190 minecraft:red_nether_bricks
setblock 283 10 194 minecraft:polished_blackstone
fill 283 10 195 283 13 195 minecraft:red_nether_bricks
fill 283 10 200 283 13 200 minecraft:red_nether_bricks
setblock 283 10 204 minecraft:polished_blackstone
fill 283 10 205 283 13 205 minecraft:red_nether_bricks
setblock 283 10 209 minecraft:polished_blackstone
fill 283 10 210 283 13 210 minecraft:red_nether_bricks
setblock 283 10 213 minecraft:red_nether_bricks
setblock 283 10 214 minecraft:polished_blackstone
fill 283 10 215 283 13 215 minecraft:red_nether_bricks
setblock 283 10 219 minecraft:polished_blackstone
fill 283 10 220 283 13 220 minecraft:red_nether_bricks
setblock 284 10 183 minecraft:polished_blackstone
fill 284 10 184 284 13 184 minecraft:red_nether_bricks
setblock 284 10 188 minecraft:polished_blackstone
fill 284 10 189 284 13 189 minecraft:red_nether_bricks
setblock 284 10 192 minecraft:red_nether_bricks
setblock 284 10 203 minecraft:polished_blackstone
fill 284 10 204 284 13 204 minecraft:red_nether_bricks
setblock 284 10 207 minecraft:red_nether_bricks
setblock 284 10 208 minecraft:polished_blackstone
fill 284 10 209 284 13 209 minecraft:red_nether_bricks
setblock 284 10 213 minecraft:polished_blackstone
fill 284 10 214 284 13 214 minecraft:red_nether_bricks
setblock 284 10 218 minecraft:polished_blackstone
fill 284 10 219 284 13 219 minecraft:red_nether_bricks
setblock 285 10 182 minecraft:polished_blackstone
fill 285 10 183 285 12 183 minecraft:red_nether_bricks
setblock 285 10 187 minecraft:polished_blackstone
fill 285 10 188 285 11 188 minecraft:red_nether_bricks
setblock 285 10 207 minecraft:polished_blackstone
fill 285 10 208 285 13 208 minecraft:red_nether_bricks
setblock 285 10 212 minecraft:polished_blackstone
fill 285 10 213 285 13 213 minecraft:red_nether_bricks
setblock 285 10 216 minecraft:red_nether_bricks
setblock 285 10 222 minecraft:polished_blackstone
fill 286 10 182 286 13 182 minecraft:red_nether_bricks
fill 286 10 209 286 10 210 minecraft:red_nether_bricks
setblock 286 10 211 minecraft:polished_blackstone
setblock 286 10 221 minecraft:polished_blackstone
fill 286 10 222 286 13 222 minecraft:red_nether_bricks
setblock 287 10 221 minecraft:red_nether_bricks
fill 288 10 222 289 10 222 minecraft:red_nether_bricks
fill 298 10 182 299 10 182 minecraft:red_nether_bricks
setblock 300 10 182 minecraft:polished_blackstone
fill 300 10 183 300 13 183 minecraft:red_nether_bricks
setblock 300 10 222 minecraft:polished_blackstone
fill 301 10 182 301 13 182 minecraft:red_nether_bricks
fill 301 10 222 301 13 222 minecraft:red_nether_bricks
setblock 302 10 184 minecraft:red_nether_bricks
setblock 303 10 184 minecraft:polished_blackstone
setblock 304 10 183 minecraft:polished_blackstone
fill 304 10 184 304 12 184 minecraft:red_nether_bricks
setblock 305 10 182 minecraft:polished_blackstone
fill 305 10 183 305 13 183 minecraft:red_nether_bricks
fill 306 10 182 306 13 182 minecraft:red_nether_bricks
setblock 309 10 183 minecraft:polished_blackstone
setblock 310 10 182 minecraft:polished_blackstone
setblock 310 10 183 minecraft:red_nether_bricks
fill 311 10 182 311 13 182 minecraft:red_nether_bricks
setblock 314 10 183 minecraft:polished_blackstone
setblock 315 10 182 minecraft:polished_blackstone
fill 315 10 183 315 13 183 minecraft:red_nether_bricks
fill 316 10 182 316 13 182 minecraft:red_nether_bricks
fill 316 10 184 317 10 184 minecraft:red_nether_bricks
setblock 318 10 184 minecraft:polished_blackstone
fill 318 10 222 318 11 222 minecraft:red_nether_bricks
setblock 319 10 183 minecraft:polished_blackstone
fill 319 10 184 320 11 185 minecraft:red_nether_bricks
setblock 320 10 182 minecraft:polished_blackstone
fill 320 10 183 320 13 183 minecraft:red_nether_bricks
setblock 320 10 186 minecraft:red_nether_bricks
setblock 320 10 187 minecraft:polished_blackstone
fill 320 10 188 320 12 189 minecraft:red_nether_bricks
setblock 320 10 222 minecraft:polished_blackstone
fill 321 10 182 321 13 182 minecraft:red_nether_bricks
setblock 321 10 186 minecraft:polished_blackstone
fill 321 10 187 321 13 187 minecraft:red_nether_bricks
setblock 321 10 191 minecraft:polished_blackstone
fill 321 10 192 321 13 192 minecraft:red_nether_bricks
setblock 321 10 221 minecraft:polished_blackstone
fill 321 10 222 321 13 222 minecraft:red_nether_bricks
setblock 322 10 185 minecraft:polished_blackstone
fill 322 10 186 322 13 186 minecraft:red_nether_bricks
setblock 322 10 190 minecraft:polished_blackstone
fill 322 10 191 322 13 191 minecraft:red_nether_bricks
setblock 322 10 204 minecraft:red_nether_bricks
setblock 322 10 205 minecraft:polished_blackstone
fill 322 10 206 322 13 206 minecraft:red_nether_bricks
fill 322 10 208 322 10 209 minecraft:red_nether_bricks
setblock 322 10 210 minecraft:polished_blackstone
fill 322 10 211 322 13 211 minecraft:red_nether_bricks
setblock 322 10 214 minecraft:red_nether_bricks
setblock 322 10 215 minecraft:polished_blackstone
fill 322 10 216 322 12 217 minecraft:red_nether_bricks
setblock 322 10 219 minecraft:red_nether_bricks
setblock 322 10 220 minecraft:polished_blackstone
fill 322 10 221 322 13 221 minecraft:red_nether_bricks
setblock 323 10 184 minecraft:polished_blackstone
fill 323 10 185 323 13 185 minecraft:red_nether_bricks
setblock 323 10 189 minecraft:polished_blackstone
fill 323 10 190 323 13 190 minecraft:red_nether_bricks
setblock 323 10 194 minecraft:polished_blackstone
fill 323 10 195 323 13 195 minecraft:red_nether_bricks
setblock 323 10 199 minecraft:polished_blackstone
fill 323 10 200 323 12 200 minecraft:red_nether_bricks
setblock 323 10 204 minecraft:polished_blackstone
fill 323 10 205 323 13 205 minecraft:red_nether_bricks
setblock 323 10 209 minecraft:polished_blackstone
fill 323 10 210 323 13 210 minecraft:red_nether_bricks
setblock 323 10 214 minecraft:polished_blackstone
fill 323 10 215 323 13 215 minecraft:red_nether_bricks
setblock 323 10 219 minecraft:polished_blackstone
fill 323 10 220 323 13 220 minecraft:red_nether_bricks
setblock 283 11 183 minecraft:polished_blackstone
fill 283 11 184 283 14 184 minecraft:red_nether_bricks
setblock 283 11 188 minecraft:polished_blackstone
fill 283 11 189 283 14 189 minecraft:red_nether_bricks
setblock 283 11 192 minecraft:red_nether_bricks
setblock 283 11 193 minecraft:polished_blackstone
fill 283 11 194 283 14 194 minecraft:red_nether_bricks
fill 283 11 196 283 11 197 minecraft:red_nether_bricks
setblock 283 11 198 minecraft:polished_blackstone
fill 283 11 199 283 13 199 minecraft:red_nether_bricks
setblock 283 11 203 minecraft:polished_blackstone
fill 283 11 204 283 14 204 minecraft:red_nether_bricks
setblock 283 11 208 minecraft:polished_blackstone
fill 283 11 209 283 14 209 minecraft:red_nether_bricks
setblock 283 11 213 minecraft:polished_blackstone
fill 283 11 214 283 14 214 minecraft:red_nether_bricks
setblock 283 11 218 minecraft:polished_blackstone
fill 283 11 219 283 14 219 minecraft:red_nether_bricks
setblock 284 11 182 minecraft:polished_blackstone
fill 284 11 183 284 13 183 minecraft:red_nether_bricks
setblock 284 11 187 minecraft:polished_blackstone
fill 284 11 188 284 14 188 minecraft:red_nether_bricks
setblock 284 11 192 minecraft:polished_blackstone
fill 284 11 203 284 12 203 minecraft:red_nether_bricks
setblock 284 11 207 minecraft:polished_blackstone
fill 284 11 208 284 14 208 minecraft:red_nether_bricks
setblock 284 11 211 minecraft:red_nether_bricks
setblock 284 11 212 minecraft:polished_blackstone
fill 284 11 213 284 14 213 minecraft:red_nether_bricks
setblock 284 11 217 minecraft:polished_blackstone
fill 284 11 218 284 14 218 minecraft:red_nether_bricks
setblock 284 11 222 minecraft:polished_blackstone
fill 285 11 182 285 14 182 minecraft:red_nether_bricks
setblock 285 11 186 minecraft:polished_blackstone
setblock 285 11 187 minecraft:red_nether_bricks
fill 285 11 206 286 11 206 minecraft:polished_blackstone
fill 285 11 207 285 13 207 minecraft:red_nether_bricks
setblock 285 11 211 minecraft:polished_blackstone
fill 285 11 212 286 13 212 minecraft:red_nether_bricks
setblock 285 11 216 minecraft:polished_blackstone
fill 285 11 217 285 14 217 minecraft:red_nether_bricks
setblock 285 11 221 minecraft:polished_blackstone
fill 285 11 222 285 14 222 minecraft:red_nether_bricks
setblock 286 11 205 minecraft:polished_blackstone
setblock 286 11 207 minecraft:polished_blackstone
setblock 286 11 209 minecraft:red_nether_bricks
setblock 286 11 210 minecraft:polished_blackstone
fill 286 11 211 286 13 211 minecraft:red_nether_bricks
fill 286 11 221 286 12 221 minecraft:red_nether_bricks
setblock 288 11 222 minecraft:red_nether_bricks
setblock 289 11 222 minecraft:polished_blackstone
setblock 298 11 182 minecraft:red_nether_bricks
setblock 299 11 182 minecraft:polished_blackstone
fill 300 11 182 300 14 182 minecraft:red_nether_bricks
fill 300 11 222 300 13 222 minecraft:red_nether_bricks
setblock 302 11 184 minecraft:polished_blackstone
setblock 303 11 183 minecraft:polished_blackstone
fill 303 11 184 303 12 184 minecraft:red_nether_bricks
setblock 304 11 182 minecraft:polished_blackstone
fill 304 11 183 304 13 183 minecraft:red_nether_bricks
setblock 304 11 222 minecraft:polished_blackstone
fill 305 11 182 305 14 182 minecraft:red_nether_bricks
setblock 308 11 183 minecraft:polished_blackstone
setblock 309 11 182 minecraft:polished_blackstone
setblock 309 11 183 minecraft:red_nether_bricks
fill 310 11 182 310 12 182 minecraft:red_nether_bricks
setblock 314 11 182 minecraft:polished_blackstone
fill 314 11 183 314 13 183 minecraft:red_nether_bricks
fill 315 11 182 315 14 182 minecraft:red_nether_bricks
setblock 316 11 184 minecraft:red_nether_bricks
setblock 317 11 184 minecraft:polished_blackstone
setblock 318 11 183 minecraft:polished_blackstone
fill 318 11 184 318 13 185 minecraft:red_nether_bricks
setblock 319 11 182 minecraft:polished_blackstone
fill 319 11 183 319 14 183 minecraft:red_nether_bricks
setblock 319 11 222 minecraft:polished_blackstone
fill 320 11 182 320 14 182 minecraft:red_nether_bricks
setblock 320 11 186 minecraft:polished_blackstone
fill 320 11 187 320 14 187 minecraft:red_nether_bricks
setblock 320 11 190 minecraft:red_nether_bricks
setblock 320 11 221 minecraft:polished_blackstone
fill 320 11 222 320 14 222 minecraft:red_nether_bricks
setblock 321 11 185 minecraft:polished_blackstone
fill 321 11 186 321 14 186 minecraft:red_nether_bricks
setblock 321 11 189 minecraft:red_nether_bricks
setblock 321 11 190 minecraft:polished_blackstone
fill 321 11 191 321 14 191 minecraft:red_nether_bricks
fill 321 11 193 322 11 193 minecraft:red_nether_bricks
fill 321 11 208 321 11 209 minecraft:red_nether_bricks
setblock 321 11 210 minecraft:polished_blackstone
fill 321 11 211 321 13 212 minecraft:red_nether_bricks
fill 321 11 221 321 14 221 minecraft:red_nether_bricks
setblock 322 11 184 minecraft:polished_blackstone
fill 322 11 185 322 14 185 minecraft:red_nether_bricks
setblock 322 11 189 minecraft:polished_blackstone
fill 322 11 190 322 14 190 minecraft:red_nether_bricks
fill 322 11 192 322 12 192 minecraft:red_nether_bricks
setblock 322 11 194 minecraft:polished_blackstone
fill 322 11 195 322 14 195 minecraft:red_nether_bricks
setblock 322 11 204 minecraft:polished_blackstone
fill 322 11 205 322 13 205 minecraft:red_nether_bricks
setblock 322 11 208 minecraft:red_nether_bricks
setblock 322 11 209 minecraft:polished_blackstone
fill 322 11 210 322 14 210 minecraft:red_nether_bricks
setblock 322 11 214 minecraft:polished_blackstone
fill 322 11 215 322 14 215 minecraft:red_nether_bricks
setblock 322 11 218 minecraft:red_nether_bricks
setblock 322 11 219 minecraft:polished_blackstone
fill 322 11 220 322 14 220 minecraft:red_nether_bricks
setblock 323 11 183 minecraft:polished_blackstone
fill 323 11 184 323 14 184 minecraft:red_nether_bricks
setblock 323 11 188 minecraft:polished_blackstone
fill 323 11 189 323 14 189 minecraft:red_nether_bricks
setblock 323 11 193 minecraft:polished_blackstone
fill 323 11 194 323 14 194 minecraft:red_nether_bricks
setblock 323 11 197 minecraft:red_nether_bricks
setblock 323 11 198 minecraft:polished_blackstone
fill 323 11 199 323 13 199 minecraft:red_nether_bricks
setblock 323 11 203 minecraft:polished_blackstone
fill 323 11 204 323 14 204 minecraft:red_nether_bricks
setblock 323 11 208 minecraft:polished_blackstone
fill 323 11 209 323 14 209 minecraft:red_nether_bricks
setblock 323 11 213 minecraft:polished_blackstone
fill 323 11 214 323 14 214 minecraft:red_nether_bricks
setblock 323 11 218 minecraft:polished_blackstone
fill 323 11 219 323 14 219 minecraft:red_nether_bricks
setblock 283 12 182 minecraft:polished_blackstone
fill 283 12 183 283 15 183 minecraft:red_nether_bricks
setblock 283 12 187 minecraft:polished_blackstone
fill 283 12 188 283 15 188 minecraft:red_nether_bricks
setblock 283 12 191 minecraft:red_nether_bricks
setblock 283 12 192 minecraft:polished_blackstone
fill 283 12 193 284 14 193 minecraft:red_nether_bricks
setblock 283 12 196 minecraft:red_nether_bricks
setblock 283 12 197 minecraft:polished_blackstone
fill 283 12 198 283 14 198 minecraft:red_nether_bricks
setblock 283 12 202 minecraft:polished_blackstone
fill 283 12 203 283 15 203 minecraft:red_nether_bricks
setblock 283 12 207 minecraft:polished_blackstone
fill 283 12 208 283 15 208 minecraft:red_nether_bricks
setblock 283 12 212 minecraft:polished_blackstone
fill 283 12 213 283 15 213 minecraft:red_nether_bricks
setblock 283 12 217 minecraft:polished_blackstone
fill 283 12 218 283 15 218 minecraft:red_nether_bricks
setblock 283 12 222 minecraft:polished_blackstone
fill 284 12 182 284 14 182 minecraft:red_nether_bricks
setblock 284 12 186 minecraft:polished_blackstone
fill 284 12 187 284 14 187 minecraft:red_nether_bricks
setblock 284 12 191 minecraft:polished_blackstone
fill 284 12 192 284 14 192 minecraft:red_nether_bricks
setblock 284 12 206 minecraft:polished_blackstone
fill 284 12 207 284 15 207 minecraft:red_nether_bricks
setblock 284 12 211 minecraft:polished_blackstone
fill 284 12 212 284 15 212 minecraft:red_nether_bricks
setblock 284 12 215 minecraft:red_nether_bricks
setblock 284 12 216 minecraft:polished_blackstone
fill 284 12 217 284 15 217 minecraft:red_nether_bricks
setblock 284 12 221 minecraft:polished_blackstone
fill 284 12 222 284 15 222 minecraft:red_nether_bricks
setblock 285 12 184 minecraft:light[level=14]
setblock 285 12 192 minecraft:light[level=14]
setblock 285 12 200 minecraft:light[level=14]
setblock 285 12 206 minecraft:red_nether_bricks
setblock 285 12 210 minecraft:polished_blackstone
fill 285 12 211 285 15 211 minecraft:red_nether_bricks
setblock 285 12 215 minecraft:polished_blackstone
fill 285 12 216 285 15 216 minecraft:red_nether_bricks
setblock 285 12 218 minecraft:red_nether_bricks
fill 285 12 221 285 13 221 minecraft:red_nether_bricks
setblock 286 12 209 minecraft:polished_blackstone
fill 286 12 210 286 13 210 minecraft:red_nether_bricks
setblock 286 12 213 minecraft:red_nether_bricks
setblock 288 12 222 minecraft:polished_blackstone
setblock 293 12 184 minecraft:light[level=14]
setblock 293 12 192 minecraft:light[level=14]
setblock 293 12 200 minecraft:light[level=14]
setblock 293 12 208 minecraft:light[level=14]
setblock 293 12 216 minecraft:light[level=14]
setblock 298 12 182 minecraft:polished_blackstone
fill 299 12 182 299 15 182 minecraft:red_nether_bricks
setblock 301 12 184 minecraft:light[level=14]
setblock 301 12 192 minecraft:light[level=14]
setblock 301 12 200 minecraft:light[level=14]
setblock 301 12 208 minecraft:light[level=14]
setblock 301 12 216 minecraft:light[level=14]
setblock 302 12 183 minecraft:polished_blackstone
setblock 302 12 184 minecraft:red_nether_bricks
setblock 303 12 182 minecraft:polished_blackstone
fill 303 12 183 303 14 183 minecraft:red_nether_bricks
setblock 303 12 222 minecraft:polished_blackstone
fill 304 12 182 304 15 182 minecraft:red_nether_bricks
setblock 307 12 183 minecraft:polished_blackstone
setblock 308 12 182 minecraft:polished_blackstone
fill 309 12 182 309 13 182 minecraft:red_nether_bricks
setblock 309 12 184 minecraft:light[level=14]
setblock 309 12 192 minecraft:light[level=14]
setblock 309 12 200 minecraft:light[level=14]
setblock 309 12 208 minecraft:light[level=14]
setblock 309 12 216 minecraft:light[level=14]
setblock 313 12 182 minecraft:polished_blackstone
fill 314 12 182 314 15 182 minecraft:red_nether_bricks
setblock 316 12 184 minecraft:polished_blackstone
setblock 317 12 183 minecraft:polished_blackstone
fill 317 12 184 317 15 184 minecraft:red_nether_bricks
setblock 317 12 192 minecraft:light[level=14]
setblock 317 12 200 minecraft:light[level=14]
setblock 317 12 208 minecraft:light[level=14]
setblock 317 12 216 minecraft:light[level=14]
setblock 317 12 222 minecraft:red_nether_bricks
setblock 318 12 182 minecraft:polished_blackstone
fill 318 12 183 318 15 183 minecraft:red_nether_bricks
setblock 318 12 222 minecraft:polished_blackstone
fill 319 12 182 319 15 182 minecraft:red_nether_bricks
fill 319 12 184 319 12 185 minecraft:red_nether_bricks
fill 319 12 222 319 15 222 minecraft:red_nether_bricks
setblock 320 12 184 minecraft:red_nether_bricks
setblock 320 12 185 minecraft:polished_blackstone
fill 320 12 186 320 14 186 minecraft:red_nether_bricks
setblock 320 12 190 minecraft:polished_blackstone
fill 320 12 191 320 15 191 minecraft:red_nether_bricks
fill 320 12 221 320 15 221 minecraft:red_nether_bricks
setblock 321 12 184 minecraft:polished_blackstone
fill 321 12 185 321 15 185 minecraft:red_nether_bricks
setblock 321 12 189 minecraft:polished_blackstone
fill 321 12 190 321 15 190 minecraft:red_nether_bricks
setblock 321 12 193 minecraft:red_nether_bricks
setblock 321 12 208 minecraft:red_nether_bricks
setblock 321 12 209 minecraft:polished_blackstone
fill 321 12 210 321 15 210 minecraft:red_nether_bricks
setblock 321 12 213 minecraft:red_nether_bricks
setblock 321 12 214 minecraft:polished_blackstone
setblock 322 12 183 minecraft:polished_blackstone
fill 322 12 184 322 15 184 minecraft:red_nether_bricks
setblock 322 12 188 minecraft:polished_blackstone
fill 322 12 189 322 15 189 minecraft:red_nether_bricks
setblock 322 12 193 minecraft:polished_blackstone
fill 322 12 194 322 15 194 minecraft:red_nether_bricks
fill 322 12 196 322 13 196 minecraft:red_nether_bricks
setblock 322 12 208 minecraft:polished_blackstone
fill 322 12 209 322 15 209 minecraft:red_nether_bricks
setblock 322 12 212 minecraft:red_nether_bricks
setblock 322 12 213 minecraft:polished_blackstone
fill 322 12 214 322 15 214 minecraft:red_nether_bricks
setblock 322 12 218 minecraft:polished_blackstone
fill 322 12 219 322 15 219 minecraft:red_nether_bricks
setblock 323 12 182 minecraft:polished_blackstone
fill 323 12 183 323 15 183 minecraft:red_nether_bricks
setblock 323 12 187 minecraft:polished_blackstone
fill 323 12 188 323 15 188 minecraft:red_nether_bricks
setblock 323 12 192 minecraft:polished_blackstone
fill 323 12 193 323 15 193 minecraft:red_nether_bricks
setblock 323 12 197 minecraft:polished_blackstone
fill 323 12 198 323 14 198 minecraft:red_nether_bricks
setblock 323 12 202 minecraft:polished_blackstone
fill 323 12 203 323 13 203 minecraft:red_nether_bricks
setblock 323 12 207 minecraft:polished_blackstone
fill 323 12 208 323 15 208 minecraft:red_nether_bricks
setblock 323 12 212 minecraft:polished_blackstone
fill 323 12 213 323 15 213 minecraft:red_nether_bricks
setblock 323 12 217 minecraft:polished_blackstone
fill 323 12 218 323 15 218 minecraft:red_nether_bricks
setblock 323 12 222 minecraft:polished_blackstone
fill 283 13 182 283 15 182 minecraft:red_nether_bricks
setblock 283 13 186 minecraft:polished_blackstone
fill 283 13 187 283 16 187 minecraft:red_nether_bricks
setblock 283 13 191 minecraft:polished_blackstone
fill 283 13 192 283 16 192 minecraft:red_nether_bricks
setblock 283 13 196 minecraft:polished_blackstone
fill 283 13 197 283 15 197 minecraft:red_nether_bricks
setblock 283 13 201 minecraft:polished_blackstone
fill 283 13 202 283 14 202 minecraft:red_nether_bricks
setblock 283 13 206 minecraft:polished_blackstone
fill 283 13 207 283 16 207 minecraft:red_nether_bricks
setblock 283 13 211 minecraft:polished_blackstone
fill 283 13 212 283 16 212 minecraft:red_nether_bricks
setblock 283 13 216 minecraft:polished_blackstone
fill 283 13 217 283 16 217 minecraft:red_nether_bricks
setblock 283 13 221 minecraft:polished_blackstone
fill 283 13 222 283 16 222 minecraft:red_nether_bricks
setblock 284 13 185 minecraft:polished_blackstone
fill 284 13 186 284 14 186 minecraft:red_nether_bricks
setblock 284 13 190 minecraft:polished_blackstone
fill 284 13 191 284 15 191 minecraft:red_nether_bricks
setblock 284 13 205 minecraft:polished_blackstone
fill 284 13 206 284 15 206 minecraft:red_nether_bricks
setblock 284 13 210 minecraft:polished_blackstone
fill 284 13 211 284 16 211 minecraft:red_nether_bricks
setblock 284 13 215 minecraft:polished_blackstone
fill 284 13 216 284 16 216 minecraft:red_nether_bricks
setblock 284 13 220 minecraft:polished_blackstone
fill 284 13 221 284 15 221 minecraft:red_nether_bricks
fill 285 13 206 285 33 206 minecraft:gilded_blackstone
setblock 285 13 209 minecraft:polished_blackstone
fill 285 13 210 285 16 210 minecraft:red_nether_bricks
setblock 285 13 214 minecraft:polished_blackstone
fill 285 13 215 285 16 215 minecraft:red_nether_bricks
setblock 286 13 213 minecraft:polished_blackstone
setblock 287 13 222 minecraft:polished_blackstone
fill 298 13 182 298 14 182 minecraft:red_nether_bricks
setblock 301 13 183 minecraft:polished_blackstone
setblock 302 13 182 minecraft:polished_blackstone
fill 302 13 183 302 14 183 minecraft:red_nether_bricks
setblock 302 13 222 minecraft:polished_blackstone
fill 303 13 182 303 15 182 minecraft:red_nether_bricks
setblock 307 13 182 minecraft:polished_blackstone
setblock 308 13 182 minecraft:red_nether_bricks
setblock 312 13 182 minecraft:polished_blackstone
fill 313 13 182 313 15 182 minecraft:red_nether_bricks
setblock 316 13 183 minecraft:polished_blackstone
fill 316 13 184 316 14 184 minecraft:red_nether_bricks
setblock 317 13 182 minecraft:polished_blackstone
fill 317 13 183 317 16 183 minecraft:red_nether_bricks
setblock 317 13 222 minecraft:polished_blackstone
fill 318 13 182 318 16 182 minecraft:red_nether_bricks
fill 318 13 222 318 16 222 minecraft:red_nether_bricks
setblock 319 13 184 minecraft:red_nether_bricks
setblock 319 13 185 minecraft:polished_blackstone
fill 319 13 221 319 16 221 minecraft:red_nether_bricks
setblock 320 13 184 minecraft:polished_blackstone
fill 320 13 185 320 14 185 minecraft:red_nether_bricks
setblock 320 13 188 minecraft:red_nether_bricks
setblock 320 13 189 minecraft:polished_blackstone
fill 320 13 190 320 15 190 minecraft:red_nether_bricks
fill 320 13 192 320 14 192 minecraft:red_nether_bricks
setblock 321 13 183 minecraft:polished_blackstone
fill 321 13 184 321 15 184 minecraft:red_nether_bricks
setblock 321 13 188 minecraft:polished_blackstone
fill 321 13 189 321 16 189 minecraft:red_nether_bricks
setblock 321 13 193 minecraft:polished_blackstone
fill 321 13 194 321 15 194 minecraft:red_nether_bricks
fill 321 13 209 321 14 209 minecraft:red_nether_bricks
setblock 321 13 213 minecraft:polished_blackstone
fill 321 13 214 321 14 216 minecraft:red_nether_bricks
setblock 322 13 182 minecraft:polished_blackstone
fill 322 13 183 322 16 183 minecraft:red_nether_bricks
setblock 322 13 187 minecraft:polished_blackstone
fill 322 13 188 322 16 188 minecraft:red_nether_bricks
setblock 322 13 192 minecraft:polished_blackstone
fill 322 13 193 322 16 193 minecraft:red_nether_bricks
setblock 322 13 207 minecraft:polished_blackstone
fill 322 13 208 322 15 208 minecraft:red_nether_bricks
setblock 322 13 212 minecraft:polished_blackstone
fill 322 13 213 322 16 213 minecraft:red_nether_bricks
setblock 322 13 216 minecraft:red_nether_bricks
setblock 322 13 217 minecraft:polished_blackstone
fill 322 13 218 322 16 218 minecraft:red_nether_bricks
setblock 322 13 222 minecraft:polished_blackstone
fill 323 13 182 323 16 182 minecraft:red_nether_bricks
setblock 323 13 186 minecraft:polished_blackstone
fill 323 13 187 323 16 187 minecraft:red_nether_bricks
setblock 323 13 191 minecraft:polished_blackstone
fill 323 13 192 323 16 192 minecraft:red_nether_bricks
setblock 323 13 196 minecraft:polished_blackstone
fill 323 13 197 323 16 197 minecraft:red_nether_bricks
setblock 323 13 202 minecraft:red_nether_bricks
setblock 323 13 206 minecraft:polished_blackstone
fill 323 13 207 323 16 207 minecraft:red_nether_bricks
setblock 323 13 211 minecraft:polished_blackstone
fill 323 13 212 323 16 212 minecraft:red_nether_bricks
setblock 323 13 216 minecraft:polished_blackstone
fill 323 13 217 323 16 217 minecraft:red_nether_bricks
setblock 323 13 221 minecraft:polished_blackstone
fill 323 13 222 323 16 222 minecraft:red_nether_bricks
setblock 283 14 185 minecraft:polished_blackstone
fill 283 14 186 283 16 186 minecraft:red_nether_bricks
setblock 283 14 190 minecraft:polished_blackstone
fill 283 14 191 283 17 191 minecraft:red_nether_bricks
setblock 283 14 195 minecraft:polished_blackstone
fill 283 14 196 283 17 196 minecraft:red_nether_bricks
setblock 283 14 201 minecraft:red_nether_bricks
setblock 283 14 205 minecraft:polished_blackstone
fill 283 14 206 283 17 206 minecraft:red_nether_bricks
setblock 283 14 210 minecraft:polished_blackstone
fill 283 14 211 283 17 211 minecraft:red_nether_bricks
setblock 283 14 215 minecraft:polished_blackstone
fill 283 14 216 283 17 216 minecraft:red_nether_bricks
setblock 283 14 220 minecraft:polished_blackstone
fill 283 14 221 283 17 221 minecraft:red_nether_bricks
setblock 284 14 185 minecraft:red_nether_bricks
setblock 284 14 189 minecraft:polished_blackstone
fill 284 14 190 284 15 190 minecraft:red_nether_bricks
setblock 284 14 205 minecraft:red_nether_bricks
setblock 284 14 209 minecraft:polished_blackstone
fill 284 14 210 284 17 210 minecraft:red_nether_bricks
setblock 284 14 214 minecraft:polished_blackstone
fill 284 14 215 284 17 215 minecraft:red_nether_bricks
setblock 284 14 219 minecraft:polished_blackstone
fill 284 14 220 284 16 220 minecraft:red_nether_bricks
setblock 285 14 208 minecraft:polished_blackstone
fill 285 14 209 285 15 209 minecraft:red_nether_bricks
setblock 285 14 212 minecraft:red_nether_bricks
setblock 285 14 213 minecraft:polished_blackstone
fill 285 14 214 285 17 214 minecraft:red_nether_bricks
setblock 286 14 222 minecraft:polished_blackstone
setblock 301 14 182 minecraft:polished_blackstone
setblock 301 14 183 minecraft:red_nether_bricks
fill 302 14 182 302 15 182 minecraft:red_nether_bricks
setblock 306 14 182 minecraft:polished_blackstone
setblock 315 14 183 minecraft:polished_blackstone
setblock 316 14 182 minecraft:polished_blackstone
fill 316 14 183 316 17 183 minecraft:red_nether_bricks
setblock 316 14 222 minecraft:polished_blackstone
fill 317 14 182 317 17 182 minecraft:red_nether_bricks
fill 317 14 222 317 17 222 minecraft:red_nether_bricks
setblock 318 14 184 minecraft:red_nether_bricks
setblock 319 14 184 minecraft:polished_blackstone
setblock 319 14 185 minecraft:red_nether_bricks
setblock 320 14 183 minecraft:polished_blackstone
fill 320 14 184 320 16 184 minecraft:red_nether_bricks
setblock 320 14 188 minecraft:polished_blackstone
fill 320 14 189 320 15 189 minecraft:red_nether_bricks
setblock 321 14 182 minecraft:polished_blackstone
fill 321 14 183 321 17 183 minecraft:red_nether_bricks
setblock 321 14 187 minecraft:polished_blackstone
fill 321 14 188 321 16 188 minecraft:red_nether_bricks
setblock 321 14 192 minecraft:polished_blackstone
fill 321 14 193 321 16 193 minecraft:red_nether_bricks
setblock 321 14 211 minecraft:red_nether_bricks
setblock 321 14 212 minecraft:polished_blackstone
fill 321 14 213 321 17 213 minecraft:red_nether_bricks
setblock 321 14 217 minecraft:polished_blackstone
setblock 321 14 222 minecraft:polished_blackstone
fill 322 14 182 322 17 182 minecraft:red_nether_bricks
setblock 322 14 186 minecraft:polished_blackstone
fill 322 14 187 322 17 187 minecraft:red_nether_bricks
setblock 322 14 191 minecraft:polished_blackstone
fill 322 14 192 322 17 192 minecraft:red_nether_bricks
setblock 322 14 196 minecraft:polished_blackstone
setblock 322 14 206 minecraft:polished_blackstone
setblock 322 14 207 minecraft:red_nether_bricks
setblock 322 14 211 minecraft:polished_blackstone
fill 322 14 212 322 17 212 minecraft:red_nether_bricks
setblock 322 14 216 minecraft:polished_blackstone
fill 322 14 217 322 17 217 minecraft:red_nether_bricks
setblock 322 14 221 minecraft:polished_blackstone
fill 322 14 222 322 17 222 minecraft:red_nether_bricks
setblock 323 14 185 minecraft:polished_blackstone
fill 323 14 186 323 17 186 minecraft:red_nether_bricks
setblock 323 14 190 minecraft:polished_blackstone
fill 323 14 191 323 17 191 minecraft:red_nether_bricks
setblock 323 14 195 minecraft:polished_blackstone
fill 323 14 196 323 17 196 minecraft:red_nether_bricks
setblock 323 14 205 minecraft:polished_blackstone
fill 323 14 206 323 15 206 minecraft:red_nether_bricks
setblock 323 14 210 minecraft:polished_blackstone
fill 323 14 211 323 17 211 minecraft:red_nether_bricks
setblock 323 14 215 minecraft:polished_blackstone
fill 323 14 216 323 17 216 minecraft:red_nether_bricks
setblock 323 14 220 minecraft:polished_blackstone
fill 323 14 221 323 17 221 minecraft:red_nether_bricks
setblock 283 15 184 minecraft:polished_blackstone
fill 283 15 185 283 16 185 minecraft:red_nether_bricks
setblock 283 15 189 minecraft:polished_blackstone
fill 283 15 190 283 17 190 minecraft:red_nether_bricks
setblock 283 15 193 minecraft:red_nether_bricks
setblock 283 15 194 minecraft:polished_blackstone
fill 283 15 195 283 18 195 minecraft:red_nether_bricks
setblock 283 15 204 minecraft:polished_blackstone
fill 283 15 205 283 16 205 minecraft:red_nether_bricks
setblock 283 15 209 minecraft:polished_blackstone
fill 283 15 210 283 18 210 minecraft:red_nether_bricks
setblock 283 15 214 minecraft:polished_blackstone
fill 283 15 215 283 18 215 minecraft:red_nether_bricks
setblock 283 15 219 minecraft:polished_blackstone
fill 283 15 220 283 18 220 minecraft:red_nether_bricks
setblock 284 15 189 minecraft:red_nether_bricks
setblock 284 15 208 minecraft:polished_blackstone
fill 284 15 209 284 17 209 minecraft:red_nether_bricks
setblock 284 15 213 minecraft:polished_blackstone
fill 284 15 214 284 18 214 minecraft:red_nether_bricks
setblock 284 15 218 minecraft:polished_blackstone
fill 284 15 219 284 18 219 minecraft:red_nether_bricks
setblock 285 15 212 minecraft:polished_blackstone
fill 285 15 213 285 17 213 minecraft:red_nether_bricks
setblock 285 15 222 minecraft:polished_blackstone
setblock 300 15 182 minecraft:polished_blackstone
setblock 301 15 182 minecraft:red_nether_bricks
setblock 315 15 182 minecraft:polished_blackstone
setblock 315 15 183 minecraft:red_nether_bricks
fill 316 15 182 316 18 182 minecraft:red_nether_bricks
fill 316 15 222 316 18 222 minecraft:red_nether_bricks
setblock 318 15 184 minecraft:polished_blackstone
fill 318 15 221 318 17 221 minecraft:red_nether_bricks
setblock 319 15 183 minecraft:polished_blackstone
fill 319 15 184 319 16 184 minecraft:red_nether_bricks
setblock 320 15 182 minecraft:polished_blackstone
fill 320 15 183 320 18 183 minecraft:red_nether_bricks
setblock 320 15 187 minecraft:polished_blackstone
setblock 320 15 188 minecraft:red_nether_bricks
setblock 320 15 222 minecraft:polished_blackstone
fill 321 15 182 321 18 182 minecraft:red_nether_bricks
setblock 321 15 186 minecraft:polished_blackstone
fill 321 15 187 321 16 187 minecraft:red_nether_bricks
setblock 321 15 191 minecraft:polished_blackstone
fill 321 15 192 321 17 192 minecraft:red_nether_bricks
setblock 321 15 211 minecraft:polished_blackstone
fill 321 15 212 321 16 212 minecraft:red_nether_bricks
fill 321 15 214 321 15 215 minecraft:red_nether_bricks
setblock 321 15 216 minecraft:polished_blackstone
fill 321 15 217 321 17 218 minecraft:red_nether_bricks
setblock 321 15 221 minecraft:polished_blackstone
fill 321 15 222 321 18 222 minecraft:red_nether_bricks
setblock 322 15 185 minecraft:polished_blackstone
fill 322 15 186 322 17 186 minecraft:red_nether_bricks
setblock 322 15 190 minecraft:polished_blackstone
fill 322 15 191 322 18 191 minecraft:red_nether_bricks
setblock 322 15 195 minecraft:polished_blackstone
setblock 322 15 210 minecraft:polished_blackstone
fill 322 15 211 322 18 211 minecraft:red_nether_bricks
setblock 322 15 215 minecraft:polished_blackstone
fill 322 15 216 322 18 216 minecraft:red_nether_bricks
setblock 322 15 220 minecraft:polished_blackstone
fill 322 15 221 322 18 221 minecraft:red_nether_bricks
setblock 323 15 184 minecraft:polished_blackstone
fill 323 15 185 323 18 185 minecraft:red_nether_bricks
setblock 323 15 189 minecraft:polished_blackstone
fill 323 15 190 323 18 190 minecraft:red_nether_bricks
setblock 323 15 194 minecraft:polished_blackstone
fill 323 15 195 323 18 195 minecraft:red_nether_bricks
setblock 323 15 205 minecraft:red_nether_bricks
setblock 323 15 209 minecraft:polished_blackstone
fill 323 15 210 323 18 210 minecraft:red_nether_bricks
setblock 323 15 214 minecraft:polished_blackstone
fill 323 15 215 323 18 215 minecraft:red_nether_bricks
setblock 323 15 219 minecraft:polished_blackstone
fill 323 15 220 323 18 220 minecraft:red_nether_bricks
setblock 283 16 188 minecraft:polished_blackstone
fill 283 16 189 283 17 189 minecraft:red_nether_bricks
setblock 283 16 193 minecraft:polished_blackstone
fill 283 16 194 283 19 194 minecraft:red_nether_bricks
setblock 283 16 204 minecraft:red_nether_bricks
setblock 283 16 208 minecraft:polished_blackstone
fill 283 16 209 283 19 209 minecraft:red_nether_bricks
setblock 283 16 213 minecraft:polished_blackstone
fill 283 16 214 283 19 214 minecraft:red_nether_bricks
setblock 283 16 218 minecraft:polished_blackstone
fill 283 16 219 283 19 219 minecraft:red_nether_bricks
setblock 284 16 207 minecraft:polished_blackstone
setblock 284 16 208 minecraft:red_nether_bricks
setblock 284 16 212 minecraft:polished_blackstone
fill 284 16 213 284 19 213 minecraft:red_nether_bricks
setblock 284 16 217 minecraft:polished_blackstone
fill 284 16 218 284 19 218 minecraft:red_nether_bricks
setblock 284 16 222 minecraft:polished_blackstone
setblock 285 16 211 minecraft:polished_blackstone
setblock 285 16 212 minecraft:red_nether_bricks
setblock 285 16 216 minecraft:polished_blackstone
setblock 314 16 182 minecraft:polished_blackstone
fill 315 16 182 315 19 182 minecraft:red_nether_bricks
setblock 318 16 183 minecraft:polished_blackstone
setblock 319 16 182 minecraft:polished_blackstone
fill 319 16 183 319 18 183 minecraft:red_nether_bricks
setblock 319 16 222 minecraft:polished_blackstone
fill 320 16 182 320 19 182 minecraft:red_nether_bricks
setblock 320 16 221 minecraft:polished_blackstone
fill 320 16 222 320 19 222 minecraft:red_nether_bricks
setblock 321 16 185 minecraft:polished_blackstone
setblock 321 16 186 minecraft:red_nether_bricks
setblock 321 16 190 minecraft:polished_blackstone
fill 321 16 191 321 17 191 minecraft:red_nether_bricks
setblock 321 16 211 minecraft:red_nether_bricks
setblock 321 16 214 minecraft:red_nether_bricks
setblock 321 16 215 minecraft:polished_blackstone
fill 321 16 216 321 19 216 minecraft:red_nether_bricks
fill 321 16 221 321 19 221 minecraft:red_nether_bricks
setblock 322 16 184 minecraft:polished_blackstone
fill 322 16 185 322 17 185 minecraft:red_nether_bricks
setblock 322 16 189 minecraft:polished_blackstone
fill 322 16 190 322 18 190 minecraft:red_nether_bricks
setblock 322 16 194 minecraft:polished_blackstone
setblock 322 16 195 minecraft:red_nether_bricks
setblock 322 16 209 minecraft:polished_blackstone
fill 322 16 210 322 17 210 minecraft:red_nether_bricks
setblock 322 16 214 minecraft:polished_blackstone
fill 322 16 215 322 19 215 minecraft:red_nether_bricks
setblock 322 16 219 minecraft:polished_blackstone
fill 322 16 220 322 19 220 minecraft:red_nether_bricks
setblock 323 16 183 minecraft:polished_blackstone
fill 323 16 184 323 17 184 minecraft:red_nether_bricks
setblock 323 16 188 minecraft:polished_blackstone
fill 323 16 189 323 19 189 minecraft:red_nether_bricks
setblock 323 16 193 minecraft:polished_blackstone
fill 323 16 194 323 19 194 minecraft:red_nether_bricks
setblock 323 16 208 minecraft:polished_blackstone
fill 323 16 209 323 18 209 minecraft:red_nether_bricks
setblock 323 16 213 minecraft:polished_blackstone
fill 323 16 214 323 19 214 minecraft:red_nether_bricks
setblock 323 16 218 minecraft:polished_blackstone
fill 323 16 219 323 19 219 minecraft:red_nether_bricks
setblock 283 17 188 minecraft:red_nether_bricks
setblock 283 17 192 minecraft:polished_blackstone
fill 283 17 193 283 19 193 minecraft:red_nether_bricks
setblock 283 17 207 minecraft:polished_blackstone
fill 283 17 208 283 19 208 minecraft:red_nether_bricks
setblock 283 17 212 minecraft:polished_blackstone
fill 283 17 213 283 20 213 minecraft:red_nether_bricks
setblock 283 17 217 minecraft:polished_blackstone
fill 283 17 218 283 20 218 minecraft:red_nether_bricks
setblock 283 17 222 minecraft:polished_blackstone
setblock 284 17 211 minecraft:polished_blackstone
fill 284 17 212 284 20 212 minecraft:red_nether_bricks
setblock 284 17 216 minecraft:polished_blackstone
fill 284 17 217 284 20 217 minecraft:red_nether_bricks
setblock 284 17 222 minecraft:red_nether_bricks
setblock 285 17 215 minecraft:polished_blackstone
fill 314 17 182 314 20 182 minecraft:red_nether_bricks
fill 315 17 222 315 19 222 minecraft:red_nether_bricks
setblock 317 17 183 minecraft:polished_blackstone
setblock 318 17 182 minecraft:polished_blackstone
fill 318 17 183 318 19 183 minecraft:red_nether_bricks
setblock 318 17 222 minecraft:polished_blackstone
fill 319 17 182 319 20 182 minecraft:red_nether_bricks
setblock 319 17 221 minecraft:polished_blackstone
fill 319 17 222 319 20 222 minecraft:red_nether_bricks
fill 320 17 221 320 20 221 minecraft:red_nether_bricks
setblock 321 17 189 minecraft:polished_blackstone
setblock 321 17 190 minecraft:red_nether_bricks
setblock 321 17 214 minecraft:polished_blackstone
fill 321 17 215 321 20 215 minecraft:red_nether_bricks
setblock 322 17 188 minecraft:polished_blackstone
fill 322 17 189 322 18 189 minecraft:red_nether_bricks
setblock 322 17 193 minecraft:polished_blackstone
setblock 322 17 194 minecraft:red_nether_bricks
setblock 322 17 213 minecraft:polished_blackstone
fill 322 17 214 322 20 214 minecraft:red_nether_bricks
setblock 322 17 218 minecraft:polished_blackstone
fill 322 17 219 322 20 219 minecraft:red_nether_bricks
setblock 323 17 182 minecraft:polished_blackstone
setblock 323 17 183 minecraft:red_nether_bricks
setblock 323 17 187 minecraft:polished_blackstone
fill 323 17 188 323 18 188 minecraft:red_nether_bricks
setblock 323 17 192 minecraft:polished_blackstone
fill 323 17 193 323 20 193 minecraft:red_nether_bricks
setblock 323 17 208 minecraft:red_nether_bricks
setblock 323 17 212 minecraft:polished_blackstone
fill 323 17 213 323 20 213 minecraft:red_nether_bricks
setblock 323 17 217 minecraft:polished_blackstone
fill 323 17 218 323 20 218 minecraft:red_nether_bricks
setblock 323 17 222 minecraft:polished_blackstone
setblock 283 18 191 minecraft:polished_blackstone
setblock 283 18 192 minecraft:red_nether_bricks
setblock 283 18 196 minecraft:polished_blackstone
setblock 283 18 207 minecraft:red_nether_bricks
setblock 283 18 211 minecraft:polished_blackstone
fill 283 18 212 283 21 212 minecraft:red_nether_bricks
setblock 283 18 216 minecraft:polished_blackstone
fill 283 18 217 283 21 217 minecraft:red_nether_bricks
setblock 283 18 221 minecraft:polished_blackstone
fill 283 18 222 283 21 222 minecraft:red_nether_bricks
fill 284 18 205 284 18 207 minecraft:polished_blackstone
setblock 284 18 210 minecraft:polished_blackstone
fill 284 18 211 284 19 211 minecraft:red_nether_bricks
setblock 284 18 215 minecraft:polished_blackstone
fill 284 18 216 284 21 216 minecraft:red_nether_bricks
fill 285 18 205 286 18 205 minecraft:polished_blackstone
fill 285 18 207 286 18 207 minecraft:polished_blackstone
setblock 286 18 206 minecraft:polished_blackstone
setblock 317 18 182 minecraft:polished_blackstone
fill 317 18 183 317 21 183 minecraft:red_nether_bricks
setblock 317 18 221 minecraft:red_nether_bricks
setblock 317 18 222 minecraft:polished_blackstone
fill 318 18 182 318 21 182 minecraft:red_nether_bricks
setblock 318 18 221 minecraft:polished_blackstone
fill 318 18 222 318 21 222 minecraft:red_nether_bricks
fill 319 18 221 319 21 221 minecraft:red_nether_bricks
fill 321 18 214 321 19 214 minecraft:red_nether_bricks
setblock 321 18 217 minecraft:red_nether_bricks
setblock 321 18 218 minecraft:polished_blackstone
setblock 322 18 182 minecraft:polished_blackstone
setblock 322 18 192 minecraft:polished_blackstone
setblock 322 18 193 minecraft:red_nether_bricks
setblock 322 18 212 minecraft:polished_blackstone
fill 322 18 213 322 21 213 minecraft:red_nether_bricks
setblock 322 18 217 minecraft:polished_blackstone
fill 322 18 218 322 21 218 minecraft:red_nether_bricks
setblock 322 18 222 minecraft:polished_blackstone
setblock 323 18 182 minecraft:red_nether_bricks
setblock 323 18 186 minecraft:polished_blackstone
setblock 323 18 187 minecraft:red_nether_bricks
setblock 323 18 191 minecraft:polished_blackstone
fill 323 18 192 323 20 192 minecraft:red_nether_bricks
setblock 323 18 196 minecraft:polished_blackstone
setblock 323 18 211 minecraft:polished_blackstone
fill 323 18 212 323 21 212 minecraft:red_nether_bricks
setblock 323 18 216 minecraft:polished_blackstone
fill 323 18 217 323 21 217 minecraft:red_nether_bricks
setblock 323 18 221 minecraft:polished_blackstone
fill 323 18 222 323 21 222 minecraft:red_nether_bricks
setblock 283 19 195 minecraft:polished_blackstone
setblock 283 19 210 minecraft:polished_blackstone
fill 283 19 211 283 22 211 minecraft:red_nether_bricks
setblock 283 19 215 minecraft:polished_blackstone
fill 283 19 216 283 22 216 minecraft:red_nether_bricks
setblock 283 19 220 minecraft:polished_blackstone
fill 283 19 221 283 22 221 minecraft:red_nether_bricks
setblock 284 19 214 minecraft:polished_blackstone
fill 284 19 215 284 22 215 minecraft:red_nether_bricks
fill 314 19 222 314 20 222 minecraft:red_nether_bricks
setblock 316 19 182 minecraft:polished_blackstone
setblock 316 19 221 minecraft:red_nether_bricks
setblock 316 19 222 minecraft:polished_blackstone
fill 317 19 182 317 22 182 minecraft:red_nether_bricks
setblock 317 19 221 minecraft:polished_blackstone
fill 317 19 222 317 22 222 minecraft:red_nether_bricks
fill 318 19 221 318 22 221 minecraft:red_nether_bricks
setblock 321 19 182 minecraft:polished_blackstone
setblock 321 19 217 minecraft:polished_blackstone
fill 321 19 218 321 21 219 minecraft:red_nether_bricks
setblock 321 19 222 minecraft:polished_blackstone
setblock 322 19 182 minecraft:red_nether_bricks
setblock 322 19 212 minecraft:red_nether_bricks
setblock 322 19 216 minecraft:polished_blackstone
fill 322 19 217 322 22 217 minecraft:red_nether_bricks
setblock 322 19 221 minecraft:polished_blackstone
fill 322 19 222 322 22 222 minecraft:red_nether_bricks
setblock 323 19 190 minecraft:polished_blackstone
setblock 323 19 191 minecraft:red_nether_bricks
setblock 323 19 195 minecraft:polished_blackstone
setblock 323 19 210 minecraft:polished_blackstone
fill 323 19 211 323 22 211 minecraft:red_nether_bricks
setblock 323 19 215 minecraft:polished_blackstone
fill 323 19 216 323 22 216 minecraft:red_nether_bricks
setblock 323 19 220 minecraft:polished_blackstone
fill 323 19 221 323 22 221 minecraft:red_nether_bricks
fill 283 20 195 283 22 196 minecraft:red_nether_bricks
setblock 283 20 209 minecraft:polished_blackstone
fill 283 20 210 283 23 210 minecraft:red_nether_bricks
setblock 283 20 214 minecraft:polished_blackstone
fill 283 20 215 283 23 215 minecraft:red_nether_bricks
setblock 283 20 219 minecraft:polished_blackstone
fill 283 20 220 283 23 220 minecraft:red_nether_bricks
setblock 284 20 213 minecraft:polished_blackstone
fill 284 20 214 284 23 214 minecraft:red_nether_bricks
setblock 284 20 218 minecraft:polished_blackstone
setblock 285 20 184 minecraft:light[level=14]
setblock 285 20 192 minecraft:light[level=14]
setblock 285 20 200 minecraft:light[level=14]
setblock 285 20 208 minecraft:light[level=14]
setblock 285 20 216 minecraft:light[level=14]
setblock 293 20 184 minecraft:light[level=14]
setblock 293 20 192 minecraft:light[level=14]
setblock 293 20 200 minecraft:light[level=14]
setblock 293 20 208 minecraft:light[level=14]
setblock 293 20 216 minecraft:light[level=14]
setblock 301 20 184 minecraft:light[level=14]
setblock 301 20 192 minecraft:light[level=14]
setblock 301 20 200 minecraft:light[level=14]
setblock 301 20 208 minecraft:light[level=14]
setblock 301 20 216 minecraft:light[level=14]
setblock 309 20 184 minecraft:light[level=14]
setblock 309 20 192 minecraft:light[level=14]
setblock 309 20 200 minecraft:light[level=14]
setblock 309 20 208 minecraft:light[level=14]
setblock 309 20 216 minecraft:light[level=14]
fill 313 20 182 313 21 182 minecraft:red_nether_bricks
fill 313 20 222 313 21 222 minecraft:red_nether_bricks
setblock 315 20 182 minecraft:polished_blackstone
setblock 315 20 221 minecraft:red_nether_bricks
setblock 315 20 222 minecraft:polished_blackstone
fill 316 20 182 316 23 182 minecraft:red_nether_bricks
setblock 316 20 221 minecraft:polished_blackstone
fill 316 20 222 316 23 222 minecraft:red_nether_bricks
setblock 317 20 184 minecraft:light[level=14]
setblock 317 20 192 minecraft:light[level=14]
setblock 317 20 200 minecraft:light[level=14]
setblock 317 20 208 minecraft:light[level=14]
setblock 317 20 216 minecraft:light[level=14]
setblock 317 20 220 minecraft:polished_blackstone
fill 317 20 221 317 23 221 minecraft:red_nether_bricks
fill 318 20 220 320 21 220 minecraft:red_nether_bricks
setblock 320 20 182 minecraft:polished_blackstone
setblock 320 20 222 minecraft:polished_blackstone
fill 321 20 182 321 23 182 minecraft:red_nether_bricks
setblock 321 20 216 minecraft:polished_blackstone
fill 321 20 217 321 23 217 minecraft:red_nether_bricks
setblock 321 20 221 minecraft:polished_blackstone
fill 321 20 222 321 23 222 minecraft:red_nether_bricks
setblock 322 20 215 minecraft:polished_blackstone
fill 322 20 216 322 23 216 minecraft:red_nether_bricks
setblock 322 20 220 minecraft:polished_blackstone
fill 322 20 221 322 23 221 minecraft:red_nether_bricks
setblock 323 20 194 minecraft:polished_blackstone
setblock 323 20 195 minecraft:red_nether_bricks
setblock 323 20 214 minecraft:polished_blackstone
fill 323 20 215 323 23 215 minecraft:red_nether_bricks
setblock 323 20 219 minecraft:polished_blackstone
fill 323 20 220 323 23 220 minecraft:red_nether_bricks
setblock 283 21 197 minecraft:red_nether_bricks
setblock 283 21 209 minecraft:red_nether_bricks
setblock 283 21 213 minecraft:polished_blackstone
fill 283 21 214 283 24 214 minecraft:red_nether_bricks
setblock 283 21 218 minecraft:polished_blackstone
fill 283 21 219 283 24 219 minecraft:red_nether_bricks
setblock 284 21 213 minecraft:red_nether_bricks
setblock 284 21 217 minecraft:polished_blackstone
fill 284 21 218 284 24 218 minecraft:red_nether_bricks
fill 295 21 222 298 21 222 minecraft:red_nether_bricks
fill 312 21 182 312 22 182 minecraft:red_nether_bricks
fill 312 21 222 312 22 222 minecraft:red_nether_bricks
fill 313 21 221 314 21 221 minecraft:red_nether_bricks
setblock 314 21 182 minecraft:polished_blackstone
setblock 314 21 222 minecraft:polished_blackstone
fill 315 21 182 315 23 183 minecraft:red_nether_bricks
setblock 315 21 220 minecraft:red_nether_bricks
setblock 315 21 221 minecraft:polished_blackstone
fill 315 21 222 315 24 222 minecraft:red_nether_bricks
fill 316 21 183 316 22 183 minecraft:red_nether_bricks
setblock 316 21 220 minecraft:polished_blackstone
fill 316 21 221 316 24 221 minecraft:red_nether_bricks
fill 317 21 220 317 24 220 minecraft:red_nether_bricks
setblock 318 21 183 minecraft:polished_blackstone
setblock 319 21 182 minecraft:polished_blackstone
setblock 319 21 222 minecraft:polished_blackstone
fill 320 21 182 320 24 182 minecraft:red_nether_bricks
setblock 320 21 221 minecraft:polished_blackstone
fill 320 21 222 320 24 222 minecraft:red_nether_bricks
setblock 321 21 215 minecraft:polished_blackstone
fill 321 21 216 321 24 216 minecraft:red_nether_bricks
setblock 321 21 220 minecraft:polished_blackstone
fill 321 21 221 321 24 221 minecraft:red_nether_bricks
setblock 322 21 214 minecraft:polished_blackstone
fill 322 21 215 322 24 215 minecraft:red_nether_bricks
setblock 322 21 219 minecraft:polished_blackstone
fill 322 21 220 322 24 220 minecraft:red_nether_bricks
setblock 323 21 213 minecraft:polished_blackstone
fill 323 21 214 323 24 214 minecraft:red_nether_bricks
setblock 323 21 218 minecraft:polished_blackstone
fill 323 21 219 323 24 219 minecraft:red_nether_bricks
setblock 283 22 197 minecraft:polished_blackstone
fill 283 22 198 283 23 200 minecraft:red_nether_bricks
setblock 283 22 212 minecraft:polished_blackstone
fill 283 22 213 283 25 213 minecraft:red_nether_bricks
setblock 283 22 217 minecraft:polished_blackstone
fill 283 22 218 283 25 218 minecraft:red_nether_bricks
setblock 283 22 222 minecraft:polished_blackstone
setblock 284 22 216 minecraft:polished_blackstone
fill 284 22 217 284 25 217 minecraft:red_nether_bricks
fill 284 22 219 284 23 219 minecraft:red_nether_bricks
setblock 293 22 222 minecraft:polished_blackstone
fill 294 22 222 297 22 222 minecraft:red_nether_bricks
setblock 297 22 182 minecraft:red_nether_bricks
setblock 298 22 182 minecraft:polished_blackstone
setblock 298 22 222 minecraft:polished_blackstone
fill 299 22 182 299 25 182 minecraft:red_nether_bricks
fill 299 22 222 299 25 222 minecraft:red_nether_bricks
fill 310 22 182 311 23 182 minecraft:red_nether_bricks
fill 310 22 222 311 23 222 minecraft:red_nether_bricks
fill 312 22 221 313 22 221 minecraft:red_nether_bricks
setblock 313 22 182 minecraft:polished_blackstone
setblock 313 22 222 minecraft:polished_blackstone
fill 314 22 182 314 24 183 minecraft:red_nether_bricks
setblock 314 22 220 minecraft:red_nether_bricks
setblock 314 22 221 minecraft:polished_blackstone
fill 314 22 222 314 25 222 minecraft:red_nether_bricks
setblock 315 22 220 minecraft:polished_blackstone
fill 315 22 221 315 25 221 minecraft:red_nether_bricks
fill 316 22 220 316 25 220 minecraft:red_nether_bricks
setblock 317 22 183 minecraft:polished_blackstone
fill 317 22 219 318 24 219 minecraft:red_nether_bricks
setblock 318 22 182 minecraft:polished_blackstone
fill 318 22 183 318 25 183 minecraft:red_nether_bricks
fill 318 22 220 319 22 220 minecraft:red_nether_bricks
setblock 318 22 222 minecraft:polished_blackstone
fill 319 22 182 319 25 182 minecraft:red_nether_bricks
setblock 319 22 221 minecraft:polished_blackstone
fill 319 22 222 319 25 222 minecraft:red_nether_bricks
setblock 320 22 220 minecraft:polished_blackstone
fill 320 22 221 320 25 221 minecraft:red_nether_bricks
fill 321 22 215 321 23 215 minecraft:red_nether_bricks
setblock 321 22 218 minecraft:red_nether_bricks
setblock 321 22 219 minecraft:polished_blackstone
fill 321 22 220 321 25 220 minecraft:red_nether_bricks
setblock 322 22 213 minecraft:polished_blackstone
fill 322 22 214 322 25 214 minecraft:red_nether_bricks
setblock 322 22 218 minecraft:polished_blackstone
fill 322 22 219 322 25 219 minecraft:red_nether_bricks
setblock 323 22 212 minecraft:polished_blackstone
fill 323 22 213 323 25 213 minecraft:red_nether_bricks
setblock 323 22 217 minecraft:polished_blackstone
fill 323 22 218 323 25 218 minecraft:red_nether_bricks
setblock 323 22 222 minecraft:polished_blackstone
setblock 283 23 195 minecraft:red_nether_bricks
setblock 283 23 196 minecraft:polished_blackstone
fill 283 23 197 283 26 197 minecraft:red_nether_bricks
setblock 283 23 201 minecraft:polished_blackstone
fill 283 23 202 283 26 202 minecraft:red_nether_bricks
setblock 283 23 211 minecraft:polished_blackstone
fill 283 23 212 283 26 212 minecraft:red_nether_bricks
setblock 283 23 216 minecraft:polished_blackstone
fill 283 23 217 283 26 217 minecraft:red_nether_bricks
setblock 283 23 221 minecraft:polished_blackstone
fill 283 23 222 284 25 222 minecraft:red_nether_bricks
setblock 284 23 215 minecraft:polished_blackstone
fill 284 23 216 284 26 216 minecraft:red_nether_bricks
fill 290 23 222 291 23 222 minecraft:red_nether_bricks
setblock 292 23 222 minecraft:polished_blackstone
setblock 293 23 221 minecraft:polished_blackstone
fill 293 23 222 296 23 222 minecraft:red_nether_bricks
fill 294 23 182 296 23 182 minecraft:red_nether_bricks
fill 294 23 221 297 23 221 minecraft:red_nether_bricks
setblock 297 23 182 minecraft:polished_blackstone
setblock 297 23 222 minecraft:polished_blackstone
fill 298 23 182 298 26 182 minecraft:red_nether_bricks
setblock 298 23 221 minecraft:polished_blackstone
fill 298 23 222 298 26 222 minecraft:red_nether_bricks
fill 300 23 182 301 23 182 minecraft:red_nether_bricks
fill 300 23 222 301 23 222 minecraft:red_nether_bricks
fill 308 23 182 309 25 182 minecraft:red_nether_bricks
fill 308 23 222 309 25 222 minecraft:red_nether_bricks
fill 311 23 221 312 23 221 minecraft:red_nether_bricks
setblock 312 23 182 minecraft:polished_blackstone
fill 312 23 183 313 25 183 minecraft:red_nether_bricks
fill 312 23 220 313 23 220 minecraft:red_nether_bricks
setblock 312 23 222 minecraft:polished_blackstone
fill 313 23 182 313 26 182 minecraft:red_nether_bricks
setblock 313 23 221 minecraft:polished_blackstone
fill 313 23 222 313 26 222 minecraft:red_nether_bricks
setblock 314 23 220 minecraft:polished_blackstone
fill 314 23 221 314 26 221 minecraft:red_nether_bricks
setblock 315 23 219 minecraft:polished_blackstone
fill 315 23 220 315 26 220 minecraft:red_nether_bricks
setblock 316 23 183 minecraft:polished_blackstone
fill 316 23 219 316 26 219 minecraft:red_nether_bricks
setblock 317 23 182 minecraft:polished_blackstone
fill 317 23 183 317 26 183 minecraft:red_nether_bricks
setblock 317 23 222 minecraft:polished_blackstone
fill 318 23 182 318 26 182 minecraft:red_nether_bricks
setblock 318 23 220 minecraft:red_nether_bricks
setblock 318 23 221 minecraft:polished_blackstone
fill 318 23 222 318 26 222 minecraft:red_nether_bricks
fill 319 23 183 319 24 183 minecraft:red_nether_bricks
setblock 319 23 219 minecraft:red_nether_bricks
setblock 319 23 220 minecraft:polished_blackstone
fill 319 23 221 319 26 221 minecraft:red_nether_bricks
fill 320 23 220 320 26 220 minecraft:red_nether_bricks
setblock 321 23 218 minecraft:polished_blackstone
fill 321 23 219 321 26 219 minecraft:red_nether_bricks
setblock 322 23 182 minecraft:polished_blackstone
setblock 322 23 213 minecraft:red_nether_bricks
setblock 322 23 217 minecraft:polished_blackstone
fill 322 23 218 322 26 218 minecraft:red_nether_bricks
setblock 322 23 222 minecraft:polished_blackstone
fill 323 23 212 323 26 212 minecraft:red_nether_bricks
setblock 323 23 216 minecraft:polished_blackstone
fill 323 23 217 323 26 217 minecraft:red_nether_bricks
setblock 323 23 221 minecraft:polished_blackstone
fill 323 23 222 323 26 222 minecraft:red_nether_bricks
setblock 283 24 194 minecraft:red_nether_bricks
setblock 283 24 195 minecraft:polished_blackstone
fill 283 24 196 283 27 196 minecraft:red_nether_bricks
fill 283 24 198 283 24 199 minecraft:red_nether_bricks
setblock 283 24 200 minecraft:polished_blackstone
fill 283 24 201 283 27 201 minecraft:red_nether_bricks
fill 283 24 203 283 24 204 minecraft:red_nether_bricks
setblock 283 24 210 minecraft:polished_blackstone
fill 283 24 211 283 27 211 minecraft:red_nether_bricks
setblock 283 24 215 minecraft:polished_blackstone
fill 283 24 216 283 27 216 minecraft:red_nether_bricks
setblock 283 24 220 minecraft:polished_blackstone
fill 283 24 221 283 27 221 minecraft:red_nether_bricks
fill 284 24 215 284 25 215 minecraft:red_nether_bricks
setblock 284 24 219 minecraft:polished_blackstone
fill 284 24 220 284 27 220 minecraft:red_nether_bricks
setblock 285 24 222 minecraft:red_nether_bricks
setblock 286 24 222 minecraft:polished_blackstone
fill 287 24 222 290 24 222 minecraft:red_nether_bricks
setblock 291 24 221 minecraft:red_nether_bricks
setblock 291 24 222 minecraft:polished_blackstone
fill 292 24 182 295 24 182 minecraft:red_nether_bricks
setblock 292 24 221 minecraft:polished_blackstone
fill 292 24 222 295 24 222 minecraft:red_nether_bricks
fill 293 24 221 296 24 221 minecraft:red_nether_bricks
setblock 296 24 182 minecraft:polished_blackstone
setblock 296 24 222 minecraft:polished_blackstone
fill 297 24 182 297 27 182 minecraft:red_nether_bricks
setblock 297 24 221 minecraft:polished_blackstone
fill 297 24 222 297 27 222 minecraft:red_nether_bricks
fill 298 24 221 299 26 221 minecraft:red_nether_bricks
setblock 300 24 182 minecraft:red_nether_bricks
setblock 300 24 222 minecraft:red_nether_bricks
setblock 301 24 182 minecraft:polished_blackstone
setblock 301 24 222 minecraft:polished_blackstone
fill 302 24 182 303 26 182 minecraft:red_nether_bricks
fill 302 24 222 302 27 222 minecraft:red_nether_bricks
setblock 305 24 182 minecraft:red_nether_bricks
setblock 306 24 182 minecraft:polished_blackstone
setblock 306 24 222 minecraft:polished_blackstone
fill 307 24 182 307 27 182 minecraft:red_nether_bricks
fill 307 24 222 307 27 222 minecraft:red_nether_bricks
fill 309 24 221 311 24 221 minecraft:red_nether_bricks
setblock 310 24 182 minecraft:red_nether_bricks
setblock 310 24 183 minecraft:polished_blackstone
setblock 310 24 222 minecraft:red_nether_bricks
setblock 311 24 182 minecraft:polished_blackstone
fill 311 24 183 311 27 183 minecraft:red_nether_bricks
fill 311 24 220 312 24 220 minecraft:red_nether_bricks
setblock 311 24 222 minecraft:polished_blackstone
fill 312 24 182 312 27 182 minecraft:red_nether_bricks
setblock 312 24 221 minecraft:polished_blackstone
fill 312 24 222 312 27 222 minecraft:red_nether_bricks
setblock 313 24 220 minecraft:polished_blackstone
fill 313 24 221 313 27 221 minecraft:red_nether_bricks
setblock 314 24 219 minecraft:polished_blackstone
fill 314 24 220 314 27 220 minecraft:red_nether_bricks
setblock 315 24 182 minecraft:red_nether_bricks
setblock 315 24 183 minecraft:polished_blackstone
fill 315 24 219 315 27 219 minecraft:red_nether_bricks
setblock 316 24 182 minecraft:polished_blackstone
fill 316 24 183 316 27 183 minecraft:red_nether_bricks
setblock 316 24 222 minecraft:polished_blackstone
fill 317 24 182 317 27 182 minecraft:red_nether_bricks
setblock 317 24 221 minecraft:polished_blackstone
fill 317 24 222 317 27 222 minecraft:red_nether_bricks
setblock 318 24 220 minecraft:polished_blackstone
fill 318 24 221 318 27 221 minecraft:red_nether_bricks
setblock 319 24 219 minecraft:polished_blackstone
fill 319 24 220 319 27 220 minecraft:red_nether_bricks
setblock 320 24 218 minecraft:polished_blackstone
fill 320 24 219 320 26 219 minecraft:red_nether_bricks
setblock 321 24 182 minecraft:polished_blackstone
setblock 321 24 217 minecraft:polished_blackstone
fill 321 24 218 321 27 218 minecraft:red_nether_bricks
setblock 321 24 222 minecraft:polished_blackstone
fill 322 24 182 322 27 182 minecraft:red_nether_bricks
setblock 322 24 216 minecraft:polished_blackstone
fill 322 24 217 322 27 217 minecraft:red_nether_bricks
setblock 322 24 221 minecraft:polished_blackstone
fill 322 24 222 322 27 222 minecraft:red_nether_bricks
fill 323 24 196 323 24 199 minecraft:red_nether_bricks
setblock 323 24 215 minecraft:polished_blackstone
fill 323 24 216 323 27 216 minecraft:red_nether_bricks
setblock 323 24 220 minecraft:polished_blackstone
fill 323 24 221 323 27 221 minecraft:red_nether_bricks
setblock 283 25 194 minecraft:polished_blackstone
fill 283 25 195 283 27 195 minecraft:red_nether_bricks
setblock 283 25 198 minecraft:red_nether_bricks
setblock 283 25 199 minecraft:polished_blackstone
fill 283 25 200 284 27 200 minecraft:red_nether_bricks
setblock 283 25 203 minecraft:red_nether_bricks
setblock 283 25 204 minecraft:polished_blackstone
fill 283 25 205 283 25 208 minecraft:red_nether_bricks
setblock 283 25 209 minecraft:polished_blackstone
fill 283 25 210 283 27 210 minecraft:red_nether_bricks
setblock 283 25 214 minecraft:polished_blackstone
fill 283 25 215 283 28 215 minecraft:red_nether_bricks
setblock 283 25 219 minecraft:polished_blackstone
fill 283 25 220 283 28 220 minecraft:red_nether_bricks
setblock 284 25 198 minecraft:polished_blackstone
fill 284 25 199 284 28 199 minecraft:red_nether_bricks
fill 284 25 201 284 26 201 minecraft:red_nether_bricks
fill 284 25 205 284 25 207 minecraft:polished_blackstone
setblock 284 25 218 minecraft:polished_blackstone
fill 284 25 219 284 27 219 minecraft:red_nether_bricks
fill 285 25 205 286 25 205 minecraft:polished_blackstone
fill 285 25 207 286 25 207 minecraft:polished_blackstone
setblock 285 25 222 minecraft:polished_blackstone
setblock 286 25 206 minecraft:polished_blackstone
fill 286 25 222 289 25 222 minecraft:red_nether_bricks
fill 289 25 221 290 25 221 minecraft:red_nether_bricks
setblock 290 25 222 minecraft:polished_blackstone
fill 291 25 182 294 25 182 minecraft:red_nether_bricks
setblock 291 25 221 minecraft:polished_blackstone
fill 291 25 222 294 25 222 minecraft:red_nether_bricks
fill 292 25 221 295 25 221 minecraft:red_nether_bricks
fill 293 25 220 296 25 220 minecraft:red_nether_bricks
setblock 294 25 183 minecraft:polished_blackstone
setblock 295 25 182 minecraft:polished_blackstone
fill 295 25 183 298 25 183 minecraft:red_nether_bricks
setblock 295 25 222 minecraft:polished_blackstone
fill 296 25 182 296 28 182 minecraft:red_nether_bricks
setblock 296 25 221 minecraft:polished_blackstone
fill 296 25 222 296 28 222 minecraft:red_nether_bricks
fill 297 25 221 297 28 221 minecraft:red_nether_bricks
setblock 300 25 182 minecraft:polished_blackstone
setblock 300 25 222 minecraft:polished_blackstone
fill 301 25 182 301 28 182 minecraft:red_nether_bricks
fill 301 25 222 301 28 222 minecraft:red_nether_bricks
fill 303 25 222 304 25 222 minecraft:red_nether_bricks
setblock 304 25 182 minecraft:red_nether_bricks
setblock 305 25 182 minecraft:polished_blackstone
setblock 305 25 222 minecraft:polished_blackstone
fill 306 25 182 306 28 182 minecraft:red_nether_bricks
fill 306 25 222 306 28 222 minecraft:red_nether_bricks
fill 308 25 221 310 25 221 minecraft:red_nether_bricks
setblock 309 25 183 minecraft:polished_blackstone
setblock 310 25 182 minecraft:polished_blackstone
fill 310 25 183 310 28 183 minecraft:red_nether_bricks
fill 310 25 220 311 25 220 minecraft:red_nether_bricks
setblock 310 25 222 minecraft:polished_blackstone
fill 311 25 182 311 28 182 minecraft:red_nether_bricks
setblock 311 25 221 minecraft:polished_blackstone
fill 311 25 222 311 28 222 minecraft:red_nether_bricks
setblock 312 25 219 minecraft:red_nether_bricks
setblock 312 25 220 minecraft:polished_blackstone
fill 312 25 221 312 28 221 minecraft:red_nether_bricks
setblock 313 25 184 minecraft:polished_blackstone
setblock 313 25 219 minecraft:polished_blackstone
fill 313 25 220 313 28 220 minecraft:red_nether_bricks
setblock 314 25 182 minecraft:red_nether_bricks
setblock 314 25 183 minecraft:polished_blackstone
fill 314 25 184 316 26 184 minecraft:red_nether_bricks
fill 314 25 219 314 28 219 minecraft:red_nether_bricks
setblock 315 25 182 minecraft:polished_blackstone
fill 315 25 183 315 28 183 minecraft:red_nether_bricks
setblock 315 25 222 minecraft:polished_blackstone
fill 316 25 182 316 28 182 minecraft:red_nether_bricks
setblock 316 25 221 minecraft:polished_blackstone
fill 316 25 222 316 28 222 minecraft:red_nether_bricks
setblock 317 25 219 minecraft:red_nether_bricks
setblock 317 25 220 minecraft:polished_blackstone
fill 317 25 221 317 28 221 minecraft:red_nether_bricks
setblock 318 25 219 minecraft:polished_blackstone
fill 318 25 220 318 28 220 minecraft:red_nether_bricks
setblock 319 25 183 minecraft:polished_blackstone
fill 319 25 219 319 27 219 minecraft:red_nether_bricks
setblock 320 25 182 minecraft:polished_blackstone
setblock 320 25 218 minecraft:red_nether_bricks
setblock 320 25 222 minecraft:polished_blackstone
fill 321 25 182 321 28 182 minecraft:red_nether_bricks
setblock 321 25 216 minecraft:polished_blackstone
fill 321 25 217 321 27 217 minecraft:red_nether_bricks
setblock 321 25 221 minecraft:polished_blackstone
fill 321 25 222 321 28 222 minecraft:red_nether_bricks
setblock 322 25 215 minecraft:polished_blackstone
fill 322 25 216 322 28 216 minecraft:red_nether_bricks
setblock 322 25 220 minecraft:polished_blackstone
fill 322 25 221 322 28 221 minecraft:red_nether_bricks
fill 323 25 196 323 25 198 minecraft:red_nether_bricks
setblock 323 25 199 minecraft:polished_blackstone
fill 323 25 200 323 27 201 minecraft:red_nether_bricks
setblock 323 25 214 minecraft:polished_blackstone
fill 323 25 215 323 28 215 minecraft:red_nether_bricks
setblock 323 25 219 minecraft:polished_blackstone
fill 323 25 220 323 28 220 minecraft:red_nether_bricks
setblock 283 26 198 minecraft:polished_blackstone
fill 283 26 199 283 29 199 minecraft:red_nether_bricks
setblock 283 26 203 minecraft:polished_blackstone
fill 283 26 204 283 26 207 minecraft:red_nether_bricks
setblock 283 26 208 minecraft:polished_blackstone
fill 283 26 209 283 29 209 minecraft:red_nether_bricks
setblock 283 26 213 minecraft:polished_blackstone
fill 283 26 214 283 28 214 minecraft:red_nether_bricks
setblock 283 26 218 minecraft:polished_blackstone
fill 283 26 219 283 29 219 minecraft:red_nether_bricks
setblock 283 26 222 minecraft:red_nether_bricks
setblock 284 26 197 minecraft:polished_blackstone
fill 284 26 198 284 29 198 minecraft:red_nether_bricks
setblock 284 26 202 minecraft:polished_blackstone
fill 284 26 203 284 29 203 minecraft:red_nether_bricks
setblock 284 26 217 minecraft:polished_blackstone
fill 284 26 218 284 27 218 minecraft:red_nether_bricks
setblock 284 26 221 minecraft:red_nether_bricks
setblock 284 26 222 minecraft:polished_blackstone
fill 285 26 222 288 26 222 minecraft:red_nether_bricks
fill 287 26 221 289 26 221 minecraft:red_nether_bricks
setblock 289 26 182 minecraft:polished_blackstone
setblock 289 26 222 minecraft:polished_blackstone
fill 290 26 182 293 26 182 minecraft:red_nether_bricks
setblock 290 26 221 minecraft:polished_blackstone
fill 290 26 222 293 26 222 minecraft:red_nether_bricks
setblock 291 26 220 minecraft:polished_blackstone
fill 291 26 221 294 26 221 minecraft:red_nether_bricks
setblock 292 26 183 minecraft:red_nether_bricks
fill 292 26 220 295 26 220 minecraft:red_nether_bricks
setblock 293 26 183 minecraft:polished_blackstone
setblock 294 26 182 minecraft:polished_blackstone
fill 294 26 183 297 26 183 minecraft:red_nether_bricks
setblock 294 26 222 minecraft:polished_blackstone
fill 295 26 182 295 29 182 minecraft:red_nether_bricks
setblock 295 26 221 minecraft:polished_blackstone
fill 295 26 222 295 29 222 minecraft:red_nether_bricks
setblock 296 26 220 minecraft:polished_blackstone
fill 296 26 221 296 29 221 minecraft:red_nether_bricks
setblock 298 26 183 minecraft:polished_blackstone
setblock 299 26 182 minecraft:polished_blackstone
fill 299 26 183 299 29 183 minecraft:red_nether_bricks
setblock 299 26 222 minecraft:polished_blackstone
fill 300 26 182 300 29 182 minecraft:red_nether_bricks
fill 300 26 222 300 29 222 minecraft:red_nether_bricks
setblock 303 26 222 minecraft:red_nether_bricks
setblock 304 26 182 minecraft:polished_blackstone
setblock 304 26 222 minecraft:polished_blackstone
fill 305 26 182 305 29 182 minecraft:red_nether_bricks
fill 305 26 222 305 29 222 minecraft:red_nether_bricks
fill 306 26 221 309 26 221 minecraft:red_nether_bricks
setblock 307 26 183 minecraft:red_nether_bricks
setblock 308 26 182 minecraft:red_nether_bricks
setblock 308 26 183 minecraft:polished_blackstone
setblock 308 26 222 minecraft:red_nether_bricks
setblock 309 26 182 minecraft:polished_blackstone
fill 309 26 183 309 29 183 minecraft:red_nether_bricks
fill 309 26 220 310 26 220 minecraft:red_nether_bricks
setblock 309 26 222 minecraft:polished_blackstone
fill 310 26 182 310 29 182 minecraft:red_nether_bricks
setblock 310 26 221 minecraft:polished_blackstone
fill 310 26 222 310 29 222 minecraft:red_nether_bricks
setblock 311 26 184 minecraft:red_nether_bricks
setblock 311 26 220 minecraft:polished_blackstone
fill 311 26 221 311 29 221 minecraft:red_nether_bricks
setblock 312 26 183 minecraft:red_nether_bricks
setblock 312 26 184 minecraft:polished_blackstone
setblock 312 26 219 minecraft:polished_blackstone
fill 312 26 220 312 29 220 minecraft:red_nether_bricks
setblock 313 26 183 minecraft:polished_blackstone
fill 313 26 184 313 29 184 minecraft:red_nether_bricks
fill 313 26 219 313 29 219 minecraft:red_nether_bricks
setblock 314 26 182 minecraft:polished_blackstone
fill 314 26 183 314 29 183 minecraft:red_nether_bricks
setblock 314 26 222 minecraft:polished_blackstone
fill 315 26 182 315 29 182 minecraft:red_nether_bricks
setblock 315 26 221 minecraft:polished_blackstone
fill 315 26 222 315 29 222 minecraft:red_nether_bricks
setblock 316 26 220 minecraft:polished_blackstone
fill 316 26 221 316 29 221 minecraft:red_nether_bricks
setblock 317 26 219 minecraft:polished_blackstone
fill 317 26 220 317 29 220 minecraft:red_nether_bricks
setblock 318 26 183 minecraft:polished_blackstone
fill 318 26 219 318 28 219 minecraft:red_nether_bricks
setblock 319 26 182 minecraft:polished_blackstone
fill 319 26 183 319 28 183 minecraft:red_nether_bricks
setblock 319 26 222 minecraft:polished_blackstone
fill 320 26 182 320 29 182 minecraft:red_nether_bricks
setblock 320 26 221 minecraft:polished_blackstone
fill 320 26 222 320 29 222 minecraft:red_nether_bricks
setblock 321 26 216 minecraft:red_nether_bricks
setblock 321 26 220 minecraft:polished_blackstone
fill 321 26 221 321 29 221 minecraft:red_nether_bricks
setblock 322 26 214 minecraft:polished_blackstone
fill 322 26 215 322 27 215 minecraft:red_nether_bricks
setblock 322 26 219 minecraft:polished_blackstone
fill 322 26 220 322 29 220 minecraft:red_nether_bricks
setblock 323 26 182 minecraft:red_nether_bricks
setblock 323 26 197 minecraft:red_nether_bricks
setblock 323 26 198 minecraft:polished_blackstone
fill 323 26 199 323 29 199 minecraft:red_nether_bricks
setblock 323 26 202 minecraft:red_nether_bricks
setblock 323 26 203 minecraft:polished_blackstone
setblock 323 26 213 minecraft:polished_blackstone
fill 323 26 214 323 29 214 minecraft:red_nether_bricks
setblock 323 26 218 minecraft:polished_blackstone
fill 323 26 219 323 29 219 minecraft:red_nether_bricks
setblock 283 27 197 minecraft:polished_blackstone
fill 283 27 198 283 30 198 minecraft:red_nether_bricks
setblock 283 27 202 minecraft:polished_blackstone
fill 283 27 203 283 27 206 minecraft:red_nether_bricks
setblock 283 27 207 minecraft:polished_blackstone
fill 283 27 208 283 30 208 minecraft:red_nether_bricks
setblock 283 27 212 minecraft:polished_blackstone
setblock 283 27 213 minecraft:red_nether_bricks
setblock 283 27 217 minecraft:polished_blackstone
fill 283 27 218 283 29 218 minecraft:red_nether_bricks
setblock 283 27 222 minecraft:polished_blackstone
fill 284 27 197 284 28 197 minecraft:red_nether_bricks
setblock 284 27 201 minecraft:polished_blackstone
fill 284 27 202 284 30 202 minecraft:red_nether_bricks
fill 284 27 204 284 28 204 minecraft:red_nether_bricks
fill 284 27 222 287 27 222 minecraft:red_nether_bricks
fill 286 27 221 288 27 221 minecraft:red_nether_bricks
setblock 288 27 182 minecraft:polished_blackstone
setblock 288 27 222 minecraft:polished_blackstone
fill 289 27 182 292 27 182 minecraft:red_nether_bricks
setblock 289 27 221 minecraft:polished_blackstone
fill 289 27 222 292 27 222 minecraft:red_nether_bricks
fill 290 27 221 293 27 221 minecraft:red_nether_bricks
setblock 291 27 183 minecraft:red_nether_bricks
fill 291 27 220 294 27 220 minecraft:red_nether_bricks
setblock 292 27 183 minecraft:polished_blackstone
setblock 293 27 182 minecraft:polished_blackstone
fill 293 27 183 296 27 183 minecraft:red_nether_bricks
setblock 293 27 222 minecraft:polished_blackstone
fill 294 27 182 294 30 182 minecraft:red_nether_bricks
setblock 294 27 221 minecraft:polished_blackstone
fill 294 27 222 294 30 222 minecraft:red_nether_bricks
setblock 295 27 220 minecraft:polished_blackstone
fill 295 27 221 295 30 221 minecraft:red_nether_bricks
setblock 297 27 183 minecraft:polished_blackstone
setblock 298 27 182 minecraft:polished_blackstone
fill 298 27 183 298 30 183 minecraft:red_nether_bricks
setblock 298 27 221 minecraft:red_nether_bricks
setblock 298 27 222 minecraft:polished_blackstone
fill 299 27 182 299 30 182 minecraft:red_nether_bricks
setblock 299 27 221 minecraft:polished_blackstone
fill 299 27 222 299 30 222 minecraft:red_nether_bricks
fill 300 27 183 300 28 183 minecraft:red_nether_bricks
setblock 302 27 182 minecraft:red_nether_bricks
setblock 303 27 182 minecraft:polished_blackstone
setblock 303 27 222 minecraft:polished_blackstone
fill 304 27 182 304 30 182 minecraft:red_nether_bricks
fill 304 27 222 304 30 222 minecraft:red_nether_bricks
fill 305 27 183 306 27 183 minecraft:red_nether_bricks
fill 306 27 221 308 27 221 minecraft:red_nether_bricks
setblock 307 27 183 minecraft:polished_blackstone
setblock 308 27 182 minecraft:polished_blackstone
fill 308 27 183 308 30 183 minecraft:red_nether_bricks
setblock 308 27 222 minecraft:polished_blackstone
fill 309 27 182 309 30 182 minecraft:red_nether_bricks
setblock 309 27 220 minecraft:red_nether_bricks
setblock 309 27 221 minecraft:polished_blackstone
fill 309 27 222 309 30 222 minecraft:red_nether_bricks
setblock 310 27 184 minecraft:red_nether_bricks
setblock 310 27 220 minecraft:polished_blackstone
fill 310 27 221 310 30 221 minecraft:red_nether_bricks
setblock 311 27 184 minecraft:polished_blackstone
setblock 311 27 219 minecraft:polished_blackstone
fill 311 27 220 311 30 220 minecraft:red_nether_bricks
setblock 312 27 183 minecraft:polished_blackstone
fill 312 27 184 312 30 184 minecraft:red_nether_bricks
fill 312 27 219 312 29 219 minecraft:red_nether_bricks
setblock 313 27 182 minecraft:polished_blackstone
fill 313 27 183 313 30 183 minecraft:red_nether_bricks
setblock 313 27 222 minecraft:polished_blackstone
fill 314 27 182 314 30 182 minecraft:red_nether_bricks
fill 314 27 184 315 27 184 minecraft:red_nether_bricks
setblock 314 27 221 minecraft:polished_blackstone
fill 314 27 222 314 30 222 minecraft:red_nether_bricks
setblock 315 27 220 minecraft:polished_blackstone
fill 315 27 221 315 30 221 minecraft:red_nether_bricks
setblock 316 27 184 minecraft:polished_blackstone
setblock 316 27 219 minecraft:polished_blackstone
fill 316 27 220 316 30 220 minecraft:red_nether_bricks
setblock 317 27 183 minecraft:polished_blackstone
fill 317 27 219 317 28 219 minecraft:red_nether_bricks
setblock 318 27 182 minecraft:polished_blackstone
fill 318 27 183 318 30 183 minecraft:red_nether_bricks
setblock 318 27 222 minecraft:polished_blackstone
fill 319 27 182 319 30 182 minecraft:red_nether_bricks
setblock 319 27 221 minecraft:polished_blackstone
fill 319 27 222 319 30 222 minecraft:red_nether_bricks
setblock 320 27 220 minecraft:polished_blackstone
fill 320 27 221 320 30 221 minecraft:red_nether_bricks
setblock 321 27 219 minecraft:polished_blackstone
fill 321 27 220 321 28 220 minecraft:red_nether_bricks
setblock 322 27 218 minecraft:polished_blackstone
fill 322 27 219 322 30 219 minecraft:red_nether_bricks
setblock 323 27 182 minecraft:polished_blackstone
setblock 323 27 197 minecraft:polished_blackstone
fill 323 27 198 323 28 198 minecraft:red_nether_bricks
setblock 323 27 202 minecraft:polished_blackstone
fill 323 27 203 323 29 204 minecraft:red_nether_bricks
setblock 323 27 212 minecraft:polished_blackstone
fill 323 27 213 323 28 213 minecraft:red_nether_bricks
setblock 323 27 217 minecraft:polished_blackstone
fill 323 27 218 323 30 218 minecraft:red_nether_bricks
setblock 323 27 222 minecraft:polished_blackstone
setblock 283 28 196 minecraft:polished_blackstone
fill 283 28 197 283 31 197 minecraft:red_nether_bricks
setblock 283 28 200 minecraft:red_nether_bricks
setblock 283 28 201 minecraft:polished_blackstone
fill 283 28 202 283 28 205 minecraft:red_nether_bricks
setblock 283 28 206 minecraft:polished_blackstone
fill 283 28 207 283 31 207 minecraft:red_nether_bricks
setblock 283 28 216 minecraft:polished_blackstone
fill 283 28 217 283 29 217 minecraft:red_nether_bricks
setblock 283 28 221 minecraft:polished_blackstone
fill 283 28 222 286 28 222 minecraft:red_nether_bricks
setblock 284 28 200 minecraft:polished_blackstone
fill 284 28 201 285 30 201 minecraft:red_nether_bricks
setblock 284 28 205 minecraft:polished_blackstone
setblock 285 28 184 minecraft:light[level=14]
setblock 285 28 192 minecraft:light[level=14]
fill 285 28 200 285 30 200 minecraft:red_nether_bricks
fill 285 28 202 285 29 202 minecraft:red_nether_bricks
setblock 285 28 208 minecraft:light[level=14]
setblock 285 28 216 minecraft:light[level=14]
setblock 287 28 182 minecraft:polished_blackstone
setblock 287 28 221 minecraft:red_nether_bricks
setblock 287 28 222 minecraft:polished_blackstone
fill 288 28 182 291 28 182 minecraft:red_nether_bricks
setblock 288 28 221 minecraft:polished_blackstone
fill 288 28 222 291 28 222 minecraft:red_nether_bricks
fill 289 28 221 292 28 221 minecraft:red_nether_bricks
setblock 290 28 183 minecraft:red_nether_bricks
setblock 291 28 183 minecraft:polished_blackstone
fill 291 28 220 293 28 220 minecraft:red_nether_bricks
setblock 292 28 182 minecraft:polished_blackstone
fill 292 28 183 295 28 183 minecraft:red_nether_bricks
setblock 292 28 222 minecraft:polished_blackstone
fill 293 28 182 293 31 182 minecraft:red_nether_bricks
setblock 293 28 184 minecraft:light[level=14]
setblock 293 28 192 minecraft:light[level=14]
setblock 293 28 200 minecraft:light[level=14]
setblock 293 28 208 minecraft:light[level=14]
setblock 293 28 216 minecraft:light[level=14]
setblock 293 28 221 minecraft:polished_blackstone
fill 293 28 222 293 31 222 minecraft:red_nether_bricks
setblock 294 28 220 minecraft:polished_blackstone
fill 294 28 221 294 30 221 minecraft:red_nether_bricks
setblock 296 28 183 minecraft:polished_blackstone
setblock 297 28 182 minecraft:polished_blackstone
fill 297 28 183 297 31 183 minecraft:red_nether_bricks
setblock 297 28 222 minecraft:polished_blackstone
fill 298 28 182 298 31 182 minecraft:red_nether_bricks
setblock 298 28 221 minecraft:polished_blackstone
fill 298 28 222 298 31 222 minecraft:red_nether_bricks
setblock 301 28 183 minecraft:polished_blackstone
setblock 301 28 184 minecraft:light[level=14]
setblock 301 28 192 minecraft:light[level=14]
setblock 301 28 200 minecraft:light[level=14]
setblock 301 28 208 minecraft:light[level=14]
setblock 301 28 216 minecraft:light[level=14]
setblock 302 28 182 minecraft:polished_blackstone
fill 302 28 183 305 28 183 minecraft:red_nether_bricks
setblock 302 28 222 minecraft:polished_blackstone
fill 303 28 182 303 31 182 minecraft:red_nether_bricks
fill 303 28 222 303 31 222 minecraft:red_nether_bricks
fill 305 28 221 307 28 221 minecraft:red_nether_bricks
setblock 306 28 183 minecraft:polished_blackstone
setblock 307 28 182 minecraft:polished_blackstone
fill 307 28 183 307 31 183 minecraft:red_nether_bricks
setblock 307 28 222 minecraft:polished_blackstone
fill 308 28 182 308 31 182 minecraft:red_nether_bricks
setblock 308 28 220 minecraft:red_nether_bricks
setblock 308 28 221 minecraft:polished_blackstone
fill 308 28 222 308 31 222 minecraft:red_nether_bricks
setblock 309 28 184 minecraft:red_nether_bricks
setblock 309 28 192 minecraft:light[level=14]
setblock 309 28 200 minecraft:light[level=14]
setblock 309 28 208 minecraft:light[level=14]
setblock 309 28 216 minecraft:light[level=14]
setblock 309 28 220 minecraft:polished_blackstone
fill 309 28 221 309 31 221 minecraft:red_nether_bricks
setblock 310 28 184 minecraft:polished_blackstone
fill 310 28 220 310 31 220 minecraft:red_nether_bricks
setblock 311 28 183 minecraft:polished_blackstone
fill 311 28 184 311 31 184 minecraft:red_nether_bricks
setblock 311 28 219 minecraft:red_nether_bricks
setblock 312 28 182 minecraft:polished_blackstone
fill 312 28 183 312 31 183 minecraft:red_nether_bricks
setblock 312 28 222 minecraft:polished_blackstone
fill 313 28 182 313 31 182 minecraft:red_nether_bricks
setblock 313 28 221 minecraft:polished_blackstone
fill 313 28 222 313 31 222 minecraft:red_nether_bricks
setblock 314 28 184 minecraft:red_nether_bricks
setblock 314 28 220 minecraft:polished_blackstone
fill 314 28 221 314 31 221 minecraft:red_nether_bricks
setblock 315 28 184 minecraft:polished_blackstone
setblock 315 28 219 minecraft:polished_blackstone
fill 315 28 220 315 31 220 minecraft:red_nether_bricks
setblock 316 28 183 minecraft:polished_blackstone
setblock 316 28 184 minecraft:red_nether_bricks
fill 316 28 219 316 29 219 minecraft:red_nether_bricks
setblock 317 28 182 minecraft:polished_blackstone
fill 317 28 183 317 31 183 minecraft:red_nether_bricks
setblock 317 28 184 minecraft:light[level=14]
setblock 317 28 192 minecraft:light[level=14]
setblock 317 28 200 minecraft:light[level=14]
setblock 317 28 208 minecraft:light[level=14]
setblock 317 28 216 minecraft:light[level=14]
setblock 317 28 222 minecraft:polished_blackstone
fill 318 28 182 318 31 182 minecraft:red_nether_bricks
setblock 318 28 221 minecraft:polished_blackstone
fill 318 28 222 318 31 222 minecraft:red_nether_bricks
setblock 319 28 220 minecraft:polished_blackstone
fill 319 28 221 319 31 221 minecraft:red_nether_bricks
fill 320 28 220 320 29 220 minecraft:red_nether_bricks
setblock 321 28 219 minecraft:red_nether_bricks
setblock 322 28 182 minecraft:polished_blackstone
setblock 322 28 217 minecraft:polished_blackstone
fill 322 28 218 322 29 218 minecraft:red_nether_bricks
setblock 322 28 222 minecraft:polished_blackstone
fill 323 28 182 323 30 182 minecraft:red_nether_bricks
setblock 323 28 200 minecraft:red_nether_bricks
setblock 323 28 201 minecraft:polished_blackstone
fill 323 28 202 323 31 202 minecraft:red_nether_bricks
setblock 323 28 205 minecraft:red_nether_bricks
setblock 323 28 216 minecraft:polished_blackstone
fill 323 28 217 323 31 217 minecraft:red_nether_bricks
setblock 323 28 221 minecraft:polished_blackstone
fill 323 28 222 323 31 222 minecraft:red_nether_bricks
setblock 283 29 196 minecraft:red_nether_bricks
setblock 283 29 200 minecraft:polished_blackstone
fill 283 29 201 283 29 204 minecraft:red_nether_bricks
setblock 283 29 205 minecraft:polished_blackstone
fill 283 29 206 284 31 206 minecraft:red_nether_bricks
setblock 283 29 216 minecraft:red_nether_bricks
setblock 283 29 220 minecraft:polished_blackstone
fill 283 29 221 283 30 222 minecraft:red_nether_bricks
setblock 284 29 199 minecraft:polished_blackstone
fill 284 29 200 284 32 200 minecraft:red_nether_bricks
setblock 284 29 204 minecraft:polished_blackstone
fill 284 29 205 284 32 205 minecraft:red_nether_bricks
fill 284 29 222 285 29 222 minecraft:red_nether_bricks
setblock 285 29 203 minecraft:polished_blackstone
setblock 286 29 182 minecraft:polished_blackstone
setblock 286 29 222 minecraft:polished_blackstone
fill 287 29 182 290 29 182 minecraft:red_nether_bricks
setblock 287 29 221 minecraft:polished_blackstone
fill 287 29 222 290 29 222 minecraft:red_nether_bricks
fill 288 29 221 291 29 221 minecraft:red_nether_bricks
setblock 289 29 183 minecraft:red_nether_bricks
setblock 290 29 183 minecraft:polished_blackstone
setblock 291 29 182 minecraft:polished_blackstone
fill 291 29 183 294 29 183 minecraft:red_nether_bricks
setblock 291 29 222 minecraft:polished_blackstone
fill 292 29 182 292 32 182 minecraft:red_nether_bricks
setblock 292 29 221 minecraft:polished_blackstone
fill 292 29 222 292 32 222 minecraft:red_nether_bricks
fill 293 29 221 293 31 221 minecraft:red_nether_bricks
setblock 295 29 183 minecraft:polished_blackstone
setblock 296 29 182 minecraft:polished_blackstone
fill 296 29 183 296 32 183 minecraft:red_nether_bricks
setblock 296 29 222 minecraft:polished_blackstone
fill 297 29 182 297 32 182 minecraft:red_nether_bricks
setblock 297 29 221 minecraft:polished_blackstone
fill 297 29 222 297 31 222 minecraft:red_nether_bricks
setblock 300 29 183 minecraft:polished_blackstone
setblock 301 29 182 minecraft:polished_blackstone
fill 301 29 183 304 29 183 minecraft:red_nether_bricks
setblock 301 29 222 minecraft:polished_blackstone
fill 302 29 182 302 32 182 minecraft:red_nether_bricks
fill 302 29 222 302 31 222 minecraft:red_nether_bricks
setblock 305 29 183 minecraft:polished_blackstone
fill 305 29 221 306 29 221 minecraft:red_nether_bricks
setblock 306 29 182 minecraft:polished_blackstone
fill 306 29 183 306 32 183 minecraft:red_nether_bricks
setblock 306 29 222 minecraft:polished_blackstone
fill 307 29 182 307 32 182 minecraft:red_nether_bricks
setblock 307 29 221 minecraft:polished_blackstone
fill 307 29 222 307 32 222 minecraft:red_nether_bricks
setblock 308 29 184 minecraft:red_nether_bricks
setblock 308 29 220 minecraft:polished_blackstone
fill 308 29 221 308 32 221 minecraft:red_nether_bricks
setblock 309 29 184 minecraft:polished_blackstone
fill 309 29 220 309 32 220 minecraft:red_nether_bricks
setblock 310 29 183 minecraft:polished_blackstone
fill 310 29 184 310 32 184 minecraft:red_nether_bricks
setblock 311 29 182 minecraft:polished_blackstone
fill 311 29 183 311 32 183 minecraft:red_nether_bricks
setblock 311 29 222 minecraft:polished_blackstone
fill 312 29 182 312 32 182 minecraft:red_nether_bricks
setblock 312 29 221 minecraft:polished_blackstone
fill 312 29 222 312 32 222 minecraft:red_nether_bricks
setblock 313 29 220 minecraft:polished_blackstone
fill 313 29 221 313 32 221 minecraft:red_nether_bricks
setblock 314 29 184 minecraft:polished_blackstone
setblock 314 29 219 minecraft:polished_blackstone
fill 314 29 220 314 32 220 minecraft:red_nether_bricks
setblock 315 29 183 minecraft:polished_blackstone
fill 315 29 184 315 30 184 minecraft:red_nether_bricks
setblock 315 29 219 minecraft:red_nether_bricks
setblock 316 29 182 minecraft:polished_blackstone
fill 316 29 183 316 32 183 minecraft:red_nether_bricks
setblock 316 29 222 minecraft:polished_blackstone
fill 317 29 182 317 32 182 minecraft:red_nether_bricks
setblock 317 29 221 minecraft:polished_blackstone
fill 317 29 222 317 32 222 minecraft:red_nether_bricks
setblock 318 29 220 minecraft:polished_blackstone
fill 318 29 221 318 32 221 minecraft:red_nether_bricks
setblock 319 29 220 minecraft:red_nether_bricks
setblock 321 29 182 minecraft:polished_blackstone
setblock 321 29 222 minecraft:polished_blackstone
fill 322 29 182 322 30 182 minecraft:red_nether_bricks
setblock 322 29 221 minecraft:polished_blackstone
fill 322 29 222 322 32 222 minecraft:red_nether_bricks
setblock 323 29 200 minecraft:polished_blackstone
fill 323 29 201 323 32 201 minecraft:red_nether_bricks
setblock 323 29 205 minecraft:polished_blackstone
fill 323 29 206 323 32 206 minecraft:red_nether_bricks
setblock 323 29 215 minecraft:polished_blackstone
fill 323 29 216 323 30 216 minecraft:red_nether_bricks
setblock 323 29 220 minecraft:polished_blackstone
fill 323 29 221 323 32 221 minecraft:red_nether_bricks
setblock 283 30 199 minecraft:polished_blackstone
fill 283 30 200 283 30 203 minecraft:red_nether_bricks
setblock 283 30 204 minecraft:polished_blackstone
fill 283 30 205 283 33 205 minecraft:red_nether_bricks
setblock 283 30 209 minecraft:polished_blackstone
setblock 283 30 219 minecraft:polished_blackstone
setblock 283 30 220 minecraft:red_nether_bricks
setblock 284 30 198 minecraft:polished_blackstone
fill 284 30 199 284 32 199 minecraft:red_nether_bricks
setblock 284 30 203 minecraft:polished_blackstone
fill 284 30 204 284 33 204 minecraft:red_nether_bricks
setblock 284 30 222 minecraft:red_nether_bricks
setblock 285 30 202 minecraft:polished_blackstone
fill 285 30 203 285 33 203 minecraft:red_nether_bricks
setblock 285 30 222 minecraft:polished_blackstone
fill 286 30 182 289 30 182 minecraft:red_nether_bricks
fill 286 30 222 289 30 222 minecraft:red_nether_bricks
fill 288 30 221 290 30 221 minecraft:red_nether_bricks
setblock 289 30 183 minecraft:polished_blackstone
setblock 290 30 182 minecraft:polished_blackstone
fill 290 30 183 293 30 183 minecraft:red_nether_bricks
setblock 290 30 222 minecraft:polished_blackstone
fill 291 30 182 291 33 182 minecraft:red_nether_bricks
setblock 291 30 221 minecraft:polished_blackstone
fill 291 30 222 291 33 222 minecraft:red_nether_bricks
fill 292 30 221 292 31 221 minecraft:red_nether_bricks
setblock 294 30 183 minecraft:polished_blackstone
setblock 295 30 182 minecraft:polished_blackstone
fill 295 30 183 295 33 183 minecraft:red_nether_bricks
setblock 295 30 222 minecraft:polished_blackstone
fill 296 30 182 296 33 182 minecraft:red_nether_bricks
fill 296 30 222 296 32 222 minecraft:red_nether_bricks
setblock 299 30 183 minecraft:polished_blackstone
setblock 300 30 182 minecraft:polished_blackstone
fill 300 30 183 303 30 183 minecraft:red_nether_bricks
setblock 300 30 222 minecraft:polished_blackstone
fill 301 30 182 301 33 182 minecraft:red_nether_bricks
fill 301 30 222 301 31 222 minecraft:red_nether_bricks
setblock 304 30 183 minecraft:polished_blackstone
setblock 305 30 182 minecraft:polished_blackstone
fill 305 30 183 305 33 183 minecraft:red_nether_bricks
setblock 305 30 222 minecraft:polished_blackstone
fill 306 30 182 306 33 182 minecraft:red_nether_bricks
setblock 306 30 221 minecraft:polished_blackstone
fill 306 30 222 306 33 222 minecraft:red_nether_bricks
setblock 307 30 184 minecraft:red_nether_bricks
fill 307 30 221 307 33 221 minecraft:red_nether_bricks
setblock 308 30 184 minecraft:polished_blackstone
setblock 309 30 183 minecraft:polished_blackstone
fill 309 30 184 309 33 184 minecraft:red_nether_bricks
setblock 310 30 182 minecraft:polished_blackstone
fill 310 30 183 310 33 183 minecraft:red_nether_bricks
setblock 310 30 222 minecraft:polished_blackstone
fill 311 30 182 311 33 182 minecraft:red_nether_bricks
setblock 311 30 221 minecraft:polished_blackstone
fill 311 30 222 311 33 222 minecraft:red_nether_bricks
setblock 312 30 220 minecraft:polished_blackstone
fill 312 30 221 312 33 221 minecraft:red_nether_bricks
setblock 313 30 184 minecraft:polished_blackstone
fill 313 30 220 313 33 220 minecraft:red_nether_bricks
setblock 314 30 183 minecraft:polished_blackstone
fill 314 30 184 314 31 184 minecraft:red_nether_bricks
setblock 315 30 182 minecraft:polished_blackstone
fill 315 30 183 315 33 183 minecraft:red_nether_bricks
setblock 315 30 222 minecraft:polished_blackstone
fill 316 30 182 316 33 182 minecraft:red_nether_bricks
setblock 316 30 221 minecraft:polished_blackstone
fill 316 30 222 316 33 222 minecraft:red_nether_bricks
setblock 317 30 220 minecraft:polished_blackstone
fill 317 30 221 317 33 221 minecraft:red_nether_bricks
setblock 318 30 220 minecraft:red_nether_bricks
setblock 320 30 182 minecraft:polished_blackstone
setblock 320 30 222 minecraft:polished_blackstone
fill 321 30 182 321 31 182 minecraft:red_nether_bricks
setblock 321 30 221 minecraft:polished_blackstone
fill 321 30 222 321 33 222 minecraft:red_nether_bricks
setblock 322 30 220 minecraft:polished_blackstone
setblock 322 30 221 minecraft:red_nether_bricks
fill 323 30 200 323 31 200 minecraft:red_nether_bricks
setblock 323 30 203 minecraft:red_nether_bricks
setblock 323 30 204 minecraft:polished_blackstone
fill 323 30 205 323 33 205 minecraft:red_nether_bricks
fill 323 30 207 323 31 207 minecraft:red_nether_bricks
setblock 323 30 219 minecraft:polished_blackstone
fill 323 30 220 323 33 220 minecraft:red_nether_bricks
setblock 283 31 198 minecraft:polished_blackstone
fill 283 31 199 283 31 202 minecraft:red_nether_bricks
setblock 283 31 203 minecraft:polished_blackstone
fill 283 31 204 283 34 204 minecraft:red_nether_bricks
setblock 283 31 208 minecraft:polished_blackstone
fill 283 31 209 283 34 209 minecraft:red_nether_bricks
setblock 284 31 201 minecraft:red_nether_bricks
setblock 284 31 202 minecraft:polished_blackstone
fill 284 31 203 284 34 203 minecraft:red_nether_bricks
setblock 284 31 222 minecraft:polished_blackstone
setblock 285 31 201 minecraft:polished_blackstone
fill 285 31 202 285 34 202 minecraft:red_nether_bricks
fill 285 31 204 285 32 204 minecraft:red_nether_bricks
fill 285 31 222 288 31 222 minecraft:red_nether_bricks
fill 286 31 182 288 31 182 minecraft:red_nether_bricks
setblock 288 31 183 minecraft:polished_blackstone
setblock 289 31 182 minecraft:polished_blackstone
fill 289 31 183 292 31 183 minecraft:red_nether_bricks
setblock 289 31 221 minecraft:red_nether_bricks
setblock 289 31 222 minecraft:polished_blackstone
fill 290 31 182 290 34 182 minecraft:red_nether_bricks
setblock 290 31 221 minecraft:polished_blackstone
fill 290 31 222 290 34 222 minecraft:red_nether_bricks
setblock 291 31 221 minecraft:red_nether_bricks
setblock 293 31 183 minecraft:polished_blackstone
setblock 294 31 182 minecraft:polished_blackstone
fill 294 31 183 294 34 183 minecraft:red_nether_bricks
setblock 294 31 222 minecraft:polished_blackstone
fill 295 31 182 295 34 182 minecraft:red_nether_bricks
fill 295 31 222 295 33 222 minecraft:red_nether_bricks
setblock 298 31 183 minecraft:polished_blackstone
setblock 299 31 182 minecraft:polished_blackstone
fill 299 31 183 302 31 183 minecraft:red_nether_bricks
setblock 299 31 222 minecraft:polished_blackstone
fill 300 31 182 300 34 182 minecraft:red_nether_bricks
setblock 303 31 183 minecraft:polished_blackstone
setblock 304 31 182 minecraft:polished_blackstone
fill 304 31 183 304 34 183 minecraft:red_nether_bricks
setblock 304 31 222 minecraft:polished_blackstone
fill 305 31 182 305 34 182 minecraft:red_nether_bricks
fill 305 31 222 305 34 222 minecraft:red_nether_bricks
fill 306 31 221 306 34 221 minecraft:red_nether_bricks
setblock 307 31 184 minecraft:polished_blackstone
setblock 308 31 183 minecraft:polished_blackstone
fill 308 31 184 308 34 184 minecraft:red_nether_bricks
setblock 309 31 182 minecraft:polished_blackstone
fill 309 31 183 309 34 183 minecraft:red_nether_bricks
setblock 309 31 222 minecraft:polished_blackstone
fill 310 31 182 310 34 182 minecraft:red_nether_bricks
setblock 310 31 221 minecraft:polished_blackstone
fill 310 31 222 310 34 222 minecraft:red_nether_bricks
setblock 311 31 220 minecraft:polished_blackstone
fill 311 31 221 311 34 221 minecraft:red_nether_bricks
setblock 312 31 184 minecraft:polished_blackstone
fill 312 31 220 312 33 220 minecraft:red_nether_bricks
setblock 313 31 183 minecraft:polished_blackstone
fill 313 31 184 313 33 184 minecraft:red_nether_bricks
setblock 314 31 182 minecraft:polished_blackstone
fill 314 31 183 314 34 183 minecraft:red_nether_bricks
setblock 314 31 222 minecraft:polished_blackstone
fill 315 31 182 315 34 182 minecraft:red_nether_bricks
setblock 315 31 221 minecraft:polished_blackstone
fill 315 31 222 315 34 222 minecraft:red_nether_bricks
setblock 316 31 220 minecraft:polished_blackstone
fill 316 31 221 316 33 221 minecraft:red_nether_bricks
setblock 319 31 182 minecraft:polished_blackstone
setblock 319 31 222 minecraft:polished_blackstone
fill 320 31 182 320 32 182 minecraft:red_nether_bricks
setblock 320 31 221 minecraft:polished_blackstone
fill 320 31 222 320 34 222 minecraft:red_nether_bricks
setblock 321 31 221 minecraft:red_nether_bricks
setblock 323 31 203 minecraft:polished_blackstone
fill 323 31 204 323 34 204 minecraft:red_nether_bricks
setblock 323 31 208 minecraft:polished_blackstone
setblock 323 31 218 minecraft:polished_blackstone
fill 323 31 219 323 32 219 minecraft:red_nether_bricks
fill 283 32 198 283 32 201 minecraft:red_nether_bricks
setblock 283 32 202 minecraft:polished_blackstone
fill 283 32 203 283 35 203 minecraft:red_nether_bricks
setblock 283 32 206 minecraft:red_nether_bricks
setblock 283 32 207 minecraft:polished_blackstone
fill 283 32 208 283 35 208 minecraft:red_nether_bricks
setblock 284 32 201 minecraft:polished_blackstone
fill 284 32 202 284 35 202 minecraft:red_nether_bricks
setblock 284 32 206 minecraft:polished_blackstone
fill 284 32 207 284 35 207 minecraft:red_nether_bricks
fill 285 32 182 287 32 182 minecraft:red_nether_bricks
fill 285 32 205 286 32 205 minecraft:polished_blackstone
fill 285 32 207 286 32 207 minecraft:polished_blackstone
setblock 286 32 206 minecraft:polished_blackstone
fill 286 32 222 287 32 222 minecraft:red_nether_bricks
setblock 288 32 182 minecraft:polished_blackstone
fill 288 32 183 291 32 183 minecraft:red_nether_bricks
setblock 288 32 222 minecraft:polished_blackstone
fill 289 32 182 289 35 182 minecraft:red_nether_bricks
fill 289 32 222 289 35 222 minecraft:red_nether_bricks
setblock 292 32 183 minecraft:polished_blackstone
setblock 293 32 182 minecraft:polished_blackstone
fill 293 32 183 293 35 183 minecraft:red_nether_bricks
setblock 293 32 222 minecraft:polished_blackstone
fill 294 32 182 294 35 182 minecraft:red_nether_bricks
fill 294 32 222 294 33 222 minecraft:red_nether_bricks
setblock 297 32 183 minecraft:polished_blackstone
setblock 298 32 182 minecraft:polished_blackstone
fill 298 32 183 299 32 183 minecraft:red_nether_bricks
fill 299 32 182 299 35 182 minecraft:red_nether_bricks
setblock 301 32 183 minecraft:red_nether_bricks
setblock 302 32 183 minecraft:polished_blackstone
setblock 303 32 182 minecraft:polished_blackstone
fill 303 32 183 303 35 183 minecraft:red_nether_bricks
setblock 303 32 222 minecraft:polished_blackstone
fill 304 32 182 304 35 182 minecraft:red_nether_bricks
fill 304 32 222 304 35 222 minecraft:red_nether_bricks
setblock 306 32 184 minecraft:polished_blackstone
setblock 307 32 183 minecraft:polished_blackstone
fill 307 32 184 307 35 184 minecraft:red_nether_bricks
setblock 308 32 182 minecraft:polished_blackstone
fill 308 32 183 308 35 183 minecraft:red_nether_bricks
setblock 308 32 222 minecraft:polished_blackstone
fill 309 32 182 309 35 182 minecraft:red_nether_bricks
setblock 309 32 221 minecraft:polished_blackstone
fill 309 32 222 309 35 222 minecraft:red_nether_bricks
setblock 310 32 220 minecraft:polished_blackstone
fill 310 32 221 310 35 221 minecraft:red_nether_bricks
setblock 311 32 184 minecraft:polished_blackstone
fill 311 32 220 311 33 220 minecraft:red_nether_bricks
setblock 312 32 183 minecraft:polished_blackstone
fill 312 32 184 312 35 184 minecraft:red_nether_bricks
setblock 313 32 182 minecraft:polished_blackstone
fill 313 32 183 313 35 183 minecraft:red_nether_bricks
setblock 313 32 222 minecraft:polished_blackstone
fill 314 32 182 314 35 182 minecraft:red_nether_bricks
setblock 314 32 221 minecraft:polished_blackstone
fill 314 32 222 314 35 222 minecraft:red_nether_bricks
setblock 315 32 220 minecraft:polished_blackstone
fill 315 32 221 315 34 221 minecraft:red_nether_bricks
setblock 318 32 182 minecraft:polished_blackstone
setblock 318 32 222 minecraft:polished_blackstone
fill 319 32 182 319 33 182 minecraft:red_nether_bricks
fill 319 32 222 319 35 222 minecraft:red_nether_bricks
setblock 323 32 202 minecraft:polished_blackstone
fill 323 32 203 323 35 203 minecraft:red_nether_bricks
setblock 323 32 207 minecraft:polished_blackstone
fill 323 32 208 323 35 208 minecraft:red_nether_bricks
setblock 323 32 222 minecraft:polished_blackstone
fill 283 33 198 283 33 200 minecraft:red_nether_bricks
setblock 283 33 201 minecraft:polished_blackstone
fill 283 33 202 283 36 202 minecraft:red_nether_bricks
setblock 283 33 206 minecraft:polished_blackstone
fill 283 33 207 283 36 207 minecraft:red_nether_bricks
setblock 284 33 200 minecraft:polished_blackstone
fill 284 33 201 284 36 201 minecraft:red_nether_bricks
setblock 284 33 205 minecraft:polished_blackstone
fill 284 33 206 284 36 206 minecraft:red_nether_bricks
fill 285 33 182 286 33 182 minecraft:red_nether_bricks
setblock 285 33 204 minecraft:polished_blackstone
fill 285 33 205 285 36 205 minecraft:red_nether_bricks
setblock 286 33 222 minecraft:red_nether_bricks
setblock 287 33 182 minecraft:polished_blackstone
setblock 287 33 222 minecraft:polished_blackstone
fill 288 33 182 288 35 183 minecraft:red_nether_bricks
fill 288 33 222 288 36 222 minecraft:red_nether_bricks
fill 289 33 183 290 33 183 minecraft:red_nether_bricks
setblock 291 33 183 minecraft:polished_blackstone
setblock 292 33 182 minecraft:polished_blackstone
fill 292 33 183 292 35 184 minecraft:red_nether_bricks
setblock 292 33 222 minecraft:polished_blackstone
fill 293 33 182 293 36 182 minecraft:red_nether_bricks
fill 293 33 222 293 34 222 minecraft:red_nether_bricks
setblock 296 33 183 minecraft:polished_blackstone
setblock 297 33 182 minecraft:polished_blackstone
fill 297 33 183 298 35 183 minecraft:red_nether_bricks
fill 298 33 182 298 36 182 minecraft:red_nether_bricks
setblock 301 33 183 minecraft:polished_blackstone
setblock 302 33 182 minecraft:polished_blackstone
fill 302 33 183 302 36 183 minecraft:red_nether_bricks
fill 303 33 182 303 36 182 minecraft:red_nether_bricks
fill 303 33 222 303 36 222 minecraft:red_nether_bricks
setblock 306 33 183 minecraft:polished_blackstone
fill 306 33 184 306 36 184 minecraft:red_nether_bricks
setblock 307 33 182 minecraft:polished_blackstone
fill 307 33 183 307 36 183 minecraft:red_nether_bricks
setblock 307 33 222 minecraft:polished_blackstone
fill 308 33 182 308 36 182 minecraft:red_nether_bricks
setblock 308 33 221 minecraft:polished_blackstone
fill 308 33 222 308 36 222 minecraft:red_nether_bricks
fill 309 33 221 309 36 221 minecraft:red_nether_bricks
setblock 310 33 184 minecraft:polished_blackstone
setblock 310 33 220 minecraft:red_nether_bricks
setblock 311 33 183 minecraft:polished_blackstone
fill 311 33 184 311 36 184 minecraft:red_nether_bricks
setblock 312 33 182 minecraft:polished_blackstone
fill 312 33 183 312 36 183 minecraft:red_nether_bricks
setblock 312 33 222 minecraft:polished_blackstone
fill 313 33 182 313 36 182 minecraft:red_nether_bricks
setblock 313 33 221 minecraft:polished_blackstone
fill 313 33 222 313 36 222 minecraft:red_nether_bricks
fill 314 33 221 314 36 221 minecraft:red_nether_bricks
setblock 316 33 183 minecraft:polished_blackstone
setblock 317 33 182 minecraft:polished_blackstone
setblock 317 33 222 minecraft:polished_blackstone
fill 318 33 182 318 34 182 minecraft:red_nether_bricks
fill 318 33 222 318 35 222 minecraft:red_nether_bricks
setblock 322 33 222 minecraft:polished_blackstone
setblock 323 33 201 minecraft:polished_blackstone
fill 323 33 202 323 36 202 minecraft:red_nether_bricks
setblock 323 33 206 minecraft:polished_blackstone
fill 323 33 207 323 36 207 minecraft:red_nether_bricks
fill 323 33 209 323 34 209 minecraft:red_nether_bricks
setblock 323 33 221 minecraft:polished_blackstone
fill 323 33 222 323 36 222 minecraft:red_nether_bricks
fill 283 34 198 283 34 199 minecraft:red_nether_bricks
setblock 283 34 200 minecraft:polished_blackstone
fill 283 34 201 283 37 201 minecraft:red_nether_bricks
setblock 283 34 205 minecraft:polished_blackstone
fill 283 34 206 283 37 206 minecraft:red_nether_bricks
setblock 283 34 210 minecraft:polished_blackstone
fill 284 34 200 284 37 200 minecraft:red_nether_bricks
setblock 284 34 204 minecraft:polished_blackstone
fill 284 34 205 284 37 205 minecraft:red_nether_bricks
setblock 284 34 208 minecraft:red_nether_bricks
setblock 285 34 182 minecraft:red_nether_bricks
setblock 285 34 203 minecraft:polished_blackstone
fill 285 34 204 285 37 204 minecraft:red_nether_bricks
fill 285 34 206 285 35 206 minecraft:red_nether_bricks
setblock 286 34 182 minecraft:polished_blackstone
fill 287 34 182 287 36 183 minecraft:red_nether_bricks
fill 287 34 222 287 37 222 minecraft:red_nether_bricks
setblock 289 34 183 minecraft:red_nether_bricks
setblock 290 34 183 minecraft:polished_blackstone
fill 290 34 184 291 36 184 minecraft:red_nether_bricks
setblock 291 34 182 minecraft:polished_blackstone
fill 291 34 183 291 37 183 minecraft:red_nether_bricks
setblock 291 34 222 minecraft:polished_blackstone
fill 292 34 182 292 37 182 minecraft:red_nether_bricks
fill 292 34 222 292 35 222 minecraft:red_nether_bricks
setblock 295 34 183 minecraft:polished_blackstone
setblock 296 34 182 minecraft:polished_blackstone
fill 296 34 183 296 37 183 minecraft:red_nether_bricks
fill 297 34 182 297 37 182 minecraft:red_nether_bricks
setblock 300 34 183 minecraft:polished_blackstone
setblock 301 34 182 minecraft:polished_blackstone
fill 301 34 183 301 37 183 minecraft:red_nether_bricks
fill 302 34 182 302 37 182 minecraft:red_nether_bricks
setblock 305 34 183 minecraft:polished_blackstone
fill 305 34 184 305 37 184 minecraft:red_nether_bricks
setblock 306 34 182 minecraft:polished_blackstone
fill 306 34 183 306 37 183 minecraft:red_nether_bricks
setblock 306 34 222 minecraft:polished_blackstone
fill 307 34 182 307 37 182 minecraft:red_nether_bricks
setblock 307 34 221 minecraft:polished_blackstone
fill 307 34 222 307 37 222 minecraft:red_nether_bricks
fill 308 34 221 308 37 221 minecraft:red_nether_bricks
setblock 309 34 184 minecraft:polished_blackstone
setblock 310 34 183 minecraft:polished_blackstone
fill 310 34 184 310 37 184 minecraft:red_nether_bricks
setblock 311 34 182 minecraft:polished_blackstone
fill 311 34 183 311 37 183 minecraft:red_nether_bricks
setblock 311 34 222 minecraft:polished_blackstone
fill 312 34 182 312 37 182 minecraft:red_nether_bricks
setblock 312 34 221 minecraft:polished_blackstone
fill 312 34 222 312 37 222 minecraft:red_nether_bricks
fill 313 34 221 313 37 221 minecraft:red_nether_bricks
setblock 315 34 183 minecraft:polished_blackstone
setblock 316 34 182 minecraft:polished_blackstone
setblock 316 34 222 minecraft:polished_blackstone
fill 317 34 182 317 36 182 minecraft:red_nether_bricks
fill 317 34 222 317 37 222 minecraft:red_nether_bricks
setblock 321 34 222 minecraft:polished_blackstone
setblock 322 34 222 minecraft:red_nether_bricks
fill 323 34 201 323 37 201 minecraft:red_nether_bricks
setblock 323 34 205 minecraft:polished_blackstone
fill 323 34 206 323 37 206 minecraft:red_nether_bricks
setblock 323 34 210 minecraft:polished_blackstone
fill 323 34 211 323 37 211 minecraft:red_nether_bricks
setblock 283 35 198 minecraft:red_nether_bricks
setblock 283 35 199 minecraft:polished_blackstone
fill 283 35 200 283 38 200 minecraft:red_nether_bricks
setblock 283 35 204 minecraft:polished_blackstone
fill 283 35 205 283 38 205 minecraft:red_nether_bricks
setblock 283 35 209 minecraft:polished_blackstone
fill 283 35 210 283 37 211 minecraft:red_nether_bricks
setblock 284 35 182 minecraft:red_nether_bricks
setblock 284 35 203 minecraft:polished_blackstone
fill 284 35 204 284 38 204 minecraft:red_nether_bricks
setblock 284 35 208 minecraft:polished_blackstone
fill 284 35 209 284 38 209 minecraft:red_nether_bricks
setblock 285 35 182 minecraft:polished_blackstone
setblock 285 35 202 minecraft:polished_blackstone
fill 285 35 203 285 38 203 minecraft:red_nether_bricks
setblock 285 35 207 minecraft:polished_blackstone
fill 286 35 182 286 37 183 minecraft:red_nether_bricks
setblock 289 35 183 minecraft:polished_blackstone
fill 289 35 184 289 38 184 minecraft:red_nether_bricks
setblock 290 35 182 minecraft:polished_blackstone
fill 290 35 183 290 38 183 minecraft:red_nether_bricks
setblock 290 35 222 minecraft:polished_blackstone
fill 291 35 182 291 38 182 minecraft:red_nether_bricks
fill 291 35 222 291 36 222 minecraft:red_nether_bricks
setblock 294 35 183 minecraft:polished_blackstone
setblock 295 35 182 minecraft:polished_blackstone
fill 295 35 183 295 38 183 minecraft:red_nether_bricks
fill 296 35 182 296 38 182 minecraft:red_nether_bricks
setblock 299 35 183 minecraft:polished_blackstone
setblock 300 35 182 minecraft:polished_blackstone
fill 300 35 183 300 38 183 minecraft:red_nether_bricks
fill 301 35 182 301 38 182 minecraft:red_nether_bricks
setblock 304 35 183 minecraft:polished_blackstone
fill 304 35 184 304 38 184 minecraft:red_nether_bricks
setblock 305 35 182 minecraft:polished_blackstone
fill 305 35 183 305 38 183 minecraft:red_nether_bricks
setblock 305 35 222 minecraft:polished_blackstone
fill 306 35 182 306 38 182 minecraft:red_nether_bricks
setblock 306 35 221 minecraft:polished_blackstone
fill 306 35 222 306 38 222 minecraft:red_nether_bricks
fill 307 35 221 307 38 221 minecraft:red_nether_bricks
setblock 308 35 184 minecraft:polished_blackstone
setblock 309 35 183 minecraft:polished_blackstone
fill 309 35 184 309 38 184 minecraft:red_nether_bricks
setblock 310 35 182 minecraft:polished_blackstone
fill 310 35 183 310 38 183 minecraft:red_nether_bricks
setblock 310 35 222 minecraft:polished_blackstone
fill 311 35 182 311 38 182 minecraft:red_nether_bricks
setblock 311 35 221 minecraft:polished_blackstone
fill 311 35 222 311 38 222 minecraft:red_nether_bricks
fill 312 35 221 312 38 221 minecraft:red_nether_bricks
setblock 314 35 183 minecraft:polished_blackstone
setblock 315 35 182 minecraft:polished_blackstone
setblock 315 35 183 minecraft:red_nether_bricks
setblock 315 35 222 minecraft:polished_blackstone
fill 316 35 182 316 38 182 minecraft:red_nether_bricks
fill 316 35 222 316 38 222 minecraft:red_nether_bricks
setblock 322 35 205 minecraft:polished_blackstone
fill 322 35 206 322 37 207 minecraft:red_nether_bricks
setblock 323 35 204 minecraft:polished_blackstone
fill 323 35 205 323 38 205 minecraft:red_nether_bricks
setblock 323 35 209 minecraft:polished_blackstone
fill 323 35 210 323 38 210 minecraft:red_nether_bricks
fill 323 35 212 323 36 212 minecraft:red_nether_bricks
setblock 283 36 183 minecraft:polished_blackstone
fill 283 36 184 283 36 187 minecraft:red_nether_bricks
setblock 283 36 188 minecraft:polished_blackstone
setblock 283 36 198 minecraft:polished_blackstone
fill 283 36 199 284 38 199 minecraft:red_nether_bricks
setblock 283 36 203 minecraft:polished_blackstone
fill 283 36 204 283 39 204 minecraft:red_nether_bricks
setblock 283 36 208 minecraft:polished_blackstone
fill 283 36 209 283 39 209 minecraft:red_nether_bricks
setblock 283 36 212 minecraft:red_nether_bricks
setblock 284 36 182 minecraft:polished_blackstone
setblock 284 36 202 minecraft:polished_blackstone
fill 284 36 203 284 39 203 minecraft:red_nether_bricks
setblock 284 36 207 minecraft:polished_blackstone
fill 284 36 208 285 38 208 minecraft:red_nether_bricks
fill 284 36 210 284 37 210 minecraft:red_nether_bricks
fill 285 36 182 285 38 183 minecraft:red_nether_bricks
setblock 285 36 184 minecraft:light[level=14]
setblock 285 36 192 minecraft:light[level=14]
setblock 285 36 200 minecraft:light[level=14]
setblock 285 36 201 minecraft:polished_blackstone
fill 285 36 202 285 39 202 minecraft:red_nether_bricks
setblock 285 36 206 minecraft:polished_blackstone
fill 285 36 207 285 39 207 minecraft:red_nether_bricks
setblock 285 36 216 minecraft:light[level=14]
setblock 288 36 182 minecraft:red_nether_bricks
setblock 288 36 183 minecraft:polished_blackstone
fill 288 36 184 288 39 184 minecraft:red_nether_bricks
setblock 289 36 182 minecraft:polished_blackstone
fill 289 36 183 289 39 183 minecraft:red_nether_bricks
setblock 289 36 222 minecraft:polished_blackstone
fill 290 36 182 290 39 182 minecraft:red_nether_bricks
fill 290 36 222 290 39 222 minecraft:red_nether_bricks
setblock 292 36 183 minecraft:red_nether_bricks
setblock 292 36 184 minecraft:polished_blackstone
setblock 293 36 183 minecraft:polished_blackstone
fill 293 36 184 293 39 184 minecraft:red_nether_bricks
setblock 293 36 192 minecraft:light[level=14]
setblock 293 36 200 minecraft:light[level=14]
setblock 293 36 208 minecraft:light[level=14]
setblock 293 36 216 minecraft:light[level=14]
setblock 294 36 182 minecraft:polished_blackstone
fill 294 36 183 294 39 183 minecraft:red_nether_bricks
fill 295 36 182 295 39 182 minecraft:red_nether_bricks
setblock 297 36 183 minecraft:red_nether_bricks
setblock 298 36 183 minecraft:polished_blackstone
setblock 299 36 182 minecraft:polished_blackstone
fill 299 36 183 299 39 183 minecraft:red_nether_bricks
fill 300 36 182 300 39 182 minecraft:red_nether_bricks
setblock 301 36 184 minecraft:light[level=14]
setblock 301 36 192 minecraft:light[level=14]
setblock 301 36 200 minecraft:light[level=14]
setblock 301 36 208 minecraft:light[level=14]
setblock 301 36 216 minecraft:light[level=14]
setblock 303 36 183 minecraft:polished_blackstone
fill 303 36 184 303 39 184 minecraft:red_nether_bricks
setblock 304 36 182 minecraft:polished_blackstone
fill 304 36 183 304 39 183 minecraft:red_nether_bricks
setblock 304 36 222 minecraft:polished_blackstone
fill 305 36 182 305 39 182 minecraft:red_nether_bricks
fill 305 36 222 305 39 222 minecraft:red_nether_bricks
fill 306 36 221 306 39 221 minecraft:red_nether_bricks
setblock 307 36 184 minecraft:polished_blackstone
setblock 308 36 183 minecraft:polished_blackstone
fill 308 36 184 308 39 184 minecraft:red_nether_bricks
setblock 309 36 182 minecraft:polished_blackstone
fill 309 36 183 309 39 183 minecraft:red_nether_bricks
setblock 309 36 192 minecraft:light[level=14]
setblock 309 36 200 minecraft:light[level=14]
setblock 309 36 208 minecraft:light[level=14]
setblock 309 36 216 minecraft:light[level=14]
setblock 309 36 222 minecraft:polished_blackstone
fill 310 36 182 310 39 182 minecraft:red_nether_bricks
setblock 310 36 221 minecraft:polished_blackstone
fill 310 36 222 310 39 222 minecraft:red_nether_bricks
fill 311 36 221 311 39 221 minecraft:red_nether_bricks
setblock 312 36 184 minecraft:polished_blackstone
setblock 313 36 183 minecraft:polished_blackstone
setblock 314 36 182 minecraft:polished_blackstone
fill 314 36 183 314 38 183 minecraft:red_nether_bricks
setblock 314 36 222 minecraft:polished_blackstone
fill 315 36 182 315 39 182 minecraft:red_nether_bricks
fill 315 36 222 315 39 222 minecraft:red_nether_bricks
setblock 317 36 184 minecraft:light[level=14]
setblock 317 36 192 minecraft:light[level=14]
setblock 317 36 200 minecraft:light[level=14]
setblock 317 36 208 minecraft:light[level=14]
setblock 317 36 216 minecraft:light[level=14]
setblock 322 36 204 minecraft:polished_blackstone
fill 322 36 205 322 39 205 minecraft:red_nether_bricks
setblock 322 36 208 minecraft:red_nether_bricks
setblock 322 36 209 minecraft:polished_blackstone
setblock 323 36 203 minecraft:polished_blackstone
fill 323 36 204 323 39 204 minecraft:red_nether_bricks
setblock 323 36 208 minecraft:polished_blackstone
fill 323 36 209 323 39 209 minecraft:red_nether_bricks
setblock 323 36 213 minecraft:polished_blackstone
fill 323 36 214 323 39 214 minecraft:red_nether_bricks
setblock 283 37 182 minecraft:polished_blackstone
fill 283 37 183 283 37 186 minecraft:red_nether_bricks
setblock 283 37 187 minecraft:polished_blackstone
fill 283 37 188 283 37 191 minecraft:red_nether_bricks
setblock 283 37 192 minecraft:polished_blackstone
fill 283 37 193 283 37 196 minecraft:red_nether_bricks
setblock 283 37 197 minecraft:polished_blackstone
fill 283 37 198 283 40 198 minecraft:red_nether_bricks
setblock 283 37 202 minecraft:polished_blackstone
fill 283 37 203 283 40 203 minecraft:red_nether_bricks
setblock 283 37 207 minecraft:polished_blackstone
fill 283 37 208 283 40 208 minecraft:red_nether_bricks
setblock 283 37 212 minecraft:polished_blackstone
fill 283 37 213 283 40 213 minecraft:red_nether_bricks
fill 284 37 182 284 40 182 minecraft:red_nether_bricks
fill 284 37 184 284 37 185 minecraft:red_nether_bricks
setblock 284 37 186 minecraft:polished_blackstone
fill 284 37 187 284 38 189 minecraft:red_nether_bricks
setblock 284 37 201 minecraft:polished_blackstone
fill 284 37 202 284 40 202 minecraft:red_nether_bricks
setblock 284 37 206 minecraft:polished_blackstone
fill 284 37 207 284 40 207 minecraft:red_nether_bricks
setblock 284 37 211 minecraft:polished_blackstone
fill 285 37 201 285 40 201 minecraft:red_nether_bricks
setblock 285 37 205 minecraft:polished_blackstone
fill 285 37 206 286 39 206 minecraft:red_nether_bricks
setblock 285 37 209 minecraft:red_nether_bricks
setblock 286 37 184 minecraft:polished_blackstone
setblock 286 37 204 minecraft:polished_blackstone
fill 286 37 205 286 40 205 minecraft:red_nether_bricks
fill 286 37 222 286 38 222 minecraft:red_nether_bricks
setblock 287 37 182 minecraft:red_nether_bricks
setblock 287 37 183 minecraft:polished_blackstone
fill 287 37 184 287 40 184 minecraft:red_nether_bricks
setblock 288 37 182 minecraft:polished_blackstone
fill 288 37 183 288 40 183 minecraft:red_nether_bricks
setblock 288 37 222 minecraft:polished_blackstone
fill 289 37 182 289 40 182 minecraft:red_nether_bricks
fill 289 37 222 289 40 222 minecraft:red_nether_bricks
setblock 290 37 184 minecraft:red_nether_bricks
setblock 291 37 184 minecraft:polished_blackstone
setblock 292 37 183 minecraft:polished_blackstone
fill 292 37 184 292 40 184 minecraft:red_nether_bricks
setblock 293 37 182 minecraft:polished_blackstone
fill 293 37 183 293 40 183 minecraft:red_nether_bricks
fill 294 37 182 294 40 182 minecraft:red_nether_bricks
setblock 297 37 183 minecraft:polished_blackstone
setblock 298 37 182 minecraft:polished_blackstone
fill 298 37 183 298 40 183 minecraft:red_nether_bricks
fill 299 37 182 299 40 182 minecraft:red_nether_bricks
setblock 302 37 183 minecraft:polished_blackstone
fill 302 37 184 302 40 184 minecraft:red_nether_bricks
setblock 302 37 222 minecraft:red_nether_bricks
setblock 303 37 182 minecraft:polished_blackstone
fill 303 37 183 303 40 183 minecraft:red_nether_bricks
setblock 303 37 222 minecraft:polished_blackstone
fill 304 37 182 304 40 182 minecraft:red_nether_bricks
fill 304 37 222 304 40 222 minecraft:red_nether_bricks
fill 305 37 221 305 40 221 minecraft:red_nether_bricks
setblock 306 37 184 minecraft:polished_blackstone
fill 306 37 185 309 37 185 minecraft:red_nether_bricks
setblock 307 37 183 minecraft:polished_blackstone
fill 307 37 184 307 40 184 minecraft:red_nether_bricks
setblock 308 37 182 minecraft:polished_blackstone
fill 308 37 183 308 40 183 minecraft:red_nether_bricks
setblock 308 37 222 minecraft:polished_blackstone
fill 309 37 182 309 40 182 minecraft:red_nether_bricks
setblock 309 37 221 minecraft:polished_blackstone
fill 309 37 222 309 40 222 minecraft:red_nether_bricks
fill 310 37 221 310 40 221 minecraft:red_nether_bricks
setblock 311 37 184 minecraft:polished_blackstone
setblock 312 37 183 minecraft:polished_blackstone
fill 312 37 184 312 38 184 minecraft:red_nether_bricks
setblock 313 37 182 minecraft:polished_blackstone
fill 313 37 183 313 39 183 minecraft:red_nether_bricks
setblock 313 37 222 minecraft:polished_blackstone
fill 314 37 182 314 40 182 minecraft:red_nether_bricks
fill 314 37 198 314 38 198 minecraft:blackstone
fill 314 37 222 314 40 222 minecraft:red_nether_bricks
setblock 322 37 203 minecraft:polished_blackstone
fill 322 37 204 322 40 204 minecraft:red_nether_bricks
setblock 322 37 208 minecraft:polished_blackstone
fill 322 37 209 322 38 211 minecraft:red_nether_bricks
setblock 323 37 182 minecraft:polished_blackstone
fill 323 37 183 323 37 186 minecraft:red_nether_bricks
setblock 323 37 187 minecraft:polished_blackstone
fill 323 37 200 323 38 200 minecraft:red_nether_bricks
setblock 323 37 202 minecraft:polished_blackstone
fill 323 37 203 323 40 203 minecraft:red_nether_bricks
setblock 323 37 207 minecraft:polished_blackstone
fill 323 37 208 323 40 208 minecraft:red_nether_bricks
setblock 323 37 212 minecraft:polished_blackstone
fill 323 37 213 323 40 213 minecraft:red_nether_bricks
fill 323 37 215 323 37 216 minecraft:red_nether_bricks
setblock 323 37 222 minecraft:polished_blackstone
fill 283 38 182 283 38 185 minecraft:red_nether_bricks
setblock 283 38 186 minecraft:polished_blackstone
fill 283 38 187 283 38 190 minecraft:red_nether_bricks
setblock 283 38 191 minecraft:polished_blackstone
fill 283 38 192 283 38 195 minecraft:red_nether_bricks
setblock 283 38 196 minecraft:polished_blackstone
fill 283 38 197 284 40 197 minecraft:red_nether_bricks
setblock 283 38 201 minecraft:polished_blackstone
fill 283 38 202 283 41 202 minecraft:red_nether_bricks
setblock 283 38 206 minecraft:polished_blackstone
fill 283 38 207 283 41 207 minecraft:red_nether_bricks
setblock 283 38 210 minecraft:red_nether_bricks
setblock 283 38 211 minecraft:polished_blackstone
fill 283 38 212 284 40 212 minecraft:red_nether_bricks
fill 283 38 214 283 39 214 minecraft:red_nether_bricks
fill 284 38 183 284 38 184 minecraft:red_nether_bricks
setblock 284 38 185 minecraft:polished_blackstone
fill 284 38 186 285 40 186 minecraft:red_nether_bricks
setblock 284 38 190 minecraft:polished_blackstone
fill 284 38 191 284 38 194 minecraft:red_nether_bricks
setblock 284 38 195 minecraft:polished_blackstone
fill 284 38 196 284 41 196 minecraft:red_nether_bricks
fill 284 38 198 284 39 198 minecraft:red_nether_bricks
setblock 284 38 200 minecraft:polished_blackstone
fill 284 38 201 284 41 201 minecraft:red_nether_bricks
setblock 284 38 205 minecraft:polished_blackstone
fill 284 38 206 284 41 206 minecraft:red_nether_bricks
setblock 284 38 210 minecraft:polished_blackstone
fill 284 38 211 284 41 211 minecraft:red_nether_bricks
setblock 285 38 184 minecraft:polished_blackstone
fill 285 38 185 285 41 185 minecraft:red_nether_bricks
fill 285 38 187 285 38 188 minecraft:red_nether_bricks
setblock 285 38 189 minecraft:polished_blackstone
fill 285 38 190 285 41 190 minecraft:red_nether_bricks
fill 285 38 200 285 41 200 minecraft:red_nether_bricks
setblock 285 38 204 minecraft:polished_blackstone
fill 285 38 205 285 41 205 minecraft:red_nether_bricks
setblock 285 38 209 minecraft:polished_blackstone
fill 285 38 210 285 41 210 minecraft:red_nether_bricks
setblock 286 38 182 minecraft:red_nether_bricks
setblock 286 38 183 minecraft:polished_blackstone
fill 286 38 184 286 41 184 minecraft:red_nether_bricks
fill 286 38 204 286 40 204 minecraft:red_nether_bricks
setblock 286 38 207 minecraft:red_nether_bricks
setblock 286 38 208 minecraft:polished_blackstone
setblock 287 38 182 minecraft:polished_blackstone
fill 287 38 183 287 41 183 minecraft:red_nether_bricks
setblock 287 38 222 minecraft:polished_blackstone
fill 288 38 182 288 41 182 minecraft:red_nether_bricks
fill 288 38 222 288 41 222 minecraft:red_nether_bricks
setblock 289 38 185 minecraft:polished_blackstone
setblock 290 38 184 minecraft:polished_blackstone
setblock 291 38 183 minecraft:polished_blackstone
fill 291 38 184 291 41 184 minecraft:red_nether_bricks
setblock 292 38 182 minecraft:polished_blackstone
fill 292 38 183 292 41 183 minecraft:red_nether_bricks
fill 293 38 182 293 41 182 minecraft:red_nether_bricks
setblock 296 38 183 minecraft:polished_blackstone
setblock 297 38 182 minecraft:polished_blackstone
fill 297 38 183 297 41 183 minecraft:red_nether_bricks
fill 298 38 182 298 41 182 minecraft:red_nether_bricks
setblock 301 38 183 minecraft:polished_blackstone
fill 301 38 184 301 41 184 minecraft:red_nether_bricks
setblock 301 38 222 minecraft:red_nether_bricks
setblock 302 38 182 minecraft:polished_blackstone
fill 302 38 183 302 41 183 minecraft:red_nether_bricks
setblock 302 38 222 minecraft:polished_blackstone
fill 303 38 182 303 41 182 minecraft:red_nether_bricks
fill 303 38 222 303 41 222 minecraft:red_nether_bricks
setblock 304 38 185 minecraft:polished_blackstone
fill 304 38 221 304 41 221 minecraft:red_nether_bricks
setblock 305 38 184 minecraft:polished_blackstone
fill 305 38 185 308 38 185 minecraft:red_nether_bricks
setblock 306 38 183 minecraft:polished_blackstone
fill 306 38 184 306 41 184 minecraft:red_nether_bricks
setblock 307 38 182 minecraft:polished_blackstone
fill 307 38 183 307 41 183 minecraft:red_nether_bricks
setblock 307 38 222 minecraft:polished_blackstone
fill 308 38 182 308 41 182 minecraft:red_nether_bricks
setblock 308 38 221 minecraft:polished_blackstone
fill 308 38 222 308 41 222 minecraft:red_nether_bricks
setblock 309 38 185 minecraft:polished_blackstone
fill 309 38 221 309 41 221 minecraft:red_nether_bricks
setblock 310 38 184 minecraft:polished_blackstone
setblock 311 38 183 minecraft:polished_blackstone
fill 311 38 184 311 40 184 minecraft:red_nether_bricks
setblock 312 38 182 minecraft:polished_blackstone
fill 312 38 183 312 41 183 minecraft:red_nether_bricks
setblock 312 38 222 minecraft:polished_blackstone
fill 313 38 182 313 41 182 minecraft:red_nether_bricks
setblock 313 38 221 minecraft:polished_blackstone
fill 313 38 222 313 41 222 minecraft:red_nether_bricks
schedule function dropper:buildpart/42_3 1t
