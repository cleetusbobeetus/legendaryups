setblock 192 120 441 minecraft:iron_block
fill 196 120 456 198 120 456 minecraft:polished_deepslate
fill 200 120 418 202 120 418 minecraft:polished_deepslate
fill 208 120 456 210 120 456 minecraft:polished_deepslate
fill 212 120 418 214 120 418 minecraft:polished_deepslate
fill 220 120 456 222 120 456 minecraft:polished_deepslate
fill 224 120 418 226 120 418 minecraft:polished_deepslate
fill 228 120 426 228 120 428 minecraft:polished_deepslate
fill 228 120 438 228 120 440 minecraft:polished_deepslate
fill 228 120 450 228 120 452 minecraft:polished_deepslate
setblock 191 121 419 minecraft:light[level=13]
setblock 191 121 427 minecraft:light[level=13]
setblock 191 121 435 minecraft:light[level=13]
setblock 191 121 443 minecraft:light[level=13]
setblock 191 121 451 minecraft:light[level=13]
setblock 199 121 419 minecraft:light[level=13]
setblock 199 121 427 minecraft:light[level=13]
setblock 199 121 435 minecraft:light[level=13]
setblock 199 121 443 minecraft:light[level=13]
setblock 199 121 451 minecraft:light[level=13]
setblock 207 121 419 minecraft:light[level=13]
setblock 207 121 427 minecraft:light[level=13]
setblock 207 121 435 minecraft:light[level=13]
setblock 207 121 443 minecraft:light[level=13]
setblock 207 121 451 minecraft:light[level=13]
setblock 215 121 419 minecraft:light[level=13]
setblock 215 121 427 minecraft:light[level=13]
setblock 215 121 435 minecraft:light[level=13]
setblock 215 121 443 minecraft:light[level=13]
setblock 215 121 451 minecraft:light[level=13]
setblock 223 121 419 minecraft:light[level=13]
setblock 223 121 427 minecraft:light[level=13]
setblock 223 121 435 minecraft:light[level=13]
setblock 223 121 443 minecraft:light[level=13]
setblock 223 121 451 minecraft:light[level=13]
fill 189 126 417 189 127 421 minecraft:iron_block
fill 189 126 422 189 127 423 minecraft:polished_deepslate
fill 189 126 424 189 127 432 minecraft:iron_block
fill 189 126 433 189 127 433 minecraft:polished_deepslate
fill 189 126 434 189 127 442 minecraft:iron_block
fill 189 126 443 189 127 444 minecraft:polished_deepslate
fill 189 126 445 189 127 453 minecraft:iron_block
fill 189 126 454 189 127 454 minecraft:polished_deepslate
fill 189 126 455 191 127 457 minecraft:iron_block
fill 190 126 417 190 127 419 minecraft:iron_block
fill 190 126 420 190 127 420 minecraft:polished_deepslate
fill 190 126 421 190 127 429 minecraft:iron_block
fill 190 126 430 190 127 431 minecraft:polished_deepslate
fill 190 126 432 190 127 440 minecraft:iron_block
fill 190 126 441 190 127 441 minecraft:polished_deepslate
fill 190 126 442 190 127 450 minecraft:iron_block
fill 190 126 451 190 127 452 minecraft:polished_deepslate
fill 190 126 453 193 127 454 minecraft:iron_block
fill 191 126 417 195 127 417 minecraft:iron_block
fill 191 126 418 191 127 418 minecraft:polished_deepslate
fill 191 126 419 191 127 427 minecraft:iron_block
fill 191 126 428 191 127 428 minecraft:polished_deepslate
fill 191 126 429 191 127 438 minecraft:iron_block
fill 191 126 439 191 127 439 minecraft:polished_deepslate
fill 191 126 440 191 127 448 minecraft:iron_block
fill 191 126 449 191 127 449 minecraft:polished_deepslate
fill 191 126 450 194 127 452 minecraft:iron_block
fill 192 126 418 192 127 425 minecraft:iron_block
fill 192 126 426 192 127 426 minecraft:polished_deepslate
fill 192 126 427 192 127 435 minecraft:iron_block
fill 192 126 436 192 127 437 minecraft:polished_deepslate
fill 192 126 438 192 127 446 minecraft:iron_block
fill 192 126 447 192 127 447 minecraft:polished_deepslate
fill 192 126 448 195 127 449 minecraft:iron_block
fill 192 126 455 192 127 456 minecraft:iron_block
fill 192 126 457 192 127 457 minecraft:polished_deepslate
fill 193 126 418 193 127 422 minecraft:iron_block
fill 193 126 423 193 127 424 minecraft:polished_deepslate
fill 193 126 425 193 127 433 minecraft:iron_block
fill 193 126 434 193 127 434 minecraft:polished_deepslate
fill 193 126 435 193 127 443 minecraft:iron_block
fill 193 126 444 193 127 445 minecraft:polished_deepslate
fill 193 126 446 196 127 447 minecraft:iron_block
fill 193 126 455 193 127 455 minecraft:polished_deepslate
fill 193 126 456 196 127 457 minecraft:iron_block
fill 194 126 418 194 127 420 minecraft:iron_block
fill 194 126 421 194 127 421 minecraft:polished_deepslate
fill 194 126 422 194 127 431 minecraft:iron_block
fill 194 126 432 194 127 432 minecraft:polished_deepslate
fill 194 126 433 194 127 441 minecraft:iron_block
fill 194 126 442 194 127 442 minecraft:polished_deepslate
fill 194 126 443 197 127 445 minecraft:iron_block
fill 194 126 453 194 127 453 minecraft:polished_deepslate
fill 194 126 454 197 127 455 minecraft:iron_block
fill 195 126 418 199 127 418 minecraft:iron_block
fill 195 126 419 195 127 419 minecraft:polished_deepslate
fill 195 126 420 195 127 428 minecraft:iron_block
fill 195 126 429 195 127 430 minecraft:polished_deepslate
fill 195 126 431 195 127 439 minecraft:iron_block
fill 195 126 440 195 127 440 minecraft:polished_deepslate
fill 195 126 441 198 127 442 minecraft:iron_block
fill 195 126 450 195 127 451 minecraft:polished_deepslate
fill 195 126 452 198 127 453 minecraft:iron_block
fill 196 126 417 196 127 417 minecraft:polished_deepslate
fill 196 126 419 196 127 426 minecraft:iron_block
fill 196 126 427 196 127 427 minecraft:polished_deepslate
fill 196 126 428 196 127 436 minecraft:iron_block
fill 196 126 437 196 127 438 minecraft:polished_deepslate
fill 196 126 439 199 127 440 minecraft:iron_block
fill 196 126 448 196 127 448 minecraft:polished_deepslate
fill 196 126 449 198 127 451 minecraft:iron_block
fill 197 126 417 204 127 417 minecraft:iron_block
fill 197 126 419 197 127 424 minecraft:iron_block
fill 197 126 425 197 127 425 minecraft:polished_deepslate
fill 197 126 426 197 127 434 minecraft:iron_block
fill 197 126 435 197 127 435 minecraft:polished_deepslate
fill 197 126 436 200 127 438 minecraft:iron_block
fill 197 126 446 197 127 446 minecraft:polished_deepslate
fill 197 126 447 200 127 448 minecraft:iron_block
fill 197 126 456 197 127 456 minecraft:polished_deepslate
fill 197 126 457 200 127 457 minecraft:iron_block
fill 198 126 419 198 127 421 minecraft:iron_block
fill 198 126 422 198 127 423 minecraft:polished_deepslate
fill 198 126 424 198 127 432 minecraft:iron_block
fill 198 126 433 198 127 433 minecraft:polished_deepslate
fill 198 126 434 201 127 435 minecraft:iron_block
fill 198 126 443 198 127 444 minecraft:polished_deepslate
fill 198 126 445 201 127 446 minecraft:iron_block
fill 198 126 454 198 127 454 minecraft:polished_deepslate
fill 198 126 455 201 127 456 minecraft:iron_block
fill 199 126 419 203 127 419 minecraft:iron_block
fill 199 126 420 199 127 420 minecraft:polished_deepslate
fill 199 126 421 199 127 429 minecraft:iron_block
fill 199 126 430 199 127 431 minecraft:polished_deepslate
fill 199 126 432 202 127 433 minecraft:iron_block
fill 199 126 441 199 127 441 minecraft:polished_deepslate
fill 199 126 442 201 127 444 minecraft:iron_block
fill 199 126 449 199 127 450 minecraft:iron_block
fill 199 126 451 199 127 452 minecraft:polished_deepslate
fill 199 126 453 202 127 454 minecraft:iron_block
fill 200 126 418 200 127 418 minecraft:polished_deepslate
fill 200 126 420 200 127 427 minecraft:iron_block
fill 200 126 428 200 127 428 minecraft:polished_deepslate
fill 200 126 429 203 127 431 minecraft:iron_block
fill 200 126 439 200 127 439 minecraft:polished_deepslate
fill 200 126 440 203 127 441 minecraft:iron_block
fill 200 126 449 200 127 449 minecraft:polished_deepslate
fill 200 126 450 202 127 452 minecraft:iron_block
fill 201 126 418 208 127 418 minecraft:iron_block
fill 201 126 420 201 127 425 minecraft:iron_block
fill 201 126 426 201 127 426 minecraft:polished_deepslate
fill 201 126 427 204 127 428 minecraft:iron_block
fill 201 126 436 201 126 437 minecraft:polished_deepslate
fill 201 126 438 204 127 439 minecraft:iron_block
setblock 201 126 447 minecraft:polished_deepslate
fill 201 126 448 204 127 449 minecraft:iron_block
fill 201 126 457 201 127 457 minecraft:polished_deepslate
fill 202 126 420 202 127 422 minecraft:iron_block
fill 202 126 423 202 127 424 minecraft:polished_deepslate
fill 202 126 425 205 127 426 minecraft:iron_block
fill 202 126 434 202 127 434 minecraft:polished_deepslate
fill 202 126 435 204 127 437 minecraft:iron_block
fill 202 126 442 202 127 443 minecraft:iron_block
fill 202 126 444 202 127 445 minecraft:polished_deepslate
fill 202 126 446 205 128 447 minecraft:iron_block
fill 202 126 455 202 127 455 minecraft:polished_deepslate
fill 202 126 456 205 127 457 minecraft:iron_block
fill 203 126 420 207 127 420 minecraft:iron_block
fill 203 126 421 203 127 421 minecraft:polished_deepslate
fill 203 126 422 206 127 424 minecraft:iron_block
fill 203 126 432 203 127 432 minecraft:polished_deepslate
fill 203 126 433 206 127 434 minecraft:iron_block
setblock 203 126 442 minecraft:polished_deepslate
fill 203 126 443 205 128 445 minecraft:iron_block
fill 203 126 450 203 127 451 minecraft:iron_block
fill 203 126 452 203 127 453 minecraft:polished_deepslate
fill 203 126 454 206 127 455 minecraft:iron_block
fill 204 126 419 204 127 419 minecraft:polished_deepslate
fill 204 126 421 211 127 421 minecraft:iron_block
fill 204 126 429 204 127 430 minecraft:polished_deepslate
fill 204 126 431 207 127 432 minecraft:iron_block
setblock 204 126 440 minecraft:polished_deepslate
fill 204 126 441 207 128 442 minecraft:iron_block
fill 204 126 450 204 127 450 minecraft:polished_deepslate
fill 204 126 451 207 127 453 minecraft:iron_block
fill 205 126 417 205 127 417 minecraft:polished_deepslate
fill 205 126 419 212 127 419 minecraft:iron_block
fill 205 126 427 205 127 427 minecraft:polished_deepslate
fill 205 126 428 207 127 430 minecraft:iron_block
fill 205 126 435 205 128 436 minecraft:iron_block
fill 205 126 437 205 126 438 minecraft:polished_deepslate
fill 205 126 439 208 128 440 minecraft:iron_block
setblock 205 126 448 minecraft:polished_deepslate
fill 205 126 449 208 127 450 minecraft:iron_block
fill 206 126 417 213 127 417 minecraft:iron_block
fill 206 126 425 206 127 425 minecraft:polished_deepslate
fill 206 126 426 209 127 427 minecraft:iron_block
setblock 206 126 435 minecraft:polished_deepslate
fill 206 126 436 208 128 438 minecraft:iron_block
fill 206 126 443 206 128 444 minecraft:iron_block
fill 206 126 445 206 126 446 minecraft:polished_deepslate
fill 206 126 447 209 128 448 minecraft:iron_block
fill 206 126 456 206 127 456 minecraft:polished_deepslate
fill 206 126 457 209 127 457 minecraft:iron_block
fill 207 126 422 207 127 423 minecraft:polished_deepslate
fill 207 126 424 210 127 425 minecraft:iron_block
setblock 207 126 433 minecraft:polished_deepslate
fill 207 126 434 210 128 435 minecraft:iron_block
setblock 207 126 443 minecraft:polished_deepslate
fill 207 126 444 210 126 446 minecraft:iron_block
fill 207 126 454 207 127 454 minecraft:polished_deepslate
fill 207 126 455 210 127 456 minecraft:iron_block
fill 208 126 420 208 127 420 minecraft:polished_deepslate
fill 208 126 422 210 127 423 minecraft:iron_block
fill 208 126 428 208 127 429 minecraft:iron_block
fill 208 126 430 208 127 431 minecraft:polished_deepslate
fill 208 126 432 211 127 433 minecraft:iron_block
setblock 208 126 441 minecraft:polished_deepslate
fill 208 126 442 210 126 443 minecraft:iron_block
fill 208 126 451 208 126 452 minecraft:polished_deepslate
fill 208 126 453 211 127 454 minecraft:iron_block
fill 209 126 418 209 127 418 minecraft:polished_deepslate
fill 209 126 420 216 127 420 minecraft:iron_block
fill 209 126 428 209 127 428 minecraft:polished_deepslate
fill 209 126 429 211 127 431 minecraft:iron_block
fill 209 126 436 209 128 437 minecraft:iron_block
fill 209 126 438 209 126 439 minecraft:polished_deepslate
fill 209 126 440 210 126 441 minecraft:iron_block
setblock 209 126 449 minecraft:polished_deepslate
fill 209 126 450 211 128 452 minecraft:iron_block
fill 210 126 418 217 127 418 minecraft:iron_block
fill 210 126 426 210 127 426 minecraft:polished_deepslate
fill 210 126 427 213 127 428 minecraft:iron_block
setblock 210 126 436 minecraft:polished_deepslate
fill 210 126 437 213 126 439 minecraft:iron_block
setblock 210 126 447 minecraft:polished_deepslate
fill 210 126 448 213 128 449 minecraft:iron_block
fill 210 126 457 210 127 457 minecraft:polished_deepslate
fill 211 126 422 215 127 422 minecraft:iron_block
fill 211 126 423 211 127 424 minecraft:polished_deepslate
fill 211 126 425 214 127 426 minecraft:iron_block
setblock 211 126 434 minecraft:polished_deepslate
fill 211 126 435 214 128 436 minecraft:iron_block
setblock 211 126 440 minecraft:iron_block
fill 211 126 444 211 126 445 minecraft:polished_deepslate
fill 211 126 446 214 126 447 minecraft:iron_block
fill 211 126 455 211 127 455 minecraft:polished_deepslate
fill 211 126 456 214 127 457 minecraft:iron_block
fill 212 126 421 212 127 421 minecraft:polished_deepslate
fill 212 126 423 214 127 424 minecraft:iron_block
fill 212 126 429 212 127 430 minecraft:iron_block
fill 212 126 431 212 126 432 minecraft:polished_deepslate
fill 212 126 433 215 128 434 minecraft:iron_block
fill 212 126 445 214 126 445 minecraft:iron_block
fill 212 126 450 212 128 451 minecraft:iron_block
fill 212 126 452 212 126 453 minecraft:polished_deepslate
fill 212 126 454 215 127 455 minecraft:iron_block
fill 213 126 419 213 127 419 minecraft:polished_deepslate
fill 213 126 421 220 127 421 minecraft:iron_block
fill 213 126 429 213 127 429 minecraft:polished_deepslate
fill 213 126 430 216 127 432 minecraft:iron_block
setblock 213 126 450 minecraft:polished_deepslate
fill 213 126 451 216 127 453 minecraft:iron_block
fill 214 126 417 214 127 417 minecraft:polished_deepslate
fill 214 126 419 221 127 419 minecraft:iron_block
fill 214 126 427 214 127 427 minecraft:polished_deepslate
fill 214 126 428 217 127 429 minecraft:iron_block
fill 214 126 437 214 126 438 minecraft:polished_deepslate
fill 214 126 439 217 126 439 minecraft:iron_block
setblock 214 126 448 minecraft:polished_deepslate
fill 214 126 449 217 128 450 minecraft:iron_block
fill 215 126 417 217 127 417 minecraft:iron_block
fill 215 126 423 219 127 423 minecraft:iron_block
fill 215 126 424 215 127 425 minecraft:polished_deepslate
fill 215 126 426 218 127 427 minecraft:iron_block
setblock 215 126 435 minecraft:polished_deepslate
fill 215 126 436 217 128 438 minecraft:iron_block
fill 215 126 440 221 126 440 minecraft:iron_block
fill 215 126 444 219 126 444 minecraft:iron_block
fill 215 126 445 215 126 446 minecraft:polished_deepslate
fill 215 126 447 218 128 448 minecraft:iron_block
fill 215 126 456 215 127 456 minecraft:polished_deepslate
fill 215 126 457 218 127 457 minecraft:iron_block
fill 216 126 422 216 127 422 minecraft:polished_deepslate
fill 216 126 424 219 127 425 minecraft:iron_block
setblock 216 126 433 minecraft:polished_deepslate
fill 216 126 434 219 128 435 minecraft:iron_block
fill 216 126 441 216 126 442 minecraft:iron_block
setblock 216 126 443 minecraft:polished_deepslate
fill 216 126 445 219 128 446 minecraft:iron_block
setblock 216 126 454 minecraft:polished_deepslate
fill 216 126 455 219 127 456 minecraft:iron_block
fill 217 126 420 217 127 420 minecraft:polished_deepslate
fill 217 126 422 224 127 422 minecraft:iron_block
fill 217 126 430 217 127 431 minecraft:polished_deepslate
fill 217 126 432 220 127 433 minecraft:iron_block
setblock 217 126 441 minecraft:polished_deepslate
fill 217 126 442 220 126 443 minecraft:iron_block
fill 217 126 451 217 126 452 minecraft:polished_deepslate
fill 217 126 453 220 127 454 minecraft:iron_block
fill 218 126 417 218 127 418 minecraft:polished_deepslate
fill 218 126 420 225 127 420 minecraft:iron_block
fill 218 126 428 218 127 428 minecraft:polished_deepslate
fill 218 126 429 220 127 431 minecraft:iron_block
fill 218 126 436 218 128 437 minecraft:iron_block
fill 218 126 438 218 126 439 minecraft:polished_deepslate
fill 218 126 441 225 127 441 minecraft:iron_block
setblock 218 126 449 minecraft:polished_deepslate
fill 218 126 450 220 127 452 minecraft:iron_block
fill 219 126 417 222 127 418 minecraft:iron_block
fill 219 126 426 219 127 426 minecraft:polished_deepslate
fill 219 126 427 222 127 428 minecraft:iron_block
setblock 219 126 436 minecraft:polished_deepslate
fill 219 126 437 222 128 439 minecraft:iron_block
setblock 219 126 447 minecraft:polished_deepslate
fill 219 126 448 222 127 449 minecraft:iron_block
fill 219 126 457 219 127 457 minecraft:polished_deepslate
fill 220 126 423 220 127 424 minecraft:polished_deepslate
fill 220 126 425 223 127 426 minecraft:iron_block
setblock 220 126 434 minecraft:polished_deepslate
fill 220 126 435 223 127 436 minecraft:iron_block
fill 220 126 444 220 126 445 minecraft:polished_deepslate
fill 220 126 446 223 128 447 minecraft:iron_block
fill 220 126 455 220 127 455 minecraft:polished_deepslate
fill 220 126 456 223 127 457 minecraft:iron_block
fill 221 126 421 221 127 421 minecraft:polished_deepslate
fill 221 126 423 223 127 424 minecraft:iron_block
fill 221 126 429 221 127 430 minecraft:iron_block
fill 221 126 431 221 126 432 minecraft:polished_deepslate
fill 221 126 433 224 127 434 minecraft:iron_block
setblock 221 126 442 minecraft:polished_deepslate
fill 221 126 443 223 128 445 minecraft:iron_block
fill 221 126 450 221 127 451 minecraft:iron_block
fill 221 126 452 221 126 453 minecraft:polished_deepslate
fill 221 126 454 224 127 455 minecraft:iron_block
fill 222 126 419 222 127 419 minecraft:polished_deepslate
fill 222 126 421 229 127 421 minecraft:iron_block
fill 222 126 429 222 127 429 minecraft:polished_deepslate
fill 222 126 430 225 127 432 minecraft:iron_block
setblock 222 126 440 minecraft:polished_deepslate
fill 222 126 442 229 127 442 minecraft:iron_block
fill 222 126 450 222 127 450 minecraft:polished_deepslate
fill 222 126 451 224 127 453 minecraft:iron_block
fill 223 126 417 223 127 417 minecraft:polished_deepslate
fill 223 126 418 226 127 419 minecraft:iron_block
fill 223 126 427 223 127 427 minecraft:polished_deepslate
fill 223 126 428 226 127 429 minecraft:iron_block
fill 223 126 437 223 126 438 minecraft:polished_deepslate
fill 223 126 439 226 127 440 minecraft:iron_block
setblock 223 126 448 minecraft:polished_deepslate
fill 223 126 449 226 127 450 minecraft:iron_block
fill 224 126 417 226 127 417 minecraft:iron_block
fill 224 126 423 228 127 423 minecraft:iron_block
fill 224 126 424 224 127 425 minecraft:polished_deepslate
fill 224 126 426 227 127 427 minecraft:iron_block
fill 224 126 435 224 127 435 minecraft:polished_deepslate
fill 224 126 436 226 127 438 minecraft:iron_block
fill 224 126 443 224 127 444 minecraft:iron_block
fill 224 126 445 224 126 446 minecraft:polished_deepslate
fill 224 126 447 227 127 448 minecraft:iron_block
fill 224 126 456 224 127 456 minecraft:polished_deepslate
fill 224 126 457 227 127 457 minecraft:iron_block
fill 225 126 422 225 127 422 minecraft:polished_deepslate
fill 225 126 424 228 127 425 minecraft:iron_block
fill 225 126 433 225 127 433 minecraft:polished_deepslate
fill 225 126 434 228 127 435 minecraft:iron_block
setblock 225 126 443 minecraft:polished_deepslate
fill 225 126 444 227 127 446 minecraft:iron_block
fill 225 126 451 225 127 452 minecraft:iron_block
fill 225 126 453 225 127 454 minecraft:polished_deepslate
fill 225 126 455 228 127 456 minecraft:iron_block
fill 226 126 420 226 127 420 minecraft:polished_deepslate
fill 226 126 422 229 127 422 minecraft:iron_block
fill 226 126 430 226 127 431 minecraft:polished_deepslate
fill 226 126 432 229 127 433 minecraft:iron_block
fill 226 126 441 226 127 441 minecraft:polished_deepslate
fill 226 126 443 229 127 443 minecraft:iron_block
fill 226 126 451 226 127 452 minecraft:polished_deepslate
fill 226 126 453 229 127 454 minecraft:iron_block
fill 227 126 417 227 127 418 minecraft:polished_deepslate
fill 227 126 419 229 127 420 minecraft:iron_block
fill 227 126 428 227 127 428 minecraft:polished_deepslate
fill 227 126 429 229 127 431 minecraft:iron_block
fill 227 126 436 227 127 437 minecraft:iron_block
fill 227 126 438 227 127 439 minecraft:polished_deepslate
fill 227 126 440 229 127 441 minecraft:iron_block
fill 227 126 449 227 127 449 minecraft:polished_deepslate
fill 227 126 450 229 127 452 minecraft:iron_block
fill 228 126 417 229 127 418 minecraft:iron_block
fill 228 126 426 228 127 426 minecraft:polished_deepslate
fill 228 126 427 229 127 428 minecraft:iron_block
fill 228 126 436 228 127 436 minecraft:polished_deepslate
fill 228 126 437 229 127 439 minecraft:iron_block
fill 228 126 444 228 127 445 minecraft:iron_block
fill 228 126 446 228 127 447 minecraft:polished_deepslate
fill 228 126 448 229 127 449 minecraft:iron_block
fill 228 126 457 228 127 457 minecraft:polished_deepslate
fill 229 126 423 229 127 424 minecraft:polished_deepslate
fill 229 126 425 229 127 426 minecraft:iron_block
fill 229 126 434 229 127 434 minecraft:polished_deepslate
fill 229 126 435 229 127 436 minecraft:iron_block
fill 229 126 444 229 127 445 minecraft:polished_deepslate
fill 229 126 446 229 127 447 minecraft:iron_block
fill 229 126 455 229 127 455 minecraft:polished_deepslate
fill 229 126 456 229 127 457 minecraft:iron_block
setblock 201 127 436 minecraft:polished_deepslate
fill 201 127 437 201 128 437 minecraft:iron_block
fill 201 127 447 201 128 447 minecraft:iron_block
fill 203 127 442 203 128 442 minecraft:iron_block
fill 204 127 440 204 128 440 minecraft:iron_block
fill 205 127 437 205 128 438 minecraft:iron_block
fill 205 127 448 205 128 448 minecraft:iron_block
fill 206 127 435 206 128 435 minecraft:iron_block
fill 206 127 445 210 128 446 minecraft:iron_block
fill 207 127 433 207 128 433 minecraft:iron_block
fill 207 127 443 209 128 444 minecraft:iron_block
fill 208 127 441 208 128 442 minecraft:iron_block
fill 208 127 451 208 128 451 minecraft:iron_block
setblock 208 127 452 minecraft:polished_deepslate
fill 209 127 438 209 128 441 minecraft:iron_block
fill 209 127 442 210 127 442 minecraft:waxed_copper_block
fill 209 127 449 209 128 449 minecraft:iron_block
fill 210 127 436 210 128 439 minecraft:iron_block
fill 210 127 440 210 128 441 minecraft:waxed_copper_block
fill 210 127 443 210 128 444 minecraft:waxed_copper_block
fill 210 127 447 214 128 447 minecraft:iron_block
fill 211 127 434 211 128 434 minecraft:iron_block
fill 211 127 437 212 128 438 minecraft:iron_block
fill 211 127 439 211 127 440 minecraft:waxed_copper_block
fill 211 127 444 211 127 445 minecraft:waxed_copper_block
fill 211 127 446 212 128 446 minecraft:iron_block
setblock 212 127 431 minecraft:polished_deepslate
fill 212 127 432 212 128 432 minecraft:iron_block
fill 212 127 439 215 127 439 minecraft:waxed_copper_block
fill 212 127 445 215 127 445 minecraft:waxed_copper_block
fill 212 127 452 212 128 452 minecraft:iron_block
setblock 212 127 453 minecraft:polished_deepslate
fill 213 127 437 214 128 437 minecraft:iron_block
fill 213 127 438 213 129 438 minecraft:waxed_copper_block
fill 213 127 446 213 129 446 minecraft:waxed_copper_block
fill 213 127 450 213 128 450 minecraft:iron_block
fill 214 127 438 214 128 438 minecraft:iron_block
fill 214 127 446 215 128 446 minecraft:iron_block
fill 214 127 448 214 128 448 minecraft:iron_block
fill 215 127 435 215 128 435 minecraft:iron_block
fill 215 127 440 216 127 440 minecraft:waxed_copper_block
fill 215 127 444 216 127 444 minecraft:waxed_copper_block
fill 216 127 433 216 128 433 minecraft:iron_block
fill 216 127 439 218 128 439 minecraft:iron_block
fill 216 127 441 216 127 443 minecraft:waxed_copper_block
fill 216 127 454 216 128 454 minecraft:iron_block
fill 217 127 440 217 128 441 minecraft:iron_block
fill 217 127 442 217 129 442 minecraft:waxed_copper_block
fill 217 127 443 220 128 444 minecraft:iron_block
fill 217 127 451 217 128 452 minecraft:iron_block
fill 218 127 438 218 128 438 minecraft:iron_block
fill 218 127 440 222 128 440 minecraft:iron_block
fill 218 127 442 221 128 442 minecraft:iron_block
fill 218 127 449 218 128 449 minecraft:iron_block
fill 219 127 436 219 128 436 minecraft:iron_block
fill 219 127 447 219 128 447 minecraft:iron_block
fill 220 127 434 220 128 434 minecraft:iron_block
fill 220 127 445 220 128 445 minecraft:iron_block
setblock 221 127 431 minecraft:polished_deepslate
fill 221 127 432 221 128 432 minecraft:iron_block
fill 221 127 452 221 128 452 minecraft:iron_block
setblock 221 127 453 minecraft:polished_deepslate
fill 223 127 437 223 128 438 minecraft:iron_block
fill 223 127 448 223 128 448 minecraft:iron_block
setblock 224 127 445 minecraft:polished_deepslate
fill 224 127 446 224 128 446 minecraft:iron_block
fill 225 127 443 225 128 443 minecraft:iron_block
fill 200 128 442 202 128 442 minecraft:iron_block
setblock 201 128 441 minecraft:iron_block
setblock 201 128 443 minecraft:iron_block
fill 202 128 436 204 128 438 minecraft:iron_block
fill 202 128 448 204 128 448 minecraft:iron_block
fill 203 128 439 203 128 441 minecraft:iron_block
setblock 204 128 439 minecraft:iron_block
fill 205 128 432 206 128 433 minecraft:iron_block
fill 205 128 449 208 128 449 minecraft:iron_block
fill 205 128 451 206 128 452 minecraft:iron_block
setblock 206 128 434 minecraft:iron_block
fill 206 128 450 208 128 450 minecraft:iron_block
setblock 207 128 451 minecraft:iron_block
fill 208 128 433 211 128 433 minecraft:iron_block
fill 209 128 432 211 128 432 minecraft:iron_block
fill 209 128 442 209 129 442 minecraft:waxed_copper_block
fill 210 128 430 211 128 431 minecraft:iron_block
fill 210 128 453 211 128 454 minecraft:iron_block
fill 211 128 439 212 128 439 minecraft:waxed_copper_block
fill 211 128 445 212 128 445 minecraft:waxed_copper_block
fill 213 128 431 213 128 432 minecraft:iron_block
fill 213 128 451 213 128 453 minecraft:iron_block
fill 214 128 432 217 128 432 minecraft:iron_block
fill 214 128 439 215 128 439 minecraft:waxed_copper_block
fill 214 128 445 215 128 445 minecraft:waxed_copper_block
fill 214 128 451 216 128 452 minecraft:iron_block
fill 215 128 430 216 128 431 minecraft:iron_block
fill 215 128 453 215 128 454 minecraft:iron_block
fill 216 128 440 216 128 441 minecraft:waxed_copper_block
fill 216 128 443 216 128 444 minecraft:waxed_copper_block
setblock 216 128 453 minecraft:iron_block
fill 217 128 433 221 128 433 minecraft:iron_block
fill 218 128 441 223 128 441 minecraft:iron_block
fill 218 128 450 220 128 451 minecraft:iron_block
fill 219 128 448 221 128 449 minecraft:iron_block
setblock 220 128 432 minecraft:iron_block
fill 220 128 435 221 128 436 minecraft:iron_block
setblock 220 128 452 minecraft:iron_block
setblock 221 128 451 minecraft:iron_block
fill 222 128 436 224 128 436 minecraft:iron_block
fill 222 128 442 226 128 442 minecraft:iron_block
setblock 222 128 448 minecraft:iron_block
fill 223 128 439 223 128 440 minecraft:iron_block
fill 224 128 437 224 128 438 minecraft:iron_block
fill 224 128 447 224 128 448 minecraft:iron_block
setblock 225 128 437 minecraft:iron_block
setblock 225 128 441 minecraft:iron_block
setblock 225 128 447 minecraft:iron_block
setblock 191 129 419 minecraft:light[level=13]
setblock 191 129 427 minecraft:light[level=13]
setblock 191 129 435 minecraft:light[level=13]
setblock 191 129 443 minecraft:light[level=13]
setblock 191 129 451 minecraft:light[level=13]
setblock 199 129 419 minecraft:light[level=13]
setblock 199 129 427 minecraft:light[level=13]
setblock 199 129 435 minecraft:light[level=13]
setblock 199 129 443 minecraft:light[level=13]
setblock 199 129 451 minecraft:light[level=13]
fill 206 129 440 206 129 444 minecraft:waxed_oxidized_copper
setblock 207 129 419 minecraft:light[level=13]
setblock 207 129 427 minecraft:light[level=13]
setblock 207 129 435 minecraft:light[level=13]
fill 207 129 438 207 129 439 minecraft:waxed_oxidized_copper
setblock 207 129 443 minecraft:light[level=13]
fill 207 129 445 207 129 446 minecraft:waxed_oxidized_copper
setblock 207 129 451 minecraft:light[level=13]
setblock 208 129 437 minecraft:waxed_oxidized_copper
setblock 208 129 447 minecraft:waxed_oxidized_copper
fill 209 129 436 210 129 436 minecraft:waxed_oxidized_copper
fill 209 129 448 210 129 448 minecraft:waxed_oxidized_copper
setblock 210 129 440 minecraft:waxed_copper_block
setblock 210 129 444 minecraft:waxed_copper_block
fill 211 129 435 215 129 435 minecraft:waxed_oxidized_copper
setblock 211 129 439 minecraft:waxed_copper_block
setblock 211 129 445 minecraft:waxed_copper_block
fill 211 129 449 215 129 449 minecraft:waxed_oxidized_copper
setblock 215 129 419 minecraft:light[level=13]
setblock 215 129 427 minecraft:light[level=13]
setblock 215 129 439 minecraft:waxed_copper_block
setblock 215 129 445 minecraft:waxed_copper_block
setblock 215 129 451 minecraft:light[level=13]
fill 216 129 436 217 129 436 minecraft:waxed_oxidized_copper
setblock 216 129 440 minecraft:waxed_copper_block
setblock 216 129 444 minecraft:waxed_copper_block
fill 216 129 448 217 129 448 minecraft:waxed_oxidized_copper
setblock 218 129 437 minecraft:waxed_oxidized_copper
setblock 218 129 447 minecraft:waxed_oxidized_copper
fill 219 129 438 219 129 439 minecraft:waxed_oxidized_copper
fill 219 129 445 219 129 446 minecraft:waxed_oxidized_copper
fill 220 129 440 220 129 444 minecraft:waxed_oxidized_copper
setblock 223 129 419 minecraft:light[level=13]
setblock 223 129 427 minecraft:light[level=13]
setblock 223 129 435 minecraft:light[level=13]
setblock 223 129 443 minecraft:light[level=13]
setblock 223 129 451 minecraft:light[level=13]
fill 188 131 422 188 131 425 minecraft:shroomlight
fill 188 131 434 188 131 437 minecraft:shroomlight
fill 188 131 446 188 131 449 minecraft:shroomlight
fill 188 131 458 191 131 458 minecraft:shroomlight
fill 189 131 417 191 176 417 minecraft:polished_deepslate
fill 189 131 427 189 176 429 minecraft:polished_deepslate
fill 189 131 439 189 176 441 minecraft:polished_deepslate
fill 189 131 451 189 176 453 minecraft:polished_deepslate
fill 192 131 441 192 134 441 minecraft:iron_block
fill 195 131 416 198 131 416 minecraft:shroomlight
fill 195 131 457 197 176 457 minecraft:polished_deepslate
fill 199 131 420 199 139 420 minecraft:iron_block
fill 200 131 458 203 131 458 minecraft:shroomlight
fill 201 131 417 203 176 417 minecraft:polished_deepslate
fill 207 131 416 210 131 416 minecraft:shroomlight
fill 207 131 457 209 176 457 minecraft:polished_deepslate
fill 212 131 458 215 131 458 minecraft:shroomlight
fill 213 131 417 215 176 417 minecraft:polished_deepslate
fill 214 131 451 214 138 451 minecraft:iron_block
fill 219 131 416 222 131 416 minecraft:shroomlight
fill 219 131 457 221 176 457 minecraft:polished_deepslate
fill 224 131 458 227 131 458 minecraft:shroomlight
fill 225 131 417 227 176 417 minecraft:polished_deepslate
fill 229 131 425 229 176 427 minecraft:polished_deepslate
fill 229 131 437 229 176 439 minecraft:polished_deepslate
fill 229 131 449 229 176 451 minecraft:polished_deepslate
fill 230 131 417 230 131 420 minecraft:shroomlight
fill 230 131 429 230 131 432 minecraft:shroomlight
fill 230 131 441 230 131 444 minecraft:shroomlight
fill 230 131 453 230 131 456 minecraft:shroomlight
fill 188 132 422 188 145 422 minecraft:deepslate
fill 188 132 423 188 132 424 minecraft:shroomlight
fill 188 132 425 188 143 425 minecraft:deepslate
fill 188 132 434 188 145 434 minecraft:deepslate
fill 188 132 435 188 132 436 minecraft:shroomlight
fill 188 132 437 188 145 437 minecraft:deepslate
fill 188 132 446 188 141 446 minecraft:deepslate
fill 188 132 447 188 132 448 minecraft:shroomlight
fill 188 132 449 188 145 449 minecraft:deepslate
fill 188 132 458 188 143 458 minecraft:deepslate
fill 189 132 458 190 132 458 minecraft:shroomlight
fill 191 132 458 191 142 458 minecraft:deepslate
fill 195 132 416 195 145 416 minecraft:deepslate
fill 196 132 416 197 132 416 minecraft:shroomlight
fill 198 132 416 198 145 416 minecraft:deepslate
fill 200 132 458 200 145 458 minecraft:deepslate
fill 201 132 458 202 132 458 minecraft:shroomlight
fill 203 132 458 203 145 458 minecraft:deepslate
fill 207 132 416 207 141 416 minecraft:deepslate
fill 208 132 416 209 132 416 minecraft:shroomlight
fill 210 132 416 210 142 416 minecraft:deepslate
fill 212 132 458 212 145 458 minecraft:deepslate
fill 213 132 458 214 132 458 minecraft:shroomlight
fill 215 132 458 215 141 458 minecraft:deepslate
fill 219 132 416 219 145 416 minecraft:deepslate
fill 220 132 416 221 132 416 minecraft:shroomlight
fill 222 132 416 222 145 416 minecraft:deepslate
fill 224 132 458 224 145 458 minecraft:deepslate
fill 225 132 458 226 132 458 minecraft:shroomlight
fill 227 132 458 227 145 458 minecraft:deepslate
fill 230 132 417 230 141 417 minecraft:deepslate
fill 230 132 418 230 132 419 minecraft:shroomlight
fill 230 132 420 230 145 420 minecraft:deepslate
fill 230 132 429 230 145 429 minecraft:deepslate
fill 230 132 430 230 132 431 minecraft:shroomlight
fill 230 132 432 230 142 432 minecraft:deepslate
fill 230 132 441 230 145 441 minecraft:deepslate
fill 230 132 442 230 132 443 minecraft:shroomlight
fill 230 132 444 230 145 444 minecraft:deepslate
fill 230 132 453 230 145 453 minecraft:deepslate
fill 230 132 454 230 132 455 minecraft:shroomlight
fill 230 132 456 230 145 456 minecraft:deepslate
fill 188 133 423 188 141 424 minecraft:deepslate
fill 188 133 435 188 145 436 minecraft:deepslate
fill 188 133 447 188 145 448 minecraft:deepslate
fill 189 133 458 190 143 458 minecraft:deepslate
fill 196 133 416 197 145 416 minecraft:deepslate
fill 201 133 458 202 145 458 minecraft:deepslate
fill 208 133 416 209 142 416 minecraft:deepslate
fill 213 133 458 214 145 458 minecraft:deepslate
fill 217 133 439 221 134 439 minecraft:waxed_copper_block
fill 217 133 445 221 134 445 minecraft:waxed_copper_block
fill 218 133 438 226 134 438 minecraft:waxed_copper_block
fill 218 133 440 218 134 444 minecraft:waxed_copper_block
fill 218 133 446 226 134 446 minecraft:waxed_copper_block
fill 219 133 437 225 134 437 minecraft:waxed_copper_block
fill 219 133 440 219 134 441 minecraft:waxed_copper_block
fill 219 133 443 219 134 444 minecraft:waxed_copper_block
fill 219 133 447 225 134 447 minecraft:waxed_copper_block
fill 220 133 416 221 143 416 minecraft:deepslate
fill 222 133 436 222 134 436 minecraft:waxed_copper_block
fill 222 133 448 222 134 448 minecraft:waxed_copper_block
fill 223 133 439 227 134 439 minecraft:waxed_copper_block
fill 223 133 445 227 134 445 minecraft:waxed_copper_block
fill 225 133 440 227 134 441 minecraft:waxed_copper_block
fill 225 133 443 227 134 444 minecraft:waxed_copper_block
fill 225 133 458 226 141 458 minecraft:deepslate
fill 226 133 442 228 134 442 minecraft:waxed_copper_block
fill 230 133 418 230 145 419 minecraft:deepslate
fill 230 133 430 230 145 431 minecraft:deepslate
fill 230 133 442 230 141 443 minecraft:deepslate
fill 230 133 454 230 145 455 minecraft:deepslate
setblock 191 137 419 minecraft:light[level=13]
setblock 191 137 427 minecraft:light[level=13]
setblock 191 137 435 minecraft:light[level=13]
setblock 191 137 443 minecraft:light[level=13]
setblock 191 137 451 minecraft:light[level=13]
fill 195 137 450 195 147 450 minecraft:iron_block
setblock 199 137 419 minecraft:light[level=13]
setblock 199 137 427 minecraft:light[level=13]
setblock 199 137 435 minecraft:light[level=13]
setblock 199 137 443 minecraft:light[level=13]
setblock 199 137 451 minecraft:light[level=13]
setblock 207 137 419 minecraft:light[level=13]
setblock 207 137 427 minecraft:light[level=13]
setblock 207 137 435 minecraft:light[level=13]
setblock 207 137 443 minecraft:light[level=13]
setblock 207 137 451 minecraft:light[level=13]
setblock 215 137 419 minecraft:light[level=13]
setblock 215 137 427 minecraft:light[level=13]
setblock 215 137 435 minecraft:light[level=13]
setblock 215 137 443 minecraft:light[level=13]
setblock 215 137 451 minecraft:light[level=13]
setblock 223 137 419 minecraft:light[level=13]
setblock 223 137 427 minecraft:light[level=13]
setblock 223 137 435 minecraft:light[level=13]
setblock 223 137 443 minecraft:light[level=13]
setblock 223 137 451 minecraft:light[level=13]
fill 207 138 454 207 139 456 minecraft:iron_block
fill 190 140 426 190 145 428 minecraft:polished_deepslate
fill 190 140 438 190 145 440 minecraft:polished_deepslate
fill 190 140 450 190 145 452 minecraft:polished_deepslate
fill 196 140 456 198 145 456 minecraft:polished_deepslate
fill 200 140 418 202 145 418 minecraft:polished_deepslate
fill 208 140 456 210 145 456 minecraft:polished_deepslate
fill 212 140 418 214 145 418 minecraft:polished_deepslate
fill 220 140 456 222 145 456 minecraft:polished_deepslate
fill 224 140 418 226 145 418 minecraft:polished_deepslate
fill 228 140 426 228 145 428 minecraft:polished_deepslate
fill 228 140 438 228 145 440 minecraft:polished_deepslate
fill 228 140 450 228 145 452 minecraft:polished_deepslate
setblock 188 142 416 minecraft:polished_andesite
fill 188 142 423 188 145 423 minecraft:deepslate
setblock 188 142 424 minecraft:polished_andesite
fill 188 142 426 188 145 426 minecraft:deepslate
setblock 188 142 427 minecraft:polished_andesite
setblock 188 142 433 minecraft:polished_andesite
setblock 188 142 441 minecraft:polished_andesite
setblock 188 142 446 minecraft:polished_andesite
fill 192 142 458 193 142 458 minecraft:polished_andesite
fill 194 142 458 194 145 458 minecraft:deepslate
setblock 207 142 416 minecraft:polished_andesite
fill 208 142 458 209 142 458 minecraft:polished_andesite
setblock 210 142 458 minecraft:deepslate
setblock 211 142 458 minecraft:polished_andesite
setblock 215 142 458 minecraft:polished_andesite
setblock 225 142 458 minecraft:polished_andesite
setblock 226 142 458 minecraft:deepslate
fill 228 142 458 228 143 458 minecraft:polished_andesite
fill 230 142 416 230 142 417 minecraft:polished_andesite
setblock 230 142 433 minecraft:polished_andesite
fill 230 142 434 230 142 437 minecraft:deepslate
setblock 230 142 438 minecraft:polished_andesite
fill 230 142 439 230 142 440 minecraft:deepslate
fill 230 142 442 230 143 442 minecraft:polished_andesite
fill 230 142 443 230 145 443 minecraft:deepslate
fill 188 143 416 189 145 416 minecraft:deepslate
fill 188 143 424 188 145 424 minecraft:deepslate
fill 188 143 427 188 145 427 minecraft:deepslate
fill 188 143 428 188 143 429 minecraft:polished_andesite
fill 188 143 430 188 145 433 minecraft:deepslate
setblock 188 143 441 minecraft:deepslate
setblock 188 143 445 minecraft:polished_andesite
fill 188 143 446 188 145 446 minecraft:deepslate
setblock 188 143 450 minecraft:polished_andesite
fill 188 143 451 188 145 456 minecraft:deepslate
setblock 190 143 416 minecraft:polished_andesite
fill 191 143 416 191 145 416 minecraft:deepslate
fill 191 143 458 191 144 458 minecraft:polished_andesite
fill 192 143 458 193 145 458 minecraft:deepslate
fill 200 143 416 202 143 416 minecraft:deepslate
setblock 203 143 416 minecraft:polished_andesite
fill 207 143 416 208 145 416 minecraft:deepslate
setblock 208 143 458 minecraft:polished_andesite
fill 209 143 416 211 143 416 minecraft:polished_andesite
fill 209 143 458 209 145 458 minecraft:deepslate
setblock 210 143 458 minecraft:polished_andesite
fill 211 143 458 211 146 458 minecraft:deepslate
fill 212 143 416 212 145 416 minecraft:deepslate
fill 215 143 458 215 145 458 minecraft:deepslate
setblock 220 143 458 minecraft:polished_andesite
fill 221 143 458 222 145 458 minecraft:deepslate
fill 225 143 458 225 145 458 minecraft:deepslate
setblock 226 143 458 minecraft:polished_andesite
fill 228 143 416 228 145 416 minecraft:deepslate
setblock 229 143 416 minecraft:polished_andesite
fill 230 143 416 230 145 417 minecraft:deepslate
fill 230 143 421 230 143 422 minecraft:polished_andesite
setblock 230 143 432 minecraft:polished_andesite
fill 230 143 433 230 145 433 minecraft:deepslate
setblock 230 143 434 minecraft:polished_andesite
fill 230 143 435 230 143 439 minecraft:deepslate
setblock 230 143 440 minecraft:polished_andesite
setblock 230 143 457 minecraft:polished_andesite
fill 230 143 458 230 146 458 minecraft:deepslate
setblock 188 144 425 minecraft:polished_andesite
fill 188 144 428 188 145 429 minecraft:deepslate
setblock 188 144 438 minecraft:polished_andesite
fill 188 144 439 188 146 439 minecraft:deepslate
setblock 188 144 441 minecraft:polished_andesite
fill 188 144 445 188 145 445 minecraft:deepslate
fill 188 144 450 188 145 450 minecraft:deepslate
setblock 188 144 458 minecraft:polished_andesite
fill 189 144 458 189 145 458 minecraft:deepslate
fill 190 144 416 190 145 416 minecraft:deepslate
setblock 190 144 458 minecraft:polished_andesite
setblock 196 144 458 minecraft:polished_andesite
fill 197 144 458 199 145 458 minecraft:deepslate
setblock 200 144 416 minecraft:polished_andesite
fill 201 144 416 203 145 416 minecraft:deepslate
fill 208 144 458 208 145 458 minecraft:deepslate
fill 209 144 416 211 145 416 minecraft:deepslate
fill 210 144 458 210 145 458 minecraft:deepslate
fill 215 144 416 217 145 416 minecraft:deepslate
setblock 218 144 416 minecraft:polished_andesite
fill 220 144 416 220 145 416 minecraft:deepslate
fill 220 144 458 220 145 458 minecraft:deepslate
setblock 221 144 416 minecraft:polished_andesite
fill 224 144 430 227 176 430 minecraft:polished_deepslate
fill 225 144 429 226 176 429 minecraft:polished_deepslate
fill 225 144 431 226 176 431 minecraft:polished_deepslate
fill 226 144 458 226 145 458 minecraft:deepslate
fill 228 144 458 228 145 458 minecraft:deepslate
fill 229 144 416 229 146 416 minecraft:deepslate
fill 230 144 421 230 145 421 minecraft:deepslate
setblock 230 144 422 minecraft:polished_andesite
fill 230 144 432 230 145 432 minecraft:deepslate
fill 230 144 434 230 145 434 minecraft:deepslate
setblock 230 144 435 minecraft:polished_andesite
fill 230 144 436 230 145 437 minecraft:deepslate
setblock 230 144 438 minecraft:polished_andesite
fill 230 144 439 230 145 440 minecraft:deepslate
fill 230 144 442 230 145 442 minecraft:deepslate
setblock 230 144 445 minecraft:polished_andesite
fill 230 144 446 230 145 447 minecraft:deepslate
fill 230 144 457 230 145 457 minecraft:deepslate
fill 188 145 425 189 145 425 minecraft:deepslate
setblock 188 145 438 minecraft:deepslate
setblock 188 145 441 minecraft:deepslate
setblock 188 145 458 minecraft:deepslate
fill 189 145 420 189 145 424 minecraft:deepslate
fill 189 145 432 189 145 437 minecraft:deepslate
fill 189 145 444 189 145 449 minecraft:deepslate
fill 189 145 456 189 145 457 minecraft:deepslate
fill 190 145 457 191 145 458 minecraft:deepslate
setblock 191 145 419 minecraft:light[level=13]
setblock 191 145 427 minecraft:light[level=13]
setblock 191 145 435 minecraft:light[level=13]
setblock 191 145 443 minecraft:light[level=13]
setblock 191 145 451 minecraft:light[level=13]
fill 192 145 457 193 145 457 minecraft:deepslate
fill 193 145 417 198 145 417 minecraft:deepslate
fill 196 145 458 196 146 458 minecraft:deepslate
setblock 199 145 419 minecraft:light[level=13]
setblock 199 145 427 minecraft:light[level=13]
setblock 199 145 435 minecraft:light[level=13]
setblock 199 145 443 minecraft:light[level=13]
setblock 199 145 451 minecraft:light[level=13]
setblock 200 145 416 minecraft:deepslate
fill 200 145 457 205 145 457 minecraft:deepslate
fill 205 145 417 210 145 417 minecraft:deepslate
setblock 207 145 419 minecraft:light[level=13]
setblock 207 145 427 minecraft:light[level=13]
setblock 207 145 435 minecraft:light[level=13]
setblock 207 145 443 minecraft:light[level=13]
setblock 207 145 451 minecraft:light[level=13]
fill 212 145 457 217 145 457 minecraft:deepslate
setblock 215 145 419 minecraft:light[level=13]
setblock 215 145 427 minecraft:light[level=13]
setblock 215 145 435 minecraft:light[level=13]
setblock 215 145 443 minecraft:light[level=13]
setblock 215 145 451 minecraft:light[level=13]
fill 217 145 417 222 145 417 minecraft:deepslate
setblock 218 145 416 minecraft:deepslate
setblock 221 145 416 minecraft:deepslate
setblock 223 145 419 minecraft:light[level=13]
setblock 223 145 427 minecraft:light[level=13]
setblock 223 145 435 minecraft:light[level=13]
setblock 223 145 443 minecraft:light[level=13]
setblock 223 145 451 minecraft:light[level=13]
fill 224 145 429 224 146 429 minecraft:deepslate
fill 224 145 431 224 146 431 minecraft:deepslate
fill 224 145 457 229 145 457 minecraft:deepslate
fill 225 145 432 226 146 432 minecraft:deepslate
fill 227 145 429 227 146 429 minecraft:deepslate
fill 227 145 431 227 146 431 minecraft:deepslate
fill 229 145 417 229 145 422 minecraft:deepslate
fill 229 145 429 229 145 434 minecraft:deepslate
fill 229 145 441 229 145 446 minecraft:deepslate
fill 229 145 453 229 145 456 minecraft:deepslate
setblock 230 145 422 minecraft:deepslate
setblock 230 145 435 minecraft:deepslate
setblock 230 145 438 minecraft:deepslate
setblock 230 145 445 minecraft:deepslate
fill 188 146 416 188 146 420 minecraft:polished_andesite
setblock 188 146 421 minecraft:deepslate
fill 188 146 422 188 151 425 minecraft:shroomlight
fill 188 146 426 188 226 428 minecraft:polished_andesite
setblock 188 146 429 minecraft:deepslate
fill 188 146 430 188 147 433 minecraft:polished_andesite
fill 188 146 434 188 151 437 minecraft:shroomlight
fill 188 146 438 188 147 438 minecraft:polished_andesite
fill 188 146 440 188 147 445 minecraft:polished_andesite
fill 188 146 446 188 151 449 minecraft:shroomlight
fill 188 146 450 188 223 451 minecraft:polished_andesite
setblock 188 146 452 minecraft:deepslate
fill 188 146 453 188 146 457 minecraft:polished_andesite
fill 188 146 458 191 151 458 minecraft:shroomlight
fill 189 146 416 192 222 416 minecraft:polished_andesite
fill 192 146 458 195 147 458 minecraft:polished_andesite
fill 193 146 416 193 147 416 minecraft:deepslate
fill 195 146 416 198 151 416 minecraft:shroomlight
fill 197 146 458 199 147 458 minecraft:polished_andesite
fill 199 146 416 206 223 416 minecraft:polished_andesite
fill 200 146 458 203 151 458 minecraft:shroomlight
fill 204 146 458 204 147 458 minecraft:deepslate
fill 205 146 458 210 146 458 minecraft:polished_andesite
fill 207 146 416 210 151 416 minecraft:shroomlight
fill 211 146 416 215 146 416 minecraft:polished_andesite
fill 212 146 458 215 151 458 minecraft:shroomlight
setblock 216 146 416 minecraft:deepslate
fill 216 146 458 223 224 458 minecraft:polished_andesite
fill 217 146 416 218 147 416 minecraft:polished_andesite
fill 219 146 416 222 151 416 minecraft:shroomlight
fill 223 146 416 228 146 416 minecraft:polished_andesite
fill 223 146 429 223 146 431 minecraft:deepslate
fill 224 146 428 227 146 428 minecraft:deepslate
setblock 224 146 432 minecraft:deepslate
fill 224 146 458 227 151 458 minecraft:shroomlight
fill 225 146 433 226 146 433 minecraft:deepslate
setblock 227 146 432 minecraft:deepslate
fill 228 146 429 228 146 431 minecraft:deepslate
fill 228 146 458 228 226 458 minecraft:polished_andesite
fill 230 146 416 230 224 416 minecraft:polished_andesite
fill 230 146 417 230 151 420 minecraft:shroomlight
fill 230 146 421 230 226 422 minecraft:polished_andesite
fill 230 146 424 230 224 428 minecraft:polished_andesite
fill 230 146 429 230 151 432 minecraft:shroomlight
fill 230 146 433 230 146 440 minecraft:polished_andesite
fill 230 146 441 230 151 444 minecraft:shroomlight
fill 230 146 445 230 147 452 minecraft:polished_andesite
fill 230 146 453 230 151 456 minecraft:shroomlight
fill 230 146 457 230 226 457 minecraft:polished_andesite
fill 188 147 416 188 224 418 minecraft:polished_andesite
setblock 188 147 419 minecraft:deepslate
fill 188 147 420 188 224 421 minecraft:polished_andesite
fill 188 147 429 188 227 429 minecraft:polished_andesite
fill 188 147 439 188 223 439 minecraft:polished_andesite
fill 188 147 452 188 226 452 minecraft:polished_andesite
setblock 188 147 453 minecraft:deepslate
fill 188 147 454 188 226 456 minecraft:polished_andesite
setblock 188 147 457 minecraft:deepslate
fill 194 147 416 194 226 416 minecraft:polished_andesite
setblock 196 147 458 minecraft:polished_andesite
fill 205 147 458 208 147 458 minecraft:polished_andesite
setblock 209 147 458 minecraft:deepslate
fill 210 147 458 211 222 458 minecraft:polished_andesite
setblock 211 147 416 minecraft:deepslate
fill 212 147 416 213 226 416 minecraft:polished_andesite
setblock 214 147 416 minecraft:deepslate
fill 215 147 416 216 147 416 minecraft:polished_andesite
fill 223 147 416 225 222 416 minecraft:polished_andesite
setblock 226 147 416 minecraft:deepslate
fill 227 147 416 229 147 416 minecraft:polished_andesite
fill 229 147 458 230 147 458 minecraft:polished_andesite
fill 230 147 423 230 227 423 minecraft:polished_andesite
fill 230 147 433 230 226 433 minecraft:polished_andesite
setblock 230 147 434 minecraft:deepslate
fill 230 147 435 230 227 435 minecraft:polished_andesite
setblock 230 147 436 minecraft:deepslate
fill 230 147 437 230 222 439 minecraft:polished_andesite
setblock 230 147 440 minecraft:deepslate
fill 188 148 419 188 226 419 minecraft:polished_andesite
setblock 188 148 430 minecraft:deepslate
fill 188 148 431 188 226 433 minecraft:polished_andesite
setblock 188 148 438 minecraft:deepslate
fill 188 148 440 188 222 444 minecraft:polished_andesite
setblock 188 148 445 minecraft:deepslate
fill 188 148 453 188 222 453 minecraft:polished_andesite
fill 188 148 457 188 226 457 minecraft:polished_andesite
fill 192 148 458 194 226 458 minecraft:polished_andesite
fill 193 148 416 193 226 416 minecraft:polished_andesite
fill 195 148 458 196 148 458 minecraft:deepslate
fill 197 148 458 197 226 458 minecraft:polished_andesite
setblock 198 148 458 minecraft:deepslate
fill 199 148 458 199 226 458 minecraft:polished_andesite
fill 204 148 458 206 223 458 minecraft:polished_andesite
setblock 207 148 458 minecraft:deepslate
fill 208 148 458 209 223 458 minecraft:polished_andesite
fill 211 148 416 211 223 416 minecraft:polished_andesite
fill 214 148 416 215 226 416 minecraft:polished_andesite
setblock 216 148 416 minecraft:deepslate
fill 217 148 416 217 226 416 minecraft:polished_andesite
setblock 218 148 416 minecraft:deepslate
fill 226 148 416 228 224 416 minecraft:polished_andesite
fill 226 148 440 228 149 440 minecraft:iron_block
fill 227 148 446 227 161 446 minecraft:red_wool
setblock 229 148 416 minecraft:deepslate
fill 229 148 458 229 226 458 minecraft:polished_andesite
fill 230 148 434 230 226 434 minecraft:polished_andesite
fill 230 148 436 230 226 436 minecraft:polished_andesite
fill 230 148 440 230 222 440 minecraft:polished_andesite
setblock 230 148 445 minecraft:deepslate
fill 230 148 446 230 222 452 minecraft:polished_andesite
setblock 230 148 458 minecraft:deepslate
fill 188 149 430 188 226 430 minecraft:polished_andesite
fill 188 149 438 188 222 438 minecraft:polished_andesite
fill 188 149 445 188 226 445 minecraft:polished_andesite
fill 195 149 458 196 224 458 minecraft:polished_andesite
fill 198 149 458 198 226 458 minecraft:polished_andesite
fill 207 149 458 207 226 458 minecraft:polished_andesite
fill 216 149 416 216 223 416 minecraft:polished_andesite
fill 218 149 416 218 226 416 minecraft:polished_andesite
fill 227 149 444 227 161 445 minecraft:red_wool
fill 227 149 447 227 161 448 minecraft:red_wool
fill 229 149 416 229 224 416 minecraft:polished_andesite
fill 230 149 445 230 227 445 minecraft:polished_andesite
fill 230 149 458 230 226 458 minecraft:polished_andesite
fill 188 152 422 188 165 422 minecraft:polished_andesite
fill 188 152 423 188 152 424 minecraft:shroomlight
fill 188 152 425 188 165 425 minecraft:polished_andesite
fill 188 152 434 188 165 434 minecraft:polished_andesite
fill 188 152 435 188 152 436 minecraft:shroomlight
fill 188 152 437 188 165 437 minecraft:polished_andesite
fill 188 152 446 188 165 446 minecraft:polished_andesite
fill 188 152 447 188 152 448 minecraft:shroomlight
fill 188 152 449 188 165 449 minecraft:polished_andesite
fill 188 152 458 188 165 458 minecraft:polished_andesite
fill 189 152 458 190 152 458 minecraft:shroomlight
fill 191 152 458 191 165 458 minecraft:polished_andesite
fill 195 152 416 195 165 416 minecraft:polished_andesite
fill 196 152 416 197 152 416 minecraft:shroomlight
fill 198 152 416 198 165 416 minecraft:polished_andesite
fill 200 152 458 200 165 458 minecraft:polished_andesite
fill 201 152 458 202 152 458 minecraft:shroomlight
fill 203 152 458 203 165 458 minecraft:polished_andesite
fill 207 152 416 207 165 416 minecraft:polished_andesite
fill 208 152 416 209 152 416 minecraft:shroomlight
fill 210 152 416 210 165 416 minecraft:polished_andesite
fill 212 152 458 212 165 458 minecraft:polished_andesite
fill 213 152 458 214 152 458 minecraft:shroomlight
fill 215 152 458 215 165 458 minecraft:polished_andesite
fill 219 152 416 219 165 416 minecraft:polished_andesite
fill 220 152 416 221 152 416 minecraft:shroomlight
fill 222 152 416 222 165 416 minecraft:polished_andesite
fill 224 152 458 224 165 458 minecraft:polished_andesite
fill 225 152 458 226 152 458 minecraft:shroomlight
fill 227 152 458 227 165 458 minecraft:polished_andesite
fill 230 152 417 230 165 417 minecraft:polished_andesite
fill 230 152 418 230 152 419 minecraft:shroomlight
fill 230 152 420 230 165 420 minecraft:polished_andesite
fill 230 152 429 230 165 429 minecraft:polished_andesite
fill 230 152 430 230 152 431 minecraft:shroomlight
fill 230 152 432 230 165 432 minecraft:polished_andesite
fill 230 152 441 230 165 441 minecraft:polished_andesite
fill 230 152 442 230 152 443 minecraft:shroomlight
fill 230 152 444 230 165 444 minecraft:polished_andesite
fill 230 152 453 230 165 453 minecraft:polished_andesite
fill 230 152 454 230 152 455 minecraft:shroomlight
fill 230 152 456 230 165 456 minecraft:polished_andesite
fill 188 153 423 188 165 424 minecraft:polished_andesite
fill 188 153 435 188 165 436 minecraft:polished_andesite
fill 188 153 447 188 165 448 minecraft:polished_andesite
fill 189 153 458 190 165 458 minecraft:polished_andesite
setblock 191 153 419 minecraft:light[level=13]
setblock 191 153 427 minecraft:light[level=13]
setblock 191 153 435 minecraft:light[level=13]
setblock 191 153 443 minecraft:light[level=13]
setblock 191 153 451 minecraft:light[level=13]
fill 196 153 416 197 165 416 minecraft:polished_andesite
setblock 199 153 419 minecraft:light[level=13]
setblock 199 153 427 minecraft:light[level=13]
setblock 199 153 435 minecraft:light[level=13]
setblock 199 153 443 minecraft:light[level=13]
setblock 199 153 451 minecraft:light[level=13]
fill 201 153 458 202 165 458 minecraft:polished_andesite
setblock 207 153 419 minecraft:light[level=13]
setblock 207 153 427 minecraft:light[level=13]
setblock 207 153 435 minecraft:light[level=13]
setblock 207 153 443 minecraft:light[level=13]
setblock 207 153 451 minecraft:light[level=13]
fill 208 153 416 209 165 416 minecraft:polished_andesite
fill 213 153 458 214 165 458 minecraft:polished_andesite
setblock 215 153 419 minecraft:light[level=13]
setblock 215 153 427 minecraft:light[level=13]
setblock 215 153 435 minecraft:light[level=13]
setblock 215 153 443 minecraft:light[level=13]
setblock 215 153 451 minecraft:light[level=13]
fill 220 153 416 221 165 416 minecraft:polished_andesite
setblock 223 153 419 minecraft:light[level=13]
setblock 223 153 427 minecraft:light[level=13]
setblock 223 153 435 minecraft:light[level=13]
setblock 223 153 443 minecraft:light[level=13]
setblock 223 153 451 minecraft:light[level=13]
fill 225 153 458 226 165 458 minecraft:polished_andesite
fill 230 153 418 230 165 419 minecraft:polished_andesite
fill 230 153 430 230 165 431 minecraft:polished_andesite
fill 230 153 442 230 165 443 minecraft:polished_andesite
fill 230 153 454 230 165 455 minecraft:polished_andesite
fill 190 160 426 190 165 428 minecraft:polished_deepslate
fill 190 160 438 190 165 440 minecraft:polished_deepslate
fill 190 160 450 190 165 452 minecraft:polished_deepslate
fill 196 160 456 198 165 456 minecraft:polished_deepslate
fill 200 160 418 202 165 418 minecraft:polished_deepslate
fill 208 160 456 210 165 456 minecraft:polished_deepslate
fill 212 160 418 214 165 418 minecraft:polished_deepslate
fill 220 160 456 222 165 456 minecraft:polished_deepslate
fill 224 160 418 226 165 418 minecraft:polished_deepslate
fill 228 160 426 228 165 428 minecraft:polished_deepslate
fill 228 160 438 228 165 440 minecraft:polished_deepslate
fill 228 160 450 228 165 452 minecraft:polished_deepslate
setblock 191 161 419 minecraft:light[level=13]
setblock 191 161 427 minecraft:light[level=13]
setblock 191 161 435 minecraft:light[level=13]
setblock 191 161 443 minecraft:light[level=13]
setblock 191 161 451 minecraft:light[level=13]
setblock 199 161 419 minecraft:light[level=13]
setblock 199 161 427 minecraft:light[level=13]
setblock 199 161 435 minecraft:light[level=13]
setblock 199 161 443 minecraft:light[level=13]
setblock 199 161 451 minecraft:light[level=13]
setblock 207 161 419 minecraft:light[level=13]
setblock 207 161 427 minecraft:light[level=13]
setblock 207 161 435 minecraft:light[level=13]
setblock 207 161 443 minecraft:light[level=13]
setblock 207 161 451 minecraft:light[level=13]
setblock 215 161 419 minecraft:light[level=13]
setblock 215 161 427 minecraft:light[level=13]
setblock 215 161 435 minecraft:light[level=13]
setblock 215 161 443 minecraft:light[level=13]
setblock 215 161 451 minecraft:light[level=13]
setblock 223 161 419 minecraft:light[level=13]
setblock 223 161 427 minecraft:light[level=13]
setblock 223 161 435 minecraft:light[level=13]
setblock 223 161 443 minecraft:light[level=13]
setblock 223 161 451 minecraft:light[level=13]
fill 227 162 443 227 163 449 minecraft:iron_block
fill 189 165 420 189 165 425 minecraft:deepslate
fill 189 165 432 189 165 437 minecraft:deepslate
fill 189 165 444 189 165 449 minecraft:deepslate
fill 189 165 456 189 165 457 minecraft:deepslate
fill 190 165 457 193 165 457 minecraft:deepslate
fill 193 165 417 198 165 417 minecraft:deepslate
fill 200 165 457 205 165 457 minecraft:deepslate
fill 205 165 417 210 165 417 minecraft:deepslate
fill 212 165 457 217 165 457 minecraft:deepslate
fill 217 165 417 222 165 417 minecraft:deepslate
fill 224 165 457 229 165 457 minecraft:deepslate
fill 229 165 417 229 165 422 minecraft:deepslate
fill 229 165 429 229 165 434 minecraft:deepslate
fill 229 165 441 229 165 446 minecraft:deepslate
fill 229 165 453 229 165 456 minecraft:deepslate
fill 188 166 422 188 171 425 minecraft:shroomlight
fill 188 166 434 188 171 437 minecraft:shroomlight
fill 188 166 446 188 171 449 minecraft:shroomlight
fill 188 166 458 191 171 458 minecraft:shroomlight
fill 195 166 416 198 171 416 minecraft:shroomlight
fill 200 166 458 203 171 458 minecraft:shroomlight
fill 206 166 454 206 167 456 minecraft:iron_block
fill 207 166 416 210 171 416 minecraft:shroomlight
fill 212 166 458 215 171 458 minecraft:shroomlight
fill 219 166 416 222 171 416 minecraft:shroomlight
fill 224 166 458 227 171 458 minecraft:shroomlight
fill 230 166 417 230 171 420 minecraft:shroomlight
fill 230 166 429 230 171 432 minecraft:shroomlight
fill 230 166 441 230 171 444 minecraft:shroomlight
fill 230 166 453 230 171 456 minecraft:shroomlight
fill 190 167 439 192 169 441 minecraft:iron_block
fill 191 167 438 191 169 438 minecraft:iron_block
fill 191 167 442 191 169 442 minecraft:iron_block
fill 193 167 440 193 169 440 minecraft:iron_block
fill 225 167 440 229 169 440 minecraft:iron_block
fill 226 167 439 228 169 439 minecraft:iron_block
fill 226 167 441 228 169 441 minecraft:iron_block
fill 227 167 438 227 169 438 minecraft:iron_block
fill 227 167 442 227 169 442 minecraft:iron_block
fill 189 168 438 190 169 438 minecraft:iron_block
fill 189 168 442 190 169 442 minecraft:iron_block
fill 190 168 437 192 170 437 minecraft:iron_block
fill 190 168 443 192 170 443 minecraft:iron_block
fill 192 168 438 193 169 438 minecraft:iron_block
fill 192 168 442 193 169 442 minecraft:iron_block
fill 193 168 439 194 169 439 minecraft:iron_block
fill 193 168 441 194 169 441 minecraft:iron_block
fill 194 168 440 194 170 440 minecraft:iron_block
fill 224 168 439 224 170 441 minecraft:iron_block
fill 225 168 438 225 169 439 minecraft:iron_block
fill 225 168 441 225 169 442 minecraft:iron_block
fill 226 168 437 226 169 438 minecraft:iron_block
fill 226 168 442 226 169 443 minecraft:iron_block
fill 227 168 437 228 170 437 minecraft:iron_block
fill 227 168 443 228 170 443 minecraft:iron_block
fill 228 168 438 228 169 438 minecraft:iron_block
fill 228 168 442 229 169 442 minecraft:iron_block
fill 229 168 441 229 169 441 minecraft:iron_block
fill 189 169 437 189 171 437 minecraft:iron_block
fill 189 169 443 189 171 443 minecraft:iron_block
fill 190 169 436 192 172 436 minecraft:iron_block
fill 190 169 444 192 172 444 minecraft:iron_block
setblock 191 169 419 minecraft:light[level=13]
setblock 191 169 427 minecraft:light[level=13]
setblock 191 169 435 minecraft:light[level=13]
setblock 191 169 451 minecraft:light[level=13]
fill 193 169 437 194 171 437 minecraft:iron_block
fill 193 169 443 194 171 443 minecraft:iron_block
fill 194 169 438 194 171 438 minecraft:iron_block
fill 194 169 442 194 171 442 minecraft:iron_block
fill 195 169 439 195 172 441 minecraft:iron_block
setblock 199 169 419 minecraft:light[level=13]
setblock 199 169 427 minecraft:light[level=13]
setblock 199 169 435 minecraft:light[level=13]
setblock 199 169 443 minecraft:light[level=13]
setblock 199 169 451 minecraft:light[level=13]
setblock 207 169 419 minecraft:light[level=13]
setblock 207 169 427 minecraft:light[level=13]
setblock 207 169 435 minecraft:light[level=13]
setblock 207 169 443 minecraft:light[level=13]
setblock 207 169 451 minecraft:light[level=13]
setblock 215 169 419 minecraft:light[level=13]
setblock 215 169 427 minecraft:light[level=13]
setblock 215 169 435 minecraft:light[level=13]
setblock 215 169 443 minecraft:light[level=13]
setblock 215 169 451 minecraft:light[level=13]
setblock 223 169 419 minecraft:light[level=13]
setblock 223 169 427 minecraft:light[level=13]
setblock 223 169 435 minecraft:light[level=13]
fill 223 169 439 223 172 441 minecraft:iron_block
setblock 223 169 443 minecraft:light[level=13]
setblock 223 169 451 minecraft:light[level=13]
fill 224 169 437 224 171 438 minecraft:iron_block
fill 224 169 442 224 171 443 minecraft:iron_block
fill 225 169 437 225 171 437 minecraft:iron_block
fill 225 169 443 225 171 443 minecraft:iron_block
fill 226 169 436 228 172 436 minecraft:iron_block
fill 226 169 444 228 172 444 minecraft:iron_block
fill 229 169 443 229 171 443 minecraft:iron_block
fill 189 170 436 189 173 436 minecraft:iron_block
setblock 189 170 438 minecraft:iron_block
setblock 189 170 442 minecraft:iron_block
fill 189 170 444 189 173 444 minecraft:iron_block
fill 190 170 438 192 176 442 minecraft:polished_deepslate
fill 193 170 436 193 173 436 minecraft:iron_block
setblock 193 170 438 minecraft:iron_block
fill 193 170 439 193 176 441 minecraft:polished_deepslate
setblock 193 170 442 minecraft:iron_block
fill 193 170 444 193 173 444 minecraft:iron_block
setblock 194 170 439 minecraft:iron_block
setblock 194 170 441 minecraft:iron_block
fill 195 170 438 195 173 438 minecraft:iron_block
fill 195 170 442 195 173 442 minecraft:iron_block
fill 223 170 438 223 173 438 minecraft:iron_block
fill 223 170 442 223 173 442 minecraft:iron_block
fill 225 170 436 225 173 436 minecraft:iron_block
setblock 225 170 438 minecraft:iron_block
fill 225 170 439 228 176 441 minecraft:polished_deepslate
setblock 225 170 442 minecraft:iron_block
fill 225 170 444 225 173 444 minecraft:iron_block
setblock 226 170 437 minecraft:iron_block
fill 226 170 438 228 176 438 minecraft:polished_deepslate
fill 226 170 442 228 176 442 minecraft:polished_deepslate
setblock 226 170 443 minecraft:iron_block
fill 229 170 436 229 173 436 minecraft:iron_block
fill 229 170 440 229 176 441 minecraft:polished_deepslate
setblock 229 170 442 minecraft:iron_block
fill 229 170 444 229 173 444 minecraft:iron_block
fill 189 171 438 189 176 438 minecraft:polished_deepslate
fill 189 171 442 189 176 442 minecraft:polished_deepslate
fill 190 171 437 192 176 437 minecraft:polished_deepslate
fill 190 171 443 192 176 443 minecraft:polished_deepslate
fill 193 171 438 193 176 438 minecraft:polished_deepslate
fill 193 171 442 193 176 442 minecraft:polished_deepslate
fill 194 171 439 194 176 441 minecraft:polished_deepslate
fill 224 171 439 224 176 441 minecraft:polished_deepslate
fill 225 171 438 225 176 438 minecraft:polished_deepslate
fill 225 171 442 225 176 442 minecraft:polished_deepslate
fill 226 171 437 228 176 437 minecraft:polished_deepslate
fill 226 171 443 228 176 443 minecraft:polished_deepslate
fill 227 171 421 229 174 423 minecraft:orange_stained_glass
fill 229 171 442 229 176 442 minecraft:polished_deepslate
fill 188 172 422 188 205 422 minecraft:polished_andesite
fill 188 172 423 188 172 424 minecraft:shroomlight
fill 188 172 425 188 205 425 minecraft:polished_andesite
fill 188 172 434 188 205 434 minecraft:polished_andesite
fill 188 172 435 188 172 436 minecraft:shroomlight
fill 188 172 437 188 205 437 minecraft:polished_andesite
fill 188 172 446 188 205 446 minecraft:polished_andesite
fill 188 172 447 188 172 448 minecraft:shroomlight
fill 188 172 449 188 205 449 minecraft:polished_andesite
fill 188 172 458 188 205 458 minecraft:polished_andesite
fill 189 172 437 189 176 437 minecraft:polished_deepslate
fill 189 172 443 189 176 443 minecraft:polished_deepslate
fill 189 172 458 190 172 458 minecraft:shroomlight
fill 191 172 458 191 205 458 minecraft:polished_andesite
fill 193 172 437 193 176 437 minecraft:polished_deepslate
fill 193 172 443 193 176 443 minecraft:polished_deepslate
fill 194 172 437 194 173 437 minecraft:iron_block
fill 194 172 438 194 176 438 minecraft:polished_deepslate
fill 194 172 442 194 176 442 minecraft:polished_deepslate
fill 194 172 443 194 174 443 minecraft:iron_block
fill 195 172 416 195 205 416 minecraft:polished_andesite
fill 196 172 416 197 172 416 minecraft:shroomlight
fill 198 172 416 198 205 416 minecraft:polished_andesite
fill 200 172 458 200 205 458 minecraft:polished_andesite
fill 201 172 458 202 172 458 minecraft:shroomlight
fill 203 172 458 203 205 458 minecraft:polished_andesite
fill 207 172 416 207 205 416 minecraft:polished_andesite
fill 208 172 416 209 172 416 minecraft:shroomlight
fill 210 172 416 210 205 416 minecraft:polished_andesite
fill 212 172 458 212 205 458 minecraft:polished_andesite
fill 213 172 458 214 172 458 minecraft:shroomlight
fill 215 172 458 215 205 458 minecraft:polished_andesite
setblock 217 172 421 minecraft:orange_stained_glass
fill 219 172 416 219 205 416 minecraft:polished_andesite
fill 220 172 416 221 172 416 minecraft:shroomlight
fill 222 172 416 222 205 416 minecraft:polished_andesite
fill 224 172 437 224 173 437 minecraft:iron_block
fill 224 172 438 224 176 438 minecraft:polished_deepslate
fill 224 172 442 224 176 442 minecraft:polished_deepslate
fill 224 172 443 224 174 443 minecraft:iron_block
fill 224 172 458 224 205 458 minecraft:polished_andesite
fill 225 172 437 225 176 437 minecraft:polished_deepslate
fill 225 172 443 225 176 443 minecraft:polished_deepslate
fill 225 172 458 226 172 458 minecraft:shroomlight
fill 226 172 421 226 174 423 minecraft:orange_stained_glass
fill 227 172 420 229 173 420 minecraft:orange_stained_glass
fill 227 172 424 229 173 424 minecraft:orange_stained_glass
fill 227 172 458 227 205 458 minecraft:polished_andesite
fill 229 172 443 229 176 443 minecraft:polished_deepslate
fill 230 172 417 230 205 417 minecraft:polished_andesite
fill 230 172 418 230 172 419 minecraft:shroomlight
fill 230 172 420 230 205 420 minecraft:polished_andesite
fill 230 172 429 230 205 429 minecraft:polished_andesite
fill 230 172 430 230 172 431 minecraft:shroomlight
fill 230 172 432 230 205 432 minecraft:polished_andesite
fill 230 172 441 230 205 441 minecraft:polished_andesite
fill 230 172 442 230 172 443 minecraft:shroomlight
fill 230 172 444 230 205 444 minecraft:polished_andesite
fill 230 172 453 230 205 453 minecraft:polished_andesite
fill 230 172 454 230 172 455 minecraft:shroomlight
fill 230 172 456 230 205 456 minecraft:polished_andesite
fill 188 173 423 188 205 424 minecraft:polished_andesite
fill 188 173 435 188 205 436 minecraft:polished_andesite
fill 188 173 447 188 205 448 minecraft:polished_andesite
fill 189 173 458 190 205 458 minecraft:polished_andesite
fill 190 173 436 192 176 436 minecraft:polished_deepslate
fill 190 173 444 192 174 444 minecraft:polished_deepslate
fill 195 173 439 195 176 441 minecraft:polished_deepslate
fill 196 173 416 197 205 416 minecraft:polished_andesite
fill 201 173 458 202 205 458 minecraft:polished_andesite
fill 208 173 416 209 205 416 minecraft:polished_andesite
fill 213 173 458 214 205 458 minecraft:polished_andesite
fill 217 173 418 217 173 420 minecraft:orange_stained_glass
fill 220 173 416 221 205 416 minecraft:polished_andesite
fill 223 173 429 223 173 431 minecraft:gold_block
fill 223 173 439 223 176 441 minecraft:polished_deepslate
fill 224 173 428 224 173 429 minecraft:gold_block
fill 224 173 431 224 174 432 minecraft:gold_block
fill 225 173 422 225 175 422 minecraft:orange_stained_glass
fill 225 173 428 227 173 428 minecraft:gold_block
fill 225 173 432 226 173 433 minecraft:gold_block
fill 225 173 458 226 205 458 minecraft:polished_andesite
fill 226 173 436 228 176 436 minecraft:polished_deepslate
fill 226 173 444 228 174 444 minecraft:polished_deepslate
fill 227 173 429 228 173 429 minecraft:gold_block
fill 227 173 431 227 174 432 minecraft:gold_block
fill 228 173 430 228 173 431 minecraft:gold_block
fill 230 173 418 230 205 419 minecraft:polished_andesite
fill 230 173 430 230 205 431 minecraft:polished_andesite
fill 230 173 442 230 205 443 minecraft:polished_andesite
fill 230 173 454 230 205 455 minecraft:polished_andesite
fill 194 174 437 194 176 437 minecraft:polished_deepslate
fill 216 174 417 218 174 418 minecraft:orange_stained_glass
setblock 217 174 419 minecraft:orange_stained_glass
fill 224 174 422 224 175 422 minecraft:orange_stained_glass
fill 224 174 429 224 175 429 minecraft:gold_block
fill 224 174 437 224 176 437 minecraft:polished_deepslate
setblock 225 174 421 minecraft:orange_stained_glass
setblock 225 174 423 minecraft:orange_stained_glass
fill 225 174 428 226 174 428 minecraft:gold_block
fill 225 174 432 226 175 432 minecraft:gold_block
fill 227 174 429 227 175 429 minecraft:gold_block
setblock 228 174 430 minecraft:gold_block
fill 191 175 444 191 176 444 minecraft:polished_deepslate
fill 216 175 417 218 175 417 minecraft:orange_stained_glass
setblock 217 175 418 minecraft:orange_stained_glass
setblock 224 175 431 minecraft:gold_block
fill 226 175 422 227 175 422 minecraft:orange_stained_glass
setblock 227 175 431 minecraft:gold_block
fill 227 175 444 227 176 444 minecraft:polished_deepslate
setblock 191 177 419 minecraft:light[level=13]
setblock 191 177 427 minecraft:light[level=13]
setblock 191 177 435 minecraft:light[level=13]
setblock 191 177 443 minecraft:light[level=13]
setblock 191 177 451 minecraft:light[level=13]
setblock 199 177 419 minecraft:light[level=13]
setblock 199 177 427 minecraft:light[level=13]
setblock 199 177 435 minecraft:light[level=13]
setblock 199 177 443 minecraft:light[level=13]
setblock 199 177 451 minecraft:light[level=13]
setblock 207 177 419 minecraft:light[level=13]
setblock 207 177 427 minecraft:light[level=13]
setblock 207 177 435 minecraft:light[level=13]
setblock 207 177 443 minecraft:light[level=13]
setblock 207 177 451 minecraft:light[level=13]
setblock 215 177 419 minecraft:light[level=13]
setblock 215 177 427 minecraft:light[level=13]
setblock 215 177 435 minecraft:light[level=13]
setblock 215 177 443 minecraft:light[level=13]
setblock 215 177 451 minecraft:light[level=13]
setblock 223 177 419 minecraft:light[level=13]
setblock 223 177 427 minecraft:light[level=13]
setblock 223 177 435 minecraft:light[level=13]
setblock 223 177 443 minecraft:light[level=13]
setblock 223 177 451 minecraft:light[level=13]
fill 210 179 438 214 179 440 minecraft:redstone_block
fill 211 179 437 214 179 437 minecraft:redstone_block
fill 211 179 441 214 179 441 minecraft:redstone_block
fill 215 179 438 215 179 439 minecraft:redstone_block
fill 208 180 438 209 180 440 minecraft:redstone_block
fill 209 180 436 210 180 437 minecraft:redstone_block
fill 209 180 441 210 180 442 minecraft:redstone_block
fill 210 180 438 214 180 440 minecraft:red_concrete
fill 211 180 435 214 180 436 minecraft:redstone_block
fill 211 180 437 214 193 437 minecraft:red_concrete
fill 211 180 441 214 180 441 minecraft:red_concrete
fill 211 180 442 214 180 443 minecraft:redstone_block
fill 215 180 436 216 180 437 minecraft:redstone_block
fill 215 180 438 215 180 439 minecraft:red_concrete
setblock 215 180 442 minecraft:redstone_block
fill 216 180 438 217 180 439 minecraft:redstone_block
setblock 217 180 440 minecraft:redstone_block
fill 207 181 438 207 181 440 minecraft:redstone_block
fill 208 181 436 208 181 437 minecraft:redstone_block
fill 208 181 438 213 190 440 minecraft:red_concrete
fill 208 181 441 208 181 442 minecraft:redstone_block
fill 209 181 435 210 181 435 minecraft:redstone_block
fill 209 181 436 210 192 437 minecraft:red_concrete
fill 209 181 441 213 190 442 minecraft:red_concrete
fill 209 181 443 210 181 443 minecraft:redstone_block
fill 210 181 434 215 181 434 minecraft:redstone_block
fill 210 181 444 215 181 444 minecraft:redstone_block
fill 211 181 435 214 192 436 minecraft:red_concrete
fill 211 181 443 214 190 443 minecraft:red_concrete
fill 214 181 438 214 190 439 minecraft:red_concrete
fill 215 181 435 216 181 435 minecraft:redstone_block
fill 215 181 436 216 190 438 minecraft:red_concrete
fill 217 181 436 217 181 437 minecraft:redstone_block
fill 217 181 438 217 190 438 minecraft:red_concrete
fill 218 181 438 218 181 439 minecraft:redstone_block
fill 206 182 438 206 183 440 minecraft:redstone_block
fill 207 182 436 207 182 437 minecraft:redstone_block
fill 207 182 438 207 191 440 minecraft:red_concrete
fill 207 182 441 207 182 442 minecraft:redstone_block
setblock 208 182 435 minecraft:redstone_block
fill 208 182 436 208 191 437 minecraft:red_concrete
fill 208 182 441 208 191 442 minecraft:red_concrete
setblock 208 182 443 minecraft:redstone_block
setblock 209 182 434 minecraft:redstone_block
fill 209 182 435 210 191 435 minecraft:red_concrete
fill 209 182 443 210 191 443 minecraft:red_concrete
setblock 209 182 444 minecraft:redstone_block
fill 210 182 433 215 182 433 minecraft:redstone_block
fill 210 182 434 215 191 434 minecraft:red_concrete
fill 210 182 444 215 190 444 minecraft:red_concrete
fill 210 182 445 215 182 445 minecraft:redstone_block
fill 215 182 435 216 191 435 minecraft:red_concrete
setblock 216 182 434 minecraft:redstone_block
setblock 216 182 444 minecraft:redstone_block
setblock 217 182 435 minecraft:redstone_block
fill 217 182 436 217 191 437 minecraft:red_concrete
fill 218 182 436 218 182 437 minecraft:redstone_block
fill 218 182 438 218 190 439 minecraft:red_concrete
fill 219 182 438 219 183 440 minecraft:redstone_block
fill 206 183 436 206 184 437 minecraft:redstone_block
fill 206 183 441 206 184 442 minecraft:redstone_block
fill 207 183 435 207 184 435 minecraft:redstone_block
fill 207 183 436 207 190 437 minecraft:red_concrete
fill 207 183 441 207 190 442 minecraft:red_concrete
fill 207 183 443 207 184 443 minecraft:redstone_block
setblock 208 183 434 minecraft:redstone_block
fill 208 183 435 208 190 435 minecraft:red_concrete
fill 208 183 443 208 190 443 minecraft:red_concrete
setblock 208 183 444 minecraft:redstone_block
fill 209 183 433 210 183 433 minecraft:redstone_block
fill 209 183 434 209 190 434 minecraft:red_concrete
fill 209 183 444 209 190 444 minecraft:red_concrete
fill 209 183 445 210 183 445 minecraft:redstone_block
fill 211 183 432 214 190 432 minecraft:redstone_block
fill 211 183 433 214 190 433 minecraft:red_concrete
fill 211 183 445 214 190 445 minecraft:red_concrete
fill 211 183 446 214 190 446 minecraft:redstone_block
fill 215 183 433 216 183 433 minecraft:redstone_block
fill 215 183 445 216 183 445 minecraft:redstone_block
fill 216 183 434 216 190 434 minecraft:red_concrete
fill 216 183 444 216 190 444 minecraft:red_concrete
setblock 217 183 434 minecraft:redstone_block
fill 217 183 435 217 190 435 minecraft:red_concrete
setblock 217 183 444 minecraft:redstone_block
fill 218 183 435 218 184 435 minecraft:redstone_block
fill 218 183 436 218 190 437 minecraft:red_concrete
fill 218 183 443 218 184 443 minecraft:redstone_block
fill 219 183 436 219 184 437 minecraft:redstone_block
fill 219 183 441 219 184 442 minecraft:redstone_block
fill 205 184 438 205 189 440 minecraft:redstone_block
fill 206 184 438 206 189 440 minecraft:red_concrete
fill 207 184 434 207 189 434 minecraft:redstone_block
fill 207 184 444 207 189 444 minecraft:redstone_block
fill 208 184 433 209 184 433 minecraft:redstone_block
fill 208 184 434 208 189 434 minecraft:red_concrete
fill 208 184 444 208 189 444 minecraft:red_concrete
fill 208 184 445 209 184 445 minecraft:redstone_block
fill 210 184 432 210 189 432 minecraft:redstone_block
fill 210 184 433 210 189 433 minecraft:red_concrete
fill 210 184 445 210 189 445 minecraft:red_concrete
fill 210 184 446 210 189 446 minecraft:redstone_block
fill 215 184 432 215 189 432 minecraft:redstone_block
fill 215 184 433 215 189 433 minecraft:red_concrete
fill 215 184 445 215 189 445 minecraft:red_concrete
fill 215 184 446 215 189 446 minecraft:redstone_block
fill 216 184 433 217 184 433 minecraft:redstone_block
fill 216 184 445 217 184 445 minecraft:redstone_block
fill 217 184 434 217 189 434 minecraft:red_concrete
fill 217 184 444 217 189 444 minecraft:red_concrete
fill 218 184 434 218 189 434 minecraft:redstone_block
fill 218 184 444 218 189 444 minecraft:redstone_block
fill 219 184 438 219 189 440 minecraft:red_concrete
fill 220 184 438 220 189 440 minecraft:redstone_block
setblock 191 185 419 minecraft:light[level=13]
setblock 191 185 427 minecraft:light[level=13]
setblock 191 185 435 minecraft:light[level=13]
setblock 191 185 443 minecraft:light[level=13]
setblock 191 185 451 minecraft:light[level=13]
setblock 199 185 419 minecraft:light[level=13]
setblock 199 185 427 minecraft:light[level=13]
setblock 199 185 435 minecraft:light[level=13]
setblock 199 185 443 minecraft:light[level=13]
setblock 199 185 451 minecraft:light[level=13]
fill 205 185 437 205 188 437 minecraft:redstone_block
fill 205 185 441 205 188 441 minecraft:redstone_block
fill 206 185 435 206 188 436 minecraft:redstone_block
fill 206 185 437 206 188 437 minecraft:red_concrete
fill 206 185 441 206 188 441 minecraft:red_concrete
fill 206 185 442 206 188 443 minecraft:redstone_block
setblock 207 185 419 minecraft:light[level=13]
setblock 207 185 427 minecraft:light[level=13]
fill 207 185 435 207 188 435 minecraft:red_concrete
fill 207 185 443 207 188 443 minecraft:red_concrete
setblock 207 185 451 minecraft:light[level=13]
fill 208 185 433 208 189 433 minecraft:redstone_block
fill 208 185 445 208 189 445 minecraft:redstone_block
fill 209 185 432 209 188 432 minecraft:redstone_block
fill 209 185 433 209 188 433 minecraft:red_concrete
fill 209 185 445 209 188 445 minecraft:red_concrete
fill 209 185 446 209 188 446 minecraft:redstone_block
setblock 215 185 419 minecraft:light[level=13]
setblock 215 185 427 minecraft:light[level=13]
setblock 215 185 451 minecraft:light[level=13]
fill 216 185 432 216 188 432 minecraft:redstone_block
fill 216 185 433 216 188 433 minecraft:red_concrete
fill 216 185 445 216 188 445 minecraft:red_concrete
fill 216 185 446 216 188 446 minecraft:redstone_block
fill 217 185 433 217 189 433 minecraft:redstone_block
fill 217 185 445 217 189 445 minecraft:redstone_block
fill 218 185 435 218 188 435 minecraft:red_concrete
fill 218 185 443 218 188 443 minecraft:red_concrete
fill 219 185 435 219 188 436 minecraft:redstone_block
fill 219 185 437 219 188 437 minecraft:red_concrete
fill 219 185 441 219 188 441 minecraft:red_concrete
fill 219 185 442 219 188 443 minecraft:redstone_block
fill 220 185 437 220 188 437 minecraft:redstone_block
fill 220 185 441 220 188 441 minecraft:redstone_block
setblock 223 185 419 minecraft:light[level=13]
setblock 223 185 427 minecraft:light[level=13]
setblock 223 185 435 minecraft:light[level=13]
setblock 223 185 443 minecraft:light[level=13]
setblock 223 185 451 minecraft:light[level=13]
fill 206 189 436 206 190 437 minecraft:redstone_block
fill 206 189 441 206 190 442 minecraft:redstone_block
fill 207 189 435 207 190 435 minecraft:redstone_block
fill 207 189 443 207 190 443 minecraft:redstone_block
fill 209 189 433 209 190 433 minecraft:redstone_block
fill 209 189 445 209 190 445 minecraft:redstone_block
fill 216 189 433 216 190 433 minecraft:redstone_block
fill 216 189 445 216 190 445 minecraft:redstone_block
fill 218 189 435 218 190 435 minecraft:redstone_block
fill 218 189 443 218 190 443 minecraft:redstone_block
fill 219 189 436 219 190 437 minecraft:redstone_block
fill 219 189 441 219 190 442 minecraft:redstone_block
fill 206 190 438 206 191 440 minecraft:redstone_block
setblock 208 190 434 minecraft:redstone_block
setblock 208 190 444 minecraft:redstone_block
fill 210 190 433 210 191 433 minecraft:redstone_block
fill 210 190 445 210 191 445 minecraft:redstone_block
fill 215 190 433 215 191 433 minecraft:redstone_block
fill 215 190 445 215 191 445 minecraft:redstone_block
setblock 217 190 434 minecraft:redstone_block
setblock 217 190 444 minecraft:redstone_block
fill 219 190 438 219 190 440 minecraft:redstone_block
fill 189 191 417 189 191 418 minecraft:polished_deepslate
setblock 189 191 419 minecraft:red_concrete
fill 189 191 420 189 191 422 minecraft:polished_deepslate
setblock 189 191 423 minecraft:red_concrete
fill 189 191 424 189 191 426 minecraft:polished_deepslate
setblock 189 191 427 minecraft:red_concrete
fill 189 191 428 189 191 430 minecraft:polished_deepslate
setblock 189 191 431 minecraft:red_concrete
fill 189 191 432 189 191 434 minecraft:polished_deepslate
setblock 189 191 435 minecraft:red_concrete
fill 189 191 436 189 191 438 minecraft:polished_deepslate
setblock 189 191 439 minecraft:red_concrete
fill 189 191 440 189 191 442 minecraft:polished_deepslate
setblock 189 191 443 minecraft:red_concrete
fill 189 191 444 189 191 446 minecraft:polished_deepslate
setblock 189 191 447 minecraft:red_concrete
fill 189 191 448 189 191 450 minecraft:polished_deepslate
setblock 189 191 451 minecraft:red_concrete
fill 189 191 452 189 191 454 minecraft:polished_deepslate
setblock 189 191 455 minecraft:red_concrete
fill 189 191 456 190 191 457 minecraft:polished_deepslate
setblock 190 191 417 minecraft:polished_deepslate
setblock 190 191 418 minecraft:red_concrete
fill 190 191 419 190 191 421 minecraft:polished_deepslate
setblock 190 191 422 minecraft:red_concrete
fill 190 191 423 190 191 425 minecraft:polished_deepslate
setblock 190 191 426 minecraft:red_concrete
fill 190 191 427 190 191 429 minecraft:polished_deepslate
setblock 190 191 430 minecraft:red_concrete
fill 190 191 431 190 191 433 minecraft:polished_deepslate
setblock 190 191 434 minecraft:red_concrete
fill 190 191 435 190 191 437 minecraft:polished_deepslate
setblock 190 191 438 minecraft:red_concrete
fill 190 191 439 190 191 441 minecraft:polished_deepslate
setblock 190 191 442 minecraft:red_concrete
fill 190 191 443 190 191 445 minecraft:polished_deepslate
setblock 190 191 446 minecraft:red_concrete
fill 190 191 447 190 191 449 minecraft:polished_deepslate
setblock 190 191 450 minecraft:red_concrete
fill 190 191 451 190 191 453 minecraft:polished_deepslate
setblock 190 191 454 minecraft:red_concrete
fill 190 191 455 192 191 455 minecraft:polished_deepslate
setblock 191 191 417 minecraft:red_concrete
fill 191 191 418 191 191 420 minecraft:polished_deepslate
setblock 191 191 421 minecraft:red_concrete
fill 191 191 422 191 191 424 minecraft:polished_deepslate
setblock 191 191 425 minecraft:red_concrete
fill 191 191 426 191 191 428 minecraft:polished_deepslate
setblock 191 191 429 minecraft:red_concrete
fill 191 191 430 191 191 432 minecraft:polished_deepslate
setblock 191 191 433 minecraft:red_concrete
fill 191 191 434 191 191 436 minecraft:polished_deepslate
setblock 191 191 437 minecraft:red_concrete
fill 191 191 438 191 191 440 minecraft:polished_deepslate
setblock 191 191 441 minecraft:red_concrete
fill 191 191 442 191 191 444 minecraft:polished_deepslate
setblock 191 191 445 minecraft:red_concrete
fill 191 191 446 191 191 448 minecraft:polished_deepslate
setblock 191 191 449 minecraft:red_concrete
fill 191 191 450 191 191 452 minecraft:polished_deepslate
setblock 191 191 453 minecraft:red_concrete
fill 191 191 454 193 191 454 minecraft:polished_deepslate
setblock 191 191 456 minecraft:polished_deepslate
setblock 191 191 457 minecraft:red_concrete
fill 192 191 417 192 191 419 minecraft:polished_deepslate
setblock 192 191 420 minecraft:red_concrete
fill 192 191 421 192 191 423 minecraft:polished_deepslate
setblock 192 191 424 minecraft:red_concrete
fill 192 191 425 192 191 427 minecraft:polished_deepslate
setblock 192 191 428 minecraft:red_concrete
fill 192 191 429 192 191 431 minecraft:polished_deepslate
setblock 192 191 432 minecraft:red_concrete
fill 192 191 433 192 191 435 minecraft:polished_deepslate
setblock 192 191 436 minecraft:red_concrete
fill 192 191 437 192 191 439 minecraft:polished_deepslate
setblock 192 191 440 minecraft:red_concrete
fill 192 191 441 192 191 443 minecraft:polished_deepslate
setblock 192 191 444 minecraft:red_concrete
fill 192 191 445 192 191 447 minecraft:polished_deepslate
setblock 192 191 448 minecraft:red_concrete
fill 192 191 449 192 191 451 minecraft:polished_deepslate
setblock 192 191 452 minecraft:red_concrete
fill 192 191 453 194 191 453 minecraft:polished_deepslate
setblock 192 191 456 minecraft:red_concrete
fill 192 191 457 194 191 457 minecraft:polished_deepslate
fill 193 191 417 193 191 418 minecraft:polished_deepslate
setblock 193 191 419 minecraft:red_concrete
fill 193 191 420 193 191 422 minecraft:polished_deepslate
setblock 193 191 423 minecraft:red_concrete
fill 193 191 424 193 191 426 minecraft:polished_deepslate
setblock 193 191 427 minecraft:red_concrete
fill 193 191 428 193 191 430 minecraft:polished_deepslate
setblock 193 191 431 minecraft:red_concrete
fill 193 191 432 193 191 434 minecraft:polished_deepslate
setblock 193 191 435 minecraft:red_concrete
fill 193 191 436 193 191 438 minecraft:polished_deepslate
setblock 193 191 439 minecraft:red_concrete
fill 193 191 440 193 191 442 minecraft:polished_deepslate
setblock 193 191 443 minecraft:red_concrete
fill 193 191 444 193 191 446 minecraft:polished_deepslate
setblock 193 191 447 minecraft:red_concrete
fill 193 191 448 193 191 450 minecraft:polished_deepslate
setblock 193 191 451 minecraft:red_concrete
fill 193 191 452 195 191 452 minecraft:polished_deepslate
setblock 193 191 455 minecraft:red_concrete
fill 193 191 456 195 191 456 minecraft:polished_deepslate
setblock 194 191 417 minecraft:polished_deepslate
setblock 194 191 418 minecraft:red_concrete
fill 194 191 419 194 191 421 minecraft:polished_deepslate
setblock 194 191 422 minecraft:red_concrete
fill 194 191 423 194 191 425 minecraft:polished_deepslate
setblock 194 191 426 minecraft:red_concrete
fill 194 191 427 194 191 429 minecraft:polished_deepslate
setblock 194 191 430 minecraft:red_concrete
fill 194 191 431 194 191 433 minecraft:polished_deepslate
setblock 194 191 434 minecraft:red_concrete
fill 194 191 435 194 191 437 minecraft:polished_deepslate
setblock 194 191 438 minecraft:red_concrete
fill 194 191 439 194 191 441 minecraft:polished_deepslate
setblock 194 191 442 minecraft:red_concrete
fill 194 191 443 194 191 445 minecraft:polished_deepslate
setblock 194 191 446 minecraft:red_concrete
fill 194 191 447 194 191 449 minecraft:polished_deepslate
setblock 194 191 450 minecraft:red_concrete
fill 194 191 451 196 191 451 minecraft:polished_deepslate
setblock 194 191 454 minecraft:red_concrete
fill 194 191 455 196 191 455 minecraft:polished_deepslate
setblock 195 191 417 minecraft:red_concrete
fill 195 191 418 195 191 420 minecraft:polished_deepslate
setblock 195 191 421 minecraft:red_concrete
fill 195 191 422 195 191 424 minecraft:polished_deepslate
setblock 195 191 425 minecraft:red_concrete
fill 195 191 426 195 191 428 minecraft:polished_deepslate
setblock 195 191 429 minecraft:red_concrete
fill 195 191 430 195 191 432 minecraft:polished_deepslate
setblock 195 191 433 minecraft:red_concrete
fill 195 191 434 195 191 436 minecraft:polished_deepslate
setblock 195 191 437 minecraft:red_concrete
fill 195 191 438 195 191 440 minecraft:polished_deepslate
setblock 195 191 441 minecraft:red_concrete
fill 195 191 442 195 191 444 minecraft:polished_deepslate
setblock 195 191 445 minecraft:red_concrete
fill 195 191 446 195 191 448 minecraft:polished_deepslate
setblock 195 191 449 minecraft:red_concrete
fill 195 191 450 197 191 450 minecraft:polished_deepslate
setblock 195 191 453 minecraft:red_concrete
fill 195 191 454 197 191 454 minecraft:polished_deepslate
setblock 195 191 457 minecraft:red_concrete
fill 196 191 417 196 191 419 minecraft:polished_deepslate
setblock 196 191 420 minecraft:red_concrete
fill 196 191 421 196 191 423 minecraft:polished_deepslate
setblock 196 191 424 minecraft:red_concrete
fill 196 191 425 196 191 427 minecraft:polished_deepslate
setblock 196 191 428 minecraft:red_concrete
fill 196 191 429 196 191 431 minecraft:polished_deepslate
setblock 196 191 432 minecraft:red_concrete
fill 196 191 433 196 191 435 minecraft:polished_deepslate
setblock 196 191 436 minecraft:red_concrete
fill 196 191 437 196 191 439 minecraft:polished_deepslate
setblock 196 191 440 minecraft:red_concrete
fill 196 191 441 196 191 443 minecraft:polished_deepslate
setblock 196 191 444 minecraft:red_concrete
fill 196 191 445 196 191 447 minecraft:polished_deepslate
setblock 196 191 448 minecraft:red_concrete
fill 196 191 449 198 191 449 minecraft:polished_deepslate
setblock 196 191 452 minecraft:red_concrete
fill 196 191 453 198 191 453 minecraft:polished_deepslate
setblock 196 191 456 minecraft:red_concrete
fill 196 191 457 198 191 457 minecraft:polished_deepslate
fill 197 191 417 197 191 418 minecraft:polished_deepslate
setblock 197 191 419 minecraft:red_concrete
fill 197 191 420 197 191 422 minecraft:polished_deepslate
setblock 197 191 423 minecraft:red_concrete
fill 197 191 424 197 191 426 minecraft:polished_deepslate
setblock 197 191 427 minecraft:red_concrete
fill 197 191 428 197 191 430 minecraft:polished_deepslate
setblock 197 191 431 minecraft:red_concrete
fill 197 191 432 197 191 434 minecraft:polished_deepslate
setblock 197 191 435 minecraft:red_concrete
fill 197 191 436 197 191 438 minecraft:polished_deepslate
setblock 197 191 439 minecraft:red_concrete
fill 197 191 440 197 191 442 minecraft:polished_deepslate
setblock 197 191 443 minecraft:red_concrete
fill 197 191 444 197 191 446 minecraft:polished_deepslate
setblock 197 191 447 minecraft:red_concrete
fill 197 191 448 199 191 448 minecraft:polished_deepslate
setblock 197 191 451 minecraft:red_concrete
fill 197 191 452 199 191 452 minecraft:polished_deepslate
setblock 197 191 455 minecraft:red_concrete
fill 197 191 456 199 191 456 minecraft:polished_deepslate
setblock 198 191 417 minecraft:polished_deepslate
setblock 198 191 418 minecraft:red_concrete
fill 198 191 419 198 191 421 minecraft:polished_deepslate
setblock 198 191 422 minecraft:red_concrete
fill 198 191 423 198 191 425 minecraft:polished_deepslate
setblock 198 191 426 minecraft:red_concrete
fill 198 191 427 198 191 429 minecraft:polished_deepslate
setblock 198 191 430 minecraft:red_concrete
fill 198 191 431 198 191 433 minecraft:polished_deepslate
setblock 198 191 434 minecraft:red_concrete
fill 198 191 435 198 191 437 minecraft:polished_deepslate
setblock 198 191 438 minecraft:red_concrete
fill 198 191 439 198 191 441 minecraft:polished_deepslate
setblock 198 191 442 minecraft:red_concrete
fill 198 191 443 198 191 445 minecraft:polished_deepslate
setblock 198 191 446 minecraft:red_concrete
fill 198 191 447 200 191 447 minecraft:polished_deepslate
setblock 198 191 450 minecraft:red_concrete
fill 198 191 451 200 191 451 minecraft:polished_deepslate
setblock 198 191 454 minecraft:red_concrete
fill 198 191 455 200 191 455 minecraft:polished_deepslate
setblock 199 191 417 minecraft:red_concrete
fill 199 191 418 199 191 420 minecraft:polished_deepslate
setblock 199 191 421 minecraft:red_concrete
fill 199 191 422 199 191 424 minecraft:polished_deepslate
setblock 199 191 425 minecraft:red_concrete
fill 199 191 426 199 191 428 minecraft:polished_deepslate
setblock 199 191 429 minecraft:red_concrete
fill 199 191 430 199 191 432 minecraft:polished_deepslate
setblock 199 191 433 minecraft:red_concrete
fill 199 191 434 199 191 436 minecraft:polished_deepslate
setblock 199 191 437 minecraft:red_concrete
fill 199 191 438 199 191 440 minecraft:polished_deepslate
setblock 199 191 441 minecraft:red_concrete
fill 199 191 442 199 191 444 minecraft:polished_deepslate
setblock 199 191 445 minecraft:red_concrete
fill 199 191 446 201 191 446 minecraft:polished_deepslate
setblock 199 191 449 minecraft:red_concrete
fill 199 191 450 201 191 450 minecraft:polished_deepslate
setblock 199 191 453 minecraft:red_concrete
fill 199 191 454 201 191 454 minecraft:polished_deepslate
setblock 199 191 457 minecraft:red_concrete
fill 200 191 417 200 191 419 minecraft:polished_deepslate
setblock 200 191 420 minecraft:red_concrete
fill 200 191 421 200 191 423 minecraft:polished_deepslate
setblock 200 191 424 minecraft:red_concrete
fill 200 191 425 200 191 427 minecraft:polished_deepslate
setblock 200 191 428 minecraft:red_concrete
fill 200 191 429 200 191 431 minecraft:polished_deepslate
setblock 200 191 432 minecraft:red_concrete
fill 200 191 433 200 191 435 minecraft:polished_deepslate
setblock 200 191 436 minecraft:red_concrete
fill 200 191 437 200 191 439 minecraft:polished_deepslate
setblock 200 191 440 minecraft:red_concrete
fill 200 191 441 200 191 443 minecraft:polished_deepslate
setblock 200 191 444 minecraft:red_concrete
fill 200 191 445 202 191 445 minecraft:polished_deepslate
setblock 200 191 448 minecraft:red_concrete
fill 200 191 449 202 191 449 minecraft:polished_deepslate
setblock 200 191 452 minecraft:red_concrete
fill 200 191 453 202 191 453 minecraft:polished_deepslate
setblock 200 191 456 minecraft:red_concrete
fill 200 191 457 202 191 457 minecraft:polished_deepslate
fill 201 191 417 201 191 418 minecraft:polished_deepslate
setblock 201 191 419 minecraft:red_concrete
fill 201 191 420 201 191 422 minecraft:polished_deepslate
setblock 201 191 423 minecraft:red_concrete
fill 201 191 424 201 191 426 minecraft:polished_deepslate
setblock 201 191 427 minecraft:red_concrete
fill 201 191 428 201 191 430 minecraft:polished_deepslate
setblock 201 191 431 minecraft:red_concrete
fill 201 191 432 201 191 434 minecraft:polished_deepslate
setblock 201 191 435 minecraft:red_concrete
fill 201 191 436 201 191 438 minecraft:polished_deepslate
setblock 201 191 439 minecraft:red_concrete
fill 201 191 440 201 191 442 minecraft:polished_deepslate
setblock 201 191 443 minecraft:red_concrete
fill 201 191 444 203 191 444 minecraft:polished_deepslate
setblock 201 191 447 minecraft:red_concrete
fill 201 191 448 203 191 448 minecraft:polished_deepslate
setblock 201 191 451 minecraft:red_concrete
fill 201 191 452 203 191 452 minecraft:polished_deepslate
setblock 201 191 455 minecraft:red_concrete
fill 201 191 456 203 191 456 minecraft:polished_deepslate
setblock 202 191 417 minecraft:polished_deepslate
setblock 202 191 418 minecraft:red_concrete
fill 202 191 419 202 191 421 minecraft:polished_deepslate
setblock 202 191 422 minecraft:red_concrete
fill 202 191 423 202 191 425 minecraft:polished_deepslate
setblock 202 191 426 minecraft:red_concrete
fill 202 191 427 202 191 429 minecraft:polished_deepslate
setblock 202 191 430 minecraft:red_concrete
fill 202 191 431 202 191 433 minecraft:polished_deepslate
setblock 202 191 434 minecraft:red_concrete
fill 202 191 435 202 191 437 minecraft:polished_deepslate
setblock 202 191 438 minecraft:red_concrete
fill 202 191 439 202 191 441 minecraft:polished_deepslate
setblock 202 191 442 minecraft:red_concrete
fill 202 191 443 204 191 443 minecraft:polished_deepslate
setblock 202 191 446 minecraft:red_concrete
fill 202 191 447 204 191 447 minecraft:polished_deepslate
setblock 202 191 450 minecraft:red_concrete
fill 202 191 451 204 191 451 minecraft:polished_deepslate
setblock 202 191 454 minecraft:red_concrete
fill 202 191 455 204 191 455 minecraft:polished_deepslate
setblock 203 191 417 minecraft:red_concrete
fill 203 191 418 203 191 420 minecraft:polished_deepslate
setblock 203 191 421 minecraft:red_concrete
fill 203 191 422 203 191 424 minecraft:polished_deepslate
setblock 203 191 425 minecraft:red_concrete
fill 203 191 426 203 191 428 minecraft:polished_deepslate
setblock 203 191 429 minecraft:red_concrete
fill 203 191 430 203 191 432 minecraft:polished_deepslate
setblock 203 191 433 minecraft:red_concrete
fill 203 191 434 203 191 436 minecraft:polished_deepslate
setblock 203 191 437 minecraft:red_concrete
fill 203 191 438 203 191 440 minecraft:polished_deepslate
setblock 203 191 441 minecraft:red_concrete
fill 203 191 442 205 191 442 minecraft:polished_deepslate
setblock 203 191 445 minecraft:red_concrete
fill 203 191 446 205 191 446 minecraft:polished_deepslate
setblock 203 191 449 minecraft:red_concrete
fill 203 191 450 205 191 450 minecraft:polished_deepslate
setblock 203 191 453 minecraft:red_concrete
fill 203 191 454 205 191 454 minecraft:polished_deepslate
setblock 203 191 457 minecraft:red_concrete
fill 204 191 417 204 191 419 minecraft:polished_deepslate
setblock 204 191 420 minecraft:red_concrete
fill 204 191 421 204 191 423 minecraft:polished_deepslate
setblock 204 191 424 minecraft:red_concrete
fill 204 191 425 204 191 427 minecraft:polished_deepslate
setblock 204 191 428 minecraft:red_concrete
fill 204 191 429 204 191 431 minecraft:polished_deepslate
setblock 204 191 432 minecraft:red_concrete
fill 204 191 433 204 191 435 minecraft:polished_deepslate
setblock 204 191 436 minecraft:red_concrete
fill 204 191 437 204 191 439 minecraft:polished_deepslate
setblock 204 191 440 minecraft:red_concrete
fill 204 191 441 206 191 441 minecraft:polished_deepslate
setblock 204 191 444 minecraft:red_concrete
fill 204 191 445 206 191 445 minecraft:polished_deepslate
setblock 204 191 448 minecraft:red_concrete
fill 204 191 449 206 191 449 minecraft:polished_deepslate
setblock 204 191 452 minecraft:red_concrete
fill 204 191 453 206 191 453 minecraft:polished_deepslate
setblock 204 191 456 minecraft:red_concrete
fill 204 191 457 206 191 457 minecraft:polished_deepslate
fill 205 191 417 205 191 418 minecraft:polished_deepslate
setblock 205 191 419 minecraft:red_concrete
fill 205 191 420 205 191 422 minecraft:polished_deepslate
setblock 205 191 423 minecraft:red_concrete
fill 205 191 424 205 191 426 minecraft:polished_deepslate
setblock 205 191 427 minecraft:red_concrete
fill 205 191 428 205 191 430 minecraft:polished_deepslate
setblock 205 191 431 minecraft:red_concrete
fill 205 191 432 205 191 434 minecraft:polished_deepslate
setblock 205 191 435 minecraft:red_concrete
fill 205 191 436 205 191 438 minecraft:polished_deepslate
setblock 205 191 439 minecraft:red_concrete
setblock 205 191 440 minecraft:polished_deepslate
setblock 205 191 443 minecraft:red_concrete
fill 205 191 444 207 191 444 minecraft:polished_deepslate
setblock 205 191 447 minecraft:red_concrete
fill 205 191 448 207 191 448 minecraft:polished_deepslate
setblock 205 191 451 minecraft:red_concrete
fill 205 191 452 207 191 452 minecraft:polished_deepslate
setblock 205 191 455 minecraft:red_concrete
fill 205 191 456 207 191 456 minecraft:polished_deepslate
setblock 206 191 417 minecraft:polished_deepslate
setblock 206 191 418 minecraft:red_concrete
fill 206 191 419 206 191 421 minecraft:polished_deepslate
setblock 206 191 422 minecraft:red_concrete
fill 206 191 423 206 191 425 minecraft:polished_deepslate
setblock 206 191 426 minecraft:red_concrete
fill 206 191 427 206 191 429 minecraft:polished_deepslate
setblock 206 191 430 minecraft:red_concrete
fill 206 191 431 206 191 433 minecraft:polished_deepslate
setblock 206 191 434 minecraft:red_concrete
fill 206 191 435 206 191 437 minecraft:polished_deepslate
setblock 206 191 442 minecraft:red_concrete
fill 206 191 443 207 191 443 minecraft:polished_deepslate
setblock 206 191 446 minecraft:red_concrete
fill 206 191 447 208 191 447 minecraft:polished_deepslate
setblock 206 191 450 minecraft:red_concrete
fill 206 191 451 208 191 451 minecraft:polished_deepslate
setblock 206 191 454 minecraft:red_concrete
fill 206 191 455 208 191 455 minecraft:polished_deepslate
setblock 207 191 417 minecraft:red_concrete
fill 207 191 418 207 191 420 minecraft:polished_deepslate
setblock 207 191 421 minecraft:red_concrete
fill 207 191 422 207 191 424 minecraft:polished_deepslate
setblock 207 191 425 minecraft:red_concrete
fill 207 191 426 207 191 428 minecraft:polished_deepslate
setblock 207 191 429 minecraft:red_concrete
fill 207 191 430 207 191 432 minecraft:polished_deepslate
setblock 207 191 433 minecraft:red_concrete
fill 207 191 434 207 191 435 minecraft:polished_deepslate
fill 207 191 436 207 191 437 minecraft:redstone_block
fill 207 191 441 207 191 442 minecraft:redstone_block
setblock 207 191 445 minecraft:red_concrete
fill 207 191 446 209 191 446 minecraft:polished_deepslate
setblock 207 191 449 minecraft:red_concrete
fill 207 191 450 209 191 450 minecraft:polished_deepslate
setblock 207 191 453 minecraft:red_concrete
fill 207 191 454 209 191 454 minecraft:polished_deepslate
setblock 207 191 457 minecraft:red_concrete
fill 208 191 417 208 191 419 minecraft:polished_deepslate
setblock 208 191 420 minecraft:red_concrete
fill 208 191 421 208 191 423 minecraft:polished_deepslate
setblock 208 191 424 minecraft:red_concrete
fill 208 191 425 208 191 427 minecraft:polished_deepslate
setblock 208 191 428 minecraft:red_concrete
fill 208 191 429 208 191 431 minecraft:polished_deepslate
setblock 208 191 432 minecraft:red_concrete
fill 208 191 433 208 191 434 minecraft:polished_deepslate
setblock 208 191 435 minecraft:redstone_block
fill 208 191 438 212 192 440 minecraft:red_concrete
setblock 208 191 443 minecraft:redstone_block
setblock 208 191 444 minecraft:red_concrete
fill 208 191 445 209 191 445 minecraft:polished_deepslate
setblock 208 191 448 minecraft:red_concrete
fill 208 191 449 210 191 449 minecraft:polished_deepslate
setblock 208 191 452 minecraft:red_concrete
fill 208 191 453 210 191 453 minecraft:polished_deepslate
setblock 208 191 456 minecraft:red_concrete
fill 208 191 457 210 191 457 minecraft:polished_deepslate
fill 209 191 417 209 191 418 minecraft:polished_deepslate
setblock 209 191 419 minecraft:red_concrete
fill 209 191 420 209 191 422 minecraft:polished_deepslate
setblock 209 191 423 minecraft:red_concrete
fill 209 191 424 209 191 426 minecraft:polished_deepslate
setblock 209 191 427 minecraft:red_concrete
fill 209 191 428 209 191 430 minecraft:polished_deepslate
setblock 209 191 431 minecraft:red_concrete
fill 209 191 432 209 191 433 minecraft:polished_deepslate
setblock 209 191 434 minecraft:redstone_block
fill 209 191 441 212 192 442 minecraft:red_concrete
setblock 209 191 444 minecraft:redstone_block
setblock 209 191 447 minecraft:red_concrete
fill 209 191 448 211 191 448 minecraft:polished_deepslate
setblock 209 191 451 minecraft:red_concrete
fill 209 191 452 211 191 452 minecraft:polished_deepslate
setblock 209 191 455 minecraft:red_concrete
fill 209 191 456 211 191 456 minecraft:polished_deepslate
setblock 210 191 417 minecraft:polished_deepslate
setblock 210 191 418 minecraft:red_concrete
fill 210 191 419 210 191 421 minecraft:polished_deepslate
setblock 210 191 422 minecraft:red_concrete
fill 210 191 423 210 191 425 minecraft:polished_deepslate
setblock 210 191 426 minecraft:red_concrete
fill 210 191 427 210 191 429 minecraft:polished_deepslate
setblock 210 191 430 minecraft:red_concrete
fill 210 191 431 211 191 432 minecraft:polished_deepslate
fill 210 191 444 213 191 444 minecraft:red_concrete
setblock 210 191 446 minecraft:red_concrete
fill 210 191 447 212 191 447 minecraft:polished_deepslate
setblock 210 191 450 minecraft:red_concrete
fill 210 191 451 212 191 451 minecraft:polished_deepslate
setblock 210 191 454 minecraft:red_concrete
fill 210 191 455 212 191 455 minecraft:polished_deepslate
setblock 211 191 417 minecraft:red_concrete
fill 211 191 418 211 191 420 minecraft:polished_deepslate
setblock 211 191 421 minecraft:red_concrete
fill 211 191 422 211 191 424 minecraft:polished_deepslate
setblock 211 191 425 minecraft:red_concrete
fill 211 191 426 211 191 428 minecraft:polished_deepslate
setblock 211 191 429 minecraft:red_concrete
fill 211 191 430 213 191 430 minecraft:polished_deepslate
fill 211 191 433 214 191 433 minecraft:redstone_block
fill 211 191 443 212 192 443 minecraft:red_concrete
fill 211 191 445 214 191 445 minecraft:redstone_block
fill 211 191 446 213 191 446 minecraft:polished_deepslate
setblock 211 191 449 minecraft:red_concrete
fill 211 191 450 213 191 450 minecraft:polished_deepslate
setblock 211 191 453 minecraft:red_concrete
fill 211 191 454 213 191 454 minecraft:polished_deepslate
setblock 211 191 457 minecraft:red_concrete
fill 212 191 417 212 191 419 minecraft:polished_deepslate
setblock 212 191 420 minecraft:red_concrete
fill 212 191 421 212 191 423 minecraft:polished_deepslate
setblock 212 191 424 minecraft:red_concrete
fill 212 191 425 212 191 427 minecraft:polished_deepslate
setblock 212 191 428 minecraft:red_concrete
fill 212 191 429 214 191 429 minecraft:polished_deepslate
setblock 212 191 431 minecraft:polished_deepslate
setblock 212 191 432 minecraft:red_concrete
setblock 212 191 448 minecraft:red_concrete
fill 212 191 449 214 191 449 minecraft:polished_deepslate
setblock 212 191 452 minecraft:red_concrete
fill 212 191 453 214 191 453 minecraft:polished_deepslate
setblock 212 191 456 minecraft:red_concrete
fill 212 191 457 214 191 457 minecraft:polished_deepslate
fill 213 191 417 213 191 418 minecraft:polished_deepslate
setblock 213 191 419 minecraft:red_concrete
fill 213 191 420 213 191 422 minecraft:polished_deepslate
setblock 213 191 423 minecraft:red_concrete
fill 213 191 424 213 191 426 minecraft:polished_deepslate
setblock 213 191 427 minecraft:red_concrete
fill 213 191 428 215 191 428 minecraft:polished_deepslate
setblock 213 191 431 minecraft:red_concrete
fill 213 191 432 215 191 432 minecraft:polished_deepslate
fill 213 191 438 213 193 438 minecraft:red_concrete
fill 213 191 439 213 191 443 minecraft:shroomlight
setblock 213 191 447 minecraft:red_concrete
fill 213 191 448 215 191 448 minecraft:polished_deepslate
setblock 213 191 451 minecraft:red_concrete
fill 213 191 452 215 191 452 minecraft:polished_deepslate
setblock 213 191 455 minecraft:red_concrete
fill 213 191 456 215 191 456 minecraft:polished_deepslate
setblock 214 191 417 minecraft:polished_deepslate
setblock 214 191 418 minecraft:red_concrete
fill 214 191 419 214 191 421 minecraft:polished_deepslate
setblock 214 191 422 minecraft:red_concrete
fill 214 191 423 214 191 425 minecraft:polished_deepslate
setblock 214 191 426 minecraft:red_concrete
fill 214 191 427 216 191 427 minecraft:polished_deepslate
setblock 214 191 430 minecraft:red_concrete
fill 214 191 431 216 191 431 minecraft:polished_deepslate
fill 214 191 438 214 191 439 minecraft:shroomlight
fill 214 191 443 214 191 444 minecraft:shroomlight
setblock 214 191 446 minecraft:red_concrete
fill 214 191 447 216 191 447 minecraft:polished_deepslate
setblock 214 191 450 minecraft:red_concrete
fill 214 191 451 216 191 451 minecraft:polished_deepslate
setblock 214 191 454 minecraft:red_concrete
fill 214 191 455 216 191 455 minecraft:polished_deepslate
setblock 215 191 417 minecraft:red_concrete
fill 215 191 418 215 191 420 minecraft:polished_deepslate
setblock 215 191 421 minecraft:red_concrete
fill 215 191 422 215 191 424 minecraft:polished_deepslate
setblock 215 191 425 minecraft:red_concrete
fill 215 191 426 217 191 426 minecraft:polished_deepslate
setblock 215 191 429 minecraft:red_concrete
fill 215 191 430 217 191 430 minecraft:polished_deepslate
fill 215 191 436 216 192 437 minecraft:red_concrete
fill 215 191 438 218 191 438 minecraft:shroomlight
fill 215 191 444 218 191 444 minecraft:shroomlight
fill 215 191 446 217 191 446 minecraft:polished_deepslate
setblock 215 191 449 minecraft:red_concrete
fill 215 191 450 217 191 450 minecraft:polished_deepslate
setblock 215 191 453 minecraft:red_concrete
fill 215 191 454 217 191 454 minecraft:polished_deepslate
setblock 215 191 457 minecraft:red_concrete
fill 216 191 417 216 191 419 minecraft:polished_deepslate
setblock 216 191 420 minecraft:red_concrete
fill 216 191 421 216 191 423 minecraft:polished_deepslate
setblock 216 191 424 minecraft:red_concrete
fill 216 191 425 218 191 425 minecraft:polished_deepslate
setblock 216 191 428 minecraft:red_concrete
fill 216 191 429 218 191 429 minecraft:polished_deepslate
setblock 216 191 432 minecraft:red_concrete
fill 216 191 433 218 191 433 minecraft:polished_deepslate
setblock 216 191 434 minecraft:redstone_block
fill 216 191 445 218 191 445 minecraft:polished_deepslate
setblock 216 191 448 minecraft:red_concrete
fill 216 191 449 218 191 449 minecraft:polished_deepslate
setblock 216 191 452 minecraft:red_concrete
fill 216 191 453 218 191 453 minecraft:polished_deepslate
setblock 216 191 456 minecraft:red_concrete
fill 216 191 457 218 191 457 minecraft:polished_deepslate
fill 217 191 417 217 191 418 minecraft:polished_deepslate
setblock 217 191 419 minecraft:red_concrete
fill 217 191 420 217 191 422 minecraft:polished_deepslate
setblock 217 191 423 minecraft:red_concrete
fill 217 191 424 219 191 424 minecraft:polished_deepslate
setblock 217 191 427 minecraft:red_concrete
fill 217 191 428 219 191 428 minecraft:polished_deepslate
setblock 217 191 431 minecraft:red_concrete
fill 217 191 432 219 191 432 minecraft:polished_deepslate
setblock 217 191 434 minecraft:polished_deepslate
setblock 217 191 435 minecraft:redstone_block
setblock 217 191 447 minecraft:red_concrete
fill 217 191 448 219 191 448 minecraft:polished_deepslate
setblock 217 191 451 minecraft:red_concrete
fill 217 191 452 219 191 452 minecraft:polished_deepslate
setblock 217 191 455 minecraft:red_concrete
fill 217 191 456 219 191 456 minecraft:polished_deepslate
setblock 218 191 417 minecraft:polished_deepslate
setblock 218 191 418 minecraft:red_concrete
fill 218 191 419 218 191 421 minecraft:polished_deepslate
setblock 218 191 422 minecraft:red_concrete
fill 218 191 423 220 191 423 minecraft:polished_deepslate
setblock 218 191 426 minecraft:red_concrete
fill 218 191 427 220 191 427 minecraft:polished_deepslate
setblock 218 191 430 minecraft:red_concrete
fill 218 191 431 220 191 431 minecraft:polished_deepslate
setblock 218 191 434 minecraft:red_concrete
fill 218 191 435 220 191 435 minecraft:polished_deepslate
fill 218 191 436 218 191 437 minecraft:redstone_block
fill 218 191 439 219 191 439 minecraft:shroomlight
fill 218 191 443 219 191 443 minecraft:shroomlight
setblock 218 191 446 minecraft:red_concrete
fill 218 191 447 220 191 447 minecraft:polished_deepslate
setblock 218 191 450 minecraft:red_concrete
fill 218 191 451 220 191 451 minecraft:polished_deepslate
setblock 218 191 454 minecraft:red_concrete
fill 218 191 455 220 191 455 minecraft:polished_deepslate
setblock 219 191 417 minecraft:red_concrete
fill 219 191 418 219 191 420 minecraft:polished_deepslate
setblock 219 191 421 minecraft:red_concrete
fill 219 191 422 221 191 422 minecraft:polished_deepslate
setblock 219 191 425 minecraft:red_concrete
fill 219 191 426 221 191 426 minecraft:polished_deepslate
setblock 219 191 429 minecraft:red_concrete
fill 219 191 430 221 191 430 minecraft:polished_deepslate
setblock 219 191 433 minecraft:red_concrete
fill 219 191 434 221 191 434 minecraft:polished_deepslate
setblock 219 191 436 minecraft:polished_deepslate
setblock 219 191 437 minecraft:red_concrete
setblock 219 191 438 minecraft:redstone_block
fill 219 191 440 219 191 442 minecraft:shroomlight
setblock 219 191 444 minecraft:polished_deepslate
setblock 219 191 445 minecraft:red_concrete
fill 219 191 446 221 191 446 minecraft:polished_deepslate
setblock 219 191 449 minecraft:red_concrete
fill 219 191 450 221 191 450 minecraft:polished_deepslate
setblock 219 191 453 minecraft:red_concrete
fill 219 191 454 221 191 454 minecraft:polished_deepslate
setblock 219 191 457 minecraft:red_concrete
fill 220 191 417 220 191 419 minecraft:polished_deepslate
setblock 220 191 420 minecraft:red_concrete
fill 220 191 421 222 191 421 minecraft:polished_deepslate
setblock 220 191 424 minecraft:red_concrete
fill 220 191 425 222 191 425 minecraft:polished_deepslate
setblock 220 191 428 minecraft:red_concrete
fill 220 191 429 222 191 429 minecraft:polished_deepslate
setblock 220 191 432 minecraft:red_concrete
fill 220 191 433 222 191 433 minecraft:polished_deepslate
setblock 220 191 436 minecraft:red_concrete
fill 220 191 437 220 191 439 minecraft:polished_deepslate
setblock 220 191 440 minecraft:red_concrete
fill 220 191 441 220 191 443 minecraft:polished_deepslate
setblock 220 191 444 minecraft:red_concrete
fill 220 191 445 222 191 445 minecraft:polished_deepslate
setblock 220 191 448 minecraft:red_concrete
fill 220 191 449 222 191 449 minecraft:polished_deepslate
setblock 220 191 452 minecraft:red_concrete
fill 220 191 453 222 191 453 minecraft:polished_deepslate
setblock 220 191 456 minecraft:red_concrete
fill 220 191 457 222 191 457 minecraft:polished_deepslate
fill 221 191 417 221 191 418 minecraft:polished_deepslate
setblock 221 191 419 minecraft:red_concrete
fill 221 191 420 223 191 420 minecraft:polished_deepslate
setblock 221 191 423 minecraft:red_concrete
fill 221 191 424 223 191 424 minecraft:polished_deepslate
setblock 221 191 427 minecraft:red_concrete
fill 221 191 428 223 191 428 minecraft:polished_deepslate
setblock 221 191 431 minecraft:red_concrete
fill 221 191 432 223 191 432 minecraft:polished_deepslate
setblock 221 191 435 minecraft:red_concrete
fill 221 191 436 221 191 438 minecraft:polished_deepslate
setblock 221 191 439 minecraft:red_concrete
fill 221 191 440 221 191 442 minecraft:polished_deepslate
setblock 221 191 443 minecraft:red_concrete
fill 221 191 444 223 191 444 minecraft:polished_deepslate
setblock 221 191 447 minecraft:red_concrete
fill 221 191 448 223 191 448 minecraft:polished_deepslate
setblock 221 191 451 minecraft:red_concrete
fill 221 191 452 223 191 452 minecraft:polished_deepslate
setblock 221 191 455 minecraft:red_concrete
fill 221 191 456 223 191 456 minecraft:polished_deepslate
setblock 222 191 417 minecraft:polished_deepslate
setblock 222 191 418 minecraft:red_concrete
fill 222 191 419 224 191 419 minecraft:polished_deepslate
setblock 222 191 422 minecraft:red_concrete
fill 222 191 423 224 191 423 minecraft:polished_deepslate
setblock 222 191 426 minecraft:red_concrete
fill 222 191 427 224 191 427 minecraft:polished_deepslate
setblock 222 191 430 minecraft:red_concrete
fill 222 191 431 224 191 431 minecraft:polished_deepslate
setblock 222 191 434 minecraft:red_concrete
fill 222 191 435 222 191 437 minecraft:polished_deepslate
setblock 222 191 438 minecraft:red_concrete
fill 222 191 439 222 191 441 minecraft:polished_deepslate
setblock 222 191 442 minecraft:red_concrete
fill 222 191 443 224 191 443 minecraft:polished_deepslate
setblock 222 191 446 minecraft:red_concrete
fill 222 191 447 224 191 447 minecraft:polished_deepslate
setblock 222 191 450 minecraft:red_concrete
fill 222 191 451 224 191 451 minecraft:polished_deepslate
setblock 222 191 454 minecraft:red_concrete
fill 222 191 455 224 191 455 minecraft:polished_deepslate
setblock 223 191 417 minecraft:red_concrete
fill 223 191 418 225 191 418 minecraft:polished_deepslate
setblock 223 191 421 minecraft:red_concrete
fill 223 191 422 225 191 422 minecraft:polished_deepslate
setblock 223 191 425 minecraft:red_concrete
fill 223 191 426 225 191 426 minecraft:polished_deepslate
setblock 223 191 429 minecraft:red_concrete
fill 223 191 430 225 191 430 minecraft:polished_deepslate
setblock 223 191 433 minecraft:red_concrete
fill 223 191 434 223 191 436 minecraft:polished_deepslate
setblock 223 191 437 minecraft:red_concrete
fill 223 191 438 223 191 440 minecraft:polished_deepslate
setblock 223 191 441 minecraft:red_concrete
fill 223 191 442 225 191 442 minecraft:polished_deepslate
setblock 223 191 445 minecraft:red_concrete
fill 223 191 446 225 191 446 minecraft:polished_deepslate
setblock 223 191 449 minecraft:red_concrete
fill 223 191 450 225 191 450 minecraft:polished_deepslate
setblock 223 191 453 minecraft:red_concrete
fill 223 191 454 225 191 454 minecraft:polished_deepslate
setblock 223 191 457 minecraft:red_concrete
fill 224 191 417 226 191 417 minecraft:polished_deepslate
setblock 224 191 420 minecraft:red_concrete
fill 224 191 421 226 191 421 minecraft:polished_deepslate
setblock 224 191 424 minecraft:red_concrete
fill 224 191 425 226 191 425 minecraft:polished_deepslate
setblock 224 191 428 minecraft:red_concrete
fill 224 191 429 226 191 429 minecraft:polished_deepslate
setblock 224 191 432 minecraft:red_concrete
fill 224 191 433 224 191 435 minecraft:polished_deepslate
setblock 224 191 436 minecraft:red_concrete
fill 224 191 437 224 191 439 minecraft:polished_deepslate
setblock 224 191 440 minecraft:red_concrete
fill 224 191 441 226 191 441 minecraft:polished_deepslate
setblock 224 191 444 minecraft:red_concrete
fill 224 191 445 226 191 445 minecraft:polished_deepslate
setblock 224 191 448 minecraft:red_concrete
fill 224 191 449 226 191 449 minecraft:polished_deepslate
setblock 224 191 452 minecraft:red_concrete
fill 224 191 453 226 191 453 minecraft:polished_deepslate
setblock 224 191 456 minecraft:red_concrete
fill 224 191 457 226 191 457 minecraft:polished_deepslate
setblock 225 191 419 minecraft:red_concrete
fill 225 191 420 227 191 420 minecraft:polished_deepslate
setblock 225 191 423 minecraft:red_concrete
fill 225 191 424 227 191 424 minecraft:polished_deepslate
setblock 225 191 427 minecraft:red_concrete
fill 225 191 428 227 191 428 minecraft:polished_deepslate
setblock 225 191 431 minecraft:red_concrete
fill 225 191 432 225 191 434 minecraft:polished_deepslate
setblock 225 191 435 minecraft:red_concrete
fill 225 191 436 225 191 438 minecraft:polished_deepslate
setblock 225 191 439 minecraft:red_concrete
fill 225 191 440 227 191 440 minecraft:polished_deepslate
setblock 225 191 443 minecraft:red_concrete
fill 225 191 444 227 191 444 minecraft:polished_deepslate
setblock 225 191 447 minecraft:red_concrete
fill 225 191 448 227 191 448 minecraft:polished_deepslate
setblock 225 191 451 minecraft:red_concrete
fill 225 191 452 227 191 452 minecraft:polished_deepslate
setblock 225 191 455 minecraft:red_concrete
fill 225 191 456 227 191 456 minecraft:polished_deepslate
setblock 226 191 418 minecraft:red_concrete
fill 226 191 419 228 191 419 minecraft:polished_deepslate
setblock 226 191 422 minecraft:red_concrete
fill 226 191 423 228 191 423 minecraft:polished_deepslate
setblock 226 191 426 minecraft:red_concrete
fill 226 191 427 228 191 427 minecraft:polished_deepslate
setblock 226 191 430 minecraft:red_concrete
fill 226 191 431 226 191 433 minecraft:polished_deepslate
setblock 226 191 434 minecraft:red_concrete
fill 226 191 435 226 191 437 minecraft:polished_deepslate
setblock 226 191 438 minecraft:red_concrete
fill 226 191 439 228 191 439 minecraft:polished_deepslate
setblock 226 191 442 minecraft:red_concrete
fill 226 191 443 228 191 443 minecraft:polished_deepslate
setblock 226 191 446 minecraft:red_concrete
fill 226 191 447 228 191 447 minecraft:polished_deepslate
setblock 226 191 450 minecraft:red_concrete
fill 226 191 451 228 191 451 minecraft:polished_deepslate
setblock 226 191 454 minecraft:red_concrete
fill 226 191 455 228 191 455 minecraft:polished_deepslate
setblock 227 191 417 minecraft:red_concrete
fill 227 191 418 229 191 418 minecraft:polished_deepslate
setblock 227 191 421 minecraft:red_concrete
fill 227 191 422 229 191 422 minecraft:polished_deepslate
setblock 227 191 425 minecraft:red_concrete
fill 227 191 426 229 191 426 minecraft:polished_deepslate
setblock 227 191 429 minecraft:red_concrete
fill 227 191 430 227 191 432 minecraft:polished_deepslate
setblock 227 191 433 minecraft:red_concrete
fill 227 191 434 227 191 436 minecraft:polished_deepslate
setblock 227 191 437 minecraft:red_concrete
fill 227 191 438 229 191 438 minecraft:polished_deepslate
setblock 227 191 441 minecraft:red_concrete
fill 227 191 442 229 191 442 minecraft:polished_deepslate
setblock 227 191 445 minecraft:red_concrete
fill 227 191 446 229 191 446 minecraft:polished_deepslate
setblock 227 191 449 minecraft:red_concrete
fill 227 191 450 229 191 450 minecraft:polished_deepslate
setblock 227 191 453 minecraft:red_concrete
fill 227 191 454 229 191 454 minecraft:polished_deepslate
setblock 227 191 457 minecraft:red_concrete
fill 228 191 417 229 191 417 minecraft:polished_deepslate
setblock 228 191 420 minecraft:red_concrete
fill 228 191 421 229 191 421 minecraft:polished_deepslate
setblock 228 191 424 minecraft:red_concrete
fill 228 191 425 229 191 425 minecraft:polished_deepslate
setblock 228 191 428 minecraft:red_concrete
fill 228 191 429 228 191 431 minecraft:polished_deepslate
setblock 228 191 432 minecraft:red_concrete
fill 228 191 433 228 191 435 minecraft:polished_deepslate
setblock 228 191 436 minecraft:red_concrete
fill 228 191 437 229 191 437 minecraft:polished_deepslate
setblock 228 191 440 minecraft:red_concrete
fill 228 191 441 229 191 441 minecraft:polished_deepslate
setblock 228 191 444 minecraft:red_concrete
fill 228 191 445 229 191 445 minecraft:polished_deepslate
setblock 228 191 448 minecraft:red_concrete
fill 228 191 449 229 191 449 minecraft:polished_deepslate
setblock 228 191 452 minecraft:red_concrete
fill 228 191 453 229 191 453 minecraft:polished_deepslate
setblock 228 191 456 minecraft:red_concrete
fill 228 191 457 229 191 457 minecraft:polished_deepslate
setblock 229 191 419 minecraft:red_concrete
setblock 229 191 420 minecraft:polished_deepslate
setblock 229 191 423 minecraft:red_concrete
setblock 229 191 424 minecraft:polished_deepslate
setblock 229 191 427 minecraft:red_concrete
fill 229 191 428 229 191 430 minecraft:polished_deepslate
setblock 229 191 431 minecraft:red_concrete
fill 229 191 432 229 191 434 minecraft:polished_deepslate
setblock 229 191 435 minecraft:red_concrete
setblock 229 191 436 minecraft:polished_deepslate
setblock 229 191 439 minecraft:red_concrete
setblock 229 191 440 minecraft:polished_deepslate
setblock 229 191 443 minecraft:red_concrete
setblock 229 191 444 minecraft:polished_deepslate
setblock 229 191 447 minecraft:red_concrete
setblock 229 191 448 minecraft:polished_deepslate
setblock 229 191 451 minecraft:red_concrete
setblock 229 191 452 minecraft:polished_deepslate
setblock 229 191 455 minecraft:red_concrete
setblock 229 191 456 minecraft:polished_deepslate
fill 207 192 438 207 192 440 minecraft:redstone_block
fill 208 192 436 208 192 437 minecraft:redstone_block
fill 208 192 441 208 192 442 minecraft:redstone_block
fill 209 192 435 210 192 435 minecraft:redstone_block
fill 209 192 443 210 192 443 minecraft:redstone_block
fill 210 192 434 215 192 434 minecraft:redstone_block
fill 210 192 444 215 192 444 minecraft:redstone_block
fill 213 192 439 213 192 443 minecraft:red_concrete
fill 214 192 438 214 193 439 minecraft:red_concrete
setblock 214 192 443 minecraft:red_concrete
fill 215 192 435 216 192 435 minecraft:redstone_block
fill 215 192 438 217 192 438 minecraft:red_concrete
fill 217 192 436 217 192 437 minecraft:redstone_block
fill 218 192 438 218 192 439 minecraft:redstone_block
setblock 191 193 419 minecraft:light[level=13]
setblock 191 193 427 minecraft:light[level=13]
setblock 191 193 435 minecraft:light[level=13]
setblock 191 193 443 minecraft:light[level=13]
setblock 191 193 451 minecraft:light[level=13]
setblock 199 193 419 minecraft:light[level=13]
setblock 199 193 427 minecraft:light[level=13]
setblock 199 193 435 minecraft:light[level=13]
setblock 199 193 443 minecraft:light[level=13]
setblock 199 193 451 minecraft:light[level=13]
setblock 207 193 419 minecraft:light[level=13]
setblock 207 193 427 minecraft:light[level=13]
setblock 207 193 435 minecraft:light[level=13]
setblock 207 193 443 minecraft:light[level=13]
setblock 207 193 451 minecraft:light[level=13]
fill 208 193 438 209 193 440 minecraft:redstone_block
fill 209 193 436 210 193 437 minecraft:redstone_block
fill 209 193 441 210 193 442 minecraft:redstone_block
fill 210 193 438 212 193 440 minecraft:red_concrete
fill 211 193 435 214 193 436 minecraft:redstone_block
fill 211 193 441 213 193 441 minecraft:red_concrete
fill 211 193 442 213 193 443 minecraft:redstone_block
fill 213 193 439 213 193 440 minecraft:red_concrete
setblock 214 193 443 minecraft:redstone_block
setblock 215 193 419 minecraft:light[level=13]
setblock 215 193 427 minecraft:light[level=13]
setblock 215 193 435 minecraft:light[level=13]
fill 215 193 436 216 193 437 minecraft:redstone_block
setblock 215 193 438 minecraft:red_concrete
setblock 215 193 451 minecraft:light[level=13]
fill 216 193 438 217 193 438 minecraft:redstone_block
setblock 223 193 419 minecraft:light[level=13]
setblock 223 193 427 minecraft:light[level=13]
setblock 223 193 435 minecraft:light[level=13]
setblock 223 193 443 minecraft:light[level=13]
setblock 223 193 451 minecraft:light[level=13]
fill 210 194 438 214 194 440 minecraft:redstone_block
fill 211 194 437 214 194 437 minecraft:redstone_block
fill 211 194 441 214 194 441 minecraft:redstone_block
setblock 215 194 438 minecraft:redstone_block
fill 189 195 417 191 231 417 minecraft:polished_deepslate
fill 189 195 419 189 198 421 minecraft:orange_stained_glass
fill 189 195 427 189 231 429 minecraft:polished_deepslate
fill 189 195 435 194 204 441 minecraft:polished_deepslate
fill 189 195 451 189 231 453 minecraft:polished_deepslate
fill 190 195 420 190 198 420 minecraft:orange_stained_glass
fill 190 195 442 193 197 442 minecraft:polished_deepslate
fill 195 195 436 195 210 440 minecraft:polished_deepslate
fill 195 195 457 197 231 457 minecraft:polished_deepslate
fill 201 195 417 203 231 417 minecraft:polished_deepslate
fill 207 195 457 209 231 457 minecraft:polished_deepslate
fill 213 195 417 215 231 417 minecraft:polished_deepslate
fill 219 195 457 221 231 457 minecraft:polished_deepslate
fill 223 195 436 229 210 440 minecraft:polished_deepslate
fill 224 195 435 229 222 435 minecraft:polished_deepslate
fill 224 195 441 229 201 441 minecraft:polished_deepslate
fill 225 195 417 227 231 417 minecraft:polished_deepslate
fill 225 195 442 228 197 442 minecraft:polished_deepslate
fill 229 195 425 229 231 427 minecraft:polished_deepslate
fill 229 195 449 229 231 451 minecraft:polished_deepslate
fill 190 196 419 190 198 419 minecraft:orange_stained_glass
fill 190 196 421 190 198 421 minecraft:orange_stained_glass
fill 191 196 420 191 198 420 minecraft:orange_stained_glass
fill 191 197 419 192 198 419 minecraft:orange_stained_glass
fill 191 197 421 192 198 421 minecraft:orange_stained_glass
fill 191 197 434 192 222 434 minecraft:polished_deepslate
fill 192 197 420 192 199 420 minecraft:orange_stained_glass
fill 226 197 434 227 222 434 minecraft:polished_deepslate
fill 191 198 442 193 198 442 minecraft:polished_deepslate
fill 193 198 419 193 198 421 minecraft:orange_stained_glass
fill 194 198 420 194 199 420 minecraft:orange_stained_glass
fill 225 198 442 227 198 442 minecraft:polished_deepslate
fill 191 199 442 192 200 442 minecraft:polished_deepslate
setblock 193 199 420 minecraft:orange_stained_glass
fill 193 199 434 193 222 434 minecraft:polished_deepslate
setblock 195 199 420 minecraft:orange_stained_glass
fill 225 199 434 225 222 434 minecraft:polished_deepslate
fill 226 199 442 227 200 442 minecraft:polished_deepslate
fill 190 200 426 190 205 428 minecraft:polished_deepslate
fill 190 200 450 190 205 452 minecraft:polished_deepslate
fill 196 200 456 198 205 456 minecraft:polished_deepslate
fill 200 200 418 202 205 418 minecraft:polished_deepslate
fill 208 200 456 210 205 456 minecraft:polished_deepslate
fill 212 200 418 214 205 418 minecraft:polished_deepslate
fill 220 200 456 222 205 456 minecraft:polished_deepslate
fill 224 200 418 226 205 418 minecraft:polished_deepslate
fill 228 200 426 228 205 428 minecraft:polished_deepslate
fill 228 200 450 228 205 452 minecraft:polished_deepslate
fill 190 201 434 190 222 434 minecraft:polished_deepslate
setblock 191 201 419 minecraft:light[level=13]
setblock 191 201 427 minecraft:light[level=13]
setblock 191 201 443 minecraft:light[level=13]
setblock 191 201 451 minecraft:light[level=13]
setblock 192 201 442 minecraft:polished_deepslate
setblock 199 201 419 minecraft:light[level=13]
setblock 199 201 427 minecraft:light[level=13]
setblock 199 201 435 minecraft:light[level=13]
setblock 199 201 443 minecraft:light[level=13]
setblock 199 201 451 minecraft:light[level=13]
fill 202 201 451 202 218 451 minecraft:iron_block
schedule function dropper:buildpart/100_2 1t
