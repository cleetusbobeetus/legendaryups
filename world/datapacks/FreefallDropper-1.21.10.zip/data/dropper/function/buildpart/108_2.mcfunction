setblock 11 169 490 minecraft:light[level=12]
setblock 11 169 498 minecraft:light[level=12]
fill 15 169 504 16 170 504 minecraft:bookshelf
fill 16 169 464 17 170 464 minecraft:bookshelf
setblock 19 169 466 minecraft:light[level=12]
setblock 19 169 474 minecraft:light[level=12]
setblock 19 169 482 minecraft:light[level=12]
setblock 19 169 498 minecraft:light[level=12]
fill 22 169 504 23 170 504 minecraft:bookshelf
fill 23 169 464 24 170 464 minecraft:bookshelf
setblock 27 169 466 minecraft:light[level=12]
setblock 27 169 474 minecraft:light[level=12]
setblock 27 169 482 minecraft:light[level=12]
setblock 27 169 490 minecraft:light[level=12]
setblock 27 169 498 minecraft:light[level=12]
fill 29 169 504 30 170 504 minecraft:bookshelf
fill 30 169 464 31 170 464 minecraft:bookshelf
setblock 35 169 466 minecraft:light[level=12]
setblock 35 169 474 minecraft:light[level=12]
setblock 35 169 482 minecraft:light[level=12]
setblock 35 169 490 minecraft:light[level=12]
setblock 35 169 498 minecraft:light[level=12]
fill 36 169 504 37 170 504 minecraft:bookshelf
fill 37 169 464 38 170 464 minecraft:bookshelf
fill 37 169 482 41 171 492 minecraft:bookshelf
fill 39 169 481 41 169 481 minecraft:bookshelf
fill 41 169 467 41 170 468 minecraft:bookshelf
fill 41 169 474 41 170 475 minecraft:bookshelf
fill 41 169 495 41 170 496 minecraft:bookshelf
fill 41 169 502 41 170 503 minecraft:bookshelf
fill 1 170 464 1 170 468 minecraft:bookshelf
fill 1 170 471 1 170 475 minecraft:bookshelf
fill 1 170 478 1 170 482 minecraft:bookshelf
fill 1 170 485 1 170 489 minecraft:bookshelf
fill 1 170 492 1 170 496 minecraft:bookshelf
fill 1 170 499 1 170 503 minecraft:bookshelf
fill 3 170 504 7 170 504 minecraft:bookshelf
fill 4 170 464 8 170 464 minecraft:bookshelf
fill 10 170 504 14 170 504 minecraft:bookshelf
fill 11 170 464 15 170 464 minecraft:bookshelf
fill 17 170 504 21 170 504 minecraft:bookshelf
fill 18 170 464 22 170 464 minecraft:bookshelf
fill 24 170 504 28 170 504 minecraft:bookshelf
fill 25 170 464 29 170 464 minecraft:bookshelf
fill 31 170 504 35 170 504 minecraft:bookshelf
fill 32 170 464 36 170 464 minecraft:bookshelf
fill 38 170 504 41 170 504 minecraft:bookshelf
fill 39 170 464 41 170 464 minecraft:bookshelf
fill 41 170 465 41 170 466 minecraft:bookshelf
fill 41 170 469 41 170 473 minecraft:bookshelf
fill 41 170 476 41 170 481 minecraft:bookshelf
fill 41 170 493 41 170 494 minecraft:bookshelf
fill 41 170 497 41 170 501 minecraft:bookshelf
setblock 1 171 465 minecraft:bookshelf
fill 1 171 469 1 223 469 minecraft:bookshelf
setblock 1 171 472 minecraft:bookshelf
fill 1 171 476 1 223 476 minecraft:bookshelf
setblock 1 171 479 minecraft:bookshelf
fill 1 171 483 1 223 483 minecraft:bookshelf
setblock 1 171 486 minecraft:bookshelf
fill 1 171 490 1 223 490 minecraft:bookshelf
setblock 1 171 493 minecraft:bookshelf
fill 1 171 497 1 223 497 minecraft:bookshelf
setblock 1 171 500 minecraft:bookshelf
fill 1 171 504 1 223 504 minecraft:bookshelf
fill 3 171 464 3 223 464 minecraft:bookshelf
setblock 4 171 504 minecraft:bookshelf
setblock 7 171 464 minecraft:bookshelf
fill 8 171 504 8 223 504 minecraft:bookshelf
fill 10 171 464 10 223 464 minecraft:bookshelf
setblock 11 171 504 minecraft:bookshelf
setblock 14 171 464 minecraft:bookshelf
fill 15 171 504 15 223 504 minecraft:bookshelf
fill 17 171 464 17 223 464 minecraft:bookshelf
setblock 18 171 504 minecraft:bookshelf
setblock 21 171 464 minecraft:bookshelf
fill 22 171 504 22 223 504 minecraft:bookshelf
fill 24 171 464 24 223 464 minecraft:bookshelf
setblock 25 171 504 minecraft:bookshelf
setblock 28 171 464 minecraft:bookshelf
fill 29 171 504 29 223 504 minecraft:bookshelf
fill 31 171 464 31 223 464 minecraft:bookshelf
setblock 32 171 504 minecraft:bookshelf
setblock 35 171 464 minecraft:bookshelf
fill 36 171 504 36 223 504 minecraft:bookshelf
fill 38 171 464 38 223 464 minecraft:bookshelf
setblock 39 171 504 minecraft:bookshelf
setblock 41 171 465 minecraft:bookshelf
fill 41 171 468 41 223 468 minecraft:bookshelf
setblock 41 171 472 minecraft:bookshelf
fill 41 171 475 41 223 475 minecraft:bookshelf
setblock 41 171 479 minecraft:bookshelf
fill 41 171 493 41 172 493 minecraft:bookshelf
fill 41 171 496 41 223 496 minecraft:bookshelf
setblock 41 171 500 minecraft:bookshelf
fill 41 171 503 41 223 503 minecraft:bookshelf
setblock 1 172 466 minecraft:bookshelf
setblock 1 172 473 minecraft:bookshelf
setblock 1 172 480 minecraft:bookshelf
setblock 1 172 487 minecraft:bookshelf
setblock 1 172 494 minecraft:bookshelf
setblock 1 172 501 minecraft:bookshelf
fill 2 172 469 3 173 469 minecraft:gold_block
setblock 5 172 504 minecraft:bookshelf
setblock 6 172 464 minecraft:bookshelf
setblock 12 172 504 minecraft:bookshelf
setblock 13 172 464 minecraft:bookshelf
setblock 19 172 504 minecraft:bookshelf
setblock 20 172 464 minecraft:bookshelf
setblock 26 172 504 minecraft:bookshelf
setblock 27 172 464 minecraft:bookshelf
setblock 33 172 504 minecraft:bookshelf
setblock 34 172 464 minecraft:bookshelf
setblock 37 172 482 minecraft:ochre_froglight
fill 37 172 483 37 192 483 minecraft:bookshelf
setblock 37 172 484 minecraft:ochre_froglight
fill 37 172 485 37 192 485 minecraft:bookshelf
setblock 37 172 486 minecraft:ochre_froglight
fill 37 172 487 37 192 487 minecraft:bookshelf
setblock 37 172 488 minecraft:ochre_froglight
fill 37 172 489 37 192 489 minecraft:bookshelf
setblock 37 172 490 minecraft:ochre_froglight
fill 37 172 491 37 192 491 minecraft:bookshelf
setblock 37 172 492 minecraft:ochre_froglight
fill 38 172 482 38 192 482 minecraft:bookshelf
setblock 38 172 483 minecraft:ochre_froglight
fill 38 172 484 38 192 484 minecraft:bookshelf
setblock 38 172 485 minecraft:ochre_froglight
fill 38 172 486 38 192 486 minecraft:bookshelf
setblock 38 172 487 minecraft:ochre_froglight
fill 38 172 488 38 192 488 minecraft:bookshelf
setblock 38 172 489 minecraft:ochre_froglight
fill 38 172 490 38 192 490 minecraft:bookshelf
setblock 38 172 491 minecraft:ochre_froglight
fill 38 172 492 38 192 492 minecraft:bookshelf
setblock 39 172 482 minecraft:ochre_froglight
fill 39 172 483 39 192 483 minecraft:bookshelf
setblock 39 172 484 minecraft:ochre_froglight
fill 39 172 485 39 192 485 minecraft:bookshelf
setblock 39 172 486 minecraft:ochre_froglight
fill 39 172 487 39 192 487 minecraft:bookshelf
setblock 39 172 488 minecraft:ochre_froglight
fill 39 172 489 39 192 489 minecraft:bookshelf
setblock 39 172 490 minecraft:ochre_froglight
fill 39 172 491 39 192 491 minecraft:bookshelf
setblock 39 172 492 minecraft:ochre_froglight
fill 39 172 493 40 172 495 minecraft:bookshelf
fill 40 172 482 40 192 482 minecraft:bookshelf
setblock 40 172 483 minecraft:ochre_froglight
fill 40 172 484 40 192 484 minecraft:bookshelf
setblock 40 172 485 minecraft:ochre_froglight
fill 40 172 486 40 192 486 minecraft:bookshelf
setblock 40 172 487 minecraft:ochre_froglight
fill 40 172 488 40 192 488 minecraft:bookshelf
setblock 40 172 489 minecraft:ochre_froglight
fill 40 172 490 40 192 490 minecraft:bookshelf
setblock 40 172 491 minecraft:ochre_froglight
fill 40 172 492 40 192 492 minecraft:bookshelf
setblock 40 172 504 minecraft:bookshelf
setblock 41 172 464 minecraft:bookshelf
setblock 41 172 471 minecraft:bookshelf
setblock 41 172 478 minecraft:bookshelf
setblock 41 172 482 minecraft:ochre_froglight
fill 41 172 483 41 192 483 minecraft:bookshelf
setblock 41 172 484 minecraft:ochre_froglight
fill 41 172 485 41 193 485 minecraft:bookshelf
setblock 41 172 486 minecraft:ochre_froglight
fill 41 172 487 41 192 487 minecraft:bookshelf
setblock 41 172 488 minecraft:ochre_froglight
fill 41 172 489 41 223 489 minecraft:bookshelf
setblock 41 172 490 minecraft:ochre_froglight
fill 41 172 491 41 192 491 minecraft:bookshelf
setblock 41 172 492 minecraft:ochre_froglight
fill 41 172 494 41 173 495 minecraft:bookshelf
fill 41 172 499 41 174 499 minecraft:bookshelf
setblock 1 173 467 minecraft:bookshelf
setblock 1 173 474 minecraft:bookshelf
setblock 1 173 481 minecraft:bookshelf
setblock 1 173 488 minecraft:bookshelf
setblock 1 173 495 minecraft:bookshelf
setblock 1 173 502 minecraft:bookshelf
setblock 5 173 464 minecraft:bookshelf
setblock 6 173 504 minecraft:bookshelf
setblock 12 173 464 minecraft:bookshelf
setblock 13 173 504 minecraft:bookshelf
setblock 19 173 464 minecraft:bookshelf
setblock 20 173 504 minecraft:bookshelf
setblock 26 173 464 minecraft:bookshelf
setblock 27 173 504 minecraft:bookshelf
setblock 33 173 464 minecraft:bookshelf
setblock 34 173 504 minecraft:bookshelf
fill 37 173 482 37 174 482 minecraft:bookshelf
fill 37 173 484 37 174 484 minecraft:bookshelf
fill 37 173 486 37 174 486 minecraft:bookshelf
fill 37 173 488 37 174 488 minecraft:bookshelf
fill 37 173 490 37 174 490 minecraft:bookshelf
fill 37 173 492 37 174 492 minecraft:bookshelf
fill 38 173 483 38 174 483 minecraft:bookshelf
fill 38 173 485 38 174 485 minecraft:bookshelf
fill 38 173 487 38 174 487 minecraft:bookshelf
fill 38 173 489 38 174 489 minecraft:bookshelf
fill 38 173 491 38 174 491 minecraft:bookshelf
fill 39 173 482 39 174 482 minecraft:bookshelf
fill 39 173 484 39 174 484 minecraft:bookshelf
fill 39 173 486 39 174 486 minecraft:bookshelf
fill 39 173 488 39 174 488 minecraft:bookshelf
fill 39 173 490 39 174 490 minecraft:bookshelf
fill 39 173 492 39 173 499 minecraft:bookshelf
setblock 40 173 464 minecraft:bookshelf
fill 40 173 483 40 174 483 minecraft:bookshelf
fill 40 173 485 40 174 485 minecraft:bookshelf
fill 40 173 487 40 174 487 minecraft:bookshelf
fill 40 173 489 40 174 489 minecraft:bookshelf
fill 40 173 491 40 174 491 minecraft:bookshelf
fill 40 173 494 40 173 500 minecraft:bookshelf
setblock 41 173 470 minecraft:bookshelf
setblock 41 173 477 minecraft:bookshelf
fill 41 173 482 41 174 482 minecraft:bookshelf
fill 41 173 484 41 174 484 minecraft:bookshelf
fill 41 173 486 41 174 486 minecraft:bookshelf
fill 41 173 488 41 174 488 minecraft:bookshelf
fill 41 173 490 41 174 490 minecraft:bookshelf
fill 41 173 492 41 174 492 minecraft:bookshelf
fill 41 173 497 41 173 498 minecraft:bookshelf
fill 41 173 500 41 174 501 minecraft:bookshelf
fill 41 173 504 41 175 504 minecraft:bookshelf
setblock 1 174 468 minecraft:bookshelf
setblock 1 174 475 minecraft:bookshelf
setblock 1 174 482 minecraft:bookshelf
setblock 1 174 489 minecraft:bookshelf
setblock 1 174 496 minecraft:bookshelf
setblock 1 174 503 minecraft:bookshelf
setblock 4 174 464 minecraft:bookshelf
setblock 7 174 504 minecraft:bookshelf
setblock 11 174 464 minecraft:bookshelf
setblock 14 174 504 minecraft:bookshelf
setblock 18 174 464 minecraft:bookshelf
setblock 21 174 504 minecraft:bookshelf
setblock 25 174 464 minecraft:bookshelf
setblock 28 174 504 minecraft:bookshelf
setblock 32 174 464 minecraft:bookshelf
fill 35 174 504 35 176 504 minecraft:bookshelf
fill 37 174 502 41 174 502 minecraft:bookshelf
fill 38 174 503 40 175 503 minecraft:bookshelf
setblock 39 174 464 minecraft:bookshelf
setblock 39 174 492 minecraft:bookshelf
fill 39 174 497 39 174 501 minecraft:bookshelf
fill 39 174 504 40 175 504 minecraft:bookshelf
fill 40 174 498 40 174 501 minecraft:bookshelf
setblock 41 174 469 minecraft:bookshelf
setblock 41 174 476 minecraft:bookshelf
setblock 41 174 497 minecraft:bookshelf
fill 33 175 502 37 175 503 minecraft:bookshelf
fill 34 175 504 34 176 504 minecraft:bookshelf
setblock 37 175 482 minecraft:ochre_froglight
setblock 37 175 484 minecraft:ochre_froglight
setblock 37 175 486 minecraft:ochre_froglight
setblock 37 175 488 minecraft:ochre_froglight
setblock 37 175 490 minecraft:ochre_froglight
setblock 37 175 492 minecraft:ochre_froglight
fill 37 175 504 38 175 504 minecraft:bookshelf
setblock 38 175 483 minecraft:ochre_froglight
setblock 38 175 485 minecraft:ochre_froglight
setblock 38 175 487 minecraft:ochre_froglight
setblock 38 175 489 minecraft:ochre_froglight
setblock 38 175 491 minecraft:ochre_froglight
fill 38 175 502 39 175 502 minecraft:bookshelf
setblock 39 175 482 minecraft:ochre_froglight
setblock 39 175 484 minecraft:ochre_froglight
setblock 39 175 486 minecraft:ochre_froglight
setblock 39 175 488 minecraft:ochre_froglight
setblock 39 175 490 minecraft:ochre_froglight
setblock 39 175 492 minecraft:ochre_froglight
setblock 40 175 483 minecraft:ochre_froglight
setblock 40 175 485 minecraft:ochre_froglight
setblock 40 175 487 minecraft:ochre_froglight
setblock 40 175 489 minecraft:ochre_froglight
setblock 40 175 491 minecraft:ochre_froglight
setblock 41 175 482 minecraft:ochre_froglight
setblock 41 175 484 minecraft:ochre_froglight
setblock 41 175 486 minecraft:ochre_froglight
setblock 41 175 488 minecraft:ochre_froglight
setblock 41 175 490 minecraft:ochre_froglight
setblock 41 175 492 minecraft:ochre_froglight
setblock 1 176 470 minecraft:bookshelf
setblock 1 176 477 minecraft:bookshelf
setblock 1 176 484 minecraft:bookshelf
setblock 1 176 491 minecraft:bookshelf
setblock 1 176 498 minecraft:bookshelf
setblock 2 176 464 minecraft:bookshelf
setblock 2 176 504 minecraft:bookshelf
setblock 9 176 464 minecraft:bookshelf
setblock 9 176 504 minecraft:bookshelf
setblock 16 176 464 minecraft:bookshelf
setblock 16 176 504 minecraft:bookshelf
fill 17 176 482 18 176 482 minecraft:stone_bricks
fill 17 176 484 17 176 485 minecraft:stone_bricks
fill 18 176 483 18 176 484 minecraft:stone_bricks
fill 22 176 477 23 176 477 minecraft:stone_bricks
setblock 22 176 490 minecraft:stone_bricks
setblock 23 176 464 minecraft:bookshelf
setblock 23 176 476 minecraft:stone_bricks
setblock 23 176 504 minecraft:bookshelf
fill 24 176 491 25 176 492 minecraft:stone_bricks
fill 26 176 476 27 176 477 minecraft:stone_bricks
fill 29 176 502 34 176 503 minecraft:bookshelf
setblock 30 176 464 minecraft:bookshelf
fill 30 176 504 33 176 504 minecraft:bookshelf
setblock 32 176 482 minecraft:stone_bricks
fill 32 176 484 33 176 485 minecraft:stone_bricks
setblock 33 176 486 minecraft:stone_bricks
setblock 35 176 503 minecraft:bookshelf
setblock 37 176 464 minecraft:bookshelf
fill 37 176 482 37 177 482 minecraft:bookshelf
fill 37 176 484 37 177 484 minecraft:bookshelf
fill 37 176 486 37 177 486 minecraft:bookshelf
fill 37 176 488 37 177 488 minecraft:bookshelf
fill 37 176 490 37 177 490 minecraft:bookshelf
fill 37 176 492 37 177 492 minecraft:bookshelf
setblock 37 176 504 minecraft:bookshelf
fill 38 176 483 38 177 483 minecraft:bookshelf
fill 38 176 485 38 177 485 minecraft:bookshelf
fill 38 176 487 38 177 487 minecraft:bookshelf
fill 38 176 489 38 177 489 minecraft:bookshelf
fill 38 176 491 38 177 491 minecraft:bookshelf
fill 39 176 482 39 177 482 minecraft:bookshelf
fill 39 176 484 39 177 484 minecraft:bookshelf
fill 39 176 486 39 177 486 minecraft:bookshelf
fill 39 176 488 39 177 488 minecraft:bookshelf
fill 39 176 490 39 177 490 minecraft:bookshelf
fill 39 176 492 39 177 492 minecraft:bookshelf
fill 40 176 483 40 177 483 minecraft:bookshelf
fill 40 176 485 40 177 485 minecraft:bookshelf
fill 40 176 487 40 177 487 minecraft:bookshelf
fill 40 176 489 40 177 489 minecraft:bookshelf
fill 40 176 491 40 177 491 minecraft:bookshelf
setblock 41 176 467 minecraft:bookshelf
setblock 41 176 474 minecraft:bookshelf
fill 41 176 481 41 176 482 minecraft:bookshelf
fill 41 176 484 41 177 484 minecraft:bookshelf
fill 41 176 486 41 177 486 minecraft:bookshelf
fill 41 176 488 41 177 488 minecraft:bookshelf
fill 41 176 490 41 177 490 minecraft:bookshelf
fill 41 176 492 41 177 492 minecraft:bookshelf
setblock 41 176 495 minecraft:bookshelf
setblock 41 176 502 minecraft:bookshelf
setblock 1 177 464 minecraft:bookshelf
setblock 1 177 471 minecraft:bookshelf
setblock 1 177 478 minecraft:bookshelf
setblock 1 177 485 minecraft:bookshelf
setblock 1 177 492 minecraft:bookshelf
setblock 1 177 499 minecraft:bookshelf
setblock 3 177 466 minecraft:light[level=12]
setblock 3 177 474 minecraft:light[level=12]
setblock 3 177 482 minecraft:light[level=12]
setblock 3 177 490 minecraft:light[level=12]
setblock 3 177 498 minecraft:light[level=12]
setblock 3 177 504 minecraft:bookshelf
fill 4 177 480 4 178 481 minecraft:white_wool
setblock 8 177 464 minecraft:bookshelf
setblock 10 177 504 minecraft:bookshelf
setblock 11 177 466 minecraft:light[level=12]
setblock 11 177 474 minecraft:light[level=12]
setblock 11 177 482 minecraft:light[level=12]
setblock 11 177 490 minecraft:light[level=12]
setblock 11 177 498 minecraft:light[level=12]
setblock 15 177 464 minecraft:bookshelf
setblock 17 177 504 minecraft:bookshelf
setblock 19 177 466 minecraft:light[level=12]
setblock 19 177 474 minecraft:light[level=12]
setblock 19 177 482 minecraft:light[level=12]
setblock 19 177 498 minecraft:light[level=12]
setblock 22 177 464 minecraft:bookshelf
fill 24 177 504 24 180 504 minecraft:bookshelf
fill 26 177 502 28 177 504 minecraft:bookshelf
setblock 27 177 466 minecraft:light[level=12]
setblock 27 177 474 minecraft:light[level=12]
setblock 27 177 482 minecraft:light[level=12]
setblock 27 177 490 minecraft:light[level=12]
setblock 27 177 498 minecraft:light[level=12]
setblock 29 177 464 minecraft:bookshelf
fill 29 177 502 30 177 503 minecraft:bookshelf
fill 30 177 504 31 177 504 minecraft:bookshelf
setblock 31 177 503 minecraft:bookshelf
setblock 35 177 466 minecraft:light[level=12]
setblock 35 177 474 minecraft:light[level=12]
setblock 35 177 482 minecraft:light[level=12]
setblock 35 177 490 minecraft:light[level=12]
setblock 35 177 498 minecraft:light[level=12]
setblock 36 177 464 minecraft:bookshelf
setblock 38 177 504 minecraft:bookshelf
setblock 41 177 466 minecraft:bookshelf
setblock 41 177 473 minecraft:bookshelf
setblock 41 177 480 minecraft:bookshelf
setblock 41 177 482 minecraft:bookshelf
setblock 41 177 494 minecraft:bookshelf
setblock 41 177 501 minecraft:bookshelf
setblock 1 178 465 minecraft:bookshelf
setblock 1 178 472 minecraft:bookshelf
setblock 1 178 479 minecraft:bookshelf
setblock 1 178 486 minecraft:bookshelf
setblock 1 178 493 minecraft:bookshelf
setblock 1 178 500 minecraft:bookshelf
setblock 4 178 504 minecraft:bookshelf
fill 5 178 489 7 179 489 minecraft:blue_wool
fill 6 178 488 6 179 488 minecraft:blue_wool
fill 6 178 490 6 179 490 minecraft:blue_wool
setblock 7 178 464 minecraft:bookshelf
setblock 11 178 504 minecraft:bookshelf
setblock 14 178 464 minecraft:bookshelf
setblock 18 178 504 minecraft:bookshelf
setblock 21 178 464 minecraft:bookshelf
fill 23 178 502 23 179 504 minecraft:bookshelf
fill 24 178 502 27 178 503 minecraft:bookshelf
fill 25 178 504 27 178 504 minecraft:bookshelf
setblock 28 178 464 minecraft:bookshelf
setblock 32 178 504 minecraft:bookshelf
setblock 35 178 464 minecraft:bookshelf
setblock 37 178 482 minecraft:ochre_froglight
setblock 37 178 484 minecraft:ochre_froglight
setblock 37 178 486 minecraft:ochre_froglight
setblock 37 178 488 minecraft:ochre_froglight
setblock 37 178 490 minecraft:ochre_froglight
setblock 37 178 492 minecraft:ochre_froglight
setblock 38 178 483 minecraft:ochre_froglight
setblock 38 178 485 minecraft:ochre_froglight
setblock 38 178 487 minecraft:ochre_froglight
setblock 38 178 489 minecraft:ochre_froglight
setblock 38 178 491 minecraft:ochre_froglight
setblock 39 178 482 minecraft:ochre_froglight
setblock 39 178 484 minecraft:ochre_froglight
setblock 39 178 486 minecraft:ochre_froglight
setblock 39 178 488 minecraft:ochre_froglight
setblock 39 178 490 minecraft:ochre_froglight
setblock 39 178 492 minecraft:ochre_froglight
setblock 39 178 504 minecraft:bookshelf
setblock 40 178 483 minecraft:ochre_froglight
setblock 40 178 485 minecraft:ochre_froglight
setblock 40 178 487 minecraft:ochre_froglight
setblock 40 178 489 minecraft:ochre_froglight
setblock 40 178 491 minecraft:ochre_froglight
setblock 41 178 465 minecraft:bookshelf
setblock 41 178 472 minecraft:bookshelf
setblock 41 178 479 minecraft:bookshelf
setblock 41 178 482 minecraft:ochre_froglight
setblock 41 178 484 minecraft:ochre_froglight
setblock 41 178 486 minecraft:ochre_froglight
setblock 41 178 488 minecraft:ochre_froglight
setblock 41 178 490 minecraft:ochre_froglight
setblock 41 178 492 minecraft:ochre_froglight
setblock 41 178 493 minecraft:bookshelf
setblock 41 178 500 minecraft:bookshelf
fill 1 179 466 1 180 466 minecraft:bookshelf
fill 1 179 473 1 180 473 minecraft:bookshelf
fill 1 179 480 1 180 480 minecraft:bookshelf
fill 1 179 487 1 180 487 minecraft:bookshelf
fill 1 179 494 1 180 494 minecraft:bookshelf
fill 1 179 501 1 180 501 minecraft:bookshelf
fill 5 179 504 5 180 504 minecraft:bookshelf
fill 6 179 464 6 180 464 minecraft:bookshelf
fill 12 179 504 12 180 504 minecraft:bookshelf
fill 13 179 464 13 180 464 minecraft:bookshelf
fill 17 179 478 21 179 479 minecraft:dark_oak_planks
fill 17 179 489 21 179 490 minecraft:dark_oak_planks
fill 18 179 477 21 179 477 minecraft:dark_oak_planks
fill 18 179 480 21 179 480 minecraft:dark_oak_planks
fill 18 179 488 21 179 488 minecraft:dark_oak_planks
fill 18 179 491 21 179 491 minecraft:dark_oak_planks
fill 19 179 476 20 179 476 minecraft:dark_oak_planks
fill 19 179 492 20 179 492 minecraft:dark_oak_planks
fill 19 179 504 21 180 504 minecraft:bookshelf
fill 20 179 464 20 180 464 minecraft:bookshelf
fill 20 179 502 22 179 503 minecraft:bookshelf
fill 24 179 502 24 179 503 minecraft:bookshelf
fill 26 179 504 26 180 504 minecraft:bookshelf
fill 27 179 464 27 180 464 minecraft:bookshelf
fill 29 179 477 32 179 480 minecraft:dark_oak_planks
fill 29 179 488 32 179 491 minecraft:dark_oak_planks
fill 30 179 476 31 179 476 minecraft:dark_oak_planks
fill 30 179 492 31 179 492 minecraft:dark_oak_planks
fill 33 179 478 33 179 479 minecraft:dark_oak_planks
fill 33 179 489 33 179 490 minecraft:dark_oak_planks
fill 33 179 504 33 180 504 minecraft:bookshelf
fill 34 179 464 34 180 464 minecraft:bookshelf
fill 37 179 482 37 180 482 minecraft:bookshelf
fill 37 179 484 37 180 484 minecraft:bookshelf
fill 37 179 486 37 180 486 minecraft:bookshelf
fill 37 179 488 37 180 488 minecraft:bookshelf
fill 37 179 490 37 180 490 minecraft:bookshelf
fill 37 179 492 37 180 492 minecraft:bookshelf
fill 38 179 483 38 180 483 minecraft:bookshelf
fill 38 179 485 38 180 485 minecraft:bookshelf
fill 38 179 487 38 180 487 minecraft:bookshelf
fill 38 179 489 38 180 489 minecraft:bookshelf
fill 38 179 491 38 180 491 minecraft:bookshelf
fill 39 179 482 39 180 482 minecraft:bookshelf
fill 39 179 484 39 180 484 minecraft:bookshelf
fill 39 179 486 39 180 486 minecraft:bookshelf
fill 39 179 488 39 180 488 minecraft:bookshelf
fill 39 179 490 39 180 490 minecraft:bookshelf
fill 39 179 492 39 180 492 minecraft:bookshelf
fill 40 179 483 40 180 483 minecraft:bookshelf
fill 40 179 485 40 180 485 minecraft:bookshelf
fill 40 179 487 40 180 487 minecraft:bookshelf
fill 40 179 489 40 180 489 minecraft:bookshelf
fill 40 179 491 40 180 491 minecraft:bookshelf
fill 40 179 504 40 180 504 minecraft:bookshelf
fill 41 179 464 41 180 464 minecraft:bookshelf
fill 41 179 471 41 180 471 minecraft:bookshelf
fill 41 179 478 41 180 478 minecraft:bookshelf
fill 41 179 482 41 180 482 minecraft:bookshelf
fill 41 179 484 41 180 484 minecraft:bookshelf
fill 41 179 486 41 180 486 minecraft:bookshelf
fill 41 179 488 41 180 488 minecraft:bookshelf
fill 41 179 490 41 180 490 minecraft:bookshelf
fill 41 179 492 41 180 492 minecraft:bookshelf
fill 41 179 499 41 180 499 minecraft:bookshelf
fill 1 180 464 1 180 465 minecraft:bookshelf
fill 1 180 467 1 180 468 minecraft:bookshelf
fill 1 180 470 1 180 472 minecraft:bookshelf
fill 1 180 474 1 180 475 minecraft:bookshelf
fill 1 180 477 1 180 479 minecraft:bookshelf
fill 1 180 481 1 180 482 minecraft:bookshelf
fill 1 180 484 1 180 486 minecraft:bookshelf
fill 1 180 488 1 180 489 minecraft:bookshelf
fill 1 180 491 1 180 493 minecraft:bookshelf
fill 1 180 495 1 180 496 minecraft:bookshelf
fill 1 180 498 1 180 500 minecraft:bookshelf
fill 1 180 502 1 180 503 minecraft:bookshelf
setblock 2 180 464 minecraft:bookshelf
fill 2 180 504 4 180 504 minecraft:bookshelf
fill 4 180 464 5 180 464 minecraft:bookshelf
fill 6 180 504 7 180 504 minecraft:bookshelf
fill 7 180 464 9 180 464 minecraft:bookshelf
fill 9 180 504 11 180 504 minecraft:bookshelf
fill 11 180 464 12 180 464 minecraft:bookshelf
fill 13 180 504 14 182 504 minecraft:bookshelf
fill 14 180 464 16 180 464 minecraft:bookshelf
fill 16 180 504 18 181 504 minecraft:bookshelf
fill 17 180 502 21 180 503 minecraft:bookshelf
fill 18 180 464 19 180 464 minecraft:bookshelf
fill 18 180 477 20 180 479 minecraft:dark_oak_planks
fill 18 180 489 20 180 491 minecraft:dark_oak_planks
fill 19 180 480 20 180 480 minecraft:dark_oak_planks
fill 19 180 488 20 180 488 minecraft:dark_oak_planks
fill 21 180 464 23 180 464 minecraft:bookshelf
fill 21 180 478 21 180 479 minecraft:dark_oak_planks
fill 21 180 489 21 180 490 minecraft:dark_oak_planks
setblock 23 180 504 minecraft:bookshelf
fill 25 180 464 26 180 464 minecraft:bookshelf
setblock 25 180 504 minecraft:bookshelf
fill 27 180 504 28 180 504 minecraft:bookshelf
fill 28 180 464 30 180 464 minecraft:bookshelf
fill 29 180 478 32 180 479 minecraft:dark_oak_planks
fill 29 180 489 32 180 490 minecraft:dark_oak_planks
fill 30 180 477 32 180 477 minecraft:dark_oak_planks
fill 30 180 480 31 180 480 minecraft:dark_oak_planks
fill 30 180 488 31 180 488 minecraft:dark_oak_planks
fill 30 180 491 32 180 491 minecraft:dark_oak_planks
fill 30 180 504 32 180 504 minecraft:bookshelf
fill 32 180 464 33 180 464 minecraft:bookshelf
fill 34 180 504 35 180 504 minecraft:bookshelf
fill 35 180 464 37 180 464 minecraft:bookshelf
fill 37 180 504 39 180 504 minecraft:bookshelf
fill 39 180 464 40 180 464 minecraft:bookshelf
fill 41 180 465 41 180 467 minecraft:bookshelf
fill 41 180 469 41 180 470 minecraft:bookshelf
fill 41 180 472 41 180 474 minecraft:bookshelf
fill 41 180 476 41 180 477 minecraft:bookshelf
fill 41 180 479 41 180 481 minecraft:bookshelf
fill 41 180 493 41 180 495 minecraft:bookshelf
fill 41 180 497 41 180 498 minecraft:bookshelf
fill 41 180 500 41 180 502 minecraft:bookshelf
setblock 41 180 504 minecraft:bookshelf
setblock 1 181 468 minecraft:bookshelf
setblock 1 181 475 minecraft:bookshelf
setblock 1 181 482 minecraft:bookshelf
setblock 1 181 489 minecraft:bookshelf
setblock 1 181 496 minecraft:bookshelf
setblock 1 181 503 minecraft:bookshelf
setblock 4 181 464 minecraft:bookshelf
setblock 7 181 504 minecraft:bookshelf
setblock 11 181 464 minecraft:bookshelf
fill 14 181 502 18 181 503 minecraft:bookshelf
setblock 18 181 464 minecraft:bookshelf
fill 18 181 478 20 181 479 minecraft:dark_oak_planks
fill 18 181 489 20 181 490 minecraft:dark_oak_planks
fill 19 181 477 20 181 477 minecraft:dark_oak_planks
fill 19 181 491 20 181 491 minecraft:dark_oak_planks
setblock 21 181 504 minecraft:bookshelf
setblock 25 181 464 minecraft:bookshelf
setblock 28 181 504 minecraft:bookshelf
fill 30 181 477 31 181 479 minecraft:dark_oak_planks
fill 30 181 489 31 181 491 minecraft:dark_oak_planks
setblock 32 181 464 minecraft:bookshelf
fill 32 181 478 32 181 479 minecraft:dark_oak_planks
fill 32 181 489 32 181 490 minecraft:dark_oak_planks
setblock 35 181 504 minecraft:bookshelf
setblock 37 181 482 minecraft:ochre_froglight
setblock 37 181 484 minecraft:ochre_froglight
setblock 37 181 486 minecraft:ochre_froglight
setblock 37 181 488 minecraft:ochre_froglight
setblock 37 181 490 minecraft:ochre_froglight
setblock 37 181 492 minecraft:ochre_froglight
setblock 38 181 483 minecraft:ochre_froglight
setblock 38 181 485 minecraft:ochre_froglight
setblock 38 181 487 minecraft:ochre_froglight
setblock 38 181 489 minecraft:ochre_froglight
setblock 38 181 491 minecraft:ochre_froglight
setblock 39 181 464 minecraft:bookshelf
setblock 39 181 482 minecraft:ochre_froglight
setblock 39 181 484 minecraft:ochre_froglight
setblock 39 181 486 minecraft:ochre_froglight
setblock 39 181 488 minecraft:ochre_froglight
setblock 39 181 490 minecraft:ochre_froglight
setblock 39 181 492 minecraft:ochre_froglight
setblock 40 181 483 minecraft:ochre_froglight
setblock 40 181 485 minecraft:ochre_froglight
setblock 40 181 487 minecraft:ochre_froglight
setblock 40 181 489 minecraft:ochre_froglight
setblock 40 181 491 minecraft:ochre_froglight
setblock 41 181 469 minecraft:bookshelf
setblock 41 181 476 minecraft:bookshelf
setblock 41 181 482 minecraft:ochre_froglight
setblock 41 181 484 minecraft:ochre_froglight
setblock 41 181 486 minecraft:ochre_froglight
setblock 41 181 488 minecraft:ochre_froglight
setblock 41 181 490 minecraft:ochre_froglight
setblock 41 181 492 minecraft:ochre_froglight
setblock 41 181 497 minecraft:bookshelf
fill 9 182 504 12 182 504 minecraft:bookshelf
fill 10 182 502 15 182 503 minecraft:bookshelf
fill 19 182 478 20 182 479 minecraft:dark_oak_planks
fill 19 182 489 20 182 490 minecraft:dark_oak_planks
fill 30 182 478 31 182 479 minecraft:dark_oak_planks
fill 30 182 489 31 182 490 minecraft:dark_oak_planks
fill 37 182 482 37 183 482 minecraft:bookshelf
fill 37 182 484 37 183 484 minecraft:bookshelf
fill 37 182 486 37 183 486 minecraft:bookshelf
fill 37 182 488 37 183 488 minecraft:bookshelf
fill 37 182 490 37 183 490 minecraft:bookshelf
fill 37 182 492 37 183 492 minecraft:bookshelf
fill 38 182 483 38 183 483 minecraft:bookshelf
fill 38 182 485 38 183 485 minecraft:bookshelf
fill 38 182 487 38 183 487 minecraft:bookshelf
fill 38 182 489 38 183 489 minecraft:bookshelf
fill 38 182 491 38 183 491 minecraft:bookshelf
fill 39 182 482 39 183 482 minecraft:bookshelf
fill 39 182 484 39 183 484 minecraft:bookshelf
fill 39 182 486 39 183 486 minecraft:bookshelf
fill 39 182 488 39 183 488 minecraft:bookshelf
fill 39 182 490 39 183 490 minecraft:bookshelf
fill 39 182 492 39 183 492 minecraft:bookshelf
fill 40 182 483 40 183 483 minecraft:bookshelf
fill 40 182 485 40 183 485 minecraft:bookshelf
fill 40 182 487 40 183 487 minecraft:bookshelf
fill 40 182 489 40 183 489 minecraft:bookshelf
fill 40 182 491 40 183 491 minecraft:bookshelf
fill 41 182 482 41 183 482 minecraft:bookshelf
fill 41 182 484 41 183 484 minecraft:bookshelf
fill 41 182 486 41 183 486 minecraft:bookshelf
fill 41 182 488 41 183 488 minecraft:bookshelf
fill 41 182 490 41 183 490 minecraft:bookshelf
fill 41 182 492 41 183 492 minecraft:bookshelf
setblock 1 183 470 minecraft:bookshelf
setblock 1 183 477 minecraft:bookshelf
setblock 1 183 484 minecraft:bookshelf
setblock 1 183 491 minecraft:bookshelf
setblock 1 183 498 minecraft:bookshelf
setblock 2 183 464 minecraft:bookshelf
fill 2 183 504 2 184 504 minecraft:bookshelf
fill 4 183 478 5 184 479 minecraft:blue_wool
fill 4 183 504 7 183 504 minecraft:bookshelf
fill 5 183 503 11 183 503 minecraft:bookshelf
fill 6 183 502 12 183 502 minecraft:bookshelf
setblock 9 183 464 minecraft:bookshelf
fill 9 183 504 11 183 504 minecraft:bookshelf
setblock 16 183 464 minecraft:bookshelf
setblock 16 183 504 minecraft:bookshelf
setblock 19 183 478 minecraft:dark_oak_planks
setblock 19 183 490 minecraft:dark_oak_planks
setblock 23 183 464 minecraft:bookshelf
setblock 23 183 504 minecraft:bookshelf
setblock 30 183 464 minecraft:bookshelf
setblock 30 183 504 minecraft:bookshelf
setblock 31 183 478 minecraft:dark_oak_planks
setblock 31 183 490 minecraft:dark_oak_planks
setblock 37 183 464 minecraft:bookshelf
setblock 37 183 504 minecraft:bookshelf
setblock 41 183 467 minecraft:bookshelf
setblock 41 183 474 minecraft:bookshelf
setblock 41 183 481 minecraft:bookshelf
setblock 41 183 495 minecraft:bookshelf
setblock 41 183 502 minecraft:bookshelf
setblock 1 184 464 minecraft:bookshelf
setblock 1 184 471 minecraft:bookshelf
setblock 1 184 478 minecraft:bookshelf
setblock 1 184 485 minecraft:bookshelf
setblock 1 184 492 minecraft:bookshelf
fill 1 184 499 1 186 499 minecraft:bookshelf
fill 1 184 502 7 184 503 minecraft:bookshelf
fill 2 184 501 3 185 501 minecraft:bookshelf
fill 3 184 500 3 185 500 minecraft:bookshelf
fill 3 184 504 6 184 504 minecraft:bookshelf
setblock 8 184 464 minecraft:bookshelf
setblock 8 184 502 minecraft:bookshelf
setblock 10 184 504 minecraft:bookshelf
setblock 15 184 464 minecraft:bookshelf
setblock 17 184 504 minecraft:bookshelf
setblock 22 184 464 minecraft:bookshelf
setblock 24 184 504 minecraft:bookshelf
setblock 29 184 464 minecraft:bookshelf
setblock 31 184 504 minecraft:bookshelf
setblock 36 184 464 minecraft:bookshelf
setblock 37 184 482 minecraft:ochre_froglight
setblock 37 184 484 minecraft:ochre_froglight
setblock 37 184 486 minecraft:ochre_froglight
setblock 37 184 488 minecraft:ochre_froglight
setblock 37 184 490 minecraft:ochre_froglight
setblock 37 184 492 minecraft:ochre_froglight
setblock 38 184 483 minecraft:ochre_froglight
setblock 38 184 485 minecraft:ochre_froglight
setblock 38 184 487 minecraft:ochre_froglight
setblock 38 184 489 minecraft:ochre_froglight
setblock 38 184 491 minecraft:ochre_froglight
setblock 38 184 504 minecraft:bookshelf
setblock 39 184 482 minecraft:ochre_froglight
setblock 39 184 484 minecraft:ochre_froglight
setblock 39 184 486 minecraft:ochre_froglight
setblock 39 184 488 minecraft:ochre_froglight
setblock 39 184 490 minecraft:ochre_froglight
setblock 39 184 492 minecraft:ochre_froglight
setblock 40 184 483 minecraft:ochre_froglight
setblock 40 184 485 minecraft:ochre_froglight
setblock 40 184 487 minecraft:ochre_froglight
setblock 40 184 489 minecraft:ochre_froglight
setblock 40 184 491 minecraft:ochre_froglight
setblock 41 184 466 minecraft:bookshelf
setblock 41 184 473 minecraft:bookshelf
setblock 41 184 480 minecraft:bookshelf
setblock 41 184 482 minecraft:ochre_froglight
setblock 41 184 484 minecraft:ochre_froglight
setblock 41 184 486 minecraft:ochre_froglight
setblock 41 184 488 minecraft:ochre_froglight
setblock 41 184 490 minecraft:ochre_froglight
setblock 41 184 492 minecraft:ochre_froglight
setblock 41 184 494 minecraft:bookshelf
setblock 41 184 501 minecraft:bookshelf
setblock 1 185 465 minecraft:bookshelf
setblock 1 185 472 minecraft:bookshelf
setblock 1 185 479 minecraft:bookshelf
setblock 1 185 486 minecraft:bookshelf
fill 1 185 493 1 187 493 minecraft:bookshelf
fill 1 185 498 3 185 498 minecraft:bookshelf
fill 1 185 500 1 185 503 minecraft:bookshelf
fill 2 185 496 3 186 497 minecraft:bookshelf
fill 2 185 499 2 185 500 minecraft:bookshelf
fill 2 185 502 2 185 503 minecraft:bookshelf
setblock 3 185 466 minecraft:light[level=12]
setblock 3 185 474 minecraft:light[level=12]
setblock 3 185 482 minecraft:light[level=12]
setblock 3 185 490 minecraft:light[level=12]
setblock 3 185 499 minecraft:bookshelf
setblock 3 185 502 minecraft:bookshelf
setblock 4 185 504 minecraft:bookshelf
setblock 7 185 464 minecraft:bookshelf
setblock 11 185 466 minecraft:light[level=12]
setblock 11 185 474 minecraft:light[level=12]
setblock 11 185 482 minecraft:light[level=12]
setblock 11 185 490 minecraft:light[level=12]
setblock 11 185 498 minecraft:light[level=12]
setblock 11 185 504 minecraft:bookshelf
setblock 14 185 464 minecraft:bookshelf
setblock 18 185 504 minecraft:bookshelf
setblock 19 185 466 minecraft:light[level=12]
setblock 19 185 474 minecraft:light[level=12]
setblock 19 185 482 minecraft:light[level=12]
setblock 19 185 490 minecraft:light[level=12]
setblock 19 185 498 minecraft:light[level=12]
setblock 21 185 464 minecraft:bookshelf
setblock 25 185 504 minecraft:bookshelf
setblock 27 185 466 minecraft:light[level=12]
setblock 27 185 474 minecraft:light[level=12]
setblock 27 185 482 minecraft:light[level=12]
setblock 27 185 490 minecraft:light[level=12]
setblock 27 185 498 minecraft:light[level=12]
setblock 28 185 464 minecraft:bookshelf
setblock 32 185 504 minecraft:bookshelf
setblock 35 185 464 minecraft:bookshelf
setblock 35 185 466 minecraft:light[level=12]
setblock 35 185 474 minecraft:light[level=12]
setblock 35 185 482 minecraft:light[level=12]
setblock 35 185 490 minecraft:light[level=12]
setblock 35 185 498 minecraft:light[level=12]
fill 37 185 482 37 186 482 minecraft:bookshelf
fill 37 185 484 37 186 484 minecraft:bookshelf
fill 37 185 486 37 186 486 minecraft:bookshelf
fill 37 185 488 37 186 488 minecraft:bookshelf
fill 37 185 490 37 186 490 minecraft:bookshelf
fill 37 185 492 37 186 492 minecraft:bookshelf
fill 38 185 483 38 186 483 minecraft:bookshelf
fill 38 185 485 38 186 485 minecraft:bookshelf
fill 38 185 487 38 186 487 minecraft:bookshelf
fill 38 185 489 38 186 489 minecraft:bookshelf
fill 38 185 491 38 186 491 minecraft:bookshelf
fill 39 185 482 39 186 482 minecraft:bookshelf
fill 39 185 484 39 186 484 minecraft:bookshelf
fill 39 185 486 39 186 486 minecraft:bookshelf
fill 39 185 488 39 186 488 minecraft:bookshelf
fill 39 185 490 39 186 490 minecraft:bookshelf
fill 39 185 492 39 186 492 minecraft:bookshelf
setblock 39 185 504 minecraft:bookshelf
fill 40 185 483 40 186 483 minecraft:bookshelf
fill 40 185 485 40 186 485 minecraft:bookshelf
fill 40 185 487 40 186 487 minecraft:bookshelf
fill 40 185 489 40 186 489 minecraft:bookshelf
fill 40 185 491 40 186 491 minecraft:bookshelf
setblock 41 185 465 minecraft:bookshelf
setblock 41 185 472 minecraft:bookshelf
setblock 41 185 479 minecraft:bookshelf
fill 41 185 482 41 186 482 minecraft:bookshelf
fill 41 185 484 41 186 484 minecraft:bookshelf
fill 41 185 486 41 186 486 minecraft:bookshelf
fill 41 185 488 41 186 488 minecraft:bookshelf
fill 41 185 490 41 186 490 minecraft:bookshelf
fill 41 185 492 41 185 493 minecraft:bookshelf
setblock 41 185 500 minecraft:bookshelf
setblock 1 186 466 minecraft:bookshelf
setblock 1 186 473 minecraft:bookshelf
setblock 1 186 480 minecraft:bookshelf
setblock 1 186 487 minecraft:bookshelf
fill 1 186 494 1 186 496 minecraft:bookshelf
fill 1 186 498 2 186 498 minecraft:bookshelf
setblock 1 186 501 minecraft:bookshelf
fill 2 186 492 3 186 495 minecraft:bookshelf
setblock 5 186 504 minecraft:bookshelf
setblock 6 186 464 minecraft:bookshelf
setblock 12 186 504 minecraft:bookshelf
setblock 13 186 464 minecraft:bookshelf
setblock 19 186 504 minecraft:bookshelf
setblock 20 186 464 minecraft:bookshelf
setblock 26 186 504 minecraft:bookshelf
setblock 27 186 464 minecraft:bookshelf
setblock 33 186 504 minecraft:bookshelf
setblock 34 186 464 minecraft:bookshelf
setblock 40 186 504 minecraft:bookshelf
setblock 41 186 464 minecraft:bookshelf
setblock 41 186 471 minecraft:bookshelf
setblock 41 186 478 minecraft:bookshelf
setblock 41 186 492 minecraft:bookshelf
setblock 41 186 499 minecraft:bookshelf
setblock 1 187 467 minecraft:bookshelf
setblock 1 187 474 minecraft:bookshelf
setblock 1 187 481 minecraft:bookshelf
fill 1 187 488 1 188 489 minecraft:bookshelf
fill 1 187 491 3 187 492 minecraft:bookshelf
fill 1 187 494 1 187 495 minecraft:bookshelf
setblock 1 187 502 minecraft:bookshelf
fill 2 187 489 3 188 490 minecraft:bookshelf
fill 2 187 493 2 187 494 minecraft:bookshelf
setblock 3 187 493 minecraft:bookshelf
setblock 5 187 464 minecraft:bookshelf
setblock 6 187 504 minecraft:bookshelf
setblock 12 187 464 minecraft:bookshelf
setblock 13 187 504 minecraft:bookshelf
setblock 19 187 464 minecraft:bookshelf
setblock 20 187 504 minecraft:bookshelf
setblock 26 187 464 minecraft:bookshelf
setblock 27 187 504 minecraft:bookshelf
setblock 33 187 464 minecraft:bookshelf
setblock 34 187 504 minecraft:bookshelf
setblock 37 187 482 minecraft:ochre_froglight
setblock 37 187 484 minecraft:ochre_froglight
setblock 37 187 486 minecraft:ochre_froglight
setblock 37 187 488 minecraft:ochre_froglight
setblock 37 187 490 minecraft:ochre_froglight
setblock 37 187 492 minecraft:ochre_froglight
setblock 38 187 483 minecraft:ochre_froglight
setblock 38 187 485 minecraft:ochre_froglight
setblock 38 187 487 minecraft:ochre_froglight
setblock 38 187 489 minecraft:ochre_froglight
setblock 38 187 491 minecraft:ochre_froglight
setblock 39 187 482 minecraft:ochre_froglight
setblock 39 187 484 minecraft:ochre_froglight
setblock 39 187 486 minecraft:ochre_froglight
setblock 39 187 488 minecraft:ochre_froglight
setblock 39 187 490 minecraft:ochre_froglight
setblock 39 187 492 minecraft:ochre_froglight
setblock 40 187 464 minecraft:bookshelf
setblock 40 187 483 minecraft:ochre_froglight
setblock 40 187 485 minecraft:ochre_froglight
setblock 40 187 487 minecraft:ochre_froglight
setblock 40 187 489 minecraft:ochre_froglight
setblock 40 187 491 minecraft:ochre_froglight
setblock 41 187 470 minecraft:bookshelf
setblock 41 187 477 minecraft:bookshelf
setblock 41 187 482 minecraft:ochre_froglight
setblock 41 187 484 minecraft:ochre_froglight
setblock 41 187 486 minecraft:ochre_froglight
setblock 41 187 488 minecraft:ochre_froglight
setblock 41 187 490 minecraft:ochre_froglight
setblock 41 187 492 minecraft:ochre_froglight
setblock 41 187 498 minecraft:bookshelf
setblock 41 187 504 minecraft:bookshelf
setblock 1 188 468 minecraft:bookshelf
setblock 1 188 475 minecraft:bookshelf
setblock 1 188 482 minecraft:bookshelf
fill 1 188 486 3 189 487 minecraft:bookshelf
setblock 1 188 496 minecraft:bookshelf
setblock 1 188 503 minecraft:bookshelf
fill 2 188 488 3 188 488 minecraft:bookshelf
setblock 4 188 464 minecraft:bookshelf
setblock 7 188 504 minecraft:bookshelf
setblock 11 188 464 minecraft:bookshelf
setblock 14 188 504 minecraft:bookshelf
setblock 18 188 464 minecraft:bookshelf
setblock 21 188 504 minecraft:bookshelf
setblock 25 188 464 minecraft:bookshelf
setblock 28 188 504 minecraft:bookshelf
setblock 32 188 464 minecraft:bookshelf
setblock 35 188 504 minecraft:bookshelf
fill 37 188 482 37 189 482 minecraft:bookshelf
fill 37 188 484 37 189 484 minecraft:bookshelf
fill 37 188 486 37 189 486 minecraft:bookshelf
fill 37 188 488 37 189 488 minecraft:bookshelf
fill 37 188 490 37 189 490 minecraft:bookshelf
fill 37 188 492 37 189 492 minecraft:bookshelf
fill 38 188 471 40 189 471 minecraft:gold_block
fill 38 188 483 38 189 483 minecraft:bookshelf
fill 38 188 485 38 189 485 minecraft:bookshelf
fill 38 188 487 38 189 487 minecraft:bookshelf
fill 38 188 489 38 189 489 minecraft:bookshelf
fill 38 188 491 38 189 491 minecraft:bookshelf
setblock 39 188 464 minecraft:bookshelf
fill 39 188 482 39 189 482 minecraft:bookshelf
fill 39 188 484 39 189 484 minecraft:bookshelf
fill 39 188 486 39 189 486 minecraft:bookshelf
fill 39 188 488 39 189 488 minecraft:bookshelf
fill 39 188 490 39 189 490 minecraft:bookshelf
fill 39 188 492 39 189 492 minecraft:bookshelf
fill 40 188 483 40 189 483 minecraft:bookshelf
fill 40 188 485 40 189 485 minecraft:bookshelf
fill 40 188 487 40 189 487 minecraft:bookshelf
fill 40 188 489 40 189 489 minecraft:bookshelf
fill 40 188 491 40 189 491 minecraft:bookshelf
setblock 41 188 469 minecraft:bookshelf
setblock 41 188 476 minecraft:bookshelf
fill 41 188 482 41 189 482 minecraft:bookshelf
fill 41 188 484 41 189 484 minecraft:bookshelf
fill 41 188 486 41 189 486 minecraft:bookshelf
fill 41 188 488 41 189 488 minecraft:bookshelf
fill 41 188 490 41 189 490 minecraft:bookshelf
fill 41 188 492 41 189 492 minecraft:bookshelf
setblock 41 188 497 minecraft:bookshelf
fill 1 189 484 3 189 485 minecraft:bookshelf
fill 2 189 483 3 190 483 minecraft:bookshelf
fill 1 190 464 1 190 468 minecraft:bookshelf
fill 1 190 470 1 190 475 minecraft:bookshelf
fill 1 190 477 1 190 482 minecraft:bookshelf
fill 1 190 484 1 190 489 minecraft:bookshelf
fill 1 190 491 1 190 496 minecraft:bookshelf
fill 1 190 498 1 190 503 minecraft:bookshelf
setblock 2 190 464 minecraft:bookshelf
fill 2 190 480 3 190 482 minecraft:bookshelf
fill 2 190 484 3 190 484 minecraft:bookshelf
fill 2 190 496 3 191 496 minecraft:gold_block
fill 2 190 504 7 190 504 minecraft:bookshelf
fill 4 190 464 9 190 464 minecraft:bookshelf
fill 9 190 504 14 190 504 minecraft:bookshelf
fill 11 190 464 16 190 464 minecraft:bookshelf
fill 16 190 504 21 190 504 minecraft:bookshelf
fill 18 190 464 23 190 464 minecraft:bookshelf
fill 23 190 504 28 190 504 minecraft:bookshelf
fill 25 190 464 30 190 464 minecraft:bookshelf
fill 30 190 504 35 190 504 minecraft:bookshelf
fill 32 190 464 37 190 464 minecraft:bookshelf
setblock 37 190 482 minecraft:ochre_froglight
setblock 37 190 484 minecraft:ochre_froglight
setblock 37 190 486 minecraft:ochre_froglight
setblock 37 190 488 minecraft:ochre_froglight
setblock 37 190 490 minecraft:ochre_froglight
setblock 37 190 492 minecraft:ochre_froglight
fill 37 190 504 41 190 504 minecraft:bookshelf
setblock 38 190 483 minecraft:ochre_froglight
setblock 38 190 485 minecraft:ochre_froglight
setblock 38 190 487 minecraft:ochre_froglight
setblock 38 190 489 minecraft:ochre_froglight
setblock 38 190 491 minecraft:ochre_froglight
fill 39 190 464 41 190 464 minecraft:bookshelf
setblock 39 190 482 minecraft:ochre_froglight
setblock 39 190 484 minecraft:ochre_froglight
setblock 39 190 486 minecraft:ochre_froglight
setblock 39 190 488 minecraft:ochre_froglight
setblock 39 190 490 minecraft:ochre_froglight
setblock 39 190 492 minecraft:ochre_froglight
setblock 40 190 483 minecraft:ochre_froglight
setblock 40 190 485 minecraft:ochre_froglight
setblock 40 190 487 minecraft:ochre_froglight
setblock 40 190 489 minecraft:ochre_froglight
setblock 40 190 491 minecraft:ochre_froglight
fill 41 190 465 41 190 467 minecraft:bookshelf
fill 41 190 469 41 190 474 minecraft:bookshelf
fill 41 190 476 41 190 481 minecraft:bookshelf
setblock 41 190 482 minecraft:ochre_froglight
setblock 41 190 484 minecraft:ochre_froglight
setblock 41 190 486 minecraft:ochre_froglight
setblock 41 190 488 minecraft:ochre_froglight
setblock 41 190 490 minecraft:ochre_froglight
setblock 41 190 492 minecraft:ochre_froglight
fill 41 190 493 41 190 495 minecraft:bookshelf
fill 41 190 497 41 190 502 minecraft:bookshelf
setblock 1 191 464 minecraft:bookshelf
setblock 1 191 471 minecraft:bookshelf
fill 1 191 477 3 191 481 minecraft:bookshelf
setblock 1 191 485 minecraft:bookshelf
setblock 1 191 492 minecraft:bookshelf
setblock 1 191 496 minecraft:gold_block
setblock 1 191 499 minecraft:bookshelf
setblock 3 191 504 minecraft:bookshelf
setblock 8 191 464 minecraft:bookshelf
setblock 10 191 504 minecraft:bookshelf
setblock 15 191 464 minecraft:bookshelf
setblock 17 191 504 minecraft:bookshelf
setblock 22 191 464 minecraft:bookshelf
setblock 24 191 504 minecraft:bookshelf
setblock 29 191 464 minecraft:bookshelf
setblock 31 191 504 minecraft:bookshelf
setblock 36 191 464 minecraft:bookshelf
fill 37 191 482 37 192 482 minecraft:bookshelf
fill 37 191 484 37 192 484 minecraft:bookshelf
fill 37 191 486 37 192 486 minecraft:bookshelf
fill 37 191 488 37 192 488 minecraft:bookshelf
fill 37 191 490 37 192 490 minecraft:bookshelf
fill 37 191 492 37 192 492 minecraft:bookshelf
fill 38 191 483 38 192 483 minecraft:bookshelf
fill 38 191 485 38 192 485 minecraft:bookshelf
fill 38 191 487 38 192 487 minecraft:bookshelf
fill 38 191 489 38 192 489 minecraft:bookshelf
fill 38 191 491 38 192 491 minecraft:bookshelf
setblock 38 191 504 minecraft:bookshelf
fill 39 191 482 39 192 482 minecraft:bookshelf
fill 39 191 484 39 192 484 minecraft:bookshelf
fill 39 191 486 39 192 486 minecraft:bookshelf
fill 39 191 488 39 192 488 minecraft:bookshelf
fill 39 191 490 39 192 490 minecraft:bookshelf
fill 39 191 492 39 192 492 minecraft:bookshelf
fill 40 191 483 40 192 483 minecraft:bookshelf
fill 40 191 485 40 192 485 minecraft:bookshelf
fill 40 191 487 40 192 487 minecraft:bookshelf
fill 40 191 489 40 192 489 minecraft:bookshelf
fill 40 191 491 40 192 491 minecraft:bookshelf
setblock 41 191 466 minecraft:bookshelf
setblock 41 191 473 minecraft:bookshelf
setblock 41 191 480 minecraft:bookshelf
fill 41 191 482 41 223 482 minecraft:bookshelf
fill 41 191 484 41 192 484 minecraft:bookshelf
fill 41 191 486 41 192 486 minecraft:bookshelf
fill 41 191 488 41 192 488 minecraft:bookshelf
fill 41 191 490 41 192 490 minecraft:bookshelf
fill 41 191 492 41 193 492 minecraft:bookshelf
setblock 41 191 494 minecraft:bookshelf
setblock 41 191 501 minecraft:bookshelf
setblock 1 192 465 minecraft:bookshelf
fill 1 192 472 1 192 475 minecraft:bookshelf
fill 1 192 477 3 192 477 minecraft:bookshelf
setblock 1 192 479 minecraft:bookshelf
setblock 1 192 486 minecraft:bookshelf
setblock 1 192 493 minecraft:bookshelf
setblock 1 192 500 minecraft:bookshelf
fill 2 192 473 3 192 476 minecraft:bookshelf
fill 2 192 478 3 192 478 minecraft:bookshelf
setblock 4 192 504 minecraft:bookshelf
setblock 7 192 464 minecraft:bookshelf
setblock 11 192 504 minecraft:bookshelf
setblock 14 192 464 minecraft:bookshelf
setblock 18 192 504 minecraft:bookshelf
setblock 21 192 464 minecraft:bookshelf
setblock 25 192 504 minecraft:bookshelf
setblock 28 192 464 minecraft:bookshelf
setblock 32 192 504 minecraft:bookshelf
setblock 35 192 464 minecraft:bookshelf
setblock 39 192 504 minecraft:bookshelf
setblock 41 192 465 minecraft:bookshelf
setblock 41 192 472 minecraft:bookshelf
setblock 41 192 479 minecraft:bookshelf
setblock 41 192 493 minecraft:bookshelf
setblock 41 192 500 minecraft:bookshelf
fill 1 193 466 1 194 468 minecraft:bookshelf
fill 1 193 470 3 193 474 minecraft:bookshelf
setblock 1 193 480 minecraft:bookshelf
setblock 1 193 487 minecraft:bookshelf
setblock 1 193 494 minecraft:bookshelf
setblock 1 193 501 minecraft:bookshelf
fill 2 193 468 2 194 469 minecraft:bookshelf
setblock 3 193 466 minecraft:light[level=12]
fill 3 193 469 3 194 469 minecraft:bookshelf
setblock 3 193 475 minecraft:bookshelf
setblock 3 193 482 minecraft:light[level=12]
setblock 3 193 490 minecraft:light[level=12]
setblock 3 193 498 minecraft:light[level=12]
setblock 5 193 504 minecraft:bookshelf
setblock 6 193 464 minecraft:bookshelf
setblock 11 193 466 minecraft:light[level=12]
setblock 11 193 474 minecraft:light[level=12]
setblock 11 193 482 minecraft:light[level=12]
setblock 11 193 490 minecraft:light[level=12]
setblock 11 193 498 minecraft:light[level=12]
setblock 12 193 504 minecraft:bookshelf
setblock 13 193 464 minecraft:bookshelf
setblock 19 193 466 minecraft:light[level=12]
setblock 19 193 474 minecraft:light[level=12]
setblock 19 193 482 minecraft:light[level=12]
setblock 19 193 490 minecraft:light[level=12]
setblock 19 193 498 minecraft:light[level=12]
setblock 19 193 504 minecraft:bookshelf
setblock 20 193 464 minecraft:bookshelf
setblock 26 193 504 minecraft:bookshelf
setblock 27 193 464 minecraft:bookshelf
setblock 27 193 466 minecraft:light[level=12]
setblock 27 193 474 minecraft:light[level=12]
setblock 27 193 482 minecraft:light[level=12]
setblock 27 193 490 minecraft:light[level=12]
setblock 27 193 498 minecraft:light[level=12]
setblock 33 193 504 minecraft:bookshelf
setblock 34 193 464 minecraft:bookshelf
setblock 35 193 466 minecraft:light[level=12]
setblock 35 193 474 minecraft:light[level=12]
setblock 35 193 482 minecraft:light[level=12]
setblock 35 193 490 minecraft:light[level=12]
setblock 35 193 498 minecraft:light[level=12]
setblock 40 193 504 minecraft:bookshelf
setblock 41 193 464 minecraft:bookshelf
setblock 41 193 471 minecraft:bookshelf
setblock 41 193 478 minecraft:bookshelf
setblock 41 193 499 minecraft:bookshelf
fill 1 194 464 2 194 465 minecraft:bookshelf
setblock 1 194 474 minecraft:bookshelf
setblock 1 194 481 minecraft:bookshelf
setblock 1 194 488 minecraft:bookshelf
setblock 1 194 495 minecraft:bookshelf
setblock 1 194 502 minecraft:bookshelf
fill 2 194 466 3 194 467 minecraft:bookshelf
fill 2 194 470 3 194 470 minecraft:bookshelf
fill 3 194 465 4 195 465 minecraft:bookshelf
setblock 3 194 468 minecraft:bookshelf
setblock 3 194 471 minecraft:bookshelf
fill 4 194 466 5 195 466 minecraft:bookshelf
fill 5 194 464 5 195 464 minecraft:bookshelf
setblock 6 194 504 minecraft:bookshelf
setblock 12 194 464 minecraft:bookshelf
setblock 13 194 504 minecraft:bookshelf
setblock 19 194 464 minecraft:bookshelf
setblock 20 194 504 minecraft:bookshelf
setblock 26 194 464 minecraft:bookshelf
setblock 27 194 504 minecraft:bookshelf
setblock 33 194 464 minecraft:bookshelf
setblock 34 194 504 minecraft:bookshelf
fill 38 194 497 40 195 497 minecraft:gold_block
setblock 40 194 464 minecraft:bookshelf
setblock 41 194 470 minecraft:bookshelf
setblock 41 194 477 minecraft:bookshelf
setblock 41 194 484 minecraft:bookshelf
setblock 41 194 491 minecraft:bookshelf
setblock 41 194 498 minecraft:bookshelf
setblock 41 194 504 minecraft:bookshelf
fill 1 195 464 2 195 464 minecraft:bookshelf
setblock 1 195 468 minecraft:bookshelf
setblock 1 195 475 minecraft:bookshelf
setblock 1 195 482 minecraft:bookshelf
setblock 1 195 489 minecraft:bookshelf
setblock 1 195 496 minecraft:bookshelf
setblock 1 195 503 minecraft:bookshelf
setblock 2 195 465 minecraft:bookshelf
setblock 3 195 466 minecraft:bookshelf
setblock 4 195 464 minecraft:bookshelf
fill 5 195 465 9 195 465 minecraft:bookshelf
fill 6 195 464 8 196 464 minecraft:bookshelf
fill 6 195 466 9 195 466 minecraft:bookshelf
setblock 7 195 504 minecraft:bookshelf
fill 11 195 464 11 197 464 minecraft:bookshelf
setblock 14 195 504 minecraft:bookshelf
setblock 18 195 464 minecraft:bookshelf
setblock 21 195 504 minecraft:bookshelf
setblock 25 195 464 minecraft:bookshelf
setblock 28 195 504 minecraft:bookshelf
setblock 32 195 464 minecraft:bookshelf
setblock 35 195 504 minecraft:bookshelf
setblock 39 195 464 minecraft:bookshelf
setblock 41 195 469 minecraft:bookshelf
setblock 41 195 476 minecraft:bookshelf
setblock 41 195 483 minecraft:bookshelf
setblock 41 195 490 minecraft:bookshelf
setblock 41 195 497 minecraft:bookshelf
fill 7 196 465 13 196 465 minecraft:bookshelf
fill 8 196 466 13 196 466 minecraft:bookshelf
fill 9 196 464 9 197 464 minecraft:bookshelf
fill 12 196 464 12 197 464 minecraft:bookshelf
fill 18 196 467 18 197 468 minecraft:red_wool
setblock 1 197 470 minecraft:bookshelf
setblock 1 197 477 minecraft:bookshelf
setblock 1 197 484 minecraft:bookshelf
setblock 1 197 491 minecraft:bookshelf
setblock 1 197 498 minecraft:bookshelf
setblock 2 197 464 minecraft:bookshelf
setblock 2 197 504 minecraft:bookshelf
setblock 9 197 504 minecraft:bookshelf
fill 11 197 465 16 197 465 minecraft:bookshelf
fill 12 197 466 16 197 466 minecraft:bookshelf
fill 13 197 464 16 197 464 minecraft:bookshelf
setblock 16 197 504 minecraft:bookshelf
setblock 23 197 464 minecraft:bookshelf
setblock 23 197 504 minecraft:bookshelf
setblock 30 197 464 minecraft:bookshelf
setblock 30 197 504 minecraft:bookshelf
setblock 37 197 464 minecraft:bookshelf
setblock 37 197 504 minecraft:bookshelf
setblock 41 197 467 minecraft:bookshelf
setblock 41 197 474 minecraft:bookshelf
setblock 41 197 481 minecraft:bookshelf
setblock 41 197 488 minecraft:bookshelf
setblock 41 197 495 minecraft:bookshelf
setblock 41 197 502 minecraft:bookshelf
setblock 1 198 464 minecraft:bookshelf
setblock 1 198 471 minecraft:bookshelf
setblock 1 198 478 minecraft:bookshelf
setblock 1 198 485 minecraft:bookshelf
setblock 1 198 492 minecraft:bookshelf
setblock 1 198 499 minecraft:bookshelf
setblock 3 198 504 minecraft:bookshelf
fill 7 198 478 9 199 479 minecraft:white_wool
setblock 8 198 464 minecraft:bookshelf
setblock 10 198 504 minecraft:bookshelf
fill 14 198 471 15 199 472 minecraft:red_wool
fill 15 198 464 16 198 466 minecraft:bookshelf
fill 17 198 465 19 198 466 minecraft:bookshelf
setblock 17 198 504 minecraft:bookshelf
fill 18 198 464 19 200 464 minecraft:bookshelf
fill 22 198 464 22 200 464 minecraft:bookshelf
setblock 24 198 504 minecraft:bookshelf
setblock 29 198 464 minecraft:bookshelf
setblock 31 198 504 minecraft:bookshelf
setblock 36 198 464 minecraft:bookshelf
setblock 38 198 504 minecraft:bookshelf
setblock 41 198 466 minecraft:bookshelf
setblock 41 198 473 minecraft:bookshelf
setblock 41 198 480 minecraft:bookshelf
setblock 41 198 487 minecraft:bookshelf
setblock 41 198 494 minecraft:bookshelf
setblock 41 198 501 minecraft:bookshelf
fill 1 199 465 1 200 465 minecraft:bookshelf
fill 1 199 472 1 200 472 minecraft:bookshelf
fill 1 199 479 1 200 479 minecraft:bookshelf
fill 1 199 486 1 200 486 minecraft:bookshelf
fill 1 199 493 1 200 493 minecraft:bookshelf
fill 1 199 500 1 200 500 minecraft:bookshelf
fill 4 199 504 4 200 504 minecraft:bookshelf
fill 7 199 464 7 200 464 minecraft:bookshelf
fill 11 199 504 11 200 504 minecraft:bookshelf
fill 14 199 464 14 200 464 minecraft:bookshelf
fill 18 199 465 22 199 466 minecraft:bookshelf
fill 18 199 504 18 200 504 minecraft:bookshelf
fill 20 199 464 21 200 464 minecraft:bookshelf
fill 25 199 504 25 200 504 minecraft:bookshelf
fill 28 199 464 28 202 464 minecraft:bookshelf
fill 32 199 504 32 200 504 minecraft:bookshelf
fill 35 199 464 35 200 464 minecraft:bookshelf
fill 39 199 504 39 200 504 minecraft:bookshelf
fill 41 199 465 41 200 465 minecraft:bookshelf
fill 41 199 472 41 200 472 minecraft:bookshelf
fill 41 199 479 41 200 479 minecraft:bookshelf
fill 41 199 486 41 200 486 minecraft:bookshelf
fill 41 199 493 41 200 493 minecraft:bookshelf
fill 41 199 500 41 200 500 minecraft:bookshelf
fill 1 200 464 2 200 464 minecraft:bookshelf
fill 1 200 466 1 200 468 minecraft:bookshelf
fill 1 200 470 1 200 471 minecraft:bookshelf
fill 1 200 473 1 200 475 minecraft:bookshelf
fill 1 200 477 1 200 478 minecraft:bookshelf
fill 1 200 480 1 200 482 minecraft:bookshelf
fill 1 200 484 1 200 485 minecraft:bookshelf
fill 1 200 487 1 200 489 minecraft:bookshelf
fill 1 200 491 1 200 492 minecraft:bookshelf
fill 1 200 494 1 200 496 minecraft:bookshelf
fill 1 200 498 1 200 499 minecraft:bookshelf
fill 1 200 501 1 200 503 minecraft:bookshelf
fill 2 200 504 3 200 504 minecraft:bookshelf
fill 4 200 464 6 200 464 minecraft:bookshelf
fill 5 200 504 7 200 504 minecraft:bookshelf
fill 8 200 464 9 200 464 minecraft:bookshelf
fill 9 200 504 10 200 504 minecraft:bookshelf
fill 11 200 464 13 200 464 minecraft:bookshelf
fill 12 200 504 14 200 504 minecraft:bookshelf
fill 15 200 464 16 200 464 minecraft:bookshelf
fill 16 200 504 17 200 504 minecraft:bookshelf
fill 19 200 504 21 200 504 minecraft:bookshelf
fill 21 200 465 25 200 466 minecraft:bookshelf
setblock 23 200 464 minecraft:bookshelf
fill 23 200 504 24 200 504 minecraft:bookshelf
fill 25 200 464 27 201 464 minecraft:bookshelf
fill 26 200 504 28 200 504 minecraft:bookshelf
fill 29 200 464 30 200 464 minecraft:bookshelf
fill 30 200 504 31 200 504 minecraft:bookshelf
fill 32 200 464 34 200 464 minecraft:bookshelf
fill 33 200 504 35 200 504 minecraft:bookshelf
fill 36 200 464 37 200 464 minecraft:bookshelf
fill 37 200 504 38 200 504 minecraft:bookshelf
fill 39 200 464 41 200 464 minecraft:bookshelf
fill 40 200 504 41 200 504 minecraft:bookshelf
fill 41 200 466 41 200 467 minecraft:bookshelf
fill 41 200 469 41 200 471 minecraft:bookshelf
fill 41 200 473 41 200 474 minecraft:bookshelf
fill 41 200 476 41 200 478 minecraft:bookshelf
fill 41 200 480 41 200 481 minecraft:bookshelf
fill 41 200 483 41 200 485 minecraft:bookshelf
fill 41 200 487 41 200 488 minecraft:bookshelf
fill 41 200 490 41 200 492 minecraft:bookshelf
fill 41 200 494 41 200 495 minecraft:bookshelf
fill 41 200 497 41 200 499 minecraft:bookshelf
fill 41 200 501 41 200 502 minecraft:bookshelf
fill 0 201 472 0 202 472 minecraft:dark_oak_planks
fill 0 201 473 0 202 478 minecraft:bookshelf
fill 0 201 479 0 201 480 minecraft:dark_oak_planks
fill 0 201 481 0 201 489 minecraft:bookshelf
setblock 0 201 490 minecraft:dark_oak_planks
fill 0 201 491 0 201 494 minecraft:bookshelf
setblock 0 201 499 minecraft:dark_oak_planks
fill 0 201 500 0 202 505 minecraft:bookshelf
setblock 1 201 467 minecraft:bookshelf
setblock 1 201 474 minecraft:bookshelf
setblock 1 201 481 minecraft:bookshelf
setblock 1 201 488 minecraft:bookshelf
setblock 1 201 495 minecraft:bookshelf
setblock 1 201 502 minecraft:bookshelf
setblock 3 201 466 minecraft:light[level=12]
setblock 3 201 474 minecraft:light[level=12]
setblock 3 201 482 minecraft:light[level=12]
setblock 3 201 490 minecraft:light[level=12]
setblock 3 201 498 minecraft:light[level=12]
fill 4 201 505 4 202 505 minecraft:bookshelf
setblock 5 201 464 minecraft:bookshelf
setblock 5 201 505 minecraft:dark_oak_planks
fill 6 201 504 6 201 505 minecraft:bookshelf
setblock 11 201 466 minecraft:light[level=12]
setblock 11 201 474 minecraft:light[level=12]
setblock 11 201 482 minecraft:light[level=12]
setblock 11 201 490 minecraft:light[level=12]
setblock 11 201 498 minecraft:light[level=12]
setblock 12 201 464 minecraft:bookshelf
fill 13 201 504 13 201 505 minecraft:bookshelf
fill 14 201 505 15 201 505 minecraft:bookshelf
setblock 16 201 505 minecraft:dark_oak_planks
fill 17 201 505 19 204 505 minecraft:bookshelf
setblock 19 201 464 minecraft:bookshelf
setblock 19 201 466 minecraft:light[level=12]
setblock 19 201 474 minecraft:light[level=12]
setblock 19 201 482 minecraft:light[level=12]
setblock 19 201 490 minecraft:light[level=12]
setblock 19 201 498 minecraft:light[level=12]
setblock 20 201 504 minecraft:bookshelf
fill 20 201 505 21 201 505 minecraft:dark_oak_planks
fill 21 201 463 27 204 463 minecraft:bookshelf
fill 22 201 505 22 204 505 minecraft:bookshelf
fill 24 201 465 28 201 466 minecraft:bookshelf
setblock 25 201 505 minecraft:dark_oak_planks
setblock 27 201 474 minecraft:light[level=12]
setblock 27 201 482 minecraft:light[level=12]
setblock 27 201 490 minecraft:light[level=12]
setblock 27 201 498 minecraft:light[level=12]
setblock 27 201 504 minecraft:bookshelf
setblock 28 201 463 minecraft:dark_oak_planks
fill 29 201 464 29 202 464 minecraft:bookshelf
fill 32 201 463 33 204 463 minecraft:bookshelf
fill 33 201 464 33 203 464 minecraft:bookshelf
fill 34 201 463 34 202 463 minecraft:dark_oak_planks
fill 34 201 504 34 201 505 minecraft:bookshelf
fill 35 201 463 35 205 463 minecraft:bookshelf
setblock 35 201 466 minecraft:light[level=12]
setblock 35 201 474 minecraft:light[level=12]
setblock 35 201 482 minecraft:light[level=12]
setblock 35 201 490 minecraft:light[level=12]
setblock 35 201 498 minecraft:light[level=12]
fill 35 201 505 38 204 505 minecraft:bookshelf
setblock 39 201 505 minecraft:dark_oak_planks
setblock 40 201 464 minecraft:bookshelf
fill 40 201 505 41 204 505 minecraft:bookshelf
setblock 41 201 470 minecraft:bookshelf
setblock 41 201 477 minecraft:bookshelf
setblock 41 201 484 minecraft:bookshelf
fill 41 201 491 42 201 491 minecraft:bookshelf
setblock 41 201 498 minecraft:bookshelf
setblock 41 201 504 minecraft:bookshelf
fill 42 201 484 42 201 485 minecraft:dark_oak_planks
fill 42 201 488 42 204 488 minecraft:bookshelf
setblock 42 201 489 minecraft:dark_oak_planks
fill 42 201 490 42 204 490 minecraft:bookshelf
fill 42 201 494 42 204 495 minecraft:bookshelf
setblock 42 201 496 minecraft:dark_oak_planks
setblock 42 201 501 minecraft:dark_oak_planks
fill 0 202 463 0 204 464 minecraft:bookshelf
setblock 0 202 465 minecraft:dark_oak_planks
fill 0 202 466 0 202 470 minecraft:bookshelf
fill 0 202 471 0 203 471 minecraft:dark_oak_planks
fill 0 202 479 0 202 483 minecraft:bookshelf
setblock 0 202 484 minecraft:dark_oak_planks
fill 0 202 485 0 204 488 minecraft:bookshelf
setblock 0 202 489 minecraft:dark_oak_planks
fill 0 202 490 0 204 490 minecraft:bookshelf
setblock 0 202 491 minecraft:dark_oak_planks
fill 0 202 492 0 204 494 minecraft:bookshelf
fill 0 202 499 0 204 499 minecraft:bookshelf
setblock 1 202 468 minecraft:bookshelf
setblock 1 202 475 minecraft:bookshelf
setblock 1 202 482 minecraft:bookshelf
setblock 1 202 489 minecraft:bookshelf
setblock 1 202 496 minecraft:bookshelf
setblock 1 202 503 minecraft:bookshelf
setblock 4 202 464 minecraft:bookshelf
fill 5 202 463 6 202 463 minecraft:dark_oak_planks
fill 5 202 505 6 202 505 minecraft:bookshelf
fill 7 202 463 9 204 463 minecraft:bookshelf
setblock 7 202 504 minecraft:bookshelf
fill 8 202 505 8 204 505 minecraft:bookshelf
setblock 9 202 505 minecraft:dark_oak_planks
fill 10 202 505 11 202 505 minecraft:bookshelf
fill 11 202 463 11 202 464 minecraft:bookshelf
setblock 12 202 463 minecraft:dark_oak_planks
fill 13 202 463 15 204 463 minecraft:bookshelf
fill 13 202 505 14 204 505 minecraft:bookshelf
setblock 14 202 504 minecraft:bookshelf
setblock 15 202 505 minecraft:dark_oak_planks
fill 16 202 505 16 206 505 minecraft:bookshelf
fill 18 202 463 18 202 464 minecraft:bookshelf
setblock 19 202 463 minecraft:dark_oak_planks
fill 20 202 463 20 204 463 minecraft:bookshelf
fill 20 202 505 21 204 505 minecraft:bookshelf
setblock 21 202 504 minecraft:bookshelf
setblock 25 202 464 minecraft:bookshelf
fill 25 202 505 25 204 505 minecraft:bookshelf
fill 27 202 465 32 202 466 minecraft:bookshelf
fill 27 202 505 27 205 505 minecraft:bookshelf
fill 28 202 463 29 204 463 minecraft:bookshelf
setblock 28 202 504 minecraft:bookshelf
fill 28 202 505 28 203 505 minecraft:dark_oak_planks
fill 29 202 505 30 204 505 minecraft:bookshelf
setblock 30 202 463 minecraft:dark_oak_planks
setblock 30 202 464 minecraft:bookshelf
setblock 31 202 505 minecraft:dark_oak_planks
fill 32 202 464 32 203 464 minecraft:bookshelf
fill 34 202 505 34 204 505 minecraft:bookshelf
setblock 35 202 504 minecraft:bookshelf
setblock 39 202 464 minecraft:bookshelf
fill 39 202 505 39 204 505 minecraft:bookshelf
fill 41 202 469 42 202 469 minecraft:bookshelf
setblock 41 202 476 minecraft:bookshelf
setblock 41 202 483 minecraft:bookshelf
setblock 41 202 490 minecraft:bookshelf
setblock 41 202 497 minecraft:bookshelf
fill 42 202 466 42 204 467 minecraft:bookshelf
fill 42 202 468 42 203 468 minecraft:dark_oak_planks
setblock 42 202 472 minecraft:dark_oak_planks
fill 42 202 473 42 204 475 minecraft:bookshelf
setblock 42 202 482 minecraft:dark_oak_planks
setblock 42 202 484 minecraft:dark_oak_planks
fill 42 202 485 42 204 485 minecraft:bookshelf
setblock 42 202 486 minecraft:dark_oak_planks
setblock 42 202 489 minecraft:bookshelf
fill 42 202 491 42 204 491 minecraft:bookshelf
fill 42 202 496 42 204 496 minecraft:bookshelf
fill 42 202 501 42 204 501 minecraft:bookshelf
setblock 42 202 502 minecraft:dark_oak_planks
setblock 42 202 505 minecraft:dark_oak_planks
fill 0 203 465 0 204 466 minecraft:bookshelf
fill 0 203 467 0 203 468 minecraft:dark_oak_planks
fill 0 203 469 0 204 470 minecraft:bookshelf
fill 0 203 472 0 204 476 minecraft:bookshelf
setblock 0 203 477 minecraft:dark_oak_planks
fill 0 203 478 0 204 478 minecraft:bookshelf
fill 0 203 479 0 203 480 minecraft:dark_oak_planks
fill 0 203 481 0 204 484 minecraft:bookshelf
fill 0 203 489 0 204 489 minecraft:bookshelf
fill 0 203 491 0 205 491 minecraft:bookshelf
fill 0 203 500 0 204 502 minecraft:bookshelf
setblock 0 203 503 minecraft:dark_oak_planks
fill 0 203 504 0 204 505 minecraft:bookshelf
fill 4 203 505 5 203 505 minecraft:dark_oak_planks
fill 5 203 463 6 204 463 minecraft:bookshelf
fill 6 203 505 6 204 505 minecraft:bookshelf
fill 9 203 505 10 204 505 minecraft:bookshelf
fill 11 203 463 12 204 463 minecraft:bookshelf
setblock 11 203 505 minecraft:dark_oak_planks
fill 15 203 505 15 204 505 minecraft:bookshelf
fill 18 203 463 19 204 463 minecraft:bookshelf
fill 23 203 505 23 204 505 minecraft:bookshelf
setblock 24 203 505 minecraft:dark_oak_planks
setblock 26 203 505 minecraft:dark_oak_planks
fill 30 203 463 30 204 463 minecraft:bookshelf
fill 30 203 466 36 203 466 minecraft:bookshelf
fill 31 203 465 37 203 465 minecraft:bookshelf
fill 31 203 505 31 204 505 minecraft:bookshelf
fill 34 203 463 34 203 464 minecraft:bookshelf
fill 35 203 464 37 203 464 minecraft:bookshelf
fill 40 203 463 41 204 463 minecraft:bookshelf
setblock 42 203 463 minecraft:dark_oak_planks
fill 42 203 469 42 204 469 minecraft:bookshelf
fill 42 203 472 42 204 472 minecraft:bookshelf
setblock 42 203 479 minecraft:dark_oak_planks
fill 42 203 482 42 204 482 minecraft:bookshelf
fill 42 203 484 42 204 484 minecraft:bookshelf
fill 42 203 486 42 204 486 minecraft:bookshelf
setblock 42 203 489 minecraft:dark_oak_planks
setblock 42 203 497 minecraft:dark_oak_planks
fill 42 203 502 42 204 502 minecraft:bookshelf
fill 42 203 505 42 204 505 minecraft:bookshelf
fill 0 204 467 0 204 468 minecraft:bookshelf
setblock 0 204 471 minecraft:bookshelf
fill 0 204 477 1 204 477 minecraft:bookshelf
fill 0 204 479 0 204 480 minecraft:bookshelf
setblock 0 204 503 minecraft:bookshelf
setblock 1 204 470 minecraft:bookshelf
setblock 1 204 484 minecraft:bookshelf
setblock 1 204 491 minecraft:bookshelf
setblock 1 204 498 minecraft:bookshelf
setblock 2 204 464 minecraft:bookshelf
setblock 2 204 504 minecraft:bookshelf
fill 4 204 505 5 204 505 minecraft:bookshelf
setblock 9 204 464 minecraft:bookshelf
setblock 9 204 504 minecraft:bookshelf
setblock 11 204 505 minecraft:bookshelf
setblock 16 204 464 minecraft:bookshelf
setblock 16 204 504 minecraft:bookshelf
setblock 23 204 464 minecraft:bookshelf
setblock 23 204 504 minecraft:bookshelf
setblock 24 204 505 minecraft:bookshelf
setblock 26 204 505 minecraft:bookshelf
setblock 28 204 505 minecraft:bookshelf
setblock 30 204 464 minecraft:bookshelf
setblock 30 204 504 minecraft:bookshelf
setblock 34 204 463 minecraft:bookshelf
fill 34 204 466 41 204 466 minecraft:bookshelf
fill 35 204 465 41 204 465 minecraft:bookshelf
fill 36 204 464 37 204 464 minecraft:bookshelf
setblock 37 204 504 minecraft:bookshelf
fill 39 204 464 41 204 464 minecraft:bookshelf
fill 39 204 467 39 205 468 minecraft:bookshelf
fill 40 204 467 41 205 467 minecraft:bookshelf
setblock 41 204 474 minecraft:bookshelf
setblock 41 204 481 minecraft:bookshelf
setblock 41 204 488 minecraft:bookshelf
setblock 41 204 495 minecraft:bookshelf
setblock 41 204 502 minecraft:bookshelf
setblock 42 204 463 minecraft:bookshelf
fill 42 204 468 42 205 468 minecraft:bookshelf
setblock 42 204 479 minecraft:bookshelf
setblock 42 204 489 minecraft:bookshelf
setblock 42 204 497 minecraft:bookshelf
fill 0 205 463 0 205 472 minecraft:dark_oak_planks
setblock 0 205 473 minecraft:bookshelf
fill 0 205 474 0 205 483 minecraft:dark_oak_planks
setblock 0 205 484 minecraft:bookshelf
fill 0 205 485 0 205 490 minecraft:dark_oak_planks
fill 0 205 492 0 206 503 minecraft:dark_oak_planks
setblock 0 205 504 minecraft:bookshelf
fill 0 205 505 8 205 505 minecraft:dark_oak_planks
fill 1 205 463 34 205 463 minecraft:dark_oak_planks
setblock 1 205 464 minecraft:bookshelf
setblock 1 205 471 minecraft:bookshelf
setblock 1 205 478 minecraft:bookshelf
setblock 1 205 485 minecraft:bookshelf
setblock 1 205 492 minecraft:bookshelf
setblock 1 205 499 minecraft:bookshelf
setblock 3 205 504 minecraft:bookshelf
setblock 8 205 464 minecraft:bookshelf
setblock 9 205 505 minecraft:bookshelf
setblock 10 205 504 minecraft:bookshelf
fill 10 205 505 15 206 505 minecraft:dark_oak_planks
setblock 15 205 464 minecraft:bookshelf
setblock 17 205 504 minecraft:bookshelf
fill 17 205 505 26 307 505 minecraft:dark_oak_planks
setblock 22 205 464 minecraft:bookshelf
setblock 24 205 504 minecraft:bookshelf
fill 28 205 505 42 205 505 minecraft:dark_oak_planks
setblock 29 205 464 minecraft:bookshelf
setblock 31 205 504 minecraft:bookshelf
fill 36 205 463 42 205 463 minecraft:dark_oak_planks
setblock 36 205 464 minecraft:bookshelf
setblock 38 205 504 minecraft:bookshelf
fill 39 205 466 41 205 466 minecraft:bookshelf
fill 39 205 469 40 205 472 minecraft:bookshelf
fill 40 205 465 41 205 465 minecraft:bookshelf
setblock 40 205 468 minecraft:bookshelf
setblock 41 205 464 minecraft:bookshelf
fill 41 205 469 41 206 471 minecraft:bookshelf
fill 41 205 473 41 206 473 minecraft:bookshelf
setblock 41 205 480 minecraft:bookshelf
setblock 41 205 487 minecraft:bookshelf
setblock 41 205 494 minecraft:bookshelf
setblock 41 205 501 minecraft:bookshelf
fill 42 205 464 42 206 467 minecraft:dark_oak_planks
fill 42 205 469 42 205 477 minecraft:dark_oak_planks
fill 42 205 479 42 205 504 minecraft:dark_oak_planks
fill 0 206 463 0 206 465 minecraft:dark_oak_planks
setblock 0 206 466 minecraft:bookshelf
setblock 0 206 467 minecraft:dark_oak_planks
setblock 0 206 468 minecraft:bookshelf
fill 0 206 469 0 307 475 minecraft:dark_oak_planks
fill 0 206 476 0 206 477 minecraft:bookshelf
fill 0 206 478 0 206 480 minecraft:dark_oak_planks
setblock 0 206 481 minecraft:bookshelf
fill 0 206 482 0 206 486 minecraft:dark_oak_planks
fill 0 206 487 0 206 488 minecraft:bookshelf
fill 0 206 489 0 307 491 minecraft:dark_oak_planks
setblock 0 206 504 minecraft:dark_oak_planks
fill 0 206 505 0 207 505 minecraft:bookshelf
fill 1 206 463 4 307 463 minecraft:dark_oak_planks
setblock 1 206 465 minecraft:bookshelf
setblock 1 206 472 minecraft:bookshelf
setblock 1 206 479 minecraft:bookshelf
setblock 1 206 486 minecraft:bookshelf
setblock 1 206 493 minecraft:bookshelf
setblock 1 206 500 minecraft:bookshelf
fill 1 206 505 9 206 505 minecraft:dark_oak_planks
setblock 4 206 504 minecraft:bookshelf
setblock 5 206 463 minecraft:bookshelf
fill 6 206 463 10 206 463 minecraft:dark_oak_planks
setblock 7 206 464 minecraft:bookshelf
setblock 11 206 463 minecraft:bookshelf
setblock 11 206 504 minecraft:bookshelf
fill 12 206 463 35 206 463 minecraft:dark_oak_planks
setblock 14 206 464 minecraft:bookshelf
setblock 18 206 504 minecraft:bookshelf
setblock 21 206 464 minecraft:bookshelf
setblock 25 206 504 minecraft:bookshelf
fill 27 206 505 29 307 505 minecraft:dark_oak_planks
setblock 28 206 464 minecraft:bookshelf
setblock 30 206 505 minecraft:bookshelf
fill 31 206 505 41 206 505 minecraft:dark_oak_planks
setblock 32 206 504 minecraft:bookshelf
setblock 35 206 464 minecraft:bookshelf
setblock 36 206 463 minecraft:bookshelf
fill 37 206 463 38 307 463 minecraft:dark_oak_planks
setblock 39 206 463 minecraft:bookshelf
fill 39 206 471 40 206 476 minecraft:bookshelf
setblock 39 206 504 minecraft:bookshelf
fill 40 206 463 42 307 463 minecraft:dark_oak_planks
setblock 40 206 470 minecraft:bookshelf
setblock 41 206 465 minecraft:bookshelf
setblock 41 206 472 minecraft:bookshelf
fill 41 206 474 41 207 474 minecraft:bookshelf
fill 41 206 479 41 208 479 minecraft:bookshelf
fill 41 206 486 42 206 486 minecraft:bookshelf
setblock 41 206 493 minecraft:bookshelf
fill 41 206 500 42 206 500 minecraft:bookshelf
fill 42 206 468 42 206 474 minecraft:dark_oak_planks
setblock 42 206 475 minecraft:bookshelf
fill 42 206 476 42 307 479 minecraft:dark_oak_planks
setblock 42 206 480 minecraft:bookshelf
fill 42 206 481 42 307 485 minecraft:dark_oak_planks
fill 42 206 487 42 307 487 minecraft:dark_oak_planks
setblock 42 206 488 minecraft:bookshelf
fill 42 206 489 42 307 490 minecraft:dark_oak_planks
setblock 42 206 491 minecraft:bookshelf
fill 42 206 492 42 206 497 minecraft:dark_oak_planks
setblock 42 206 498 minecraft:bookshelf
fill 42 206 499 42 307 499 minecraft:dark_oak_planks
fill 42 206 501 42 307 504 minecraft:dark_oak_planks
setblock 42 206 505 minecraft:bookshelf
fill 0 207 463 0 307 464 minecraft:dark_oak_planks
setblock 0 207 465 minecraft:bookshelf
fill 0 207 466 0 307 466 minecraft:dark_oak_planks
setblock 0 207 467 minecraft:bookshelf
fill 0 207 468 0 307 468 minecraft:dark_oak_planks
fill 0 207 476 0 307 479 minecraft:dark_oak_planks
fill 0 207 480 1 207 480 minecraft:bookshelf
fill 0 207 481 0 307 483 minecraft:dark_oak_planks
setblock 0 207 484 minecraft:bookshelf
fill 0 207 485 0 307 488 minecraft:dark_oak_planks
fill 0 207 492 0 307 499 minecraft:dark_oak_planks
setblock 0 207 500 minecraft:bookshelf
fill 0 207 501 0 307 501 minecraft:dark_oak_planks
setblock 0 207 502 minecraft:bookshelf
fill 0 207 503 0 307 503 minecraft:dark_oak_planks
setblock 0 207 504 minecraft:bookshelf
setblock 1 207 466 minecraft:bookshelf
setblock 1 207 473 minecraft:bookshelf
setblock 1 207 487 minecraft:bookshelf
setblock 1 207 494 minecraft:bookshelf
setblock 1 207 501 minecraft:bookshelf
fill 1 207 505 5 307 505 minecraft:dark_oak_planks
fill 5 207 463 9 307 463 minecraft:dark_oak_planks
setblock 5 207 504 minecraft:bookshelf
setblock 6 207 464 minecraft:bookshelf
setblock 6 207 505 minecraft:bookshelf
fill 7 207 505 13 307 505 minecraft:dark_oak_planks
setblock 10 207 463 minecraft:bookshelf
fill 11 207 463 14 307 463 minecraft:dark_oak_planks
setblock 12 207 504 minecraft:bookshelf
setblock 13 207 464 minecraft:bookshelf
setblock 14 207 505 minecraft:bookshelf
setblock 15 207 463 minecraft:bookshelf
fill 15 207 505 16 307 505 minecraft:dark_oak_planks
fill 16 207 463 23 307 463 minecraft:dark_oak_planks
setblock 19 207 504 minecraft:bookshelf
setblock 20 207 464 minecraft:bookshelf
setblock 24 207 463 minecraft:bookshelf
fill 25 207 463 26 307 463 minecraft:dark_oak_planks
setblock 26 207 504 minecraft:bookshelf
fill 27 207 463 27 207 464 minecraft:bookshelf
fill 28 207 463 28 307 463 minecraft:dark_oak_planks
setblock 29 207 463 minecraft:bookshelf
fill 30 207 463 31 307 463 minecraft:dark_oak_planks
fill 30 207 505 30 307 505 minecraft:dark_oak_planks
setblock 31 207 505 minecraft:bookshelf
setblock 32 207 463 minecraft:bookshelf
fill 32 207 505 37 307 505 minecraft:dark_oak_planks
fill 33 207 463 36 307 463 minecraft:dark_oak_planks
setblock 33 207 504 minecraft:bookshelf
setblock 34 207 464 minecraft:bookshelf
setblock 38 207 505 minecraft:bookshelf
fill 39 207 463 39 307 463 minecraft:dark_oak_planks
fill 39 207 475 40 207 479 minecraft:bookshelf
fill 39 207 505 42 307 505 minecraft:dark_oak_planks
setblock 40 207 474 minecraft:bookshelf
setblock 40 207 504 minecraft:bookshelf
fill 41 207 464 42 207 464 minecraft:bookshelf
setblock 41 207 471 minecraft:bookshelf
fill 41 207 476 41 207 478 minecraft:bookshelf
setblock 41 207 485 minecraft:bookshelf
setblock 41 207 492 minecraft:bookshelf
setblock 41 207 499 minecraft:bookshelf
fill 42 207 465 42 307 469 minecraft:dark_oak_planks
setblock 42 207 470 minecraft:bookshelf
fill 42 207 471 42 307 475 minecraft:dark_oak_planks
fill 42 207 480 42 307 480 minecraft:dark_oak_planks
fill 42 207 486 42 307 486 minecraft:dark_oak_planks
fill 42 207 488 42 307 488 minecraft:dark_oak_planks
fill 42 207 491 42 307 493 minecraft:dark_oak_planks
setblock 42 207 494 minecraft:bookshelf
fill 42 207 495 42 307 496 minecraft:dark_oak_planks
setblock 42 207 497 minecraft:bookshelf
fill 42 207 498 42 307 498 minecraft:dark_oak_planks
fill 42 207 500 42 307 500 minecraft:dark_oak_planks
fill 0 208 465 0 307 465 minecraft:dark_oak_planks
fill 0 208 467 0 307 467 minecraft:dark_oak_planks
fill 0 208 480 0 307 480 minecraft:dark_oak_planks
fill 0 208 484 0 307 484 minecraft:dark_oak_planks
fill 0 208 500 0 307 500 minecraft:dark_oak_planks
fill 0 208 502 0 307 502 minecraft:dark_oak_planks
fill 0 208 504 0 307 505 minecraft:dark_oak_planks
setblock 1 208 467 minecraft:bookshelf
setblock 1 208 474 minecraft:bookshelf
setblock 1 208 481 minecraft:bookshelf
setblock 1 208 488 minecraft:bookshelf
setblock 1 208 495 minecraft:bookshelf
setblock 1 208 502 minecraft:bookshelf
setblock 5 208 464 minecraft:bookshelf
setblock 6 208 504 minecraft:bookshelf
fill 6 208 505 6 307 505 minecraft:dark_oak_planks
fill 10 208 463 10 307 463 minecraft:dark_oak_planks
setblock 12 208 464 minecraft:bookshelf
setblock 13 208 504 minecraft:bookshelf
fill 14 208 505 14 307 505 minecraft:dark_oak_planks
fill 15 208 463 15 307 463 minecraft:dark_oak_planks
setblock 19 208 464 minecraft:bookshelf
setblock 20 208 504 minecraft:bookshelf
fill 24 208 463 24 307 463 minecraft:dark_oak_planks
setblock 26 208 464 minecraft:bookshelf
fill 27 208 463 27 307 463 minecraft:dark_oak_planks
setblock 27 208 504 minecraft:bookshelf
fill 29 208 463 29 307 463 minecraft:dark_oak_planks
fill 31 208 505 31 307 505 minecraft:dark_oak_planks
fill 32 208 463 32 307 463 minecraft:dark_oak_planks
setblock 33 208 464 minecraft:bookshelf
setblock 34 208 504 minecraft:bookshelf
fill 38 208 505 38 307 505 minecraft:dark_oak_planks
fill 39 208 478 40 208 482 minecraft:bookshelf
setblock 40 208 464 minecraft:bookshelf
setblock 41 208 470 minecraft:bookshelf
fill 41 208 477 41 208 478 minecraft:bookshelf
fill 41 208 480 41 208 481 minecraft:bookshelf
fill 41 208 484 41 210 484 minecraft:bookshelf
setblock 41 208 491 minecraft:bookshelf
setblock 41 208 498 minecraft:bookshelf
setblock 41 208 504 minecraft:bookshelf
fill 42 208 464 42 307 464 minecraft:dark_oak_planks
fill 42 208 470 42 307 470 minecraft:dark_oak_planks
fill 42 208 494 42 307 494 minecraft:dark_oak_planks
fill 42 208 497 42 307 497 minecraft:dark_oak_planks
fill 1 209 468 1 210 468 minecraft:bookshelf
fill 1 209 475 1 210 475 minecraft:bookshelf
fill 1 209 482 1 210 482 minecraft:bookshelf
fill 1 209 489 1 210 489 minecraft:bookshelf
fill 1 209 496 1 210 496 minecraft:bookshelf
fill 1 209 503 1 210 503 minecraft:bookshelf
setblock 3 209 466 minecraft:light[level=12]
setblock 3 209 474 minecraft:light[level=12]
setblock 3 209 482 minecraft:light[level=12]
setblock 3 209 490 minecraft:light[level=12]
setblock 3 209 498 minecraft:light[level=12]
fill 4 209 464 4 210 464 minecraft:bookshelf
fill 7 209 504 7 210 504 minecraft:bookshelf
fill 11 209 464 11 210 464 minecraft:bookshelf
setblock 11 209 466 minecraft:light[level=12]
setblock 11 209 474 minecraft:light[level=12]
setblock 11 209 482 minecraft:light[level=12]
setblock 11 209 490 minecraft:light[level=12]
setblock 11 209 498 minecraft:light[level=12]
fill 14 209 504 14 210 504 minecraft:bookshelf
fill 18 209 464 18 210 464 minecraft:bookshelf
setblock 19 209 466 minecraft:light[level=12]
setblock 19 209 474 minecraft:light[level=12]
setblock 19 209 482 minecraft:light[level=12]
setblock 19 209 490 minecraft:light[level=12]
setblock 19 209 498 minecraft:light[level=12]
fill 21 209 504 21 210 504 minecraft:bookshelf
fill 25 209 464 25 210 464 minecraft:bookshelf
setblock 27 209 466 minecraft:light[level=12]
setblock 27 209 474 minecraft:light[level=12]
setblock 27 209 482 minecraft:light[level=12]
setblock 27 209 490 minecraft:light[level=12]
setblock 27 209 498 minecraft:light[level=12]
fill 28 209 504 28 210 504 minecraft:bookshelf
fill 32 209 464 32 210 464 minecraft:bookshelf
setblock 35 209 466 minecraft:light[level=12]
setblock 35 209 474 minecraft:light[level=12]
setblock 35 209 482 minecraft:light[level=12]
setblock 35 209 490 minecraft:light[level=12]
setblock 35 209 498 minecraft:light[level=12]
fill 35 209 504 35 210 504 minecraft:bookshelf
fill 39 209 464 39 210 464 minecraft:bookshelf
fill 39 209 481 40 209 485 minecraft:bookshelf
fill 41 209 469 41 210 469 minecraft:bookshelf
fill 41 209 476 41 210 476 minecraft:bookshelf
fill 41 209 481 41 211 481 minecraft:bookshelf
fill 41 209 483 41 210 483 minecraft:bookshelf
fill 41 209 485 41 210 485 minecraft:bookshelf
fill 41 209 490 41 211 490 minecraft:bookshelf
fill 41 209 497 41 210 497 minecraft:bookshelf
fill 1 210 464 1 210 467 minecraft:bookshelf
fill 1 210 470 1 210 474 minecraft:bookshelf
fill 1 210 477 1 210 481 minecraft:bookshelf
fill 1 210 484 1 210 488 minecraft:bookshelf
fill 1 210 491 1 210 495 minecraft:bookshelf
fill 1 210 498 1 210 502 minecraft:bookshelf
fill 2 210 464 2 211 464 minecraft:bookshelf
fill 2 210 504 6 210 504 minecraft:bookshelf
fill 5 210 464 9 210 464 minecraft:bookshelf
fill 9 210 504 13 210 504 minecraft:bookshelf
fill 12 210 464 16 210 464 minecraft:bookshelf
fill 15 210 467 16 211 468 minecraft:white_wool
fill 16 210 504 20 210 504 minecraft:bookshelf
fill 19 210 464 23 210 464 minecraft:bookshelf
fill 23 210 504 27 210 504 minecraft:bookshelf
fill 26 210 464 30 210 464 minecraft:bookshelf
fill 30 210 504 34 210 504 minecraft:bookshelf
fill 33 210 464 37 210 464 minecraft:bookshelf
fill 37 210 504 41 210 504 minecraft:bookshelf
fill 39 210 484 40 210 488 minecraft:bookshelf
fill 40 210 464 41 210 464 minecraft:bookshelf
fill 41 210 465 41 210 467 minecraft:bookshelf
fill 41 210 470 41 210 474 minecraft:bookshelf
fill 41 210 477 41 210 480 minecraft:bookshelf
fill 41 210 486 41 210 488 minecraft:bookshelf
fill 41 210 491 41 210 495 minecraft:bookshelf
fill 41 210 498 41 210 502 minecraft:bookshelf
setblock 1 211 470 minecraft:bookshelf
setblock 1 211 477 minecraft:bookshelf
setblock 1 211 484 minecraft:bookshelf
setblock 1 211 491 minecraft:bookshelf
setblock 1 211 498 minecraft:bookshelf
setblock 2 211 504 minecraft:bookshelf
setblock 9 211 464 minecraft:bookshelf
setblock 9 211 504 minecraft:bookshelf
setblock 16 211 464 minecraft:bookshelf
setblock 16 211 504 minecraft:bookshelf
setblock 23 211 464 minecraft:bookshelf
setblock 23 211 504 minecraft:bookshelf
setblock 30 211 464 minecraft:bookshelf
setblock 30 211 504 minecraft:bookshelf
setblock 37 211 464 minecraft:bookshelf
setblock 37 211 504 minecraft:bookshelf
fill 38 211 466 40 212 466 minecraft:gold_block
fill 39 211 487 40 211 491 minecraft:bookshelf
setblock 41 211 467 minecraft:bookshelf
setblock 41 211 474 minecraft:bookshelf
fill 41 211 487 41 211 488 minecraft:bookshelf
fill 41 211 491 41 212 492 minecraft:bookshelf
fill 41 211 495 41 213 495 minecraft:bookshelf
setblock 41 211 502 minecraft:bookshelf
setblock 1 212 464 minecraft:bookshelf
setblock 1 212 471 minecraft:bookshelf
setblock 1 212 478 minecraft:bookshelf
setblock 1 212 485 minecraft:bookshelf
setblock 1 212 492 minecraft:bookshelf
setblock 1 212 499 minecraft:bookshelf
setblock 3 212 504 minecraft:bookshelf
setblock 8 212 464 minecraft:bookshelf
setblock 10 212 504 minecraft:bookshelf
setblock 15 212 464 minecraft:bookshelf
setblock 17 212 504 minecraft:bookshelf
setblock 22 212 464 minecraft:bookshelf
fill 23 212 476 25 213 476 minecraft:blue_wool
fill 24 212 477 25 213 477 minecraft:blue_wool
setblock 24 212 504 minecraft:bookshelf
setblock 29 212 464 minecraft:bookshelf
setblock 31 212 504 minecraft:bookshelf
setblock 36 212 464 minecraft:bookshelf
setblock 38 212 504 minecraft:bookshelf
fill 39 212 490 40 212 495 minecraft:bookshelf
setblock 41 212 466 minecraft:bookshelf
setblock 41 212 473 minecraft:bookshelf
setblock 41 212 480 minecraft:bookshelf
setblock 41 212 487 minecraft:bookshelf
fill 41 212 493 41 213 494 minecraft:bookshelf
fill 41 212 501 41 214 501 minecraft:bookshelf
setblock 1 213 465 minecraft:bookshelf
setblock 1 213 472 minecraft:bookshelf
setblock 1 213 479 minecraft:bookshelf
setblock 1 213 486 minecraft:bookshelf
setblock 1 213 493 minecraft:bookshelf
setblock 1 213 500 minecraft:bookshelf
setblock 4 213 504 minecraft:bookshelf
setblock 7 213 464 minecraft:bookshelf
setblock 11 213 504 minecraft:bookshelf
setblock 14 213 464 minecraft:bookshelf
setblock 18 213 504 minecraft:bookshelf
setblock 21 213 464 minecraft:bookshelf
setblock 25 213 504 minecraft:bookshelf
setblock 28 213 464 minecraft:bookshelf
setblock 32 213 504 minecraft:bookshelf
setblock 35 213 464 minecraft:bookshelf
fill 39 213 493 39 213 499 minecraft:bookshelf
fill 39 213 504 39 215 504 minecraft:bookshelf
fill 40 213 494 40 213 500 minecraft:bookshelf
setblock 41 213 465 minecraft:bookshelf
setblock 41 213 472 minecraft:bookshelf
setblock 41 213 479 minecraft:bookshelf
setblock 41 213 486 minecraft:bookshelf
fill 41 213 497 41 213 500 minecraft:bookshelf
setblock 1 214 466 minecraft:bookshelf
setblock 1 214 473 minecraft:bookshelf
setblock 1 214 480 minecraft:bookshelf
setblock 1 214 487 minecraft:bookshelf
setblock 1 214 494 minecraft:bookshelf
setblock 1 214 501 minecraft:bookshelf
setblock 5 214 504 minecraft:bookshelf
setblock 6 214 464 minecraft:bookshelf
setblock 12 214 504 minecraft:bookshelf
setblock 13 214 464 minecraft:bookshelf
fill 18 214 466 22 215 470 minecraft:dark_oak_planks
setblock 19 214 504 minecraft:bookshelf
setblock 20 214 464 minecraft:bookshelf
setblock 20 214 465 minecraft:dark_oak_planks
setblock 26 214 504 minecraft:bookshelf
setblock 27 214 464 minecraft:bookshelf
setblock 33 214 504 minecraft:bookshelf
setblock 34 214 464 minecraft:bookshelf
fill 37 214 502 41 214 502 minecraft:bookshelf
fill 38 214 503 40 215 503 minecraft:bookshelf
fill 39 214 497 39 214 501 minecraft:bookshelf
fill 40 214 498 40 214 501 minecraft:bookshelf
fill 40 214 504 41 215 504 minecraft:bookshelf
setblock 41 214 464 minecraft:bookshelf
setblock 41 214 471 minecraft:bookshelf
setblock 41 214 478 minecraft:bookshelf
setblock 41 214 485 minecraft:bookshelf
setblock 41 214 492 minecraft:bookshelf
fill 41 214 499 41 214 500 minecraft:bookshelf
setblock 1 215 467 minecraft:bookshelf
setblock 1 215 474 minecraft:bookshelf
setblock 1 215 481 minecraft:bookshelf
setblock 1 215 488 minecraft:bookshelf
setblock 1 215 495 minecraft:bookshelf
setblock 1 215 502 minecraft:bookshelf
setblock 5 215 464 minecraft:bookshelf
setblock 6 215 504 minecraft:bookshelf
setblock 12 215 464 minecraft:bookshelf
setblock 13 215 504 minecraft:bookshelf
setblock 19 215 464 minecraft:bookshelf
setblock 20 215 504 minecraft:bookshelf
setblock 26 215 464 minecraft:bookshelf
setblock 27 215 504 minecraft:bookshelf
setblock 33 215 464 minecraft:bookshelf
fill 33 215 502 37 215 503 minecraft:bookshelf
fill 34 215 504 35 216 504 minecraft:bookshelf
fill 37 215 504 38 215 504 minecraft:bookshelf
fill 38 215 502 39 215 502 minecraft:bookshelf
setblock 40 215 464 minecraft:bookshelf
setblock 41 215 470 minecraft:bookshelf
setblock 41 215 477 minecraft:bookshelf
setblock 41 215 484 minecraft:bookshelf
setblock 41 215 491 minecraft:bookshelf
setblock 41 215 498 minecraft:bookshelf
setblock 1 216 468 minecraft:bookshelf
setblock 1 216 475 minecraft:bookshelf
setblock 1 216 482 minecraft:bookshelf
setblock 1 216 489 minecraft:bookshelf
setblock 1 216 496 minecraft:bookshelf
setblock 1 216 503 minecraft:bookshelf
setblock 4 216 464 minecraft:bookshelf
setblock 7 216 504 minecraft:bookshelf
setblock 11 216 464 minecraft:bookshelf
setblock 14 216 504 minecraft:bookshelf
setblock 18 216 464 minecraft:bookshelf
fill 19 216 468 21 223 468 minecraft:purple_concrete
fill 20 216 467 20 223 467 minecraft:purple_concrete
fill 20 216 469 20 223 469 minecraft:purple_concrete
setblock 21 216 504 minecraft:bookshelf
setblock 25 216 464 minecraft:bookshelf
fill 28 216 504 28 217 504 minecraft:bookshelf
fill 29 216 502 34 216 503 minecraft:bookshelf
fill 30 216 504 33 216 504 minecraft:bookshelf
setblock 32 216 464 minecraft:bookshelf
setblock 35 216 503 minecraft:bookshelf
setblock 39 216 464 minecraft:bookshelf
setblock 41 216 469 minecraft:bookshelf
setblock 41 216 476 minecraft:bookshelf
setblock 41 216 483 minecraft:bookshelf
setblock 41 216 490 minecraft:bookshelf
setblock 41 216 497 minecraft:bookshelf
setblock 3 217 466 minecraft:light[level=12]
setblock 3 217 474 minecraft:light[level=12]
setblock 3 217 482 minecraft:light[level=12]
setblock 3 217 490 minecraft:light[level=12]
setblock 3 217 498 minecraft:light[level=12]
setblock 11 217 466 minecraft:light[level=12]
setblock 11 217 474 minecraft:light[level=12]
setblock 11 217 482 minecraft:light[level=12]
setblock 11 217 490 minecraft:light[level=12]
setblock 11 217 498 minecraft:light[level=12]
setblock 19 217 466 minecraft:light[level=12]
setblock 19 217 474 minecraft:light[level=12]
setblock 19 217 482 minecraft:light[level=12]
setblock 19 217 490 minecraft:light[level=12]
setblock 19 217 498 minecraft:light[level=12]
fill 26 217 502 27 218 504 minecraft:bookshelf
setblock 27 217 466 minecraft:light[level=12]
setblock 27 217 474 minecraft:light[level=12]
setblock 27 217 482 minecraft:light[level=12]
setblock 27 217 490 minecraft:light[level=12]
setblock 27 217 498 minecraft:light[level=12]
fill 28 217 502 30 217 503 minecraft:bookshelf
fill 30 217 504 31 217 504 minecraft:bookshelf
setblock 31 217 503 minecraft:bookshelf
setblock 35 217 466 minecraft:light[level=12]
setblock 35 217 474 minecraft:light[level=12]
setblock 35 217 482 minecraft:light[level=12]
setblock 35 217 490 minecraft:light[level=12]
setblock 35 217 498 minecraft:light[level=12]
setblock 1 218 470 minecraft:bookshelf
setblock 1 218 477 minecraft:bookshelf
setblock 1 218 484 minecraft:bookshelf
fill 1 218 489 3 219 489 minecraft:gold_block
setblock 1 218 491 minecraft:bookshelf
setblock 1 218 498 minecraft:bookshelf
setblock 2 218 464 minecraft:bookshelf
setblock 2 218 504 minecraft:bookshelf
setblock 9 218 464 minecraft:bookshelf
setblock 9 218 504 minecraft:bookshelf
setblock 16 218 464 minecraft:bookshelf
setblock 16 218 504 minecraft:bookshelf
setblock 23 218 464 minecraft:bookshelf
fill 23 218 502 25 218 504 minecraft:bookshelf
setblock 30 218 464 minecraft:bookshelf
setblock 30 218 504 minecraft:bookshelf
setblock 37 218 464 minecraft:bookshelf
setblock 37 218 504 minecraft:bookshelf
setblock 41 218 467 minecraft:bookshelf
setblock 41 218 474 minecraft:bookshelf
setblock 41 218 481 minecraft:bookshelf
setblock 41 218 488 minecraft:bookshelf
setblock 41 218 495 minecraft:bookshelf
setblock 41 218 502 minecraft:bookshelf
fill 1 219 464 1 220 464 minecraft:bookshelf
fill 1 219 471 1 220 471 minecraft:bookshelf
fill 1 219 478 1 220 478 minecraft:bookshelf
fill 1 219 485 1 220 485 minecraft:bookshelf
fill 1 219 492 1 220 492 minecraft:bookshelf
fill 1 219 499 1 220 499 minecraft:bookshelf
fill 3 219 504 3 220 504 minecraft:bookshelf
fill 8 219 464 8 220 464 minecraft:bookshelf
fill 10 219 504 10 220 504 minecraft:bookshelf
fill 15 219 464 15 220 464 minecraft:bookshelf
fill 17 219 504 17 221 504 minecraft:bookshelf
fill 20 219 502 21 220 504 minecraft:bookshelf
fill 22 219 464 22 220 464 minecraft:bookshelf
fill 22 219 502 24 219 503 minecraft:bookshelf
fill 23 219 504 24 220 504 minecraft:bookshelf
fill 29 219 464 29 220 464 minecraft:bookshelf
fill 31 219 504 31 220 504 minecraft:bookshelf
fill 36 219 464 36 220 464 minecraft:bookshelf
fill 38 219 504 38 220 504 minecraft:bookshelf
fill 41 219 466 41 220 466 minecraft:bookshelf
fill 41 219 473 41 220 473 minecraft:bookshelf
fill 41 219 480 41 220 480 minecraft:bookshelf
fill 41 219 487 41 220 487 minecraft:bookshelf
fill 41 219 494 41 220 494 minecraft:bookshelf
fill 41 219 501 41 220 501 minecraft:bookshelf
fill 1 220 465 1 220 468 minecraft:bookshelf
setblock 1 220 470 minecraft:bookshelf
fill 1 220 472 1 220 475 minecraft:bookshelf
setblock 1 220 477 minecraft:bookshelf
fill 1 220 479 1 220 482 minecraft:bookshelf
setblock 1 220 484 minecraft:bookshelf
fill 1 220 486 1 220 489 minecraft:bookshelf
setblock 1 220 491 minecraft:bookshelf
fill 1 220 493 1 220 496 minecraft:bookshelf
setblock 1 220 498 minecraft:bookshelf
fill 1 220 500 1 220 503 minecraft:bookshelf
setblock 2 220 464 minecraft:bookshelf
setblock 2 220 504 minecraft:bookshelf
fill 4 220 464 7 220 464 minecraft:bookshelf
fill 4 220 504 7 220 504 minecraft:bookshelf
setblock 9 220 464 minecraft:bookshelf
fill 9 220 481 10 221 481 minecraft:red_wool
setblock 9 220 504 minecraft:bookshelf
fill 10 220 480 10 221 480 minecraft:red_wool
fill 11 220 464 14 220 464 minecraft:bookshelf
fill 11 220 504 14 220 504 minecraft:bookshelf
setblock 16 220 464 minecraft:bookshelf
fill 16 220 504 16 221 504 minecraft:bookshelf
fill 17 220 502 19 220 503 minecraft:bookshelf
fill 18 220 464 21 220 464 minecraft:bookshelf
fill 18 220 504 19 221 504 minecraft:bookshelf
setblock 23 220 464 minecraft:bookshelf
fill 25 220 464 28 220 464 minecraft:bookshelf
fill 25 220 504 28 220 504 minecraft:bookshelf
setblock 30 220 464 minecraft:bookshelf
setblock 30 220 504 minecraft:bookshelf
fill 32 220 464 35 220 464 minecraft:bookshelf
fill 32 220 504 35 220 504 minecraft:bookshelf
setblock 37 220 464 minecraft:bookshelf
setblock 37 220 504 minecraft:bookshelf
fill 39 220 464 41 220 464 minecraft:bookshelf
fill 39 220 504 41 220 504 minecraft:bookshelf
setblock 41 220 465 minecraft:bookshelf
setblock 41 220 467 minecraft:bookshelf
fill 41 220 469 41 220 472 minecraft:bookshelf
setblock 41 220 474 minecraft:bookshelf
fill 41 220 476 41 220 479 minecraft:bookshelf
setblock 41 220 481 minecraft:bookshelf
fill 41 220 483 41 220 486 minecraft:bookshelf
setblock 41 220 488 minecraft:bookshelf
fill 41 220 490 41 220 493 minecraft:bookshelf
setblock 41 220 495 minecraft:bookshelf
fill 41 220 497 41 220 500 minecraft:bookshelf
setblock 41 220 502 minecraft:bookshelf
setblock 1 221 466 minecraft:bookshelf
setblock 1 221 473 minecraft:bookshelf
setblock 1 221 480 minecraft:bookshelf
setblock 1 221 487 minecraft:bookshelf
setblock 1 221 494 minecraft:bookshelf
setblock 1 221 501 minecraft:bookshelf
setblock 5 221 504 minecraft:bookshelf
setblock 6 221 464 minecraft:bookshelf
fill 12 221 504 14 222 504 minecraft:bookshelf
setblock 13 221 464 minecraft:bookshelf
fill 14 221 502 18 221 503 minecraft:bookshelf
setblock 20 221 464 minecraft:bookshelf
setblock 26 221 504 minecraft:bookshelf
setblock 27 221 464 minecraft:bookshelf
setblock 33 221 504 minecraft:bookshelf
setblock 34 221 464 minecraft:bookshelf
setblock 40 221 504 minecraft:bookshelf
setblock 41 221 464 minecraft:bookshelf
setblock 41 221 471 minecraft:bookshelf
setblock 41 221 478 minecraft:bookshelf
setblock 41 221 485 minecraft:bookshelf
setblock 41 221 492 minecraft:bookshelf
setblock 41 221 499 minecraft:bookshelf
setblock 1 222 467 minecraft:bookshelf
setblock 1 222 474 minecraft:bookshelf
setblock 1 222 481 minecraft:bookshelf
setblock 1 222 488 minecraft:bookshelf
setblock 1 222 495 minecraft:bookshelf
setblock 1 222 502 minecraft:bookshelf
setblock 5 222 464 minecraft:bookshelf
fill 6 222 504 6 223 504 minecraft:bookshelf
fill 9 222 504 11 223 504 minecraft:bookshelf
fill 10 222 502 15 222 503 minecraft:bookshelf
setblock 12 222 464 minecraft:bookshelf
setblock 19 222 464 minecraft:bookshelf
setblock 20 222 504 minecraft:bookshelf
setblock 26 222 464 minecraft:bookshelf
setblock 27 222 504 minecraft:bookshelf
setblock 33 222 464 minecraft:bookshelf
setblock 34 222 504 minecraft:bookshelf
setblock 40 222 464 minecraft:bookshelf
setblock 41 222 470 minecraft:bookshelf
setblock 41 222 477 minecraft:bookshelf
setblock 41 222 484 minecraft:bookshelf
setblock 41 222 491 minecraft:bookshelf
setblock 41 222 498 minecraft:bookshelf
setblock 41 222 504 minecraft:bookshelf
setblock 1 223 468 minecraft:bookshelf
setblock 1 223 475 minecraft:bookshelf
setblock 1 223 482 minecraft:bookshelf
setblock 1 223 489 minecraft:bookshelf
setblock 1 223 496 minecraft:bookshelf
setblock 1 223 503 minecraft:bookshelf
setblock 4 223 464 minecraft:bookshelf
fill 4 223 504 5 223 504 minecraft:bookshelf
fill 5 223 503 11 223 503 minecraft:bookshelf
fill 6 223 502 12 223 502 minecraft:bookshelf
setblock 7 223 504 minecraft:bookshelf
setblock 11 223 464 minecraft:bookshelf
setblock 14 223 504 minecraft:bookshelf
setblock 18 223 464 minecraft:bookshelf
setblock 21 223 504 minecraft:bookshelf
setblock 25 223 464 minecraft:bookshelf
setblock 28 223 504 minecraft:bookshelf
setblock 32 223 464 minecraft:bookshelf
setblock 35 223 504 minecraft:bookshelf
setblock 39 223 464 minecraft:bookshelf
setblock 41 223 469 minecraft:bookshelf
setblock 41 223 476 minecraft:bookshelf
setblock 41 223 483 minecraft:bookshelf
setblock 41 223 490 minecraft:bookshelf
setblock 41 223 497 minecraft:bookshelf
setblock 3 225 466 minecraft:light[level=12]
setblock 3 225 474 minecraft:light[level=12]
setblock 3 225 482 minecraft:light[level=12]
setblock 3 225 490 minecraft:light[level=12]
setblock 3 225 498 minecraft:light[level=12]
setblock 11 225 466 minecraft:light[level=12]
setblock 11 225 474 minecraft:light[level=12]
setblock 11 225 482 minecraft:light[level=12]
setblock 11 225 490 minecraft:light[level=12]
setblock 11 225 498 minecraft:light[level=12]
setblock 19 225 466 minecraft:light[level=12]
setblock 19 225 474 minecraft:light[level=12]
setblock 19 225 482 minecraft:light[level=12]
setblock 19 225 490 minecraft:light[level=12]
setblock 19 225 498 minecraft:light[level=12]
setblock 27 225 466 minecraft:light[level=12]
setblock 27 225 474 minecraft:light[level=12]
setblock 27 225 482 minecraft:light[level=12]
setblock 27 225 490 minecraft:light[level=12]
setblock 27 225 498 minecraft:light[level=12]
setblock 35 225 466 minecraft:light[level=12]
setblock 35 225 474 minecraft:light[level=12]
setblock 35 225 482 minecraft:light[level=12]
setblock 35 225 490 minecraft:light[level=12]
setblock 35 225 498 minecraft:light[level=12]
fill 1 229 464 1 229 467 minecraft:red_wool
fill 1 229 468 1 229 471 minecraft:blue_wool
fill 1 229 472 1 229 475 minecraft:red_wool
fill 1 229 476 1 229 479 minecraft:blue_wool
fill 1 229 480 1 229 483 minecraft:red_wool
fill 1 229 484 1 229 487 minecraft:blue_wool
fill 1 229 488 1 229 491 minecraft:red_wool
fill 1 229 492 1 229 495 minecraft:blue_wool
fill 1 229 496 1 229 499 minecraft:red_wool
fill 1 229 500 1 229 503 minecraft:blue_wool
setblock 1 229 504 minecraft:red_wool
fill 2 229 464 5 229 467 minecraft:blue_wool
fill 2 229 468 5 229 471 minecraft:red_wool
fill 2 229 472 5 229 475 minecraft:blue_wool
fill 2 229 476 5 229 479 minecraft:red_wool
fill 2 229 480 5 229 483 minecraft:blue_wool
fill 2 229 484 5 229 487 minecraft:red_wool
fill 2 229 488 5 229 491 minecraft:blue_wool
fill 2 229 492 5 229 495 minecraft:red_wool
fill 2 229 496 5 229 499 minecraft:blue_wool
fill 2 229 500 5 229 503 minecraft:red_wool
fill 2 229 504 5 229 504 minecraft:blue_wool
fill 6 229 464 9 229 467 minecraft:red_wool
fill 6 229 468 9 229 471 minecraft:blue_wool
fill 6 229 472 9 229 475 minecraft:red_wool
fill 6 229 476 9 229 479 minecraft:blue_wool
fill 6 229 480 9 229 483 minecraft:red_wool
fill 6 229 484 9 229 487 minecraft:blue_wool
fill 6 229 488 9 229 491 minecraft:red_wool
fill 6 229 492 9 229 495 minecraft:blue_wool
fill 6 229 496 9 229 499 minecraft:red_wool
fill 6 229 500 9 229 503 minecraft:blue_wool
fill 6 229 504 9 229 504 minecraft:red_wool
fill 10 229 464 13 229 467 minecraft:blue_wool
fill 10 229 468 13 229 471 minecraft:red_wool
fill 10 229 472 13 229 475 minecraft:blue_wool
fill 10 229 476 13 229 479 minecraft:red_wool
fill 10 229 480 13 229 483 minecraft:blue_wool
fill 10 229 484 13 229 487 minecraft:red_wool
fill 10 229 488 13 229 491 minecraft:blue_wool
fill 10 229 492 13 229 495 minecraft:red_wool
fill 10 229 496 13 229 499 minecraft:blue_wool
fill 10 229 500 13 229 503 minecraft:red_wool
fill 10 229 504 13 229 504 minecraft:blue_wool
fill 14 229 464 17 229 467 minecraft:red_wool
fill 14 229 468 17 229 471 minecraft:blue_wool
fill 14 229 472 17 229 475 minecraft:red_wool
fill 14 229 476 17 229 479 minecraft:blue_wool
fill 14 229 480 17 229 483 minecraft:red_wool
fill 14 229 484 17 229 487 minecraft:blue_wool
fill 14 229 488 17 229 491 minecraft:red_wool
fill 14 229 492 17 229 495 minecraft:blue_wool
fill 14 229 496 17 229 499 minecraft:red_wool
fill 14 229 500 17 229 503 minecraft:blue_wool
fill 14 229 504 17 229 504 minecraft:red_wool
fill 18 229 464 21 229 467 minecraft:blue_wool
fill 18 229 468 21 229 471 minecraft:red_wool
fill 18 229 472 21 229 475 minecraft:blue_wool
fill 18 229 476 21 229 479 minecraft:red_wool
fill 18 229 480 20 229 483 minecraft:blue_wool
fill 18 229 484 19 229 487 minecraft:red_wool
fill 18 229 488 21 229 491 minecraft:blue_wool
fill 18 229 492 21 229 495 minecraft:red_wool
fill 18 229 496 21 229 499 minecraft:blue_wool
fill 18 229 500 21 229 503 minecraft:red_wool
fill 18 229 504 21 229 504 minecraft:blue_wool
fill 20 229 485 20 229 487 minecraft:red_wool
fill 21 229 480 21 229 482 minecraft:blue_wool
fill 21 229 486 21 229 487 minecraft:red_wool
fill 22 229 464 25 229 467 minecraft:red_wool
fill 22 229 468 25 229 471 minecraft:blue_wool
fill 22 229 472 25 229 475 minecraft:red_wool
fill 22 229 476 25 229 479 minecraft:blue_wool
fill 22 229 480 25 229 481 minecraft:red_wool
fill 22 229 487 25 229 487 minecraft:blue_wool
fill 22 229 488 25 229 491 minecraft:red_wool
fill 22 229 492 25 229 495 minecraft:blue_wool
fill 22 229 496 25 229 499 minecraft:red_wool
fill 22 229 500 25 229 503 minecraft:blue_wool
fill 22 229 504 25 229 504 minecraft:red_wool
fill 23 229 482 25 229 482 minecraft:red_wool
fill 23 229 486 25 229 486 minecraft:blue_wool
fill 24 229 483 25 229 483 minecraft:red_wool
fill 24 229 485 25 229 485 minecraft:blue_wool
setblock 25 229 484 minecraft:blue_wool
fill 26 229 464 29 229 467 minecraft:blue_wool
fill 26 229 468 29 229 471 minecraft:red_wool
fill 26 229 472 29 229 475 minecraft:blue_wool
fill 26 229 476 29 229 479 minecraft:red_wool
fill 26 229 480 29 229 483 minecraft:blue_wool
fill 26 229 484 29 229 487 minecraft:red_wool
fill 26 229 488 29 229 491 minecraft:blue_wool
fill 26 229 492 29 229 495 minecraft:red_wool
fill 26 229 496 29 229 499 minecraft:blue_wool
fill 26 229 500 29 229 503 minecraft:red_wool
fill 26 229 504 29 229 504 minecraft:blue_wool
fill 30 229 464 33 229 467 minecraft:red_wool
fill 30 229 468 33 229 471 minecraft:blue_wool
fill 30 229 472 33 229 475 minecraft:red_wool
fill 30 229 476 33 229 479 minecraft:blue_wool
fill 30 229 480 33 229 483 minecraft:red_wool
fill 30 229 484 33 229 487 minecraft:blue_wool
fill 30 229 488 33 229 491 minecraft:red_wool
fill 30 229 492 33 229 495 minecraft:blue_wool
fill 30 229 496 33 229 499 minecraft:red_wool
fill 30 229 500 33 229 503 minecraft:blue_wool
fill 30 229 504 33 229 504 minecraft:red_wool
fill 34 229 464 37 229 467 minecraft:blue_wool
fill 34 229 468 37 229 471 minecraft:red_wool
fill 34 229 472 37 229 475 minecraft:blue_wool
fill 34 229 476 37 229 479 minecraft:red_wool
fill 34 229 480 37 229 483 minecraft:blue_wool
fill 34 229 484 37 229 487 minecraft:red_wool
fill 34 229 488 37 229 491 minecraft:blue_wool
fill 34 229 492 37 229 495 minecraft:red_wool
fill 34 229 496 37 229 499 minecraft:blue_wool
fill 34 229 500 37 229 503 minecraft:red_wool
fill 34 229 504 37 229 504 minecraft:blue_wool
fill 38 229 464 41 229 467 minecraft:red_wool
fill 38 229 468 41 229 471 minecraft:blue_wool
fill 38 229 472 41 229 475 minecraft:red_wool
fill 38 229 476 41 229 479 minecraft:blue_wool
fill 38 229 480 41 229 483 minecraft:red_wool
fill 38 229 484 41 229 487 minecraft:blue_wool
fill 38 229 488 41 229 491 minecraft:red_wool
fill 38 229 492 41 229 495 minecraft:blue_wool
fill 38 229 496 41 229 499 minecraft:red_wool
fill 38 229 500 41 229 503 minecraft:blue_wool
fill 38 229 504 41 229 504 minecraft:red_wool
fill 1 230 464 41 230 464 minecraft:dark_oak_planks
fill 1 230 465 1 230 467 minecraft:red_wool
fill 1 230 468 41 230 468 minecraft:dark_oak_planks
fill 1 230 469 1 230 471 minecraft:blue_wool
fill 1 230 472 41 230 472 minecraft:dark_oak_planks
fill 1 230 473 1 230 475 minecraft:red_wool
fill 1 230 476 41 230 476 minecraft:dark_oak_planks
fill 1 230 477 1 230 479 minecraft:blue_wool
fill 1 230 480 41 230 480 minecraft:dark_oak_planks
fill 1 230 481 1 230 483 minecraft:red_wool
fill 1 230 484 18 230 484 minecraft:dark_oak_planks
fill 1 230 485 1 230 487 minecraft:blue_wool
fill 1 230 488 41 230 488 minecraft:dark_oak_planks
fill 1 230 489 1 230 491 minecraft:red_wool
fill 1 230 492 41 230 492 minecraft:dark_oak_planks
fill 1 230 493 1 230 495 minecraft:blue_wool
fill 1 230 496 41 230 496 minecraft:dark_oak_planks
fill 1 230 497 1 230 499 minecraft:red_wool
fill 1 230 500 41 230 500 minecraft:dark_oak_planks
fill 1 230 501 1 230 503 minecraft:blue_wool
fill 1 230 504 41 230 504 minecraft:dark_oak_planks
fill 2 230 465 2 230 467 minecraft:dark_oak_planks
fill 2 230 469 2 230 471 minecraft:dark_oak_planks
fill 2 230 473 2 230 475 minecraft:dark_oak_planks
fill 2 230 477 2 230 479 minecraft:dark_oak_planks
fill 2 230 481 2 230 483 minecraft:dark_oak_planks
fill 2 230 485 2 230 487 minecraft:dark_oak_planks
fill 2 230 489 2 230 491 minecraft:dark_oak_planks
fill 2 230 493 2 230 495 minecraft:dark_oak_planks
fill 2 230 497 2 230 499 minecraft:dark_oak_planks
fill 2 230 501 2 230 503 minecraft:dark_oak_planks
fill 3 230 465 5 230 467 minecraft:blue_wool
fill 3 230 469 5 230 471 minecraft:red_wool
fill 3 230 473 5 230 475 minecraft:blue_wool
fill 3 230 477 5 230 479 minecraft:red_wool
fill 3 230 481 5 230 483 minecraft:blue_wool
fill 3 230 485 5 230 487 minecraft:red_wool
fill 3 230 489 5 230 491 minecraft:blue_wool
fill 3 230 493 5 230 495 minecraft:red_wool
fill 3 230 497 5 230 499 minecraft:blue_wool
fill 3 230 501 5 230 503 minecraft:red_wool
fill 6 230 465 6 230 467 minecraft:dark_oak_planks
fill 6 230 469 6 230 471 minecraft:dark_oak_planks
fill 6 230 473 6 230 475 minecraft:dark_oak_planks
fill 6 230 477 6 230 479 minecraft:dark_oak_planks
fill 6 230 481 6 230 483 minecraft:dark_oak_planks
fill 6 230 485 6 230 487 minecraft:dark_oak_planks
fill 6 230 489 6 230 491 minecraft:dark_oak_planks
fill 6 230 493 6 230 495 minecraft:dark_oak_planks
fill 6 230 497 6 230 499 minecraft:dark_oak_planks
fill 6 230 501 6 230 503 minecraft:dark_oak_planks
fill 7 230 465 9 230 467 minecraft:red_wool
fill 7 230 469 9 230 471 minecraft:blue_wool
fill 7 230 473 9 230 475 minecraft:red_wool
fill 7 230 477 9 230 479 minecraft:blue_wool
fill 7 230 481 9 230 483 minecraft:red_wool
fill 7 230 485 9 230 487 minecraft:blue_wool
fill 7 230 489 9 230 491 minecraft:red_wool
fill 7 230 493 9 230 495 minecraft:blue_wool
fill 7 230 497 9 230 499 minecraft:red_wool
fill 7 230 501 9 230 503 minecraft:blue_wool
fill 10 230 465 10 230 467 minecraft:dark_oak_planks
fill 10 230 469 10 230 471 minecraft:dark_oak_planks
fill 10 230 473 10 230 475 minecraft:dark_oak_planks
fill 10 230 477 10 230 479 minecraft:dark_oak_planks
fill 10 230 481 10 230 483 minecraft:dark_oak_planks
fill 10 230 485 10 230 487 minecraft:dark_oak_planks
fill 10 230 489 10 230 491 minecraft:dark_oak_planks
fill 10 230 493 10 230 495 minecraft:dark_oak_planks
fill 10 230 497 10 230 499 minecraft:dark_oak_planks
fill 10 230 501 10 230 503 minecraft:dark_oak_planks
fill 11 230 465 13 230 467 minecraft:blue_wool
fill 11 230 469 13 230 471 minecraft:red_wool
fill 11 230 473 13 230 475 minecraft:blue_wool
fill 11 230 477 13 230 479 minecraft:red_wool
fill 11 230 481 13 230 483 minecraft:blue_wool
fill 11 230 485 13 230 487 minecraft:red_wool
fill 11 230 489 13 230 491 minecraft:blue_wool
fill 11 230 493 13 230 495 minecraft:red_wool
fill 11 230 497 13 230 499 minecraft:blue_wool
fill 11 230 501 13 230 503 minecraft:red_wool
fill 14 230 465 14 230 467 minecraft:dark_oak_planks
fill 14 230 469 14 230 471 minecraft:dark_oak_planks
fill 14 230 473 14 230 475 minecraft:dark_oak_planks
fill 14 230 477 14 230 479 minecraft:dark_oak_planks
fill 14 230 481 14 230 483 minecraft:dark_oak_planks
fill 14 230 485 14 230 487 minecraft:dark_oak_planks
fill 14 230 489 14 230 491 minecraft:dark_oak_planks
fill 14 230 493 14 230 495 minecraft:dark_oak_planks
fill 14 230 497 14 230 499 minecraft:dark_oak_planks
fill 14 230 501 14 230 503 minecraft:dark_oak_planks
fill 15 230 465 17 230 467 minecraft:red_wool
fill 15 230 469 17 230 471 minecraft:blue_wool
fill 15 230 473 17 230 475 minecraft:red_wool
fill 15 230 477 17 230 479 minecraft:blue_wool
fill 15 230 481 17 230 483 minecraft:red_wool
fill 15 230 485 17 230 487 minecraft:blue_wool
fill 15 230 489 17 230 491 minecraft:red_wool
fill 15 230 493 17 230 495 minecraft:blue_wool
fill 15 230 497 17 230 499 minecraft:red_wool
fill 15 230 501 17 230 503 minecraft:blue_wool
fill 18 230 465 18 230 467 minecraft:dark_oak_planks
fill 18 230 469 18 230 471 minecraft:dark_oak_planks
fill 18 230 473 18 230 475 minecraft:dark_oak_planks
fill 18 230 477 18 230 479 minecraft:dark_oak_planks
fill 18 230 481 18 230 483 minecraft:dark_oak_planks
fill 18 230 485 18 230 487 minecraft:dark_oak_planks
fill 18 230 489 18 230 491 minecraft:dark_oak_planks
fill 18 230 493 18 230 495 minecraft:dark_oak_planks
fill 18 230 497 18 230 499 minecraft:dark_oak_planks
fill 18 230 501 18 230 503 minecraft:dark_oak_planks
fill 19 230 465 21 230 467 minecraft:blue_wool
fill 19 230 469 21 230 471 minecraft:red_wool
fill 19 230 473 21 230 475 minecraft:blue_wool
fill 19 230 477 21 230 479 minecraft:red_wool
fill 19 230 481 19 230 482 minecraft:blue_wool
fill 19 230 483 19 230 485 minecraft:ochre_froglight
fill 19 230 486 19 230 487 minecraft:red_wool
fill 19 230 489 21 230 491 minecraft:blue_wool
fill 19 230 493 21 230 495 minecraft:red_wool
fill 19 230 497 21 230 499 minecraft:blue_wool
fill 19 230 501 21 230 503 minecraft:red_wool
setblock 20 230 481 minecraft:blue_wool
fill 20 230 482 20 230 483 minecraft:ochre_froglight
fill 20 230 485 20 230 486 minecraft:ochre_froglight
setblock 20 230 487 minecraft:red_wool
fill 21 230 481 21 230 482 minecraft:ochre_froglight
fill 21 230 486 21 230 487 minecraft:ochre_froglight
schedule function dropper:buildpart/108_3 1t
