setblock 558 211 474 minecraft:gold_block
setblock 558 211 481 minecraft:gold_block
setblock 558 211 488 minecraft:gold_block
setblock 558 211 495 minecraft:gold_block
setblock 558 211 502 minecraft:gold_block
setblock 518 212 464 minecraft:gold_block
setblock 518 212 471 minecraft:gold_block
setblock 518 212 478 minecraft:gold_block
setblock 518 212 485 minecraft:gold_block
setblock 518 212 492 minecraft:gold_block
setblock 518 212 499 minecraft:gold_block
setblock 520 212 504 minecraft:gold_block
setblock 525 212 464 minecraft:gold_block
setblock 527 212 504 minecraft:gold_block
setblock 532 212 464 minecraft:gold_block
setblock 534 212 504 minecraft:gold_block
setblock 539 212 464 minecraft:gold_block
setblock 541 212 504 minecraft:gold_block
setblock 546 212 464 minecraft:gold_block
setblock 548 212 504 minecraft:gold_block
setblock 553 212 464 minecraft:gold_block
setblock 555 212 504 minecraft:gold_block
setblock 558 212 466 minecraft:gold_block
setblock 558 212 473 minecraft:gold_block
setblock 558 212 480 minecraft:gold_block
setblock 558 212 487 minecraft:gold_block
setblock 558 212 494 minecraft:gold_block
setblock 558 212 501 minecraft:gold_block
setblock 518 213 465 minecraft:gold_block
setblock 518 213 472 minecraft:gold_block
setblock 518 213 479 minecraft:gold_block
setblock 518 213 486 minecraft:gold_block
setblock 518 213 493 minecraft:gold_block
setblock 518 213 500 minecraft:gold_block
setblock 521 213 504 minecraft:gold_block
setblock 524 213 464 minecraft:gold_block
setblock 528 213 504 minecraft:gold_block
setblock 531 213 464 minecraft:gold_block
setblock 535 213 504 minecraft:gold_block
setblock 538 213 464 minecraft:gold_block
setblock 542 213 504 minecraft:gold_block
setblock 545 213 464 minecraft:gold_block
setblock 549 213 504 minecraft:gold_block
setblock 552 213 464 minecraft:gold_block
setblock 556 213 504 minecraft:gold_block
setblock 558 213 465 minecraft:gold_block
setblock 558 213 472 minecraft:gold_block
setblock 558 213 479 minecraft:gold_block
setblock 558 213 486 minecraft:gold_block
setblock 558 213 493 minecraft:gold_block
setblock 558 213 500 minecraft:gold_block
setblock 518 214 466 minecraft:gold_block
setblock 518 214 473 minecraft:gold_block
setblock 518 214 480 minecraft:gold_block
setblock 518 214 487 minecraft:gold_block
setblock 518 214 494 minecraft:gold_block
setblock 518 214 501 minecraft:gold_block
setblock 520 214 466 minecraft:light[level=12]
setblock 520 214 474 minecraft:light[level=12]
setblock 520 214 482 minecraft:light[level=12]
setblock 520 214 490 minecraft:light[level=12]
setblock 520 214 498 minecraft:light[level=12]
setblock 522 214 504 minecraft:gold_block
setblock 523 214 464 minecraft:gold_block
setblock 528 214 466 minecraft:light[level=12]
setblock 528 214 474 minecraft:light[level=12]
setblock 528 214 482 minecraft:light[level=12]
setblock 528 214 490 minecraft:light[level=12]
setblock 528 214 498 minecraft:light[level=12]
setblock 529 214 504 minecraft:gold_block
setblock 530 214 464 minecraft:gold_block
setblock 536 214 466 minecraft:light[level=12]
setblock 536 214 474 minecraft:light[level=12]
setblock 536 214 482 minecraft:light[level=12]
setblock 536 214 490 minecraft:light[level=12]
setblock 536 214 498 minecraft:light[level=12]
setblock 536 214 504 minecraft:gold_block
setblock 537 214 464 minecraft:gold_block
setblock 543 214 504 minecraft:gold_block
setblock 544 214 464 minecraft:gold_block
setblock 544 214 466 minecraft:light[level=12]
setblock 544 214 474 minecraft:light[level=12]
setblock 544 214 482 minecraft:light[level=12]
setblock 544 214 490 minecraft:light[level=12]
setblock 544 214 498 minecraft:light[level=12]
setblock 550 214 504 minecraft:gold_block
setblock 551 214 464 minecraft:gold_block
setblock 552 214 466 minecraft:light[level=12]
setblock 552 214 474 minecraft:light[level=12]
setblock 552 214 482 minecraft:light[level=12]
setblock 552 214 490 minecraft:light[level=12]
setblock 552 214 498 minecraft:light[level=12]
setblock 557 214 504 minecraft:gold_block
setblock 558 214 464 minecraft:gold_block
setblock 558 214 471 minecraft:gold_block
setblock 558 214 478 minecraft:gold_block
setblock 558 214 485 minecraft:gold_block
setblock 558 214 492 minecraft:gold_block
setblock 558 214 499 minecraft:gold_block
setblock 518 215 467 minecraft:gold_block
setblock 518 215 474 minecraft:gold_block
setblock 518 215 481 minecraft:gold_block
setblock 518 215 488 minecraft:gold_block
setblock 518 215 495 minecraft:gold_block
setblock 518 215 502 minecraft:gold_block
setblock 522 215 464 minecraft:gold_block
setblock 523 215 504 minecraft:gold_block
setblock 529 215 464 minecraft:gold_block
setblock 530 215 504 minecraft:gold_block
setblock 536 215 464 minecraft:gold_block
setblock 537 215 504 minecraft:gold_block
setblock 543 215 464 minecraft:gold_block
setblock 544 215 504 minecraft:gold_block
setblock 550 215 464 minecraft:gold_block
setblock 551 215 504 minecraft:gold_block
setblock 557 215 464 minecraft:gold_block
setblock 558 215 470 minecraft:gold_block
setblock 558 215 477 minecraft:gold_block
setblock 558 215 484 minecraft:gold_block
setblock 558 215 491 minecraft:gold_block
setblock 558 215 498 minecraft:gold_block
setblock 558 215 504 minecraft:gold_block
setblock 518 216 468 minecraft:gold_block
setblock 518 216 475 minecraft:gold_block
setblock 518 216 482 minecraft:gold_block
setblock 518 216 489 minecraft:gold_block
setblock 518 216 496 minecraft:gold_block
setblock 518 216 503 minecraft:gold_block
setblock 521 216 464 minecraft:gold_block
setblock 524 216 504 minecraft:gold_block
setblock 528 216 464 minecraft:gold_block
setblock 531 216 504 minecraft:gold_block
setblock 535 216 464 minecraft:gold_block
setblock 538 216 504 minecraft:gold_block
setblock 542 216 464 minecraft:gold_block
setblock 545 216 504 minecraft:gold_block
setblock 549 216 464 minecraft:gold_block
setblock 552 216 504 minecraft:gold_block
setblock 556 216 464 minecraft:gold_block
setblock 558 216 469 minecraft:gold_block
setblock 558 216 476 minecraft:gold_block
setblock 558 216 483 minecraft:gold_block
setblock 558 216 490 minecraft:gold_block
setblock 558 216 497 minecraft:gold_block
setblock 518 218 470 minecraft:gold_block
setblock 518 218 477 minecraft:gold_block
setblock 518 218 484 minecraft:gold_block
setblock 518 218 491 minecraft:gold_block
setblock 518 218 498 minecraft:gold_block
setblock 519 218 464 minecraft:gold_block
setblock 519 218 504 minecraft:gold_block
setblock 526 218 464 minecraft:gold_block
setblock 526 218 504 minecraft:gold_block
setblock 533 218 464 minecraft:gold_block
setblock 533 218 504 minecraft:gold_block
setblock 540 218 464 minecraft:gold_block
setblock 540 218 504 minecraft:gold_block
setblock 547 218 464 minecraft:gold_block
setblock 547 218 504 minecraft:gold_block
setblock 554 218 464 minecraft:gold_block
setblock 554 218 504 minecraft:gold_block
setblock 558 218 467 minecraft:gold_block
setblock 558 218 474 minecraft:gold_block
setblock 558 218 481 minecraft:gold_block
setblock 558 218 488 minecraft:gold_block
setblock 558 218 495 minecraft:gold_block
setblock 558 218 502 minecraft:gold_block
setblock 517 219 464 minecraft:red_wool
fill 517 219 489 517 220 489 minecraft:red_wool
fill 517 219 491 517 220 492 minecraft:red_terracotta
setblock 517 219 493 minecraft:red_wool
fill 517 219 494 517 219 499 minecraft:red_terracotta
fill 517 219 501 517 222 501 minecraft:red_terracotta
setblock 517 219 502 minecraft:red_wool
fill 517 219 503 517 222 505 minecraft:red_terracotta
fill 518 219 464 518 220 464 minecraft:gold_block
fill 518 219 471 518 220 471 minecraft:gold_block
fill 518 219 478 518 220 478 minecraft:gold_block
fill 518 219 485 518 220 485 minecraft:gold_block
fill 518 219 492 518 220 492 minecraft:gold_block
fill 518 219 499 518 220 499 minecraft:gold_block
fill 519 219 463 519 222 463 minecraft:red_terracotta
setblock 520 219 463 minecraft:red_wool
fill 520 219 504 520 220 504 minecraft:gold_block
fill 521 219 463 530 219 463 minecraft:red_terracotta
fill 525 219 464 525 220 464 minecraft:gold_block
fill 527 219 504 527 220 504 minecraft:gold_block
fill 532 219 464 532 220 464 minecraft:gold_block
fill 534 219 504 534 220 504 minecraft:gold_block
fill 539 219 464 539 220 464 minecraft:gold_block
fill 540 219 463 540 220 463 minecraft:red_terracotta
fill 541 219 463 541 220 463 minecraft:red_wool
fill 541 219 504 541 220 504 minecraft:gold_block
fill 542 219 463 542 222 463 minecraft:red_terracotta
setblock 543 219 463 minecraft:red_wool
fill 544 219 463 546 222 463 minecraft:red_terracotta
fill 546 219 464 546 220 464 minecraft:gold_block
setblock 547 219 505 minecraft:red_wool
fill 548 219 504 548 220 504 minecraft:gold_block
fill 548 219 505 548 223 505 minecraft:red_terracotta
fill 549 219 469 549 222 469 minecraft:white_wool
fill 549 219 505 550 219 505 minecraft:red_wool
fill 551 219 505 553 219 505 minecraft:red_terracotta
fill 553 219 464 553 220 464 minecraft:gold_block
fill 555 219 504 555 220 504 minecraft:gold_block
fill 558 219 466 558 220 466 minecraft:gold_block
fill 558 219 473 558 220 473 minecraft:gold_block
fill 558 219 480 558 220 480 minecraft:gold_block
fill 558 219 487 558 220 487 minecraft:gold_block
fill 558 219 494 558 220 494 minecraft:gold_block
fill 558 219 501 558 220 501 minecraft:gold_block
fill 559 219 475 559 222 476 minecraft:red_terracotta
setblock 559 219 477 minecraft:red_wool
fill 559 219 478 559 222 484 minecraft:red_terracotta
setblock 559 219 485 minecraft:red_wool
fill 559 219 486 559 222 488 minecraft:red_terracotta
setblock 559 219 489 minecraft:red_wool
fill 559 219 490 559 220 495 minecraft:red_terracotta
setblock 559 219 496 minecraft:red_wool
fill 517 220 464 517 222 464 minecraft:red_terracotta
fill 517 220 466 517 220 467 minecraft:red_wool
fill 517 220 468 517 220 471 minecraft:red_terracotta
setblock 517 220 473 minecraft:red_wool
fill 517 220 474 517 222 474 minecraft:red_terracotta
fill 517 220 481 517 222 483 minecraft:red_terracotta
setblock 517 220 484 minecraft:red_wool
fill 517 220 485 517 222 488 minecraft:red_terracotta
fill 517 220 493 517 222 494 minecraft:red_terracotta
setblock 517 220 495 minecraft:red_wool
fill 517 220 496 517 222 498 minecraft:red_terracotta
fill 517 220 499 517 221 499 minecraft:red_wool
fill 517 220 502 517 222 502 minecraft:red_terracotta
fill 518 220 465 518 220 468 minecraft:gold_block
setblock 518 220 470 minecraft:gold_block
fill 518 220 472 518 220 475 minecraft:gold_block
setblock 518 220 477 minecraft:gold_block
fill 518 220 479 518 220 482 minecraft:gold_block
setblock 518 220 484 minecraft:gold_block
fill 518 220 486 518 220 489 minecraft:gold_block
setblock 518 220 491 minecraft:gold_block
fill 518 220 493 518 220 496 minecraft:gold_block
setblock 518 220 498 minecraft:gold_block
fill 518 220 500 518 220 503 minecraft:gold_block
setblock 519 220 464 minecraft:gold_block
setblock 519 220 504 minecraft:gold_block
fill 520 220 463 529 220 463 minecraft:red_terracotta
fill 521 220 464 524 220 464 minecraft:gold_block
fill 521 220 504 524 220 504 minecraft:gold_block
fill 524 220 505 527 220 505 minecraft:red_terracotta
setblock 526 220 464 minecraft:gold_block
setblock 526 220 504 minecraft:gold_block
fill 528 220 464 531 220 464 minecraft:gold_block
fill 528 220 504 531 220 504 minecraft:gold_block
setblock 528 220 505 minecraft:red_wool
fill 529 220 505 530 222 505 minecraft:red_terracotta
setblock 530 220 463 minecraft:red_wool
fill 532 220 463 534 222 463 minecraft:red_terracotta
setblock 533 220 464 minecraft:gold_block
setblock 533 220 504 minecraft:gold_block
setblock 535 220 463 minecraft:red_wool
fill 535 220 464 538 220 464 minecraft:gold_block
fill 535 220 504 538 220 504 minecraft:gold_block
fill 536 220 463 537 220 463 minecraft:red_terracotta
setblock 538 220 463 minecraft:red_wool
setblock 540 220 464 minecraft:gold_block
setblock 540 220 504 minecraft:gold_block
fill 542 220 464 545 220 464 minecraft:gold_block
fill 542 220 504 545 220 504 minecraft:gold_block
fill 543 220 463 543 222 463 minecraft:red_terracotta
fill 547 220 463 547 223 463 minecraft:red_terracotta
setblock 547 220 464 minecraft:gold_block
setblock 547 220 504 minecraft:gold_block
fill 547 220 505 547 222 505 minecraft:red_terracotta
setblock 548 220 463 minecraft:red_wool
fill 549 220 463 549 222 463 minecraft:red_terracotta
fill 549 220 464 552 220 464 minecraft:gold_block
fill 549 220 504 552 220 504 minecraft:gold_block
fill 549 220 505 551 220 505 minecraft:red_terracotta
fill 551 220 463 551 222 463 minecraft:red_terracotta
setblock 552 220 463 minecraft:red_wool
setblock 552 220 505 minecraft:red_wool
fill 553 220 463 553 223 463 minecraft:red_terracotta
fill 553 220 505 554 220 505 minecraft:red_terracotta
setblock 554 220 464 minecraft:gold_block
setblock 554 220 504 minecraft:gold_block
setblock 555 220 505 minecraft:red_wool
fill 556 220 464 558 220 464 minecraft:gold_block
fill 556 220 504 558 220 504 minecraft:gold_block
setblock 558 220 465 minecraft:gold_block
setblock 558 220 467 minecraft:gold_block
fill 558 220 469 558 220 472 minecraft:gold_block
setblock 558 220 474 minecraft:gold_block
fill 558 220 476 558 220 479 minecraft:gold_block
setblock 558 220 481 minecraft:gold_block
fill 558 220 483 558 220 486 minecraft:gold_block
setblock 558 220 488 minecraft:gold_block
fill 558 220 490 558 220 493 minecraft:gold_block
setblock 558 220 495 minecraft:gold_block
fill 558 220 497 558 220 500 minecraft:gold_block
setblock 558 220 502 minecraft:gold_block
fill 559 220 477 559 222 477 minecraft:red_terracotta
fill 559 220 485 559 222 485 minecraft:red_terracotta
fill 559 220 489 559 222 489 minecraft:red_terracotta
fill 559 220 496 559 222 496 minecraft:red_terracotta
setblock 559 220 499 minecraft:red_wool
fill 559 220 500 559 220 504 minecraft:red_terracotta
setblock 559 220 505 minecraft:red_wool
fill 517 221 466 517 222 468 minecraft:red_terracotta
setblock 517 221 469 minecraft:red_wool
fill 517 221 470 517 222 471 minecraft:red_terracotta
fill 517 221 473 517 222 473 minecraft:red_terracotta
fill 517 221 484 517 222 484 minecraft:red_terracotta
fill 517 221 489 517 222 489 minecraft:red_terracotta
setblock 517 221 491 minecraft:red_wool
fill 517 221 492 517 222 492 minecraft:red_terracotta
fill 517 221 495 517 222 495 minecraft:red_terracotta
setblock 518 221 466 minecraft:gold_block
setblock 518 221 473 minecraft:gold_block
setblock 518 221 480 minecraft:gold_block
setblock 518 221 487 minecraft:gold_block
setblock 518 221 494 minecraft:gold_block
setblock 518 221 501 minecraft:gold_block
fill 518 221 505 519 222 505 minecraft:red_terracotta
fill 520 221 463 520 222 463 minecraft:red_terracotta
setblock 520 221 505 minecraft:red_wool
fill 521 221 463 522 221 463 minecraft:red_wool
fill 521 221 505 522 222 505 minecraft:red_terracotta
setblock 522 221 504 minecraft:gold_block
fill 523 221 463 525 222 463 minecraft:red_terracotta
setblock 523 221 464 minecraft:gold_block
fill 524 221 505 525 222 505 minecraft:red_terracotta
setblock 526 221 463 minecraft:red_wool
setblock 526 221 505 minecraft:red_wool
fill 527 221 463 530 222 463 minecraft:red_terracotta
fill 527 221 505 528 222 505 minecraft:red_terracotta
setblock 529 221 504 minecraft:gold_block
setblock 530 221 464 minecraft:gold_block
fill 532 221 505 532 222 505 minecraft:red_terracotta
setblock 533 221 505 minecraft:red_wool
fill 534 221 497 534 234 497 minecraft:white_wool
fill 534 221 505 534 222 505 minecraft:red_terracotta
fill 535 221 463 536 222 463 minecraft:red_terracotta
setblock 536 221 504 minecraft:gold_block
setblock 537 221 463 minecraft:red_wool
setblock 537 221 464 minecraft:gold_block
fill 538 221 463 538 222 463 minecraft:red_terracotta
setblock 540 221 463 minecraft:red_wool
fill 541 221 463 541 222 463 minecraft:red_terracotta
setblock 543 221 504 minecraft:gold_block
setblock 544 221 464 minecraft:gold_block
fill 545 221 505 545 222 505 minecraft:red_terracotta
setblock 546 221 505 minecraft:red_wool
fill 548 221 463 548 222 463 minecraft:red_terracotta
fill 549 221 505 550 221 505 minecraft:red_wool
setblock 550 221 504 minecraft:gold_block
setblock 551 221 464 minecraft:gold_block
fill 551 221 505 552 222 505 minecraft:red_terracotta
fill 552 221 463 552 222 463 minecraft:red_terracotta
setblock 553 221 505 minecraft:red_wool
fill 554 221 505 555 222 505 minecraft:red_terracotta
setblock 555 221 463 minecraft:red_wool
setblock 557 221 504 minecraft:gold_block
setblock 558 221 464 minecraft:gold_block
setblock 558 221 471 minecraft:gold_block
setblock 558 221 478 minecraft:gold_block
setblock 558 221 485 minecraft:gold_block
setblock 558 221 492 minecraft:gold_block
setblock 558 221 499 minecraft:gold_block
fill 559 221 490 559 222 493 minecraft:red_terracotta
setblock 559 221 494 minecraft:red_wool
fill 559 221 495 559 223 495 minecraft:red_terracotta
setblock 559 221 497 minecraft:red_wool
fill 559 221 499 559 222 500 minecraft:red_terracotta
setblock 559 221 501 minecraft:red_wool
fill 559 221 502 559 222 502 minecraft:red_terracotta
setblock 559 221 503 minecraft:red_wool
fill 559 221 504 559 222 505 minecraft:red_terracotta
setblock 517 222 469 minecraft:red_terracotta
setblock 517 222 491 minecraft:red_terracotta
setblock 517 222 499 minecraft:red_terracotta
setblock 518 222 467 minecraft:gold_block
setblock 518 222 474 minecraft:gold_block
setblock 518 222 481 minecraft:gold_block
setblock 518 222 488 minecraft:gold_block
setblock 518 222 495 minecraft:gold_block
setblock 518 222 502 minecraft:gold_block
setblock 520 222 466 minecraft:light[level=12]
setblock 520 222 474 minecraft:light[level=12]
setblock 520 222 482 minecraft:light[level=12]
setblock 520 222 490 minecraft:light[level=12]
setblock 520 222 498 minecraft:light[level=12]
setblock 520 222 505 minecraft:red_terracotta
fill 521 222 463 522 222 463 minecraft:red_terracotta
setblock 522 222 464 minecraft:gold_block
setblock 523 222 504 minecraft:gold_block
setblock 526 222 463 minecraft:red_terracotta
setblock 526 222 505 minecraft:red_terracotta
setblock 528 222 466 minecraft:light[level=12]
setblock 528 222 474 minecraft:light[level=12]
setblock 528 222 482 minecraft:light[level=12]
setblock 528 222 490 minecraft:light[level=12]
setblock 528 222 498 minecraft:light[level=12]
setblock 529 222 464 minecraft:gold_block
setblock 530 222 504 minecraft:gold_block
setblock 533 222 505 minecraft:red_terracotta
setblock 536 222 464 minecraft:gold_block
setblock 536 222 466 minecraft:light[level=12]
setblock 536 222 474 minecraft:light[level=12]
setblock 536 222 482 minecraft:light[level=12]
setblock 536 222 490 minecraft:light[level=12]
setblock 536 222 498 minecraft:light[level=12]
setblock 537 222 463 minecraft:red_terracotta
setblock 537 222 504 minecraft:gold_block
setblock 540 222 463 minecraft:red_terracotta
setblock 543 222 464 minecraft:gold_block
setblock 544 222 466 minecraft:light[level=12]
setblock 544 222 474 minecraft:light[level=12]
setblock 544 222 482 minecraft:light[level=12]
setblock 544 222 490 minecraft:light[level=12]
setblock 544 222 498 minecraft:light[level=12]
setblock 544 222 504 minecraft:gold_block
setblock 546 222 505 minecraft:red_terracotta
fill 549 222 505 550 222 505 minecraft:red_terracotta
setblock 550 222 464 minecraft:gold_block
setblock 551 222 504 minecraft:gold_block
setblock 552 222 466 minecraft:light[level=12]
setblock 552 222 474 minecraft:light[level=12]
setblock 552 222 482 minecraft:light[level=12]
setblock 552 222 490 minecraft:light[level=12]
setblock 552 222 498 minecraft:light[level=12]
setblock 553 222 505 minecraft:red_terracotta
setblock 555 222 463 minecraft:red_terracotta
setblock 557 222 464 minecraft:gold_block
setblock 558 222 470 minecraft:gold_block
setblock 558 222 477 minecraft:gold_block
setblock 558 222 484 minecraft:gold_block
setblock 558 222 491 minecraft:gold_block
setblock 558 222 498 minecraft:gold_block
setblock 558 222 504 minecraft:gold_block
setblock 559 222 494 minecraft:red_terracotta
setblock 559 222 497 minecraft:red_terracotta
setblock 559 222 501 minecraft:red_terracotta
setblock 559 222 503 minecraft:red_terracotta
fill 517 223 463 517 224 463 minecraft:red_terracotta
fill 517 223 464 517 223 478 minecraft:red_wool
setblock 517 223 479 minecraft:red_terracotta
fill 517 223 480 517 307 482 minecraft:red_wool
setblock 517 223 483 minecraft:red_terracotta
fill 517 223 484 517 224 484 minecraft:red_wool
setblock 517 223 485 minecraft:red_terracotta
fill 517 223 486 517 307 489 minecraft:red_wool
fill 517 223 491 517 224 505 minecraft:red_wool
fill 518 223 463 520 223 463 minecraft:red_wool
setblock 518 223 468 minecraft:gold_block
setblock 518 223 475 minecraft:gold_block
setblock 518 223 482 minecraft:gold_block
setblock 518 223 489 minecraft:gold_block
setblock 518 223 496 minecraft:gold_block
setblock 518 223 503 minecraft:gold_block
fill 518 223 505 518 224 505 minecraft:red_wool
fill 519 223 505 519 224 505 minecraft:red_terracotta
fill 520 223 505 521 307 505 minecraft:red_wool
fill 521 223 463 521 224 463 minecraft:red_terracotta
setblock 521 223 464 minecraft:gold_block
fill 522 223 463 531 223 463 minecraft:red_wool
setblock 522 223 505 minecraft:red_terracotta
setblock 524 223 504 minecraft:gold_block
fill 524 223 505 536 223 505 minecraft:red_wool
setblock 528 223 464 minecraft:gold_block
setblock 531 223 504 minecraft:gold_block
setblock 532 223 463 minecraft:red_terracotta
fill 533 223 463 546 307 463 minecraft:red_wool
setblock 535 223 464 minecraft:gold_block
setblock 537 223 505 minecraft:red_terracotta
setblock 538 223 504 minecraft:gold_block
fill 538 223 505 542 224 505 minecraft:red_wool
setblock 542 223 464 minecraft:gold_block
setblock 543 223 505 minecraft:red_terracotta
fill 544 223 505 547 223 505 minecraft:red_wool
fill 545 223 464 547 223 469 minecraft:dark_oak_planks
setblock 545 223 504 minecraft:gold_block
fill 548 223 463 549 224 463 minecraft:red_wool
fill 548 223 465 553 223 469 minecraft:dark_oak_planks
fill 549 223 464 549 224 464 minecraft:gold_block
fill 549 223 505 559 223 505 minecraft:red_wool
fill 550 223 464 553 223 464 minecraft:dark_oak_planks
fill 551 223 463 552 252 463 minecraft:red_wool
setblock 552 223 504 minecraft:gold_block
fill 554 223 463 558 224 463 minecraft:red_wool
setblock 556 223 464 minecraft:gold_block
setblock 558 223 469 minecraft:gold_block
setblock 558 223 476 minecraft:gold_block
setblock 558 223 483 minecraft:gold_block
setblock 558 223 490 minecraft:gold_block
setblock 558 223 497 minecraft:gold_block
setblock 559 223 463 minecraft:red_terracotta
fill 559 223 464 559 223 467 minecraft:red_wool
setblock 559 223 468 minecraft:red_terracotta
fill 559 223 469 559 223 470 minecraft:red_wool
fill 559 223 471 559 224 471 minecraft:red_terracotta
fill 559 223 472 559 224 473 minecraft:red_wool
fill 559 223 475 559 223 477 minecraft:red_wool
setblock 559 223 478 minecraft:red_terracotta
fill 559 223 479 559 223 491 minecraft:red_wool
setblock 559 223 492 minecraft:red_terracotta
fill 559 223 493 559 307 494 minecraft:red_wool
fill 559 223 496 559 223 504 minecraft:red_wool
fill 517 224 464 517 224 466 minecraft:red_wool
setblock 517 224 467 minecraft:red_terracotta
fill 517 224 468 517 307 477 minecraft:red_wool
fill 517 224 478 517 225 478 minecraft:red_terracotta
fill 517 224 479 517 307 479 minecraft:red_wool
fill 517 224 483 517 307 483 minecraft:red_wool
fill 517 224 485 517 307 485 minecraft:red_wool
fill 517 224 490 517 307 490 minecraft:red_wool
setblock 518 224 463 minecraft:red_terracotta
fill 519 224 463 520 307 463 minecraft:red_wool
fill 522 224 463 528 307 463 minecraft:red_wool
fill 522 224 505 525 307 505 minecraft:red_wool
setblock 526 224 505 minecraft:red_terracotta
fill 527 224 505 537 224 505 minecraft:red_wool
setblock 529 224 463 minecraft:red_terracotta
fill 530 224 463 532 307 463 minecraft:red_wool
fill 543 224 505 544 307 505 minecraft:red_wool
fill 545 224 464 547 224 469 minecraft:gold_block
setblock 545 224 505 minecraft:red_terracotta
fill 546 224 505 550 307 505 minecraft:red_wool
fill 547 224 463 547 307 463 minecraft:red_wool
fill 548 224 465 553 224 469 minecraft:gold_block
setblock 550 224 463 minecraft:red_wool
fill 550 224 464 553 224 464 minecraft:gold_block
setblock 551 224 505 minecraft:red_terracotta
fill 552 224 505 554 307 505 minecraft:red_wool
fill 553 224 463 553 307 463 minecraft:red_wool
fill 555 224 505 555 225 505 minecraft:red_terracotta
fill 556 224 505 559 307 505 minecraft:red_wool
fill 559 224 463 559 307 465 minecraft:red_wool
setblock 559 224 466 minecraft:red_terracotta
fill 559 224 467 559 307 468 minecraft:red_wool
setblock 559 224 469 minecraft:red_terracotta
fill 559 224 470 559 307 470 minecraft:red_wool
fill 559 224 474 559 307 475 minecraft:red_wool
setblock 559 224 476 minecraft:red_terracotta
fill 559 224 477 559 307 488 minecraft:red_wool
fill 559 224 489 559 225 489 minecraft:red_terracotta
fill 559 224 490 559 224 492 minecraft:red_wool
fill 559 224 495 559 307 495 minecraft:red_wool
setblock 559 224 496 minecraft:red_terracotta
fill 559 224 497 559 224 504 minecraft:red_wool
fill 517 225 463 518 307 463 minecraft:red_wool
setblock 517 225 464 minecraft:red_terracotta
fill 517 225 465 517 307 467 minecraft:red_wool
setblock 517 225 484 minecraft:red_terracotta
setblock 517 225 491 minecraft:red_terracotta
fill 517 225 492 517 307 502 minecraft:red_wool
fill 517 225 503 517 225 505 minecraft:red_terracotta
setblock 518 225 470 minecraft:gold_block
setblock 518 225 477 minecraft:gold_block
setblock 518 225 484 minecraft:gold_block
setblock 518 225 491 minecraft:gold_block
setblock 518 225 498 minecraft:gold_block
setblock 518 225 505 minecraft:red_terracotta
setblock 519 225 464 minecraft:gold_block
setblock 519 225 504 minecraft:gold_block
fill 519 225 505 519 307 505 minecraft:red_wool
fill 521 225 463 521 307 463 minecraft:red_wool
setblock 526 225 464 minecraft:gold_block
setblock 526 225 504 minecraft:gold_block
fill 526 225 505 528 307 505 minecraft:red_wool
fill 529 225 463 529 307 463 minecraft:red_wool
setblock 529 225 505 minecraft:red_terracotta
fill 530 225 505 530 307 505 minecraft:red_wool
fill 531 225 505 532 225 505 minecraft:red_terracotta
setblock 533 225 464 minecraft:gold_block
setblock 533 225 504 minecraft:gold_block
fill 533 225 505 540 307 505 minecraft:red_wool
setblock 540 225 464 minecraft:gold_block
setblock 540 225 504 minecraft:gold_block
setblock 541 225 505 minecraft:red_terracotta
fill 542 225 499 542 228 499 minecraft:white_wool
fill 542 225 505 542 307 505 minecraft:red_wool
fill 545 225 469 553 225 469 minecraft:red_wool
fill 545 225 505 545 307 505 minecraft:red_wool
setblock 547 225 464 minecraft:gold_block
setblock 547 225 504 minecraft:gold_block
fill 548 225 463 550 228 463 minecraft:ochre_froglight
fill 551 225 505 551 307 505 minecraft:red_wool
setblock 554 225 463 minecraft:red_terracotta
setblock 554 225 464 minecraft:gold_block
setblock 554 225 504 minecraft:gold_block
fill 555 225 463 558 307 463 minecraft:red_wool
setblock 558 225 467 minecraft:gold_block
setblock 558 225 474 minecraft:gold_block
setblock 558 225 481 minecraft:gold_block
setblock 558 225 488 minecraft:gold_block
setblock 558 225 495 minecraft:gold_block
setblock 558 225 502 minecraft:gold_block
fill 559 225 466 559 307 466 minecraft:red_wool
fill 559 225 469 559 307 469 minecraft:red_wool
fill 559 225 471 559 307 471 minecraft:red_wool
fill 559 225 472 559 225 473 minecraft:red_terracotta
fill 559 225 476 559 307 476 minecraft:red_wool
fill 559 225 490 559 307 491 minecraft:red_wool
setblock 559 225 492 minecraft:red_terracotta
fill 559 225 496 559 307 500 minecraft:red_wool
setblock 559 225 501 minecraft:red_terracotta
fill 559 225 502 559 307 504 minecraft:red_wool
fill 517 226 464 517 307 464 minecraft:red_wool
fill 517 226 478 517 307 478 minecraft:red_wool
fill 517 226 484 517 307 484 minecraft:red_wool
fill 517 226 491 517 307 491 minecraft:red_wool
fill 517 226 503 517 307 505 minecraft:red_wool
setblock 518 226 464 minecraft:gold_block
setblock 518 226 471 minecraft:gold_block
setblock 518 226 478 minecraft:gold_block
setblock 518 226 485 minecraft:gold_block
setblock 518 226 492 minecraft:gold_block
setblock 518 226 499 minecraft:gold_block
fill 518 226 505 518 307 505 minecraft:red_wool
setblock 520 226 504 minecraft:gold_block
setblock 525 226 464 minecraft:gold_block
setblock 527 226 504 minecraft:gold_block
fill 529 226 505 529 307 505 minecraft:red_wool
fill 531 226 505 532 307 505 minecraft:red_wool
setblock 532 226 464 minecraft:gold_block
setblock 534 226 504 minecraft:gold_block
setblock 539 226 464 minecraft:gold_block
setblock 541 226 504 minecraft:gold_block
fill 541 226 505 541 307 505 minecraft:red_wool
setblock 545 226 469 minecraft:gold_block
setblock 546 226 464 minecraft:gold_block
setblock 548 226 504 minecraft:gold_block
setblock 549 226 469 minecraft:gold_block
setblock 553 226 464 minecraft:gold_block
setblock 553 226 469 minecraft:gold_block
fill 554 226 463 554 307 463 minecraft:red_wool
setblock 555 226 504 minecraft:gold_block
fill 555 226 505 555 307 505 minecraft:red_wool
setblock 558 226 466 minecraft:gold_block
setblock 558 226 473 minecraft:gold_block
setblock 558 226 480 minecraft:gold_block
setblock 558 226 487 minecraft:gold_block
setblock 558 226 494 minecraft:gold_block
setblock 558 226 501 minecraft:gold_block
fill 559 226 472 559 307 473 minecraft:red_wool
fill 559 226 489 559 307 489 minecraft:red_wool
fill 559 226 492 559 307 492 minecraft:red_wool
fill 559 226 501 559 307 501 minecraft:red_wool
setblock 518 227 465 minecraft:gold_block
setblock 518 227 472 minecraft:gold_block
setblock 518 227 479 minecraft:gold_block
setblock 518 227 486 minecraft:gold_block
setblock 518 227 493 minecraft:gold_block
setblock 518 227 500 minecraft:gold_block
setblock 521 227 504 minecraft:gold_block
setblock 524 227 464 minecraft:gold_block
fill 528 227 501 528 228 503 minecraft:white_wool
setblock 528 227 504 minecraft:gold_block
setblock 531 227 464 minecraft:gold_block
setblock 535 227 504 minecraft:gold_block
setblock 538 227 464 minecraft:gold_block
setblock 542 227 504 minecraft:gold_block
setblock 545 227 464 minecraft:gold_block
setblock 549 227 504 minecraft:gold_block
setblock 552 227 464 minecraft:gold_block
setblock 556 227 504 minecraft:gold_block
setblock 558 227 465 minecraft:gold_block
setblock 558 227 472 minecraft:gold_block
setblock 558 227 479 minecraft:gold_block
setblock 558 227 486 minecraft:gold_block
setblock 558 227 493 minecraft:gold_block
setblock 558 227 500 minecraft:gold_block
setblock 518 228 466 minecraft:gold_block
setblock 518 228 473 minecraft:gold_block
setblock 518 228 480 minecraft:gold_block
setblock 518 228 487 minecraft:gold_block
setblock 518 228 494 minecraft:gold_block
setblock 518 228 501 minecraft:gold_block
setblock 522 228 504 minecraft:gold_block
setblock 523 228 464 minecraft:gold_block
setblock 529 228 504 minecraft:gold_block
setblock 530 228 464 minecraft:gold_block
setblock 536 228 504 minecraft:gold_block
setblock 537 228 464 minecraft:gold_block
setblock 543 228 504 minecraft:gold_block
setblock 544 228 464 minecraft:gold_block
setblock 550 228 504 minecraft:gold_block
setblock 551 228 464 minecraft:gold_block
setblock 557 228 504 minecraft:gold_block
setblock 558 228 464 minecraft:gold_block
setblock 558 228 471 minecraft:gold_block
setblock 558 228 478 minecraft:gold_block
setblock 558 228 485 minecraft:gold_block
setblock 558 228 492 minecraft:gold_block
setblock 558 228 499 minecraft:gold_block
fill 518 229 467 518 230 467 minecraft:gold_block
fill 518 229 474 518 230 474 minecraft:gold_block
fill 518 229 481 518 230 481 minecraft:gold_block
fill 518 229 488 518 230 488 minecraft:gold_block
fill 518 229 495 518 230 495 minecraft:gold_block
fill 518 229 502 518 230 502 minecraft:gold_block
fill 522 229 464 522 230 464 minecraft:gold_block
fill 523 229 504 523 230 504 minecraft:gold_block
fill 529 229 464 529 230 464 minecraft:gold_block
fill 530 229 504 530 230 504 minecraft:gold_block
fill 536 229 464 536 230 464 minecraft:gold_block
fill 537 229 499 547 229 503 minecraft:dark_oak_planks
fill 537 229 504 537 230 504 minecraft:gold_block
fill 543 229 464 543 230 464 minecraft:gold_block
fill 544 229 504 544 230 504 minecraft:gold_block
fill 548 229 463 550 252 463 minecraft:red_wool
fill 550 229 464 550 230 464 minecraft:gold_block
fill 551 229 504 551 230 504 minecraft:gold_block
fill 557 229 464 557 230 464 minecraft:gold_block
fill 558 229 470 558 230 470 minecraft:gold_block
fill 558 229 477 558 230 477 minecraft:gold_block
fill 558 229 484 558 230 484 minecraft:gold_block
fill 558 229 491 558 230 491 minecraft:gold_block
fill 558 229 498 558 230 498 minecraft:gold_block
fill 558 229 504 558 230 504 minecraft:gold_block
fill 518 230 464 518 230 466 minecraft:gold_block
setblock 518 230 468 minecraft:gold_block
fill 518 230 470 518 230 473 minecraft:gold_block
setblock 518 230 475 minecraft:gold_block
fill 518 230 477 518 230 480 minecraft:gold_block
setblock 518 230 482 minecraft:gold_block
fill 518 230 484 518 230 487 minecraft:gold_block
setblock 518 230 489 minecraft:gold_block
fill 518 230 491 518 230 494 minecraft:gold_block
setblock 518 230 496 minecraft:gold_block
fill 518 230 498 518 230 501 minecraft:gold_block
setblock 518 230 503 minecraft:gold_block
setblock 519 230 464 minecraft:gold_block
fill 519 230 504 522 230 504 minecraft:gold_block
setblock 520 230 466 minecraft:light[level=12]
setblock 520 230 474 minecraft:light[level=12]
setblock 520 230 482 minecraft:light[level=12]
setblock 520 230 490 minecraft:light[level=12]
setblock 520 230 498 minecraft:light[level=12]
setblock 521 230 464 minecraft:gold_block
fill 523 230 464 526 230 464 minecraft:gold_block
setblock 524 230 504 minecraft:gold_block
fill 526 230 504 529 230 504 minecraft:gold_block
setblock 528 230 464 minecraft:gold_block
setblock 528 230 466 minecraft:light[level=12]
setblock 528 230 474 minecraft:light[level=12]
setblock 528 230 482 minecraft:light[level=12]
setblock 528 230 490 minecraft:light[level=12]
setblock 528 230 498 minecraft:light[level=12]
fill 530 230 464 533 230 464 minecraft:gold_block
setblock 531 230 504 minecraft:gold_block
fill 533 230 504 536 230 504 minecraft:gold_block
setblock 535 230 464 minecraft:gold_block
setblock 536 230 466 minecraft:light[level=12]
setblock 536 230 474 minecraft:light[level=12]
setblock 536 230 482 minecraft:light[level=12]
setblock 536 230 490 minecraft:light[level=12]
setblock 536 230 498 minecraft:light[level=12]
fill 537 230 464 540 230 464 minecraft:gold_block
fill 537 230 499 547 230 503 minecraft:gold_block
setblock 538 230 504 minecraft:gold_block
fill 540 230 504 543 230 504 minecraft:gold_block
setblock 542 230 464 minecraft:gold_block
fill 544 230 464 547 230 464 minecraft:gold_block
setblock 544 230 466 minecraft:light[level=12]
setblock 544 230 474 minecraft:light[level=12]
setblock 544 230 482 minecraft:light[level=12]
setblock 544 230 490 minecraft:light[level=12]
setblock 544 230 498 minecraft:light[level=12]
setblock 545 230 504 minecraft:gold_block
fill 547 230 504 550 230 504 minecraft:gold_block
setblock 549 230 464 minecraft:gold_block
fill 551 230 464 554 230 464 minecraft:gold_block
setblock 552 230 466 minecraft:light[level=12]
setblock 552 230 474 minecraft:light[level=12]
setblock 552 230 482 minecraft:light[level=12]
setblock 552 230 490 minecraft:light[level=12]
setblock 552 230 498 minecraft:light[level=12]
setblock 552 230 504 minecraft:gold_block
fill 554 230 504 557 230 504 minecraft:gold_block
setblock 556 230 464 minecraft:gold_block
fill 558 230 464 558 230 467 minecraft:gold_block
setblock 558 230 469 minecraft:gold_block
fill 558 230 471 558 230 474 minecraft:gold_block
setblock 558 230 476 minecraft:gold_block
fill 558 230 478 558 230 481 minecraft:gold_block
setblock 558 230 483 minecraft:gold_block
fill 558 230 485 558 230 488 minecraft:gold_block
setblock 558 230 490 minecraft:gold_block
fill 558 230 492 558 230 495 minecraft:gold_block
setblock 558 230 497 minecraft:gold_block
fill 558 230 499 558 230 502 minecraft:gold_block
fill 537 231 499 547 231 499 minecraft:red_wool
fill 541 231 504 543 234 504 minecraft:ochre_froglight
fill 549 231 501 549 232 503 minecraft:white_wool
setblock 518 232 470 minecraft:gold_block
setblock 518 232 477 minecraft:gold_block
setblock 518 232 484 minecraft:gold_block
setblock 518 232 491 minecraft:gold_block
setblock 518 232 498 minecraft:gold_block
setblock 519 232 464 minecraft:gold_block
setblock 519 232 504 minecraft:gold_block
setblock 526 232 464 minecraft:gold_block
setblock 526 232 504 minecraft:gold_block
setblock 533 232 464 minecraft:gold_block
setblock 533 232 504 minecraft:gold_block
setblock 537 232 499 minecraft:gold_block
setblock 540 232 464 minecraft:gold_block
setblock 540 232 504 minecraft:gold_block
setblock 542 232 499 minecraft:gold_block
setblock 547 232 464 minecraft:gold_block
setblock 547 232 499 minecraft:gold_block
setblock 547 232 504 minecraft:gold_block
setblock 554 232 464 minecraft:gold_block
setblock 554 232 504 minecraft:gold_block
setblock 558 232 467 minecraft:gold_block
setblock 558 232 474 minecraft:gold_block
setblock 558 232 481 minecraft:gold_block
setblock 558 232 488 minecraft:gold_block
setblock 558 232 495 minecraft:gold_block
setblock 558 232 502 minecraft:gold_block
setblock 518 233 464 minecraft:gold_block
setblock 518 233 471 minecraft:gold_block
setblock 518 233 478 minecraft:gold_block
setblock 518 233 485 minecraft:gold_block
setblock 518 233 492 minecraft:gold_block
setblock 518 233 499 minecraft:gold_block
setblock 520 233 504 minecraft:gold_block
fill 521 233 466 521 235 466 minecraft:white_wool
setblock 525 233 464 minecraft:gold_block
setblock 527 233 504 minecraft:gold_block
setblock 532 233 464 minecraft:gold_block
fill 533 233 467 533 235 467 minecraft:white_wool
setblock 534 233 504 minecraft:gold_block
setblock 539 233 464 minecraft:gold_block
setblock 546 233 464 minecraft:gold_block
setblock 548 233 504 minecraft:gold_block
setblock 553 233 464 minecraft:gold_block
setblock 555 233 504 minecraft:gold_block
setblock 558 233 466 minecraft:gold_block
setblock 558 233 473 minecraft:gold_block
setblock 558 233 480 minecraft:gold_block
setblock 558 233 487 minecraft:gold_block
setblock 558 233 494 minecraft:gold_block
setblock 558 233 501 minecraft:gold_block
setblock 518 234 465 minecraft:gold_block
setblock 518 234 472 minecraft:gold_block
setblock 518 234 479 minecraft:gold_block
setblock 518 234 486 minecraft:gold_block
setblock 518 234 493 minecraft:gold_block
setblock 518 234 500 minecraft:gold_block
setblock 521 234 504 minecraft:gold_block
setblock 524 234 464 minecraft:gold_block
setblock 528 234 504 minecraft:gold_block
setblock 531 234 464 minecraft:gold_block
setblock 535 234 504 minecraft:gold_block
setblock 538 234 464 minecraft:gold_block
setblock 545 234 464 minecraft:gold_block
setblock 549 234 504 minecraft:gold_block
setblock 552 234 464 minecraft:gold_block
setblock 556 234 504 minecraft:gold_block
setblock 558 234 465 minecraft:gold_block
setblock 558 234 472 minecraft:gold_block
setblock 558 234 479 minecraft:gold_block
setblock 558 234 486 minecraft:gold_block
setblock 558 234 493 minecraft:gold_block
setblock 558 234 500 minecraft:gold_block
setblock 518 235 466 minecraft:gold_block
setblock 518 235 473 minecraft:gold_block
setblock 518 235 480 minecraft:gold_block
setblock 518 235 487 minecraft:gold_block
setblock 518 235 494 minecraft:gold_block
setblock 518 235 501 minecraft:gold_block
setblock 522 235 504 minecraft:gold_block
setblock 523 235 464 minecraft:gold_block
setblock 529 235 504 minecraft:gold_block
setblock 530 235 464 minecraft:gold_block
setblock 536 235 504 minecraft:gold_block
setblock 537 235 464 minecraft:gold_block
setblock 543 235 504 minecraft:gold_block
setblock 544 235 464 minecraft:gold_block
setblock 550 235 504 minecraft:gold_block
setblock 551 235 464 minecraft:gold_block
setblock 557 235 504 minecraft:gold_block
setblock 558 235 464 minecraft:gold_block
setblock 558 235 471 minecraft:gold_block
setblock 558 235 478 minecraft:gold_block
setblock 558 235 485 minecraft:gold_block
setblock 558 235 492 minecraft:gold_block
setblock 558 235 499 minecraft:gold_block
setblock 520 238 466 minecraft:light[level=12]
setblock 520 238 474 minecraft:light[level=12]
setblock 520 238 482 minecraft:light[level=12]
setblock 520 238 490 minecraft:light[level=12]
setblock 520 238 498 minecraft:light[level=12]
setblock 528 238 466 minecraft:light[level=12]
setblock 528 238 474 minecraft:light[level=12]
setblock 528 238 482 minecraft:light[level=12]
setblock 528 238 490 minecraft:light[level=12]
setblock 528 238 498 minecraft:light[level=12]
setblock 536 238 466 minecraft:light[level=12]
setblock 536 238 474 minecraft:light[level=12]
setblock 536 238 482 minecraft:light[level=12]
setblock 536 238 490 minecraft:light[level=12]
setblock 536 238 498 minecraft:light[level=12]
setblock 544 238 466 minecraft:light[level=12]
setblock 544 238 474 minecraft:light[level=12]
setblock 544 238 482 minecraft:light[level=12]
setblock 544 238 490 minecraft:light[level=12]
setblock 544 238 498 minecraft:light[level=12]
setblock 552 238 466 minecraft:light[level=12]
setblock 552 238 474 minecraft:light[level=12]
setblock 552 238 482 minecraft:light[level=12]
setblock 552 238 490 minecraft:light[level=12]
setblock 552 238 498 minecraft:light[level=12]
fill 518 241 464 520 242 474 minecraft:black_concrete
fill 518 241 475 558 242 475 minecraft:gold_block
fill 518 241 476 520 242 486 minecraft:black_concrete
fill 518 241 487 535 241 487 minecraft:gold_block
fill 518 241 488 520 242 498 minecraft:black_concrete
fill 518 241 499 558 242 499 minecraft:gold_block
fill 518 241 500 520 242 504 minecraft:black_concrete
fill 521 241 464 521 242 474 minecraft:white_wool
fill 521 241 476 521 242 486 minecraft:white_wool
fill 521 241 488 521 242 498 minecraft:white_wool
fill 521 241 500 521 242 504 minecraft:white_wool
fill 522 241 464 524 242 474 minecraft:black_concrete
fill 522 241 476 524 242 486 minecraft:black_concrete
fill 522 241 488 524 242 498 minecraft:black_concrete
fill 522 241 500 524 242 504 minecraft:black_concrete
fill 525 241 464 525 242 474 minecraft:white_wool
fill 525 241 476 525 242 486 minecraft:white_wool
fill 525 241 488 525 242 498 minecraft:white_wool
fill 525 241 500 525 242 504 minecraft:white_wool
fill 526 241 464 528 242 474 minecraft:black_concrete
fill 526 241 476 528 242 486 minecraft:black_concrete
fill 526 241 488 528 242 498 minecraft:black_concrete
fill 526 241 500 528 242 504 minecraft:black_concrete
fill 529 241 464 529 242 474 minecraft:white_wool
fill 529 241 476 529 242 486 minecraft:white_wool
fill 529 241 488 529 242 498 minecraft:white_wool
fill 529 241 500 529 242 504 minecraft:white_wool
fill 530 241 464 532 242 474 minecraft:black_concrete
fill 530 241 476 532 242 486 minecraft:black_concrete
fill 530 241 488 532 242 498 minecraft:black_concrete
fill 530 241 500 532 242 504 minecraft:black_concrete
fill 533 241 464 533 242 474 minecraft:white_wool
fill 533 241 476 533 241 486 minecraft:white_wool
fill 533 241 488 533 242 498 minecraft:white_wool
fill 533 241 500 533 242 504 minecraft:white_wool
fill 534 241 464 536 242 474 minecraft:black_concrete
fill 534 241 476 534 241 484 minecraft:black_concrete
setblock 534 241 486 minecraft:black_concrete
fill 534 241 488 536 241 498 minecraft:black_concrete
fill 534 241 500 536 242 504 minecraft:black_concrete
fill 535 241 476 535 241 483 minecraft:black_concrete
fill 536 241 476 536 241 482 minecraft:black_concrete
fill 537 241 464 537 242 474 minecraft:white_wool
fill 537 241 476 537 241 483 minecraft:white_wool
fill 537 241 487 558 241 487 minecraft:gold_block
fill 537 241 488 537 241 498 minecraft:white_wool
fill 537 241 500 537 242 504 minecraft:white_wool
fill 538 241 464 540 242 474 minecraft:black_concrete
fill 538 241 476 540 241 484 minecraft:black_concrete
fill 538 241 486 540 241 486 minecraft:black_concrete
fill 538 241 488 540 242 498 minecraft:black_concrete
fill 538 241 500 540 242 504 minecraft:black_concrete
fill 539 241 485 540 241 485 minecraft:black_concrete
fill 541 241 464 541 242 474 minecraft:white_wool
fill 541 241 476 541 242 486 minecraft:white_wool
fill 541 241 488 541 242 498 minecraft:white_wool
fill 541 241 500 541 242 504 minecraft:white_wool
fill 542 241 464 544 242 474 minecraft:black_concrete
fill 542 241 476 544 242 486 minecraft:black_concrete
fill 542 241 488 544 242 498 minecraft:black_concrete
fill 542 241 500 544 242 504 minecraft:black_concrete
fill 545 241 464 545 242 474 minecraft:white_wool
fill 545 241 476 545 242 486 minecraft:white_wool
fill 545 241 488 545 242 498 minecraft:white_wool
fill 545 241 500 545 242 504 minecraft:white_wool
fill 546 241 464 548 242 474 minecraft:black_concrete
fill 546 241 476 548 242 486 minecraft:black_concrete
fill 546 241 488 548 242 498 minecraft:black_concrete
fill 546 241 500 548 242 504 minecraft:black_concrete
fill 549 241 464 549 242 474 minecraft:white_wool
fill 549 241 476 549 242 486 minecraft:white_wool
fill 549 241 488 549 242 498 minecraft:white_wool
fill 549 241 500 549 242 504 minecraft:white_wool
fill 550 241 464 552 242 474 minecraft:black_concrete
fill 550 241 476 552 242 486 minecraft:black_concrete
fill 550 241 488 552 242 498 minecraft:black_concrete
fill 550 241 500 552 242 504 minecraft:black_concrete
fill 553 241 464 553 242 474 minecraft:white_wool
fill 553 241 476 553 242 486 minecraft:white_wool
fill 553 241 488 553 242 498 minecraft:white_wool
fill 553 241 500 553 242 504 minecraft:white_wool
fill 554 241 464 556 242 474 minecraft:black_concrete
fill 554 241 476 556 242 486 minecraft:black_concrete
fill 554 241 488 556 242 498 minecraft:black_concrete
fill 554 241 500 556 242 504 minecraft:black_concrete
fill 557 241 464 557 242 474 minecraft:white_wool
fill 557 241 476 557 242 486 minecraft:white_wool
fill 557 241 488 557 242 498 minecraft:white_wool
fill 557 241 500 557 242 504 minecraft:white_wool
fill 558 241 464 558 242 474 minecraft:black_concrete
fill 558 241 476 558 242 486 minecraft:black_concrete
fill 558 241 488 558 242 498 minecraft:black_concrete
fill 558 241 500 558 242 504 minecraft:black_concrete
fill 518 242 487 533 242 487 minecraft:gold_block
fill 533 242 476 533 242 483 minecraft:white_wool
fill 533 242 484 533 242 486 minecraft:ochre_froglight
fill 534 242 476 534 242 482 minecraft:black_concrete
fill 534 242 483 534 242 484 minecraft:ochre_froglight
fill 534 242 486 534 242 487 minecraft:ochre_froglight
fill 534 242 488 534 242 498 minecraft:black_concrete
fill 535 242 476 536 242 481 minecraft:black_concrete
fill 535 242 482 535 242 483 minecraft:ochre_froglight
fill 535 242 487 535 242 488 minecraft:ochre_froglight
fill 535 242 489 536 242 498 minecraft:black_concrete
fill 536 242 482 537 242 482 minecraft:ochre_froglight
fill 536 242 488 537 242 488 minecraft:ochre_froglight
fill 537 242 476 537 242 481 minecraft:white_wool
fill 537 242 483 538 242 483 minecraft:ochre_froglight
fill 537 242 487 538 242 487 minecraft:ochre_froglight
fill 537 242 489 537 242 498 minecraft:white_wool
fill 538 242 476 540 242 482 minecraft:black_concrete
fill 538 242 484 539 242 484 minecraft:ochre_froglight
fill 538 242 486 539 242 486 minecraft:ochre_froglight
fill 539 242 483 540 242 483 minecraft:black_concrete
setblock 539 242 485 minecraft:ochre_froglight
fill 539 242 487 558 242 487 minecraft:gold_block
fill 540 242 484 540 242 486 minecraft:black_concrete
fill 518 246 469 518 246 470 minecraft:gold_block
fill 518 246 476 518 246 477 minecraft:gold_block
fill 518 246 483 518 246 484 minecraft:gold_block
fill 518 246 490 518 246 491 minecraft:gold_block
fill 518 246 497 518 246 498 minecraft:gold_block
fill 518 246 504 519 246 504 minecraft:gold_block
fill 519 246 464 520 246 464 minecraft:gold_block
setblock 520 246 466 minecraft:light[level=12]
setblock 520 246 474 minecraft:light[level=12]
setblock 520 246 482 minecraft:light[level=12]
setblock 520 246 490 minecraft:light[level=12]
setblock 520 246 498 minecraft:light[level=12]
fill 521 246 466 521 256 466 minecraft:white_wool
fill 525 246 504 526 246 504 minecraft:gold_block
fill 526 246 464 527 246 464 minecraft:gold_block
setblock 528 246 466 minecraft:light[level=12]
setblock 528 246 474 minecraft:light[level=12]
setblock 528 246 482 minecraft:light[level=12]
setblock 528 246 490 minecraft:light[level=12]
setblock 528 246 498 minecraft:light[level=12]
fill 532 246 504 533 246 504 minecraft:gold_block
fill 533 246 464 534 246 464 minecraft:gold_block
fill 533 246 467 533 256 467 minecraft:white_wool
setblock 536 246 466 minecraft:light[level=12]
setblock 536 246 474 minecraft:light[level=12]
setblock 536 246 482 minecraft:light[level=12]
setblock 536 246 490 minecraft:light[level=12]
setblock 536 246 498 minecraft:light[level=12]
fill 539 246 504 540 246 504 minecraft:gold_block
fill 540 246 464 541 246 464 minecraft:gold_block
fill 542 246 502 546 248 502 minecraft:red_wool
setblock 544 246 466 minecraft:light[level=12]
setblock 544 246 474 minecraft:light[level=12]
setblock 544 246 482 minecraft:light[level=12]
setblock 544 246 490 minecraft:light[level=12]
setblock 544 246 498 minecraft:light[level=12]
fill 546 246 504 547 246 504 minecraft:gold_block
fill 547 246 464 548 246 464 minecraft:gold_block
setblock 552 246 466 minecraft:light[level=12]
setblock 552 246 474 minecraft:light[level=12]
setblock 552 246 482 minecraft:light[level=12]
setblock 552 246 490 minecraft:light[level=12]
setblock 552 246 498 minecraft:light[level=12]
fill 553 246 504 554 246 504 minecraft:gold_block
fill 554 246 464 555 246 464 minecraft:gold_block
fill 556 246 476 556 247 482 minecraft:white_wool
fill 558 246 467 558 246 468 minecraft:gold_block
fill 558 246 474 558 246 475 minecraft:gold_block
fill 558 246 481 558 246 482 minecraft:gold_block
fill 558 246 488 558 246 489 minecraft:gold_block
fill 558 246 495 558 246 496 minecraft:gold_block
fill 558 246 502 558 246 503 minecraft:gold_block
setblock 518 247 464 minecraft:gold_block
fill 518 247 469 518 273 469 minecraft:gold_block
setblock 518 247 471 minecraft:gold_block
fill 518 247 476 518 273 476 minecraft:gold_block
setblock 518 247 478 minecraft:gold_block
fill 518 247 483 518 273 483 minecraft:gold_block
setblock 518 247 485 minecraft:gold_block
fill 518 247 490 518 273 490 minecraft:gold_block
setblock 518 247 492 minecraft:gold_block
fill 518 247 497 518 273 497 minecraft:gold_block
setblock 518 247 499 minecraft:gold_block
fill 518 247 504 518 273 504 minecraft:gold_block
fill 520 247 464 520 273 464 minecraft:gold_block
setblock 520 247 504 minecraft:gold_block
setblock 525 247 464 minecraft:gold_block
fill 525 247 504 525 273 504 minecraft:gold_block
fill 527 247 464 527 273 464 minecraft:gold_block
setblock 527 247 504 minecraft:gold_block
setblock 532 247 464 minecraft:gold_block
fill 532 247 504 532 273 504 minecraft:gold_block
fill 534 247 464 534 273 464 minecraft:gold_block
setblock 534 247 504 minecraft:gold_block
setblock 539 247 464 minecraft:gold_block
fill 539 247 504 539 273 504 minecraft:gold_block
fill 541 247 464 541 273 464 minecraft:gold_block
setblock 541 247 504 minecraft:gold_block
setblock 546 247 464 minecraft:gold_block
fill 546 247 504 546 273 504 minecraft:gold_block
fill 548 247 464 548 273 464 minecraft:gold_block
setblock 548 247 504 minecraft:gold_block
fill 550 247 468 550 250 468 minecraft:white_wool
setblock 553 247 464 minecraft:gold_block
fill 553 247 504 553 273 504 minecraft:gold_block
fill 555 247 464 555 273 464 minecraft:gold_block
setblock 555 247 504 minecraft:gold_block
setblock 558 247 466 minecraft:gold_block
fill 558 247 468 558 273 468 minecraft:gold_block
setblock 558 247 473 minecraft:gold_block
fill 558 247 475 558 273 475 minecraft:gold_block
setblock 558 247 480 minecraft:gold_block
fill 558 247 482 558 273 482 minecraft:gold_block
setblock 558 247 487 minecraft:gold_block
fill 558 247 489 558 273 489 minecraft:gold_block
setblock 558 247 494 minecraft:gold_block
fill 558 247 496 558 273 496 minecraft:gold_block
setblock 558 247 501 minecraft:gold_block
fill 558 247 503 558 273 503 minecraft:gold_block
setblock 518 248 465 minecraft:gold_block
setblock 518 248 472 minecraft:gold_block
setblock 518 248 479 minecraft:gold_block
setblock 518 248 486 minecraft:gold_block
setblock 518 248 493 minecraft:gold_block
setblock 518 248 500 minecraft:gold_block
setblock 521 248 504 minecraft:gold_block
setblock 524 248 464 minecraft:gold_block
setblock 528 248 504 minecraft:gold_block
setblock 531 248 464 minecraft:gold_block
setblock 535 248 504 minecraft:gold_block
setblock 538 248 464 minecraft:gold_block
setblock 542 248 504 minecraft:gold_block
setblock 545 248 464 minecraft:gold_block
setblock 549 248 504 minecraft:gold_block
setblock 552 248 464 minecraft:gold_block
setblock 556 248 504 minecraft:gold_block
setblock 558 248 465 minecraft:gold_block
setblock 558 248 472 minecraft:gold_block
setblock 558 248 479 minecraft:gold_block
setblock 558 248 486 minecraft:gold_block
setblock 558 248 493 minecraft:gold_block
setblock 558 248 500 minecraft:gold_block
fill 518 249 466 518 250 466 minecraft:gold_block
fill 518 249 473 518 250 473 minecraft:gold_block
fill 518 249 480 518 250 480 minecraft:gold_block
fill 518 249 487 518 250 487 minecraft:gold_block
fill 518 249 494 518 250 494 minecraft:gold_block
fill 518 249 501 518 250 501 minecraft:gold_block
fill 522 249 504 522 250 504 minecraft:gold_block
fill 523 249 464 523 250 464 minecraft:gold_block
fill 529 249 504 529 250 504 minecraft:gold_block
fill 530 249 464 530 250 464 minecraft:gold_block
fill 536 249 504 536 250 504 minecraft:gold_block
fill 537 249 464 537 250 464 minecraft:gold_block
fill 541 249 502 547 250 502 minecraft:white_wool
fill 543 249 504 543 250 504 minecraft:gold_block
fill 544 249 464 544 250 464 minecraft:gold_block
fill 550 249 504 550 250 504 minecraft:gold_block
fill 551 249 464 551 250 464 minecraft:gold_block
fill 557 249 504 557 250 504 minecraft:gold_block
fill 558 249 464 558 250 464 minecraft:gold_block
fill 558 249 471 558 250 471 minecraft:gold_block
fill 558 249 478 558 250 478 minecraft:gold_block
fill 558 249 485 558 250 485 minecraft:gold_block
fill 558 249 492 558 250 492 minecraft:gold_block
fill 558 249 499 558 250 499 minecraft:gold_block
fill 518 250 464 518 250 465 minecraft:gold_block
fill 518 250 467 518 250 468 minecraft:gold_block
fill 518 250 470 518 250 472 minecraft:gold_block
fill 518 250 474 518 250 475 minecraft:gold_block
fill 518 250 477 518 250 479 minecraft:gold_block
fill 518 250 481 518 250 482 minecraft:gold_block
fill 518 250 484 518 250 486 minecraft:gold_block
fill 518 250 488 518 250 489 minecraft:gold_block
fill 518 250 491 518 250 493 minecraft:gold_block
fill 518 250 495 518 250 496 minecraft:gold_block
fill 518 250 498 518 250 500 minecraft:gold_block
fill 518 250 502 518 250 503 minecraft:gold_block
setblock 519 250 464 minecraft:gold_block
fill 519 250 504 521 250 504 minecraft:gold_block
fill 521 250 464 522 250 464 minecraft:gold_block
fill 523 250 504 524 250 504 minecraft:gold_block
fill 524 250 464 526 250 464 minecraft:gold_block
fill 526 250 504 528 250 504 minecraft:gold_block
fill 528 250 464 529 250 464 minecraft:gold_block
fill 530 250 504 531 250 504 minecraft:gold_block
fill 531 250 464 533 250 464 minecraft:gold_block
fill 533 250 504 535 250 504 minecraft:gold_block
fill 535 250 464 536 250 464 minecraft:gold_block
fill 537 250 504 538 250 504 minecraft:gold_block
fill 538 250 464 540 250 464 minecraft:gold_block
fill 540 250 504 542 250 504 minecraft:gold_block
fill 542 250 464 543 250 464 minecraft:gold_block
fill 544 250 504 545 250 504 minecraft:gold_block
fill 545 250 464 547 250 464 minecraft:gold_block
fill 547 250 504 549 250 504 minecraft:gold_block
fill 549 250 464 550 250 464 minecraft:gold_block
fill 551 250 504 552 250 504 minecraft:gold_block
fill 552 250 464 554 250 464 minecraft:gold_block
fill 554 250 504 556 250 504 minecraft:gold_block
fill 556 250 464 557 250 464 minecraft:gold_block
fill 556 250 498 556 266 498 minecraft:white_wool
fill 558 250 465 558 250 467 minecraft:gold_block
fill 558 250 469 558 250 470 minecraft:gold_block
fill 558 250 472 558 250 474 minecraft:gold_block
fill 558 250 476 558 250 477 minecraft:gold_block
fill 558 250 479 558 250 481 minecraft:gold_block
fill 558 250 483 558 250 484 minecraft:gold_block
fill 558 250 486 558 250 488 minecraft:gold_block
fill 558 250 490 558 250 491 minecraft:gold_block
fill 558 250 493 558 250 495 minecraft:gold_block
fill 558 250 497 558 250 498 minecraft:gold_block
fill 558 250 500 558 250 502 minecraft:gold_block
setblock 558 250 504 minecraft:gold_block
setblock 518 251 468 minecraft:gold_block
setblock 518 251 475 minecraft:gold_block
setblock 518 251 482 minecraft:gold_block
setblock 518 251 489 minecraft:gold_block
setblock 518 251 496 minecraft:gold_block
setblock 518 251 503 minecraft:gold_block
setblock 521 251 464 minecraft:gold_block
setblock 524 251 504 minecraft:gold_block
setblock 528 251 464 minecraft:gold_block
setblock 531 251 504 minecraft:gold_block
setblock 535 251 464 minecraft:gold_block
fill 536 251 501 536 264 501 minecraft:white_wool
setblock 538 251 504 minecraft:gold_block
setblock 542 251 464 minecraft:gold_block
setblock 545 251 504 minecraft:gold_block
fill 547 251 464 547 251 468 minecraft:dark_oak_planks
fill 548 251 465 553 251 468 minecraft:dark_oak_planks
fill 549 251 464 549 252 464 minecraft:gold_block
fill 550 251 464 553 251 464 minecraft:dark_oak_planks
setblock 552 251 504 minecraft:gold_block
setblock 556 251 464 minecraft:gold_block
setblock 558 251 469 minecraft:gold_block
setblock 558 251 476 minecraft:gold_block
setblock 558 251 483 minecraft:gold_block
setblock 558 251 490 minecraft:gold_block
setblock 558 251 497 minecraft:gold_block
fill 547 252 464 547 252 468 minecraft:gold_block
fill 548 252 465 553 252 468 minecraft:gold_block
fill 550 252 464 553 252 464 minecraft:gold_block
setblock 518 253 470 minecraft:gold_block
setblock 518 253 477 minecraft:gold_block
setblock 518 253 484 minecraft:gold_block
setblock 518 253 491 minecraft:gold_block
setblock 518 253 498 minecraft:gold_block
setblock 519 253 464 minecraft:gold_block
setblock 519 253 504 minecraft:gold_block
setblock 526 253 464 minecraft:gold_block
setblock 526 253 504 minecraft:gold_block
setblock 533 253 464 minecraft:gold_block
setblock 533 253 504 minecraft:gold_block
setblock 540 253 464 minecraft:gold_block
setblock 540 253 504 minecraft:gold_block
setblock 547 253 464 minecraft:gold_block
fill 547 253 468 553 253 468 minecraft:red_wool
setblock 547 253 504 minecraft:gold_block
fill 548 253 463 548 307 463 minecraft:red_wool
fill 549 253 463 551 256 463 minecraft:ochre_froglight
fill 552 253 463 552 307 463 minecraft:red_wool
setblock 554 253 464 minecraft:gold_block
setblock 554 253 504 minecraft:gold_block
setblock 558 253 467 minecraft:gold_block
setblock 558 253 474 minecraft:gold_block
setblock 558 253 481 minecraft:gold_block
setblock 558 253 488 minecraft:gold_block
setblock 558 253 495 minecraft:gold_block
setblock 558 253 502 minecraft:gold_block
setblock 518 254 464 minecraft:gold_block
setblock 518 254 471 minecraft:gold_block
setblock 518 254 478 minecraft:gold_block
setblock 518 254 485 minecraft:gold_block
setblock 518 254 492 minecraft:gold_block
setblock 518 254 499 minecraft:gold_block
setblock 520 254 466 minecraft:light[level=12]
setblock 520 254 474 minecraft:light[level=12]
setblock 520 254 482 minecraft:light[level=12]
setblock 520 254 490 minecraft:light[level=12]
setblock 520 254 498 minecraft:light[level=12]
setblock 520 254 504 minecraft:gold_block
setblock 525 254 464 minecraft:gold_block
setblock 527 254 504 minecraft:gold_block
setblock 528 254 466 minecraft:light[level=12]
setblock 528 254 474 minecraft:light[level=12]
setblock 528 254 482 minecraft:light[level=12]
setblock 528 254 490 minecraft:light[level=12]
setblock 528 254 498 minecraft:light[level=12]
setblock 532 254 464 minecraft:gold_block
setblock 534 254 504 minecraft:gold_block
setblock 536 254 466 minecraft:light[level=12]
setblock 536 254 474 minecraft:light[level=12]
setblock 536 254 482 minecraft:light[level=12]
setblock 536 254 490 minecraft:light[level=12]
setblock 536 254 498 minecraft:light[level=12]
setblock 539 254 464 minecraft:gold_block
setblock 541 254 504 minecraft:gold_block
setblock 544 254 466 minecraft:light[level=12]
setblock 544 254 474 minecraft:light[level=12]
setblock 544 254 482 minecraft:light[level=12]
setblock 544 254 490 minecraft:light[level=12]
setblock 544 254 498 minecraft:light[level=12]
setblock 546 254 464 minecraft:gold_block
setblock 547 254 468 minecraft:gold_block
setblock 548 254 504 minecraft:gold_block
setblock 550 254 468 minecraft:gold_block
setblock 552 254 466 minecraft:light[level=12]
setblock 552 254 474 minecraft:light[level=12]
setblock 552 254 482 minecraft:light[level=12]
setblock 552 254 490 minecraft:light[level=12]
setblock 552 254 498 minecraft:light[level=12]
setblock 553 254 464 minecraft:gold_block
setblock 553 254 468 minecraft:gold_block
setblock 555 254 504 minecraft:gold_block
setblock 558 254 466 minecraft:gold_block
setblock 558 254 473 minecraft:gold_block
setblock 558 254 480 minecraft:gold_block
setblock 558 254 487 minecraft:gold_block
setblock 558 254 494 minecraft:gold_block
setblock 558 254 501 minecraft:gold_block
setblock 518 255 465 minecraft:gold_block
setblock 518 255 472 minecraft:gold_block
setblock 518 255 479 minecraft:gold_block
setblock 518 255 486 minecraft:gold_block
setblock 518 255 493 minecraft:gold_block
setblock 518 255 500 minecraft:gold_block
setblock 521 255 504 minecraft:gold_block
setblock 524 255 464 minecraft:gold_block
setblock 528 255 504 minecraft:gold_block
setblock 531 255 464 minecraft:gold_block
setblock 535 255 504 minecraft:gold_block
setblock 538 255 464 minecraft:gold_block
setblock 542 255 504 minecraft:gold_block
setblock 545 255 464 minecraft:gold_block
setblock 549 255 504 minecraft:gold_block
setblock 552 255 464 minecraft:gold_block
setblock 556 255 504 minecraft:gold_block
setblock 558 255 465 minecraft:gold_block
setblock 558 255 472 minecraft:gold_block
setblock 558 255 479 minecraft:gold_block
setblock 558 255 486 minecraft:gold_block
setblock 558 255 493 minecraft:gold_block
setblock 558 255 500 minecraft:gold_block
setblock 518 256 466 minecraft:gold_block
setblock 518 256 473 minecraft:gold_block
setblock 518 256 480 minecraft:gold_block
setblock 518 256 487 minecraft:gold_block
setblock 518 256 494 minecraft:gold_block
setblock 518 256 501 minecraft:gold_block
setblock 522 256 504 minecraft:gold_block
setblock 523 256 464 minecraft:gold_block
setblock 529 256 504 minecraft:gold_block
setblock 530 256 464 minecraft:gold_block
setblock 536 256 504 minecraft:gold_block
setblock 537 256 464 minecraft:gold_block
setblock 543 256 504 minecraft:gold_block
setblock 544 256 464 minecraft:gold_block
setblock 550 256 504 minecraft:gold_block
setblock 551 256 464 minecraft:gold_block
setblock 557 256 504 minecraft:gold_block
setblock 558 256 464 minecraft:gold_block
setblock 558 256 471 minecraft:gold_block
setblock 558 256 478 minecraft:gold_block
setblock 558 256 485 minecraft:gold_block
setblock 558 256 492 minecraft:gold_block
setblock 558 256 499 minecraft:gold_block
setblock 518 257 467 minecraft:gold_block
setblock 518 257 474 minecraft:gold_block
setblock 518 257 481 minecraft:gold_block
setblock 518 257 488 minecraft:gold_block
setblock 518 257 495 minecraft:gold_block
setblock 518 257 502 minecraft:gold_block
setblock 522 257 464 minecraft:gold_block
setblock 523 257 504 minecraft:gold_block
setblock 529 257 464 minecraft:gold_block
setblock 530 257 504 minecraft:gold_block
setblock 536 257 464 minecraft:gold_block
setblock 537 257 504 minecraft:gold_block
setblock 543 257 464 minecraft:gold_block
setblock 544 257 504 minecraft:gold_block
fill 549 257 463 551 307 463 minecraft:red_wool
setblock 550 257 464 minecraft:gold_block
setblock 551 257 504 minecraft:gold_block
setblock 557 257 464 minecraft:gold_block
setblock 558 257 470 minecraft:gold_block
setblock 558 257 477 minecraft:gold_block
setblock 558 257 484 minecraft:gold_block
setblock 558 257 491 minecraft:gold_block
setblock 558 257 498 minecraft:gold_block
setblock 558 257 504 minecraft:gold_block
setblock 518 258 468 minecraft:gold_block
setblock 518 258 475 minecraft:gold_block
setblock 518 258 482 minecraft:gold_block
setblock 518 258 489 minecraft:gold_block
setblock 518 258 496 minecraft:gold_block
setblock 518 258 503 minecraft:gold_block
setblock 521 258 464 minecraft:gold_block
setblock 524 258 504 minecraft:gold_block
setblock 528 258 464 minecraft:gold_block
setblock 531 258 504 minecraft:gold_block
fill 534 258 499 534 261 499 minecraft:white_wool
setblock 535 258 464 minecraft:gold_block
setblock 538 258 504 minecraft:gold_block
setblock 542 258 464 minecraft:gold_block
setblock 545 258 504 minecraft:gold_block
setblock 549 258 464 minecraft:gold_block
setblock 552 258 504 minecraft:gold_block
setblock 556 258 464 minecraft:gold_block
setblock 558 258 469 minecraft:gold_block
setblock 558 258 476 minecraft:gold_block
setblock 558 258 483 minecraft:gold_block
setblock 558 258 490 minecraft:gold_block
setblock 558 258 497 minecraft:gold_block
fill 518 260 464 518 260 468 minecraft:gold_block
fill 518 260 470 518 260 475 minecraft:gold_block
fill 518 260 477 518 260 482 minecraft:gold_block
fill 518 260 484 518 260 489 minecraft:gold_block
fill 518 260 491 518 260 496 minecraft:gold_block
fill 518 260 498 518 260 503 minecraft:gold_block
setblock 519 260 464 minecraft:gold_block
fill 519 260 504 524 260 504 minecraft:gold_block
fill 521 260 464 526 260 464 minecraft:gold_block
fill 526 260 504 531 260 504 minecraft:gold_block
fill 528 260 464 533 260 464 minecraft:gold_block
fill 533 260 504 538 260 504 minecraft:gold_block
fill 535 260 464 540 260 464 minecraft:gold_block
fill 540 260 504 545 260 504 minecraft:gold_block
fill 542 260 464 547 260 464 minecraft:gold_block
fill 547 260 504 552 260 504 minecraft:gold_block
fill 549 260 464 554 260 464 minecraft:gold_block
fill 554 260 504 558 260 504 minecraft:gold_block
fill 556 260 464 558 260 464 minecraft:gold_block
fill 558 260 465 558 260 467 minecraft:gold_block
fill 558 260 469 558 260 474 minecraft:gold_block
fill 558 260 476 558 260 481 minecraft:gold_block
fill 558 260 483 558 260 488 minecraft:gold_block
fill 558 260 490 558 260 495 minecraft:gold_block
fill 558 260 497 558 260 502 minecraft:gold_block
setblock 518 261 464 minecraft:gold_block
setblock 518 261 471 minecraft:gold_block
setblock 518 261 478 minecraft:gold_block
setblock 518 261 485 minecraft:gold_block
setblock 518 261 492 minecraft:gold_block
setblock 518 261 499 minecraft:gold_block
setblock 520 261 504 minecraft:gold_block
setblock 525 261 464 minecraft:gold_block
setblock 527 261 504 minecraft:gold_block
setblock 532 261 464 minecraft:gold_block
setblock 534 261 504 minecraft:gold_block
setblock 539 261 464 minecraft:gold_block
setblock 541 261 504 minecraft:gold_block
setblock 546 261 464 minecraft:gold_block
setblock 548 261 504 minecraft:gold_block
setblock 553 261 464 minecraft:gold_block
setblock 555 261 504 minecraft:gold_block
setblock 558 261 466 minecraft:gold_block
setblock 558 261 473 minecraft:gold_block
setblock 558 261 480 minecraft:gold_block
setblock 558 261 487 minecraft:gold_block
setblock 558 261 494 minecraft:gold_block
setblock 558 261 501 minecraft:gold_block
setblock 518 262 465 minecraft:gold_block
setblock 518 262 472 minecraft:gold_block
setblock 518 262 479 minecraft:gold_block
setblock 518 262 486 minecraft:gold_block
setblock 518 262 493 minecraft:gold_block
setblock 518 262 500 minecraft:gold_block
setblock 520 262 466 minecraft:light[level=12]
setblock 520 262 474 minecraft:light[level=12]
setblock 520 262 482 minecraft:light[level=12]
setblock 520 262 490 minecraft:light[level=12]
setblock 520 262 498 minecraft:light[level=12]
setblock 521 262 504 minecraft:gold_block
setblock 524 262 464 minecraft:gold_block
setblock 528 262 466 minecraft:light[level=12]
setblock 528 262 474 minecraft:light[level=12]
setblock 528 262 482 minecraft:light[level=12]
setblock 528 262 490 minecraft:light[level=12]
setblock 528 262 498 minecraft:light[level=12]
setblock 528 262 504 minecraft:gold_block
fill 530 262 499 535 262 503 minecraft:dark_oak_planks
setblock 531 262 464 minecraft:gold_block
setblock 535 262 504 minecraft:gold_block
setblock 536 262 466 minecraft:light[level=12]
setblock 536 262 474 minecraft:light[level=12]
setblock 536 262 482 minecraft:light[level=12]
setblock 536 262 490 minecraft:light[level=12]
setblock 536 262 498 minecraft:light[level=12]
fill 536 262 499 538 262 500 minecraft:dark_oak_planks
fill 536 262 502 538 262 503 minecraft:dark_oak_planks
fill 537 262 501 538 262 501 minecraft:dark_oak_planks
setblock 538 262 464 minecraft:gold_block
setblock 542 262 504 minecraft:gold_block
setblock 544 262 466 minecraft:light[level=12]
setblock 544 262 474 minecraft:light[level=12]
setblock 544 262 482 minecraft:light[level=12]
setblock 544 262 490 minecraft:light[level=12]
setblock 544 262 498 minecraft:light[level=12]
setblock 545 262 464 minecraft:gold_block
setblock 549 262 504 minecraft:gold_block
setblock 552 262 464 minecraft:gold_block
setblock 552 262 466 minecraft:light[level=12]
setblock 552 262 474 minecraft:light[level=12]
setblock 552 262 482 minecraft:light[level=12]
setblock 552 262 490 minecraft:light[level=12]
setblock 552 262 498 minecraft:light[level=12]
setblock 556 262 504 minecraft:gold_block
setblock 558 262 465 minecraft:gold_block
setblock 558 262 472 minecraft:gold_block
setblock 558 262 479 minecraft:gold_block
setblock 558 262 486 minecraft:gold_block
setblock 558 262 493 minecraft:gold_block
setblock 558 262 500 minecraft:gold_block
setblock 518 263 466 minecraft:gold_block
setblock 518 263 473 minecraft:gold_block
setblock 518 263 480 minecraft:gold_block
setblock 518 263 487 minecraft:gold_block
setblock 518 263 494 minecraft:gold_block
setblock 518 263 501 minecraft:gold_block
setblock 522 263 504 minecraft:gold_block
setblock 523 263 464 minecraft:gold_block
setblock 529 263 504 minecraft:gold_block
setblock 530 263 464 minecraft:gold_block
fill 530 263 499 535 263 503 minecraft:gold_block
fill 536 263 499 538 263 500 minecraft:gold_block
fill 536 263 502 536 263 504 minecraft:gold_block
setblock 537 263 464 minecraft:gold_block
fill 537 263 501 538 263 503 minecraft:gold_block
setblock 543 263 504 minecraft:gold_block
setblock 544 263 464 minecraft:gold_block
setblock 550 263 504 minecraft:gold_block
setblock 551 263 464 minecraft:gold_block
setblock 557 263 504 minecraft:gold_block
setblock 558 263 464 minecraft:gold_block
setblock 558 263 471 minecraft:gold_block
setblock 558 263 478 minecraft:gold_block
setblock 558 263 485 minecraft:gold_block
setblock 558 263 492 minecraft:gold_block
setblock 558 263 499 minecraft:gold_block
setblock 518 264 467 minecraft:gold_block
setblock 518 264 474 minecraft:gold_block
setblock 518 264 481 minecraft:gold_block
setblock 518 264 488 minecraft:gold_block
setblock 518 264 495 minecraft:gold_block
setblock 518 264 502 minecraft:gold_block
setblock 522 264 464 minecraft:gold_block
setblock 523 264 504 minecraft:gold_block
setblock 529 264 464 minecraft:gold_block
fill 530 264 499 538 264 499 minecraft:red_wool
setblock 530 264 504 minecraft:gold_block
fill 533 264 504 535 267 504 minecraft:ochre_froglight
setblock 536 264 464 minecraft:gold_block
setblock 537 264 504 minecraft:gold_block
setblock 543 264 464 minecraft:gold_block
setblock 544 264 504 minecraft:gold_block
setblock 550 264 464 minecraft:gold_block
setblock 551 264 504 minecraft:gold_block
setblock 557 264 464 minecraft:gold_block
setblock 558 264 470 minecraft:gold_block
setblock 558 264 477 minecraft:gold_block
setblock 558 264 484 minecraft:gold_block
setblock 558 264 491 minecraft:gold_block
setblock 558 264 498 minecraft:gold_block
setblock 558 264 504 minecraft:gold_block
setblock 518 265 468 minecraft:gold_block
setblock 518 265 475 minecraft:gold_block
setblock 518 265 482 minecraft:gold_block
setblock 518 265 489 minecraft:gold_block
setblock 518 265 496 minecraft:gold_block
setblock 518 265 503 minecraft:gold_block
setblock 521 265 464 minecraft:gold_block
setblock 524 265 504 minecraft:gold_block
setblock 528 265 464 minecraft:gold_block
setblock 530 265 499 minecraft:gold_block
setblock 531 265 504 minecraft:gold_block
setblock 534 265 499 minecraft:gold_block
setblock 535 265 464 minecraft:gold_block
setblock 538 265 499 minecraft:gold_block
setblock 538 265 504 minecraft:gold_block
setblock 542 265 464 minecraft:gold_block
setblock 545 265 504 minecraft:gold_block
setblock 549 265 464 minecraft:gold_block
setblock 552 265 504 minecraft:gold_block
setblock 556 265 464 minecraft:gold_block
setblock 558 265 469 minecraft:gold_block
setblock 558 265 476 minecraft:gold_block
setblock 558 265 483 minecraft:gold_block
setblock 558 265 490 minecraft:gold_block
setblock 558 265 497 minecraft:gold_block
setblock 518 267 470 minecraft:gold_block
setblock 518 267 477 minecraft:gold_block
setblock 518 267 484 minecraft:gold_block
setblock 518 267 491 minecraft:gold_block
setblock 518 267 498 minecraft:gold_block
setblock 519 267 464 minecraft:gold_block
setblock 519 267 504 minecraft:gold_block
setblock 526 267 464 minecraft:gold_block
setblock 526 267 504 minecraft:gold_block
setblock 533 267 464 minecraft:gold_block
setblock 540 267 464 minecraft:gold_block
setblock 540 267 504 minecraft:gold_block
setblock 547 267 464 minecraft:gold_block
setblock 547 267 504 minecraft:gold_block
setblock 554 267 464 minecraft:gold_block
setblock 554 267 504 minecraft:gold_block
setblock 558 267 467 minecraft:gold_block
setblock 558 267 474 minecraft:gold_block
setblock 558 267 481 minecraft:gold_block
setblock 558 267 488 minecraft:gold_block
setblock 558 267 495 minecraft:gold_block
setblock 558 267 502 minecraft:gold_block
setblock 518 268 464 minecraft:gold_block
setblock 518 268 471 minecraft:gold_block
setblock 518 268 478 minecraft:gold_block
setblock 518 268 485 minecraft:gold_block
setblock 518 268 492 minecraft:gold_block
setblock 518 268 499 minecraft:gold_block
setblock 520 268 504 minecraft:gold_block
setblock 525 268 464 minecraft:gold_block
setblock 527 268 504 minecraft:gold_block
setblock 532 268 464 minecraft:gold_block
setblock 534 268 504 minecraft:gold_block
setblock 539 268 464 minecraft:gold_block
setblock 541 268 504 minecraft:gold_block
setblock 546 268 464 minecraft:gold_block
setblock 548 268 504 minecraft:gold_block
setblock 553 268 464 minecraft:gold_block
setblock 555 268 504 minecraft:gold_block
setblock 558 268 466 minecraft:gold_block
setblock 558 268 473 minecraft:gold_block
setblock 558 268 480 minecraft:gold_block
setblock 558 268 487 minecraft:gold_block
setblock 558 268 494 minecraft:gold_block
setblock 558 268 501 minecraft:gold_block
fill 518 269 465 518 270 465 minecraft:gold_block
fill 518 269 472 518 270 472 minecraft:gold_block
fill 518 269 479 518 270 479 minecraft:gold_block
fill 518 269 486 518 270 486 minecraft:gold_block
fill 518 269 493 518 270 493 minecraft:gold_block
fill 518 269 500 518 270 500 minecraft:gold_block
fill 521 269 504 521 270 504 minecraft:gold_block
fill 524 269 464 524 270 464 minecraft:gold_block
fill 528 269 504 528 270 504 minecraft:gold_block
fill 531 269 464 531 270 464 minecraft:gold_block
fill 535 269 504 535 270 504 minecraft:gold_block
fill 538 269 464 538 270 464 minecraft:gold_block
fill 542 269 504 542 270 504 minecraft:gold_block
fill 545 269 464 545 270 464 minecraft:gold_block
fill 549 269 504 549 270 504 minecraft:gold_block
fill 552 269 464 552 270 464 minecraft:gold_block
fill 556 269 504 556 270 504 minecraft:gold_block
fill 558 269 465 558 270 465 minecraft:gold_block
fill 558 269 472 558 270 472 minecraft:gold_block
fill 558 269 479 558 270 479 minecraft:gold_block
fill 558 269 486 558 270 486 minecraft:gold_block
fill 558 269 493 558 270 493 minecraft:gold_block
fill 558 269 500 558 270 500 minecraft:gold_block
fill 518 270 464 519 270 464 minecraft:gold_block
fill 518 270 466 518 270 468 minecraft:gold_block
fill 518 270 470 518 270 471 minecraft:gold_block
fill 518 270 473 518 270 475 minecraft:gold_block
fill 518 270 477 518 270 478 minecraft:gold_block
fill 518 270 480 518 270 482 minecraft:gold_block
fill 518 270 484 518 270 485 minecraft:gold_block
fill 518 270 487 518 270 489 minecraft:gold_block
fill 518 270 491 518 270 492 minecraft:gold_block
fill 518 270 494 518 270 496 minecraft:gold_block
fill 518 270 498 518 270 499 minecraft:gold_block
fill 518 270 501 518 270 503 minecraft:gold_block
fill 519 270 496 520 271 496 minecraft:white_wool
fill 519 270 504 520 270 504 minecraft:gold_block
setblock 520 270 466 minecraft:light[level=12]
setblock 520 270 474 minecraft:light[level=12]
setblock 520 270 482 minecraft:light[level=12]
setblock 520 270 490 minecraft:light[level=12]
setblock 520 270 498 minecraft:light[level=12]
fill 521 270 464 523 270 464 minecraft:gold_block
fill 522 270 504 524 270 504 minecraft:gold_block
fill 525 270 464 526 270 464 minecraft:gold_block
fill 526 270 504 527 270 504 minecraft:gold_block
fill 528 270 464 530 270 464 minecraft:gold_block
setblock 528 270 466 minecraft:light[level=12]
setblock 528 270 474 minecraft:light[level=12]
setblock 528 270 482 minecraft:light[level=12]
setblock 528 270 490 minecraft:light[level=12]
setblock 528 270 498 minecraft:light[level=12]
fill 529 270 504 531 270 504 minecraft:gold_block
fill 532 270 464 533 270 464 minecraft:gold_block
fill 533 270 504 534 270 504 minecraft:gold_block
fill 535 270 464 537 270 464 minecraft:gold_block
setblock 536 270 466 minecraft:light[level=12]
setblock 536 270 474 minecraft:light[level=12]
setblock 536 270 482 minecraft:light[level=12]
setblock 536 270 490 minecraft:light[level=12]
setblock 536 270 498 minecraft:light[level=12]
fill 536 270 504 538 270 504 minecraft:gold_block
fill 539 270 464 540 270 464 minecraft:gold_block
fill 540 270 504 541 270 504 minecraft:gold_block
fill 542 270 464 544 270 464 minecraft:gold_block
fill 543 270 504 545 270 504 minecraft:gold_block
setblock 544 270 466 minecraft:light[level=12]
setblock 544 270 474 minecraft:light[level=12]
setblock 544 270 482 minecraft:light[level=12]
setblock 544 270 490 minecraft:light[level=12]
setblock 544 270 498 minecraft:light[level=12]
fill 546 270 464 547 270 464 minecraft:gold_block
fill 547 270 504 548 270 504 minecraft:gold_block
fill 549 270 464 551 270 464 minecraft:gold_block
fill 550 270 504 552 270 504 minecraft:gold_block
setblock 552 270 466 minecraft:light[level=12]
setblock 552 270 474 minecraft:light[level=12]
setblock 552 270 482 minecraft:light[level=12]
setblock 552 270 490 minecraft:light[level=12]
setblock 552 270 498 minecraft:light[level=12]
fill 553 270 464 554 270 464 minecraft:gold_block
fill 554 270 504 555 270 504 minecraft:gold_block
fill 556 270 464 558 270 464 minecraft:gold_block
fill 557 270 504 558 270 504 minecraft:gold_block
fill 558 270 466 558 270 467 minecraft:gold_block
fill 558 270 469 558 270 471 minecraft:gold_block
fill 558 270 473 558 270 474 minecraft:gold_block
fill 558 270 476 558 270 478 minecraft:gold_block
fill 558 270 480 558 270 481 minecraft:gold_block
fill 558 270 483 558 270 485 minecraft:gold_block
fill 558 270 487 558 270 488 minecraft:gold_block
fill 558 270 490 558 270 492 minecraft:gold_block
fill 558 270 494 558 270 495 minecraft:gold_block
fill 558 270 497 558 270 499 minecraft:gold_block
fill 558 270 501 558 270 502 minecraft:gold_block
setblock 518 271 467 minecraft:gold_block
setblock 518 271 474 minecraft:gold_block
setblock 518 271 481 minecraft:gold_block
setblock 518 271 488 minecraft:gold_block
setblock 518 271 495 minecraft:gold_block
setblock 518 271 496 minecraft:white_wool
setblock 518 271 502 minecraft:gold_block
setblock 522 271 464 minecraft:gold_block
setblock 523 271 504 minecraft:gold_block
setblock 529 271 464 minecraft:gold_block
setblock 530 271 504 minecraft:gold_block
setblock 536 271 464 minecraft:gold_block
setblock 537 271 504 minecraft:gold_block
setblock 543 271 464 minecraft:gold_block
setblock 544 271 504 minecraft:gold_block
setblock 550 271 464 minecraft:gold_block
setblock 551 271 504 minecraft:gold_block
setblock 557 271 464 minecraft:gold_block
setblock 558 271 470 minecraft:gold_block
setblock 558 271 477 minecraft:gold_block
setblock 558 271 484 minecraft:gold_block
setblock 558 271 491 minecraft:gold_block
setblock 558 271 498 minecraft:gold_block
setblock 558 271 504 minecraft:gold_block
setblock 518 272 468 minecraft:gold_block
setblock 518 272 475 minecraft:gold_block
setblock 518 272 482 minecraft:gold_block
setblock 518 272 489 minecraft:gold_block
setblock 518 272 496 minecraft:gold_block
setblock 518 272 503 minecraft:gold_block
setblock 521 272 464 minecraft:gold_block
setblock 524 272 504 minecraft:gold_block
setblock 528 272 464 minecraft:gold_block
setblock 531 272 504 minecraft:gold_block
setblock 535 272 464 minecraft:gold_block
setblock 538 272 504 minecraft:gold_block
setblock 542 272 464 minecraft:gold_block
setblock 545 272 504 minecraft:gold_block
setblock 549 272 464 minecraft:gold_block
setblock 552 272 504 minecraft:gold_block
setblock 556 272 464 minecraft:gold_block
setblock 558 272 469 minecraft:gold_block
setblock 558 272 476 minecraft:gold_block
setblock 558 272 483 minecraft:gold_block
setblock 558 272 490 minecraft:gold_block
setblock 558 272 497 minecraft:gold_block
setblock 520 278 466 minecraft:light[level=12]
setblock 520 278 474 minecraft:light[level=12]
setblock 520 278 482 minecraft:light[level=12]
setblock 520 278 490 minecraft:light[level=12]
setblock 520 278 498 minecraft:light[level=12]
setblock 528 278 466 minecraft:light[level=12]
setblock 528 278 474 minecraft:light[level=12]
setblock 528 278 482 minecraft:light[level=12]
setblock 528 278 490 minecraft:light[level=12]
setblock 528 278 498 minecraft:light[level=12]
setblock 536 278 466 minecraft:light[level=12]
setblock 536 278 474 minecraft:light[level=12]
setblock 536 278 482 minecraft:light[level=12]
setblock 536 278 490 minecraft:light[level=12]
setblock 536 278 498 minecraft:light[level=12]
setblock 544 278 466 minecraft:light[level=12]
setblock 544 278 474 minecraft:light[level=12]
setblock 544 278 482 minecraft:light[level=12]
setblock 544 278 490 minecraft:light[level=12]
setblock 544 278 498 minecraft:light[level=12]
setblock 552 278 466 minecraft:light[level=12]
setblock 552 278 474 minecraft:light[level=12]
setblock 552 278 482 minecraft:light[level=12]
setblock 552 278 490 minecraft:light[level=12]
setblock 552 278 498 minecraft:light[level=12]
fill 518 279 464 522 280 504 minecraft:red_wool
fill 523 279 464 523 280 504 minecraft:gold_block
fill 524 279 464 528 280 504 minecraft:red_wool
fill 529 279 464 529 280 504 minecraft:gold_block
fill 530 279 464 534 280 504 minecraft:red_wool
fill 535 279 464 535 279 504 minecraft:gold_block
fill 536 279 464 536 279 486 minecraft:red_wool
fill 536 279 488 536 279 504 minecraft:red_wool
fill 537 279 464 537 279 485 minecraft:red_wool
fill 537 279 489 537 279 504 minecraft:red_wool
fill 538 279 464 540 279 484 minecraft:red_wool
fill 538 279 490 540 279 504 minecraft:red_wool
fill 539 279 485 540 279 485 minecraft:red_wool
fill 539 279 489 540 279 489 minecraft:red_wool
setblock 540 279 486 minecraft:red_wool
setblock 540 279 488 minecraft:red_wool
fill 541 279 464 541 279 504 minecraft:gold_block
fill 542 279 464 546 280 504 minecraft:red_wool
fill 547 279 464 547 280 504 minecraft:gold_block
fill 548 279 464 552 280 504 minecraft:red_wool
fill 553 279 464 553 280 504 minecraft:gold_block
fill 554 279 464 558 280 504 minecraft:red_wool
fill 535 280 464 535 280 485 minecraft:gold_block
fill 535 280 486 535 280 488 minecraft:ochre_froglight
fill 535 280 489 535 280 504 minecraft:gold_block
fill 536 280 464 536 280 484 minecraft:red_wool
fill 536 280 485 536 280 486 minecraft:ochre_froglight
fill 536 280 488 536 280 489 minecraft:ochre_froglight
fill 536 280 490 536 280 504 minecraft:red_wool
fill 537 280 464 540 280 483 minecraft:red_wool
fill 537 280 484 537 280 485 minecraft:ochre_froglight
fill 537 280 489 537 280 490 minecraft:ochre_froglight
fill 537 280 491 540 280 504 minecraft:red_wool
fill 538 280 484 539 280 484 minecraft:ochre_froglight
fill 538 280 490 539 280 490 minecraft:ochre_froglight
fill 539 280 485 540 280 485 minecraft:ochre_froglight
fill 539 280 489 540 280 489 minecraft:ochre_froglight
setblock 540 280 484 minecraft:red_wool
fill 540 280 486 541 280 486 minecraft:ochre_froglight
fill 540 280 488 541 280 488 minecraft:ochre_froglight
setblock 540 280 490 minecraft:red_wool
fill 541 280 464 541 280 485 minecraft:gold_block
setblock 541 280 487 minecraft:ochre_froglight
fill 541 280 489 541 280 504 minecraft:gold_block
setblock 518 284 466 minecraft:gold_block
fill 518 284 469 518 300 469 minecraft:gold_block
setblock 518 284 473 minecraft:gold_block
fill 518 284 476 518 300 476 minecraft:gold_block
setblock 518 284 480 minecraft:gold_block
fill 518 284 483 518 300 483 minecraft:gold_block
setblock 518 284 487 minecraft:gold_block
fill 518 284 490 518 300 490 minecraft:gold_block
setblock 518 284 494 minecraft:gold_block
fill 518 284 497 518 300 497 minecraft:gold_block
setblock 518 284 501 minecraft:gold_block
fill 518 284 504 518 300 504 minecraft:gold_block
fill 520 284 464 520 300 464 minecraft:gold_block
setblock 522 284 504 minecraft:gold_block
setblock 523 284 464 minecraft:gold_block
fill 525 284 504 525 300 504 minecraft:gold_block
fill 527 284 464 527 300 464 minecraft:gold_block
setblock 529 284 504 minecraft:gold_block
setblock 530 284 464 minecraft:gold_block
fill 532 284 504 532 300 504 minecraft:gold_block
fill 534 284 464 534 300 464 minecraft:gold_block
setblock 536 284 504 minecraft:gold_block
setblock 537 284 464 minecraft:gold_block
fill 539 284 504 539 300 504 minecraft:gold_block
fill 541 284 464 541 300 464 minecraft:gold_block
setblock 543 284 504 minecraft:gold_block
setblock 544 284 464 minecraft:gold_block
fill 546 284 504 546 300 504 minecraft:gold_block
fill 548 284 464 548 300 464 minecraft:gold_block
setblock 550 284 504 minecraft:gold_block
setblock 551 284 464 minecraft:gold_block
fill 553 284 504 553 300 504 minecraft:gold_block
fill 555 284 464 555 300 464 minecraft:gold_block
fill 556 284 485 556 290 489 minecraft:red_wool
setblock 557 284 504 minecraft:gold_block
setblock 558 284 464 minecraft:gold_block
fill 558 284 468 558 300 468 minecraft:gold_block
setblock 558 284 471 minecraft:gold_block
fill 558 284 475 558 300 475 minecraft:gold_block
setblock 558 284 478 minecraft:gold_block
fill 558 284 482 558 300 482 minecraft:gold_block
setblock 558 284 485 minecraft:gold_block
fill 558 284 489 558 300 489 minecraft:gold_block
setblock 558 284 492 minecraft:gold_block
fill 558 284 496 558 300 496 minecraft:gold_block
setblock 558 284 499 minecraft:gold_block
fill 558 284 503 558 300 503 minecraft:gold_block
setblock 518 285 467 minecraft:gold_block
setblock 518 285 474 minecraft:gold_block
setblock 518 285 481 minecraft:gold_block
setblock 518 285 488 minecraft:gold_block
setblock 518 285 495 minecraft:gold_block
setblock 518 285 502 minecraft:gold_block
setblock 522 285 464 minecraft:gold_block
setblock 523 285 504 minecraft:gold_block
setblock 529 285 464 minecraft:gold_block
setblock 530 285 504 minecraft:gold_block
setblock 536 285 464 minecraft:gold_block
setblock 537 285 504 minecraft:gold_block
setblock 543 285 464 minecraft:gold_block
setblock 544 285 504 minecraft:gold_block
setblock 550 285 464 minecraft:gold_block
setblock 551 285 504 minecraft:gold_block
setblock 557 285 464 minecraft:gold_block
setblock 558 285 470 minecraft:gold_block
setblock 558 285 477 minecraft:gold_block
setblock 558 285 484 minecraft:gold_block
setblock 558 285 491 minecraft:gold_block
setblock 558 285 498 minecraft:gold_block
setblock 558 285 504 minecraft:gold_block
setblock 518 286 468 minecraft:gold_block
setblock 518 286 475 minecraft:gold_block
setblock 518 286 482 minecraft:gold_block
setblock 518 286 489 minecraft:gold_block
setblock 518 286 496 minecraft:gold_block
setblock 518 286 503 minecraft:gold_block
setblock 520 286 466 minecraft:light[level=12]
setblock 520 286 474 minecraft:light[level=12]
setblock 520 286 482 minecraft:light[level=12]
setblock 520 286 490 minecraft:light[level=12]
setblock 520 286 498 minecraft:light[level=12]
setblock 521 286 464 minecraft:gold_block
setblock 524 286 504 minecraft:gold_block
setblock 528 286 464 minecraft:gold_block
setblock 528 286 466 minecraft:light[level=12]
setblock 528 286 474 minecraft:light[level=12]
setblock 528 286 482 minecraft:light[level=12]
setblock 528 286 490 minecraft:light[level=12]
setblock 528 286 498 minecraft:light[level=12]
setblock 531 286 504 minecraft:gold_block
setblock 535 286 464 minecraft:gold_block
setblock 536 286 466 minecraft:light[level=12]
setblock 536 286 474 minecraft:light[level=12]
setblock 536 286 482 minecraft:light[level=12]
setblock 536 286 490 minecraft:light[level=12]
setblock 536 286 498 minecraft:light[level=12]
setblock 538 286 504 minecraft:gold_block
setblock 542 286 464 minecraft:gold_block
setblock 544 286 466 minecraft:light[level=12]
setblock 544 286 474 minecraft:light[level=12]
setblock 544 286 482 minecraft:light[level=12]
setblock 544 286 490 minecraft:light[level=12]
setblock 544 286 498 minecraft:light[level=12]
setblock 545 286 504 minecraft:gold_block
setblock 549 286 464 minecraft:gold_block
setblock 552 286 466 minecraft:light[level=12]
setblock 552 286 474 minecraft:light[level=12]
setblock 552 286 482 minecraft:light[level=12]
setblock 552 286 490 minecraft:light[level=12]
setblock 552 286 498 minecraft:light[level=12]
setblock 552 286 504 minecraft:gold_block
setblock 556 286 464 minecraft:gold_block
setblock 558 286 469 minecraft:gold_block
setblock 558 286 476 minecraft:gold_block
setblock 558 286 483 minecraft:gold_block
setblock 558 286 490 minecraft:gold_block
setblock 558 286 497 minecraft:gold_block
setblock 518 288 470 minecraft:gold_block
setblock 518 288 477 minecraft:gold_block
setblock 518 288 484 minecraft:gold_block
setblock 518 288 491 minecraft:gold_block
setblock 518 288 498 minecraft:gold_block
setblock 519 288 464 minecraft:gold_block
setblock 519 288 504 minecraft:gold_block
setblock 526 288 464 minecraft:gold_block
setblock 526 288 504 minecraft:gold_block
setblock 533 288 464 minecraft:gold_block
setblock 533 288 504 minecraft:gold_block
setblock 540 288 464 minecraft:gold_block
setblock 540 288 504 minecraft:gold_block
setblock 547 288 464 minecraft:gold_block
setblock 547 288 504 minecraft:gold_block
setblock 554 288 464 minecraft:gold_block
setblock 554 288 504 minecraft:gold_block
setblock 558 288 467 minecraft:gold_block
setblock 558 288 474 minecraft:gold_block
setblock 558 288 481 minecraft:gold_block
setblock 558 288 488 minecraft:gold_block
setblock 558 288 495 minecraft:gold_block
setblock 558 288 502 minecraft:gold_block
fill 518 289 464 518 290 464 minecraft:gold_block
fill 518 289 471 518 290 471 minecraft:gold_block
fill 518 289 478 518 290 478 minecraft:gold_block
fill 518 289 485 518 290 485 minecraft:gold_block
fill 518 289 492 518 290 492 minecraft:gold_block
fill 518 289 499 518 290 499 minecraft:gold_block
fill 520 289 504 520 290 504 minecraft:gold_block
fill 525 289 464 525 290 464 minecraft:gold_block
fill 527 289 504 527 290 504 minecraft:gold_block
fill 532 289 464 532 290 464 minecraft:gold_block
fill 534 289 504 534 290 504 minecraft:gold_block
fill 539 289 464 539 290 464 minecraft:gold_block
fill 541 289 504 541 290 504 minecraft:gold_block
fill 546 289 464 546 290 464 minecraft:gold_block
fill 548 289 504 548 290 504 minecraft:gold_block
fill 553 289 464 553 290 464 minecraft:gold_block
fill 555 289 504 555 290 504 minecraft:gold_block
fill 558 289 466 558 290 466 minecraft:gold_block
fill 558 289 473 558 290 473 minecraft:gold_block
fill 558 289 480 558 290 480 minecraft:gold_block
fill 558 289 487 558 290 487 minecraft:gold_block
fill 558 289 494 558 290 494 minecraft:gold_block
fill 558 289 501 558 290 501 minecraft:gold_block
fill 518 290 465 518 290 468 minecraft:gold_block
setblock 518 290 470 minecraft:gold_block
fill 518 290 472 518 290 475 minecraft:gold_block
setblock 518 290 477 minecraft:gold_block
fill 518 290 479 518 290 482 minecraft:gold_block
setblock 518 290 484 minecraft:gold_block
fill 518 290 486 518 290 489 minecraft:gold_block
setblock 518 290 491 minecraft:gold_block
fill 518 290 493 518 290 496 minecraft:gold_block
setblock 518 290 498 minecraft:gold_block
fill 518 290 500 518 290 503 minecraft:gold_block
setblock 519 290 464 minecraft:gold_block
setblock 519 290 504 minecraft:gold_block
fill 521 290 464 524 290 464 minecraft:gold_block
fill 521 290 504 524 290 504 minecraft:gold_block
setblock 526 290 464 minecraft:gold_block
setblock 526 290 504 minecraft:gold_block
fill 528 290 464 531 290 464 minecraft:gold_block
fill 528 290 504 531 290 504 minecraft:gold_block
setblock 533 290 464 minecraft:gold_block
setblock 533 290 504 minecraft:gold_block
fill 535 290 464 538 290 464 minecraft:gold_block
fill 535 290 504 538 290 504 minecraft:gold_block
setblock 540 290 464 minecraft:gold_block
setblock 540 290 504 minecraft:gold_block
fill 542 290 464 545 290 464 minecraft:gold_block
fill 542 290 504 545 290 504 minecraft:gold_block
setblock 547 290 464 minecraft:gold_block
setblock 547 290 504 minecraft:gold_block
fill 549 290 464 552 290 464 minecraft:gold_block
fill 549 290 504 552 290 504 minecraft:gold_block
setblock 554 290 464 minecraft:gold_block
setblock 554 290 504 minecraft:gold_block
fill 556 290 464 558 290 464 minecraft:gold_block
fill 556 290 504 558 290 504 minecraft:gold_block
setblock 558 290 465 minecraft:gold_block
setblock 558 290 467 minecraft:gold_block
fill 558 290 469 558 290 472 minecraft:gold_block
setblock 558 290 474 minecraft:gold_block
fill 558 290 476 558 290 479 minecraft:gold_block
setblock 558 290 481 minecraft:gold_block
fill 558 290 483 558 290 486 minecraft:gold_block
setblock 558 290 488 minecraft:gold_block
fill 558 290 490 558 290 493 minecraft:gold_block
setblock 558 290 495 minecraft:gold_block
fill 558 290 497 558 290 500 minecraft:gold_block
setblock 558 290 502 minecraft:gold_block
setblock 518 291 466 minecraft:gold_block
setblock 518 291 473 minecraft:gold_block
setblock 518 291 480 minecraft:gold_block
setblock 518 291 487 minecraft:gold_block
setblock 518 291 494 minecraft:gold_block
setblock 518 291 501 minecraft:gold_block
setblock 522 291 504 minecraft:gold_block
setblock 523 291 464 minecraft:gold_block
setblock 529 291 504 minecraft:gold_block
setblock 530 291 464 minecraft:gold_block
setblock 536 291 504 minecraft:gold_block
setblock 537 291 464 minecraft:gold_block
setblock 543 291 504 minecraft:gold_block
setblock 544 291 464 minecraft:gold_block
setblock 550 291 504 minecraft:gold_block
setblock 551 291 464 minecraft:gold_block
fill 556 291 484 556 292 490 minecraft:white_wool
setblock 557 291 504 minecraft:gold_block
setblock 558 291 464 minecraft:gold_block
setblock 558 291 471 minecraft:gold_block
setblock 558 291 478 minecraft:gold_block
setblock 558 291 485 minecraft:gold_block
setblock 558 291 492 minecraft:gold_block
setblock 558 291 499 minecraft:gold_block
setblock 518 292 467 minecraft:gold_block
setblock 518 292 474 minecraft:gold_block
setblock 518 292 481 minecraft:gold_block
setblock 518 292 488 minecraft:gold_block
setblock 518 292 495 minecraft:gold_block
setblock 518 292 502 minecraft:gold_block
setblock 522 292 464 minecraft:gold_block
setblock 523 292 504 minecraft:gold_block
setblock 529 292 464 minecraft:gold_block
setblock 530 292 504 minecraft:gold_block
setblock 536 292 464 minecraft:gold_block
setblock 537 292 504 minecraft:gold_block
setblock 543 292 464 minecraft:gold_block
setblock 544 292 504 minecraft:gold_block
setblock 550 292 464 minecraft:gold_block
setblock 551 292 504 minecraft:gold_block
setblock 557 292 464 minecraft:gold_block
setblock 558 292 470 minecraft:gold_block
setblock 558 292 477 minecraft:gold_block
setblock 558 292 484 minecraft:gold_block
setblock 558 292 491 minecraft:gold_block
setblock 558 292 498 minecraft:gold_block
setblock 558 292 504 minecraft:gold_block
setblock 518 293 468 minecraft:gold_block
setblock 518 293 475 minecraft:gold_block
setblock 518 293 482 minecraft:gold_block
setblock 518 293 489 minecraft:gold_block
setblock 518 293 496 minecraft:gold_block
setblock 518 293 503 minecraft:gold_block
setblock 521 293 464 minecraft:gold_block
setblock 524 293 504 minecraft:gold_block
setblock 528 293 464 minecraft:gold_block
setblock 531 293 504 minecraft:gold_block
setblock 535 293 464 minecraft:gold_block
setblock 538 293 504 minecraft:gold_block
setblock 542 293 464 minecraft:gold_block
setblock 545 293 504 minecraft:gold_block
setblock 549 293 464 minecraft:gold_block
setblock 552 293 504 minecraft:gold_block
setblock 556 293 464 minecraft:gold_block
setblock 558 293 469 minecraft:gold_block
setblock 558 293 476 minecraft:gold_block
setblock 558 293 483 minecraft:gold_block
setblock 558 293 490 minecraft:gold_block
setblock 558 293 497 minecraft:gold_block
setblock 520 294 466 minecraft:light[level=12]
setblock 520 294 474 minecraft:light[level=12]
setblock 520 294 482 minecraft:light[level=12]
setblock 520 294 490 minecraft:light[level=12]
setblock 520 294 498 minecraft:light[level=12]
setblock 528 294 466 minecraft:light[level=12]
setblock 528 294 474 minecraft:light[level=12]
setblock 528 294 482 minecraft:light[level=12]
setblock 528 294 490 minecraft:light[level=12]
setblock 528 294 498 minecraft:light[level=12]
setblock 536 294 466 minecraft:light[level=12]
setblock 536 294 474 minecraft:light[level=12]
setblock 536 294 482 minecraft:light[level=12]
setblock 536 294 490 minecraft:light[level=12]
setblock 536 294 498 minecraft:light[level=12]
setblock 544 294 466 minecraft:light[level=12]
setblock 544 294 474 minecraft:light[level=12]
setblock 544 294 482 minecraft:light[level=12]
setblock 544 294 490 minecraft:light[level=12]
setblock 544 294 498 minecraft:light[level=12]
setblock 552 294 466 minecraft:light[level=12]
setblock 552 294 474 minecraft:light[level=12]
setblock 552 294 482 minecraft:light[level=12]
setblock 552 294 490 minecraft:light[level=12]
setblock 552 294 498 minecraft:light[level=12]
setblock 518 295 470 minecraft:gold_block
setblock 518 295 477 minecraft:gold_block
setblock 518 295 484 minecraft:gold_block
setblock 518 295 491 minecraft:gold_block
setblock 518 295 498 minecraft:gold_block
setblock 519 295 464 minecraft:gold_block
setblock 519 295 504 minecraft:gold_block
setblock 526 295 464 minecraft:gold_block
setblock 526 295 504 minecraft:gold_block
setblock 533 295 464 minecraft:gold_block
setblock 533 295 504 minecraft:gold_block
setblock 540 295 464 minecraft:gold_block
setblock 540 295 504 minecraft:gold_block
setblock 547 295 464 minecraft:gold_block
setblock 547 295 504 minecraft:gold_block
setblock 554 295 464 minecraft:gold_block
setblock 554 295 504 minecraft:gold_block
setblock 558 295 467 minecraft:gold_block
setblock 558 295 474 minecraft:gold_block
setblock 558 295 481 minecraft:gold_block
setblock 558 295 488 minecraft:gold_block
setblock 558 295 495 minecraft:gold_block
setblock 558 295 502 minecraft:gold_block
setblock 518 296 464 minecraft:gold_block
setblock 518 296 471 minecraft:gold_block
setblock 518 296 478 minecraft:gold_block
setblock 518 296 485 minecraft:gold_block
setblock 518 296 492 minecraft:gold_block
setblock 518 296 499 minecraft:gold_block
setblock 520 296 504 minecraft:gold_block
setblock 525 296 464 minecraft:gold_block
setblock 527 296 504 minecraft:gold_block
setblock 532 296 464 minecraft:gold_block
setblock 534 296 504 minecraft:gold_block
setblock 539 296 464 minecraft:gold_block
setblock 541 296 504 minecraft:gold_block
setblock 546 296 464 minecraft:gold_block
setblock 548 296 504 minecraft:gold_block
setblock 553 296 464 minecraft:gold_block
setblock 555 296 504 minecraft:gold_block
setblock 558 296 466 minecraft:gold_block
setblock 558 296 473 minecraft:gold_block
setblock 558 296 480 minecraft:gold_block
setblock 558 296 487 minecraft:gold_block
setblock 558 296 494 minecraft:gold_block
setblock 558 296 501 minecraft:gold_block
setblock 518 297 465 minecraft:gold_block
setblock 518 297 472 minecraft:gold_block
setblock 518 297 479 minecraft:gold_block
setblock 518 297 486 minecraft:gold_block
setblock 518 297 493 minecraft:gold_block
setblock 518 297 500 minecraft:gold_block
setblock 521 297 504 minecraft:gold_block
setblock 524 297 464 minecraft:gold_block
setblock 528 297 504 minecraft:gold_block
setblock 531 297 464 minecraft:gold_block
setblock 535 297 504 minecraft:gold_block
setblock 538 297 464 minecraft:gold_block
setblock 542 297 504 minecraft:gold_block
setblock 545 297 464 minecraft:gold_block
setblock 549 297 504 minecraft:gold_block
setblock 552 297 464 minecraft:gold_block
setblock 556 297 504 minecraft:gold_block
setblock 558 297 465 minecraft:gold_block
setblock 558 297 472 minecraft:gold_block
setblock 558 297 479 minecraft:gold_block
setblock 558 297 486 minecraft:gold_block
setblock 558 297 493 minecraft:gold_block
setblock 558 297 500 minecraft:gold_block
setblock 518 298 466 minecraft:gold_block
setblock 518 298 473 minecraft:gold_block
setblock 518 298 480 minecraft:gold_block
setblock 518 298 487 minecraft:gold_block
setblock 518 298 494 minecraft:gold_block
setblock 518 298 501 minecraft:gold_block
setblock 522 298 504 minecraft:gold_block
setblock 523 298 464 minecraft:gold_block
setblock 529 298 504 minecraft:gold_block
setblock 530 298 464 minecraft:gold_block
setblock 536 298 504 minecraft:gold_block
setblock 537 298 464 minecraft:gold_block
setblock 543 298 504 minecraft:gold_block
setblock 544 298 464 minecraft:gold_block
setblock 550 298 504 minecraft:gold_block
setblock 551 298 464 minecraft:gold_block
setblock 557 298 504 minecraft:gold_block
setblock 558 298 464 minecraft:gold_block
setblock 558 298 471 minecraft:gold_block
setblock 558 298 478 minecraft:gold_block
setblock 558 298 485 minecraft:gold_block
setblock 558 298 492 minecraft:gold_block
setblock 558 298 499 minecraft:gold_block
fill 518 299 467 518 300 467 minecraft:gold_block
fill 518 299 474 518 300 474 minecraft:gold_block
fill 518 299 481 518 300 481 minecraft:gold_block
fill 518 299 488 518 300 488 minecraft:gold_block
fill 518 299 495 518 300 495 minecraft:gold_block
fill 518 299 502 518 300 502 minecraft:gold_block
fill 522 299 464 522 300 464 minecraft:gold_block
fill 523 299 504 523 300 504 minecraft:gold_block
fill 529 299 464 529 300 464 minecraft:gold_block
fill 530 299 504 530 300 504 minecraft:gold_block
fill 536 299 464 536 300 464 minecraft:gold_block
fill 537 299 504 537 300 504 minecraft:gold_block
fill 543 299 464 543 300 464 minecraft:gold_block
fill 544 299 504 544 300 504 minecraft:gold_block
fill 550 299 464 550 300 464 minecraft:gold_block
fill 551 299 504 551 300 504 minecraft:gold_block
fill 557 299 464 557 300 464 minecraft:gold_block
fill 558 299 470 558 300 470 minecraft:gold_block
fill 558 299 477 558 300 477 minecraft:gold_block
fill 558 299 484 558 300 484 minecraft:gold_block
fill 558 299 491 558 300 491 minecraft:gold_block
fill 558 299 498 558 300 498 minecraft:gold_block
fill 558 299 504 558 300 504 minecraft:gold_block
fill 518 300 464 518 300 466 minecraft:gold_block
setblock 518 300 468 minecraft:gold_block
fill 518 300 470 518 300 473 minecraft:gold_block
setblock 518 300 475 minecraft:gold_block
fill 518 300 477 518 300 480 minecraft:gold_block
setblock 518 300 482 minecraft:gold_block
fill 518 300 484 518 300 487 minecraft:gold_block
setblock 518 300 489 minecraft:gold_block
fill 518 300 491 518 300 494 minecraft:gold_block
setblock 518 300 496 minecraft:gold_block
fill 518 300 498 518 300 501 minecraft:gold_block
setblock 518 300 503 minecraft:gold_block
setblock 519 300 464 minecraft:gold_block
fill 519 300 504 522 300 504 minecraft:gold_block
setblock 521 300 464 minecraft:gold_block
fill 523 300 464 526 300 464 minecraft:gold_block
setblock 524 300 504 minecraft:gold_block
fill 526 300 504 529 300 504 minecraft:gold_block
setblock 528 300 464 minecraft:gold_block
fill 530 300 464 533 300 464 minecraft:gold_block
setblock 531 300 504 minecraft:gold_block
fill 533 300 504 536 300 504 minecraft:gold_block
setblock 535 300 464 minecraft:gold_block
fill 537 300 464 540 300 464 minecraft:gold_block
setblock 538 300 504 minecraft:gold_block
fill 540 300 504 543 300 504 minecraft:gold_block
setblock 542 300 464 minecraft:gold_block
fill 544 300 464 547 300 464 minecraft:gold_block
setblock 545 300 504 minecraft:gold_block
fill 547 300 504 550 300 504 minecraft:gold_block
setblock 549 300 464 minecraft:gold_block
fill 551 300 464 554 300 464 minecraft:gold_block
setblock 552 300 504 minecraft:gold_block
fill 554 300 504 557 300 504 minecraft:gold_block
setblock 556 300 464 minecraft:gold_block
fill 558 300 464 558 300 467 minecraft:gold_block
setblock 558 300 469 minecraft:gold_block
fill 558 300 471 558 300 474 minecraft:gold_block
setblock 558 300 476 minecraft:gold_block
fill 558 300 478 558 300 481 minecraft:gold_block
setblock 558 300 483 minecraft:gold_block
fill 558 300 485 558 300 488 minecraft:gold_block
setblock 558 300 490 minecraft:gold_block
fill 558 300 492 558 300 495 minecraft:gold_block
setblock 558 300 497 minecraft:gold_block
fill 558 300 499 558 300 502 minecraft:gold_block
setblock 520 302 466 minecraft:light[level=12]
setblock 520 302 474 minecraft:light[level=12]
setblock 520 302 482 minecraft:light[level=12]
setblock 520 302 490 minecraft:light[level=12]
setblock 520 302 498 minecraft:light[level=12]
setblock 528 302 466 minecraft:light[level=12]
setblock 528 302 474 minecraft:light[level=12]
setblock 528 302 482 minecraft:light[level=12]
setblock 528 302 490 minecraft:light[level=12]
setblock 528 302 498 minecraft:light[level=12]
setblock 536 302 466 minecraft:light[level=12]
setblock 536 302 474 minecraft:light[level=12]
setblock 536 302 482 minecraft:light[level=12]
setblock 536 302 490 minecraft:light[level=12]
setblock 536 302 498 minecraft:light[level=12]
setblock 544 302 466 minecraft:light[level=12]
setblock 544 302 474 minecraft:light[level=12]
setblock 544 302 482 minecraft:light[level=12]
setblock 544 302 490 minecraft:light[level=12]
setblock 544 302 498 minecraft:light[level=12]
setblock 552 302 466 minecraft:light[level=12]
setblock 552 302 474 minecraft:light[level=12]
setblock 552 302 482 minecraft:light[level=12]
setblock 552 302 490 minecraft:light[level=12]
setblock 552 302 498 minecraft:light[level=12]
