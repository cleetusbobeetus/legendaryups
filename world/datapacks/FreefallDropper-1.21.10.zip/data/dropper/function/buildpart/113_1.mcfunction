setblock 236 5 496 minecraft:bone_block
fill 236 5 497 236 7 497 minecraft:brown_terracotta
setblock 236 5 501 minecraft:bone_block
fill 236 5 502 236 6 504 minecraft:brown_terracotta
setblock 237 5 500 minecraft:bone_block
fill 237 5 501 237 6 501 minecraft:brown_terracotta
fill 237 5 503 237 5 504 minecraft:brown_terracotta
setblock 238 5 464 minecraft:bone_block
setblock 238 5 503 minecraft:brown_terracotta
setblock 238 5 504 minecraft:bone_block
fill 239 5 464 242 5 464 minecraft:brown_terracotta
setblock 239 5 503 minecraft:bone_block
fill 239 5 504 239 8 504 minecraft:brown_terracotta
fill 240 5 503 240 8 503 minecraft:brown_terracotta
fill 242 5 502 244 5 502 minecraft:brown_terracotta
setblock 243 5 464 minecraft:bone_block
setblock 243 5 504 minecraft:bone_block
fill 244 5 464 244 7 465 minecraft:brown_terracotta
setblock 244 5 503 minecraft:bone_block
fill 244 5 504 244 8 504 minecraft:brown_terracotta
fill 245 5 465 246 5 465 minecraft:brown_terracotta
setblock 245 5 502 minecraft:bone_block
fill 245 5 503 245 8 503 minecraft:brown_terracotta
fill 246 5 466 246 15 466 minecraft:soul_soil
fill 246 5 502 246 7 502 minecraft:brown_terracotta
setblock 247 5 465 minecraft:bone_block
setblock 248 5 464 minecraft:bone_block
fill 248 5 465 248 8 465 minecraft:brown_terracotta
setblock 248 5 504 minecraft:bone_block
fill 249 5 464 249 8 464 minecraft:brown_terracotta
setblock 249 5 503 minecraft:bone_block
fill 249 5 504 249 8 504 minecraft:brown_terracotta
setblock 250 5 502 minecraft:bone_block
fill 250 5 503 250 7 503 minecraft:brown_terracotta
setblock 251 5 465 minecraft:brown_terracotta
setblock 252 5 465 minecraft:bone_block
setblock 253 5 464 minecraft:bone_block
setblock 253 5 504 minecraft:bone_block
fill 254 5 464 254 8 464 minecraft:brown_terracotta
fill 254 5 504 254 7 504 minecraft:brown_terracotta
setblock 257 5 464 minecraft:brown_terracotta
setblock 258 5 464 minecraft:bone_block
setblock 258 5 504 minecraft:bone_block
fill 259 5 464 259 8 464 minecraft:brown_terracotta
fill 259 5 504 259 7 504 minecraft:brown_terracotta
setblock 261 5 465 minecraft:brown_terracotta
setblock 262 5 464 minecraft:brown_terracotta
setblock 262 5 465 minecraft:bone_block
setblock 263 5 464 minecraft:bone_block
fill 263 5 465 263 7 466 minecraft:brown_terracotta
setblock 263 5 503 minecraft:brown_terracotta
setblock 263 5 504 minecraft:bone_block
fill 264 5 464 264 8 464 minecraft:brown_terracotta
fill 264 5 466 265 5 466 minecraft:brown_terracotta
setblock 264 5 503 minecraft:bone_block
fill 264 5 504 264 8 504 minecraft:brown_terracotta
fill 265 5 503 265 8 503 minecraft:brown_terracotta
setblock 266 5 466 minecraft:bone_block
fill 266 5 502 269 5 502 minecraft:brown_terracotta
setblock 267 5 465 minecraft:bone_block
fill 267 5 466 267 7 467 minecraft:brown_terracotta
setblock 268 5 464 minecraft:bone_block
fill 268 5 465 268 8 465 minecraft:brown_terracotta
fill 268 5 467 269 5 467 minecraft:brown_terracotta
setblock 268 5 504 minecraft:bone_block
fill 269 5 464 269 8 464 minecraft:brown_terracotta
setblock 269 5 503 minecraft:bone_block
fill 269 5 504 269 8 504 minecraft:brown_terracotta
setblock 270 5 467 minecraft:bone_block
setblock 270 5 502 minecraft:bone_block
fill 270 5 503 270 8 503 minecraft:brown_terracotta
setblock 271 5 466 minecraft:bone_block
fill 271 5 502 271 7 502 minecraft:brown_terracotta
setblock 272 5 465 minecraft:bone_block
fill 272 5 466 272 8 466 minecraft:brown_terracotta
setblock 273 5 464 minecraft:bone_block
fill 273 5 465 273 8 465 minecraft:brown_terracotta
setblock 273 5 504 minecraft:bone_block
fill 274 5 464 274 8 464 minecraft:brown_terracotta
setblock 274 5 466 minecraft:brown_terracotta
setblock 274 5 503 minecraft:bone_block
fill 274 5 504 274 8 504 minecraft:brown_terracotta
setblock 275 5 467 minecraft:bone_block
setblock 275 5 502 minecraft:bone_block
fill 275 5 503 275 8 503 minecraft:brown_terracotta
setblock 276 5 466 minecraft:bone_block
fill 276 5 467 276 8 467 minecraft:brown_terracotta
setblock 276 5 481 minecraft:bone_block
fill 276 5 482 276 6 482 minecraft:brown_terracotta
setblock 276 5 501 minecraft:bone_block
fill 276 5 502 276 8 502 minecraft:brown_terracotta
setblock 236 6 465 minecraft:bone_block
setblock 236 6 466 minecraft:brown_terracotta
setblock 236 6 481 minecraft:brown_terracotta
setblock 236 6 484 minecraft:brown_terracotta
setblock 236 6 485 minecraft:bone_block
fill 236 6 486 236 9 486 minecraft:brown_terracotta
setblock 236 6 489 minecraft:brown_terracotta
setblock 236 6 490 minecraft:bone_block
fill 236 6 491 236 9 491 minecraft:brown_terracotta
setblock 236 6 496 minecraft:brown_terracotta
setblock 236 6 500 minecraft:bone_block
fill 236 6 501 236 9 501 minecraft:brown_terracotta
setblock 237 6 464 minecraft:bone_block
setblock 237 6 500 minecraft:brown_terracotta
setblock 237 6 503 minecraft:brown_terracotta
setblock 237 6 504 minecraft:bone_block
fill 238 6 464 241 6 464 minecraft:brown_terracotta
setblock 238 6 503 minecraft:bone_block
fill 238 6 504 238 9 504 minecraft:brown_terracotta
fill 239 6 503 239 8 503 minecraft:brown_terracotta
setblock 242 6 464 minecraft:bone_block
fill 242 6 502 243 6 502 minecraft:brown_terracotta
setblock 242 6 504 minecraft:bone_block
fill 243 6 464 243 8 465 minecraft:brown_terracotta
setblock 243 6 503 minecraft:bone_block
fill 243 6 504 243 9 504 minecraft:brown_terracotta
setblock 244 6 502 minecraft:bone_block
fill 244 6 503 244 9 503 minecraft:brown_terracotta
setblock 245 6 465 minecraft:brown_terracotta
fill 245 6 502 245 7 502 minecraft:brown_terracotta
setblock 246 6 465 minecraft:bone_block
setblock 247 6 464 minecraft:bone_block
fill 247 6 465 247 9 465 minecraft:brown_terracotta
setblock 247 6 504 minecraft:bone_block
fill 248 6 464 248 9 464 minecraft:brown_terracotta
setblock 248 6 503 minecraft:bone_block
fill 248 6 504 248 9 504 minecraft:brown_terracotta
setblock 249 6 502 minecraft:bone_block
fill 249 6 503 249 8 503 minecraft:brown_terracotta
setblock 251 6 465 minecraft:bone_block
setblock 252 6 464 minecraft:bone_block
fill 252 6 465 252 7 465 minecraft:brown_terracotta
setblock 252 6 504 minecraft:bone_block
fill 253 6 464 253 9 464 minecraft:brown_terracotta
fill 253 6 504 253 7 504 minecraft:brown_terracotta
setblock 256 6 504 minecraft:brown_terracotta
setblock 257 6 464 minecraft:bone_block
fill 258 6 464 258 9 464 minecraft:brown_terracotta
setblock 258 6 504 minecraft:brown_terracotta
fill 259 6 465 260 6 465 minecraft:brown_terracotta
setblock 261 6 465 minecraft:bone_block
setblock 261 6 504 minecraft:brown_terracotta
setblock 262 6 464 minecraft:bone_block
fill 262 6 465 262 8 466 minecraft:brown_terracotta
setblock 262 6 504 minecraft:bone_block
fill 263 6 464 263 9 464 minecraft:brown_terracotta
setblock 263 6 503 minecraft:bone_block
fill 263 6 504 263 9 504 minecraft:brown_terracotta
setblock 264 6 466 minecraft:brown_terracotta
fill 264 6 503 264 9 503 minecraft:brown_terracotta
setblock 265 6 466 minecraft:bone_block
fill 265 6 467 266 8 467 minecraft:brown_terracotta
setblock 266 6 465 minecraft:bone_block
fill 266 6 466 266 9 466 minecraft:brown_terracotta
fill 266 6 502 268 6 502 minecraft:brown_terracotta
setblock 267 6 464 minecraft:bone_block
fill 267 6 465 267 9 465 minecraft:brown_terracotta
setblock 267 6 504 minecraft:bone_block
fill 268 6 464 268 9 464 minecraft:brown_terracotta
setblock 268 6 467 minecraft:brown_terracotta
setblock 268 6 503 minecraft:bone_block
fill 268 6 504 268 9 504 minecraft:brown_terracotta
setblock 269 6 467 minecraft:bone_block
setblock 269 6 502 minecraft:bone_block
fill 269 6 503 269 9 503 minecraft:brown_terracotta
setblock 270 6 466 minecraft:bone_block
fill 270 6 467 270 7 467 minecraft:brown_terracotta
fill 270 6 502 270 7 502 minecraft:brown_terracotta
setblock 271 6 465 minecraft:bone_block
fill 271 6 466 271 9 466 minecraft:brown_terracotta
setblock 272 6 464 minecraft:bone_block
fill 272 6 465 272 9 465 minecraft:brown_terracotta
setblock 272 6 504 minecraft:bone_block
fill 273 6 464 273 9 464 minecraft:brown_terracotta
setblock 273 6 503 minecraft:bone_block
fill 273 6 504 273 9 504 minecraft:brown_terracotta
fill 274 6 503 274 8 503 minecraft:brown_terracotta
setblock 275 6 466 minecraft:bone_block
fill 275 6 467 275 7 467 minecraft:brown_terracotta
setblock 275 6 501 minecraft:bone_block
fill 275 6 502 275 7 502 minecraft:brown_terracotta
setblock 276 6 465 minecraft:bone_block
fill 276 6 466 276 9 466 minecraft:brown_terracotta
fill 276 6 468 276 7 468 minecraft:brown_terracotta
setblock 276 6 485 minecraft:bone_block
setblock 276 6 500 minecraft:bone_block
fill 276 6 501 276 9 501 minecraft:brown_terracotta
setblock 236 7 464 minecraft:bone_block
fill 236 7 465 236 8 465 minecraft:brown_terracotta
setblock 236 7 484 minecraft:bone_block
fill 236 7 485 236 10 485 minecraft:brown_terracotta
setblock 236 7 489 minecraft:bone_block
fill 236 7 490 236 10 490 minecraft:brown_terracotta
setblock 236 7 499 minecraft:bone_block
fill 236 7 500 236 8 500 minecraft:brown_terracotta
fill 236 7 502 236 7 503 minecraft:brown_terracotta
setblock 236 7 504 minecraft:bone_block
fill 237 7 464 240 7 464 minecraft:brown_terracotta
setblock 237 7 503 minecraft:bone_block
fill 237 7 504 237 10 504 minecraft:brown_terracotta
setblock 238 7 503 minecraft:brown_terracotta
setblock 241 7 464 minecraft:bone_block
setblock 241 7 504 minecraft:bone_block
fill 242 7 464 242 10 464 minecraft:brown_terracotta
setblock 242 7 503 minecraft:bone_block
fill 242 7 504 242 10 504 minecraft:brown_terracotta
fill 243 7 503 243 9 503 minecraft:brown_terracotta
setblock 244 7 502 minecraft:brown_terracotta
setblock 245 7 465 minecraft:bone_block
setblock 246 7 464 minecraft:bone_block
fill 246 7 465 246 10 465 minecraft:brown_terracotta
setblock 246 7 504 minecraft:bone_block
fill 247 7 464 247 10 464 minecraft:brown_terracotta
setblock 247 7 503 minecraft:bone_block
fill 247 7 504 247 10 504 minecraft:brown_terracotta
fill 248 7 503 248 8 503 minecraft:brown_terracotta
setblock 250 7 465 minecraft:bone_block
setblock 251 7 464 minecraft:bone_block
fill 251 7 465 251 8 465 minecraft:brown_terracotta
setblock 251 7 504 minecraft:bone_block
fill 252 7 464 252 10 464 minecraft:brown_terracotta
fill 252 7 504 252 8 504 minecraft:brown_terracotta
setblock 256 7 464 minecraft:bone_block
fill 257 7 464 257 10 464 minecraft:brown_terracotta
setblock 259 7 465 minecraft:brown_terracotta
setblock 260 7 465 minecraft:bone_block
setblock 261 7 464 minecraft:bone_block
fill 261 7 465 261 10 465 minecraft:brown_terracotta
setblock 261 7 504 minecraft:bone_block
fill 262 7 464 262 10 464 minecraft:brown_terracotta
fill 262 7 504 262 10 504 minecraft:brown_terracotta
fill 263 7 503 263 9 503 minecraft:brown_terracotta
setblock 264 7 466 minecraft:bone_block
setblock 265 7 465 minecraft:bone_block
fill 265 7 466 265 10 466 minecraft:brown_terracotta
setblock 266 7 464 minecraft:bone_block
fill 266 7 465 266 10 465 minecraft:brown_terracotta
fill 266 7 502 267 7 502 minecraft:brown_terracotta
setblock 266 7 504 minecraft:bone_block
fill 267 7 464 267 10 464 minecraft:brown_terracotta
setblock 267 7 503 minecraft:bone_block
fill 267 7 504 267 10 504 minecraft:brown_terracotta
setblock 268 7 467 minecraft:bone_block
setblock 268 7 502 minecraft:bone_block
fill 268 7 503 268 10 503 minecraft:brown_terracotta
setblock 269 7 466 minecraft:bone_block
fill 269 7 467 269 8 467 minecraft:brown_terracotta
setblock 269 7 502 minecraft:brown_terracotta
setblock 270 7 465 minecraft:bone_block
fill 270 7 466 270 10 466 minecraft:brown_terracotta
setblock 271 7 464 minecraft:bone_block
fill 271 7 465 271 10 465 minecraft:brown_terracotta
setblock 271 7 504 minecraft:bone_block
fill 272 7 464 272 10 464 minecraft:brown_terracotta
setblock 272 7 503 minecraft:bone_block
fill 272 7 504 272 10 504 minecraft:brown_terracotta
fill 273 7 503 273 9 503 minecraft:brown_terracotta
setblock 275 7 465 minecraft:bone_block
fill 275 7 466 275 8 466 minecraft:brown_terracotta
setblock 276 7 464 minecraft:bone_block
fill 276 7 465 276 10 465 minecraft:brown_terracotta
setblock 276 7 499 minecraft:bone_block
fill 276 7 500 276 8 500 minecraft:brown_terracotta
setblock 276 7 504 minecraft:bone_block
fill 236 8 464 239 8 464 minecraft:brown_terracotta
setblock 236 8 483 minecraft:bone_block
fill 236 8 484 236 10 484 minecraft:brown_terracotta
setblock 236 8 488 minecraft:bone_block
fill 236 8 489 236 11 489 minecraft:brown_terracotta
setblock 236 8 492 minecraft:brown_terracotta
setblock 236 8 499 minecraft:brown_terracotta
setblock 236 8 502 minecraft:brown_terracotta
setblock 236 8 503 minecraft:bone_block
fill 236 8 504 236 10 504 minecraft:brown_terracotta
setblock 237 8 487 minecraft:bone_block
setblock 238 8 466 minecraft:light[level=12]
setblock 238 8 474 minecraft:light[level=12]
setblock 238 8 482 minecraft:light[level=12]
setblock 238 8 490 minecraft:light[level=12]
setblock 238 8 498 minecraft:light[level=12]
setblock 240 8 464 minecraft:bone_block
setblock 240 8 504 minecraft:bone_block
fill 241 8 464 241 11 464 minecraft:brown_terracotta
setblock 241 8 503 minecraft:bone_block
fill 241 8 504 241 11 504 minecraft:brown_terracotta
fill 242 8 503 242 9 503 minecraft:brown_terracotta
setblock 244 8 464 minecraft:brown_terracotta
setblock 244 8 465 minecraft:bone_block
setblock 245 8 464 minecraft:bone_block
fill 245 8 465 245 11 465 minecraft:brown_terracotta
setblock 245 8 504 minecraft:bone_block
fill 246 8 464 246 11 464 minecraft:brown_terracotta
setblock 246 8 474 minecraft:light[level=12]
setblock 246 8 482 minecraft:light[level=12]
setblock 246 8 490 minecraft:light[level=12]
setblock 246 8 498 minecraft:light[level=12]
setblock 246 8 503 minecraft:bone_block
fill 246 8 504 246 11 504 minecraft:brown_terracotta
fill 247 8 503 247 9 503 minecraft:brown_terracotta
setblock 249 8 465 minecraft:bone_block
setblock 250 8 464 minecraft:bone_block
fill 250 8 465 250 9 465 minecraft:brown_terracotta
setblock 250 8 504 minecraft:bone_block
fill 251 8 464 251 11 464 minecraft:brown_terracotta
setblock 251 8 504 minecraft:brown_terracotta
setblock 254 8 466 minecraft:light[level=12]
setblock 254 8 474 minecraft:light[level=12]
setblock 254 8 482 minecraft:light[level=12]
setblock 254 8 490 minecraft:light[level=12]
setblock 254 8 498 minecraft:light[level=12]
setblock 255 8 464 minecraft:bone_block
fill 256 8 464 256 11 464 minecraft:brown_terracotta
setblock 258 8 465 minecraft:brown_terracotta
setblock 259 8 465 minecraft:bone_block
setblock 260 8 464 minecraft:bone_block
fill 260 8 465 260 11 465 minecraft:brown_terracotta
setblock 260 8 504 minecraft:bone_block
fill 261 8 464 261 11 464 minecraft:brown_terracotta
fill 261 8 466 261 9 466 minecraft:brown_terracotta
fill 261 8 504 261 11 504 minecraft:brown_terracotta
setblock 262 8 474 minecraft:light[level=12]
setblock 262 8 482 minecraft:light[level=12]
setblock 262 8 490 minecraft:light[level=12]
setblock 262 8 498 minecraft:light[level=12]
setblock 263 8 465 minecraft:brown_terracotta
setblock 263 8 466 minecraft:bone_block
setblock 264 8 465 minecraft:bone_block
fill 264 8 466 264 10 467 minecraft:brown_terracotta
setblock 265 8 464 minecraft:bone_block
fill 265 8 465 265 11 465 minecraft:brown_terracotta
setblock 265 8 504 minecraft:bone_block
fill 266 8 464 266 11 464 minecraft:brown_terracotta
setblock 266 8 503 minecraft:bone_block
fill 266 8 504 266 11 504 minecraft:brown_terracotta
setblock 267 8 466 minecraft:brown_terracotta
setblock 267 8 467 minecraft:bone_block
fill 267 8 503 267 11 503 minecraft:brown_terracotta
setblock 268 8 466 minecraft:bone_block
fill 268 8 467 268 10 467 minecraft:brown_terracotta
setblock 269 8 465 minecraft:bone_block
fill 269 8 466 269 11 466 minecraft:brown_terracotta
setblock 270 8 464 minecraft:bone_block
fill 270 8 465 270 11 465 minecraft:brown_terracotta
setblock 270 8 474 minecraft:light[level=12]
setblock 270 8 482 minecraft:light[level=12]
setblock 270 8 490 minecraft:light[level=12]
setblock 270 8 498 minecraft:light[level=12]
setblock 270 8 504 minecraft:bone_block
fill 271 8 464 271 11 464 minecraft:brown_terracotta
setblock 271 8 503 minecraft:bone_block
fill 271 8 504 271 11 504 minecraft:brown_terracotta
fill 272 8 503 272 9 503 minecraft:brown_terracotta
setblock 274 8 465 minecraft:bone_block
setblock 275 8 464 minecraft:bone_block
fill 275 8 465 275 9 465 minecraft:brown_terracotta
setblock 275 8 504 minecraft:bone_block
fill 276 8 464 276 11 464 minecraft:brown_terracotta
setblock 276 8 468 minecraft:bone_block
setblock 276 8 503 minecraft:bone_block
fill 276 8 504 276 11 504 minecraft:brown_terracotta
fill 236 9 464 238 9 464 minecraft:brown_terracotta
setblock 236 9 487 minecraft:bone_block
fill 236 9 488 237 11 488 minecraft:brown_terracotta
setblock 236 9 492 minecraft:bone_block
setblock 236 9 502 minecraft:bone_block
fill 236 9 503 236 10 503 minecraft:brown_terracotta
fill 237 9 487 237 12 487 minecraft:brown_terracotta
setblock 239 9 464 minecraft:bone_block
setblock 239 9 504 minecraft:bone_block
fill 240 9 464 240 12 464 minecraft:brown_terracotta
fill 240 9 504 240 12 504 minecraft:brown_terracotta
setblock 241 9 503 minecraft:brown_terracotta
setblock 243 9 464 minecraft:brown_terracotta
setblock 243 9 465 minecraft:bone_block
setblock 244 9 464 minecraft:bone_block
fill 244 9 465 244 12 465 minecraft:brown_terracotta
setblock 244 9 504 minecraft:bone_block
fill 245 9 464 245 12 464 minecraft:brown_terracotta
setblock 245 9 503 minecraft:bone_block
fill 245 9 504 245 12 504 minecraft:brown_terracotta
setblock 246 9 503 minecraft:brown_terracotta
setblock 248 9 465 minecraft:bone_block
setblock 249 9 464 minecraft:bone_block
fill 249 9 465 249 10 465 minecraft:brown_terracotta
setblock 249 9 504 minecraft:bone_block
fill 250 9 464 250 11 464 minecraft:brown_terracotta
setblock 250 9 504 minecraft:brown_terracotta
setblock 254 9 464 minecraft:bone_block
fill 255 9 464 255 10 464 minecraft:brown_terracotta
setblock 258 9 465 minecraft:bone_block
setblock 259 9 464 minecraft:bone_block
fill 259 9 465 259 12 465 minecraft:brown_terracotta
fill 260 9 464 260 12 464 minecraft:brown_terracotta
setblock 260 9 504 minecraft:brown_terracotta
setblock 262 9 465 minecraft:brown_terracotta
setblock 262 9 466 minecraft:bone_block
setblock 263 9 465 minecraft:bone_block
fill 263 9 466 263 12 466 minecraft:brown_terracotta
setblock 264 9 464 minecraft:bone_block
fill 264 9 465 264 12 465 minecraft:brown_terracotta
setblock 264 9 504 minecraft:bone_block
fill 265 9 464 265 12 464 minecraft:brown_terracotta
setblock 265 9 467 minecraft:brown_terracotta
setblock 265 9 503 minecraft:bone_block
fill 265 9 504 265 12 504 minecraft:brown_terracotta
setblock 266 9 467 minecraft:bone_block
fill 266 9 503 266 11 503 minecraft:brown_terracotta
setblock 267 9 466 minecraft:bone_block
fill 267 9 467 267 11 467 minecraft:brown_terracotta
setblock 268 9 465 minecraft:bone_block
fill 268 9 466 268 12 466 minecraft:brown_terracotta
setblock 269 9 464 minecraft:bone_block
fill 269 9 465 269 12 465 minecraft:brown_terracotta
setblock 269 9 504 minecraft:bone_block
fill 270 9 464 270 12 464 minecraft:brown_terracotta
setblock 270 9 503 minecraft:bone_block
fill 270 9 504 270 12 504 minecraft:brown_terracotta
setblock 271 9 503 minecraft:brown_terracotta
setblock 272 9 466 minecraft:bone_block
setblock 273 9 465 minecraft:bone_block
setblock 274 9 464 minecraft:bone_block
fill 274 9 465 274 10 465 minecraft:brown_terracotta
setblock 274 9 504 minecraft:bone_block
fill 275 9 464 275 12 464 minecraft:brown_terracotta
fill 275 9 504 275 11 504 minecraft:brown_terracotta
setblock 276 9 467 minecraft:bone_block
setblock 276 9 468 minecraft:brown_terracotta
setblock 276 9 502 minecraft:bone_block
fill 276 9 503 276 11 503 minecraft:brown_terracotta
setblock 236 10 486 minecraft:bone_block
fill 236 10 487 236 13 487 minecraft:brown_terracotta
setblock 236 10 491 minecraft:bone_block
fill 236 10 492 236 13 492 minecraft:brown_terracotta
setblock 237 10 489 minecraft:brown_terracotta
setblock 238 10 504 minecraft:bone_block
fill 239 10 464 239 11 464 minecraft:brown_terracotta
fill 239 10 504 239 11 504 minecraft:brown_terracotta
setblock 243 10 464 minecraft:bone_block
fill 243 10 465 243 12 465 minecraft:brown_terracotta
setblock 243 10 504 minecraft:bone_block
fill 244 10 464 244 13 464 minecraft:brown_terracotta
setblock 244 10 503 minecraft:bone_block
fill 244 10 504 244 13 504 minecraft:brown_terracotta
setblock 247 10 465 minecraft:bone_block
setblock 248 10 464 minecraft:bone_block
setblock 248 10 465 minecraft:brown_terracotta
setblock 248 10 504 minecraft:bone_block
fill 249 10 464 249 12 464 minecraft:brown_terracotta
setblock 249 10 504 minecraft:brown_terracotta
setblock 253 10 464 minecraft:bone_block
setblock 254 10 464 minecraft:brown_terracotta
setblock 258 10 464 minecraft:bone_block
fill 258 10 465 258 13 465 minecraft:brown_terracotta
fill 259 10 464 259 13 464 minecraft:brown_terracotta
setblock 260 10 466 minecraft:brown_terracotta
setblock 261 10 466 minecraft:bone_block
setblock 262 10 465 minecraft:bone_block
fill 262 10 466 262 13 466 minecraft:brown_terracotta
setblock 263 10 464 minecraft:bone_block
fill 263 10 465 263 13 465 minecraft:brown_terracotta
fill 263 10 467 263 11 467 minecraft:brown_terracotta
setblock 263 10 504 minecraft:bone_block
fill 264 10 464 264 13 464 minecraft:brown_terracotta
setblock 264 10 503 minecraft:bone_block
fill 264 10 504 264 13 504 minecraft:brown_terracotta
setblock 265 10 467 minecraft:bone_block
fill 265 10 503 265 11 503 minecraft:brown_terracotta
setblock 266 10 466 minecraft:bone_block
fill 266 10 467 266 13 467 minecraft:brown_terracotta
setblock 267 10 465 minecraft:bone_block
fill 267 10 466 267 13 466 minecraft:brown_terracotta
setblock 268 10 464 minecraft:bone_block
fill 268 10 465 268 13 465 minecraft:brown_terracotta
setblock 268 10 504 minecraft:bone_block
fill 269 10 464 269 13 464 minecraft:brown_terracotta
setblock 269 10 503 minecraft:bone_block
fill 269 10 504 269 13 504 minecraft:brown_terracotta
setblock 270 10 503 minecraft:brown_terracotta
setblock 271 10 466 minecraft:bone_block
setblock 272 10 465 minecraft:bone_block
setblock 273 10 464 minecraft:bone_block
fill 273 10 465 273 11 465 minecraft:brown_terracotta
setblock 273 10 504 minecraft:bone_block
fill 274 10 464 274 13 464 minecraft:brown_terracotta
fill 274 10 504 274 11 504 minecraft:brown_terracotta
setblock 276 10 466 minecraft:bone_block
fill 276 10 467 276 13 467 minecraft:brown_terracotta
setblock 236 11 485 minecraft:bone_block
fill 236 11 486 236 14 486 minecraft:brown_terracotta
setblock 236 11 490 minecraft:bone_block
fill 236 11 491 236 14 491 minecraft:brown_terracotta
fill 236 11 493 236 12 493 minecraft:brown_terracotta
setblock 237 11 489 minecraft:bone_block
fill 237 11 490 237 14 490 minecraft:brown_terracotta
setblock 238 11 504 minecraft:brown_terracotta
setblock 242 11 464 minecraft:bone_block
setblock 242 11 504 minecraft:bone_block
fill 243 11 464 243 14 464 minecraft:brown_terracotta
fill 243 11 504 243 14 504 minecraft:brown_terracotta
setblock 246 11 465 minecraft:bone_block
setblock 247 11 464 minecraft:bone_block
setblock 247 11 465 minecraft:brown_terracotta
setblock 247 11 504 minecraft:bone_block
fill 248 11 464 248 13 464 minecraft:brown_terracotta
fill 252 11 496 258 29 500 minecraft:bone_block
fill 253 11 495 257 29 495 minecraft:bone_block
fill 253 11 501 257 29 501 minecraft:bone_block
setblock 257 11 464 minecraft:bone_block
fill 258 11 464 258 14 464 minecraft:brown_terracotta
setblock 260 11 466 minecraft:bone_block
setblock 261 11 465 minecraft:bone_block
fill 261 11 466 261 14 466 minecraft:brown_terracotta
setblock 262 11 464 minecraft:bone_block
fill 262 11 465 262 14 465 minecraft:brown_terracotta
setblock 262 11 504 minecraft:bone_block
fill 263 11 464 263 14 464 minecraft:brown_terracotta
fill 263 11 504 263 14 504 minecraft:brown_terracotta
setblock 264 11 466 minecraft:brown_terracotta
setblock 264 11 467 minecraft:bone_block
setblock 265 11 466 minecraft:bone_block
fill 265 11 467 265 14 467 minecraft:brown_terracotta
setblock 266 11 465 minecraft:bone_block
fill 266 11 466 266 14 466 minecraft:brown_terracotta
setblock 267 11 464 minecraft:bone_block
fill 267 11 465 267 14 465 minecraft:brown_terracotta
setblock 267 11 504 minecraft:bone_block
fill 268 11 464 268 14 464 minecraft:brown_terracotta
setblock 268 11 503 minecraft:bone_block
fill 268 11 504 268 14 504 minecraft:brown_terracotta
setblock 270 11 466 minecraft:bone_block
setblock 271 11 465 minecraft:bone_block
setblock 272 11 464 minecraft:bone_block
fill 272 11 465 272 12 465 minecraft:brown_terracotta
setblock 272 11 504 minecraft:bone_block
fill 273 11 464 273 14 464 minecraft:brown_terracotta
fill 273 11 504 273 12 504 minecraft:brown_terracotta
setblock 276 11 465 minecraft:bone_block
fill 276 11 466 276 14 466 minecraft:brown_terracotta
fill 236 12 485 236 15 485 minecraft:brown_terracotta
setblock 236 12 488 minecraft:brown_terracotta
setblock 236 12 489 minecraft:bone_block
fill 236 12 490 236 15 490 minecraft:brown_terracotta
setblock 236 12 494 minecraft:bone_block
setblock 237 12 488 minecraft:bone_block
fill 237 12 489 237 15 489 minecraft:brown_terracotta
fill 237 12 491 237 13 491 minecraft:brown_terracotta
setblock 241 12 464 minecraft:bone_block
setblock 241 12 504 minecraft:bone_block
fill 242 12 464 242 15 464 minecraft:brown_terracotta
fill 242 12 504 242 15 504 minecraft:brown_terracotta
setblock 245 12 465 minecraft:bone_block
fill 245 12 466 245 15 466 minecraft:soul_soil
setblock 246 12 464 minecraft:bone_block
setblock 246 12 465 minecraft:brown_terracotta
fill 246 12 467 246 15 467 minecraft:soul_soil
fill 247 12 464 247 15 464 minecraft:brown_terracotta
fill 247 12 466 247 15 466 minecraft:soul_soil
fill 250 12 497 251 28 499 minecraft:bone_block
fill 251 12 495 251 28 496 minecraft:bone_block
fill 251 12 500 251 28 501 minecraft:bone_block
fill 252 12 494 252 28 495 minecraft:bone_block
fill 252 12 501 252 28 502 minecraft:bone_block
fill 253 12 494 258 28 494 minecraft:bone_block
fill 253 12 502 258 26 502 minecraft:bone_block
fill 254 12 493 256 28 493 minecraft:bone_block
fill 254 12 503 256 23 503 minecraft:bone_block
setblock 256 12 464 minecraft:bone_block
fill 257 12 464 257 15 464 minecraft:brown_terracotta
fill 258 12 495 259 28 495 minecraft:bone_block
fill 258 12 501 259 28 501 minecraft:bone_block
fill 259 12 496 259 28 500 minecraft:bone_block
setblock 260 12 465 minecraft:bone_block
fill 260 12 466 260 15 466 minecraft:brown_terracotta
fill 260 12 497 260 28 499 minecraft:bone_block
setblock 261 12 464 minecraft:bone_block
fill 261 12 465 261 15 465 minecraft:brown_terracotta
setblock 261 12 504 minecraft:bone_block
fill 262 12 464 262 15 464 minecraft:brown_terracotta
setblock 262 12 467 minecraft:brown_terracotta
fill 262 12 504 262 15 504 minecraft:brown_terracotta
setblock 263 12 467 minecraft:bone_block
setblock 264 12 466 minecraft:bone_block
fill 264 12 467 264 15 467 minecraft:brown_terracotta
setblock 265 12 465 minecraft:bone_block
fill 265 12 466 265 15 466 minecraft:brown_terracotta
setblock 266 12 464 minecraft:bone_block
fill 266 12 465 266 15 465 minecraft:brown_terracotta
setblock 266 12 504 minecraft:bone_block
fill 267 12 464 267 15 464 minecraft:brown_terracotta
fill 267 12 504 267 15 504 minecraft:brown_terracotta
setblock 269 12 466 minecraft:bone_block
setblock 270 12 465 minecraft:bone_block
setblock 271 12 464 minecraft:bone_block
fill 271 12 465 271 13 465 minecraft:brown_terracotta
setblock 271 12 504 minecraft:bone_block
fill 272 12 464 272 15 464 minecraft:brown_terracotta
setblock 272 12 504 minecraft:brown_terracotta
setblock 276 12 464 minecraft:bone_block
fill 276 12 465 276 15 465 minecraft:brown_terracotta
setblock 276 12 504 minecraft:bone_block
setblock 236 13 488 minecraft:bone_block
fill 236 13 489 236 16 489 minecraft:brown_terracotta
setblock 236 13 493 minecraft:bone_block
fill 236 13 494 236 15 495 minecraft:brown_terracotta
setblock 237 13 486 minecraft:brown_terracotta
setblock 237 13 487 minecraft:bone_block
fill 237 13 488 237 16 488 minecraft:brown_terracotta
setblock 237 13 492 minecraft:bone_block
fill 237 13 493 237 16 493 minecraft:brown_terracotta
fill 238 13 489 238 13 490 minecraft:brown_terracotta
setblock 240 13 464 minecraft:bone_block
setblock 240 13 504 minecraft:bone_block
fill 241 13 464 241 16 464 minecraft:brown_terracotta
fill 241 13 504 241 16 504 minecraft:brown_terracotta
fill 242 13 471 243 14 471 minecraft:soul_soil
setblock 244 13 465 minecraft:bone_block
setblock 245 13 464 minecraft:bone_block
fill 246 13 464 246 16 464 minecraft:brown_terracotta
fill 246 13 465 246 15 465 minecraft:soul_soil
fill 249 13 496 249 27 500 minecraft:bone_block
fill 250 13 495 250 27 496 minecraft:bone_block
fill 250 13 500 250 27 501 minecraft:bone_block
fill 251 13 494 251 27 494 minecraft:bone_block
fill 251 13 502 251 27 502 minecraft:bone_block
fill 252 13 493 253 27 493 minecraft:bone_block
fill 252 13 503 253 26 503 minecraft:bone_block
fill 253 13 492 257 27 492 minecraft:bone_block
fill 253 13 504 257 17 504 minecraft:bone_block
fill 256 13 464 256 16 464 minecraft:brown_terracotta
fill 256 13 466 258 14 470 minecraft:soul_soil
fill 257 13 493 258 27 493 minecraft:bone_block
fill 257 13 503 258 19 503 minecraft:bone_block
setblock 259 13 465 minecraft:bone_block
fill 259 13 466 259 16 466 minecraft:brown_terracotta
fill 259 13 467 260 14 470 minecraft:soul_soil
fill 259 13 494 259 27 494 minecraft:bone_block
fill 259 13 502 259 26 502 minecraft:bone_block
setblock 260 13 464 minecraft:bone_block
fill 260 13 465 260 16 465 minecraft:brown_terracotta
fill 260 13 495 260 27 496 minecraft:bone_block
fill 260 13 500 260 27 501 minecraft:bone_block
fill 261 13 464 261 16 464 minecraft:brown_terracotta
fill 261 13 496 261 27 500 minecraft:bone_block
fill 261 13 504 261 16 504 minecraft:brown_terracotta
setblock 262 13 467 minecraft:bone_block
setblock 263 13 466 minecraft:bone_block
fill 263 13 467 263 16 467 minecraft:brown_terracotta
setblock 264 13 465 minecraft:bone_block
fill 264 13 466 264 16 466 minecraft:brown_terracotta
setblock 265 13 464 minecraft:bone_block
fill 265 13 465 265 16 465 minecraft:brown_terracotta
setblock 265 13 504 minecraft:bone_block
fill 266 13 464 266 16 464 minecraft:brown_terracotta
fill 266 13 504 266 16 504 minecraft:brown_terracotta
setblock 268 13 466 minecraft:bone_block
setblock 269 13 465 minecraft:bone_block
setblock 270 13 464 minecraft:bone_block
fill 270 13 465 270 14 465 minecraft:brown_terracotta
setblock 270 13 504 minecraft:bone_block
fill 271 13 464 271 16 464 minecraft:brown_terracotta
setblock 271 13 504 minecraft:brown_terracotta
setblock 275 13 464 minecraft:bone_block
fill 276 13 464 276 16 464 minecraft:brown_terracotta
setblock 276 13 468 minecraft:bone_block
fill 276 13 489 276 13 492 minecraft:brown_terracotta
setblock 236 14 487 minecraft:bone_block
fill 236 14 488 236 17 488 minecraft:brown_terracotta
setblock 236 14 492 minecraft:bone_block
fill 236 14 493 236 17 493 minecraft:brown_terracotta
setblock 236 14 496 minecraft:brown_terracotta
setblock 237 14 486 minecraft:bone_block
fill 237 14 487 237 17 487 minecraft:brown_terracotta
setblock 237 14 491 minecraft:bone_block
fill 237 14 492 238 16 492 minecraft:brown_terracotta
fill 237 14 494 237 15 494 minecraft:brown_terracotta
fill 238 14 488 238 14 489 minecraft:brown_terracotta
setblock 238 14 490 minecraft:bone_block
fill 238 14 491 238 17 491 minecraft:brown_terracotta
fill 240 14 464 240 17 464 minecraft:brown_terracotta
setblock 243 14 465 minecraft:bone_block
setblock 244 14 464 minecraft:bone_block
fill 245 14 464 245 17 464 minecraft:brown_terracotta
fill 248 14 497 248 26 499 minecraft:bone_block
fill 249 14 495 249 26 495 minecraft:bone_block
fill 249 14 501 249 26 501 minecraft:bone_block
fill 250 14 493 250 26 494 minecraft:bone_block
fill 250 14 502 250 26 503 minecraft:bone_block
fill 251 14 493 251 26 493 minecraft:bone_block
fill 251 14 503 251 26 503 minecraft:bone_block
fill 252 14 492 252 26 492 minecraft:bone_block
fill 252 14 504 252 26 504 minecraft:bone_block
fill 254 14 491 256 26 491 minecraft:bone_block
setblock 257 14 465 minecraft:brown_terracotta
setblock 258 14 465 minecraft:bone_block
fill 258 14 492 258 26 492 minecraft:bone_block
fill 258 14 504 258 16 504 minecraft:bone_block
setblock 259 14 464 minecraft:bone_block
fill 259 14 465 259 17 465 minecraft:brown_terracotta
fill 259 14 493 260 26 493 minecraft:bone_block
fill 259 14 503 260 18 503 minecraft:bone_block
fill 260 14 464 260 17 464 minecraft:brown_terracotta
fill 260 14 494 260 26 494 minecraft:bone_block
fill 260 14 502 260 26 502 minecraft:bone_block
fill 260 14 504 260 17 504 minecraft:brown_terracotta
setblock 261 14 467 minecraft:bone_block
fill 261 14 495 261 26 495 minecraft:bone_block
fill 261 14 501 261 26 501 minecraft:bone_block
setblock 262 14 466 minecraft:bone_block
fill 262 14 467 262 17 467 minecraft:brown_terracotta
fill 262 14 497 262 26 499 minecraft:bone_block
setblock 263 14 465 minecraft:bone_block
fill 263 14 466 263 17 466 minecraft:brown_terracotta
setblock 264 14 464 minecraft:bone_block
fill 264 14 465 264 17 465 minecraft:brown_terracotta
setblock 264 14 504 minecraft:bone_block
fill 265 14 464 265 17 464 minecraft:brown_terracotta
fill 265 14 504 265 17 504 minecraft:brown_terracotta
setblock 267 14 466 minecraft:bone_block
setblock 268 14 465 minecraft:bone_block
setblock 268 14 466 minecraft:brown_terracotta
setblock 269 14 464 minecraft:bone_block
fill 269 14 465 269 16 465 minecraft:brown_terracotta
setblock 269 14 504 minecraft:bone_block
fill 270 14 464 270 17 464 minecraft:brown_terracotta
setblock 270 14 504 minecraft:brown_terracotta
setblock 274 14 464 minecraft:bone_block
fill 275 14 464 275 17 464 minecraft:brown_terracotta
setblock 276 14 467 minecraft:bone_block
fill 276 14 468 276 17 468 minecraft:brown_terracotta
fill 276 14 488 276 14 491 minecraft:brown_terracotta
setblock 276 14 492 minecraft:bone_block
fill 276 14 493 276 15 495 minecraft:brown_terracotta
fill 236 15 484 236 16 484 minecraft:brown_terracotta
setblock 236 15 486 minecraft:bone_block
fill 236 15 487 236 18 487 minecraft:brown_terracotta
setblock 236 15 491 minecraft:bone_block
fill 236 15 492 236 18 492 minecraft:brown_terracotta
setblock 236 15 496 minecraft:bone_block
fill 236 15 497 236 17 498 minecraft:brown_terracotta
setblock 237 15 485 minecraft:bone_block
fill 237 15 486 237 18 486 minecraft:brown_terracotta
setblock 237 15 490 minecraft:bone_block
fill 237 15 491 237 18 491 minecraft:brown_terracotta
setblock 237 15 495 minecraft:bone_block
fill 237 15 496 237 18 496 minecraft:brown_terracotta
fill 238 15 487 238 15 488 minecraft:brown_terracotta
setblock 238 15 489 minecraft:bone_block
fill 238 15 490 239 17 490 minecraft:brown_terracotta
setblock 238 15 493 minecraft:brown_terracotta
setblock 238 15 494 minecraft:bone_block
fill 239 15 464 239 18 464 minecraft:brown_terracotta
fill 239 15 489 239 18 489 minecraft:brown_terracotta
fill 239 15 491 239 16 491 minecraft:brown_terracotta
fill 240 15 504 240 17 504 minecraft:brown_terracotta
setblock 243 15 464 minecraft:bone_block
fill 243 15 465 243 17 465 minecraft:brown_terracotta
fill 244 15 464 244 18 464 minecraft:brown_terracotta
setblock 245 15 465 minecraft:soul_soil
setblock 245 15 467 minecraft:soul_soil
setblock 247 15 465 minecraft:soul_soil
setblock 247 15 467 minecraft:soul_soil
fill 248 15 495 248 25 496 minecraft:bone_block
fill 248 15 500 248 25 501 minecraft:bone_block
fill 249 15 494 249 25 494 minecraft:bone_block
fill 249 15 502 249 25 502 minecraft:bone_block
fill 251 15 492 251 25 492 minecraft:bone_block
fill 251 15 504 251 25 504 minecraft:bone_block
fill 252 15 491 253 25 491 minecraft:bone_block
fill 254 15 467 256 16 467 minecraft:bone_block
fill 254 15 469 256 16 469 minecraft:bone_block
fill 255 15 464 255 17 464 minecraft:brown_terracotta
fill 255 15 468 255 16 468 minecraft:bone_block
setblock 256 15 465 minecraft:brown_terracotta
setblock 257 15 465 minecraft:bone_block
fill 257 15 491 258 25 491 minecraft:bone_block
setblock 258 15 464 minecraft:bone_block
fill 258 15 465 258 17 466 minecraft:brown_terracotta
fill 259 15 464 259 18 464 minecraft:brown_terracotta
fill 259 15 492 259 25 492 minecraft:bone_block
setblock 259 15 504 minecraft:bone_block
setblock 260 15 467 minecraft:bone_block
setblock 261 15 466 minecraft:bone_block
fill 261 15 467 261 18 467 minecraft:brown_terracotta
fill 261 15 494 261 25 494 minecraft:bone_block
fill 261 15 502 261 25 502 minecraft:bone_block
setblock 262 15 465 minecraft:bone_block
fill 262 15 466 262 18 466 minecraft:brown_terracotta
fill 262 15 495 262 25 496 minecraft:bone_block
fill 262 15 500 262 25 501 minecraft:bone_block
setblock 263 15 464 minecraft:bone_block
fill 263 15 465 263 18 465 minecraft:brown_terracotta
setblock 263 15 504 minecraft:bone_block
fill 264 15 464 264 18 464 minecraft:brown_terracotta
fill 264 15 504 264 18 504 minecraft:brown_terracotta
setblock 265 15 467 minecraft:bone_block
setblock 266 15 466 minecraft:bone_block
setblock 267 15 465 minecraft:bone_block
fill 267 15 466 267 16 466 minecraft:brown_terracotta
setblock 268 15 464 minecraft:bone_block
fill 268 15 465 268 18 465 minecraft:brown_terracotta
setblock 268 15 504 minecraft:bone_block
fill 269 15 464 269 18 464 minecraft:brown_terracotta
fill 269 15 504 269 18 504 minecraft:brown_terracotta
setblock 273 15 464 minecraft:bone_block
fill 274 15 464 274 18 464 minecraft:brown_terracotta
setblock 276 15 466 minecraft:bone_block
fill 276 15 467 276 18 467 minecraft:brown_terracotta
fill 276 15 469 276 15 470 minecraft:brown_terracotta
fill 276 15 487 276 15 490 minecraft:brown_terracotta
setblock 276 15 491 minecraft:bone_block
fill 276 15 492 276 18 492 minecraft:brown_terracotta
setblock 276 15 496 minecraft:bone_block
fill 276 15 497 276 17 498 minecraft:brown_terracotta
fill 276 15 504 276 16 504 minecraft:brown_terracotta
fill 236 16 467 236 16 469 minecraft:brown_terracotta
setblock 236 16 470 minecraft:bone_block
fill 236 16 471 236 18 472 minecraft:brown_terracotta
fill 236 16 483 236 17 483 minecraft:brown_terracotta
setblock 236 16 485 minecraft:bone_block
fill 236 16 486 236 19 486 minecraft:brown_terracotta
setblock 236 16 490 minecraft:bone_block
fill 236 16 491 236 19 491 minecraft:brown_terracotta
setblock 236 16 494 minecraft:brown_terracotta
setblock 236 16 495 minecraft:bone_block
fill 236 16 496 236 19 496 minecraft:brown_terracotta
setblock 236 16 499 minecraft:brown_terracotta
fill 237 16 485 237 19 485 minecraft:brown_terracotta
setblock 237 16 489 minecraft:bone_block
fill 237 16 490 237 19 490 minecraft:brown_terracotta
setblock 237 16 494 minecraft:bone_block
fill 237 16 495 238 18 495 minecraft:brown_terracotta
fill 237 16 497 237 17 497 minecraft:brown_terracotta
setblock 238 16 466 minecraft:light[level=12]
setblock 238 16 474 minecraft:light[level=12]
setblock 238 16 482 minecraft:light[level=12]
fill 238 16 486 238 16 487 minecraft:brown_terracotta
setblock 238 16 488 minecraft:bone_block
fill 238 16 489 238 19 489 minecraft:brown_terracotta
setblock 238 16 493 minecraft:bone_block
fill 238 16 494 238 19 494 minecraft:brown_terracotta
setblock 238 16 498 minecraft:light[level=12]
fill 239 16 488 239 19 488 minecraft:brown_terracotta
setblock 239 16 492 minecraft:bone_block
fill 239 16 493 239 19 493 minecraft:brown_terracotta
fill 239 16 504 239 18 504 minecraft:brown_terracotta
setblock 242 16 464 minecraft:bone_block
fill 242 16 465 242 18 465 minecraft:brown_terracotta
setblock 242 16 504 minecraft:bone_block
fill 243 16 464 243 19 464 minecraft:brown_terracotta
setblock 246 16 466 minecraft:light[level=12]
setblock 246 16 474 minecraft:light[level=12]
setblock 246 16 482 minecraft:light[level=12]
setblock 246 16 490 minecraft:light[level=12]
setblock 246 16 498 minecraft:light[level=12]
fill 247 16 497 247 24 499 minecraft:bone_block
fill 248 16 494 248 24 494 minecraft:bone_block
fill 248 16 502 248 24 502 minecraft:bone_block
fill 249 16 493 249 24 493 minecraft:bone_block
fill 249 16 503 249 24 503 minecraft:bone_block
fill 250 16 492 250 24 492 minecraft:bone_block
fill 250 16 504 250 24 504 minecraft:bone_block
fill 251 16 491 251 24 491 minecraft:bone_block
setblock 253 16 490 minecraft:soul_soil
fill 254 16 464 254 18 464 minecraft:brown_terracotta
setblock 254 16 466 minecraft:light[level=12]
setblock 254 16 474 minecraft:light[level=12]
setblock 254 16 482 minecraft:light[level=12]
fill 254 16 490 256 24 490 minecraft:bone_block
setblock 256 16 465 minecraft:bone_block
fill 256 16 468 257 17 468 minecraft:bone_block
setblock 257 16 464 minecraft:bone_block
fill 257 16 465 257 18 466 minecraft:brown_terracotta
fill 257 16 490 258 16 490 minecraft:soul_soil
fill 258 16 464 258 19 464 minecraft:brown_terracotta
setblock 259 16 467 minecraft:bone_block
fill 259 16 491 259 24 491 minecraft:bone_block
fill 259 16 504 259 18 504 minecraft:brown_terracotta
setblock 260 16 466 minecraft:bone_block
fill 260 16 467 260 19 467 minecraft:brown_terracotta
fill 260 16 492 260 24 492 minecraft:bone_block
setblock 261 16 465 minecraft:bone_block
fill 261 16 466 261 19 466 minecraft:brown_terracotta
fill 261 16 493 261 24 493 minecraft:bone_block
fill 261 16 503 261 18 503 minecraft:bone_block
setblock 262 16 464 minecraft:bone_block
fill 262 16 465 262 19 465 minecraft:brown_terracotta
setblock 262 16 474 minecraft:light[level=12]
setblock 262 16 482 minecraft:light[level=12]
setblock 262 16 490 minecraft:light[level=12]
fill 262 16 494 262 24 494 minecraft:bone_block
fill 262 16 502 262 24 502 minecraft:bone_block
setblock 262 16 504 minecraft:bone_block
fill 263 16 464 263 19 464 minecraft:brown_terracotta
fill 263 16 497 263 24 499 minecraft:bone_block
fill 263 16 504 263 19 504 minecraft:brown_terracotta
setblock 264 16 467 minecraft:bone_block
setblock 265 16 466 minecraft:bone_block
setblock 265 16 467 minecraft:brown_terracotta
setblock 266 16 465 minecraft:bone_block
fill 266 16 466 266 18 466 minecraft:brown_terracotta
setblock 267 16 464 minecraft:bone_block
fill 267 16 465 267 19 465 minecraft:brown_terracotta
setblock 267 16 504 minecraft:bone_block
fill 268 16 464 268 19 464 minecraft:brown_terracotta
fill 268 16 504 268 19 504 minecraft:brown_terracotta
setblock 270 16 466 minecraft:light[level=12]
setblock 270 16 474 minecraft:light[level=12]
setblock 270 16 482 minecraft:light[level=12]
setblock 270 16 490 minecraft:light[level=12]
setblock 270 16 498 minecraft:light[level=12]
setblock 272 16 464 minecraft:bone_block
setblock 273 16 464 minecraft:brown_terracotta
setblock 275 16 490 minecraft:brown_terracotta
setblock 275 16 491 minecraft:bone_block
fill 275 16 492 275 16 495 minecraft:brown_terracotta
fill 275 16 504 275 17 504 minecraft:brown_terracotta
setblock 276 16 465 minecraft:bone_block
fill 276 16 466 276 19 466 minecraft:brown_terracotta
setblock 276 16 469 minecraft:brown_terracotta
setblock 276 16 470 minecraft:bone_block
fill 276 16 471 276 18 472 minecraft:brown_terracotta
fill 276 16 487 276 16 489 minecraft:brown_terracotta
setblock 276 16 490 minecraft:bone_block
fill 276 16 491 276 19 491 minecraft:brown_terracotta
fill 276 16 493 276 16 494 minecraft:brown_terracotta
setblock 276 16 495 minecraft:bone_block
fill 276 16 496 276 19 496 minecraft:brown_terracotta
setblock 276 16 499 minecraft:brown_terracotta
setblock 276 16 500 minecraft:bone_block
fill 276 16 501 276 17 503 minecraft:brown_terracotta
fill 236 17 466 236 17 468 minecraft:brown_terracotta
setblock 236 17 469 minecraft:bone_block
fill 236 17 470 237 19 470 minecraft:brown_terracotta
setblock 236 17 473 minecraft:brown_terracotta
setblock 236 17 474 minecraft:bone_block
fill 236 17 475 236 19 476 minecraft:brown_terracotta
fill 236 17 482 236 18 482 minecraft:brown_terracotta
setblock 236 17 484 minecraft:bone_block
fill 236 17 485 236 20 485 minecraft:brown_terracotta
setblock 236 17 489 minecraft:bone_block
fill 236 17 490 236 20 490 minecraft:brown_terracotta
setblock 236 17 494 minecraft:bone_block
fill 236 17 495 236 20 495 minecraft:brown_terracotta
setblock 236 17 499 minecraft:bone_block
fill 236 17 500 236 19 501 minecraft:brown_terracotta
fill 237 17 469 237 20 469 minecraft:brown_terracotta
fill 237 17 471 237 17 472 minecraft:brown_terracotta
setblock 237 17 473 minecraft:bone_block
fill 237 17 484 237 20 484 minecraft:brown_terracotta
setblock 237 17 488 minecraft:bone_block
fill 237 17 489 237 20 489 minecraft:brown_terracotta
setblock 237 17 492 minecraft:brown_terracotta
setblock 237 17 493 minecraft:bone_block
fill 237 17 494 237 20 494 minecraft:brown_terracotta
setblock 237 17 498 minecraft:bone_block
fill 238 17 464 238 19 464 minecraft:brown_terracotta
setblock 238 17 486 minecraft:brown_terracotta
setblock 238 17 487 minecraft:bone_block
fill 238 17 488 238 20 488 minecraft:brown_terracotta
setblock 238 17 492 minecraft:bone_block
fill 238 17 493 238 20 493 minecraft:brown_terracotta
setblock 238 17 496 minecraft:brown_terracotta
setblock 238 17 497 minecraft:bone_block
fill 238 17 504 238 19 504 minecraft:brown_terracotta
setblock 239 17 491 minecraft:bone_block
fill 239 17 492 239 20 492 minecraft:brown_terracotta
fill 239 17 494 239 17 495 minecraft:brown_terracotta
setblock 241 17 464 minecraft:bone_block
fill 241 17 465 241 18 465 minecraft:brown_terracotta
setblock 241 17 504 minecraft:bone_block
fill 242 17 464 242 20 464 minecraft:brown_terracotta
fill 242 17 504 242 19 504 minecraft:brown_terracotta
setblock 246 17 464 minecraft:bone_block
fill 247 17 495 247 23 496 minecraft:bone_block
fill 247 17 500 247 23 501 minecraft:bone_block
fill 249 17 492 249 23 492 minecraft:bone_block
fill 249 17 504 249 23 504 minecraft:bone_block
fill 253 17 490 253 23 490 minecraft:bone_block
setblock 255 17 465 minecraft:bone_block
setblock 256 17 464 minecraft:bone_block
fill 256 17 465 256 20 465 minecraft:brown_terracotta
fill 257 17 464 257 20 464 minecraft:brown_terracotta
fill 257 17 490 258 23 490 minecraft:bone_block
fill 258 17 467 258 17 468 minecraft:bone_block
fill 258 17 504 258 19 504 minecraft:brown_terracotta
setblock 259 17 466 minecraft:bone_block
fill 259 17 467 259 20 467 minecraft:brown_terracotta
setblock 260 17 465 minecraft:bone_block
fill 260 17 466 260 20 466 minecraft:brown_terracotta
setblock 261 17 464 minecraft:bone_block
fill 261 17 465 261 20 465 minecraft:brown_terracotta
fill 261 17 492 261 23 492 minecraft:bone_block
setblock 261 17 504 minecraft:bone_block
fill 262 17 464 262 20 464 minecraft:brown_terracotta
setblock 262 17 503 minecraft:bone_block
fill 262 17 504 262 20 504 minecraft:brown_terracotta
setblock 263 17 467 minecraft:bone_block
fill 263 17 495 263 23 496 minecraft:bone_block
fill 263 17 500 263 23 501 minecraft:bone_block
fill 263 17 503 264 19 503 minecraft:brown_terracotta
setblock 264 17 466 minecraft:bone_block
fill 264 17 467 264 18 467 minecraft:brown_terracotta
setblock 265 17 465 minecraft:bone_block
fill 265 17 466 265 19 466 minecraft:brown_terracotta
setblock 266 17 464 minecraft:bone_block
fill 266 17 465 266 20 465 minecraft:brown_terracotta
setblock 266 17 504 minecraft:bone_block
fill 267 17 464 267 20 464 minecraft:brown_terracotta
fill 267 17 504 267 20 504 minecraft:brown_terracotta
setblock 271 17 464 minecraft:bone_block
fill 271 17 500 271 24 500 minecraft:soul_soil
setblock 272 17 464 minecraft:brown_terracotta
fill 274 17 504 274 18 504 minecraft:brown_terracotta
setblock 275 17 489 minecraft:brown_terracotta
setblock 275 17 490 minecraft:bone_block
fill 275 17 491 275 17 494 minecraft:brown_terracotta
setblock 275 17 495 minecraft:bone_block
fill 275 17 496 275 18 498 minecraft:brown_terracotta
setblock 276 17 464 minecraft:bone_block
fill 276 17 465 276 20 465 minecraft:brown_terracotta
setblock 276 17 469 minecraft:bone_block
fill 276 17 470 276 20 470 minecraft:brown_terracotta
setblock 276 17 473 minecraft:brown_terracotta
fill 276 17 486 276 17 488 minecraft:brown_terracotta
setblock 276 17 489 minecraft:bone_block
fill 276 17 490 276 20 490 minecraft:brown_terracotta
setblock 276 17 493 minecraft:brown_terracotta
setblock 276 17 494 minecraft:bone_block
fill 276 17 495 276 20 495 minecraft:brown_terracotta
setblock 276 17 499 minecraft:bone_block
fill 276 17 500 276 20 500 minecraft:brown_terracotta
setblock 276 17 504 minecraft:bone_block
fill 236 18 466 236 18 467 minecraft:brown_terracotta
setblock 236 18 468 minecraft:bone_block
fill 236 18 469 236 21 469 minecraft:brown_terracotta
setblock 236 18 473 minecraft:bone_block
fill 236 18 474 238 19 474 minecraft:brown_terracotta
setblock 236 18 477 minecraft:brown_terracotta
setblock 236 18 478 minecraft:bone_block
fill 236 18 479 236 19 481 minecraft:brown_terracotta
setblock 236 18 483 minecraft:bone_block
fill 236 18 484 236 21 484 minecraft:brown_terracotta
setblock 236 18 488 minecraft:bone_block
fill 236 18 489 236 21 489 minecraft:brown_terracotta
setblock 236 18 493 minecraft:bone_block
fill 236 18 494 236 21 494 minecraft:brown_terracotta
setblock 236 18 497 minecraft:brown_terracotta
setblock 236 18 498 minecraft:bone_block
fill 236 18 499 237 20 499 minecraft:brown_terracotta
setblock 236 18 502 minecraft:brown_terracotta
fill 237 18 468 237 21 468 minecraft:brown_terracotta
setblock 237 18 471 minecraft:brown_terracotta
setblock 237 18 472 minecraft:bone_block
fill 237 18 473 238 20 473 minecraft:brown_terracotta
fill 237 18 475 237 18 476 minecraft:brown_terracotta
setblock 237 18 477 minecraft:bone_block
fill 237 18 483 237 21 483 minecraft:brown_terracotta
setblock 237 18 487 minecraft:bone_block
fill 237 18 488 237 21 488 minecraft:brown_terracotta
setblock 237 18 492 minecraft:bone_block
fill 237 18 493 237 21 493 minecraft:brown_terracotta
setblock 237 18 497 minecraft:bone_block
fill 237 18 498 238 20 498 minecraft:brown_terracotta
fill 237 18 500 237 19 500 minecraft:brown_terracotta
fill 237 18 504 237 20 504 minecraft:brown_terracotta
setblock 238 18 471 minecraft:bone_block
fill 238 18 472 238 21 472 minecraft:brown_terracotta
setblock 238 18 485 minecraft:brown_terracotta
setblock 238 18 486 minecraft:bone_block
fill 238 18 487 239 19 487 minecraft:brown_terracotta
setblock 238 18 490 minecraft:brown_terracotta
setblock 238 18 491 minecraft:bone_block
fill 238 18 492 238 21 492 minecraft:brown_terracotta
setblock 238 18 496 minecraft:bone_block
fill 238 18 497 238 21 497 minecraft:brown_terracotta
setblock 239 18 490 minecraft:bone_block
fill 239 18 491 240 18 491 minecraft:brown_terracotta
setblock 239 18 494 minecraft:brown_terracotta
setblock 239 18 495 minecraft:bone_block
fill 239 18 496 239 21 496 minecraft:brown_terracotta
setblock 240 18 464 minecraft:bone_block
fill 240 18 492 240 19 492 minecraft:brown_terracotta
setblock 240 18 504 minecraft:bone_block
fill 241 18 464 241 21 464 minecraft:brown_terracotta
fill 241 18 504 241 20 504 minecraft:brown_terracotta
setblock 245 18 464 minecraft:bone_block
fill 248 18 493 248 22 493 minecraft:bone_block
fill 248 18 503 248 22 503 minecraft:bone_block
fill 250 18 491 250 22 491 minecraft:bone_block
fill 253 18 464 253 19 464 minecraft:brown_terracotta
fill 253 18 504 256 19 504 minecraft:bone_block
setblock 255 18 464 minecraft:bone_block
fill 255 18 465 255 21 465 minecraft:brown_terracotta
fill 256 18 464 256 21 464 minecraft:brown_terracotta
fill 256 18 466 256 19 466 minecraft:brown_terracotta
fill 257 18 504 257 20 504 minecraft:brown_terracotta
setblock 258 18 465 minecraft:brown_terracotta
setblock 258 18 466 minecraft:bone_block
fill 258 18 467 258 21 467 minecraft:brown_terracotta
fill 258 18 468 260 18 468 minecraft:bone_block
setblock 259 18 465 minecraft:bone_block
fill 259 18 466 259 21 466 minecraft:brown_terracotta
setblock 260 18 464 minecraft:bone_block
fill 260 18 465 260 21 465 minecraft:brown_terracotta
fill 260 18 491 260 22 491 minecraft:bone_block
setblock 260 18 504 minecraft:bone_block
fill 261 18 464 261 21 464 minecraft:brown_terracotta
fill 261 18 504 261 21 504 minecraft:brown_terracotta
setblock 262 18 467 minecraft:bone_block
fill 262 18 493 262 22 493 minecraft:bone_block
fill 262 18 503 262 21 503 minecraft:brown_terracotta
setblock 263 18 466 minecraft:bone_block
fill 263 18 467 263 19 467 minecraft:brown_terracotta
setblock 264 18 465 minecraft:bone_block
fill 264 18 466 264 20 466 minecraft:brown_terracotta
setblock 265 18 464 minecraft:bone_block
fill 265 18 465 265 20 465 minecraft:brown_terracotta
setblock 265 18 504 minecraft:bone_block
fill 266 18 464 266 21 464 minecraft:brown_terracotta
fill 266 18 504 266 21 504 minecraft:brown_terracotta
setblock 270 18 464 minecraft:bone_block
setblock 270 18 504 minecraft:bone_block
setblock 271 18 464 minecraft:brown_terracotta
fill 273 18 504 273 19 504 minecraft:brown_terracotta
setblock 275 18 464 minecraft:bone_block
setblock 275 18 489 minecraft:bone_block
fill 275 18 490 275 18 493 minecraft:brown_terracotta
setblock 275 18 494 minecraft:bone_block
fill 275 18 495 275 21 495 minecraft:brown_terracotta
setblock 275 18 499 minecraft:bone_block
fill 275 18 500 275 21 500 minecraft:brown_terracotta
setblock 275 18 504 minecraft:bone_block
fill 276 18 464 276 21 464 minecraft:brown_terracotta
setblock 276 18 468 minecraft:bone_block
fill 276 18 469 276 21 469 minecraft:brown_terracotta
setblock 276 18 473 minecraft:bone_block
fill 276 18 474 276 20 475 minecraft:brown_terracotta
fill 276 18 485 276 18 487 minecraft:brown_terracotta
setblock 276 18 488 minecraft:bone_block
fill 276 18 489 276 21 489 minecraft:brown_terracotta
setblock 276 18 493 minecraft:bone_block
fill 276 18 494 276 21 494 minecraft:brown_terracotta
setblock 276 18 497 minecraft:brown_terracotta
setblock 276 18 498 minecraft:bone_block
fill 276 18 499 276 21 499 minecraft:brown_terracotta
fill 276 18 501 276 18 502 minecraft:brown_terracotta
setblock 276 18 503 minecraft:bone_block
fill 276 18 504 276 21 504 minecraft:brown_terracotta
fill 236 19 465 236 19 466 minecraft:brown_terracotta
setblock 236 19 467 minecraft:bone_block
fill 236 19 468 236 22 468 minecraft:brown_terracotta
setblock 236 19 471 minecraft:brown_terracotta
setblock 236 19 472 minecraft:bone_block
fill 236 19 473 236 22 473 minecraft:brown_terracotta
setblock 236 19 477 minecraft:bone_block
fill 236 19 478 237 21 478 minecraft:brown_terracotta
setblock 236 19 482 minecraft:bone_block
fill 236 19 483 236 22 483 minecraft:brown_terracotta
setblock 236 19 487 minecraft:bone_block
fill 236 19 488 236 22 488 minecraft:brown_terracotta
setblock 236 19 492 minecraft:bone_block
fill 236 19 493 236 22 493 minecraft:brown_terracotta
setblock 236 19 497 minecraft:bone_block
fill 236 19 498 236 22 498 minecraft:brown_terracotta
setblock 236 19 502 minecraft:bone_block
fill 236 19 503 236 21 504 minecraft:brown_terracotta
fill 237 19 464 237 20 464 minecraft:brown_terracotta
setblock 237 19 471 minecraft:bone_block
fill 237 19 472 237 22 472 minecraft:brown_terracotta
setblock 237 19 475 minecraft:brown_terracotta
setblock 237 19 476 minecraft:bone_block
fill 237 19 477 238 21 477 minecraft:brown_terracotta
fill 237 19 479 237 19 480 minecraft:brown_terracotta
setblock 237 19 481 minecraft:bone_block
fill 237 19 482 237 22 482 minecraft:brown_terracotta
setblock 237 19 486 minecraft:bone_block
fill 237 19 487 237 22 487 minecraft:brown_terracotta
setblock 237 19 491 minecraft:bone_block
fill 237 19 492 237 22 492 minecraft:brown_terracotta
setblock 237 19 495 minecraft:brown_terracotta
setblock 237 19 496 minecraft:bone_block
fill 237 19 497 237 22 497 minecraft:brown_terracotta
setblock 237 19 501 minecraft:bone_block
setblock 238 19 470 minecraft:bone_block
fill 238 19 471 238 22 471 minecraft:brown_terracotta
setblock 238 19 475 minecraft:bone_block
fill 238 19 476 238 22 476 minecraft:brown_terracotta
setblock 238 19 485 minecraft:bone_block
fill 238 19 486 238 22 486 minecraft:brown_terracotta
setblock 238 19 490 minecraft:bone_block
fill 238 19 491 239 21 491 minecraft:brown_terracotta
setblock 238 19 495 minecraft:bone_block
fill 238 19 496 238 22 496 minecraft:brown_terracotta
setblock 239 19 464 minecraft:bone_block
setblock 239 19 489 minecraft:bone_block
fill 239 19 490 239 21 490 minecraft:brown_terracotta
setblock 239 19 494 minecraft:bone_block
fill 239 19 495 239 22 495 minecraft:brown_terracotta
setblock 239 19 504 minecraft:bone_block
fill 240 19 464 240 21 464 minecraft:brown_terracotta
fill 240 19 504 240 22 504 minecraft:brown_terracotta
fill 243 19 482 243 20 483 minecraft:bone_block
setblock 244 19 464 minecraft:bone_block
fill 247 19 494 247 21 494 minecraft:bone_block
fill 247 19 502 247 21 502 minecraft:bone_block
fill 251 19 490 251 21 490 minecraft:bone_block
setblock 254 19 464 minecraft:bone_block
fill 254 19 465 254 21 465 minecraft:brown_terracotta
fill 255 19 464 255 22 464 minecraft:brown_terracotta
setblock 257 19 465 minecraft:brown_terracotta
setblock 257 19 466 minecraft:bone_block
setblock 257 19 467 minecraft:brown_terracotta
setblock 258 19 465 minecraft:bone_block
fill 258 19 466 258 22 466 minecraft:brown_terracotta
setblock 259 19 464 minecraft:bone_block
fill 259 19 465 259 22 465 minecraft:brown_terracotta
fill 259 19 468 261 19 468 minecraft:bone_block
fill 259 19 490 259 21 490 minecraft:bone_block
setblock 259 19 503 minecraft:brown_terracotta
setblock 259 19 504 minecraft:bone_block
fill 260 19 464 260 22 464 minecraft:brown_terracotta
fill 260 19 469 262 20 469 minecraft:bone_block
setblock 260 19 503 minecraft:bone_block
fill 260 19 504 260 22 504 minecraft:brown_terracotta
setblock 261 19 467 minecraft:bone_block
fill 261 19 503 261 22 503 minecraft:brown_terracotta
setblock 262 19 466 minecraft:bone_block
fill 262 19 467 262 20 467 minecraft:brown_terracotta
setblock 263 19 465 minecraft:bone_block
fill 263 19 466 263 20 466 minecraft:brown_terracotta
fill 263 19 494 263 21 494 minecraft:bone_block
fill 263 19 502 263 21 502 minecraft:bone_block
setblock 264 19 464 minecraft:bone_block
fill 264 19 465 264 21 465 minecraft:brown_terracotta
setblock 264 19 504 minecraft:bone_block
fill 265 19 464 265 22 464 minecraft:brown_terracotta
fill 265 19 504 265 22 504 minecraft:brown_terracotta
setblock 269 19 464 minecraft:bone_block
setblock 269 19 504 minecraft:bone_block
fill 270 19 504 272 20 504 minecraft:brown_terracotta
fill 274 19 492 274 19 493 minecraft:brown_terracotta
setblock 274 19 494 minecraft:bone_block
fill 274 19 495 274 20 497 minecraft:brown_terracotta
setblock 274 19 504 minecraft:bone_block
fill 275 19 464 275 20 464 minecraft:brown_terracotta
fill 275 19 470 275 20 471 minecraft:brown_terracotta
setblock 275 19 488 minecraft:bone_block
fill 275 19 489 275 19 492 minecraft:brown_terracotta
setblock 275 19 493 minecraft:bone_block
fill 275 19 494 275 22 494 minecraft:brown_terracotta
fill 275 19 496 275 19 497 minecraft:brown_terracotta
setblock 275 19 498 minecraft:bone_block
fill 275 19 499 275 22 499 minecraft:brown_terracotta
fill 275 19 501 275 19 502 minecraft:brown_terracotta
fill 275 19 504 275 22 504 minecraft:brown_terracotta
setblock 276 19 467 minecraft:bone_block
fill 276 19 468 276 22 468 minecraft:brown_terracotta
setblock 276 19 471 minecraft:brown_terracotta
setblock 276 19 472 minecraft:bone_block
fill 276 19 473 276 22 473 minecraft:brown_terracotta
setblock 276 19 476 minecraft:brown_terracotta
setblock 276 19 477 minecraft:bone_block
fill 276 19 485 276 19 486 minecraft:brown_terracotta
setblock 276 19 487 minecraft:bone_block
fill 276 19 488 276 22 488 minecraft:brown_terracotta
setblock 276 19 492 minecraft:bone_block
fill 276 19 493 276 22 493 minecraft:brown_terracotta
setblock 276 19 497 minecraft:bone_block
fill 276 19 498 276 22 498 minecraft:brown_terracotta
setblock 276 19 501 minecraft:brown_terracotta
setblock 276 19 502 minecraft:bone_block
fill 276 19 503 276 22 503 minecraft:brown_terracotta
setblock 236 20 466 minecraft:bone_block
fill 236 20 467 236 23 467 minecraft:brown_terracotta
setblock 236 20 470 minecraft:brown_terracotta
setblock 236 20 471 minecraft:bone_block
fill 236 20 472 236 23 472 minecraft:brown_terracotta
fill 236 20 474 236 20 475 minecraft:brown_terracotta
setblock 236 20 476 minecraft:bone_block
fill 236 20 477 236 23 477 minecraft:brown_terracotta
fill 236 20 479 236 20 480 minecraft:brown_terracotta
setblock 236 20 481 minecraft:bone_block
fill 236 20 482 236 23 482 minecraft:brown_terracotta
setblock 236 20 486 minecraft:bone_block
fill 236 20 487 236 23 487 minecraft:brown_terracotta
setblock 236 20 491 minecraft:bone_block
fill 236 20 492 236 23 492 minecraft:brown_terracotta
setblock 236 20 496 minecraft:bone_block
fill 236 20 497 236 23 497 minecraft:brown_terracotta
setblock 236 20 500 minecraft:brown_terracotta
setblock 236 20 501 minecraft:bone_block
fill 236 20 502 236 23 502 minecraft:brown_terracotta
setblock 237 20 470 minecraft:bone_block
fill 237 20 471 237 23 471 minecraft:brown_terracotta
setblock 237 20 474 minecraft:brown_terracotta
setblock 237 20 475 minecraft:bone_block
fill 237 20 476 237 23 476 minecraft:brown_terracotta
setblock 237 20 479 minecraft:brown_terracotta
setblock 237 20 480 minecraft:bone_block
fill 237 20 481 237 23 481 minecraft:brown_terracotta
setblock 237 20 485 minecraft:bone_block
fill 237 20 486 237 23 486 minecraft:brown_terracotta
setblock 237 20 490 minecraft:bone_block
fill 237 20 491 237 23 491 minecraft:brown_terracotta
setblock 237 20 495 minecraft:bone_block
fill 237 20 496 237 23 496 minecraft:brown_terracotta
setblock 237 20 500 minecraft:bone_block
fill 237 20 501 237 23 501 minecraft:brown_terracotta
setblock 238 20 464 minecraft:bone_block
fill 238 20 470 238 21 470 minecraft:brown_terracotta
setblock 238 20 474 minecraft:bone_block
fill 238 20 475 239 22 475 minecraft:brown_terracotta
setblock 238 20 478 minecraft:brown_terracotta
setblock 238 20 479 minecraft:bone_block
fill 238 20 480 238 23 480 minecraft:brown_terracotta
setblock 238 20 484 minecraft:bone_block
fill 238 20 485 238 21 485 minecraft:brown_terracotta
fill 238 20 487 238 21 487 minecraft:brown_terracotta
setblock 238 20 489 minecraft:bone_block
fill 238 20 490 238 23 490 minecraft:brown_terracotta
setblock 238 20 494 minecraft:bone_block
fill 238 20 495 238 23 495 minecraft:brown_terracotta
setblock 238 20 499 minecraft:bone_block
setblock 238 20 504 minecraft:bone_block
fill 239 20 464 239 21 464 minecraft:brown_terracotta
setblock 239 20 472 minecraft:brown_terracotta
setblock 239 20 473 minecraft:bone_block
fill 239 20 474 239 23 474 minecraft:brown_terracotta
setblock 239 20 488 minecraft:bone_block
fill 239 20 489 239 21 489 minecraft:brown_terracotta
setblock 239 20 493 minecraft:bone_block
fill 239 20 494 239 22 494 minecraft:brown_terracotta
setblock 239 20 497 minecraft:brown_terracotta
fill 239 20 504 239 23 504 minecraft:brown_terracotta
setblock 243 20 464 minecraft:bone_block
setblock 246 20 498 minecraft:bone_block
fill 252 20 490 252 23 490 minecraft:bone_block
setblock 253 20 464 minecraft:bone_block
fill 253 20 504 255 20 504 minecraft:bone_block
fill 254 20 464 254 23 464 minecraft:brown_terracotta
setblock 255 20 489 minecraft:bone_block
setblock 256 20 466 minecraft:bone_block
fill 256 20 504 256 21 504 minecraft:brown_terracotta
setblock 257 20 465 minecraft:bone_block
fill 257 20 466 257 22 466 minecraft:brown_terracotta
fill 257 20 503 257 22 503 minecraft:bone_block
setblock 258 20 464 minecraft:bone_block
fill 258 20 465 258 23 465 minecraft:brown_terracotta
setblock 258 20 503 minecraft:brown_terracotta
setblock 258 20 504 minecraft:bone_block
fill 259 20 464 259 23 464 minecraft:brown_terracotta
setblock 259 20 503 minecraft:bone_block
fill 259 20 504 259 23 504 minecraft:brown_terracotta
setblock 260 20 467 minecraft:bone_block
fill 260 20 503 260 23 503 minecraft:brown_terracotta
setblock 261 20 466 minecraft:bone_block
setblock 261 20 467 minecraft:brown_terracotta
setblock 261 20 468 minecraft:bone_block
setblock 262 20 465 minecraft:bone_block
fill 262 20 466 262 21 466 minecraft:brown_terracotta
setblock 263 20 464 minecraft:bone_block
fill 263 20 465 263 22 465 minecraft:brown_terracotta
setblock 263 20 503 minecraft:brown_terracotta
setblock 263 20 504 minecraft:bone_block
fill 264 20 464 264 23 464 minecraft:brown_terracotta
setblock 264 20 498 minecraft:bone_block
setblock 264 20 503 minecraft:bone_block
fill 264 20 504 264 23 504 minecraft:brown_terracotta
setblock 268 20 464 minecraft:bone_block
setblock 268 20 504 minecraft:bone_block
fill 269 20 504 269 21 504 minecraft:brown_terracotta
setblock 273 20 504 minecraft:bone_block
setblock 274 20 492 minecraft:brown_terracotta
setblock 274 20 493 minecraft:bone_block
fill 274 20 494 274 23 494 minecraft:brown_terracotta
setblock 274 20 498 minecraft:bone_block
fill 274 20 504 274 23 504 minecraft:brown_terracotta
setblock 275 20 472 minecraft:bone_block
fill 275 20 473 275 23 473 minecraft:brown_terracotta
fill 275 20 488 275 20 491 minecraft:brown_terracotta
setblock 275 20 492 minecraft:bone_block
fill 275 20 493 275 23 493 minecraft:brown_terracotta
setblock 275 20 496 minecraft:brown_terracotta
setblock 275 20 497 minecraft:bone_block
fill 275 20 498 275 23 498 minecraft:brown_terracotta
setblock 275 20 501 minecraft:brown_terracotta
setblock 275 20 502 minecraft:bone_block
fill 275 20 503 275 23 503 minecraft:brown_terracotta
setblock 276 20 466 minecraft:bone_block
fill 276 20 467 276 22 467 minecraft:brown_terracotta
setblock 276 20 471 minecraft:bone_block
fill 276 20 472 276 23 472 minecraft:brown_terracotta
setblock 276 20 476 minecraft:bone_block
fill 276 20 477 276 20 480 minecraft:brown_terracotta
fill 276 20 484 276 20 485 minecraft:brown_terracotta
setblock 276 20 486 minecraft:bone_block
fill 276 20 487 276 23 487 minecraft:brown_terracotta
setblock 276 20 491 minecraft:bone_block
fill 276 20 492 276 23 492 minecraft:brown_terracotta
setblock 276 20 496 minecraft:bone_block
fill 276 20 497 276 23 497 minecraft:brown_terracotta
setblock 276 20 501 minecraft:bone_block
fill 276 20 502 276 23 502 minecraft:brown_terracotta
setblock 236 21 466 minecraft:brown_terracotta
setblock 236 21 470 minecraft:bone_block
fill 236 21 471 236 24 471 minecraft:brown_terracotta
setblock 236 21 474 minecraft:brown_terracotta
setblock 236 21 475 minecraft:bone_block
fill 236 21 476 236 24 476 minecraft:brown_terracotta
setblock 236 21 479 minecraft:brown_terracotta
setblock 236 21 480 minecraft:bone_block
fill 236 21 481 236 24 481 minecraft:brown_terracotta
setblock 236 21 485 minecraft:bone_block
fill 236 21 486 236 24 486 minecraft:brown_terracotta
setblock 236 21 490 minecraft:bone_block
fill 236 21 491 236 24 491 minecraft:brown_terracotta
setblock 236 21 495 minecraft:bone_block
fill 236 21 496 236 24 496 minecraft:brown_terracotta
setblock 236 21 499 minecraft:brown_terracotta
setblock 236 21 500 minecraft:bone_block
fill 236 21 501 236 24 501 minecraft:brown_terracotta
setblock 237 21 469 minecraft:bone_block
fill 237 21 470 237 24 470 minecraft:brown_terracotta
setblock 237 21 473 minecraft:brown_terracotta
setblock 237 21 474 minecraft:bone_block
fill 237 21 475 237 24 475 minecraft:brown_terracotta
setblock 237 21 479 minecraft:bone_block
fill 237 21 480 237 24 480 minecraft:brown_terracotta
setblock 237 21 484 minecraft:bone_block
fill 237 21 485 237 24 485 minecraft:brown_terracotta
setblock 237 21 489 minecraft:bone_block
fill 237 21 490 237 24 490 minecraft:brown_terracotta
setblock 237 21 494 minecraft:bone_block
fill 237 21 495 237 24 495 minecraft:brown_terracotta
setblock 237 21 498 minecraft:brown_terracotta
setblock 237 21 499 minecraft:bone_block
fill 237 21 500 237 24 500 minecraft:brown_terracotta
fill 237 21 502 237 22 502 minecraft:brown_terracotta
setblock 237 21 504 minecraft:bone_block
setblock 238 21 464 minecraft:brown_terracotta
setblock 238 21 473 minecraft:bone_block
fill 238 21 474 238 24 474 minecraft:brown_terracotta
setblock 238 21 478 minecraft:bone_block
fill 238 21 479 238 24 479 minecraft:brown_terracotta
fill 238 21 481 238 21 482 minecraft:brown_terracotta
setblock 238 21 483 minecraft:bone_block
setblock 238 21 484 minecraft:brown_terracotta
setblock 238 21 488 minecraft:bone_block
fill 238 21 489 238 23 489 minecraft:brown_terracotta
setblock 238 21 493 minecraft:bone_block
fill 238 21 494 238 24 494 minecraft:brown_terracotta
setblock 238 21 498 minecraft:bone_block
fill 238 21 499 238 24 499 minecraft:brown_terracotta
fill 238 21 504 238 24 504 minecraft:brown_terracotta
setblock 239 21 472 minecraft:bone_block
fill 239 21 473 239 22 473 minecraft:brown_terracotta
setblock 239 21 476 minecraft:brown_terracotta
setblock 239 21 477 minecraft:bone_block
setblock 239 21 492 minecraft:bone_block
fill 239 21 493 239 22 493 minecraft:brown_terracotta
setblock 239 21 497 minecraft:bone_block
fill 250 21 490 250 22 490 minecraft:shroomlight
fill 253 21 464 253 24 464 minecraft:brown_terracotta
fill 253 21 504 254 24 504 minecraft:bone_block
fill 255 21 504 255 22 504 minecraft:brown_terracotta
setblock 256 21 465 minecraft:bone_block
fill 256 21 466 256 22 466 minecraft:brown_terracotta
setblock 257 21 464 minecraft:bone_block
fill 257 21 465 257 24 465 minecraft:brown_terracotta
setblock 257 21 504 minecraft:bone_block
fill 258 21 464 258 24 464 minecraft:brown_terracotta
setblock 258 21 503 minecraft:bone_block
fill 258 21 504 258 24 504 minecraft:brown_terracotta
setblock 259 21 467 minecraft:bone_block
fill 259 21 503 259 24 503 minecraft:brown_terracotta
setblock 260 21 466 minecraft:bone_block
setblock 260 21 467 minecraft:brown_terracotta
fill 260 21 490 260 22 490 minecraft:shroomlight
setblock 261 21 465 minecraft:bone_block
fill 261 21 466 261 22 466 minecraft:brown_terracotta
setblock 262 21 464 minecraft:bone_block
fill 262 21 465 262 23 465 minecraft:brown_terracotta
setblock 262 21 504 minecraft:bone_block
fill 263 21 464 263 24 464 minecraft:brown_terracotta
setblock 263 21 503 minecraft:bone_block
fill 263 21 504 263 24 504 minecraft:brown_terracotta
fill 264 21 503 264 22 503 minecraft:brown_terracotta
setblock 267 21 464 minecraft:bone_block
setblock 267 21 504 minecraft:bone_block
fill 268 21 504 268 22 504 minecraft:brown_terracotta
fill 270 21 500 270 24 500 minecraft:soul_soil
fill 270 21 504 271 21 504 minecraft:brown_terracotta
fill 271 21 499 271 24 499 minecraft:soul_soil
fill 271 21 501 271 24 501 minecraft:soul_soil
fill 272 21 500 272 24 500 minecraft:soul_soil
setblock 272 21 504 minecraft:bone_block
fill 273 21 504 273 24 504 minecraft:brown_terracotta
setblock 274 21 492 minecraft:bone_block
fill 274 21 493 274 24 493 minecraft:brown_terracotta
fill 274 21 495 274 21 496 minecraft:brown_terracotta
setblock 274 21 497 minecraft:bone_block
fill 274 21 498 274 23 499 minecraft:brown_terracotta
setblock 275 21 471 minecraft:bone_block
fill 275 21 472 275 22 472 minecraft:brown_terracotta
fill 275 21 474 275 21 475 minecraft:brown_terracotta
fill 275 21 488 275 21 490 minecraft:brown_terracotta
setblock 275 21 491 minecraft:bone_block
fill 275 21 492 275 24 492 minecraft:brown_terracotta
setblock 275 21 496 minecraft:bone_block
fill 275 21 497 275 24 497 minecraft:brown_terracotta
setblock 275 21 501 minecraft:bone_block
fill 275 21 502 275 24 502 minecraft:brown_terracotta
setblock 276 21 465 minecraft:bone_block
fill 276 21 466 276 22 466 minecraft:brown_terracotta
setblock 276 21 470 minecraft:bone_block
fill 276 21 471 276 24 471 minecraft:brown_terracotta
setblock 276 21 474 minecraft:brown_terracotta
setblock 276 21 475 minecraft:bone_block
fill 276 21 476 276 21 479 minecraft:brown_terracotta
setblock 276 21 480 minecraft:bone_block
fill 276 21 481 276 21 484 minecraft:brown_terracotta
setblock 276 21 485 minecraft:bone_block
fill 276 21 486 276 24 486 minecraft:brown_terracotta
setblock 276 21 490 minecraft:bone_block
fill 276 21 491 276 24 491 minecraft:brown_terracotta
setblock 276 21 495 minecraft:bone_block
fill 276 21 496 276 24 496 minecraft:brown_terracotta
setblock 276 21 500 minecraft:bone_block
fill 276 21 501 276 24 501 minecraft:brown_terracotta
setblock 236 22 469 minecraft:bone_block
fill 236 22 470 236 25 470 minecraft:brown_terracotta
setblock 236 22 474 minecraft:bone_block
fill 236 22 475 236 25 475 minecraft:brown_terracotta
setblock 236 22 478 minecraft:brown_terracotta
setblock 236 22 479 minecraft:bone_block
fill 236 22 480 236 25 480 minecraft:brown_terracotta
setblock 236 22 484 minecraft:bone_block
fill 236 22 485 236 25 485 minecraft:brown_terracotta
setblock 236 22 489 minecraft:bone_block
fill 236 22 490 236 25 490 minecraft:brown_terracotta
setblock 236 22 494 minecraft:bone_block
fill 236 22 495 236 25 495 minecraft:brown_terracotta
setblock 236 22 499 minecraft:bone_block
fill 236 22 500 236 25 500 minecraft:brown_terracotta
setblock 236 22 503 minecraft:brown_terracotta
setblock 236 22 504 minecraft:bone_block
fill 237 22 469 237 23 469 minecraft:brown_terracotta
setblock 237 22 473 minecraft:bone_block
fill 237 22 474 237 25 474 minecraft:brown_terracotta
setblock 237 22 477 minecraft:brown_terracotta
setblock 237 22 478 minecraft:bone_block
fill 237 22 479 237 25 479 minecraft:brown_terracotta
setblock 237 22 483 minecraft:bone_block
fill 237 22 484 237 25 484 minecraft:brown_terracotta
setblock 237 22 488 minecraft:bone_block
fill 237 22 489 237 25 489 minecraft:brown_terracotta
setblock 237 22 493 minecraft:bone_block
fill 237 22 494 237 25 494 minecraft:brown_terracotta
setblock 237 22 498 minecraft:bone_block
fill 237 22 499 237 25 499 minecraft:brown_terracotta
fill 237 22 504 237 25 504 minecraft:brown_terracotta
setblock 238 22 472 minecraft:bone_block
fill 238 22 473 238 25 473 minecraft:brown_terracotta
setblock 238 22 477 minecraft:bone_block
fill 238 22 478 238 25 478 minecraft:brown_terracotta
setblock 238 22 481 minecraft:brown_terracotta
setblock 238 22 482 minecraft:bone_block
setblock 238 22 487 minecraft:bone_block
fill 238 22 488 238 23 488 minecraft:brown_terracotta
setblock 238 22 491 minecraft:brown_terracotta
setblock 238 22 492 minecraft:bone_block
fill 238 22 493 238 24 493 minecraft:brown_terracotta
setblock 238 22 497 minecraft:bone_block
fill 238 22 498 238 25 498 minecraft:brown_terracotta
setblock 239 22 476 minecraft:bone_block
fill 239 22 477 239 24 477 minecraft:brown_terracotta
setblock 239 22 491 minecraft:bone_block
setblock 239 22 492 minecraft:brown_terracotta
setblock 239 22 496 minecraft:bone_block
fill 251 22 490 251 23 490 minecraft:shroomlight
setblock 255 22 465 minecraft:bone_block
setblock 256 22 464 minecraft:bone_block
fill 256 22 465 256 25 465 minecraft:brown_terracotta
setblock 256 22 504 minecraft:bone_block
fill 257 22 464 257 25 464 minecraft:brown_terracotta
fill 257 22 504 257 25 504 minecraft:brown_terracotta
fill 258 22 489 259 22 489 minecraft:shroomlight
fill 258 22 503 258 25 503 minecraft:brown_terracotta
setblock 259 22 466 minecraft:bone_block
fill 259 22 490 259 23 490 minecraft:shroomlight
setblock 260 22 465 minecraft:bone_block
setblock 260 22 466 minecraft:brown_terracotta
setblock 261 22 464 minecraft:bone_block
fill 261 22 465 261 23 465 minecraft:brown_terracotta
setblock 261 22 504 minecraft:bone_block
fill 262 22 464 262 25 464 minecraft:brown_terracotta
setblock 262 22 503 minecraft:bone_block
fill 262 22 504 262 25 504 minecraft:brown_terracotta
fill 263 22 503 263 23 503 minecraft:brown_terracotta
setblock 266 22 504 minecraft:bone_block
fill 267 22 504 267 23 504 minecraft:brown_terracotta
fill 270 22 499 270 24 499 minecraft:soul_soil
fill 270 22 501 270 24 501 minecraft:soul_soil
setblock 270 22 504 minecraft:brown_terracotta
setblock 271 22 504 minecraft:bone_block
fill 272 22 499 272 24 499 minecraft:soul_soil
fill 272 22 501 272 24 501 minecraft:soul_soil
fill 272 22 504 272 25 504 minecraft:brown_terracotta
fill 274 22 492 274 23 492 minecraft:brown_terracotta
setblock 274 22 495 minecraft:brown_terracotta
setblock 274 22 496 minecraft:bone_block
fill 274 22 497 274 25 497 minecraft:brown_terracotta
setblock 274 22 500 minecraft:brown_terracotta
fill 274 22 503 274 24 503 minecraft:brown_terracotta
setblock 275 22 474 minecraft:brown_terracotta
setblock 275 22 475 minecraft:bone_block
fill 275 22 476 276 24 476 minecraft:brown_terracotta
fill 275 22 488 275 22 489 minecraft:brown_terracotta
setblock 275 22 490 minecraft:bone_block
fill 275 22 491 275 25 491 minecraft:brown_terracotta
setblock 275 22 495 minecraft:bone_block
fill 275 22 496 275 25 496 minecraft:brown_terracotta
setblock 275 22 500 minecraft:bone_block
fill 275 22 501 275 25 501 minecraft:brown_terracotta
setblock 276 22 469 minecraft:bone_block
fill 276 22 470 276 25 470 minecraft:brown_terracotta
setblock 276 22 474 minecraft:bone_block
fill 276 22 475 276 25 475 minecraft:brown_terracotta
fill 276 22 477 276 22 478 minecraft:brown_terracotta
setblock 276 22 479 minecraft:bone_block
fill 276 22 480 276 22 483 minecraft:brown_terracotta
setblock 276 22 484 minecraft:bone_block
fill 276 22 485 276 25 485 minecraft:brown_terracotta
setblock 276 22 489 minecraft:bone_block
fill 276 22 490 276 25 490 minecraft:brown_terracotta
setblock 276 22 494 minecraft:bone_block
fill 276 22 495 276 25 495 minecraft:brown_terracotta
setblock 276 22 499 minecraft:bone_block
fill 276 22 500 276 25 500 minecraft:brown_terracotta
setblock 276 22 504 minecraft:bone_block
setblock 236 23 468 minecraft:bone_block
fill 236 23 469 236 26 469 minecraft:brown_terracotta
setblock 236 23 473 minecraft:bone_block
fill 236 23 474 236 26 474 minecraft:brown_terracotta
setblock 236 23 478 minecraft:bone_block
fill 236 23 479 236 26 479 minecraft:brown_terracotta
setblock 236 23 483 minecraft:bone_block
fill 236 23 484 236 26 484 minecraft:brown_terracotta
setblock 236 23 488 minecraft:bone_block
fill 236 23 489 236 26 489 minecraft:brown_terracotta
setblock 236 23 493 minecraft:bone_block
fill 236 23 494 236 26 494 minecraft:brown_terracotta
setblock 236 23 498 minecraft:bone_block
fill 236 23 499 236 26 499 minecraft:brown_terracotta
setblock 236 23 503 minecraft:bone_block
fill 236 23 504 236 26 504 minecraft:brown_terracotta
setblock 237 23 472 minecraft:bone_block
fill 237 23 473 237 26 473 minecraft:brown_terracotta
setblock 237 23 477 minecraft:bone_block
fill 237 23 478 237 26 478 minecraft:brown_terracotta
setblock 237 23 482 minecraft:bone_block
fill 237 23 483 237 26 483 minecraft:brown_terracotta
setblock 237 23 487 minecraft:bone_block
fill 237 23 488 237 26 488 minecraft:brown_terracotta
setblock 237 23 492 minecraft:bone_block
fill 237 23 493 237 26 493 minecraft:brown_terracotta
setblock 237 23 497 minecraft:bone_block
fill 237 23 498 237 26 498 minecraft:brown_terracotta
setblock 237 23 502 minecraft:bone_block
setblock 238 23 471 minecraft:bone_block
fill 238 23 472 238 24 472 minecraft:brown_terracotta
setblock 238 23 475 minecraft:brown_terracotta
setblock 238 23 476 minecraft:bone_block
fill 238 23 477 238 26 477 minecraft:brown_terracotta
setblock 238 23 481 minecraft:bone_block
fill 238 23 482 238 26 482 minecraft:brown_terracotta
setblock 238 23 491 minecraft:bone_block
fill 238 23 492 238 24 492 minecraft:brown_terracotta
setblock 238 23 496 minecraft:bone_block
fill 238 23 497 238 25 497 minecraft:brown_terracotta
setblock 239 23 475 minecraft:bone_block
fill 239 23 476 239 24 476 minecraft:brown_terracotta
setblock 239 23 478 minecraft:brown_terracotta
setblock 255 23 464 minecraft:bone_block
fill 255 23 465 255 26 465 minecraft:brown_terracotta
setblock 255 23 504 minecraft:bone_block
fill 256 23 464 256 26 464 minecraft:brown_terracotta
fill 256 23 504 256 26 504 minecraft:brown_terracotta
fill 257 23 503 257 26 503 minecraft:brown_terracotta
setblock 258 23 466 minecraft:bone_block
setblock 259 23 465 minecraft:bone_block
setblock 260 23 464 minecraft:bone_block
fill 260 23 465 260 24 465 minecraft:brown_terracotta
setblock 260 23 504 minecraft:bone_block
fill 261 23 464 261 26 464 minecraft:brown_terracotta
setblock 261 23 503 minecraft:bone_block
fill 261 23 504 261 26 504 minecraft:brown_terracotta
fill 262 23 503 262 26 503 minecraft:brown_terracotta
setblock 265 23 504 minecraft:bone_block
fill 266 23 504 266 24 504 minecraft:brown_terracotta
setblock 270 23 504 minecraft:bone_block
fill 271 23 504 271 26 504 minecraft:brown_terracotta
setblock 274 23 495 minecraft:bone_block
fill 274 23 496 274 26 496 minecraft:brown_terracotta
setblock 274 23 500 minecraft:bone_block
setblock 275 23 474 minecraft:bone_block
fill 275 23 475 275 26 475 minecraft:brown_terracotta
fill 275 23 477 276 23 477 minecraft:brown_terracotta
setblock 275 23 489 minecraft:bone_block
fill 275 23 490 275 26 490 minecraft:brown_terracotta
setblock 275 23 494 minecraft:bone_block
fill 275 23 495 275 26 495 minecraft:brown_terracotta
setblock 275 23 499 minecraft:bone_block
fill 275 23 500 275 26 500 minecraft:brown_terracotta
setblock 275 23 504 minecraft:bone_block
setblock 276 23 468 minecraft:bone_block
fill 276 23 469 276 24 469 minecraft:brown_terracotta
setblock 276 23 473 minecraft:bone_block
fill 276 23 474 276 26 474 minecraft:brown_terracotta
setblock 276 23 478 minecraft:bone_block
fill 276 23 479 276 23 482 minecraft:brown_terracotta
setblock 276 23 483 minecraft:bone_block
fill 276 23 484 276 26 484 minecraft:brown_terracotta
setblock 276 23 488 minecraft:bone_block
fill 276 23 489 276 26 489 minecraft:brown_terracotta
setblock 276 23 493 minecraft:bone_block
fill 276 23 494 276 26 494 minecraft:brown_terracotta
setblock 276 23 498 minecraft:bone_block
fill 276 23 499 276 26 499 minecraft:brown_terracotta
setblock 276 23 503 minecraft:bone_block
fill 276 23 504 276 26 504 minecraft:brown_terracotta
setblock 236 24 468 minecraft:brown_terracotta
setblock 236 24 472 minecraft:bone_block
fill 236 24 473 236 27 473 minecraft:brown_terracotta
setblock 236 24 477 minecraft:bone_block
fill 236 24 478 236 27 478 minecraft:brown_terracotta
setblock 236 24 482 minecraft:bone_block
fill 236 24 483 236 27 483 minecraft:brown_terracotta
setblock 236 24 487 minecraft:bone_block
fill 236 24 488 236 27 488 minecraft:brown_terracotta
setblock 236 24 492 minecraft:bone_block
fill 236 24 493 236 27 493 minecraft:brown_terracotta
setblock 236 24 497 minecraft:bone_block
fill 236 24 498 236 27 498 minecraft:brown_terracotta
setblock 236 24 502 minecraft:bone_block
fill 236 24 503 236 27 503 minecraft:brown_terracotta
setblock 237 24 471 minecraft:bone_block
fill 237 24 472 237 27 472 minecraft:brown_terracotta
setblock 237 24 476 minecraft:bone_block
fill 237 24 477 237 27 477 minecraft:brown_terracotta
setblock 237 24 481 minecraft:bone_block
fill 237 24 482 237 27 482 minecraft:brown_terracotta
setblock 237 24 486 minecraft:bone_block
fill 237 24 487 237 27 487 minecraft:brown_terracotta
setblock 237 24 491 minecraft:bone_block
fill 237 24 492 237 27 492 minecraft:brown_terracotta
setblock 237 24 496 minecraft:bone_block
fill 237 24 497 237 27 497 minecraft:brown_terracotta
setblock 237 24 501 minecraft:bone_block
setblock 238 24 466 minecraft:light[level=12]
setblock 238 24 475 minecraft:bone_block
fill 238 24 476 238 27 476 minecraft:brown_terracotta
setblock 238 24 480 minecraft:bone_block
fill 238 24 481 238 27 481 minecraft:brown_terracotta
setblock 238 24 490 minecraft:light[level=12]
setblock 238 24 491 minecraft:brown_terracotta
setblock 238 24 495 minecraft:bone_block
fill 238 24 496 238 25 496 minecraft:brown_terracotta
setblock 239 24 475 minecraft:brown_terracotta
setblock 246 24 466 minecraft:light[level=12]
setblock 246 24 474 minecraft:light[level=12]
setblock 246 24 482 minecraft:light[level=12]
setblock 246 24 490 minecraft:light[level=12]
setblock 246 24 498 minecraft:light[level=12]
setblock 254 24 464 minecraft:bone_block
setblock 254 24 466 minecraft:light[level=12]
setblock 254 24 474 minecraft:light[level=12]
setblock 254 24 482 minecraft:light[level=12]
fill 254 24 503 255 24 503 minecraft:bone_block
fill 255 24 464 255 27 464 minecraft:brown_terracotta
fill 255 24 504 255 27 504 minecraft:brown_terracotta
fill 256 24 503 256 27 503 minecraft:brown_terracotta
setblock 258 24 465 minecraft:bone_block
setblock 259 24 464 minecraft:bone_block
fill 259 24 465 259 25 465 minecraft:brown_terracotta
setblock 259 24 504 minecraft:bone_block
fill 260 24 464 260 27 464 minecraft:brown_terracotta
setblock 260 24 503 minecraft:bone_block
fill 260 24 504 260 27 504 minecraft:brown_terracotta
fill 261 24 503 261 27 503 minecraft:brown_terracotta
setblock 262 24 466 minecraft:light[level=12]
setblock 262 24 474 minecraft:light[level=12]
setblock 262 24 482 minecraft:light[level=12]
setblock 262 24 490 minecraft:light[level=12]
setblock 264 24 504 minecraft:bone_block
fill 265 24 504 265 27 504 minecraft:brown_terracotta
setblock 269 24 500 minecraft:soul_soil
setblock 270 24 466 minecraft:light[level=12]
setblock 270 24 474 minecraft:light[level=12]
setblock 270 24 482 minecraft:light[level=12]
setblock 270 24 490 minecraft:light[level=12]
setblock 270 24 498 minecraft:light[level=12]
fill 270 24 504 270 27 504 minecraft:brown_terracotta
setblock 271 24 498 minecraft:soul_soil
setblock 271 24 502 minecraft:soul_soil
setblock 273 24 500 minecraft:soul_soil
fill 273 24 503 273 25 503 minecraft:brown_terracotta
setblock 274 24 494 minecraft:bone_block
fill 274 24 495 274 27 495 minecraft:brown_terracotta
setblock 274 24 498 minecraft:brown_terracotta
setblock 274 24 499 minecraft:bone_block
fill 274 24 500 274 26 501 minecraft:brown_terracotta
setblock 274 24 504 minecraft:bone_block
setblock 275 24 474 minecraft:brown_terracotta
setblock 275 24 477 minecraft:brown_terracotta
setblock 275 24 478 minecraft:bone_block
setblock 275 24 489 minecraft:brown_terracotta
setblock 275 24 493 minecraft:bone_block
fill 275 24 494 275 27 494 minecraft:brown_terracotta
setblock 275 24 498 minecraft:bone_block
fill 275 24 499 275 27 499 minecraft:brown_terracotta
setblock 275 24 503 minecraft:bone_block
fill 275 24 504 275 27 504 minecraft:brown_terracotta
setblock 276 24 472 minecraft:bone_block
fill 276 24 473 276 27 473 minecraft:brown_terracotta
setblock 276 24 477 minecraft:bone_block
fill 276 24 478 276 24 481 minecraft:brown_terracotta
setblock 276 24 482 minecraft:bone_block
fill 276 24 483 276 27 483 minecraft:brown_terracotta
setblock 276 24 487 minecraft:bone_block
fill 276 24 488 276 27 488 minecraft:brown_terracotta
setblock 276 24 492 minecraft:bone_block
fill 276 24 493 276 27 493 minecraft:brown_terracotta
setblock 276 24 497 minecraft:bone_block
fill 276 24 498 276 27 498 minecraft:brown_terracotta
setblock 276 24 502 minecraft:bone_block
fill 276 24 503 276 27 503 minecraft:brown_terracotta
setblock 236 25 471 minecraft:bone_block
fill 236 25 472 236 28 472 minecraft:brown_terracotta
setblock 236 25 476 minecraft:bone_block
fill 236 25 477 236 28 477 minecraft:brown_terracotta
setblock 236 25 481 minecraft:bone_block
fill 236 25 482 236 28 482 minecraft:brown_terracotta
setblock 236 25 486 minecraft:bone_block
fill 236 25 487 236 28 487 minecraft:brown_terracotta
setblock 236 25 491 minecraft:bone_block
fill 236 25 492 236 28 492 minecraft:brown_terracotta
setblock 236 25 496 minecraft:bone_block
fill 236 25 497 236 28 497 minecraft:brown_terracotta
setblock 236 25 501 minecraft:bone_block
fill 236 25 502 236 28 502 minecraft:brown_terracotta
setblock 237 25 471 minecraft:brown_terracotta
setblock 237 25 475 minecraft:bone_block
fill 237 25 476 237 28 476 minecraft:brown_terracotta
setblock 237 25 480 minecraft:bone_block
fill 237 25 481 237 28 481 minecraft:brown_terracotta
setblock 237 25 485 minecraft:bone_block
fill 237 25 486 237 28 486 minecraft:brown_terracotta
setblock 237 25 490 minecraft:bone_block
fill 237 25 491 237 26 491 minecraft:brown_terracotta
setblock 237 25 495 minecraft:bone_block
fill 237 25 496 237 28 496 minecraft:brown_terracotta
setblock 237 25 500 minecraft:bone_block
fill 237 25 501 237 28 501 minecraft:brown_terracotta
setblock 238 25 474 minecraft:bone_block
fill 238 25 475 238 28 475 minecraft:brown_terracotta
setblock 238 25 479 minecraft:bone_block
fill 238 25 480 238 28 480 minecraft:brown_terracotta
setblock 238 25 494 minecraft:bone_block
setblock 238 25 495 minecraft:brown_terracotta
setblock 253 25 464 minecraft:bone_block
setblock 253 25 504 minecraft:bone_block
fill 254 25 464 254 28 464 minecraft:brown_terracotta
fill 254 25 503 254 26 503 minecraft:bone_block
fill 254 25 504 254 28 504 minecraft:brown_terracotta
fill 255 25 503 255 28 503 minecraft:brown_terracotta
setblock 257 25 465 minecraft:bone_block
setblock 258 25 464 minecraft:bone_block
fill 258 25 465 258 26 465 minecraft:brown_terracotta
setblock 258 25 504 minecraft:bone_block
fill 259 25 464 259 28 464 minecraft:brown_terracotta
setblock 259 25 503 minecraft:bone_block
fill 259 25 504 259 28 504 minecraft:brown_terracotta
fill 260 25 503 260 28 503 minecraft:brown_terracotta
setblock 263 25 504 minecraft:bone_block
fill 264 25 504 264 28 504 minecraft:brown_terracotta
setblock 273 25 504 minecraft:bone_block
setblock 274 25 493 minecraft:bone_block
fill 274 25 494 274 28 494 minecraft:brown_terracotta
setblock 274 25 498 minecraft:bone_block
fill 274 25 499 274 28 499 minecraft:brown_terracotta
setblock 274 25 503 minecraft:bone_block
fill 274 25 504 274 28 504 minecraft:brown_terracotta
setblock 275 25 476 minecraft:brown_terracotta
setblock 275 25 477 minecraft:bone_block
fill 275 25 478 276 26 479 minecraft:brown_terracotta
setblock 275 25 492 minecraft:bone_block
fill 275 25 493 275 28 493 minecraft:brown_terracotta
setblock 275 25 497 minecraft:bone_block
fill 275 25 498 275 28 498 minecraft:brown_terracotta
setblock 275 25 502 minecraft:bone_block
fill 275 25 503 275 28 503 minecraft:brown_terracotta
setblock 276 25 471 minecraft:bone_block
fill 276 25 472 276 28 472 minecraft:brown_terracotta
setblock 276 25 476 minecraft:bone_block
fill 276 25 477 276 28 477 minecraft:brown_terracotta
setblock 276 25 480 minecraft:brown_terracotta
setblock 276 25 481 minecraft:bone_block
fill 276 25 482 276 28 482 minecraft:brown_terracotta
setblock 276 25 486 minecraft:bone_block
fill 276 25 487 276 28 487 minecraft:brown_terracotta
setblock 276 25 491 minecraft:bone_block
fill 276 25 492 276 28 492 minecraft:brown_terracotta
setblock 276 25 496 minecraft:bone_block
fill 276 25 497 276 28 497 minecraft:brown_terracotta
setblock 276 25 501 minecraft:bone_block
fill 276 25 502 276 28 502 minecraft:brown_terracotta
setblock 236 26 470 minecraft:bone_block
fill 236 26 471 236 29 471 minecraft:brown_terracotta
setblock 236 26 475 minecraft:bone_block
fill 236 26 476 236 29 476 minecraft:brown_terracotta
setblock 236 26 480 minecraft:bone_block
fill 236 26 481 236 29 481 minecraft:brown_terracotta
setblock 236 26 485 minecraft:bone_block
fill 236 26 486 236 29 486 minecraft:brown_terracotta
setblock 236 26 490 minecraft:bone_block
fill 236 26 491 236 29 491 minecraft:brown_terracotta
setblock 236 26 495 minecraft:bone_block
fill 236 26 496 236 29 496 minecraft:brown_terracotta
setblock 236 26 500 minecraft:bone_block
fill 236 26 501 236 29 501 minecraft:brown_terracotta
setblock 237 26 474 minecraft:bone_block
fill 237 26 475 237 29 475 minecraft:brown_terracotta
setblock 237 26 479 minecraft:bone_block
fill 237 26 480 237 29 480 minecraft:brown_terracotta
setblock 237 26 484 minecraft:bone_block
fill 237 26 485 237 29 485 minecraft:brown_terracotta
setblock 237 26 489 minecraft:bone_block
setblock 237 26 490 minecraft:brown_terracotta
setblock 237 26 494 minecraft:bone_block
fill 237 26 495 237 28 495 minecraft:brown_terracotta
setblock 237 26 499 minecraft:bone_block
fill 237 26 500 237 29 500 minecraft:brown_terracotta
setblock 237 26 504 minecraft:bone_block
fill 238 26 474 238 27 474 minecraft:brown_terracotta
setblock 238 26 478 minecraft:bone_block
fill 238 26 479 238 29 479 minecraft:brown_terracotta
setblock 252 26 464 minecraft:bone_block
fill 253 26 464 253 29 464 minecraft:brown_terracotta
fill 253 26 504 253 29 504 minecraft:brown_terracotta
setblock 256 26 465 minecraft:bone_block
setblock 257 26 464 minecraft:bone_block
fill 257 26 465 257 29 465 minecraft:brown_terracotta
setblock 257 26 504 minecraft:bone_block
fill 258 26 464 258 29 464 minecraft:brown_terracotta
setblock 258 26 503 minecraft:bone_block
fill 258 26 504 258 29 504 minecraft:brown_terracotta
fill 259 26 503 259 29 503 minecraft:brown_terracotta
setblock 262 26 504 minecraft:bone_block
fill 263 26 504 263 29 504 minecraft:brown_terracotta
fill 269 26 504 269 28 504 minecraft:brown_terracotta
setblock 272 26 503 minecraft:brown_terracotta
setblock 272 26 504 minecraft:bone_block
setblock 273 26 503 minecraft:bone_block
fill 273 26 504 273 29 504 minecraft:brown_terracotta
setblock 274 26 497 minecraft:bone_block
fill 274 26 498 274 29 498 minecraft:brown_terracotta
setblock 274 26 502 minecraft:bone_block
fill 274 26 503 274 29 503 minecraft:brown_terracotta
setblock 275 26 476 minecraft:bone_block
fill 275 26 477 275 29 477 minecraft:brown_terracotta
setblock 275 26 480 minecraft:brown_terracotta
setblock 275 26 481 minecraft:bone_block
setblock 275 26 491 minecraft:bone_block
fill 275 26 492 275 29 492 minecraft:brown_terracotta
setblock 275 26 496 minecraft:bone_block
fill 275 26 497 275 29 497 minecraft:brown_terracotta
setblock 275 26 501 minecraft:bone_block
fill 275 26 502 275 29 502 minecraft:brown_terracotta
setblock 276 26 471 minecraft:brown_terracotta
setblock 276 26 475 minecraft:bone_block
fill 276 26 476 276 29 476 minecraft:brown_terracotta
setblock 276 26 480 minecraft:bone_block
fill 276 26 481 276 29 481 minecraft:brown_terracotta
setblock 276 26 485 minecraft:bone_block
fill 276 26 486 276 29 486 minecraft:brown_terracotta
setblock 276 26 490 minecraft:bone_block
fill 276 26 491 276 29 491 minecraft:brown_terracotta
setblock 276 26 495 minecraft:bone_block
fill 276 26 496 276 29 496 minecraft:brown_terracotta
setblock 276 26 500 minecraft:bone_block
fill 276 26 501 276 29 501 minecraft:brown_terracotta
fill 236 27 470 236 30 470 minecraft:brown_terracotta
setblock 236 27 474 minecraft:bone_block
fill 236 27 475 236 30 475 minecraft:brown_terracotta
setblock 236 27 479 minecraft:bone_block
fill 236 27 480 236 30 480 minecraft:brown_terracotta
setblock 236 27 484 minecraft:bone_block
fill 236 27 485 236 30 485 minecraft:brown_terracotta
setblock 236 27 489 minecraft:bone_block
fill 236 27 490 236 30 490 minecraft:brown_terracotta
setblock 236 27 494 minecraft:bone_block
fill 236 27 495 236 30 495 minecraft:brown_terracotta
setblock 236 27 499 minecraft:bone_block
fill 236 27 500 236 30 500 minecraft:brown_terracotta
setblock 236 27 504 minecraft:bone_block
setblock 237 27 473 minecraft:bone_block
fill 237 27 474 237 30 474 minecraft:brown_terracotta
setblock 237 27 478 minecraft:bone_block
fill 237 27 479 237 30 479 minecraft:brown_terracotta
setblock 237 27 483 minecraft:bone_block
fill 237 27 484 237 30 484 minecraft:brown_terracotta
setblock 237 27 493 minecraft:bone_block
fill 237 27 494 237 28 494 minecraft:brown_terracotta
setblock 237 27 498 minecraft:bone_block
fill 237 27 499 237 30 499 minecraft:brown_terracotta
fill 237 27 504 237 30 504 minecraft:brown_terracotta
setblock 238 27 477 minecraft:bone_block
fill 238 27 478 238 30 478 minecraft:brown_terracotta
setblock 238 27 482 minecraft:bone_block
fill 241 27 491 241 28 491 minecraft:bone_block
setblock 251 27 464 minecraft:bone_block
fill 252 27 464 252 30 464 minecraft:brown_terracotta
setblock 252 27 503 minecraft:bone_block
fill 252 27 504 252 30 504 minecraft:brown_terracotta
fill 253 27 502 255 27 502 minecraft:bone_block
fill 253 27 503 254 29 503 minecraft:brown_terracotta
setblock 254 27 465 minecraft:brown_terracotta
setblock 255 27 465 minecraft:bone_block
setblock 256 27 464 minecraft:bone_block
fill 256 27 465 256 30 465 minecraft:brown_terracotta
fill 256 27 502 257 27 502 minecraft:brown_terracotta
setblock 256 27 504 minecraft:bone_block
fill 257 27 464 257 30 464 minecraft:brown_terracotta
setblock 257 27 503 minecraft:bone_block
fill 257 27 504 257 30 504 minecraft:brown_terracotta
setblock 258 27 502 minecraft:bone_block
fill 258 27 503 258 30 503 minecraft:brown_terracotta
fill 259 27 502 259 30 502 minecraft:brown_terracotta
setblock 261 27 464 minecraft:bone_block
setblock 261 27 504 minecraft:bone_block
setblock 262 27 503 minecraft:bone_block
fill 262 27 504 262 30 504 minecraft:brown_terracotta
setblock 266 27 504 minecraft:bone_block
fill 267 27 504 268 29 504 minecraft:brown_terracotta
setblock 271 27 503 minecraft:brown_terracotta
setblock 271 27 504 minecraft:bone_block
setblock 272 27 503 minecraft:bone_block
fill 272 27 504 272 30 504 minecraft:brown_terracotta
setblock 273 27 502 minecraft:bone_block
fill 273 27 503 273 30 503 minecraft:brown_terracotta
setblock 274 27 496 minecraft:bone_block
fill 274 27 497 274 30 497 minecraft:brown_terracotta
setblock 274 27 500 minecraft:brown_terracotta
setblock 274 27 501 minecraft:bone_block
fill 274 27 502 274 30 502 minecraft:brown_terracotta
setblock 275 27 475 minecraft:bone_block
fill 275 27 476 275 30 476 minecraft:brown_terracotta
fill 275 27 478 275 27 479 minecraft:brown_terracotta
setblock 275 27 480 minecraft:bone_block
fill 275 27 481 275 28 483 minecraft:brown_terracotta
setblock 275 27 490 minecraft:bone_block
fill 275 27 491 275 30 491 minecraft:brown_terracotta
setblock 275 27 495 minecraft:bone_block
fill 275 27 496 275 30 496 minecraft:brown_terracotta
setblock 275 27 500 minecraft:bone_block
fill 275 27 501 275 30 501 minecraft:brown_terracotta
setblock 276 27 474 minecraft:bone_block
fill 276 27 475 276 30 475 minecraft:brown_terracotta
setblock 276 27 478 minecraft:brown_terracotta
setblock 276 27 479 minecraft:bone_block
fill 276 27 480 276 30 480 minecraft:brown_terracotta
setblock 276 27 484 minecraft:bone_block
fill 276 27 485 276 30 485 minecraft:brown_terracotta
setblock 276 27 489 minecraft:bone_block
fill 276 27 490 276 30 490 minecraft:brown_terracotta
setblock 276 27 494 minecraft:bone_block
fill 276 27 495 276 30 495 minecraft:brown_terracotta
setblock 276 27 499 minecraft:bone_block
fill 276 27 500 276 30 500 minecraft:brown_terracotta
setblock 276 27 504 minecraft:bone_block
setblock 236 28 473 minecraft:bone_block
fill 236 28 474 236 31 474 minecraft:brown_terracotta
setblock 236 28 478 minecraft:bone_block
fill 236 28 479 236 31 479 minecraft:brown_terracotta
setblock 236 28 483 minecraft:bone_block
fill 236 28 484 236 31 484 minecraft:brown_terracotta
setblock 236 28 488 minecraft:bone_block
fill 236 28 489 236 31 489 minecraft:brown_terracotta
setblock 236 28 493 minecraft:bone_block
fill 236 28 494 236 31 494 minecraft:brown_terracotta
setblock 236 28 498 minecraft:bone_block
fill 236 28 499 236 31 499 minecraft:brown_terracotta
setblock 236 28 503 minecraft:bone_block
fill 236 28 504 236 31 504 minecraft:brown_terracotta
setblock 237 28 472 minecraft:bone_block
fill 237 28 473 237 31 473 minecraft:brown_terracotta
setblock 237 28 477 minecraft:bone_block
fill 237 28 478 237 31 478 minecraft:brown_terracotta
setblock 237 28 482 minecraft:bone_block
fill 237 28 483 238 30 483 minecraft:brown_terracotta
setblock 237 28 487 minecraft:bone_block
setblock 237 28 497 minecraft:bone_block
fill 237 28 498 237 31 498 minecraft:brown_terracotta
setblock 237 28 502 minecraft:bone_block
setblock 238 28 476 minecraft:bone_block
fill 238 28 477 238 31 477 minecraft:brown_terracotta
setblock 238 28 481 minecraft:bone_block
fill 238 28 482 238 31 482 minecraft:brown_terracotta
fill 238 28 504 238 29 504 minecraft:brown_terracotta
setblock 250 28 464 minecraft:bone_block
setblock 250 28 504 minecraft:bone_block
fill 251 28 464 251 31 464 minecraft:brown_terracotta
fill 251 28 504 251 31 504 minecraft:brown_terracotta
fill 252 28 503 252 31 503 minecraft:brown_terracotta
setblock 253 28 465 minecraft:brown_terracotta
fill 253 28 502 254 28 502 minecraft:bone_block
setblock 254 28 465 minecraft:bone_block
setblock 255 28 464 minecraft:bone_block
fill 255 28 465 255 31 465 minecraft:brown_terracotta
fill 255 28 502 256 28 502 minecraft:brown_terracotta
setblock 255 28 504 minecraft:bone_block
fill 256 28 464 256 31 464 minecraft:brown_terracotta
setblock 256 28 503 minecraft:bone_block
fill 256 28 504 256 31 504 minecraft:brown_terracotta
setblock 257 28 502 minecraft:bone_block
fill 257 28 503 257 31 503 minecraft:brown_terracotta
setblock 258 28 465 minecraft:brown_terracotta
fill 258 28 502 258 31 502 minecraft:brown_terracotta
setblock 260 28 464 minecraft:bone_block
setblock 260 28 504 minecraft:bone_block
fill 261 28 464 261 31 464 minecraft:brown_terracotta
setblock 261 28 503 minecraft:bone_block
fill 261 28 504 261 31 504 minecraft:brown_terracotta
fill 262 28 503 263 30 503 minecraft:brown_terracotta
setblock 265 28 504 minecraft:bone_block
fill 266 28 504 266 31 504 minecraft:brown_terracotta
fill 269 28 503 270 28 503 minecraft:brown_terracotta
setblock 270 28 504 minecraft:bone_block
setblock 271 28 503 minecraft:bone_block
fill 271 28 504 271 31 504 minecraft:brown_terracotta
setblock 272 28 502 minecraft:bone_block
fill 272 28 503 272 31 503 minecraft:brown_terracotta
fill 273 28 502 273 31 502 minecraft:brown_terracotta
setblock 274 28 495 minecraft:bone_block
fill 274 28 496 274 31 496 minecraft:brown_terracotta
setblock 274 28 500 minecraft:bone_block
fill 274 28 501 274 31 501 minecraft:brown_terracotta
fill 275 28 475 275 31 475 minecraft:brown_terracotta
setblock 275 28 478 minecraft:brown_terracotta
setblock 275 28 479 minecraft:bone_block
fill 275 28 480 275 31 480 minecraft:brown_terracotta
setblock 275 28 484 minecraft:bone_block
fill 275 28 485 275 30 486 minecraft:brown_terracotta
setblock 275 28 489 minecraft:bone_block
fill 275 28 490 275 31 490 minecraft:brown_terracotta
setblock 275 28 494 minecraft:bone_block
fill 275 28 495 275 31 495 minecraft:brown_terracotta
setblock 275 28 499 minecraft:bone_block
fill 275 28 500 275 31 500 minecraft:brown_terracotta
setblock 275 28 504 minecraft:bone_block
setblock 276 28 473 minecraft:bone_block
fill 276 28 474 276 31 474 minecraft:brown_terracotta
setblock 276 28 478 minecraft:bone_block
fill 276 28 479 276 31 479 minecraft:brown_terracotta
setblock 276 28 483 minecraft:bone_block
fill 276 28 484 276 31 484 minecraft:brown_terracotta
setblock 276 28 488 minecraft:bone_block
fill 276 28 489 276 31 489 minecraft:brown_terracotta
setblock 276 28 493 minecraft:bone_block
fill 276 28 494 276 31 494 minecraft:brown_terracotta
setblock 276 28 498 minecraft:bone_block
fill 276 28 499 276 31 499 minecraft:brown_terracotta
setblock 276 28 503 minecraft:bone_block
fill 276 28 504 276 31 504 minecraft:brown_terracotta
setblock 236 29 472 minecraft:bone_block
fill 236 29 473 236 32 473 minecraft:brown_terracotta
setblock 236 29 477 minecraft:bone_block
fill 236 29 478 236 32 478 minecraft:brown_terracotta
setblock 236 29 482 minecraft:bone_block
fill 236 29 483 236 32 483 minecraft:brown_terracotta
setblock 236 29 487 minecraft:bone_block
fill 236 29 488 236 32 488 minecraft:brown_terracotta
setblock 236 29 492 minecraft:bone_block
fill 236 29 493 236 32 493 minecraft:brown_terracotta
setblock 236 29 497 minecraft:bone_block
fill 236 29 498 236 32 498 minecraft:brown_terracotta
setblock 236 29 502 minecraft:bone_block
fill 236 29 503 236 32 503 minecraft:brown_terracotta
setblock 237 29 476 minecraft:bone_block
fill 237 29 477 237 32 477 minecraft:brown_terracotta
setblock 237 29 481 minecraft:bone_block
fill 237 29 482 237 32 482 minecraft:brown_terracotta
setblock 237 29 486 minecraft:bone_block
fill 237 29 487 237 32 487 minecraft:brown_terracotta
setblock 237 29 496 minecraft:bone_block
fill 237 29 497 237 30 497 minecraft:brown_terracotta
setblock 237 29 501 minecraft:bone_block
fill 237 29 502 237 32 502 minecraft:brown_terracotta
setblock 238 29 475 minecraft:bone_block
fill 238 29 476 238 32 476 minecraft:brown_terracotta
setblock 238 29 480 minecraft:bone_block
fill 238 29 481 238 32 481 minecraft:brown_terracotta
setblock 249 29 464 minecraft:bone_block
setblock 249 29 504 minecraft:bone_block
fill 250 29 464 250 32 464 minecraft:brown_terracotta
fill 250 29 504 250 32 504 minecraft:brown_terracotta
fill 251 29 503 251 32 503 minecraft:brown_terracotta
setblock 252 29 465 minecraft:brown_terracotta
setblock 253 29 465 minecraft:bone_block
fill 253 29 502 255 29 502 minecraft:brown_terracotta
setblock 254 29 464 minecraft:bone_block
fill 254 29 465 254 32 465 minecraft:brown_terracotta
setblock 254 29 504 minecraft:bone_block
fill 255 29 464 255 32 464 minecraft:brown_terracotta
setblock 255 29 503 minecraft:bone_block
fill 255 29 504 255 32 504 minecraft:brown_terracotta
setblock 256 29 502 minecraft:bone_block
fill 256 29 503 256 32 503 minecraft:brown_terracotta
fill 257 29 502 257 32 502 minecraft:brown_terracotta
setblock 258 29 465 minecraft:bone_block
setblock 259 29 464 minecraft:bone_block
setblock 259 29 504 minecraft:bone_block
fill 260 29 464 260 32 464 minecraft:brown_terracotta
setblock 260 29 502 minecraft:brown_terracotta
setblock 260 29 503 minecraft:bone_block
fill 260 29 504 260 32 504 minecraft:brown_terracotta
fill 261 29 503 261 32 503 minecraft:brown_terracotta
setblock 264 29 503 minecraft:brown_terracotta
setblock 264 29 504 minecraft:bone_block
setblock 265 29 503 minecraft:bone_block
fill 265 29 504 265 32 504 minecraft:brown_terracotta
fill 266 29 503 269 29 503 minecraft:brown_terracotta
setblock 269 29 504 minecraft:bone_block
setblock 270 29 502 minecraft:brown_terracotta
setblock 270 29 503 minecraft:bone_block
fill 270 29 504 270 32 504 minecraft:brown_terracotta
setblock 271 29 502 minecraft:bone_block
fill 271 29 503 271 32 503 minecraft:brown_terracotta
fill 272 29 502 272 32 502 minecraft:brown_terracotta
setblock 273 29 499 minecraft:brown_terracotta
setblock 273 29 500 minecraft:bone_block
setblock 274 29 479 minecraft:bone_block
fill 274 29 480 274 30 482 minecraft:brown_terracotta
setblock 274 29 494 minecraft:bone_block
fill 274 29 495 274 32 495 minecraft:brown_terracotta
setblock 274 29 499 minecraft:bone_block
fill 274 29 500 274 32 500 minecraft:brown_terracotta
setblock 274 29 504 minecraft:bone_block
setblock 275 29 478 minecraft:bone_block
fill 275 29 479 275 32 479 minecraft:brown_terracotta
fill 275 29 481 275 29 482 minecraft:brown_terracotta
setblock 275 29 483 minecraft:bone_block
fill 275 29 484 275 32 484 minecraft:brown_terracotta
setblock 275 29 487 minecraft:brown_terracotta
setblock 275 29 488 minecraft:bone_block
fill 275 29 489 275 32 489 minecraft:brown_terracotta
setblock 275 29 493 minecraft:bone_block
fill 275 29 494 275 32 494 minecraft:brown_terracotta
setblock 275 29 498 minecraft:bone_block
fill 275 29 499 275 32 499 minecraft:brown_terracotta
setblock 275 29 503 minecraft:bone_block
fill 275 29 504 275 32 504 minecraft:brown_terracotta
setblock 276 29 472 minecraft:bone_block
fill 276 29 473 276 32 473 minecraft:brown_terracotta
setblock 276 29 477 minecraft:bone_block
fill 276 29 478 276 32 478 minecraft:brown_terracotta
setblock 276 29 482 minecraft:bone_block
fill 276 29 483 276 32 483 minecraft:brown_terracotta
setblock 276 29 487 minecraft:bone_block
fill 276 29 488 276 32 488 minecraft:brown_terracotta
setblock 276 29 492 minecraft:bone_block
fill 276 29 493 276 32 493 minecraft:brown_terracotta
setblock 276 29 497 minecraft:bone_block
fill 276 29 498 276 32 498 minecraft:brown_terracotta
setblock 276 29 502 minecraft:bone_block
fill 276 29 503 276 32 503 minecraft:brown_terracotta
fill 236 30 464 236 30 465 minecraft:brown_terracotta
setblock 236 30 466 minecraft:bone_block
fill 236 30 469 236 31 469 minecraft:brown_terracotta
setblock 236 30 471 minecraft:bone_block
fill 236 30 472 236 33 472 minecraft:brown_terracotta
setblock 236 30 476 minecraft:bone_block
fill 236 30 477 236 33 477 minecraft:brown_terracotta
setblock 236 30 481 minecraft:bone_block
fill 236 30 482 236 33 482 minecraft:brown_terracotta
setblock 236 30 486 minecraft:bone_block
fill 236 30 487 236 33 487 minecraft:brown_terracotta
setblock 236 30 491 minecraft:bone_block
fill 236 30 492 236 33 492 minecraft:brown_terracotta
setblock 236 30 496 minecraft:bone_block
fill 236 30 497 236 33 497 minecraft:brown_terracotta
setblock 236 30 501 minecraft:bone_block
fill 236 30 502 236 33 502 minecraft:brown_terracotta
setblock 237 30 464 minecraft:brown_terracotta
setblock 237 30 475 minecraft:bone_block
fill 237 30 476 237 33 476 minecraft:brown_terracotta
setblock 237 30 480 minecraft:bone_block
fill 237 30 481 237 33 481 minecraft:brown_terracotta
setblock 237 30 485 minecraft:bone_block
fill 237 30 486 237 33 486 minecraft:brown_terracotta
fill 237 30 488 237 31 488 minecraft:brown_terracotta
setblock 237 30 500 minecraft:bone_block
fill 237 30 501 237 33 501 minecraft:brown_terracotta
fill 237 30 503 237 31 503 minecraft:brown_terracotta
setblock 238 30 464 minecraft:bone_block
setblock 238 30 475 minecraft:brown_terracotta
setblock 238 30 479 minecraft:bone_block
fill 238 30 480 238 33 480 minecraft:brown_terracotta
setblock 238 30 484 minecraft:bone_block
setblock 238 30 504 minecraft:bone_block
fill 239 30 504 239 33 504 minecraft:brown_terracotta
fill 240 30 498 240 37 498 minecraft:bone_block
setblock 247 30 464 minecraft:brown_terracotta
setblock 248 30 464 minecraft:bone_block
setblock 248 30 504 minecraft:bone_block
fill 249 30 464 249 33 464 minecraft:brown_terracotta
fill 249 30 504 249 33 504 minecraft:brown_terracotta
fill 250 30 465 251 30 465 minecraft:brown_terracotta
fill 250 30 503 250 33 503 minecraft:brown_terracotta
setblock 252 30 465 minecraft:bone_block
fill 252 30 502 254 30 502 minecraft:brown_terracotta
setblock 253 30 464 minecraft:bone_block
fill 253 30 465 253 33 465 minecraft:brown_terracotta
fill 253 30 499 255 33 499 minecraft:soul_soil
setblock 253 30 503 minecraft:brown_terracotta
setblock 253 30 504 minecraft:bone_block
fill 254 30 464 254 33 464 minecraft:brown_terracotta
fill 254 30 498 254 33 498 minecraft:soul_soil
fill 254 30 500 254 33 500 minecraft:soul_soil
setblock 254 30 503 minecraft:bone_block
fill 254 30 504 254 33 504 minecraft:brown_terracotta
setblock 255 30 502 minecraft:bone_block
fill 255 30 503 255 33 503 minecraft:brown_terracotta
fill 256 30 502 256 33 502 minecraft:brown_terracotta
setblock 257 30 465 minecraft:bone_block
setblock 258 30 464 minecraft:bone_block
fill 258 30 465 258 33 465 minecraft:brown_terracotta
setblock 258 30 504 minecraft:bone_block
fill 259 30 464 259 33 464 minecraft:brown_terracotta
setblock 259 30 503 minecraft:bone_block
fill 259 30 504 259 33 504 minecraft:brown_terracotta
setblock 260 30 502 minecraft:bone_block
fill 260 30 503 260 33 503 minecraft:brown_terracotta
fill 261 30 502 261 33 502 minecraft:brown_terracotta
setblock 262 30 464 minecraft:brown_terracotta
setblock 263 30 504 minecraft:bone_block
setblock 264 30 503 minecraft:bone_block
fill 264 30 504 264 33 504 minecraft:brown_terracotta
fill 265 30 503 268 30 503 minecraft:brown_terracotta
setblock 267 30 504 minecraft:brown_terracotta
setblock 268 30 504 minecraft:bone_block
setblock 269 30 502 minecraft:brown_terracotta
setblock 269 30 503 minecraft:bone_block
fill 269 30 504 269 33 504 minecraft:brown_terracotta
setblock 270 30 502 minecraft:bone_block
fill 270 30 503 270 33 503 minecraft:brown_terracotta
fill 271 30 464 272 30 464 minecraft:brown_terracotta
fill 271 30 502 271 33 502 minecraft:brown_terracotta
fill 272 30 501 273 32 501 minecraft:brown_terracotta
setblock 273 30 464 minecraft:bone_block
setblock 273 30 498 minecraft:brown_terracotta
setblock 273 30 499 minecraft:bone_block
fill 273 30 500 273 33 500 minecraft:brown_terracotta
setblock 273 30 504 minecraft:bone_block
fill 274 30 464 276 31 464 minecraft:brown_terracotta
setblock 274 30 478 minecraft:bone_block
fill 274 30 479 274 33 479 minecraft:brown_terracotta
setblock 274 30 483 minecraft:bone_block
fill 274 30 484 274 32 485 minecraft:brown_terracotta
fill 274 30 494 274 33 494 minecraft:brown_terracotta
setblock 274 30 498 minecraft:bone_block
fill 274 30 499 274 33 499 minecraft:brown_terracotta
setblock 274 30 503 minecraft:bone_block
fill 274 30 504 274 33 504 minecraft:brown_terracotta
setblock 275 30 477 minecraft:bone_block
fill 275 30 478 275 33 478 minecraft:brown_terracotta
setblock 275 30 481 minecraft:brown_terracotta
setblock 275 30 482 minecraft:bone_block
fill 275 30 483 275 33 483 minecraft:brown_terracotta
setblock 275 30 487 minecraft:bone_block
fill 275 30 488 275 33 488 minecraft:brown_terracotta
setblock 275 30 492 minecraft:bone_block
fill 275 30 493 275 33 493 minecraft:brown_terracotta
setblock 275 30 497 minecraft:bone_block
fill 275 30 498 275 33 498 minecraft:brown_terracotta
setblock 275 30 502 minecraft:bone_block
fill 275 30 503 275 33 503 minecraft:brown_terracotta
fill 276 30 472 276 33 472 minecraft:brown_terracotta
setblock 276 30 476 minecraft:bone_block
fill 276 30 477 276 33 477 minecraft:brown_terracotta
setblock 276 30 481 minecraft:bone_block
fill 276 30 482 276 33 482 minecraft:brown_terracotta
setblock 276 30 486 minecraft:bone_block
fill 276 30 487 276 33 487 minecraft:brown_terracotta
setblock 276 30 491 minecraft:bone_block
fill 276 30 492 276 33 492 minecraft:brown_terracotta
setblock 276 30 496 minecraft:bone_block
fill 276 30 497 276 33 497 minecraft:brown_terracotta
setblock 276 30 501 minecraft:bone_block
fill 276 30 502 276 33 502 minecraft:brown_terracotta
setblock 236 31 464 minecraft:brown_terracotta
setblock 236 31 465 minecraft:bone_block
fill 236 31 466 236 32 468 minecraft:brown_terracotta
setblock 236 31 470 minecraft:bone_block
fill 236 31 471 236 34 471 minecraft:brown_terracotta
setblock 236 31 475 minecraft:bone_block
fill 236 31 476 236 34 476 minecraft:brown_terracotta
setblock 236 31 480 minecraft:bone_block
fill 236 31 481 236 34 481 minecraft:brown_terracotta
setblock 236 31 485 minecraft:bone_block
fill 236 31 486 236 34 486 minecraft:brown_terracotta
setblock 236 31 490 minecraft:bone_block
fill 236 31 491 236 34 491 minecraft:brown_terracotta
setblock 236 31 495 minecraft:bone_block
fill 236 31 496 236 34 496 minecraft:brown_terracotta
setblock 236 31 500 minecraft:bone_block
fill 236 31 501 236 34 501 minecraft:brown_terracotta
setblock 237 31 464 minecraft:bone_block
setblock 237 31 474 minecraft:bone_block
fill 237 31 475 237 34 475 minecraft:brown_terracotta
setblock 237 31 479 minecraft:bone_block
fill 237 31 480 237 34 480 minecraft:brown_terracotta
setblock 237 31 483 minecraft:brown_terracotta
setblock 237 31 484 minecraft:bone_block
fill 237 31 485 237 34 485 minecraft:brown_terracotta
setblock 237 31 499 minecraft:bone_block
fill 237 31 500 237 32 500 minecraft:brown_terracotta
setblock 237 31 504 minecraft:bone_block
fill 238 31 464 239 33 464 minecraft:brown_terracotta
setblock 238 31 478 minecraft:bone_block
fill 238 31 479 238 34 479 minecraft:brown_terracotta
setblock 238 31 483 minecraft:bone_block
fill 238 31 484 238 34 484 minecraft:brown_terracotta
fill 238 31 504 238 34 504 minecraft:brown_terracotta
fill 240 31 504 240 32 504 minecraft:brown_terracotta
fill 245 31 464 246 31 464 minecraft:brown_terracotta
setblock 246 31 504 minecraft:brown_terracotta
setblock 247 31 464 minecraft:bone_block
setblock 247 31 504 minecraft:bone_block
fill 248 31 464 248 34 464 minecraft:brown_terracotta
setblock 248 31 503 minecraft:bone_block
fill 248 31 504 248 34 504 minecraft:brown_terracotta
fill 249 31 465 250 31 465 minecraft:brown_terracotta
fill 249 31 503 249 34 503 minecraft:brown_terracotta
setblock 251 31 465 minecraft:bone_block
fill 251 31 502 253 31 502 minecraft:brown_terracotta
setblock 252 31 464 minecraft:bone_block
fill 252 31 465 252 33 466 minecraft:brown_terracotta
setblock 252 31 504 minecraft:bone_block
fill 253 31 464 253 34 464 minecraft:brown_terracotta
fill 253 31 466 254 31 466 minecraft:brown_terracotta
setblock 253 31 503 minecraft:bone_block
fill 253 31 504 253 34 504 minecraft:brown_terracotta
setblock 254 31 501 minecraft:brown_terracotta
setblock 254 31 502 minecraft:bone_block
fill 254 31 503 254 34 503 minecraft:brown_terracotta
setblock 255 31 466 minecraft:bone_block
setblock 255 31 501 minecraft:bone_block
fill 255 31 502 255 34 502 minecraft:brown_terracotta
setblock 256 31 465 minecraft:bone_block
fill 256 31 501 256 33 501 minecraft:brown_terracotta
setblock 257 31 464 minecraft:bone_block
fill 257 31 465 257 34 465 minecraft:brown_terracotta
setblock 257 31 504 minecraft:bone_block
fill 258 31 464 258 34 464 minecraft:brown_terracotta
setblock 258 31 503 minecraft:bone_block
fill 258 31 504 258 34 504 minecraft:brown_terracotta
fill 259 31 465 259 32 465 minecraft:brown_terracotta
setblock 259 31 502 minecraft:bone_block
fill 259 31 503 259 34 503 minecraft:brown_terracotta
fill 260 31 502 260 34 502 minecraft:brown_terracotta
setblock 262 31 464 minecraft:bone_block
setblock 262 31 503 minecraft:brown_terracotta
setblock 262 31 504 minecraft:bone_block
fill 263 31 464 263 34 464 minecraft:brown_terracotta
setblock 263 31 503 minecraft:bone_block
fill 263 31 504 263 34 504 minecraft:brown_terracotta
fill 264 31 503 267 31 503 minecraft:brown_terracotta
fill 267 31 502 268 31 502 minecraft:brown_terracotta
setblock 267 31 504 minecraft:bone_block
setblock 268 31 503 minecraft:bone_block
fill 268 31 504 268 34 504 minecraft:brown_terracotta
fill 269 31 464 271 31 464 minecraft:brown_terracotta
setblock 269 31 502 minecraft:bone_block
fill 269 31 503 269 34 503 minecraft:brown_terracotta
fill 270 31 502 270 34 502 minecraft:brown_terracotta
fill 271 31 501 271 34 501 minecraft:brown_terracotta
setblock 272 31 464 minecraft:bone_block
setblock 272 31 504 minecraft:bone_block
fill 273 31 464 273 34 464 minecraft:brown_terracotta
setblock 273 31 498 minecraft:bone_block
fill 273 31 499 273 33 499 minecraft:brown_terracotta
setblock 273 31 503 minecraft:bone_block
fill 273 31 504 273 34 504 minecraft:brown_terracotta
setblock 274 31 477 minecraft:bone_block
fill 274 31 478 274 34 478 minecraft:brown_terracotta
fill 274 31 480 274 31 481 minecraft:brown_terracotta
setblock 274 31 482 minecraft:bone_block
schedule function dropper:buildpart/113_2 1t
