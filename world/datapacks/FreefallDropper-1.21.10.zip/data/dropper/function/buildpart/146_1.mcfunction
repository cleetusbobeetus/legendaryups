fill 133 146 621 133 146 629 minecraft:crying_obsidian
fill 136 146 634 136 186 635 minecraft:black_concrete
setblock 136 146 636 minecraft:white_concrete
fill 136 146 637 136 163 638 minecraft:black_concrete
fill 136 146 644 136 146 645 minecraft:crying_obsidian
fill 94 147 612 94 153 612 minecraft:black_concrete
setblock 94 147 623 minecraft:white_concrete
fill 94 147 626 94 215 626 minecraft:black_concrete
setblock 94 147 627 minecraft:amethyst_block
setblock 94 147 628 minecraft:black_concrete
fill 94 147 631 94 162 632 minecraft:black_concrete
setblock 94 147 633 minecraft:white_concrete
setblock 94 147 640 minecraft:amethyst_block
fill 94 147 644 94 153 644 minecraft:black_concrete
fill 98 147 604 98 153 604 minecraft:black_concrete
fill 100 147 617 101 148 618 minecraft:end_stone
fill 101 147 604 102 150 604 minecraft:black_concrete
setblock 103 147 604 minecraft:white_concrete
fill 108 147 646 108 153 646 minecraft:black_concrete
fill 114 147 604 114 153 604 minecraft:black_concrete
fill 124 147 646 124 153 646 minecraft:black_concrete
fill 130 147 604 130 153 604 minecraft:black_concrete
fill 133 147 604 133 153 604 minecraft:black_concrete
setblock 136 147 605 minecraft:white_concrete
fill 136 147 614 136 153 614 minecraft:black_concrete
fill 136 147 630 136 153 630 minecraft:black_concrete
fill 136 147 636 136 199 636 minecraft:black_concrete
fill 136 147 644 136 147 645 minecraft:black_concrete
fill 94 148 623 94 215 623 minecraft:black_concrete
fill 94 148 627 94 213 627 minecraft:black_concrete
setblock 94 148 628 minecraft:crying_obsidian
fill 94 148 633 94 213 633 minecraft:black_concrete
fill 94 148 640 94 218 640 minecraft:black_concrete
fill 103 148 604 103 194 604 minecraft:black_concrete
setblock 109 148 604 minecraft:white_concrete
setblock 136 148 605 minecraft:amethyst_block
fill 136 148 644 136 167 644 minecraft:black_concrete
setblock 136 148 645 minecraft:amethyst_block
fill 94 149 628 94 153 628 minecraft:black_concrete
fill 109 149 604 109 206 604 minecraft:black_concrete
setblock 119 149 646 minecraft:amethyst_block
fill 136 149 605 136 172 605 minecraft:black_concrete
fill 136 149 645 136 151 645 minecraft:black_concrete
fill 94 150 615 94 169 616 minecraft:black_concrete
setblock 94 150 617 minecraft:crying_obsidian
fill 94 150 618 94 216 621 minecraft:black_concrete
setblock 94 150 630 minecraft:amethyst_block
fill 104 150 613 105 151 614 minecraft:netherrack
setblock 105 150 604 minecraft:crying_obsidian
fill 119 150 646 119 160 646 minecraft:black_concrete
fill 136 150 623 136 150 624 minecraft:black_concrete
setblock 136 150 625 minecraft:amethyst_block
fill 136 150 626 136 160 627 minecraft:black_concrete
fill 94 151 617 94 201 617 minecraft:black_concrete
fill 94 151 630 94 168 630 minecraft:black_concrete
setblock 94 151 642 minecraft:amethyst_block
fill 94 151 643 94 166 643 minecraft:black_concrete
fill 94 151 646 94 214 646 minecraft:black_concrete
setblock 95 151 646 minecraft:amethyst_block
setblock 101 151 604 minecraft:white_concrete
fill 102 151 604 102 174 604 minecraft:black_concrete
fill 105 151 604 105 159 604 minecraft:black_concrete
setblock 110 151 604 minecraft:crying_obsidian
fill 136 151 623 136 166 623 minecraft:black_concrete
setblock 136 151 624 minecraft:white_concrete
fill 136 151 625 136 213 625 minecraft:black_concrete
setblock 94 152 642 minecraft:black_concrete
fill 95 152 646 95 162 646 minecraft:black_concrete
fill 101 152 604 101 181 604 minecraft:black_concrete
setblock 104 152 646 minecraft:white_concrete
fill 110 152 604 110 165 604 minecraft:black_concrete
setblock 116 152 604 minecraft:crying_obsidian
fill 116 152 607 116 153 608 minecraft:obsidian
fill 117 152 604 117 166 604 minecraft:black_concrete
setblock 136 152 613 minecraft:amethyst_block
setblock 136 152 617 minecraft:crying_obsidian
fill 136 152 620 136 219 620 minecraft:black_concrete
setblock 136 152 621 minecraft:white_concrete
fill 136 152 622 136 218 622 minecraft:black_concrete
fill 136 152 624 136 157 624 minecraft:black_concrete
setblock 136 152 629 minecraft:amethyst_block
setblock 136 152 645 minecraft:white_concrete
setblock 94 153 642 minecraft:white_concrete
fill 104 153 646 104 206 646 minecraft:black_concrete
fill 116 153 604 116 168 604 minecraft:black_concrete
fill 136 153 613 136 170 613 minecraft:black_concrete
fill 136 153 617 136 218 617 minecraft:black_concrete
fill 136 153 621 136 218 621 minecraft:black_concrete
fill 136 153 629 136 210 629 minecraft:black_concrete
fill 136 153 645 136 158 645 minecraft:black_concrete
fill 94 154 612 94 155 612 minecraft:purple_stained_glass
fill 94 154 628 94 155 628 minecraft:purple_stained_glass
fill 94 154 642 94 181 642 minecraft:black_concrete
fill 94 154 644 94 155 644 minecraft:purple_stained_glass
setblock 97 154 607 minecraft:light[level=14]
setblock 97 154 615 minecraft:light[level=14]
setblock 97 154 623 minecraft:light[level=14]
setblock 97 154 631 minecraft:light[level=14]
setblock 97 154 639 minecraft:light[level=14]
fill 98 154 604 98 155 604 minecraft:purple_stained_glass
setblock 105 154 607 minecraft:light[level=14]
setblock 105 154 615 minecraft:light[level=14]
setblock 105 154 623 minecraft:light[level=14]
setblock 105 154 631 minecraft:light[level=14]
setblock 105 154 639 minecraft:light[level=14]
fill 108 154 646 108 155 646 minecraft:purple_stained_glass
setblock 113 154 607 minecraft:light[level=14]
setblock 113 154 615 minecraft:light[level=14]
setblock 113 154 623 minecraft:light[level=14]
setblock 113 154 631 minecraft:light[level=14]
setblock 113 154 639 minecraft:light[level=14]
fill 114 154 604 114 155 604 minecraft:purple_stained_glass
setblock 121 154 607 minecraft:light[level=14]
setblock 121 154 615 minecraft:light[level=14]
setblock 121 154 623 minecraft:light[level=14]
setblock 121 154 631 minecraft:light[level=14]
setblock 121 154 639 minecraft:light[level=14]
fill 124 154 646 124 155 646 minecraft:purple_stained_glass
setblock 129 154 607 minecraft:light[level=14]
setblock 129 154 615 minecraft:light[level=14]
setblock 129 154 623 minecraft:light[level=14]
setblock 129 154 631 minecraft:light[level=14]
setblock 129 154 639 minecraft:light[level=14]
fill 130 154 604 130 155 604 minecraft:purple_stained_glass
setblock 133 154 604 minecraft:amethyst_block
fill 136 154 614 136 155 614 minecraft:purple_stained_glass
fill 136 154 630 136 155 630 minecraft:purple_stained_glass
fill 133 155 604 133 219 604 minecraft:black_concrete
fill 94 156 612 94 161 612 minecraft:black_concrete
fill 94 156 628 94 160 628 minecraft:black_concrete
setblock 94 156 634 minecraft:crying_obsidian
fill 94 156 644 94 161 644 minecraft:black_concrete
fill 98 156 604 98 161 604 minecraft:black_concrete
fill 108 156 646 108 161 646 minecraft:black_concrete
setblock 109 156 646 minecraft:crying_obsidian
fill 110 156 646 111 170 646 minecraft:black_concrete
fill 114 156 604 114 161 604 minecraft:black_concrete
fill 124 156 646 124 157 646 minecraft:black_concrete
fill 130 156 604 130 161 604 minecraft:black_concrete
fill 136 156 614 136 161 614 minecraft:black_concrete
fill 136 156 630 136 161 630 minecraft:black_concrete
fill 94 157 634 94 185 634 minecraft:black_concrete
fill 109 157 646 109 183 646 minecraft:black_concrete
fill 126 157 626 127 158 626 minecraft:netherrack
fill 136 157 610 136 194 610 minecraft:black_concrete
setblock 136 157 611 minecraft:white_concrete
fill 136 157 612 136 182 612 minecraft:black_concrete
setblock 124 158 646 minecraft:crying_obsidian
fill 136 158 611 136 169 611 minecraft:black_concrete
setblock 136 158 619 minecraft:amethyst_block
setblock 136 158 624 minecraft:white_concrete
fill 105 159 624 105 160 624 minecraft:netherrack
fill 124 159 646 124 161 646 minecraft:black_concrete
fill 136 159 619 136 214 619 minecraft:black_concrete
fill 136 159 624 136 178 624 minecraft:black_concrete
setblock 136 159 645 minecraft:crying_obsidian
fill 104 160 604 105 160 604 minecraft:white_concrete
fill 124 160 604 124 204 604 minecraft:black_concrete
setblock 125 160 604 minecraft:white_concrete
fill 126 160 604 127 171 604 minecraft:black_concrete
fill 136 160 645 136 202 645 minecraft:black_concrete
setblock 94 161 628 minecraft:white_concrete
fill 104 161 604 105 181 604 minecraft:black_concrete
fill 119 161 604 120 161 604 minecraft:black_concrete
setblock 119 161 646 minecraft:crying_obsidian
setblock 121 161 604 minecraft:crying_obsidian
fill 125 161 604 125 218 604 minecraft:black_concrete
setblock 136 161 626 minecraft:white_concrete
fill 136 161 627 136 218 627 minecraft:black_concrete
setblock 94 162 607 minecraft:white_concrete
fill 94 162 612 94 164 612 minecraft:purple_stained_glass
setblock 94 162 614 minecraft:amethyst_block
fill 94 162 628 94 164 628 minecraft:purple_stained_glass
fill 94 162 644 94 164 644 minecraft:purple_stained_glass
setblock 97 162 607 minecraft:light[level=14]
setblock 97 162 615 minecraft:light[level=14]
setblock 97 162 623 minecraft:light[level=14]
setblock 97 162 631 minecraft:light[level=14]
setblock 97 162 639 minecraft:light[level=14]
fill 98 162 604 98 164 604 minecraft:purple_stained_glass
setblock 105 162 607 minecraft:light[level=14]
setblock 105 162 615 minecraft:light[level=14]
setblock 105 162 623 minecraft:light[level=14]
setblock 105 162 631 minecraft:light[level=14]
setblock 105 162 639 minecraft:light[level=14]
fill 108 162 646 108 164 646 minecraft:purple_stained_glass
setblock 113 162 607 minecraft:light[level=14]
setblock 113 162 615 minecraft:light[level=14]
setblock 113 162 623 minecraft:light[level=14]
setblock 113 162 631 minecraft:light[level=14]
setblock 113 162 639 minecraft:light[level=14]
fill 114 162 604 114 164 604 minecraft:purple_stained_glass
fill 117 162 638 118 163 639 minecraft:obsidian
setblock 119 162 604 minecraft:crying_obsidian
fill 119 162 646 119 168 646 minecraft:black_concrete
fill 120 162 604 121 198 604 minecraft:black_concrete
setblock 121 162 607 minecraft:light[level=14]
setblock 121 162 615 minecraft:light[level=14]
setblock 121 162 623 minecraft:light[level=14]
setblock 121 162 631 minecraft:light[level=14]
setblock 121 162 639 minecraft:light[level=14]
fill 124 162 646 124 164 646 minecraft:purple_stained_glass
setblock 129 162 607 minecraft:light[level=14]
setblock 129 162 615 minecraft:light[level=14]
setblock 129 162 623 minecraft:light[level=14]
setblock 129 162 631 minecraft:light[level=14]
setblock 129 162 639 minecraft:light[level=14]
fill 130 162 604 130 164 604 minecraft:purple_stained_glass
setblock 130 162 646 minecraft:white_concrete
fill 131 162 646 131 204 646 minecraft:black_concrete
setblock 132 162 646 minecraft:crying_obsidian
fill 136 162 614 136 164 614 minecraft:purple_stained_glass
fill 136 162 626 136 192 626 minecraft:black_concrete
fill 136 162 630 136 164 630 minecraft:purple_stained_glass
fill 94 163 607 94 218 607 minecraft:black_concrete
fill 94 163 614 94 186 614 minecraft:black_concrete
setblock 94 163 631 minecraft:white_concrete
fill 94 163 632 94 215 632 minecraft:black_concrete
setblock 94 163 635 minecraft:crying_obsidian
setblock 95 163 646 minecraft:amethyst_block
setblock 106 163 646 minecraft:crying_obsidian
fill 119 163 604 119 171 604 minecraft:black_concrete
fill 130 163 646 130 185 646 minecraft:black_concrete
fill 132 163 646 132 171 646 minecraft:black_concrete
fill 134 163 604 134 218 604 minecraft:black_concrete
setblock 135 163 604 minecraft:crying_obsidian
setblock 136 163 633 minecraft:crying_obsidian
fill 94 164 631 94 187 631 minecraft:black_concrete
fill 94 164 635 94 218 635 minecraft:black_concrete
fill 94 164 637 94 218 637 minecraft:black_concrete
setblock 94 164 638 minecraft:white_concrete
fill 95 164 646 95 219 646 minecraft:black_concrete
fill 106 164 646 106 201 646 minecraft:black_concrete
fill 135 164 604 135 188 604 minecraft:black_concrete
fill 136 164 633 136 171 633 minecraft:black_concrete
fill 136 164 637 136 169 637 minecraft:black_concrete
setblock 136 164 638 minecraft:crying_obsidian
fill 94 165 612 94 170 612 minecraft:black_concrete
fill 94 165 628 94 170 628 minecraft:black_concrete
fill 94 165 638 94 188 638 minecraft:black_concrete
fill 94 165 644 94 170 644 minecraft:black_concrete
fill 98 165 604 98 166 604 minecraft:black_concrete
fill 108 165 646 108 170 646 minecraft:black_concrete
fill 114 165 604 114 170 604 minecraft:black_concrete
fill 124 165 646 124 170 646 minecraft:black_concrete
fill 130 165 604 130 170 604 minecraft:black_concrete
setblock 136 165 609 minecraft:crying_obsidian
fill 136 165 614 136 170 614 minecraft:black_concrete
fill 136 165 630 136 170 630 minecraft:black_concrete
fill 136 165 638 136 196 638 minecraft:black_concrete
setblock 110 166 604 minecraft:crying_obsidian
fill 136 166 609 136 216 609 minecraft:black_concrete
setblock 94 167 643 minecraft:crying_obsidian
setblock 98 167 604 minecraft:crying_obsidian
fill 110 167 604 110 216 604 minecraft:black_concrete
setblock 117 167 604 minecraft:crying_obsidian
setblock 136 167 623 minecraft:amethyst_block
fill 94 168 643 94 218 643 minecraft:black_concrete
fill 95 168 637 95 173 637 minecraft:amethyst_block
fill 98 168 604 98 170 604 minecraft:black_concrete
fill 117 168 604 117 218 604 minecraft:black_concrete
fill 136 168 623 136 219 623 minecraft:black_concrete
setblock 136 168 644 minecraft:amethyst_block
setblock 94 169 630 minecraft:amethyst_block
fill 95 169 635 95 172 636 minecraft:amethyst_block
fill 95 169 638 95 172 639 minecraft:amethyst_block
fill 96 169 636 101 169 638 minecraft:amethyst_block
setblock 102 169 637 minecraft:amethyst_block
setblock 108 169 604 minecraft:crying_obsidian
setblock 115 169 604 minecraft:amethyst_block
setblock 116 169 604 minecraft:white_concrete
setblock 119 169 646 minecraft:white_concrete
fill 136 169 644 136 173 644 minecraft:black_concrete
setblock 94 170 615 minecraft:amethyst_block
fill 94 170 616 94 202 616 minecraft:black_concrete
fill 94 170 630 94 183 630 minecraft:black_concrete
fill 96 170 635 97 170 639 minecraft:amethyst_block
setblock 97 170 607 minecraft:light[level=14]
setblock 97 170 615 minecraft:light[level=14]
setblock 97 170 623 minecraft:light[level=14]
setblock 97 170 631 minecraft:light[level=14]
fill 98 170 636 100 170 638 minecraft:amethyst_block
setblock 101 170 637 minecraft:amethyst_block
setblock 105 170 607 minecraft:light[level=14]
setblock 105 170 615 minecraft:light[level=14]
setblock 105 170 623 minecraft:light[level=14]
setblock 105 170 631 minecraft:light[level=14]
setblock 105 170 639 minecraft:light[level=14]
setblock 107 170 646 minecraft:crying_obsidian
fill 108 170 604 108 210 604 minecraft:black_concrete
setblock 113 170 607 minecraft:light[level=14]
setblock 113 170 615 minecraft:light[level=14]
setblock 113 170 623 minecraft:light[level=14]
setblock 113 170 631 minecraft:light[level=14]
setblock 113 170 639 minecraft:light[level=14]
fill 115 170 604 116 178 604 minecraft:black_concrete
fill 119 170 646 119 205 646 minecraft:black_concrete
setblock 121 170 607 minecraft:light[level=14]
setblock 121 170 615 minecraft:light[level=14]
setblock 121 170 623 minecraft:light[level=14]
setblock 121 170 631 minecraft:light[level=14]
setblock 121 170 639 minecraft:light[level=14]
setblock 129 170 607 minecraft:light[level=14]
setblock 129 170 615 minecraft:light[level=14]
setblock 129 170 623 minecraft:light[level=14]
setblock 129 170 631 minecraft:light[level=14]
setblock 129 170 639 minecraft:light[level=14]
setblock 136 170 611 minecraft:crying_obsidian
setblock 136 170 637 minecraft:white_concrete
fill 94 171 612 94 173 612 minecraft:purple_stained_glass
fill 94 171 615 94 214 615 minecraft:black_concrete
fill 94 171 628 94 173 628 minecraft:purple_stained_glass
fill 94 171 644 94 173 644 minecraft:purple_stained_glass
fill 96 171 635 96 171 639 minecraft:amethyst_block
fill 97 171 636 98 171 638 minecraft:amethyst_block
fill 98 171 604 98 173 604 minecraft:purple_stained_glass
setblock 99 171 637 minecraft:amethyst_block
fill 100 171 646 100 208 646 minecraft:black_concrete
setblock 101 171 646 minecraft:crying_obsidian
fill 102 171 646 102 214 646 minecraft:black_concrete
fill 107 171 646 107 195 646 minecraft:black_concrete
fill 108 171 646 108 173 646 minecraft:purple_stained_glass
setblock 110 171 646 minecraft:amethyst_block
fill 111 171 646 111 186 646 minecraft:black_concrete
fill 114 171 604 114 173 604 minecraft:purple_stained_glass
fill 124 171 646 124 173 646 minecraft:purple_stained_glass
fill 126 171 625 128 172 625 minecraft:obsidian
fill 127 171 624 127 172 624 minecraft:obsidian
fill 127 171 626 127 172 626 minecraft:obsidian
fill 130 171 604 130 173 604 minecraft:purple_stained_glass
fill 136 171 611 136 201 611 minecraft:black_concrete
setblock 136 171 613 minecraft:white_concrete
fill 136 171 614 136 173 614 minecraft:purple_stained_glass
fill 136 171 630 136 173 630 minecraft:purple_stained_glass
fill 136 171 637 136 205 637 minecraft:black_concrete
setblock 94 172 624 minecraft:white_concrete
fill 96 172 636 97 172 638 minecraft:amethyst_block
fill 101 172 646 101 201 646 minecraft:black_concrete
fill 110 172 646 110 177 646 minecraft:black_concrete
setblock 113 172 604 minecraft:amethyst_block
setblock 119 172 604 minecraft:amethyst_block
fill 126 172 604 126 218 604 minecraft:black_concrete
setblock 127 172 604 minecraft:amethyst_block
setblock 132 172 646 minecraft:crying_obsidian
fill 136 172 613 136 176 613 minecraft:black_concrete
setblock 136 172 633 minecraft:crying_obsidian
setblock 136 172 640 minecraft:crying_obsidian
setblock 94 173 622 minecraft:white_concrete
fill 94 173 624 94 218 624 minecraft:black_concrete
fill 103 173 627 103 174 628 minecraft:obsidian
fill 113 173 604 113 191 604 minecraft:black_concrete
fill 119 173 604 119 181 604 minecraft:black_concrete
fill 127 173 604 127 214 604 minecraft:black_concrete
fill 130 173 643 132 176 645 minecraft:amethyst_block
fill 132 173 646 132 179 646 minecraft:black_concrete
setblock 136 173 605 minecraft:amethyst_block
fill 136 173 633 136 219 633 minecraft:black_concrete
fill 136 173 640 136 218 640 minecraft:black_concrete
fill 94 174 612 94 179 612 minecraft:black_concrete
fill 94 174 622 94 187 622 minecraft:black_concrete
fill 94 174 628 94 179 628 minecraft:black_concrete
fill 94 174 644 94 175 644 minecraft:black_concrete
fill 98 174 604 98 179 604 minecraft:black_concrete
fill 108 174 646 108 179 646 minecraft:black_concrete
fill 114 174 604 114 179 604 minecraft:black_concrete
fill 124 174 646 124 179 646 minecraft:black_concrete
fill 129 174 643 129 175 645 minecraft:amethyst_block
fill 130 174 604 130 179 604 minecraft:black_concrete
fill 130 174 642 132 177 642 minecraft:amethyst_block
fill 133 174 643 133 175 645 minecraft:amethyst_block
fill 136 174 605 136 205 605 minecraft:black_concrete
fill 136 174 614 136 179 614 minecraft:black_concrete
fill 136 174 630 136 179 630 minecraft:black_concrete
setblock 136 174 644 minecraft:white_concrete
setblock 102 175 604 minecraft:white_concrete
fill 131 175 641 131 177 641 minecraft:amethyst_block
fill 133 175 639 135 178 639 minecraft:amethyst_block
fill 134 175 638 134 178 638 minecraft:amethyst_block
fill 134 175 640 134 178 640 minecraft:amethyst_block
setblock 136 175 628 minecraft:crying_obsidian
fill 136 175 631 136 177 631 minecraft:black_concrete
setblock 136 175 632 minecraft:white_concrete
fill 136 175 644 136 205 644 minecraft:black_concrete
setblock 94 176 644 minecraft:crying_obsidian
fill 95 176 604 95 185 604 minecraft:black_concrete
setblock 96 176 604 minecraft:crying_obsidian
fill 102 176 604 102 178 604 minecraft:black_concrete
fill 130 176 641 130 177 641 minecraft:amethyst_block
fill 131 176 639 132 178 639 minecraft:amethyst_block
fill 132 176 638 133 177 638 minecraft:amethyst_block
fill 132 176 640 132 177 641 minecraft:amethyst_block
fill 133 176 640 133 178 640 minecraft:amethyst_block
fill 135 176 638 135 177 638 minecraft:amethyst_block
fill 135 176 640 135 177 640 minecraft:amethyst_block
fill 136 176 628 136 218 628 minecraft:black_concrete
fill 136 176 632 136 195 632 minecraft:black_concrete
fill 94 177 644 94 179 644 minecraft:black_concrete
fill 96 177 604 96 215 604 minecraft:black_concrete
setblock 122 177 604 minecraft:white_concrete
fill 129 177 626 135 179 626 minecraft:amethyst_block
setblock 130 177 639 minecraft:amethyst_block
fill 131 177 625 135 179 625 minecraft:amethyst_block
fill 131 177 627 135 179 627 minecraft:amethyst_block
setblock 131 177 638 minecraft:amethyst_block
setblock 131 177 640 minecraft:amethyst_block
fill 131 177 643 131 177 644 minecraft:amethyst_block
setblock 136 177 613 minecraft:crying_obsidian
setblock 97 178 607 minecraft:light[level=14]
setblock 97 178 615 minecraft:light[level=14]
setblock 97 178 623 minecraft:light[level=14]
setblock 97 178 631 minecraft:light[level=14]
setblock 97 178 639 minecraft:light[level=14]
setblock 103 178 646 minecraft:crying_obsidian
setblock 105 178 607 minecraft:light[level=14]
setblock 105 178 615 minecraft:light[level=14]
setblock 105 178 623 minecraft:light[level=14]
setblock 105 178 631 minecraft:light[level=14]
setblock 105 178 639 minecraft:light[level=14]
setblock 110 178 646 minecraft:crying_obsidian
setblock 111 178 604 minecraft:crying_obsidian
setblock 113 178 607 minecraft:light[level=14]
setblock 113 178 615 minecraft:light[level=14]
setblock 113 178 623 minecraft:light[level=14]
setblock 113 178 631 minecraft:light[level=14]
setblock 113 178 639 minecraft:light[level=14]
setblock 121 178 607 minecraft:light[level=14]
setblock 121 178 615 minecraft:light[level=14]
setblock 121 178 623 minecraft:light[level=14]
setblock 121 178 631 minecraft:light[level=14]
setblock 121 178 639 minecraft:light[level=14]
fill 122 178 604 122 218 604 minecraft:black_concrete
fill 127 178 626 128 178 626 minecraft:amethyst_block
setblock 129 178 607 minecraft:light[level=14]
setblock 129 178 615 minecraft:light[level=14]
setblock 129 178 623 minecraft:light[level=14]
fill 129 178 625 130 178 625 minecraft:amethyst_block
fill 129 178 627 130 178 627 minecraft:amethyst_block
setblock 129 178 631 minecraft:light[level=14]
setblock 129 178 639 minecraft:light[level=14]
fill 133 178 624 135 179 624 minecraft:amethyst_block
fill 133 178 628 135 179 628 minecraft:amethyst_block
setblock 133 178 638 minecraft:amethyst_block
fill 136 178 613 136 218 613 minecraft:black_concrete
setblock 136 178 631 minecraft:crying_obsidian
setblock 102 179 604 minecraft:amethyst_block
fill 103 179 646 103 214 646 minecraft:black_concrete
fill 109 179 607 110 180 608 minecraft:obsidian
fill 110 179 606 110 180 606 minecraft:obsidian
fill 110 179 646 110 181 646 minecraft:black_concrete
fill 111 179 604 111 218 604 minecraft:black_concrete
fill 115 179 604 115 218 604 minecraft:black_concrete
setblock 116 179 604 minecraft:crying_obsidian
setblock 118 179 604 minecraft:white_concrete
fill 123 179 623 124 180 623 minecraft:end_stone
fill 124 179 622 124 180 622 minecraft:end_stone
fill 129 179 633 129 180 633 minecraft:obsidian
setblock 130 179 625 minecraft:amethyst_block
setblock 130 179 627 minecraft:amethyst_block
setblock 133 179 646 minecraft:crying_obsidian
setblock 136 179 624 minecraft:white_concrete
fill 136 179 631 136 205 631 minecraft:black_concrete
fill 94 180 612 94 182 612 minecraft:purple_stained_glass
fill 94 180 628 94 182 628 minecraft:purple_stained_glass
fill 94 180 644 94 182 644 minecraft:purple_stained_glass
fill 98 180 604 98 182 604 minecraft:purple_stained_glass
fill 102 180 604 102 199 604 minecraft:black_concrete
fill 108 180 646 108 182 646 minecraft:purple_stained_glass
fill 114 180 604 114 182 604 minecraft:purple_stained_glass
fill 116 180 604 116 218 604 minecraft:black_concrete
fill 118 180 604 118 189 604 minecraft:black_concrete
fill 124 180 646 124 182 646 minecraft:purple_stained_glass
fill 130 180 604 130 182 604 minecraft:purple_stained_glass
fill 132 180 626 135 180 626 minecraft:amethyst_block
setblock 132 180 646 minecraft:white_concrete
fill 133 180 625 135 180 625 minecraft:amethyst_block
fill 133 180 627 135 180 627 minecraft:amethyst_block
fill 133 180 646 133 188 646 minecraft:black_concrete
fill 136 180 614 136 182 614 minecraft:purple_stained_glass
setblock 136 180 624 minecraft:crying_obsidian
fill 136 180 630 136 182 630 minecraft:purple_stained_glass
setblock 94 181 625 minecraft:crying_obsidian
setblock 131 181 604 minecraft:amethyst_block
fill 132 181 604 132 218 604 minecraft:black_concrete
fill 132 181 646 132 185 646 minecraft:black_concrete
fill 136 181 624 136 214 624 minecraft:black_concrete
fill 94 182 625 94 197 625 minecraft:black_concrete
setblock 94 182 642 minecraft:amethyst_block
setblock 101 182 604 minecraft:crying_obsidian
fill 104 182 604 104 218 604 minecraft:black_concrete
setblock 105 182 604 minecraft:white_concrete
setblock 110 182 646 minecraft:white_concrete
setblock 119 182 604 minecraft:amethyst_block
fill 131 182 604 131 214 604 minecraft:black_concrete
fill 94 183 612 94 197 612 minecraft:black_concrete
fill 94 183 628 94 197 628 minecraft:black_concrete
fill 94 183 642 94 215 642 minecraft:black_concrete
fill 94 183 644 94 197 644 minecraft:black_concrete
fill 98 183 604 98 197 604 minecraft:black_concrete
fill 101 183 604 101 218 604 minecraft:black_concrete
fill 105 183 604 105 215 604 minecraft:black_concrete
fill 108 183 646 108 192 646 minecraft:black_concrete
fill 110 183 646 110 192 646 minecraft:black_concrete
fill 114 183 604 114 197 604 minecraft:black_concrete
setblock 114 183 646 minecraft:amethyst_block
fill 119 183 604 119 218 604 minecraft:black_concrete
fill 124 183 646 124 197 646 minecraft:black_concrete
fill 130 183 604 130 197 604 minecraft:black_concrete
setblock 136 183 612 minecraft:white_concrete
fill 136 183 614 136 197 614 minecraft:black_concrete
fill 136 183 630 136 197 630 minecraft:black_concrete
setblock 94 184 630 minecraft:white_concrete
setblock 109 184 646 minecraft:amethyst_block
setblock 114 184 646 minecraft:white_concrete
fill 136 184 612 136 216 612 minecraft:black_concrete
fill 94 185 630 94 218 630 minecraft:black_concrete
setblock 107 185 604 minecraft:amethyst_block
fill 109 185 646 109 186 646 minecraft:black_concrete
fill 114 185 646 114 208 646 minecraft:black_concrete
fill 94 186 608 94 215 608 minecraft:black_concrete
setblock 94 186 609 minecraft:white_concrete
setblock 94 186 634 minecraft:crying_obsidian
setblock 95 186 604 minecraft:white_concrete
setblock 97 186 607 minecraft:light[level=14]
setblock 97 186 615 minecraft:light[level=14]
setblock 97 186 623 minecraft:light[level=14]
setblock 97 186 631 minecraft:light[level=14]
setblock 97 186 639 minecraft:light[level=14]
setblock 105 186 607 minecraft:light[level=14]
setblock 105 186 615 minecraft:light[level=14]
setblock 105 186 623 minecraft:light[level=14]
setblock 105 186 631 minecraft:light[level=14]
setblock 105 186 639 minecraft:light[level=14]
fill 107 186 604 107 218 604 minecraft:black_concrete
setblock 113 186 607 minecraft:light[level=14]
setblock 113 186 615 minecraft:light[level=14]
setblock 113 186 623 minecraft:light[level=14]
setblock 113 186 631 minecraft:light[level=14]
setblock 113 186 639 minecraft:light[level=14]
setblock 121 186 607 minecraft:light[level=14]
setblock 121 186 615 minecraft:light[level=14]
setblock 121 186 623 minecraft:light[level=14]
setblock 121 186 631 minecraft:light[level=14]
setblock 121 186 639 minecraft:light[level=14]
setblock 129 186 607 minecraft:light[level=14]
setblock 129 186 615 minecraft:light[level=14]
setblock 129 186 623 minecraft:light[level=14]
setblock 129 186 631 minecraft:light[level=14]
setblock 129 186 639 minecraft:light[level=14]
setblock 130 186 646 minecraft:amethyst_block
setblock 132 186 646 minecraft:amethyst_block
fill 94 187 609 94 201 609 minecraft:black_concrete
setblock 94 187 614 minecraft:crying_obsidian
fill 94 187 634 94 204 634 minecraft:black_concrete
fill 95 187 604 95 200 604 minecraft:black_concrete
setblock 109 187 646 minecraft:white_concrete
setblock 111 187 646 minecraft:amethyst_block
setblock 112 187 604 minecraft:amethyst_block
fill 121 187 646 122 216 646 minecraft:black_concrete
setblock 123 187 646 minecraft:amethyst_block
fill 130 187 646 130 214 646 minecraft:black_concrete
setblock 132 187 646 minecraft:white_concrete
setblock 136 187 634 minecraft:crying_obsidian
fill 136 187 635 136 205 635 minecraft:black_concrete
fill 94 188 614 94 197 614 minecraft:black_concrete
setblock 94 188 622 minecraft:amethyst_block
setblock 94 188 631 minecraft:crying_obsidian
setblock 94 188 641 minecraft:amethyst_block
fill 109 188 646 109 195 646 minecraft:black_concrete
fill 111 188 646 111 218 646 minecraft:black_concrete
fill 112 188 604 112 214 604 minecraft:black_concrete
setblock 115 188 646 minecraft:white_concrete
fill 116 188 646 116 195 646 minecraft:black_concrete
fill 123 188 646 123 209 646 minecraft:black_concrete
fill 132 188 646 132 216 646 minecraft:black_concrete
fill 136 188 634 136 218 634 minecraft:black_concrete
fill 94 189 622 94 216 622 minecraft:black_concrete
fill 94 189 631 94 218 631 minecraft:black_concrete
setblock 94 189 638 minecraft:crying_obsidian
fill 94 189 641 94 205 641 minecraft:black_concrete
fill 109 189 622 111 189 624 minecraft:redstone_block
fill 109 189 628 111 189 630 minecraft:redstone_block
fill 115 189 646 115 218 646 minecraft:black_concrete
fill 116 189 621 118 189 623 minecraft:redstone_block
fill 116 189 629 118 189 631 minecraft:redstone_block
fill 128 189 646 128 190 646 minecraft:amethyst_block
setblock 133 189 646 minecraft:crying_obsidian
setblock 135 189 604 minecraft:white_concrete
setblock 94 190 638 minecraft:amethyst_block
fill 106 190 618 107 190 634 minecraft:stone_bricks
fill 108 190 618 122 190 619 minecraft:stone_bricks
fill 108 190 620 108 190 632 minecraft:lime_stained_glass
fill 108 190 633 122 190 634 minecraft:stone_bricks
fill 109 190 620 115 190 621 minecraft:lime_stained_glass
fill 109 190 625 112 190 627 minecraft:lime_stained_glass
fill 109 190 631 115 190 632 minecraft:lime_stained_glass
fill 112 190 622 115 190 624 minecraft:lime_stained_glass
fill 112 190 628 115 190 630 minecraft:lime_stained_glass
fill 116 190 620 120 190 620 minecraft:lime_stained_glass
fill 116 190 624 120 190 628 minecraft:lime_stained_glass
fill 116 190 632 120 190 632 minecraft:lime_stained_glass
setblock 118 190 604 minecraft:amethyst_block
fill 119 190 621 120 190 623 minecraft:lime_stained_glass
fill 119 190 629 120 190 631 minecraft:lime_stained_glass
fill 121 190 620 122 190 632 minecraft:stone_bricks
fill 133 190 646 133 206 646 minecraft:black_concrete
fill 135 190 604 135 218 604 minecraft:black_concrete
setblock 136 190 616 minecraft:amethyst_block
fill 94 191 638 94 218 638 minecraft:black_concrete
fill 95 191 605 105 191 645 minecraft:moss_block
fill 106 191 605 135 191 617 minecraft:moss_block
fill 106 191 618 106 191 619 minecraft:stone_bricks
setblock 106 191 620 minecraft:glowstone
fill 106 191 621 106 191 623 minecraft:stone_bricks
setblock 106 191 624 minecraft:glowstone
fill 106 191 625 106 191 627 minecraft:stone_bricks
setblock 106 191 628 minecraft:glowstone
fill 106 191 629 106 191 631 minecraft:stone_bricks
setblock 106 191 632 minecraft:glowstone
fill 106 191 633 107 191 634 minecraft:stone_bricks
fill 106 191 635 135 191 645 minecraft:moss_block
setblock 107 191 618 minecraft:stone_bricks
setblock 107 191 619 minecraft:glowstone
fill 107 191 620 107 191 622 minecraft:stone_bricks
setblock 107 191 623 minecraft:glowstone
fill 107 191 624 107 191 626 minecraft:stone_bricks
setblock 107 191 627 minecraft:glowstone
fill 107 191 628 107 191 630 minecraft:stone_bricks
setblock 107 191 631 minecraft:glowstone
setblock 107 191 632 minecraft:stone_bricks
setblock 108 191 618 minecraft:glowstone
fill 108 191 619 110 191 619 minecraft:stone_bricks
fill 108 191 620 114 191 620 minecraft:lime_stained_glass
fill 108 191 621 108 191 625 minecraft:crying_obsidian
fill 108 191 626 111 191 626 minecraft:lime_stained_glass
fill 108 191 627 108 191 631 minecraft:crying_obsidian
fill 108 191 632 114 191 632 minecraft:lime_stained_glass
setblock 108 191 633 minecraft:stone_bricks
setblock 108 191 634 minecraft:glowstone
fill 109 191 618 111 191 618 minecraft:stone_bricks
fill 109 191 621 112 191 621 minecraft:crying_obsidian
fill 109 191 622 111 191 624 minecraft:moss_block
fill 109 191 625 111 191 625 minecraft:crying_obsidian
fill 109 191 627 111 191 627 minecraft:crying_obsidian
fill 109 191 628 111 191 630 minecraft:moss_block
fill 109 191 631 112 191 631 minecraft:crying_obsidian
setblock 109 191 633 minecraft:glowstone
fill 109 191 634 111 191 634 minecraft:stone_bricks
fill 110 191 633 112 191 633 minecraft:stone_bricks
setblock 111 191 619 minecraft:glowstone
setblock 112 191 618 minecraft:glowstone
fill 112 191 619 114 191 619 minecraft:stone_bricks
fill 112 191 622 112 191 624 minecraft:crying_obsidian
fill 112 191 625 112 191 627 minecraft:sea_lantern
fill 112 191 628 112 191 630 minecraft:crying_obsidian
setblock 112 191 634 minecraft:glowstone
fill 113 191 618 115 191 618 minecraft:stone_bricks
fill 113 191 621 114 191 623 minecraft:lime_stained_glass
fill 113 191 624 115 191 624 minecraft:sea_lantern
fill 113 191 628 115 191 628 minecraft:sea_lantern
fill 113 191 629 114 191 631 minecraft:lime_stained_glass
setblock 113 191 633 minecraft:glowstone
fill 113 191 634 115 191 634 minecraft:stone_bricks
fill 114 191 633 116 191 633 minecraft:stone_bricks
setblock 115 191 619 minecraft:glowstone
fill 115 191 620 115 191 623 minecraft:crying_obsidian
fill 115 191 629 115 191 632 minecraft:crying_obsidian
setblock 116 191 618 minecraft:glowstone
fill 116 191 619 118 191 619 minecraft:stone_bricks
fill 116 191 620 119 191 620 minecraft:crying_obsidian
fill 116 191 621 118 191 623 minecraft:moss_block
fill 116 191 624 119 191 624 minecraft:crying_obsidian
fill 116 191 625 116 191 627 minecraft:sea_lantern
fill 116 191 628 119 191 628 minecraft:crying_obsidian
fill 116 191 629 118 191 631 minecraft:moss_block
fill 116 191 632 119 191 632 minecraft:crying_obsidian
setblock 116 191 634 minecraft:glowstone
fill 117 191 618 119 191 618 minecraft:stone_bricks
fill 117 191 625 120 191 627 minecraft:lime_stained_glass
setblock 117 191 633 minecraft:glowstone
fill 117 191 634 119 191 634 minecraft:stone_bricks
fill 118 191 604 118 219 604 minecraft:black_concrete
fill 118 191 633 120 191 633 minecraft:stone_bricks
setblock 119 191 619 minecraft:glowstone
fill 119 191 621 119 191 623 minecraft:crying_obsidian
fill 119 191 629 119 191 631 minecraft:crying_obsidian
setblock 120 191 618 minecraft:glowstone
fill 120 191 619 122 191 619 minecraft:stone_bricks
fill 120 191 620 120 191 624 minecraft:lime_stained_glass
fill 120 191 628 120 191 632 minecraft:lime_stained_glass
setblock 120 191 634 minecraft:glowstone
fill 121 191 618 122 191 618 minecraft:stone_bricks
setblock 121 191 620 minecraft:stone_bricks
setblock 121 191 621 minecraft:glowstone
fill 121 191 622 121 191 624 minecraft:stone_bricks
setblock 121 191 625 minecraft:glowstone
fill 121 191 626 121 191 628 minecraft:stone_bricks
setblock 121 191 629 minecraft:glowstone
fill 121 191 630 121 191 632 minecraft:stone_bricks
setblock 121 191 633 minecraft:glowstone
fill 121 191 634 122 191 634 minecraft:stone_bricks
setblock 122 191 620 minecraft:glowstone
fill 122 191 621 122 191 623 minecraft:stone_bricks
setblock 122 191 624 minecraft:glowstone
fill 122 191 625 122 191 627 minecraft:stone_bricks
setblock 122 191 628 minecraft:glowstone
fill 122 191 629 122 191 631 minecraft:stone_bricks
setblock 122 191 632 minecraft:glowstone
setblock 122 191 633 minecraft:stone_bricks
fill 123 191 618 135 191 634 minecraft:moss_block
fill 128 191 646 128 206 646 minecraft:black_concrete
fill 134 191 646 134 214 646 minecraft:black_concrete
setblock 135 191 646 minecraft:white_concrete
fill 136 191 616 136 192 616 minecraft:black_concrete
fill 136 191 646 136 218 646 minecraft:black_concrete
fill 102 192 614 112 192 638 minecraft:prismarine_bricks
setblock 113 192 604 minecraft:white_concrete
fill 113 192 614 126 192 624 minecraft:prismarine_bricks
fill 113 192 628 126 192 638 minecraft:prismarine_bricks
fill 116 192 625 126 192 627 minecraft:prismarine_bricks
fill 135 192 646 135 218 646 minecraft:black_concrete
setblock 94 193 636 minecraft:amethyst_block
fill 102 193 614 111 193 638 minecraft:prismarine_bricks
setblock 108 193 646 minecraft:crying_obsidian
setblock 110 193 646 minecraft:amethyst_block
fill 112 193 614 112 193 625 minecraft:prismarine_bricks
fill 112 193 627 112 193 638 minecraft:prismarine_bricks
fill 113 193 604 113 218 604 minecraft:black_concrete
fill 113 193 614 113 193 624 minecraft:prismarine_bricks
fill 113 193 628 113 193 638 minecraft:prismarine_bricks
fill 114 193 614 126 193 623 minecraft:prismarine_bricks
fill 114 193 629 126 193 638 minecraft:prismarine_bricks
fill 115 193 624 126 193 624 minecraft:prismarine_bricks
fill 115 193 628 126 193 628 minecraft:prismarine_bricks
fill 116 193 625 126 193 625 minecraft:prismarine_bricks
fill 116 193 627 126 193 627 minecraft:prismarine_bricks
fill 117 193 626 126 193 626 minecraft:prismarine_bricks
setblock 136 193 616 minecraft:crying_obsidian
setblock 136 193 626 minecraft:amethyst_block
fill 94 194 636 94 218 636 minecraft:black_concrete
setblock 97 194 607 minecraft:light[level=14]
setblock 97 194 615 minecraft:light[level=14]
setblock 97 194 623 minecraft:light[level=14]
setblock 97 194 631 minecraft:light[level=14]
setblock 97 194 639 minecraft:light[level=14]
fill 103 194 615 103 195 615 minecraft:sea_lantern
fill 103 194 637 103 195 637 minecraft:sea_lantern
fill 104 194 616 111 195 636 minecraft:dark_prismarine
setblock 105 194 607 minecraft:light[level=14]
setblock 105 194 615 minecraft:light[level=14]
setblock 105 194 639 minecraft:light[level=14]
fill 108 194 646 108 197 646 minecraft:black_concrete
fill 110 194 646 110 205 646 minecraft:black_concrete
fill 112 194 616 112 195 624 minecraft:dark_prismarine
fill 112 194 628 112 195 636 minecraft:dark_prismarine
setblock 113 194 607 minecraft:light[level=14]
setblock 113 194 615 minecraft:light[level=14]
fill 113 194 616 124 195 623 minecraft:dark_prismarine
fill 113 194 629 124 195 636 minecraft:dark_prismarine
setblock 113 194 639 minecraft:light[level=14]
fill 116 194 624 124 195 624 minecraft:dark_prismarine
fill 116 194 628 124 195 628 minecraft:dark_prismarine
fill 117 194 625 124 195 627 minecraft:dark_prismarine
setblock 121 194 607 minecraft:light[level=14]
setblock 121 194 615 minecraft:light[level=14]
setblock 121 194 639 minecraft:light[level=14]
fill 125 194 615 125 195 615 minecraft:sea_lantern
fill 125 194 637 125 195 637 minecraft:sea_lantern
setblock 129 194 607 minecraft:light[level=14]
setblock 129 194 615 minecraft:light[level=14]
setblock 129 194 623 minecraft:light[level=14]
setblock 129 194 631 minecraft:light[level=14]
setblock 129 194 639 minecraft:light[level=14]
fill 136 194 616 136 209 616 minecraft:black_concrete
fill 136 194 626 136 201 626 minecraft:black_concrete
fill 95 195 624 96 195 626 minecraft:amethyst_block
setblock 97 195 625 minecraft:amethyst_block
setblock 103 195 604 minecraft:crying_obsidian
setblock 136 195 610 minecraft:white_concrete
fill 95 196 624 95 196 626 minecraft:amethyst_block
setblock 96 196 625 minecraft:amethyst_block
fill 103 196 604 103 218 604 minecraft:black_concrete
fill 106 196 618 111 197 634 minecraft:prismarine_bricks
setblock 107 196 646 minecraft:amethyst_block
setblock 109 196 646 minecraft:white_concrete
fill 112 196 618 112 197 624 minecraft:prismarine_bricks
fill 112 196 628 112 197 634 minecraft:prismarine_bricks
fill 113 196 618 122 197 623 minecraft:prismarine_bricks
fill 113 196 629 122 197 634 minecraft:prismarine_bricks
fill 116 196 624 122 197 624 minecraft:prismarine_bricks
fill 116 196 628 122 197 628 minecraft:prismarine_bricks
setblock 116 196 646 minecraft:white_concrete
fill 117 196 625 122 197 627 minecraft:prismarine_bricks
fill 136 196 610 136 218 610 minecraft:black_concrete
setblock 136 196 632 minecraft:amethyst_block
fill 94 197 604 94 215 604 minecraft:black_concrete
setblock 94 197 605 minecraft:white_concrete
fill 107 197 646 107 218 646 minecraft:black_concrete
fill 109 197 646 109 204 646 minecraft:black_concrete
fill 116 197 646 116 218 646 minecraft:black_concrete
fill 136 197 632 136 218 632 minecraft:black_concrete
setblock 136 197 638 minecraft:white_concrete
fill 94 198 605 94 218 605 minecraft:black_concrete
fill 94 198 612 94 200 612 minecraft:purple_stained_glass
setblock 94 198 614 minecraft:white_concrete
setblock 94 198 625 minecraft:crying_obsidian
fill 94 198 628 94 200 628 minecraft:purple_stained_glass
fill 94 198 644 94 200 644 minecraft:purple_stained_glass
fill 98 198 604 98 200 604 minecraft:purple_stained_glass
fill 108 198 620 111 198 632 minecraft:dark_prismarine
fill 108 198 646 108 200 646 minecraft:purple_stained_glass
fill 112 198 620 120 198 623 minecraft:dark_prismarine
fill 112 198 629 120 198 632 minecraft:dark_prismarine
fill 114 198 604 114 200 604 minecraft:purple_stained_glass
fill 117 198 624 120 198 628 minecraft:dark_prismarine
fill 124 198 646 124 200 646 minecraft:purple_stained_glass
fill 130 198 604 130 200 604 minecraft:purple_stained_glass
fill 136 198 614 136 200 614 minecraft:purple_stained_glass
setblock 136 198 618 minecraft:white_concrete
fill 136 198 630 136 200 630 minecraft:purple_stained_glass
fill 136 198 638 136 201 638 minecraft:black_concrete
fill 94 199 614 94 218 614 minecraft:black_concrete
fill 94 199 625 94 218 625 minecraft:black_concrete
setblock 99 199 646 minecraft:white_concrete
fill 108 199 620 110 199 632 minecraft:dark_prismarine
fill 111 199 620 111 199 625 minecraft:dark_prismarine
fill 111 199 627 111 199 632 minecraft:dark_prismarine
fill 112 199 620 113 199 623 minecraft:dark_prismarine
fill 112 199 629 113 199 632 minecraft:dark_prismarine
fill 114 199 620 120 199 622 minecraft:dark_prismarine
fill 114 199 630 120 199 632 minecraft:dark_prismarine
fill 115 199 623 120 199 623 minecraft:dark_prismarine
fill 115 199 629 120 199 629 minecraft:dark_prismarine
fill 117 199 624 120 199 625 minecraft:dark_prismarine
fill 117 199 627 120 199 628 minecraft:dark_prismarine
fill 118 199 626 120 199 626 minecraft:dark_prismarine
setblock 120 199 604 minecraft:amethyst_block
setblock 121 199 604 minecraft:black_concrete
fill 122 199 613 122 200 613 minecraft:amethyst_block
fill 132 199 631 132 200 631 minecraft:obsidian
fill 136 199 618 136 215 618 minecraft:black_concrete
fill 99 200 646 99 210 646 minecraft:black_concrete
setblock 102 200 604 minecraft:crying_obsidian
fill 110 200 622 110 201 630 minecraft:prismarine_bricks
fill 111 200 622 111 201 624 minecraft:prismarine_bricks
fill 111 200 628 111 201 630 minecraft:prismarine_bricks
fill 112 200 622 112 201 623 minecraft:prismarine_bricks
fill 112 200 629 112 201 630 minecraft:prismarine_bricks
fill 113 200 622 118 201 622 minecraft:prismarine_bricks
fill 113 200 630 118 201 630 minecraft:prismarine_bricks
fill 116 200 623 118 201 623 minecraft:prismarine_bricks
fill 116 200 629 118 201 629 minecraft:prismarine_bricks
fill 117 200 624 118 201 624 minecraft:prismarine_bricks
fill 117 200 628 118 201 628 minecraft:prismarine_bricks
fill 118 200 625 118 201 627 minecraft:prismarine_bricks
fill 120 200 604 120 213 604 minecraft:black_concrete
setblock 121 200 604 minecraft:crying_obsidian
fill 136 200 636 136 201 636 minecraft:crying_obsidian
fill 94 201 612 94 206 612 minecraft:black_concrete
fill 94 201 628 94 206 628 minecraft:black_concrete
fill 94 201 644 94 206 644 minecraft:black_concrete
setblock 95 201 604 minecraft:white_concrete
fill 98 201 604 98 206 604 minecraft:black_concrete
fill 102 201 604 102 209 604 minecraft:black_concrete
fill 108 201 646 108 206 646 minecraft:black_concrete
fill 114 201 604 114 202 604 minecraft:black_concrete
fill 121 201 604 121 218 604 minecraft:black_concrete
fill 122 201 613 123 208 613 minecraft:obsidian
fill 124 201 646 124 206 646 minecraft:black_concrete
setblock 129 201 604 minecraft:white_concrete
fill 130 201 604 130 206 604 minecraft:black_concrete
fill 136 201 614 136 206 614 minecraft:black_concrete
fill 136 201 630 136 206 630 minecraft:black_concrete
setblock 94 202 609 minecraft:amethyst_block
setblock 94 202 613 minecraft:amethyst_block
setblock 94 202 617 minecraft:white_concrete
fill 95 202 604 95 207 604 minecraft:black_concrete
setblock 97 202 607 minecraft:light[level=14]
setblock 97 202 615 minecraft:light[level=14]
setblock 97 202 623 minecraft:light[level=14]
setblock 97 202 631 minecraft:light[level=14]
setblock 97 202 639 minecraft:light[level=14]
setblock 101 202 646 minecraft:amethyst_block
setblock 105 202 607 minecraft:light[level=14]
setblock 105 202 615 minecraft:light[level=14]
setblock 105 202 623 minecraft:light[level=14]
setblock 105 202 631 minecraft:light[level=14]
setblock 105 202 639 minecraft:light[level=14]
setblock 106 202 646 minecraft:white_concrete
setblock 113 202 607 minecraft:light[level=14]
setblock 113 202 615 minecraft:light[level=14]
setblock 113 202 631 minecraft:light[level=14]
setblock 113 202 639 minecraft:light[level=14]
fill 115 202 615 117 203 615 minecraft:end_stone
fill 116 202 614 116 203 614 minecraft:end_stone
fill 116 202 616 116 203 616 minecraft:end_stone
setblock 121 202 607 minecraft:light[level=14]
setblock 121 202 615 minecraft:light[level=14]
setblock 121 202 623 minecraft:light[level=14]
setblock 121 202 631 minecraft:light[level=14]
setblock 121 202 639 minecraft:light[level=14]
fill 129 202 604 129 208 604 minecraft:black_concrete
setblock 129 202 607 minecraft:light[level=14]
setblock 129 202 615 minecraft:light[level=14]
setblock 129 202 623 minecraft:light[level=14]
setblock 129 202 631 minecraft:light[level=14]
setblock 129 202 639 minecraft:light[level=14]
setblock 136 202 611 minecraft:amethyst_block
setblock 136 202 626 minecraft:white_concrete
fill 136 202 636 136 218 636 minecraft:black_concrete
setblock 136 202 638 minecraft:white_concrete
fill 94 203 609 94 204 609 minecraft:black_concrete
fill 94 203 613 94 214 613 minecraft:black_concrete
setblock 94 203 616 minecraft:crying_obsidian
fill 94 203 617 94 218 617 minecraft:black_concrete
fill 101 203 646 101 214 646 minecraft:black_concrete
fill 106 203 646 106 218 646 minecraft:black_concrete
setblock 114 203 604 minecraft:amethyst_block
fill 122 203 612 123 208 612 minecraft:obsidian
fill 122 203 614 123 208 614 minecraft:obsidian
fill 136 203 611 136 218 611 minecraft:black_concrete
fill 136 203 626 136 218 626 minecraft:black_concrete
fill 136 203 638 136 218 638 minecraft:black_concrete
setblock 136 203 645 minecraft:amethyst_block
fill 94 204 616 94 219 616 minecraft:black_concrete
setblock 94 204 645 minecraft:crying_obsidian
fill 114 204 604 114 206 604 minecraft:black_concrete
fill 121 204 613 121 208 613 minecraft:obsidian
fill 124 204 613 124 208 613 minecraft:obsidian
fill 136 204 645 136 205 645 minecraft:black_concrete
setblock 94 205 609 minecraft:amethyst_block
setblock 94 205 634 minecraft:amethyst_block
fill 94 205 645 94 218 645 minecraft:black_concrete
setblock 109 205 646 minecraft:white_concrete
fill 121 205 612 121 208 612 minecraft:obsidian
fill 121 205 614 121 208 614 minecraft:obsidian
fill 122 205 611 123 208 611 minecraft:obsidian
fill 122 205 615 123 208 615 minecraft:obsidian
setblock 124 205 604 minecraft:crying_obsidian
fill 124 205 612 124 208 612 minecraft:obsidian
fill 124 205 614 124 208 614 minecraft:obsidian
setblock 131 205 646 minecraft:white_concrete
fill 94 206 609 94 218 609 minecraft:black_concrete
fill 94 206 634 94 211 634 minecraft:black_concrete
setblock 94 206 641 minecraft:amethyst_block
fill 109 206 646 109 219 646 minecraft:black_concrete
setblock 110 206 646 minecraft:amethyst_block
setblock 119 206 646 minecraft:white_concrete
fill 120 206 612 120 208 614 minecraft:obsidian
fill 121 206 611 121 208 611 minecraft:obsidian
fill 121 206 615 121 208 615 minecraft:obsidian
fill 124 206 604 124 215 604 minecraft:black_concrete
fill 124 206 611 124 208 611 minecraft:obsidian
fill 124 206 615 124 208 615 minecraft:obsidian
fill 125 206 613 125 208 613 minecraft:obsidian
fill 131 206 646 131 218 646 minecraft:black_concrete
setblock 136 206 605 minecraft:white_concrete
setblock 136 206 631 minecraft:crying_obsidian
setblock 136 206 635 minecraft:white_concrete
setblock 136 206 637 minecraft:white_concrete
setblock 136 206 644 minecraft:amethyst_block
setblock 136 206 645 minecraft:crying_obsidian
fill 94 207 612 94 209 612 minecraft:purple_stained_glass
fill 94 207 628 94 209 628 minecraft:purple_stained_glass
setblock 94 207 641 minecraft:crying_obsidian
fill 94 207 644 94 209 644 minecraft:purple_stained_glass
fill 98 207 604 98 209 604 minecraft:purple_stained_glass
setblock 104 207 646 minecraft:amethyst_block
fill 108 207 646 108 209 646 minecraft:purple_stained_glass
setblock 109 207 604 minecraft:amethyst_block
fill 110 207 646 110 210 646 minecraft:black_concrete
fill 114 207 604 114 209 604 minecraft:purple_stained_glass
fill 119 207 646 119 215 646 minecraft:black_concrete
fill 122 207 610 123 208 610 minecraft:obsidian
fill 122 207 616 123 208 616 minecraft:obsidian
fill 124 207 646 124 209 646 minecraft:purple_stained_glass
fill 125 207 612 125 208 612 minecraft:obsidian
fill 125 207 614 125 208 614 minecraft:obsidian
setblock 128 207 646 minecraft:crying_obsidian
fill 130 207 604 130 209 604 minecraft:purple_stained_glass
setblock 133 207 646 minecraft:amethyst_block
fill 136 207 605 136 218 605 minecraft:black_concrete
fill 136 207 614 136 209 614 minecraft:purple_stained_glass
fill 136 207 630 136 209 630 minecraft:purple_stained_glass
fill 136 207 631 136 218 631 minecraft:black_concrete
fill 136 207 635 136 214 635 minecraft:black_concrete
fill 136 207 637 136 216 637 minecraft:black_concrete
fill 136 207 644 136 218 645 minecraft:black_concrete
fill 94 208 641 94 210 641 minecraft:black_concrete
setblock 95 208 604 minecraft:white_concrete
fill 104 208 646 104 218 646 minecraft:black_concrete
fill 105 208 605 105 213 605 minecraft:amethyst_block
fill 109 208 604 109 211 604 minecraft:black_concrete
fill 119 208 612 119 208 614 minecraft:obsidian
setblock 120 208 611 minecraft:obsidian
setblock 120 208 615 minecraft:obsidian
setblock 121 208 610 minecraft:obsidian
setblock 121 208 616 minecraft:obsidian
setblock 124 208 610 minecraft:obsidian
setblock 124 208 616 minecraft:obsidian
setblock 125 208 611 minecraft:obsidian
setblock 125 208 615 minecraft:obsidian
fill 128 208 646 128 215 646 minecraft:black_concrete
fill 133 208 646 133 218 646 minecraft:black_concrete
fill 95 209 604 95 218 604 minecraft:black_concrete
fill 100 209 615 101 210 616 minecraft:netherrack
setblock 100 209 646 minecraft:amethyst_block
fill 103 209 605 104 212 605 minecraft:amethyst_block
fill 104 209 606 106 212 607 minecraft:amethyst_block
fill 105 209 608 105 212 608 minecraft:amethyst_block
fill 106 209 605 107 212 605 minecraft:amethyst_block
setblock 114 209 646 minecraft:amethyst_block
fill 122 209 612 123 209 614 minecraft:amethyst_block
setblock 129 209 604 minecraft:white_concrete
fill 94 210 612 94 215 612 minecraft:black_concrete
fill 94 210 628 94 215 628 minecraft:black_concrete
fill 94 210 644 94 215 644 minecraft:black_concrete
setblock 97 210 607 minecraft:light[level=14]
setblock 97 210 615 minecraft:light[level=14]
setblock 97 210 623 minecraft:light[level=14]
setblock 97 210 631 minecraft:light[level=14]
setblock 97 210 639 minecraft:light[level=14]
fill 98 210 604 98 215 604 minecraft:black_concrete
fill 100 210 646 100 214 646 minecraft:black_concrete
setblock 102 210 604 minecraft:white_concrete
fill 103 210 606 103 211 606 minecraft:amethyst_block
fill 104 210 608 104 211 609 minecraft:amethyst_block
fill 105 210 609 105 211 610 minecraft:amethyst_block
setblock 105 210 615 minecraft:light[level=14]
setblock 105 210 623 minecraft:light[level=14]
setblock 105 210 631 minecraft:light[level=14]
setblock 105 210 639 minecraft:light[level=14]
fill 106 210 608 106 211 609 minecraft:amethyst_block
fill 107 210 606 107 211 606 minecraft:amethyst_block
fill 108 210 646 108 215 646 minecraft:black_concrete
setblock 113 210 607 minecraft:light[level=14]
setblock 113 210 615 minecraft:light[level=14]
setblock 113 210 623 minecraft:light[level=14]
setblock 113 210 631 minecraft:light[level=14]
setblock 113 210 639 minecraft:light[level=14]
fill 114 210 604 114 215 604 minecraft:black_concrete
fill 114 210 646 114 214 646 minecraft:black_concrete
setblock 121 210 607 minecraft:light[level=14]
setblock 121 210 615 minecraft:light[level=14]
setblock 121 210 623 minecraft:light[level=14]
setblock 121 210 631 minecraft:light[level=14]
setblock 121 210 639 minecraft:light[level=14]
fill 122 210 613 123 211 613 minecraft:amethyst_block
setblock 123 210 646 minecraft:amethyst_block
fill 124 210 646 124 215 646 minecraft:black_concrete
fill 129 210 604 130 215 604 minecraft:black_concrete
setblock 129 210 607 minecraft:light[level=14]
setblock 129 210 615 minecraft:light[level=14]
setblock 129 210 623 minecraft:light[level=14]
setblock 129 210 631 minecraft:light[level=14]
setblock 129 210 639 minecraft:light[level=14]
fill 136 210 614 136 215 614 minecraft:black_concrete
setblock 136 210 616 minecraft:crying_obsidian
fill 136 210 630 136 215 630 minecraft:black_concrete
setblock 94 211 641 minecraft:crying_obsidian
setblock 99 211 646 minecraft:amethyst_block
fill 102 211 604 102 218 604 minecraft:black_concrete
setblock 105 211 611 minecraft:amethyst_block
setblock 108 211 604 minecraft:amethyst_block
setblock 110 211 646 minecraft:crying_obsidian
fill 123 211 646 123 216 646 minecraft:black_concrete
fill 136 211 616 136 212 616 minecraft:black_concrete
setblock 136 211 629 minecraft:white_concrete
setblock 94 212 634 minecraft:amethyst_block
fill 94 212 641 94 214 641 minecraft:black_concrete
fill 99 212 646 99 216 646 minecraft:black_concrete
setblock 105 212 609 minecraft:amethyst_block
fill 108 212 604 108 213 604 minecraft:black_concrete
setblock 109 212 604 minecraft:white_concrete
fill 110 212 646 110 218 646 minecraft:black_concrete
setblock 122 212 613 minecraft:amethyst_block
fill 136 212 629 136 216 629 minecraft:black_concrete
setblock 136 212 639 minecraft:amethyst_block
fill 94 213 634 94 218 634 minecraft:black_concrete
fill 109 213 604 109 218 604 minecraft:black_concrete
setblock 136 213 616 minecraft:white_concrete
fill 136 213 639 136 214 639 minecraft:black_concrete
setblock 94 214 627 minecraft:crying_obsidian
setblock 94 214 633 minecraft:white_concrete
setblock 108 214 604 minecraft:white_concrete
setblock 120 214 604 minecraft:amethyst_block
setblock 123 214 604 minecraft:white_concrete
setblock 129 214 646 minecraft:white_concrete
fill 136 214 616 136 218 616 minecraft:black_concrete
setblock 136 214 625 minecraft:white_concrete
setblock 94 215 613 minecraft:obsidian
setblock 94 215 615 minecraft:obsidian
setblock 94 215 627 minecraft:obsidian
fill 94 215 633 94 216 633 minecraft:black_concrete
setblock 94 215 641 minecraft:obsidian
setblock 94 215 646 minecraft:obsidian
fill 100 215 646 103 215 646 minecraft:obsidian
fill 108 215 604 108 218 604 minecraft:black_concrete
setblock 112 215 604 minecraft:obsidian
setblock 114 215 646 minecraft:obsidian
setblock 117 215 646 minecraft:black_concrete
setblock 118 215 646 minecraft:white_concrete
fill 120 215 604 120 217 604 minecraft:black_concrete
fill 123 215 604 123 218 604 minecraft:black_concrete
setblock 127 215 604 minecraft:crying_obsidian
fill 129 215 646 129 218 646 minecraft:black_concrete
setblock 130 215 646 minecraft:obsidian
setblock 131 215 604 minecraft:obsidian
setblock 134 215 646 minecraft:white_concrete
setblock 136 215 619 minecraft:obsidian
setblock 136 215 624 minecraft:obsidian
fill 136 215 625 136 218 625 minecraft:black_concrete
setblock 136 215 635 minecraft:obsidian
setblock 136 215 639 minecraft:obsidian
setblock 94 216 604 minecraft:obsidian
setblock 94 216 608 minecraft:obsidian
fill 94 216 612 94 218 612 minecraft:purple_stained_glass
fill 94 216 613 94 218 613 minecraft:black_concrete
fill 94 216 615 94 219 615 minecraft:black_concrete
setblock 94 216 623 minecraft:obsidian
setblock 94 216 626 minecraft:obsidian
fill 94 216 627 94 218 627 minecraft:black_concrete
fill 94 216 628 94 218 628 minecraft:purple_stained_glass
setblock 94 216 632 minecraft:obsidian
fill 94 216 641 94 218 641 minecraft:black_concrete
setblock 94 216 642 minecraft:obsidian
fill 94 216 644 94 218 644 minecraft:purple_stained_glass
fill 94 216 646 94 218 646 minecraft:black_concrete
fill 96 216 604 97 216 604 minecraft:obsidian
fill 98 216 604 98 218 604 minecraft:purple_stained_glass
fill 100 216 646 101 218 646 minecraft:black_concrete
setblock 102 216 646 minecraft:obsidian
fill 103 216 646 103 218 646 minecraft:black_concrete
setblock 105 216 604 minecraft:obsidian
fill 108 216 646 108 218 646 minecraft:purple_stained_glass
fill 112 216 604 112 218 604 minecraft:black_concrete
fill 114 216 604 114 218 604 minecraft:purple_stained_glass
fill 114 216 646 114 218 646 minecraft:black_concrete
fill 117 216 646 119 216 646 minecraft:obsidian
setblock 124 216 604 minecraft:obsidian
fill 124 216 646 124 218 646 minecraft:purple_stained_glass
fill 125 216 646 125 217 646 minecraft:obsidian
fill 126 216 646 126 218 646 minecraft:black_concrete
fill 127 216 604 127 218 604 minecraft:black_concrete
setblock 128 216 646 minecraft:obsidian
setblock 129 216 604 minecraft:black_concrete
fill 130 216 604 130 218 604 minecraft:purple_stained_glass
fill 130 216 646 130 219 646 minecraft:black_concrete
fill 131 216 604 131 218 604 minecraft:black_concrete
setblock 134 216 646 minecraft:black_concrete
setblock 136 216 608 minecraft:white_concrete
fill 136 216 614 136 218 614 minecraft:purple_stained_glass
setblock 136 216 618 minecraft:obsidian
fill 136 216 619 136 218 619 minecraft:black_concrete
fill 136 216 624 136 218 624 minecraft:black_concrete
fill 136 216 630 136 218 630 minecraft:purple_stained_glass
fill 136 216 635 136 218 635 minecraft:black_concrete
fill 136 216 639 136 218 639 minecraft:black_concrete
setblock 136 216 643 minecraft:obsidian
fill 94 217 604 94 218 604 minecraft:black_concrete
fill 94 217 608 94 218 608 minecraft:black_concrete
fill 94 217 618 94 218 620 minecraft:black_concrete
setblock 94 217 621 minecraft:crying_obsidian
setblock 94 217 622 minecraft:obsidian
fill 94 217 623 94 219 623 minecraft:black_concrete
fill 94 217 626 94 218 626 minecraft:black_concrete
fill 94 217 632 94 218 632 minecraft:black_concrete
setblock 94 217 633 minecraft:obsidian
fill 94 217 642 94 218 642 minecraft:black_concrete
setblock 96 217 604 minecraft:obsidian
setblock 96 217 646 minecraft:crying_obsidian
fill 97 217 604 97 219 604 minecraft:black_concrete
setblock 99 217 646 minecraft:white_concrete
fill 102 217 646 102 218 646 minecraft:black_concrete
fill 105 217 604 105 218 604 minecraft:black_concrete
setblock 106 217 604 minecraft:obsidian
setblock 110 217 604 minecraft:obsidian
fill 117 217 646 119 218 646 minecraft:black_concrete
setblock 121 217 646 minecraft:obsidian
fill 122 217 646 122 219 646 minecraft:black_concrete
setblock 123 217 646 minecraft:obsidian
fill 124 217 604 124 218 604 minecraft:black_concrete
setblock 128 217 604 minecraft:obsidian
fill 128 217 646 128 218 646 minecraft:black_concrete
setblock 129 217 604 minecraft:amethyst_block
setblock 132 217 646 minecraft:obsidian
setblock 134 217 646 minecraft:obsidian
fill 136 217 608 136 219 608 minecraft:black_concrete
setblock 136 217 609 minecraft:obsidian
setblock 136 217 612 minecraft:obsidian
fill 136 217 618 136 218 618 minecraft:black_concrete
setblock 136 217 629 minecraft:amethyst_block
setblock 136 217 637 minecraft:obsidian
fill 136 217 643 136 218 643 minecraft:black_concrete
fill 94 218 621 94 218 622 minecraft:black_concrete
setblock 94 218 633 minecraft:black_concrete
setblock 96 218 604 minecraft:black_concrete
setblock 96 218 646 minecraft:black_concrete
setblock 97 218 607 minecraft:light[level=14]
setblock 97 218 615 minecraft:light[level=14]
setblock 97 218 623 minecraft:light[level=14]
setblock 97 218 631 minecraft:light[level=14]
setblock 97 218 639 minecraft:light[level=14]
setblock 99 218 646 minecraft:black_concrete
setblock 105 218 607 minecraft:light[level=14]
setblock 105 218 615 minecraft:light[level=14]
setblock 105 218 623 minecraft:light[level=14]
setblock 105 218 631 minecraft:light[level=14]
setblock 105 218 639 minecraft:light[level=14]
setblock 105 218 646 minecraft:crying_obsidian
setblock 106 218 604 minecraft:black_concrete
setblock 110 218 604 minecraft:black_concrete
setblock 113 218 607 minecraft:light[level=14]
setblock 113 218 615 minecraft:light[level=14]
setblock 113 218 623 minecraft:light[level=14]
setblock 113 218 631 minecraft:light[level=14]
setblock 113 218 639 minecraft:light[level=14]
setblock 120 218 604 minecraft:white_concrete
setblock 121 218 607 minecraft:light[level=14]
setblock 121 218 615 minecraft:light[level=14]
setblock 121 218 623 minecraft:light[level=14]
setblock 121 218 631 minecraft:light[level=14]
setblock 121 218 639 minecraft:light[level=14]
fill 121 218 646 121 219 646 minecraft:black_concrete
setblock 123 218 646 minecraft:black_concrete
setblock 125 218 646 minecraft:black_concrete
fill 128 218 604 129 218 604 minecraft:black_concrete
setblock 129 218 607 minecraft:light[level=14]
setblock 129 218 615 minecraft:light[level=14]
setblock 129 218 623 minecraft:light[level=14]
setblock 129 218 631 minecraft:light[level=14]
setblock 129 218 639 minecraft:light[level=14]
setblock 132 218 646 minecraft:black_concrete
setblock 134 218 646 minecraft:black_concrete
setblock 136 218 609 minecraft:black_concrete
setblock 136 218 612 minecraft:black_concrete
setblock 136 218 629 minecraft:black_concrete
setblock 136 218 637 minecraft:black_concrete
fill 94 219 604 94 219 614 minecraft:obsidian
fill 94 219 617 94 220 618 minecraft:obsidian
setblock 94 219 619 minecraft:crying_obsidian
fill 94 219 620 94 233 622 minecraft:obsidian
fill 94 219 624 94 219 630 minecraft:obsidian
setblock 94 219 631 minecraft:white_concrete
fill 94 219 632 94 307 632 minecraft:obsidian
setblock 94 219 633 minecraft:white_concrete
fill 94 219 634 94 219 646 minecraft:obsidian
fill 95 219 604 96 220 604 minecraft:obsidian
fill 96 219 646 96 245 646 minecraft:obsidian
fill 98 219 604 113 219 604 minecraft:obsidian
fill 98 219 646 104 222 646 minecraft:obsidian
setblock 105 219 646 minecraft:black_concrete
fill 106 219 646 107 231 646 minecraft:obsidian
setblock 108 219 646 minecraft:white_concrete
fill 110 219 646 120 219 646 minecraft:obsidian
fill 114 219 604 114 220 604 minecraft:black_concrete
fill 115 219 604 117 220 604 minecraft:obsidian
fill 119 219 604 121 219 604 minecraft:obsidian
setblock 122 219 604 minecraft:amethyst_block
fill 123 219 604 132 219 604 minecraft:obsidian
fill 123 219 646 126 220 646 minecraft:obsidian
fill 128 219 646 129 222 646 minecraft:obsidian
fill 131 219 646 136 219 646 minecraft:obsidian
fill 134 219 604 136 220 604 minecraft:obsidian
fill 136 219 605 136 219 607 minecraft:obsidian
fill 136 219 609 136 219 619 minecraft:obsidian
fill 136 219 621 136 219 622 minecraft:obsidian
fill 136 219 624 136 219 629 minecraft:obsidian
setblock 136 219 630 minecraft:crying_obsidian
fill 136 219 631 136 229 632 minecraft:obsidian
fill 136 219 634 136 220 640 minecraft:obsidian
setblock 136 219 641 minecraft:black_concrete
fill 136 219 642 136 219 645 minecraft:obsidian
setblock 94 220 604 minecraft:black_concrete
fill 94 220 605 94 220 616 minecraft:obsidian
fill 94 220 619 94 297 619 minecraft:obsidian
fill 94 220 623 94 282 623 minecraft:obsidian
fill 94 220 624 94 220 625 minecraft:black_concrete
fill 94 220 626 94 224 631 minecraft:obsidian
fill 94 220 633 94 222 636 minecraft:obsidian
setblock 94 220 637 minecraft:black_concrete
fill 94 220 638 94 221 642 minecraft:obsidian
setblock 94 220 643 minecraft:black_concrete
fill 94 220 644 94 224 645 minecraft:obsidian
fill 94 220 646 94 221 646 minecraft:black_concrete
fill 95 220 646 95 307 646 minecraft:obsidian
fill 97 220 604 97 232 604 minecraft:obsidian
fill 97 220 646 97 307 646 minecraft:obsidian
setblock 98 220 604 minecraft:black_concrete
fill 99 220 604 99 246 604 minecraft:obsidian
setblock 100 220 604 minecraft:amethyst_block
setblock 101 220 604 minecraft:black_concrete
fill 102 220 604 111 222 604 minecraft:obsidian
fill 105 220 646 105 307 646 minecraft:obsidian
setblock 108 220 646 minecraft:black_concrete
fill 109 220 646 110 220 646 minecraft:obsidian
setblock 111 220 646 minecraft:black_concrete
setblock 112 220 604 minecraft:black_concrete
fill 112 220 646 122 220 646 minecraft:obsidian
fill 113 220 604 113 231 604 minecraft:obsidian
fill 118 220 604 119 266 604 minecraft:obsidian
setblock 120 220 604 minecraft:black_concrete
fill 121 220 604 128 220 604 minecraft:obsidian
fill 127 220 646 127 256 646 minecraft:obsidian
setblock 129 220 604 minecraft:black_concrete
fill 130 220 604 130 224 604 minecraft:obsidian
fill 130 220 646 130 240 646 minecraft:obsidian
setblock 131 220 604 minecraft:black_concrete
fill 131 220 646 131 221 646 minecraft:black_concrete
fill 132 220 604 133 220 604 minecraft:obsidian
fill 132 220 646 136 220 646 minecraft:obsidian
setblock 136 220 605 minecraft:black_concrete
fill 136 220 606 136 220 615 minecraft:obsidian
fill 136 220 616 136 220 617 minecraft:black_concrete
fill 136 220 618 136 227 620 minecraft:obsidian
setblock 136 220 621 minecraft:black_concrete
fill 136 220 622 136 227 624 minecraft:obsidian
setblock 136 220 625 minecraft:black_concrete
fill 136 220 626 136 235 627 minecraft:obsidian
setblock 136 220 628 minecraft:black_concrete
fill 136 220 629 136 224 630 minecraft:obsidian
fill 136 220 633 136 307 633 minecraft:obsidian
fill 136 220 641 136 220 642 minecraft:obsidian
setblock 136 220 643 minecraft:black_concrete
fill 136 220 644 136 220 645 minecraft:obsidian
fill 94 221 604 94 225 608 minecraft:obsidian
setblock 94 221 609 minecraft:black_concrete
fill 94 221 610 94 224 612 minecraft:obsidian
setblock 94 221 613 minecraft:crying_obsidian
setblock 94 221 614 minecraft:black_concrete
fill 94 221 615 94 223 616 minecraft:obsidian
setblock 94 221 617 minecraft:black_concrete
setblock 94 221 618 minecraft:white_concrete
fill 94 221 624 94 245 625 minecraft:obsidian
fill 94 221 637 94 289 637 minecraft:obsidian
fill 94 221 643 94 282 643 minecraft:obsidian
fill 95 221 604 95 245 604 minecraft:obsidian
setblock 96 221 604 minecraft:black_concrete
fill 98 221 604 98 224 604 minecraft:obsidian
fill 100 221 604 101 257 604 minecraft:obsidian
fill 108 221 646 109 221 646 minecraft:obsidian
setblock 110 221 646 minecraft:black_concrete
fill 111 221 646 113 225 646 minecraft:obsidian
fill 112 221 604 112 227 604 minecraft:obsidian
fill 114 221 604 114 224 604 minecraft:obsidian
fill 114 221 646 116 221 646 minecraft:black_concrete
fill 115 221 604 116 221 604 minecraft:black_concrete
fill 117 221 604 117 248 604 minecraft:obsidian
fill 117 221 646 118 241 646 minecraft:obsidian
setblock 119 221 646 minecraft:black_concrete
fill 120 221 604 122 222 604 minecraft:obsidian
fill 120 221 646 122 241 646 minecraft:obsidian
setblock 123 221 604 minecraft:black_concrete
setblock 123 221 646 minecraft:amethyst_block
fill 124 221 604 129 223 604 minecraft:obsidian
fill 124 221 646 126 224 646 minecraft:obsidian
fill 131 221 604 131 260 604 minecraft:obsidian
setblock 132 221 604 minecraft:black_concrete
fill 132 221 646 133 221 646 minecraft:black_concrete
fill 133 221 604 133 247 604 minecraft:obsidian
setblock 134 221 604 minecraft:white_concrete
fill 134 221 646 136 226 646 minecraft:obsidian
fill 135 221 604 136 272 604 minecraft:obsidian
fill 136 221 605 136 256 606 minecraft:obsidian
setblock 136 221 607 minecraft:amethyst_block
fill 136 221 608 136 229 609 minecraft:obsidian
setblock 136 221 610 minecraft:black_concrete
fill 136 221 611 136 224 617 minecraft:obsidian
fill 136 221 621 136 307 621 minecraft:obsidian
fill 136 221 625 136 234 625 minecraft:obsidian
fill 136 221 628 136 266 628 minecraft:obsidian
setblock 136 221 634 minecraft:black_concrete
fill 136 221 635 136 223 640 minecraft:obsidian
setblock 136 221 641 minecraft:black_concrete
fill 136 221 642 136 226 643 minecraft:obsidian
setblock 136 221 644 minecraft:amethyst_block
setblock 136 221 645 minecraft:black_concrete
fill 94 222 609 94 262 609 minecraft:obsidian
fill 94 222 613 94 238 614 minecraft:obsidian
fill 94 222 617 94 262 618 minecraft:obsidian
fill 94 222 638 94 229 640 minecraft:obsidian
setblock 94 222 641 minecraft:crying_obsidian
fill 94 222 642 94 267 642 minecraft:obsidian
fill 94 222 646 94 307 646 minecraft:obsidian
fill 96 222 604 96 225 604 minecraft:obsidian
fill 108 222 646 108 224 646 minecraft:obsidian
setblock 109 222 646 minecraft:white_concrete
fill 110 222 646 110 307 646 minecraft:obsidian
fill 114 222 646 116 229 646 minecraft:obsidian
fill 115 222 604 116 233 604 minecraft:obsidian
fill 119 222 646 119 247 646 minecraft:obsidian
fill 123 222 604 123 230 604 minecraft:obsidian
fill 123 222 646 123 259 646 minecraft:obsidian
setblock 131 222 646 minecraft:white_concrete
fill 132 222 604 132 225 604 minecraft:obsidian
fill 132 222 646 133 248 646 minecraft:obsidian
fill 134 222 604 134 239 604 minecraft:obsidian
fill 136 222 607 136 258 607 minecraft:obsidian
fill 136 222 610 136 307 610 minecraft:obsidian
fill 136 222 634 136 248 634 minecraft:obsidian
fill 136 222 641 136 289 641 minecraft:obsidian
fill 136 222 644 136 234 645 minecraft:obsidian
fill 94 223 633 94 229 634 minecraft:obsidian
setblock 94 223 635 minecraft:amethyst_block
fill 94 223 636 94 307 636 minecraft:obsidian
fill 94 223 641 94 271 641 minecraft:obsidian
fill 98 223 646 100 231 646 minecraft:obsidian
setblock 101 223 646 minecraft:white_concrete
fill 102 223 604 104 235 604 minecraft:obsidian
fill 102 223 646 104 234 646 minecraft:obsidian
setblock 105 223 604 minecraft:amethyst_block
fill 106 223 604 111 230 604 minecraft:obsidian
fill 109 223 646 109 285 646 minecraft:obsidian
fill 120 223 604 121 272 604 minecraft:obsidian
setblock 122 223 604 minecraft:crying_obsidian
setblock 128 223 646 minecraft:white_concrete
fill 129 223 646 129 307 646 minecraft:obsidian
fill 131 223 646 131 307 646 minecraft:obsidian
fill 94 224 615 94 252 615 minecraft:obsidian
setblock 94 224 616 minecraft:amethyst_block
fill 94 224 635 94 225 635 minecraft:obsidian
fill 101 224 646 101 231 646 minecraft:obsidian
fill 105 224 604 105 227 604 minecraft:obsidian
fill 113 224 639 113 225 641 minecraft:obsidian
fill 114 224 640 114 225 641 minecraft:obsidian
fill 122 224 604 122 307 604 minecraft:obsidian
fill 124 224 604 124 292 604 minecraft:obsidian
setblock 125 224 604 minecraft:crying_obsidian
fill 126 224 604 129 231 604 minecraft:obsidian
fill 128 224 646 128 307 646 minecraft:obsidian
fill 136 224 635 136 230 638 minecraft:obsidian
setblock 136 224 639 minecraft:amethyst_block
fill 136 224 640 136 282 640 minecraft:obsidian
fill 94 225 610 94 235 611 minecraft:obsidian
fill 94 225 612 94 227 612 minecraft:purple_stained_glass
fill 94 225 616 94 260 616 minecraft:obsidian
fill 94 225 626 94 229 627 minecraft:obsidian
fill 94 225 628 94 227 628 minecraft:purple_stained_glass
fill 94 225 629 94 241 631 minecraft:obsidian
fill 94 225 644 94 227 644 minecraft:purple_stained_glass
fill 94 225 645 94 235 645 minecraft:obsidian
fill 98 225 604 98 227 604 minecraft:purple_stained_glass
fill 108 225 646 108 227 646 minecraft:purple_stained_glass
fill 114 225 604 114 227 604 minecraft:purple_stained_glass
fill 124 225 646 124 227 646 minecraft:purple_stained_glass
fill 125 225 604 125 284 604 minecraft:obsidian
fill 125 225 646 126 234 646 minecraft:obsidian
fill 130 225 604 130 227 604 minecraft:purple_stained_glass
fill 136 225 611 136 234 613 minecraft:obsidian
fill 136 225 614 136 227 614 minecraft:purple_stained_glass
setblock 136 225 615 minecraft:crying_obsidian
fill 136 225 616 136 244 617 minecraft:obsidian
fill 136 225 629 136 227 629 minecraft:obsidian
fill 136 225 630 136 227 630 minecraft:purple_stained_glass
fill 136 225 639 136 228 639 minecraft:obsidian
fill 94 226 604 94 281 606 minecraft:obsidian
setblock 94 226 607 minecraft:crying_obsidian
fill 94 226 608 94 307 608 minecraft:obsidian
setblock 94 226 635 minecraft:crying_obsidian
setblock 96 226 604 minecraft:amethyst_block
setblock 97 226 607 minecraft:light[level=14]
setblock 97 226 615 minecraft:light[level=14]
setblock 97 226 623 minecraft:light[level=14]
setblock 97 226 631 minecraft:light[level=14]
setblock 97 226 639 minecraft:light[level=14]
setblock 105 226 607 minecraft:light[level=14]
setblock 105 226 615 minecraft:light[level=14]
setblock 105 226 623 minecraft:light[level=14]
setblock 105 226 631 minecraft:light[level=14]
setblock 105 226 639 minecraft:light[level=14]
setblock 111 226 646 minecraft:white_concrete
setblock 112 226 646 minecraft:obsidian
setblock 113 226 607 minecraft:light[level=14]
setblock 113 226 615 minecraft:light[level=14]
setblock 113 226 623 minecraft:light[level=14]
setblock 113 226 631 minecraft:light[level=14]
setblock 113 226 639 minecraft:light[level=14]
setblock 113 226 646 minecraft:crying_obsidian
setblock 121 226 607 minecraft:light[level=14]
setblock 121 226 615 minecraft:light[level=14]
setblock 121 226 623 minecraft:light[level=14]
setblock 121 226 631 minecraft:light[level=14]
setblock 121 226 639 minecraft:light[level=14]
setblock 129 226 607 minecraft:light[level=14]
setblock 129 226 615 minecraft:light[level=14]
setblock 129 226 623 minecraft:light[level=14]
setblock 129 226 631 minecraft:light[level=14]
setblock 129 226 639 minecraft:light[level=14]
setblock 132 226 604 minecraft:amethyst_block
fill 136 226 615 136 227 615 minecraft:obsidian
fill 94 227 607 94 233 607 minecraft:obsidian
fill 94 227 635 94 270 635 minecraft:obsidian
fill 96 227 604 96 266 604 minecraft:obsidian
fill 111 227 646 111 271 646 minecraft:obsidian
setblock 112 227 646 minecraft:amethyst_block
fill 113 227 646 113 277 646 minecraft:obsidian
fill 128 227 624 129 228 625 minecraft:end_stone
fill 132 227 604 132 255 604 minecraft:obsidian
fill 134 227 646 134 250 646 minecraft:obsidian
setblock 135 227 646 minecraft:crying_obsidian
fill 136 227 642 136 307 642 minecraft:obsidian
setblock 136 227 643 minecraft:white_concrete
fill 136 227 646 136 307 646 minecraft:obsidian
fill 94 228 612 94 233 612 minecraft:obsidian
fill 94 228 628 94 233 628 minecraft:obsidian
fill 94 228 644 94 233 644 minecraft:obsidian
fill 98 228 604 98 231 604 minecraft:obsidian
setblock 105 228 604 minecraft:crying_obsidian
fill 108 228 646 108 233 646 minecraft:obsidian
setblock 112 228 604 minecraft:amethyst_block
fill 112 228 646 112 230 646 minecraft:obsidian
fill 114 228 604 114 233 604 minecraft:obsidian
fill 124 228 646 124 233 646 minecraft:obsidian
fill 130 228 604 130 233 604 minecraft:obsidian
fill 135 228 646 135 254 646 minecraft:obsidian
fill 136 228 614 136 232 614 minecraft:obsidian
setblock 136 228 615 minecraft:crying_obsidian
setblock 136 228 618 minecraft:crying_obsidian
fill 136 228 619 136 247 620 minecraft:obsidian
setblock 136 228 622 minecraft:white_concrete
fill 136 228 623 136 242 624 minecraft:obsidian
setblock 136 228 629 minecraft:amethyst_block
fill 136 228 630 136 233 630 minecraft:obsidian
fill 136 228 643 136 269 643 minecraft:obsidian
fill 97 229 623 98 230 627 minecraft:obsidian
fill 98 229 619 98 230 622 minecraft:obsidian
fill 98 229 628 98 230 631 minecraft:obsidian
fill 99 229 617 99 230 619 minecraft:obsidian
fill 99 229 631 99 230 633 minecraft:obsidian
fill 100 229 615 100 230 617 minecraft:obsidian
fill 100 229 633 100 230 635 minecraft:obsidian
fill 101 229 614 101 230 615 minecraft:obsidian
fill 101 229 635 101 230 636 minecraft:obsidian
fill 102 229 613 102 230 614 minecraft:obsidian
fill 102 229 636 102 230 637 minecraft:obsidian
fill 103 229 612 103 230 613 minecraft:obsidian
fill 103 229 637 103 230 638 minecraft:obsidian
fill 104 229 611 104 230 612 minecraft:obsidian
fill 104 229 638 104 230 639 minecraft:obsidian
fill 105 229 604 105 234 604 minecraft:obsidian
fill 105 229 610 105 230 611 minecraft:obsidian
fill 105 229 639 105 230 640 minecraft:obsidian
fill 106 229 610 107 230 610 minecraft:obsidian
fill 106 229 640 107 230 640 minecraft:obsidian
fill 107 229 609 109 230 609 minecraft:obsidian
fill 107 229 641 109 230 641 minecraft:obsidian
fill 109 229 608 121 230 608 minecraft:obsidian
fill 109 229 642 121 230 642 minecraft:obsidian
fill 112 229 604 112 244 604 minecraft:obsidian
fill 113 229 607 117 230 607 minecraft:obsidian
fill 113 229 643 117 230 643 minecraft:obsidian
fill 121 229 609 123 230 609 minecraft:obsidian
fill 121 229 641 123 230 641 minecraft:obsidian
fill 123 229 610 125 230 610 minecraft:obsidian
fill 123 229 640 125 230 640 minecraft:obsidian
fill 125 229 611 126 230 611 minecraft:obsidian
fill 125 229 639 126 230 639 minecraft:obsidian
fill 126 229 612 127 230 612 minecraft:obsidian
fill 126 229 638 127 230 638 minecraft:obsidian
fill 127 229 613 128 230 613 minecraft:obsidian
fill 127 229 637 128 230 637 minecraft:obsidian
fill 128 229 614 129 230 614 minecraft:obsidian
fill 128 229 636 129 230 636 minecraft:obsidian
fill 129 229 615 130 230 615 minecraft:obsidian
fill 129 229 635 130 230 635 minecraft:obsidian
fill 130 229 616 130 230 617 minecraft:obsidian
fill 130 229 633 130 230 634 minecraft:obsidian
fill 131 229 617 131 230 619 minecraft:obsidian
fill 131 229 631 131 230 633 minecraft:obsidian
fill 132 229 619 132 230 631 minecraft:obsidian
fill 133 229 623 133 230 627 minecraft:obsidian
fill 136 229 615 136 253 615 minecraft:obsidian
fill 136 229 618 136 240 618 minecraft:obsidian
fill 136 229 622 136 307 622 minecraft:obsidian
fill 136 229 629 136 268 629 minecraft:obsidian
setblock 136 229 639 minecraft:crying_obsidian
setblock 94 230 626 minecraft:white_concrete
fill 94 230 627 94 285 627 minecraft:obsidian
setblock 94 230 633 minecraft:amethyst_block
fill 94 230 634 94 307 634 minecraft:obsidian
fill 94 230 638 94 259 638 minecraft:obsidian
setblock 94 230 639 minecraft:white_concrete
setblock 94 230 640 minecraft:crying_obsidian
setblock 114 230 646 minecraft:crying_obsidian
fill 115 230 646 116 241 646 minecraft:obsidian
fill 136 230 608 136 307 608 minecraft:obsidian
setblock 136 230 609 minecraft:white_concrete
fill 136 230 631 136 231 631 minecraft:amethyst_block
fill 136 230 632 136 236 632 minecraft:obsidian
fill 136 230 639 136 234 639 minecraft:obsidian
fill 94 231 626 94 232 626 minecraft:obsidian
fill 94 231 633 94 268 633 minecraft:obsidian
fill 94 231 639 94 307 640 minecraft:obsidian
fill 106 231 604 107 254 604 minecraft:obsidian
setblock 108 231 604 minecraft:crying_obsidian
fill 109 231 604 111 262 604 minecraft:obsidian
fill 109 231 608 110 231 608 minecraft:crying_obsidian
setblock 110 231 642 minecraft:crying_obsidian
fill 111 231 607 119 231 607 minecraft:crying_obsidian
fill 111 231 643 119 231 643 minecraft:crying_obsidian
setblock 112 231 646 minecraft:amethyst_block
fill 114 231 646 114 307 646 minecraft:obsidian
fill 120 231 608 122 231 608 minecraft:crying_obsidian
fill 120 231 642 122 231 642 minecraft:crying_obsidian
setblock 123 231 604 minecraft:amethyst_block
fill 123 231 609 124 231 609 minecraft:crying_obsidian
fill 123 231 641 124 231 641 minecraft:crying_obsidian
setblock 125 231 610 minecraft:crying_obsidian
setblock 125 231 640 minecraft:crying_obsidian
fill 126 231 611 127 231 611 minecraft:crying_obsidian
fill 126 231 639 127 231 639 minecraft:crying_obsidian
fill 127 231 612 128 231 612 minecraft:crying_obsidian
fill 127 231 638 128 231 638 minecraft:crying_obsidian
fill 128 231 613 129 231 613 minecraft:crying_obsidian
fill 128 231 637 129 231 637 minecraft:crying_obsidian
setblock 129 231 614 minecraft:crying_obsidian
setblock 129 231 636 minecraft:crying_obsidian
setblock 130 231 615 minecraft:crying_obsidian
setblock 130 231 635 minecraft:crying_obsidian
fill 131 231 616 131 231 617 minecraft:crying_obsidian
fill 131 231 633 131 231 634 minecraft:crying_obsidian
fill 132 231 618 132 231 620 minecraft:crying_obsidian
fill 132 231 630 132 231 632 minecraft:crying_obsidian
fill 133 231 621 133 231 629 minecraft:crying_obsidian
fill 136 231 609 136 238 609 minecraft:obsidian
fill 136 231 635 136 239 636 minecraft:obsidian
setblock 136 231 637 minecraft:crying_obsidian
fill 136 231 638 136 251 638 minecraft:obsidian
setblock 98 232 604 minecraft:white_concrete
setblock 98 232 646 minecraft:amethyst_block
fill 99 232 646 100 261 646 minecraft:obsidian
setblock 101 232 646 minecraft:amethyst_block
fill 106 232 646 106 233 646 minecraft:obsidian
setblock 107 232 646 minecraft:crying_obsidian
fill 108 232 604 108 241 604 minecraft:obsidian
fill 110 232 612 111 233 613 minecraft:end_stone
fill 112 232 612 112 233 612 minecraft:end_stone
fill 112 232 646 112 264 646 minecraft:obsidian
setblock 113 232 604 minecraft:white_concrete
fill 123 232 604 123 255 604 minecraft:obsidian
fill 126 232 604 127 249 604 minecraft:obsidian
setblock 128 232 604 minecraft:white_concrete
fill 129 232 604 129 273 604 minecraft:obsidian
fill 130 232 628 130 233 628 minecraft:end_stone
setblock 136 232 631 minecraft:crying_obsidian
fill 136 232 637 136 285 637 minecraft:obsidian
setblock 94 233 626 minecraft:amethyst_block
setblock 97 233 604 minecraft:white_concrete
setblock 98 233 604 minecraft:obsidian
fill 98 233 646 98 307 646 minecraft:obsidian
fill 101 233 646 101 285 646 minecraft:obsidian
setblock 107 233 646 minecraft:white_concrete
fill 113 233 604 113 280 604 minecraft:obsidian
fill 128 233 604 128 307 604 minecraft:obsidian
setblock 136 233 614 minecraft:crying_obsidian
fill 136 233 631 136 307 631 minecraft:obsidian
setblock 94 234 607 minecraft:white_concrete
fill 94 234 612 94 235 612 minecraft:purple_stained_glass
setblock 94 234 620 minecraft:white_concrete
fill 94 234 621 94 252 622 minecraft:obsidian
fill 94 234 626 94 307 626 minecraft:obsidian
fill 94 234 628 94 235 628 minecraft:purple_stained_glass
fill 94 234 644 94 235 644 minecraft:purple_stained_glass
fill 97 234 604 97 307 604 minecraft:obsidian
setblock 97 234 607 minecraft:light[level=14]
setblock 97 234 615 minecraft:light[level=14]
setblock 97 234 623 minecraft:light[level=14]
setblock 97 234 631 minecraft:light[level=14]
setblock 97 234 639 minecraft:light[level=14]
fill 98 234 604 98 235 604 minecraft:purple_stained_glass
setblock 105 234 607 minecraft:light[level=14]
setblock 105 234 615 minecraft:light[level=14]
setblock 105 234 623 minecraft:light[level=14]
setblock 105 234 631 minecraft:light[level=14]
setblock 105 234 639 minecraft:light[level=14]
setblock 106 234 646 minecraft:white_concrete
fill 107 234 646 107 251 646 minecraft:obsidian
fill 108 234 646 108 235 646 minecraft:purple_stained_glass
setblock 113 234 607 minecraft:light[level=14]
setblock 113 234 615 minecraft:light[level=14]
setblock 113 234 623 minecraft:light[level=14]
setblock 113 234 631 minecraft:light[level=14]
setblock 113 234 639 minecraft:light[level=14]
fill 114 234 604 114 235 604 minecraft:purple_stained_glass
fill 115 234 604 115 304 604 minecraft:obsidian
setblock 116 234 604 minecraft:crying_obsidian
fill 116 234 616 116 235 616 minecraft:end_stone
setblock 121 234 607 minecraft:light[level=14]
setblock 121 234 615 minecraft:light[level=14]
setblock 121 234 623 minecraft:light[level=14]
setblock 121 234 631 minecraft:light[level=14]
setblock 121 234 639 minecraft:light[level=14]
fill 124 234 646 124 235 646 minecraft:purple_stained_glass
setblock 129 234 607 minecraft:light[level=14]
setblock 129 234 615 minecraft:light[level=14]
setblock 129 234 623 minecraft:light[level=14]
setblock 129 234 631 minecraft:light[level=14]
setblock 129 234 639 minecraft:light[level=14]
fill 130 234 604 130 235 604 minecraft:purple_stained_glass
fill 136 234 614 136 235 614 minecraft:purple_stained_glass
fill 136 234 630 136 235 630 minecraft:purple_stained_glass
fill 94 235 607 94 248 607 minecraft:obsidian
fill 94 235 620 94 307 620 minecraft:obsidian
fill 102 235 646 102 276 646 minecraft:obsidian
setblock 103 235 646 minecraft:white_concrete
fill 104 235 646 104 293 646 minecraft:obsidian
setblock 105 235 604 minecraft:amethyst_block
fill 106 235 646 106 261 646 minecraft:obsidian
fill 116 235 604 116 307 604 minecraft:obsidian
fill 125 235 646 125 272 646 minecraft:obsidian
setblock 126 235 646 minecraft:crying_obsidian
fill 136 235 611 136 284 611 minecraft:obsidian
setblock 136 235 612 minecraft:amethyst_block
fill 136 235 613 136 266 613 minecraft:obsidian
setblock 136 235 625 minecraft:white_concrete
setblock 136 235 639 minecraft:crying_obsidian
setblock 136 235 644 minecraft:amethyst_block
fill 136 235 645 136 285 645 minecraft:obsidian
setblock 94 236 610 minecraft:amethyst_block
fill 94 236 611 94 250 612 minecraft:obsidian
setblock 94 236 628 minecraft:amethyst_block
fill 94 236 644 94 251 644 minecraft:obsidian
setblock 94 236 645 minecraft:amethyst_block
fill 98 236 604 98 251 604 minecraft:obsidian
setblock 102 236 604 minecraft:amethyst_block
fill 103 236 604 105 262 604 minecraft:obsidian
fill 103 236 646 103 268 646 minecraft:obsidian
fill 108 236 646 108 251 646 minecraft:obsidian
fill 114 236 604 114 251 604 minecraft:obsidian
fill 124 236 646 124 251 646 minecraft:obsidian
fill 126 236 646 126 264 646 minecraft:obsidian
fill 130 236 604 130 251 604 minecraft:obsidian
fill 136 236 612 136 255 612 minecraft:obsidian
fill 136 236 614 136 251 614 minecraft:obsidian
fill 136 236 625 136 274 626 minecraft:obsidian
setblock 136 236 627 minecraft:white_concrete
fill 136 236 630 136 251 630 minecraft:obsidian
fill 136 236 639 136 307 639 minecraft:obsidian
fill 136 236 644 136 303 644 minecraft:obsidian
fill 94 237 610 94 283 610 minecraft:obsidian
fill 94 237 628 94 251 628 minecraft:obsidian
fill 94 237 645 94 248 645 minecraft:obsidian
fill 102 237 604 102 257 604 minecraft:obsidian
fill 136 237 627 136 274 627 minecraft:obsidian
setblock 136 237 632 minecraft:white_concrete
fill 136 238 632 136 250 632 minecraft:obsidian
setblock 94 239 613 minecraft:crying_obsidian
fill 94 239 614 94 307 614 minecraft:obsidian
setblock 136 239 609 minecraft:crying_obsidian
fill 94 240 613 94 254 613 minecraft:obsidian
fill 111 240 628 113 240 630 minecraft:redstone_block
fill 112 240 621 114 240 623 minecraft:redstone_block
fill 118 240 629 120 240 631 minecraft:redstone_block
fill 119 240 622 121 240 624 minecraft:redstone_block
setblock 134 240 604 minecraft:white_concrete
fill 136 240 609 136 244 609 minecraft:obsidian
fill 136 240 635 136 294 635 minecraft:obsidian
setblock 136 240 636 minecraft:crying_obsidian
fill 106 241 626 107 242 626 minecraft:end_stone_bricks
fill 107 241 622 108 241 625 minecraft:end_stone_bricks
fill 107 241 627 108 241 630 minecraft:end_stone_bricks
fill 108 241 620 109 241 621 minecraft:end_stone_bricks
fill 108 241 626 114 241 626 minecraft:black_concrete
fill 108 241 631 109 242 632 minecraft:end_stone_bricks
fill 109 241 619 112 241 619 minecraft:end_stone_bricks
fill 109 241 622 109 242 622 minecraft:end_stone_bricks
fill 109 241 623 111 241 625 minecraft:black_concrete
fill 109 241 627 110 241 629 minecraft:black_concrete
fill 109 241 630 109 242 630 minecraft:end_stone_bricks
fill 109 241 633 112 241 633 minecraft:end_stone_bricks
fill 110 241 618 115 241 618 minecraft:end_stone_bricks
setblock 110 241 620 minecraft:end_stone_bricks
fill 110 241 621 111 241 622 minecraft:black_concrete
fill 110 241 630 110 241 631 minecraft:black_concrete
setblock 110 241 632 minecraft:end_stone_bricks
fill 110 241 634 115 241 634 minecraft:end_stone_bricks
fill 111 241 620 121 241 620 minecraft:black_concrete
fill 111 241 627 114 241 627 minecraft:black_concrete
fill 111 241 631 117 241 632 minecraft:black_concrete
fill 112 241 617 120 241 617 minecraft:end_stone_bricks
fill 112 241 624 114 241 625 minecraft:black_concrete
fill 112 241 635 120 241 635 minecraft:end_stone_bricks
fill 113 241 619 119 242 619 minecraft:black_concrete
fill 113 241 633 119 242 633 minecraft:black_concrete
fill 114 241 628 117 241 630 minecraft:black_concrete
fill 115 241 621 118 241 624 minecraft:black_concrete
fill 116 241 616 116 242 616 minecraft:end_stone_bricks
fill 116 241 618 116 242 618 minecraft:black_concrete
fill 116 241 634 116 242 634 minecraft:black_concrete
fill 116 241 636 116 242 636 minecraft:end_stone_bricks
fill 117 241 618 122 241 618 minecraft:end_stone_bricks
fill 117 241 634 122 241 634 minecraft:end_stone_bricks
fill 118 241 625 123 241 628 minecraft:black_concrete
fill 118 241 632 121 241 632 minecraft:black_concrete
fill 119 241 621 122 241 621 minecraft:black_concrete
fill 120 241 619 123 241 619 minecraft:end_stone_bricks
fill 120 241 633 123 241 633 minecraft:end_stone_bricks
fill 121 241 629 122 241 631 minecraft:black_concrete
fill 122 241 620 124 241 620 minecraft:end_stone_bricks
fill 122 241 622 122 241 624 minecraft:black_concrete
fill 122 241 632 124 241 632 minecraft:end_stone_bricks
fill 123 241 621 124 241 622 minecraft:end_stone_bricks
fill 123 241 623 123 242 624 minecraft:black_concrete
fill 123 241 629 123 242 629 minecraft:black_concrete
fill 123 241 630 124 241 631 minecraft:end_stone_bricks
fill 124 241 623 125 241 625 minecraft:end_stone_bricks
fill 124 241 626 124 242 626 minecraft:black_concrete
fill 124 241 627 125 241 629 minecraft:end_stone_bricks
fill 125 241 622 125 242 622 minecraft:end_stone_bricks
fill 125 241 626 126 242 626 minecraft:end_stone_bricks
fill 125 241 630 125 242 630 minecraft:end_stone_bricks
setblock 130 241 646 minecraft:white_concrete
fill 134 241 604 134 246 604 minecraft:obsidian
setblock 136 241 618 minecraft:white_concrete
setblock 136 241 636 minecraft:obsidian
fill 94 242 629 94 257 630 minecraft:obsidian
setblock 94 242 631 minecraft:white_concrete
fill 95 242 605 105 242 645 minecraft:end_stone
fill 106 242 605 106 242 625 minecraft:end_stone
fill 106 242 627 106 242 645 minecraft:end_stone
fill 107 242 605 107 242 621 minecraft:end_stone
setblock 107 242 622 minecraft:end_stone_bricks
setblock 107 242 623 minecraft:pearlescent_froglight
fill 107 242 624 108 242 625 minecraft:end_stone_bricks
setblock 107 242 627 minecraft:pearlescent_froglight
fill 107 242 628 107 242 630 minecraft:end_stone_bricks
fill 107 242 631 107 242 645 minecraft:end_stone
setblock 108 242 604 minecraft:crying_obsidian
fill 108 242 605 108 242 619 minecraft:end_stone
fill 108 242 620 108 242 621 minecraft:end_stone_bricks
setblock 108 242 622 minecraft:pearlescent_froglight
setblock 108 242 623 minecraft:end_stone_bricks
fill 108 242 626 113 242 626 minecraft:black_concrete
fill 108 242 627 108 242 629 minecraft:end_stone_bricks
setblock 108 242 630 minecraft:pearlescent_froglight
fill 108 242 633 108 242 645 minecraft:end_stone
fill 109 242 605 109 242 618 minecraft:end_stone
fill 109 242 619 109 242 620 minecraft:end_stone_bricks
setblock 109 242 621 minecraft:pearlescent_froglight
fill 109 242 623 110 242 625 minecraft:black_concrete
fill 109 242 627 109 242 629 minecraft:black_concrete
setblock 109 242 633 minecraft:pearlescent_froglight
fill 109 242 634 109 242 645 minecraft:end_stone
fill 110 242 605 111 242 617 minecraft:end_stone
fill 110 242 618 110 242 619 minecraft:end_stone_bricks
setblock 110 242 620 minecraft:pearlescent_froglight
fill 110 242 621 110 242 622 minecraft:black_concrete
fill 110 242 627 110 242 631 minecraft:crying_obsidian
setblock 110 242 632 minecraft:pearlescent_froglight
fill 110 242 633 111 242 634 minecraft:end_stone_bricks
fill 110 242 635 111 242 645 minecraft:end_stone
setblock 111 242 618 minecraft:end_stone_bricks
setblock 111 242 619 minecraft:pearlescent_froglight
fill 111 242 620 111 242 624 minecraft:crying_obsidian
fill 111 242 625 113 242 625 minecraft:black_concrete
fill 111 242 627 114 242 627 minecraft:crying_obsidian
fill 111 242 628 113 242 630 minecraft:end_stone
fill 111 242 631 114 242 631 minecraft:crying_obsidian
fill 111 242 632 116 242 632 minecraft:black_concrete
fill 112 242 605 115 242 616 minecraft:end_stone
setblock 112 242 617 minecraft:end_stone_bricks
setblock 112 242 618 minecraft:pearlescent_froglight
setblock 112 242 619 minecraft:end_stone_bricks
fill 112 242 620 115 242 620 minecraft:crying_obsidian
fill 112 242 621 114 242 623 minecraft:end_stone
fill 112 242 624 118 242 624 minecraft:crying_obsidian
setblock 112 242 633 minecraft:end_stone_bricks
setblock 112 242 634 minecraft:pearlescent_froglight
fill 112 242 635 114 242 635 minecraft:end_stone_bricks
fill 112 242 636 115 242 645 minecraft:end_stone
setblock 113 242 617 minecraft:pearlescent_froglight
fill 113 242 618 115 242 618 minecraft:end_stone_bricks
fill 113 242 634 115 242 634 minecraft:end_stone_bricks
fill 114 242 617 116 242 617 minecraft:end_stone_bricks
fill 114 242 625 114 242 626 minecraft:crying_obsidian
fill 114 242 628 114 242 630 minecraft:crying_obsidian
fill 115 242 621 115 242 623 minecraft:crying_obsidian
fill 115 242 628 121 242 628 minecraft:crying_obsidian
fill 115 242 629 116 242 631 minecraft:black_concrete
setblock 115 242 635 minecraft:pearlescent_froglight
setblock 115 242 646 minecraft:amethyst_block
fill 116 242 605 135 242 615 minecraft:end_stone
fill 116 242 620 117 242 623 minecraft:black_concrete
fill 116 242 635 118 242 635 minecraft:end_stone_bricks
fill 116 242 637 135 242 645 minecraft:end_stone
fill 116 242 646 116 307 646 minecraft:obsidian
fill 117 242 616 135 242 616 minecraft:end_stone
setblock 117 242 617 minecraft:pearlescent_froglight
fill 117 242 618 119 242 618 minecraft:end_stone_bricks
fill 117 242 629 117 242 632 minecraft:crying_obsidian
fill 117 242 634 119 242 634 minecraft:end_stone_bricks
fill 117 242 636 135 242 636 minecraft:end_stone
setblock 117 242 646 minecraft:amethyst_block
fill 118 242 617 120 242 617 minecraft:end_stone_bricks
fill 118 242 620 121 242 620 minecraft:black_concrete
fill 118 242 621 118 242 623 minecraft:crying_obsidian
fill 118 242 625 118 242 627 minecraft:crying_obsidian
fill 118 242 629 120 242 631 minecraft:end_stone
fill 118 242 632 121 242 632 minecraft:crying_obsidian
fill 118 242 646 118 307 646 minecraft:obsidian
fill 119 242 621 122 242 621 minecraft:crying_obsidian
fill 119 242 622 121 242 624 minecraft:end_stone
fill 119 242 625 122 242 625 minecraft:crying_obsidian
fill 119 242 626 123 242 627 minecraft:black_concrete
setblock 119 242 635 minecraft:pearlescent_froglight
setblock 120 242 618 minecraft:pearlescent_froglight
fill 120 242 619 122 242 619 minecraft:end_stone_bricks
setblock 120 242 633 minecraft:end_stone_bricks
setblock 120 242 634 minecraft:pearlescent_froglight
setblock 120 242 635 minecraft:end_stone_bricks
fill 120 242 646 121 245 646 minecraft:obsidian
fill 121 242 617 135 242 617 minecraft:end_stone
fill 121 242 618 122 242 618 minecraft:end_stone_bricks
fill 121 242 629 121 242 631 minecraft:crying_obsidian
setblock 121 242 633 minecraft:pearlescent_froglight
fill 121 242 634 122 242 634 minecraft:end_stone_bricks
fill 121 242 635 135 242 635 minecraft:end_stone
setblock 122 242 620 minecraft:pearlescent_froglight
fill 122 242 622 122 242 624 minecraft:crying_obsidian
fill 122 242 628 122 242 631 minecraft:black_concrete
setblock 122 242 632 minecraft:pearlescent_froglight
fill 122 242 633 123 242 633 minecraft:end_stone_bricks
setblock 122 242 646 minecraft:crying_obsidian
fill 123 242 618 135 242 618 minecraft:end_stone
setblock 123 242 619 minecraft:pearlescent_froglight
fill 123 242 620 123 242 622 minecraft:end_stone_bricks
setblock 123 242 625 minecraft:black_concrete
setblock 123 242 628 minecraft:black_concrete
setblock 123 242 630 minecraft:end_stone_bricks
setblock 123 242 631 minecraft:pearlescent_froglight
fill 123 242 632 124 242 632 minecraft:end_stone_bricks
fill 123 242 634 135 242 634 minecraft:end_stone
fill 124 242 619 135 242 619 minecraft:end_stone
fill 124 242 620 124 242 621 minecraft:end_stone_bricks
setblock 124 242 622 minecraft:pearlescent_froglight
fill 124 242 623 124 242 625 minecraft:end_stone_bricks
fill 124 242 627 124 242 629 minecraft:end_stone_bricks
setblock 124 242 630 minecraft:pearlescent_froglight
setblock 124 242 631 minecraft:end_stone_bricks
fill 124 242 633 135 242 633 minecraft:end_stone
fill 125 242 620 135 242 621 minecraft:end_stone
fill 125 242 623 125 242 624 minecraft:end_stone_bricks
setblock 125 242 625 minecraft:pearlescent_froglight
fill 125 242 627 125 242 628 minecraft:end_stone_bricks
setblock 125 242 629 minecraft:pearlescent_froglight
fill 125 242 631 135 242 632 minecraft:end_stone
fill 126 242 622 135 242 625 minecraft:end_stone
fill 126 242 627 135 242 630 minecraft:end_stone
fill 127 242 626 135 242 626 minecraft:end_stone
fill 130 242 646 130 290 646 minecraft:obsidian
fill 136 242 618 136 257 618 minecraft:obsidian
setblock 136 242 636 minecraft:white_concrete
fill 94 243 631 94 270 631 minecraft:obsidian
fill 106 243 617 108 246 617 minecraft:end_stone_bricks
fill 106 243 635 108 246 635 minecraft:end_stone_bricks
fill 107 243 616 107 246 616 minecraft:end_stone_bricks
fill 107 243 618 107 246 618 minecraft:end_stone_bricks
fill 107 243 634 107 246 634 minecraft:end_stone_bricks
fill 107 243 636 107 246 636 minecraft:end_stone_bricks
fill 108 243 604 108 244 604 minecraft:obsidian
fill 115 243 646 115 264 646 minecraft:obsidian
fill 117 243 646 117 255 646 minecraft:obsidian
setblock 122 243 646 minecraft:white_concrete
fill 124 243 617 126 246 617 minecraft:end_stone_bricks
fill 124 243 635 126 246 635 minecraft:end_stone_bricks
fill 125 243 616 125 246 616 minecraft:end_stone_bricks
fill 125 243 618 125 246 618 minecraft:end_stone_bricks
fill 125 243 634 125 246 634 minecraft:end_stone_bricks
fill 125 243 636 125 246 636 minecraft:end_stone_bricks
fill 136 243 623 136 279 623 minecraft:obsidian
setblock 136 243 624 minecraft:crying_obsidian
fill 136 243 636 136 258 636 minecraft:obsidian
fill 122 244 646 122 247 646 minecraft:obsidian
fill 136 244 624 136 253 624 minecraft:obsidian
setblock 108 245 604 minecraft:white_concrete
setblock 112 245 604 minecraft:white_concrete
setblock 136 245 609 minecraft:white_concrete
fill 136 245 616 136 250 616 minecraft:obsidian
setblock 136 245 617 minecraft:crying_obsidian
fill 94 246 624 94 307 624 minecraft:obsidian
setblock 94 246 625 minecraft:crying_obsidian
setblock 95 246 604 minecraft:crying_obsidian
setblock 96 246 646 minecraft:crying_obsidian
fill 108 246 604 108 258 604 minecraft:obsidian
fill 112 246 604 112 259 604 minecraft:obsidian
fill 120 246 646 120 307 646 minecraft:obsidian
setblock 121 246 646 minecraft:white_concrete
fill 136 246 609 136 307 609 minecraft:obsidian
fill 136 246 617 136 260 617 minecraft:obsidian
fill 94 247 625 94 283 625 minecraft:obsidian
fill 95 247 604 95 263 604 minecraft:obsidian
fill 96 247 646 96 307 646 minecraft:obsidian
setblock 99 247 604 minecraft:crying_obsidian
fill 121 247 646 121 274 646 minecraft:obsidian
setblock 134 247 604 minecraft:amethyst_block
fill 99 248 604 99 307 604 minecraft:obsidian
fill 117 248 605 119 251 605 minecraft:amethyst_block
fill 118 248 606 118 251 606 minecraft:amethyst_block
setblock 119 248 646 minecraft:amethyst_block
setblock 122 248 646 minecraft:white_concrete
setblock 133 248 604 minecraft:white_concrete
fill 134 248 604 134 307 604 minecraft:obsidian
fill 136 248 619 136 307 619 minecraft:obsidian
setblock 136 248 620 minecraft:amethyst_block
setblock 94 249 607 minecraft:amethyst_block
setblock 94 249 645 minecraft:amethyst_block
setblock 117 249 604 minecraft:amethyst_block
fill 117 249 606 117 250 607 minecraft:amethyst_block
fill 118 249 607 118 251 608 minecraft:amethyst_block
fill 119 249 606 119 250 607 minecraft:amethyst_block
fill 119 249 646 119 298 646 minecraft:obsidian
fill 122 249 646 122 307 646 minecraft:obsidian
fill 132 249 646 132 270 646 minecraft:obsidian
fill 133 249 604 133 284 604 minecraft:obsidian
setblock 133 249 646 minecraft:white_concrete
fill 136 249 620 136 291 620 minecraft:obsidian
setblock 136 249 634 minecraft:crying_obsidian
fill 94 250 607 94 266 607 minecraft:obsidian
fill 94 250 645 94 277 645 minecraft:obsidian
setblock 97 250 607 minecraft:light[level=14]
setblock 97 250 615 minecraft:light[level=14]
setblock 97 250 623 minecraft:light[level=14]
setblock 97 250 631 minecraft:light[level=14]
setblock 97 250 639 minecraft:light[level=14]
setblock 105 250 607 minecraft:light[level=14]
setblock 105 250 615 minecraft:light[level=14]
setblock 105 250 623 minecraft:light[level=14]
setblock 105 250 631 minecraft:light[level=14]
setblock 105 250 639 minecraft:light[level=14]
setblock 113 250 607 minecraft:light[level=14]
setblock 113 250 615 minecraft:light[level=14]
setblock 113 250 623 minecraft:light[level=14]
setblock 113 250 631 minecraft:light[level=14]
setblock 113 250 639 minecraft:light[level=14]
fill 117 250 604 117 269 604 minecraft:obsidian
setblock 117 250 608 minecraft:amethyst_block
fill 118 250 609 118 251 610 minecraft:amethyst_block
setblock 119 250 608 minecraft:amethyst_block
setblock 121 250 607 minecraft:light[level=14]
setblock 121 250 615 minecraft:light[level=14]
setblock 121 250 623 minecraft:light[level=14]
setblock 121 250 631 minecraft:light[level=14]
setblock 121 250 639 minecraft:light[level=14]
fill 126 250 604 126 306 604 minecraft:obsidian
setblock 127 250 604 minecraft:crying_obsidian
setblock 129 250 607 minecraft:light[level=14]
setblock 129 250 615 minecraft:light[level=14]
setblock 129 250 623 minecraft:light[level=14]
setblock 129 250 631 minecraft:light[level=14]
setblock 129 250 639 minecraft:light[level=14]
fill 133 250 646 133 307 646 minecraft:obsidian
fill 136 250 634 136 294 634 minecraft:obsidian
setblock 94 251 611 minecraft:white_concrete
setblock 94 251 612 minecraft:obsidian
setblock 117 251 606 minecraft:amethyst_block
setblock 118 251 611 minecraft:amethyst_block
setblock 119 251 606 minecraft:amethyst_block
fill 127 251 604 127 283 604 minecraft:obsidian
fill 130 251 630 130 252 631 minecraft:netherrack
setblock 134 251 646 minecraft:crying_obsidian
setblock 136 251 616 minecraft:white_concrete
fill 136 251 632 136 252 632 minecraft:crying_obsidian
fill 94 252 611 94 288 611 minecraft:obsidian
fill 94 252 612 94 254 612 minecraft:purple_stained_glass
fill 94 252 628 94 254 628 minecraft:purple_stained_glass
fill 94 252 644 94 254 644 minecraft:purple_stained_glass
fill 98 252 604 98 254 604 minecraft:purple_stained_glass
setblock 107 252 646 minecraft:white_concrete
fill 108 252 646 108 254 646 minecraft:purple_stained_glass
fill 114 252 604 114 254 604 minecraft:purple_stained_glass
fill 124 252 646 124 254 646 minecraft:purple_stained_glass
fill 130 252 604 130 254 604 minecraft:purple_stained_glass
fill 134 252 646 134 307 646 minecraft:obsidian
fill 136 252 614 136 254 614 minecraft:purple_stained_glass
fill 136 252 616 136 299 616 minecraft:obsidian
fill 136 252 630 136 254 630 minecraft:purple_stained_glass
setblock 136 252 638 minecraft:amethyst_block
setblock 94 253 615 minecraft:white_concrete
fill 94 253 621 94 282 621 minecraft:obsidian
setblock 94 253 622 minecraft:crying_obsidian
fill 107 253 646 107 307 646 minecraft:obsidian
fill 136 253 632 136 273 632 minecraft:obsidian
fill 136 253 638 136 284 638 minecraft:obsidian
fill 94 254 615 94 276 615 minecraft:obsidian
fill 94 254 622 94 267 622 minecraft:obsidian
setblock 136 254 615 minecraft:amethyst_block
setblock 136 254 624 minecraft:amethyst_block
fill 94 255 612 94 260 612 minecraft:obsidian
setblock 94 255 613 minecraft:amethyst_block
fill 94 255 628 94 260 628 minecraft:obsidian
fill 94 255 644 94 260 644 minecraft:obsidian
fill 98 255 604 98 260 604 minecraft:obsidian
setblock 106 255 604 minecraft:amethyst_block
fill 107 255 604 107 268 604 minecraft:obsidian
fill 108 255 646 108 260 646 minecraft:obsidian
fill 114 255 604 114 260 604 minecraft:obsidian
fill 124 255 646 124 260 646 minecraft:obsidian
fill 130 255 604 130 260 604 minecraft:obsidian
setblock 135 255 646 minecraft:white_concrete
fill 136 255 614 136 260 615 minecraft:obsidian
fill 136 255 624 136 297 624 minecraft:obsidian
fill 136 255 630 136 260 630 minecraft:obsidian
fill 94 256 613 94 303 613 minecraft:obsidian
fill 106 256 604 106 306 604 minecraft:obsidian
setblock 117 256 646 minecraft:white_concrete
setblock 123 256 604 minecraft:white_concrete
setblock 132 256 604 minecraft:crying_obsidian
fill 135 256 646 135 280 646 minecraft:obsidian
setblock 136 256 612 minecraft:crying_obsidian
fill 117 257 646 117 263 646 minecraft:obsidian
fill 123 257 604 123 307 604 minecraft:obsidian
setblock 127 257 646 minecraft:amethyst_block
fill 132 257 604 132 272 604 minecraft:obsidian
fill 136 257 605 136 307 605 minecraft:obsidian
setblock 136 257 606 minecraft:white_concrete
fill 136 257 612 136 284 612 minecraft:obsidian
setblock 94 258 629 minecraft:amethyst_block
fill 94 258 630 94 299 630 minecraft:obsidian
setblock 97 258 607 minecraft:light[level=14]
setblock 97 258 615 minecraft:light[level=14]
setblock 97 258 623 minecraft:light[level=14]
setblock 97 258 631 minecraft:light[level=14]
setblock 97 258 639 minecraft:light[level=14]
fill 100 258 604 100 262 604 minecraft:obsidian
setblock 101 258 604 minecraft:crying_obsidian
setblock 102 258 604 minecraft:white_concrete
setblock 105 258 607 minecraft:light[level=14]
setblock 105 258 615 minecraft:light[level=14]
setblock 105 258 623 minecraft:light[level=14]
setblock 105 258 631 minecraft:light[level=14]
setblock 105 258 639 minecraft:light[level=14]
setblock 113 258 607 minecraft:light[level=14]
setblock 113 258 615 minecraft:light[level=14]
setblock 113 258 623 minecraft:light[level=14]
setblock 113 258 631 minecraft:light[level=14]
setblock 113 258 639 minecraft:light[level=14]
setblock 121 258 607 minecraft:light[level=14]
setblock 121 258 615 minecraft:light[level=14]
setblock 121 258 623 minecraft:light[level=14]
setblock 121 258 631 minecraft:light[level=14]
setblock 121 258 639 minecraft:light[level=14]
fill 127 258 646 127 304 646 minecraft:obsidian
setblock 129 258 607 minecraft:light[level=14]
setblock 129 258 615 minecraft:light[level=14]
setblock 129 258 623 minecraft:light[level=14]
setblock 129 258 631 minecraft:light[level=14]
setblock 129 258 639 minecraft:light[level=14]
fill 136 258 606 136 279 606 minecraft:obsidian
setblock 136 258 618 minecraft:crying_obsidian
fill 94 259 629 94 272 629 minecraft:obsidian
fill 101 259 604 102 282 604 minecraft:obsidian
setblock 108 259 604 minecraft:white_concrete
setblock 136 259 607 minecraft:amethyst_block
fill 136 259 618 136 293 618 minecraft:obsidian
setblock 136 259 636 minecraft:amethyst_block
setblock 94 260 638 minecraft:white_concrete
fill 108 260 604 108 290 604 minecraft:obsidian
setblock 112 260 604 minecraft:white_concrete
fill 112 260 633 113 261 634 minecraft:obsidian
fill 113 260 635 113 261 635 minecraft:obsidian
setblock 123 260 646 minecraft:amethyst_block
fill 136 260 607 136 307 607 minecraft:obsidian
fill 136 260 636 136 307 636 minecraft:obsidian
fill 94 261 612 94 263 612 minecraft:purple_stained_glass
setblock 94 261 616 minecraft:white_concrete
fill 94 261 628 94 263 628 minecraft:purple_stained_glass
fill 94 261 638 94 307 638 minecraft:obsidian
fill 94 261 644 94 263 644 minecraft:purple_stained_glass
fill 98 261 604 98 263 604 minecraft:purple_stained_glass
fill 108 261 646 108 263 646 minecraft:purple_stained_glass
fill 112 261 604 112 307 604 minecraft:obsidian
fill 114 261 604 114 263 604 minecraft:purple_stained_glass
fill 123 261 646 123 278 646 minecraft:obsidian
fill 124 261 646 124 263 646 minecraft:purple_stained_glass
fill 130 261 604 130 263 604 minecraft:purple_stained_glass
setblock 131 261 604 minecraft:white_concrete
fill 136 261 614 136 263 614 minecraft:purple_stained_glass
fill 136 261 615 136 269 615 minecraft:obsidian
setblock 136 261 617 minecraft:white_concrete
fill 136 261 630 136 263 630 minecraft:purple_stained_glass
fill 94 262 616 94 307 616 minecraft:obsidian
fill 99 262 646 99 307 646 minecraft:obsidian
setblock 100 262 646 minecraft:amethyst_block
setblock 106 262 646 minecraft:crying_obsidian
fill 131 262 604 131 274 604 minecraft:obsidian
fill 136 262 617 136 267 617 minecraft:obsidian
setblock 94 263 609 minecraft:amethyst_block
fill 94 263 617 94 275 617 minecraft:obsidian
setblock 94 263 618 minecraft:white_concrete
setblock 100 263 604 minecraft:white_concrete
fill 100 263 646 100 307 646 minecraft:obsidian
setblock 103 263 604 minecraft:white_concrete
fill 104 263 604 105 304 604 minecraft:obsidian
fill 106 263 646 106 267 646 minecraft:obsidian
setblock 109 263 604 minecraft:amethyst_block
fill 110 263 604 111 265 604 minecraft:obsidian
fill 94 264 609 94 280 609 minecraft:obsidian
fill 94 264 612 94 269 612 minecraft:obsidian
fill 94 264 618 94 282 618 minecraft:obsidian
fill 94 264 628 94 269 628 minecraft:obsidian
setblock 94 264 644 minecraft:obsidian
setblock 95 264 604 minecraft:amethyst_block
fill 98 264 604 98 269 604 minecraft:obsidian
fill 100 264 604 100 300 604 minecraft:obsidian
fill 103 264 604 103 306 604 minecraft:obsidian
fill 108 264 646 108 269 646 minecraft:obsidian
fill 109 264 604 109 274 604 minecraft:obsidian
fill 114 264 604 114 269 604 minecraft:obsidian
setblock 117 264 646 minecraft:amethyst_block
fill 123 264 641 123 265 642 minecraft:end_stone
fill 124 264 646 124 269 646 minecraft:obsidian
fill 130 264 604 130 269 604 minecraft:obsidian
fill 136 264 614 136 269 614 minecraft:obsidian
fill 136 264 630 136 265 630 minecraft:obsidian
setblock 94 265 644 minecraft:amethyst_block
fill 95 265 604 95 274 604 minecraft:obsidian
setblock 112 265 646 minecraft:amethyst_block
setblock 115 265 646 minecraft:crying_obsidian
fill 117 265 646 117 293 646 minecraft:obsidian
setblock 126 265 646 minecraft:amethyst_block
fill 94 266 644 94 269 644 minecraft:obsidian
setblock 97 266 607 minecraft:light[level=14]
setblock 97 266 615 minecraft:light[level=14]
setblock 97 266 623 minecraft:light[level=14]
setblock 97 266 631 minecraft:light[level=14]
setblock 97 266 639 minecraft:light[level=14]
setblock 105 266 607 minecraft:light[level=14]
setblock 105 266 615 minecraft:light[level=14]
setblock 105 266 623 minecraft:light[level=14]
setblock 105 266 631 minecraft:light[level=14]
setblock 105 266 639 minecraft:light[level=14]
fill 110 266 604 110 307 604 minecraft:obsidian
setblock 111 266 604 minecraft:crying_obsidian
fill 112 266 646 112 277 646 minecraft:obsidian
setblock 113 266 607 minecraft:light[level=14]
setblock 113 266 615 minecraft:light[level=14]
setblock 113 266 623 minecraft:light[level=14]
setblock 113 266 631 minecraft:light[level=14]
setblock 113 266 639 minecraft:light[level=14]
fill 115 266 646 115 307 646 minecraft:obsidian
setblock 121 266 607 minecraft:light[level=14]
setblock 121 266 615 minecraft:light[level=14]
setblock 121 266 623 minecraft:light[level=14]
setblock 121 266 631 minecraft:light[level=14]
setblock 121 266 639 minecraft:light[level=14]
fill 126 266 646 126 275 646 minecraft:obsidian
setblock 129 266 607 minecraft:light[level=14]
setblock 129 266 615 minecraft:light[level=14]
setblock 129 266 623 minecraft:light[level=14]
setblock 129 266 631 minecraft:light[level=14]
setblock 129 266 639 minecraft:light[level=14]
setblock 136 266 630 minecraft:crying_obsidian
setblock 94 267 607 minecraft:amethyst_block
setblock 96 267 604 minecraft:crying_obsidian
fill 105 267 620 107 268 620 minecraft:obsidian
fill 106 267 621 106 268 621 minecraft:obsidian
fill 111 267 604 111 299 604 minecraft:obsidian
fill 118 267 604 118 283 604 minecraft:obsidian
setblock 119 267 604 minecraft:crying_obsidian
setblock 136 267 613 minecraft:crying_obsidian
setblock 136 267 628 minecraft:amethyst_block
fill 136 267 630 136 269 630 minecraft:obsidian
fill 94 268 607 94 307 607 minecraft:obsidian
setblock 94 268 622 minecraft:amethyst_block
setblock 94 268 642 minecraft:crying_obsidian
fill 96 268 604 96 307 604 minecraft:obsidian
setblock 106 268 646 minecraft:amethyst_block
fill 119 268 604 119 294 604 minecraft:obsidian
fill 136 268 613 136 307 613 minecraft:obsidian
setblock 136 268 617 minecraft:white_concrete
fill 136 268 628 136 279 628 minecraft:obsidian
fill 94 269 622 94 270 622 minecraft:obsidian
setblock 94 269 633 minecraft:crying_obsidian
fill 94 269 642 94 302 642 minecraft:obsidian
fill 97 269 623 98 270 627 minecraft:obsidian
fill 98 269 619 98 270 622 minecraft:obsidian
fill 98 269 628 98 270 631 minecraft:obsidian
fill 99 269 617 99 270 619 minecraft:obsidian
fill 99 269 631 99 270 633 minecraft:obsidian
fill 100 269 615 100 270 617 minecraft:obsidian
fill 100 269 633 100 270 635 minecraft:obsidian
fill 101 269 614 101 270 615 minecraft:obsidian
fill 101 269 635 101 270 636 minecraft:obsidian
fill 102 269 613 102 270 614 minecraft:obsidian
fill 102 269 636 102 270 637 minecraft:obsidian
fill 103 269 612 103 270 613 minecraft:obsidian
fill 103 269 637 103 270 638 minecraft:obsidian
setblock 103 269 646 minecraft:crying_obsidian
fill 104 269 611 104 270 612 minecraft:obsidian
fill 104 269 638 104 270 639 minecraft:obsidian
fill 105 269 610 105 270 611 minecraft:obsidian
fill 105 269 639 105 270 640 minecraft:obsidian
fill 106 269 610 107 270 610 minecraft:obsidian
fill 106 269 640 107 270 640 minecraft:obsidian
fill 106 269 646 106 307 646 minecraft:obsidian
setblock 107 269 604 minecraft:amethyst_block
fill 107 269 609 109 270 609 minecraft:obsidian
fill 107 269 641 109 270 641 minecraft:obsidian
fill 109 269 608 121 270 608 minecraft:obsidian
fill 109 269 642 121 270 642 minecraft:obsidian
fill 113 269 607 117 270 607 minecraft:obsidian
fill 113 269 643 117 270 643 minecraft:obsidian
fill 121 269 609 123 270 609 minecraft:obsidian
fill 121 269 641 123 270 641 minecraft:obsidian
fill 123 269 610 125 270 610 minecraft:obsidian
fill 123 269 640 125 270 640 minecraft:obsidian
fill 125 269 611 126 270 611 minecraft:obsidian
fill 125 269 639 126 270 639 minecraft:obsidian
fill 126 269 612 127 270 612 minecraft:obsidian
fill 126 269 638 127 270 638 minecraft:obsidian
fill 127 269 613 128 270 613 minecraft:obsidian
fill 127 269 637 128 270 637 minecraft:obsidian
fill 128 269 614 129 270 614 minecraft:obsidian
fill 128 269 636 129 270 636 minecraft:obsidian
fill 129 269 615 130 270 615 minecraft:obsidian
fill 129 269 635 130 270 635 minecraft:obsidian
fill 130 269 616 130 270 617 minecraft:obsidian
fill 130 269 633 130 270 634 minecraft:obsidian
fill 131 269 617 131 270 619 minecraft:obsidian
fill 131 269 631 131 270 633 minecraft:obsidian
fill 132 269 619 132 270 631 minecraft:obsidian
fill 133 269 623 133 270 627 minecraft:obsidian
fill 136 269 617 136 292 617 minecraft:obsidian
setblock 136 269 629 minecraft:amethyst_block
fill 94 270 612 94 272 612 minecraft:purple_stained_glass
fill 94 270 628 94 272 628 minecraft:purple_stained_glass
fill 94 270 633 94 305 633 minecraft:obsidian
fill 94 270 644 94 272 644 minecraft:purple_stained_glass
fill 98 270 604 98 272 604 minecraft:purple_stained_glass
fill 103 270 646 103 295 646 minecraft:obsidian
fill 107 270 604 107 287 604 minecraft:obsidian
fill 108 270 646 108 272 646 minecraft:purple_stained_glass
fill 114 270 604 114 272 604 minecraft:purple_stained_glass
setblock 117 270 604 minecraft:amethyst_block
fill 117 270 637 119 271 638 minecraft:netherrack
fill 124 270 646 124 272 646 minecraft:purple_stained_glass
fill 130 270 604 130 272 604 minecraft:purple_stained_glass
fill 136 270 614 136 272 614 minecraft:purple_stained_glass
setblock 136 270 615 minecraft:crying_obsidian
fill 136 270 629 136 307 629 minecraft:obsidian
fill 136 270 630 136 272 630 minecraft:purple_stained_glass
setblock 136 270 643 minecraft:amethyst_block
setblock 94 271 622 minecraft:white_concrete
setblock 94 271 631 minecraft:crying_obsidian
setblock 94 271 635 minecraft:white_concrete
fill 106 271 641 107 271 641 minecraft:crying_obsidian
fill 108 271 642 110 271 642 minecraft:crying_obsidian
fill 111 271 643 119 271 643 minecraft:crying_obsidian
fill 117 271 604 117 301 604 minecraft:obsidian
fill 120 271 642 122 271 642 minecraft:crying_obsidian
setblock 132 271 646 minecraft:crying_obsidian
fill 136 271 615 136 307 615 minecraft:obsidian
fill 136 271 643 136 277 643 minecraft:obsidian
fill 94 272 622 94 290 622 minecraft:obsidian
fill 94 272 631 94 286 631 minecraft:obsidian
fill 94 272 635 94 297 635 minecraft:obsidian
setblock 94 272 641 minecraft:white_concrete
setblock 111 272 646 minecraft:white_concrete
fill 132 272 646 132 273 646 minecraft:obsidian
fill 94 273 612 94 287 612 minecraft:obsidian
fill 94 273 628 94 284 628 minecraft:obsidian
setblock 94 273 629 minecraft:amethyst_block
fill 94 273 641 94 307 641 minecraft:obsidian
fill 94 273 644 94 287 644 minecraft:obsidian
fill 98 273 604 98 287 604 minecraft:obsidian
fill 108 273 646 108 287 646 minecraft:obsidian
fill 111 273 646 111 293 646 minecraft:obsidian
fill 114 273 604 114 287 604 minecraft:obsidian
setblock 120 273 604 minecraft:amethyst_block
fill 121 273 604 121 307 604 minecraft:obsidian
fill 124 273 646 124 287 646 minecraft:obsidian
setblock 125 273 646 minecraft:crying_obsidian
setblock 130 273 604 minecraft:obsidian
setblock 132 273 604 minecraft:white_concrete
setblock 135 273 604 minecraft:amethyst_block
fill 136 273 604 136 307 604 minecraft:obsidian
fill 136 273 614 136 277 614 minecraft:obsidian
fill 136 273 630 136 277 630 minecraft:obsidian
fill 94 274 629 94 307 629 minecraft:obsidian
setblock 97 274 607 minecraft:light[level=14]
setblock 97 274 615 minecraft:light[level=14]
setblock 97 274 623 minecraft:light[level=14]
setblock 97 274 631 minecraft:light[level=14]
setblock 97 274 639 minecraft:light[level=14]
setblock 105 274 607 minecraft:light[level=14]
setblock 105 274 615 minecraft:light[level=14]
setblock 105 274 623 minecraft:light[level=14]
setblock 105 274 631 minecraft:light[level=14]
setblock 105 274 639 minecraft:light[level=14]
setblock 113 274 607 minecraft:light[level=14]
setblock 113 274 615 minecraft:light[level=14]
setblock 113 274 623 minecraft:light[level=14]
setblock 113 274 631 minecraft:light[level=14]
setblock 113 274 639 minecraft:light[level=14]
fill 120 274 604 120 307 604 minecraft:obsidian
setblock 121 274 607 minecraft:light[level=14]
setblock 121 274 615 minecraft:light[level=14]
setblock 121 274 623 minecraft:light[level=14]
setblock 121 274 631 minecraft:light[level=14]
setblock 121 274 639 minecraft:light[level=14]
fill 125 274 646 125 283 646 minecraft:obsidian
setblock 129 274 604 minecraft:amethyst_block
setblock 129 274 607 minecraft:light[level=14]
setblock 129 274 615 minecraft:light[level=14]
setblock 129 274 623 minecraft:light[level=14]
setblock 129 274 631 minecraft:light[level=14]
setblock 129 274 639 minecraft:light[level=14]
setblock 130 274 604 minecraft:crying_obsidian
fill 132 274 604 132 301 604 minecraft:obsidian
setblock 132 274 646 minecraft:crying_obsidian
fill 135 274 604 135 307 604 minecraft:obsidian
setblock 136 274 632 minecraft:amethyst_block
setblock 95 275 604 minecraft:white_concrete
setblock 109 275 604 minecraft:amethyst_block
setblock 121 275 646 minecraft:crying_obsidian
fill 129 275 604 130 280 604 minecraft:obsidian
setblock 131 275 604 minecraft:amethyst_block
fill 132 275 646 132 300 646 minecraft:obsidian
setblock 136 275 625 minecraft:white_concrete
fill 136 275 626 136 307 626 minecraft:obsidian
setblock 136 275 627 minecraft:crying_obsidian
fill 136 275 632 136 277 632 minecraft:obsidian
setblock 94 276 617 minecraft:amethyst_block
fill 95 276 604 95 295 604 minecraft:obsidian
fill 109 276 604 109 307 604 minecraft:obsidian
fill 121 276 646 121 307 646 minecraft:obsidian
setblock 126 276 646 minecraft:amethyst_block
fill 131 276 604 131 307 604 minecraft:obsidian
fill 136 276 625 136 307 625 minecraft:obsidian
fill 136 276 627 136 307 627 minecraft:obsidian
setblock 94 277 615 minecraft:white_concrete
fill 94 277 617 94 307 617 minecraft:obsidian
setblock 102 277 646 minecraft:white_concrete
fill 126 277 646 126 286 646 minecraft:obsidian
fill 94 278 615 94 306 615 minecraft:obsidian
setblock 94 278 645 minecraft:crying_obsidian
setblock 102 278 646 minecraft:crying_obsidian
fill 112 278 646 113 278 646 minecraft:crying_obsidian
fill 114 278 628 116 278 630 minecraft:redstone_block
fill 116 278 619 118 278 621 minecraft:redstone_block
fill 121 278 621 123 278 623 minecraft:redstone_block
fill 121 278 627 123 278 629 minecraft:redstone_block
setblock 136 278 614 minecraft:amethyst_block
setblock 136 278 630 minecraft:white_concrete
setblock 136 278 632 minecraft:white_concrete
setblock 136 278 643 minecraft:amethyst_block
fill 94 279 645 94 307 645 minecraft:obsidian
fill 102 279 646 102 307 646 minecraft:obsidian
fill 106 279 613 107 279 637 minecraft:obsidian
fill 108 279 613 130 279 614 minecraft:obsidian
fill 108 279 615 113 279 635 minecraft:purple_stained_glass
fill 108 279 636 130 279 637 minecraft:obsidian
fill 112 279 646 113 279 646 minecraft:obsidian
fill 114 279 615 115 279 627 minecraft:purple_stained_glass
fill 114 279 631 128 279 635 minecraft:purple_stained_glass
fill 116 279 615 128 279 618 minecraft:purple_stained_glass
fill 116 279 622 116 279 627 minecraft:purple_stained_glass
fill 117 279 622 120 279 623 minecraft:purple_stained_glass
fill 117 279 627 120 279 630 minecraft:purple_stained_glass
fill 119 279 619 120 279 621 minecraft:purple_stained_glass
fill 120 279 624 128 279 626 minecraft:purple_stained_glass
fill 121 279 619 128 279 620 minecraft:purple_stained_glass
fill 121 279 630 128 279 630 minecraft:purple_stained_glass
setblock 123 279 646 minecraft:white_concrete
fill 124 279 621 128 279 623 minecraft:purple_stained_glass
fill 124 279 627 128 279 629 minecraft:purple_stained_glass
fill 129 279 615 130 279 635 minecraft:obsidian
fill 136 279 614 136 287 614 minecraft:obsidian
fill 136 279 630 136 287 630 minecraft:obsidian
fill 136 279 632 136 307 632 minecraft:obsidian
fill 136 279 643 136 307 643 minecraft:obsidian
fill 95 280 605 105 280 645 minecraft:netherrack
fill 106 280 605 135 280 612 minecraft:netherrack
fill 106 280 613 106 280 615 minecraft:obsidian
setblock 106 280 616 minecraft:crying_obsidian
fill 106 280 617 106 280 619 minecraft:obsidian
setblock 106 280 620 minecraft:crying_obsidian
fill 106 280 621 106 280 623 minecraft:obsidian
setblock 106 280 624 minecraft:crying_obsidian
fill 106 280 625 106 280 627 minecraft:obsidian
setblock 106 280 628 minecraft:crying_obsidian
fill 106 280 629 106 280 631 minecraft:obsidian
setblock 106 280 632 minecraft:crying_obsidian
fill 106 280 633 106 280 635 minecraft:obsidian
setblock 106 280 636 minecraft:crying_obsidian
fill 106 280 637 108 280 637 minecraft:obsidian
fill 106 280 638 135 280 645 minecraft:netherrack
fill 107 280 613 107 284 614 minecraft:obsidian
setblock 107 280 615 minecraft:crying_obsidian
fill 107 280 616 107 280 618 minecraft:obsidian
setblock 107 280 619 minecraft:crying_obsidian
fill 107 280 620 107 280 622 minecraft:obsidian
setblock 107 280 623 minecraft:crying_obsidian
fill 107 280 624 107 280 626 minecraft:obsidian
setblock 107 280 627 minecraft:crying_obsidian
fill 107 280 628 107 280 630 minecraft:obsidian
setblock 107 280 631 minecraft:crying_obsidian
fill 107 280 632 107 280 634 minecraft:obsidian
setblock 107 280 635 minecraft:crying_obsidian
fill 107 280 636 109 280 636 minecraft:obsidian
setblock 108 280 613 minecraft:obsidian
schedule function dropper:buildpart/146_2 1t
