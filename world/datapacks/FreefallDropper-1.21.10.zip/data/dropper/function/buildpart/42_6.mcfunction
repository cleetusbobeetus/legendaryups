fill 322 125 211 322 128 211 minecraft:red_nether_bricks
setblock 323 125 184 minecraft:polished_blackstone
fill 323 125 185 323 128 185 minecraft:red_nether_bricks
setblock 323 125 189 minecraft:polished_blackstone
fill 323 125 190 323 128 190 minecraft:red_nether_bricks
setblock 323 125 194 minecraft:polished_blackstone
fill 323 125 195 323 128 195 minecraft:red_nether_bricks
setblock 323 125 199 minecraft:polished_blackstone
fill 323 125 200 323 128 200 minecraft:red_nether_bricks
setblock 323 125 204 minecraft:polished_blackstone
fill 323 125 205 323 128 205 minecraft:red_nether_bricks
setblock 323 125 209 minecraft:polished_blackstone
fill 323 125 210 323 128 210 minecraft:red_nether_bricks
setblock 283 126 183 minecraft:polished_blackstone
fill 283 126 184 283 129 184 minecraft:red_nether_bricks
setblock 283 126 188 minecraft:polished_blackstone
fill 283 126 189 283 126 192 minecraft:red_nether_bricks
setblock 283 126 193 minecraft:polished_blackstone
fill 283 126 194 283 129 194 minecraft:red_nether_bricks
setblock 283 126 198 minecraft:polished_blackstone
fill 283 126 199 283 129 199 minecraft:red_nether_bricks
setblock 283 126 203 minecraft:polished_blackstone
fill 283 126 204 283 129 204 minecraft:red_nether_bricks
setblock 283 126 208 minecraft:polished_blackstone
fill 283 126 209 283 129 209 minecraft:red_nether_bricks
setblock 283 126 212 minecraft:red_nether_bricks
setblock 284 126 182 minecraft:polished_blackstone
fill 284 126 183 284 129 183 minecraft:red_nether_bricks
setblock 284 126 186 minecraft:red_nether_bricks
setblock 284 126 187 minecraft:polished_blackstone
fill 284 126 188 284 129 188 minecraft:red_nether_bricks
setblock 284 126 192 minecraft:polished_blackstone
setblock 284 126 202 minecraft:polished_blackstone
fill 284 126 203 284 127 203 minecraft:red_nether_bricks
setblock 284 126 207 minecraft:polished_blackstone
setblock 284 126 222 minecraft:polished_blackstone
fill 285 126 182 285 129 182 minecraft:red_nether_bricks
setblock 285 126 186 minecraft:polished_blackstone
fill 285 126 187 285 129 187 minecraft:red_nether_bricks
fill 285 126 222 285 129 222 minecraft:red_nether_bricks
setblock 287 126 184 minecraft:polished_blackstone
setblock 288 126 183 minecraft:polished_blackstone
fill 288 126 184 288 128 184 minecraft:red_nether_bricks
setblock 289 126 182 minecraft:polished_blackstone
fill 289 126 183 289 129 183 minecraft:red_nether_bricks
setblock 289 126 222 minecraft:polished_blackstone
fill 290 126 182 290 129 182 minecraft:red_nether_bricks
fill 290 126 222 290 129 222 minecraft:red_nether_bricks
setblock 293 126 183 minecraft:polished_blackstone
fill 293 126 184 294 128 184 minecraft:red_nether_bricks
setblock 294 126 182 minecraft:polished_blackstone
fill 294 126 183 294 129 183 minecraft:red_nether_bricks
setblock 294 126 222 minecraft:polished_blackstone
fill 295 126 182 295 129 182 minecraft:red_nether_bricks
setblock 295 126 221 minecraft:polished_blackstone
fill 295 126 222 295 129 222 minecraft:red_nether_bricks
setblock 296 126 184 minecraft:red_nether_bricks
fill 296 126 221 296 129 221 minecraft:red_nether_bricks
setblock 297 126 184 minecraft:polished_blackstone
setblock 298 126 183 minecraft:polished_blackstone
fill 298 126 184 298 129 184 minecraft:red_nether_bricks
fill 298 126 220 298 128 220 minecraft:red_nether_bricks
setblock 299 126 182 minecraft:polished_blackstone
fill 299 126 183 299 129 183 minecraft:red_nether_bricks
fill 299 126 217 299 126 219 minecraft:polished_blackstone
setblock 299 126 222 minecraft:polished_blackstone
fill 300 126 182 300 129 182 minecraft:red_nether_bricks
fill 300 126 217 301 126 217 minecraft:polished_blackstone
fill 300 126 219 301 126 219 minecraft:polished_blackstone
setblock 300 126 221 minecraft:polished_blackstone
fill 300 126 222 300 129 222 minecraft:red_nether_bricks
setblock 301 126 184 minecraft:red_nether_bricks
setblock 301 126 218 minecraft:polished_blackstone
setblock 301 126 220 minecraft:polished_blackstone
fill 301 126 221 301 129 221 minecraft:red_nether_bricks
setblock 302 126 184 minecraft:polished_blackstone
setblock 302 126 220 minecraft:red_nether_bricks
setblock 303 126 183 minecraft:polished_blackstone
setblock 303 126 184 minecraft:red_nether_bricks
setblock 304 126 182 minecraft:polished_blackstone
fill 304 126 183 304 128 183 minecraft:red_nether_bricks
setblock 304 126 222 minecraft:polished_blackstone
fill 305 126 182 305 129 182 minecraft:red_nether_bricks
setblock 305 126 221 minecraft:polished_blackstone
fill 305 126 222 305 129 222 minecraft:red_nether_bricks
fill 307 126 222 308 126 222 minecraft:red_nether_bricks
setblock 314 126 182 minecraft:polished_blackstone
fill 315 126 182 315 129 182 minecraft:red_nether_bricks
fill 316 126 183 317 126 183 minecraft:red_nether_bricks
setblock 318 126 183 minecraft:polished_blackstone
setblock 319 126 182 minecraft:polished_blackstone
fill 319 126 183 319 128 184 minecraft:red_nether_bricks
setblock 319 126 222 minecraft:polished_blackstone
fill 320 126 182 320 129 182 minecraft:red_nether_bricks
setblock 320 126 201 minecraft:polished_blackstone
fill 320 126 202 320 128 202 minecraft:red_nether_bricks
setblock 320 126 206 minecraft:polished_blackstone
fill 320 126 207 320 128 208 minecraft:red_nether_bricks
fill 320 126 222 320 129 222 minecraft:red_nether_bricks
setblock 321 126 184 minecraft:red_nether_bricks
setblock 321 126 185 minecraft:polished_blackstone
fill 321 126 186 321 129 186 minecraft:red_nether_bricks
fill 321 126 188 321 126 189 minecraft:red_nether_bricks
setblock 321 126 190 minecraft:polished_blackstone
setblock 321 126 200 minecraft:polished_blackstone
fill 321 126 201 321 129 201 minecraft:red_nether_bricks
setblock 321 126 205 minecraft:polished_blackstone
fill 321 126 206 321 129 206 minecraft:red_nether_bricks
setblock 321 126 210 minecraft:polished_blackstone
setblock 322 126 184 minecraft:polished_blackstone
fill 322 126 185 322 129 185 minecraft:red_nether_bricks
setblock 322 126 188 minecraft:red_nether_bricks
setblock 322 126 189 minecraft:polished_blackstone
fill 322 126 190 322 129 190 minecraft:red_nether_bricks
fill 322 126 192 322 126 193 minecraft:red_nether_bricks
setblock 322 126 194 minecraft:polished_blackstone
fill 322 126 195 322 129 195 minecraft:red_nether_bricks
setblock 322 126 199 minecraft:polished_blackstone
fill 322 126 200 322 129 200 minecraft:red_nether_bricks
setblock 322 126 204 minecraft:polished_blackstone
fill 322 126 205 322 129 205 minecraft:red_nether_bricks
setblock 322 126 209 minecraft:polished_blackstone
fill 322 126 210 322 129 210 minecraft:red_nether_bricks
fill 322 126 212 322 127 212 minecraft:red_nether_bricks
setblock 323 126 183 minecraft:polished_blackstone
fill 323 126 184 323 129 184 minecraft:red_nether_bricks
setblock 323 126 188 minecraft:polished_blackstone
fill 323 126 189 323 129 189 minecraft:red_nether_bricks
setblock 323 126 193 minecraft:polished_blackstone
fill 323 126 194 323 129 194 minecraft:red_nether_bricks
setblock 323 126 198 minecraft:polished_blackstone
fill 323 126 199 323 129 199 minecraft:red_nether_bricks
setblock 323 126 203 minecraft:polished_blackstone
fill 323 126 204 323 129 204 minecraft:red_nether_bricks
setblock 323 126 208 minecraft:polished_blackstone
fill 323 126 209 323 129 209 minecraft:red_nether_bricks
setblock 323 126 213 minecraft:polished_blackstone
fill 323 126 214 323 129 214 minecraft:red_nether_bricks
setblock 283 127 182 minecraft:polished_blackstone
fill 283 127 183 283 130 183 minecraft:red_nether_bricks
setblock 283 127 187 minecraft:polished_blackstone
fill 283 127 188 283 127 191 minecraft:red_nether_bricks
setblock 283 127 192 minecraft:polished_blackstone
fill 283 127 193 284 129 193 minecraft:red_nether_bricks
setblock 283 127 197 minecraft:polished_blackstone
fill 283 127 198 283 129 198 minecraft:red_nether_bricks
setblock 283 127 202 minecraft:polished_blackstone
fill 283 127 203 283 130 203 minecraft:red_nether_bricks
setblock 283 127 207 minecraft:polished_blackstone
fill 283 127 208 284 128 208 minecraft:red_nether_bricks
setblock 283 127 212 minecraft:polished_blackstone
setblock 283 127 221 minecraft:red_nether_bricks
setblock 283 127 222 minecraft:polished_blackstone
fill 284 127 182 284 130 182 minecraft:red_nether_bricks
setblock 284 127 186 minecraft:polished_blackstone
fill 284 127 187 284 130 187 minecraft:red_nether_bricks
setblock 284 127 191 minecraft:polished_blackstone
fill 284 127 192 284 130 192 minecraft:red_nether_bricks
setblock 284 127 206 minecraft:polished_blackstone
fill 284 127 207 284 128 207 minecraft:red_nether_bricks
fill 284 127 222 284 129 222 minecraft:red_nether_bricks
setblock 285 127 185 minecraft:polished_blackstone
fill 285 127 186 285 130 186 minecraft:red_nether_bricks
setblock 285 127 189 minecraft:red_nether_bricks
setblock 286 127 184 minecraft:polished_blackstone
setblock 287 127 183 minecraft:polished_blackstone
fill 287 127 184 287 129 184 minecraft:red_nether_bricks
setblock 288 127 182 minecraft:polished_blackstone
fill 288 127 183 288 130 183 minecraft:red_nether_bricks
setblock 288 127 222 minecraft:polished_blackstone
fill 289 127 182 289 130 182 minecraft:red_nether_bricks
fill 289 127 222 289 130 222 minecraft:red_nether_bricks
setblock 291 127 184 minecraft:polished_blackstone
setblock 292 127 183 minecraft:polished_blackstone
fill 292 127 184 292 130 184 minecraft:red_nether_bricks
setblock 293 127 182 minecraft:polished_blackstone
fill 293 127 183 293 130 183 minecraft:red_nether_bricks
setblock 293 127 222 minecraft:polished_blackstone
fill 294 127 182 294 130 182 minecraft:red_nether_bricks
setblock 294 127 221 minecraft:polished_blackstone
fill 294 127 222 294 130 222 minecraft:red_nether_bricks
fill 295 127 221 295 130 221 minecraft:red_nether_bricks
setblock 296 127 184 minecraft:polished_blackstone
setblock 297 127 183 minecraft:polished_blackstone
fill 297 127 184 297 130 184 minecraft:red_nether_bricks
setblock 298 127 182 minecraft:polished_blackstone
fill 298 127 183 298 130 183 minecraft:red_nether_bricks
fill 298 127 185 298 128 185 minecraft:red_nether_bricks
setblock 298 127 222 minecraft:polished_blackstone
fill 299 127 182 299 130 182 minecraft:red_nether_bricks
setblock 299 127 221 minecraft:polished_blackstone
fill 299 127 222 299 130 222 minecraft:red_nether_bricks
setblock 300 127 220 minecraft:polished_blackstone
fill 300 127 221 300 130 221 minecraft:red_nether_bricks
setblock 301 127 184 minecraft:polished_blackstone
fill 301 127 220 301 128 220 minecraft:red_nether_bricks
setblock 302 127 183 minecraft:polished_blackstone
fill 302 127 184 302 128 184 minecraft:red_nether_bricks
setblock 303 127 182 minecraft:polished_blackstone
fill 303 127 183 303 129 183 minecraft:red_nether_bricks
setblock 303 127 222 minecraft:polished_blackstone
fill 304 127 182 304 130 182 minecraft:red_nether_bricks
setblock 304 127 221 minecraft:polished_blackstone
fill 304 127 222 304 130 222 minecraft:red_nether_bricks
setblock 307 127 222 minecraft:red_nether_bricks
setblock 313 127 182 minecraft:polished_blackstone
fill 314 127 182 314 130 182 minecraft:red_nether_bricks
fill 315 127 222 315 129 222 minecraft:red_nether_bricks
setblock 316 127 183 minecraft:red_nether_bricks
setblock 317 127 183 minecraft:polished_blackstone
setblock 318 127 182 minecraft:polished_blackstone
fill 318 127 183 318 129 184 minecraft:red_nether_bricks
setblock 318 127 222 minecraft:polished_blackstone
fill 319 127 182 319 130 182 minecraft:red_nether_bricks
fill 319 127 222 319 130 222 minecraft:red_nether_bricks
setblock 320 127 201 minecraft:red_nether_bricks
setblock 320 127 205 minecraft:polished_blackstone
fill 320 127 206 320 130 206 minecraft:red_nether_bricks
setblock 320 127 209 minecraft:red_nether_bricks
setblock 321 127 184 minecraft:polished_blackstone
fill 321 127 185 321 130 185 minecraft:red_nether_bricks
setblock 321 127 188 minecraft:red_nether_bricks
setblock 321 127 189 minecraft:polished_blackstone
fill 321 127 190 321 127 193 minecraft:red_nether_bricks
fill 321 127 197 321 128 197 minecraft:red_nether_bricks
setblock 321 127 199 minecraft:polished_blackstone
fill 321 127 200 321 129 200 minecraft:red_nether_bricks
setblock 321 127 204 minecraft:polished_blackstone
fill 321 127 205 321 130 205 minecraft:red_nether_bricks
setblock 321 127 208 minecraft:red_nether_bricks
setblock 321 127 209 minecraft:polished_blackstone
fill 321 127 210 321 129 211 minecraft:red_nether_bricks
setblock 322 127 183 minecraft:polished_blackstone
fill 322 127 184 322 130 184 minecraft:red_nether_bricks
setblock 322 127 188 minecraft:polished_blackstone
fill 322 127 189 322 130 189 minecraft:red_nether_bricks
setblock 322 127 192 minecraft:red_nether_bricks
setblock 322 127 193 minecraft:polished_blackstone
fill 322 127 194 322 130 194 minecraft:red_nether_bricks
setblock 322 127 198 minecraft:polished_blackstone
fill 322 127 199 322 130 199 minecraft:red_nether_bricks
setblock 322 127 203 minecraft:polished_blackstone
fill 322 127 204 322 130 204 minecraft:red_nether_bricks
setblock 322 127 208 minecraft:polished_blackstone
fill 322 127 209 322 130 209 minecraft:red_nether_bricks
setblock 323 127 182 minecraft:polished_blackstone
fill 323 127 183 323 130 183 minecraft:red_nether_bricks
setblock 323 127 187 minecraft:polished_blackstone
fill 323 127 188 323 130 188 minecraft:red_nether_bricks
setblock 323 127 192 minecraft:polished_blackstone
fill 323 127 193 323 130 193 minecraft:red_nether_bricks
setblock 323 127 197 minecraft:polished_blackstone
fill 323 127 198 323 130 198 minecraft:red_nether_bricks
setblock 323 127 202 minecraft:polished_blackstone
fill 323 127 203 323 130 203 minecraft:red_nether_bricks
setblock 323 127 207 minecraft:polished_blackstone
fill 323 127 208 323 130 208 minecraft:red_nether_bricks
setblock 323 127 212 minecraft:polished_blackstone
fill 323 127 213 323 130 213 minecraft:red_nether_bricks
setblock 323 127 222 minecraft:polished_blackstone
fill 283 128 182 283 131 182 minecraft:red_nether_bricks
setblock 283 128 186 minecraft:polished_blackstone
fill 283 128 187 283 128 190 minecraft:red_nether_bricks
setblock 283 128 191 minecraft:polished_blackstone
fill 283 128 192 283 131 192 minecraft:red_nether_bricks
setblock 283 128 196 minecraft:polished_blackstone
fill 283 128 197 283 130 197 minecraft:red_nether_bricks
setblock 283 128 201 minecraft:polished_blackstone
fill 283 128 202 283 130 202 minecraft:red_nether_bricks
setblock 283 128 206 minecraft:polished_blackstone
fill 283 128 207 283 131 207 minecraft:red_nether_bricks
setblock 283 128 210 minecraft:red_nether_bricks
setblock 283 128 211 minecraft:polished_blackstone
fill 283 128 212 283 130 213 minecraft:red_nether_bricks
setblock 283 128 221 minecraft:polished_blackstone
fill 283 128 222 283 130 222 minecraft:red_nether_bricks
setblock 284 128 185 minecraft:polished_blackstone
fill 284 128 186 284 131 186 minecraft:red_nether_bricks
setblock 284 128 190 minecraft:polished_blackstone
fill 284 128 191 284 131 191 minecraft:red_nether_bricks
setblock 284 128 205 minecraft:polished_blackstone
setblock 284 128 206 minecraft:red_nether_bricks
setblock 285 128 184 minecraft:polished_blackstone
fill 285 128 185 285 130 185 minecraft:red_nether_bricks
setblock 285 128 189 minecraft:polished_blackstone
setblock 286 128 183 minecraft:polished_blackstone
fill 286 128 184 286 129 184 minecraft:red_nether_bricks
setblock 287 128 182 minecraft:polished_blackstone
fill 287 128 183 287 131 183 minecraft:red_nether_bricks
setblock 287 128 222 minecraft:polished_blackstone
fill 288 128 182 288 131 182 minecraft:red_nether_bricks
setblock 288 128 222 minecraft:red_nether_bricks
setblock 289 128 184 minecraft:red_nether_bricks
setblock 290 128 184 minecraft:polished_blackstone
setblock 291 128 183 minecraft:polished_blackstone
fill 291 128 184 291 129 184 minecraft:red_nether_bricks
setblock 292 128 182 minecraft:polished_blackstone
fill 292 128 183 292 131 183 minecraft:red_nether_bricks
setblock 292 128 222 minecraft:polished_blackstone
fill 293 128 182 293 131 182 minecraft:red_nether_bricks
fill 293 128 222 293 131 222 minecraft:red_nether_bricks
fill 294 128 221 294 131 221 minecraft:red_nether_bricks
setblock 295 128 183 minecraft:red_nether_bricks
setblock 295 128 184 minecraft:polished_blackstone
setblock 296 128 183 minecraft:polished_blackstone
fill 296 128 184 296 129 185 minecraft:red_nether_bricks
setblock 297 128 182 minecraft:polished_blackstone
fill 297 128 183 297 131 183 minecraft:red_nether_bricks
fill 297 128 185 297 129 185 minecraft:red_nether_bricks
fill 297 128 220 297 129 220 minecraft:red_nether_bricks
setblock 297 128 222 minecraft:polished_blackstone
fill 298 128 182 298 131 182 minecraft:red_nether_bricks
setblock 298 128 221 minecraft:polished_blackstone
fill 298 128 222 298 131 222 minecraft:red_nether_bricks
setblock 299 128 185 minecraft:polished_blackstone
setblock 299 128 220 minecraft:polished_blackstone
fill 299 128 221 299 131 221 minecraft:red_nether_bricks
setblock 300 128 184 minecraft:polished_blackstone
fill 300 128 220 300 129 220 minecraft:red_nether_bricks
setblock 301 128 183 minecraft:polished_blackstone
fill 301 128 184 301 129 184 minecraft:red_nether_bricks
setblock 302 128 182 minecraft:polished_blackstone
fill 302 128 183 302 130 183 minecraft:red_nether_bricks
setblock 302 128 222 minecraft:polished_blackstone
fill 303 128 182 303 130 182 minecraft:red_nether_bricks
setblock 303 128 221 minecraft:polished_blackstone
fill 303 128 222 303 131 222 minecraft:red_nether_bricks
setblock 304 128 221 minecraft:red_nether_bricks
fill 309 128 207 309 129 207 minecraft:magma_block
fill 313 128 182 313 130 182 minecraft:red_nether_bricks
setblock 315 128 183 minecraft:red_nether_bricks
setblock 316 128 183 minecraft:polished_blackstone
setblock 317 128 182 minecraft:polished_blackstone
fill 317 128 183 317 130 184 minecraft:red_nether_bricks
setblock 317 128 222 minecraft:polished_blackstone
fill 318 128 182 318 131 182 minecraft:red_nether_bricks
fill 318 128 222 318 130 222 minecraft:red_nether_bricks
setblock 320 128 183 minecraft:red_nether_bricks
setblock 320 128 184 minecraft:polished_blackstone
fill 320 128 185 320 128 188 minecraft:red_nether_bricks
setblock 320 128 189 minecraft:polished_blackstone
setblock 320 128 204 minecraft:polished_blackstone
fill 320 128 205 320 130 205 minecraft:red_nether_bricks
setblock 320 128 209 minecraft:polished_blackstone
fill 320 128 210 320 129 210 minecraft:red_nether_bricks
setblock 321 128 183 minecraft:polished_blackstone
fill 321 128 184 321 131 184 minecraft:red_nether_bricks
setblock 321 128 188 minecraft:polished_blackstone
fill 321 128 189 321 128 192 minecraft:red_nether_bricks
setblock 321 128 193 minecraft:polished_blackstone
fill 321 128 194 321 129 196 minecraft:red_nether_bricks
setblock 321 128 198 minecraft:polished_blackstone
fill 321 128 199 321 129 199 minecraft:red_nether_bricks
setblock 321 128 203 minecraft:polished_blackstone
fill 321 128 204 321 130 204 minecraft:red_nether_bricks
setblock 321 128 208 minecraft:polished_blackstone
fill 321 128 209 321 131 209 minecraft:red_nether_bricks
setblock 322 128 182 minecraft:polished_blackstone
fill 322 128 183 322 131 183 minecraft:red_nether_bricks
setblock 322 128 187 minecraft:polished_blackstone
fill 322 128 188 322 131 188 minecraft:red_nether_bricks
setblock 322 128 192 minecraft:polished_blackstone
fill 322 128 193 322 131 193 minecraft:red_nether_bricks
setblock 322 128 197 minecraft:polished_blackstone
fill 322 128 198 322 131 198 minecraft:red_nether_bricks
setblock 322 128 202 minecraft:polished_blackstone
fill 322 128 203 322 131 203 minecraft:red_nether_bricks
setblock 322 128 207 minecraft:polished_blackstone
fill 322 128 208 322 131 208 minecraft:red_nether_bricks
setblock 322 128 212 minecraft:polished_blackstone
fill 322 128 213 322 130 213 minecraft:red_nether_bricks
setblock 322 128 222 minecraft:polished_blackstone
fill 323 128 182 323 131 182 minecraft:red_nether_bricks
setblock 323 128 186 minecraft:polished_blackstone
fill 323 128 187 323 131 187 minecraft:red_nether_bricks
setblock 323 128 191 minecraft:polished_blackstone
fill 323 128 192 323 131 192 minecraft:red_nether_bricks
setblock 323 128 196 minecraft:polished_blackstone
fill 323 128 197 323 131 197 minecraft:red_nether_bricks
setblock 323 128 201 minecraft:polished_blackstone
fill 323 128 202 323 131 202 minecraft:red_nether_bricks
setblock 323 128 206 minecraft:polished_blackstone
fill 323 128 207 323 131 207 minecraft:red_nether_bricks
setblock 323 128 211 minecraft:polished_blackstone
fill 323 128 212 323 131 212 minecraft:red_nether_bricks
setblock 323 128 222 minecraft:red_nether_bricks
setblock 283 129 185 minecraft:polished_blackstone
fill 283 129 186 283 129 189 minecraft:red_nether_bricks
setblock 283 129 190 minecraft:polished_blackstone
fill 283 129 191 283 132 191 minecraft:red_nether_bricks
setblock 283 129 195 minecraft:polished_blackstone
fill 283 129 196 283 131 196 minecraft:red_nether_bricks
setblock 283 129 200 minecraft:polished_blackstone
setblock 283 129 201 minecraft:red_nether_bricks
setblock 283 129 205 minecraft:polished_blackstone
fill 283 129 206 283 131 206 minecraft:red_nether_bricks
fill 283 129 208 283 130 208 minecraft:red_nether_bricks
setblock 283 129 210 minecraft:polished_blackstone
fill 283 129 211 283 132 211 minecraft:red_nether_bricks
setblock 283 129 214 minecraft:red_nether_bricks
setblock 283 129 221 minecraft:red_nether_bricks
setblock 284 129 184 minecraft:polished_blackstone
fill 284 129 185 284 132 185 minecraft:red_nether_bricks
setblock 284 129 189 minecraft:polished_blackstone
fill 284 129 190 284 132 190 minecraft:red_nether_bricks
setblock 285 129 183 minecraft:polished_blackstone
fill 285 129 184 285 130 184 minecraft:red_nether_bricks
setblock 285 129 188 minecraft:polished_blackstone
fill 285 129 189 285 130 189 minecraft:red_nether_bricks
setblock 286 129 182 minecraft:polished_blackstone
fill 286 129 183 286 131 183 minecraft:red_nether_bricks
fill 287 129 182 287 132 182 minecraft:red_nether_bricks
setblock 290 129 183 minecraft:polished_blackstone
setblock 291 129 182 minecraft:polished_blackstone
fill 291 129 183 291 132 183 minecraft:red_nether_bricks
setblock 291 129 222 minecraft:polished_blackstone
fill 292 129 182 292 132 182 minecraft:red_nether_bricks
fill 292 129 222 292 132 222 minecraft:red_nether_bricks
setblock 293 129 184 minecraft:red_nether_bricks
fill 293 129 221 293 132 221 minecraft:red_nether_bricks
setblock 294 129 184 minecraft:polished_blackstone
setblock 295 129 183 minecraft:polished_blackstone
fill 295 129 184 295 132 184 minecraft:red_nether_bricks
setblock 296 129 182 minecraft:polished_blackstone
fill 296 129 183 296 132 183 minecraft:red_nether_bricks
setblock 296 129 222 minecraft:polished_blackstone
fill 297 129 182 297 132 182 minecraft:red_nether_bricks
setblock 297 129 221 minecraft:polished_blackstone
fill 297 129 222 297 132 222 minecraft:red_nether_bricks
setblock 298 129 185 minecraft:polished_blackstone
setblock 298 129 220 minecraft:polished_blackstone
fill 298 129 221 298 132 221 minecraft:red_nether_bricks
setblock 299 129 184 minecraft:polished_blackstone
fill 299 129 220 299 130 220 minecraft:red_nether_bricks
setblock 300 129 183 minecraft:polished_blackstone
fill 300 129 184 300 130 184 minecraft:red_nether_bricks
setblock 301 129 182 minecraft:polished_blackstone
fill 301 129 183 301 131 183 minecraft:red_nether_bricks
setblock 301 129 222 minecraft:polished_blackstone
fill 302 129 182 302 131 182 minecraft:red_nether_bricks
setblock 302 129 221 minecraft:polished_blackstone
fill 302 129 222 302 132 222 minecraft:red_nether_bricks
setblock 303 129 221 minecraft:red_nether_bricks
setblock 315 129 183 minecraft:polished_blackstone
setblock 316 129 182 minecraft:polished_blackstone
fill 316 129 183 316 132 183 minecraft:red_nether_bricks
setblock 316 129 222 minecraft:polished_blackstone
fill 317 129 182 317 132 182 minecraft:red_nether_bricks
fill 317 129 222 317 130 222 minecraft:red_nether_bricks
setblock 319 129 183 minecraft:red_nether_bricks
setblock 319 129 184 minecraft:polished_blackstone
fill 319 129 185 320 129 185 minecraft:red_nether_bricks
setblock 320 129 183 minecraft:polished_blackstone
fill 320 129 184 320 131 184 minecraft:red_nether_bricks
fill 320 129 186 320 129 187 minecraft:red_nether_bricks
setblock 320 129 188 minecraft:polished_blackstone
fill 320 129 189 321 129 191 minecraft:red_nether_bricks
setblock 320 129 203 minecraft:polished_blackstone
setblock 320 129 204 minecraft:red_nether_bricks
setblock 320 129 207 minecraft:red_nether_bricks
setblock 320 129 208 minecraft:polished_blackstone
fill 320 129 209 320 130 209 minecraft:red_nether_bricks
setblock 321 129 182 minecraft:polished_blackstone
fill 321 129 183 321 132 183 minecraft:red_nether_bricks
setblock 321 129 187 minecraft:polished_blackstone
fill 321 129 188 321 132 188 minecraft:red_nether_bricks
setblock 321 129 192 minecraft:polished_blackstone
fill 321 129 193 321 132 193 minecraft:red_nether_bricks
setblock 321 129 198 minecraft:red_nether_bricks
setblock 321 129 202 minecraft:polished_blackstone
fill 321 129 203 321 130 203 minecraft:red_nether_bricks
setblock 321 129 207 minecraft:polished_blackstone
fill 321 129 208 321 131 208 minecraft:red_nether_bricks
setblock 321 129 222 minecraft:polished_blackstone
fill 322 129 182 322 132 182 minecraft:red_nether_bricks
setblock 322 129 186 minecraft:polished_blackstone
fill 322 129 187 322 132 187 minecraft:red_nether_bricks
setblock 322 129 191 minecraft:polished_blackstone
fill 322 129 192 322 132 192 minecraft:red_nether_bricks
setblock 322 129 196 minecraft:polished_blackstone
fill 322 129 197 322 131 197 minecraft:red_nether_bricks
setblock 322 129 201 minecraft:polished_blackstone
fill 322 129 202 322 131 202 minecraft:red_nether_bricks
setblock 322 129 206 minecraft:polished_blackstone
fill 322 129 207 322 132 207 minecraft:red_nether_bricks
setblock 322 129 211 minecraft:polished_blackstone
fill 322 129 212 322 131 212 minecraft:red_nether_bricks
setblock 323 129 185 minecraft:polished_blackstone
fill 323 129 186 323 132 186 minecraft:red_nether_bricks
setblock 323 129 190 minecraft:polished_blackstone
fill 323 129 191 323 132 191 minecraft:red_nether_bricks
setblock 323 129 195 minecraft:polished_blackstone
fill 323 129 196 323 132 196 minecraft:red_nether_bricks
setblock 323 129 200 minecraft:polished_blackstone
fill 323 129 201 323 132 201 minecraft:red_nether_bricks
setblock 323 129 205 minecraft:polished_blackstone
fill 323 129 206 323 132 206 minecraft:red_nether_bricks
setblock 323 129 210 minecraft:polished_blackstone
fill 323 129 211 323 132 211 minecraft:red_nether_bricks
setblock 283 130 184 minecraft:polished_blackstone
fill 283 130 185 283 130 188 minecraft:red_nether_bricks
setblock 283 130 189 minecraft:polished_blackstone
fill 283 130 190 283 133 190 minecraft:red_nether_bricks
setblock 283 130 193 minecraft:red_nether_bricks
setblock 283 130 194 minecraft:polished_blackstone
fill 283 130 195 283 132 195 minecraft:red_nether_bricks
setblock 283 130 204 minecraft:polished_blackstone
fill 283 130 205 283 131 205 minecraft:red_nether_bricks
setblock 283 130 209 minecraft:polished_blackstone
fill 283 130 210 283 132 210 minecraft:red_nether_bricks
setblock 283 130 214 minecraft:polished_blackstone
setblock 284 130 183 minecraft:polished_blackstone
fill 284 130 184 284 132 184 minecraft:red_nether_bricks
setblock 284 130 188 minecraft:polished_blackstone
fill 284 130 189 284 133 189 minecraft:red_nether_bricks
setblock 284 130 193 minecraft:polished_blackstone
setblock 285 130 182 minecraft:polished_blackstone
fill 285 130 183 285 131 183 minecraft:red_nether_bricks
setblock 285 130 187 minecraft:polished_blackstone
fill 285 130 188 285 131 188 minecraft:red_nether_bricks
fill 286 130 182 286 132 182 minecraft:red_nether_bricks
setblock 289 130 183 minecraft:polished_blackstone
setblock 290 130 182 minecraft:polished_blackstone
fill 290 130 183 290 131 183 minecraft:red_nether_bricks
setblock 290 130 222 minecraft:polished_blackstone
fill 291 130 182 291 133 182 minecraft:red_nether_bricks
fill 291 130 222 291 133 222 minecraft:red_nether_bricks
setblock 293 130 184 minecraft:polished_blackstone
setblock 294 130 183 minecraft:polished_blackstone
fill 294 130 184 294 131 184 minecraft:red_nether_bricks
setblock 295 130 182 minecraft:polished_blackstone
fill 295 130 183 295 133 183 minecraft:red_nether_bricks
setblock 295 130 222 minecraft:polished_blackstone
fill 296 130 182 296 133 182 minecraft:red_nether_bricks
fill 296 130 184 296 131 184 minecraft:red_nether_bricks
setblock 296 130 220 minecraft:red_nether_bricks
setblock 296 130 221 minecraft:polished_blackstone
fill 296 130 222 296 133 222 minecraft:red_nether_bricks
setblock 297 130 220 minecraft:polished_blackstone
fill 297 130 221 297 133 221 minecraft:red_nether_bricks
setblock 298 130 184 minecraft:polished_blackstone
fill 298 130 220 298 131 220 minecraft:red_nether_bricks
setblock 299 130 183 minecraft:polished_blackstone
fill 299 130 184 299 131 184 minecraft:red_nether_bricks
setblock 300 130 182 minecraft:polished_blackstone
fill 300 130 183 300 131 183 minecraft:red_nether_bricks
setblock 300 130 222 minecraft:polished_blackstone
fill 301 130 182 301 132 182 minecraft:red_nether_bricks
setblock 301 130 221 minecraft:polished_blackstone
fill 301 130 222 301 133 222 minecraft:red_nether_bricks
setblock 302 130 221 minecraft:red_nether_bricks
setblock 315 130 182 minecraft:polished_blackstone
fill 315 130 183 315 131 183 minecraft:red_nether_bricks
fill 316 130 182 316 133 182 minecraft:red_nether_bricks
setblock 316 130 222 minecraft:red_nether_bricks
setblock 318 130 183 minecraft:red_nether_bricks
setblock 318 130 184 minecraft:polished_blackstone
setblock 319 130 183 minecraft:polished_blackstone
fill 319 130 184 319 131 184 minecraft:red_nether_bricks
setblock 320 130 182 minecraft:polished_blackstone
fill 320 130 183 320 132 183 minecraft:red_nether_bricks
setblock 320 130 186 minecraft:red_nether_bricks
setblock 320 130 187 minecraft:polished_blackstone
fill 320 130 188 320 130 191 minecraft:red_nether_bricks
setblock 320 130 192 minecraft:polished_blackstone
setblock 320 130 207 minecraft:polished_blackstone
setblock 320 130 208 minecraft:red_nether_bricks
setblock 320 130 222 minecraft:polished_blackstone
fill 321 130 182 321 133 182 minecraft:red_nether_bricks
setblock 321 130 186 minecraft:polished_blackstone
fill 321 130 187 321 133 187 minecraft:red_nether_bricks
fill 321 130 189 321 130 190 minecraft:red_nether_bricks
setblock 321 130 191 minecraft:polished_blackstone
fill 321 130 192 321 133 192 minecraft:red_nether_bricks
fill 321 130 194 321 130 195 minecraft:red_nether_bricks
setblock 321 130 202 minecraft:red_nether_bricks
setblock 321 130 206 minecraft:polished_blackstone
fill 321 130 207 321 131 207 minecraft:red_nether_bricks
setblock 321 130 210 minecraft:red_nether_bricks
setblock 321 130 211 minecraft:polished_blackstone
setblock 322 130 185 minecraft:polished_blackstone
fill 322 130 186 322 133 186 minecraft:red_nether_bricks
setblock 322 130 190 minecraft:polished_blackstone
fill 322 130 191 322 133 191 minecraft:red_nether_bricks
setblock 322 130 195 minecraft:polished_blackstone
fill 322 130 196 322 132 196 minecraft:red_nether_bricks
setblock 322 130 200 minecraft:polished_blackstone
fill 322 130 201 322 131 201 minecraft:red_nether_bricks
setblock 322 130 205 minecraft:polished_blackstone
fill 322 130 206 322 132 206 minecraft:red_nether_bricks
setblock 322 130 210 minecraft:polished_blackstone
fill 322 130 211 322 132 211 minecraft:red_nether_bricks
setblock 323 130 184 minecraft:polished_blackstone
fill 323 130 185 323 133 185 minecraft:red_nether_bricks
setblock 323 130 189 minecraft:polished_blackstone
fill 323 130 190 323 133 190 minecraft:red_nether_bricks
setblock 323 130 194 minecraft:polished_blackstone
fill 323 130 195 323 133 195 minecraft:red_nether_bricks
setblock 323 130 199 minecraft:polished_blackstone
fill 323 130 200 323 132 200 minecraft:red_nether_bricks
setblock 323 130 204 minecraft:polished_blackstone
fill 323 130 205 323 132 205 minecraft:red_nether_bricks
setblock 323 130 209 minecraft:polished_blackstone
fill 323 130 210 323 133 210 minecraft:red_nether_bricks
setblock 323 130 214 minecraft:polished_blackstone
setblock 283 131 183 minecraft:polished_blackstone
fill 283 131 184 283 131 187 minecraft:red_nether_bricks
setblock 283 131 188 minecraft:polished_blackstone
fill 283 131 189 283 134 189 minecraft:red_nether_bricks
setblock 283 131 193 minecraft:polished_blackstone
fill 283 131 194 283 134 194 minecraft:red_nether_bricks
setblock 283 131 208 minecraft:polished_blackstone
fill 283 131 209 283 132 209 minecraft:red_nether_bricks
setblock 283 131 212 minecraft:red_nether_bricks
setblock 283 131 213 minecraft:polished_blackstone
setblock 283 131 214 minecraft:red_nether_bricks
setblock 284 131 182 minecraft:polished_blackstone
fill 284 131 183 284 132 183 minecraft:red_nether_bricks
setblock 284 131 187 minecraft:polished_blackstone
fill 284 131 188 284 134 188 minecraft:red_nether_bricks
setblock 284 131 192 minecraft:polished_blackstone
fill 285 131 182 285 133 182 minecraft:red_nether_bricks
setblock 285 131 186 minecraft:polished_blackstone
setblock 285 131 187 minecraft:red_nether_bricks
setblock 288 131 183 minecraft:polished_blackstone
setblock 289 131 182 minecraft:polished_blackstone
setblock 289 131 183 minecraft:red_nether_bricks
fill 290 131 182 290 134 182 minecraft:red_nether_bricks
fill 290 131 222 290 134 222 minecraft:red_nether_bricks
setblock 293 131 183 minecraft:polished_blackstone
setblock 293 131 184 minecraft:red_nether_bricks
setblock 294 131 182 minecraft:polished_blackstone
fill 294 131 183 294 133 183 minecraft:red_nether_bricks
setblock 294 131 222 minecraft:polished_blackstone
fill 295 131 182 295 134 182 minecraft:red_nether_bricks
setblock 295 131 221 minecraft:polished_blackstone
fill 295 131 222 295 134 222 minecraft:red_nether_bricks
fill 296 131 221 296 134 221 minecraft:red_nether_bricks
setblock 297 131 184 minecraft:polished_blackstone
setblock 297 131 220 minecraft:red_nether_bricks
setblock 298 131 183 minecraft:polished_blackstone
setblock 298 131 184 minecraft:red_nether_bricks
setblock 299 131 182 minecraft:polished_blackstone
fill 299 131 183 299 132 183 minecraft:red_nether_bricks
setblock 299 131 222 minecraft:polished_blackstone
fill 300 131 182 300 132 182 minecraft:red_nether_bricks
setblock 300 131 221 minecraft:polished_blackstone
fill 300 131 222 300 134 222 minecraft:red_nether_bricks
setblock 301 131 221 minecraft:red_nether_bricks
setblock 314 131 182 minecraft:polished_blackstone
fill 315 131 182 315 133 182 minecraft:red_nether_bricks
setblock 317 131 183 minecraft:red_nether_bricks
setblock 317 131 184 minecraft:polished_blackstone
setblock 318 131 183 minecraft:polished_blackstone
setblock 318 131 184 minecraft:red_nether_bricks
setblock 319 131 182 minecraft:polished_blackstone
fill 319 131 183 319 132 183 minecraft:red_nether_bricks
fill 320 131 182 320 133 182 minecraft:red_nether_bricks
fill 320 131 187 320 131 190 minecraft:red_nether_bricks
setblock 320 131 191 minecraft:polished_blackstone
setblock 320 131 192 minecraft:red_nether_bricks
setblock 321 131 185 minecraft:polished_blackstone
fill 321 131 186 321 132 186 minecraft:red_nether_bricks
setblock 321 131 189 minecraft:red_nether_bricks
setblock 321 131 190 minecraft:polished_blackstone
fill 321 131 191 321 134 191 minecraft:red_nether_bricks
setblock 321 131 194 minecraft:red_nether_bricks
setblock 321 131 195 minecraft:polished_blackstone
setblock 321 131 205 minecraft:polished_blackstone
setblock 321 131 206 minecraft:red_nether_bricks
setblock 321 131 210 minecraft:polished_blackstone
setblock 321 131 211 minecraft:red_nether_bricks
setblock 322 131 184 minecraft:polished_blackstone
fill 322 131 185 322 133 185 minecraft:red_nether_bricks
setblock 322 131 189 minecraft:polished_blackstone
fill 322 131 190 322 134 190 minecraft:red_nether_bricks
setblock 322 131 194 minecraft:polished_blackstone
fill 322 131 195 322 134 195 minecraft:red_nether_bricks
setblock 322 131 199 minecraft:polished_blackstone
setblock 322 131 204 minecraft:polished_blackstone
setblock 322 131 205 minecraft:red_nether_bricks
setblock 322 131 209 minecraft:polished_blackstone
fill 322 131 210 322 132 210 minecraft:red_nether_bricks
setblock 323 131 183 minecraft:polished_blackstone
fill 323 131 184 323 134 184 minecraft:red_nether_bricks
setblock 323 131 188 minecraft:polished_blackstone
fill 323 131 189 323 134 189 minecraft:red_nether_bricks
setblock 323 131 193 minecraft:polished_blackstone
fill 323 131 194 323 134 194 minecraft:red_nether_bricks
setblock 323 131 198 minecraft:polished_blackstone
fill 323 131 199 323 132 199 minecraft:red_nether_bricks
setblock 323 131 203 minecraft:polished_blackstone
fill 323 131 204 323 132 204 minecraft:red_nether_bricks
setblock 323 131 208 minecraft:polished_blackstone
fill 323 131 209 323 133 209 minecraft:red_nether_bricks
setblock 323 131 213 minecraft:polished_blackstone
setblock 323 131 214 minecraft:red_nether_bricks
setblock 283 132 182 minecraft:polished_blackstone
fill 283 132 183 283 132 186 minecraft:red_nether_bricks
setblock 283 132 187 minecraft:polished_blackstone
fill 283 132 188 283 135 188 minecraft:red_nether_bricks
setblock 283 132 192 minecraft:polished_blackstone
fill 283 132 193 283 135 193 minecraft:red_nether_bricks
setblock 283 132 208 minecraft:red_nether_bricks
setblock 283 132 212 minecraft:polished_blackstone
setblock 283 132 213 minecraft:red_nether_bricks
fill 284 132 182 284 133 182 minecraft:red_nether_bricks
setblock 284 132 186 minecraft:polished_blackstone
fill 284 132 187 284 133 187 minecraft:red_nether_bricks
setblock 284 132 191 minecraft:polished_blackstone
setblock 284 132 192 minecraft:red_nether_bricks
setblock 285 132 184 minecraft:light[level=14]
setblock 285 132 192 minecraft:light[level=14]
setblock 285 132 200 minecraft:light[level=14]
setblock 285 132 208 minecraft:light[level=14]
setblock 285 132 216 minecraft:light[level=14]
setblock 288 132 182 minecraft:polished_blackstone
fill 289 132 182 289 133 182 minecraft:red_nether_bricks
setblock 292 132 183 minecraft:polished_blackstone
setblock 293 132 182 minecraft:polished_blackstone
fill 293 132 183 293 133 183 minecraft:red_nether_bricks
setblock 293 132 184 minecraft:light[level=14]
setblock 293 132 192 minecraft:light[level=14]
setblock 293 132 200 minecraft:light[level=14]
setblock 293 132 208 minecraft:light[level=14]
setblock 293 132 216 minecraft:light[level=14]
setblock 293 132 222 minecraft:polished_blackstone
fill 294 132 182 294 135 182 minecraft:red_nether_bricks
setblock 294 132 221 minecraft:polished_blackstone
fill 294 132 222 294 135 222 minecraft:red_nether_bricks
fill 295 132 221 295 135 221 minecraft:red_nether_bricks
setblock 296 132 184 minecraft:polished_blackstone
setblock 297 132 183 minecraft:polished_blackstone
setblock 298 132 182 minecraft:polished_blackstone
setblock 298 132 183 minecraft:red_nether_bricks
setblock 298 132 222 minecraft:polished_blackstone
fill 299 132 182 299 133 182 minecraft:red_nether_bricks
setblock 299 132 221 minecraft:polished_blackstone
fill 299 132 222 299 135 222 minecraft:red_nether_bricks
setblock 300 132 221 minecraft:red_nether_bricks
setblock 301 132 184 minecraft:light[level=14]
setblock 301 132 192 minecraft:light[level=14]
setblock 301 132 200 minecraft:light[level=14]
setblock 301 132 208 minecraft:light[level=14]
setblock 301 132 216 minecraft:light[level=14]
setblock 309 132 184 minecraft:light[level=14]
setblock 309 132 192 minecraft:light[level=14]
setblock 309 132 200 minecraft:light[level=14]
setblock 309 132 208 minecraft:light[level=14]
setblock 309 132 216 minecraft:light[level=14]
setblock 311 132 183 minecraft:polished_blackstone
setblock 311 132 185 minecraft:polished_blackstone
setblock 313 132 183 minecraft:polished_blackstone
setblock 313 132 185 minecraft:polished_blackstone
setblock 314 132 182 minecraft:red_nether_bricks
setblock 317 132 183 minecraft:polished_blackstone
setblock 317 132 184 minecraft:light[level=14]
setblock 317 132 192 minecraft:light[level=14]
setblock 317 132 200 minecraft:light[level=14]
setblock 317 132 208 minecraft:light[level=14]
setblock 317 132 216 minecraft:light[level=14]
setblock 318 132 182 minecraft:polished_blackstone
setblock 318 132 183 minecraft:red_nether_bricks
fill 319 132 182 319 134 182 minecraft:red_nether_bricks
fill 320 132 188 320 132 189 minecraft:red_nether_bricks
setblock 320 132 190 minecraft:polished_blackstone
setblock 320 132 191 minecraft:red_nether_bricks
setblock 321 132 185 minecraft:red_nether_bricks
setblock 321 132 189 minecraft:polished_blackstone
fill 321 132 190 321 135 190 minecraft:red_nether_bricks
setblock 321 132 194 minecraft:polished_blackstone
setblock 322 132 184 minecraft:red_nether_bricks
setblock 322 132 188 minecraft:polished_blackstone
fill 322 132 189 322 135 189 minecraft:red_nether_bricks
setblock 322 132 193 minecraft:polished_blackstone
fill 322 132 194 322 135 194 minecraft:red_nether_bricks
setblock 322 132 208 minecraft:polished_blackstone
setblock 322 132 209 minecraft:red_nether_bricks
setblock 323 132 182 minecraft:polished_blackstone
fill 323 132 183 323 133 183 minecraft:red_nether_bricks
setblock 323 132 187 minecraft:polished_blackstone
fill 323 132 188 323 135 188 minecraft:red_nether_bricks
setblock 323 132 192 minecraft:polished_blackstone
fill 323 132 193 323 135 193 minecraft:red_nether_bricks
setblock 323 132 197 minecraft:polished_blackstone
setblock 323 132 198 minecraft:red_nether_bricks
setblock 323 132 202 minecraft:polished_blackstone
setblock 323 132 203 minecraft:red_nether_bricks
setblock 323 132 207 minecraft:polished_blackstone
fill 323 132 208 323 133 208 minecraft:red_nether_bricks
setblock 323 132 212 minecraft:polished_blackstone
setblock 323 132 213 minecraft:red_nether_bricks
fill 283 133 182 283 133 185 minecraft:red_nether_bricks
setblock 283 133 186 minecraft:polished_blackstone
fill 283 133 187 283 136 187 minecraft:red_nether_bricks
setblock 283 133 191 minecraft:polished_blackstone
fill 283 133 192 283 136 192 minecraft:red_nether_bricks
setblock 284 133 185 minecraft:polished_blackstone
setblock 284 133 186 minecraft:red_nether_bricks
setblock 284 133 190 minecraft:polished_blackstone
setblock 284 133 191 minecraft:red_nether_bricks
setblock 288 133 182 minecraft:red_nether_bricks
setblock 292 133 182 minecraft:polished_blackstone
setblock 292 133 183 minecraft:red_nether_bricks
setblock 292 133 222 minecraft:polished_blackstone
fill 293 133 182 293 136 182 minecraft:red_nether_bricks
setblock 293 133 221 minecraft:polished_blackstone
fill 293 133 222 293 136 222 minecraft:red_nether_bricks
fill 294 133 221 294 136 221 minecraft:red_nether_bricks
setblock 296 133 183 minecraft:polished_blackstone
setblock 297 133 182 minecraft:polished_blackstone
setblock 297 133 183 minecraft:red_nether_bricks
setblock 297 133 222 minecraft:polished_blackstone
fill 298 133 182 298 134 182 minecraft:red_nether_bricks
setblock 298 133 221 minecraft:polished_blackstone
fill 298 133 222 298 136 222 minecraft:red_nether_bricks
setblock 299 133 221 minecraft:red_nether_bricks
setblock 317 133 182 minecraft:polished_blackstone
fill 318 133 182 318 134 182 minecraft:red_nether_bricks
setblock 321 133 188 minecraft:polished_blackstone
fill 321 133 189 321 134 189 minecraft:red_nether_bricks
setblock 321 133 193 minecraft:polished_blackstone
setblock 321 133 194 minecraft:red_nether_bricks
setblock 322 133 187 minecraft:polished_blackstone
fill 322 133 188 322 136 188 minecraft:red_nether_bricks
setblock 322 133 192 minecraft:polished_blackstone
fill 322 133 193 322 136 193 minecraft:red_nether_bricks
setblock 323 133 186 minecraft:polished_blackstone
fill 323 133 187 323 136 187 minecraft:red_nether_bricks
setblock 323 133 191 minecraft:polished_blackstone
fill 323 133 192 323 136 192 minecraft:red_nether_bricks
setblock 323 133 196 minecraft:polished_blackstone
setblock 323 133 197 minecraft:red_nether_bricks
setblock 323 133 207 minecraft:red_nether_bricks
setblock 323 133 211 minecraft:polished_blackstone
setblock 323 133 212 minecraft:red_nether_bricks
fill 283 134 183 283 134 184 minecraft:red_nether_bricks
setblock 283 134 185 minecraft:polished_blackstone
fill 283 134 186 283 135 186 minecraft:red_nether_bricks
setblock 283 134 190 minecraft:polished_blackstone
fill 283 134 191 283 136 191 minecraft:red_nether_bricks
setblock 284 134 189 minecraft:polished_blackstone
setblock 291 134 182 minecraft:polished_blackstone
setblock 291 134 222 minecraft:polished_blackstone
fill 292 134 182 292 136 182 minecraft:red_nether_bricks
fill 292 134 222 292 136 222 minecraft:red_nether_bricks
fill 293 134 221 293 136 221 minecraft:red_nether_bricks
setblock 296 134 182 minecraft:polished_blackstone
setblock 296 134 222 minecraft:polished_blackstone
setblock 297 134 182 minecraft:red_nether_bricks
setblock 297 134 221 minecraft:polished_blackstone
fill 297 134 222 297 136 222 minecraft:red_nether_bricks
setblock 298 134 221 minecraft:red_nether_bricks
fill 299 134 217 299 134 219 minecraft:polished_blackstone
fill 300 134 217 301 134 217 minecraft:polished_blackstone
fill 300 134 219 301 134 219 minecraft:polished_blackstone
setblock 301 134 218 minecraft:polished_blackstone
setblock 316 134 182 minecraft:polished_blackstone
setblock 317 134 182 minecraft:red_nether_bricks
setblock 321 134 188 minecraft:red_nether_bricks
setblock 321 134 192 minecraft:polished_blackstone
setblock 321 134 193 minecraft:red_nether_bricks
setblock 322 134 186 minecraft:polished_blackstone
fill 322 134 187 322 135 187 minecraft:red_nether_bricks
setblock 322 134 191 minecraft:polished_blackstone
fill 322 134 192 322 136 192 minecraft:red_nether_bricks
setblock 323 134 185 minecraft:polished_blackstone
fill 323 134 186 323 136 186 minecraft:red_nether_bricks
setblock 323 134 190 minecraft:polished_blackstone
fill 323 134 191 323 136 191 minecraft:red_nether_bricks
setblock 323 134 195 minecraft:polished_blackstone
fill 323 134 196 323 136 196 minecraft:red_nether_bricks
setblock 283 135 185 minecraft:red_nether_bricks
setblock 283 135 189 minecraft:polished_blackstone
fill 283 135 190 283 136 190 minecraft:red_nether_bricks
setblock 290 135 222 minecraft:polished_blackstone
fill 291 135 182 291 136 182 minecraft:red_nether_bricks
fill 291 135 222 291 136 222 minecraft:red_nether_bricks
setblock 295 135 182 minecraft:polished_blackstone
setblock 295 135 222 minecraft:polished_blackstone
setblock 296 135 182 minecraft:red_nether_bricks
setblock 296 135 221 minecraft:polished_blackstone
fill 296 135 222 296 136 222 minecraft:red_nether_bricks
fill 297 135 221 297 136 221 minecraft:red_nether_bricks
setblock 321 135 191 minecraft:polished_blackstone
setblock 321 135 192 minecraft:red_nether_bricks
setblock 322 135 190 minecraft:polished_blackstone
fill 322 135 191 322 136 191 minecraft:red_nether_bricks
setblock 323 135 185 minecraft:red_nether_bricks
setblock 323 135 189 minecraft:polished_blackstone
fill 323 135 190 323 136 190 minecraft:red_nether_bricks
setblock 323 135 194 minecraft:polished_blackstone
fill 323 135 195 323 136 195 minecraft:red_nether_bricks
setblock 283 136 188 minecraft:polished_blackstone
setblock 283 136 189 minecraft:red_nether_bricks
setblock 283 136 193 minecraft:polished_blackstone
setblock 289 136 222 minecraft:polished_blackstone
setblock 290 136 222 minecraft:red_nether_bricks
setblock 292 136 221 minecraft:red_nether_bricks
setblock 294 136 182 minecraft:polished_blackstone
setblock 294 136 222 minecraft:polished_blackstone
setblock 295 136 182 minecraft:red_nether_bricks
setblock 295 136 221 minecraft:polished_blackstone
setblock 295 136 222 minecraft:red_nether_bricks
setblock 296 136 221 minecraft:red_nether_bricks
setblock 322 136 189 minecraft:polished_blackstone
setblock 322 136 190 minecraft:red_nether_bricks
setblock 322 136 194 minecraft:polished_blackstone
setblock 323 136 188 minecraft:polished_blackstone
setblock 323 136 189 minecraft:red_nether_bricks
setblock 323 136 193 minecraft:polished_blackstone
setblock 323 136 194 minecraft:red_nether_bricks
fill 298 137 205 305 137 206 minecraft:magma_block
fill 299 137 203 304 137 204 minecraft:magma_block
fill 299 137 207 299 137 208 minecraft:magma_block
fill 300 137 207 304 137 207 minecraft:magma_block
fill 301 137 202 302 137 202 minecraft:magma_block
fill 301 137 208 304 137 208 minecraft:magma_block
setblock 302 137 209 minecraft:magma_block
fill 297 138 204 297 138 207 minecraft:magma_block
fill 298 138 203 298 138 204 minecraft:magma_block
fill 298 138 205 305 140 206 minecraft:red_nether_bricks
fill 298 138 207 298 138 208 minecraft:magma_block
fill 299 138 202 300 138 202 minecraft:magma_block
fill 299 138 203 304 148 204 minecraft:red_nether_bricks
fill 299 138 207 299 140 208 minecraft:red_nether_bricks
fill 300 138 201 303 138 201 minecraft:magma_block
fill 300 138 207 304 140 207 minecraft:red_nether_bricks
fill 301 138 202 302 148 202 minecraft:red_nether_bricks
fill 301 138 208 304 140 208 minecraft:red_nether_bricks
fill 301 138 210 303 138 210 minecraft:magma_block
fill 302 138 209 302 140 209 minecraft:red_nether_bricks
fill 303 138 202 304 138 202 minecraft:magma_block
fill 303 138 209 304 138 209 minecraft:magma_block
fill 305 138 203 305 138 204 minecraft:magma_block
fill 305 138 207 305 138 208 minecraft:magma_block
fill 306 138 204 306 138 207 minecraft:magma_block
fill 296 139 204 296 140 207 minecraft:magma_block
fill 297 139 202 297 139 203 minecraft:magma_block
fill 297 139 204 297 143 207 minecraft:red_nether_bricks
fill 297 139 208 297 139 209 minecraft:magma_block
fill 298 139 201 298 139 202 minecraft:magma_block
fill 298 139 203 298 147 204 minecraft:red_nether_bricks
fill 298 139 207 298 140 208 minecraft:red_nether_bricks
fill 298 139 209 298 139 210 minecraft:magma_block
setblock 299 139 201 minecraft:magma_block
fill 299 139 202 300 147 202 minecraft:red_nether_bricks
setblock 299 139 210 minecraft:magma_block
fill 300 139 200 303 140 200 minecraft:magma_block
fill 300 139 201 303 147 201 minecraft:red_nether_bricks
fill 300 139 211 303 140 211 minecraft:magma_block
fill 301 139 210 303 140 210 minecraft:red_nether_bricks
fill 303 139 202 304 147 202 minecraft:red_nether_bricks
fill 303 139 209 304 140 209 minecraft:red_nether_bricks
fill 304 139 201 305 139 201 minecraft:magma_block
fill 304 139 210 305 139 210 minecraft:magma_block
fill 305 139 202 306 139 202 minecraft:magma_block
fill 305 139 203 305 147 204 minecraft:red_nether_bricks
fill 305 139 207 305 147 208 minecraft:red_nether_bricks
fill 305 139 209 306 139 209 minecraft:magma_block
setblock 306 139 203 minecraft:magma_block
fill 306 139 204 306 147 207 minecraft:red_nether_bricks
setblock 306 139 208 minecraft:magma_block
fill 307 139 204 307 140 207 minecraft:magma_block
setblock 285 140 184 minecraft:light[level=14]
setblock 285 140 192 minecraft:light[level=14]
setblock 285 140 200 minecraft:light[level=14]
setblock 285 140 208 minecraft:light[level=14]
setblock 285 140 216 minecraft:light[level=14]
setblock 293 140 184 minecraft:light[level=14]
setblock 293 140 192 minecraft:light[level=14]
setblock 293 140 200 minecraft:light[level=14]
setblock 293 140 208 minecraft:light[level=14]
setblock 293 140 216 minecraft:light[level=14]
fill 296 140 203 296 142 203 minecraft:magma_block
fill 296 140 208 296 142 208 minecraft:magma_block
setblock 297 140 202 minecraft:magma_block
fill 297 140 203 297 146 203 minecraft:red_nether_bricks
fill 297 140 208 297 143 208 minecraft:red_nether_bricks
setblock 297 140 209 minecraft:magma_block
setblock 298 140 201 minecraft:magma_block
fill 298 140 202 298 146 202 minecraft:red_nether_bricks
setblock 298 140 209 minecraft:red_nether_bricks
setblock 298 140 210 minecraft:magma_block
fill 299 140 200 299 142 200 minecraft:magma_block
fill 299 140 201 299 146 201 minecraft:red_nether_bricks
setblock 299 140 210 minecraft:red_nether_bricks
setblock 299 140 211 minecraft:magma_block
setblock 301 140 184 minecraft:light[level=14]
setblock 301 140 192 minecraft:light[level=14]
setblock 301 140 216 minecraft:light[level=14]
fill 304 140 200 304 142 200 minecraft:magma_block
fill 304 140 201 304 146 201 minecraft:red_nether_bricks
fill 304 140 210 304 143 210 minecraft:red_nether_bricks
fill 304 140 211 304 142 211 minecraft:magma_block
setblock 305 140 201 minecraft:magma_block
fill 305 140 202 305 146 202 minecraft:red_nether_bricks
fill 305 140 209 305 146 209 minecraft:red_nether_bricks
setblock 305 140 210 minecraft:magma_block
setblock 306 140 202 minecraft:magma_block
fill 306 140 203 306 146 203 minecraft:red_nether_bricks
fill 306 140 208 306 146 208 minecraft:red_nether_bricks
setblock 306 140 209 minecraft:magma_block
fill 307 140 203 307 142 203 minecraft:magma_block
fill 307 140 208 307 142 208 minecraft:magma_block
setblock 309 140 184 minecraft:light[level=14]
setblock 309 140 192 minecraft:light[level=14]
setblock 309 140 200 minecraft:light[level=14]
setblock 309 140 208 minecraft:light[level=14]
setblock 309 140 216 minecraft:light[level=14]
setblock 317 140 184 minecraft:light[level=14]
setblock 317 140 192 minecraft:light[level=14]
setblock 317 140 200 minecraft:light[level=14]
setblock 317 140 208 minecraft:light[level=14]
setblock 317 140 216 minecraft:light[level=14]
fill 295 141 204 295 145 207 minecraft:magma_block
fill 296 141 202 296 145 202 minecraft:magma_block
fill 296 141 204 296 145 207 minecraft:red_nether_bricks
fill 296 141 209 296 143 209 minecraft:magma_block
fill 297 141 201 297 145 201 minecraft:magma_block
fill 297 141 202 297 145 202 minecraft:red_nether_bricks
fill 297 141 210 297 143 210 minecraft:magma_block
fill 298 141 200 298 145 200 minecraft:magma_block
fill 298 141 201 298 145 201 minecraft:red_nether_bricks
fill 298 141 205 299 143 206 minecraft:red_nether_bricks
fill 300 141 199 303 145 199 minecraft:magma_block
fill 300 141 200 303 145 200 minecraft:red_nether_bricks
fill 300 141 205 305 143 205 minecraft:red_nether_bricks
fill 301 141 206 305 143 206 minecraft:red_nether_bricks
fill 301 141 212 303 143 212 minecraft:magma_block
fill 303 141 207 304 143 208 minecraft:red_nether_bricks
fill 303 141 210 303 143 211 minecraft:red_nether_bricks
fill 304 141 209 304 143 209 minecraft:red_nether_bricks
fill 305 141 200 305 145 200 minecraft:magma_block
fill 305 141 201 305 145 201 minecraft:red_nether_bricks
fill 305 141 210 305 145 210 minecraft:red_nether_bricks
fill 305 141 211 305 145 211 minecraft:magma_block
fill 306 141 201 306 145 201 minecraft:magma_block
fill 306 141 202 306 145 202 minecraft:red_nether_bricks
fill 306 141 209 306 145 209 minecraft:red_nether_bricks
fill 306 141 210 306 145 210 minecraft:magma_block
fill 307 141 202 307 145 202 minecraft:magma_block
fill 307 141 204 307 145 207 minecraft:red_nether_bricks
fill 307 141 209 307 145 209 minecraft:magma_block
fill 308 141 204 308 145 207 minecraft:magma_block
setblock 295 143 203 minecraft:magma_block
setblock 295 143 208 minecraft:magma_block
setblock 296 143 203 minecraft:red_nether_bricks
setblock 296 143 208 minecraft:red_nether_bricks
setblock 299 143 199 minecraft:magma_block
setblock 299 143 200 minecraft:red_nether_bricks
setblock 299 143 212 minecraft:magma_block
setblock 304 143 199 minecraft:magma_block
setblock 304 143 200 minecraft:red_nether_bricks
setblock 304 143 211 minecraft:red_nether_bricks
setblock 304 143 212 minecraft:magma_block
setblock 307 143 203 minecraft:red_nether_bricks
setblock 307 143 208 minecraft:red_nether_bricks
setblock 308 143 203 minecraft:magma_block
setblock 308 143 208 minecraft:magma_block
fill 283 144 182 294 144 222 minecraft:blackstone
fill 295 144 182 295 144 203 minecraft:blackstone
fill 295 144 208 295 144 222 minecraft:blackstone
fill 296 144 182 296 144 201 minecraft:blackstone
fill 296 144 203 296 146 203 minecraft:magma_block
fill 296 144 208 296 144 210 minecraft:shroomlight
fill 296 144 211 296 144 222 minecraft:blackstone
fill 297 144 182 297 144 200 minecraft:blackstone
fill 297 144 204 297 147 205 minecraft:red_nether_bricks
fill 297 144 206 297 144 208 minecraft:shroomlight
fill 297 144 210 297 144 212 minecraft:shroomlight
fill 297 144 213 298 144 222 minecraft:blackstone
fill 298 144 182 299 144 199 minecraft:blackstone
fill 298 144 205 298 148 205 minecraft:red_nether_bricks
fill 298 144 206 299 144 206 minecraft:shroomlight
fill 298 144 212 299 144 212 minecraft:shroomlight
fill 299 144 200 299 146 200 minecraft:magma_block
fill 299 144 205 301 144 205 minecraft:shroomlight
fill 299 144 213 301 144 213 minecraft:shroomlight
fill 299 144 214 323 144 222 minecraft:blackstone
fill 300 144 182 323 144 198 minecraft:blackstone
fill 301 144 206 303 144 206 minecraft:shroomlight
fill 301 144 212 303 144 212 minecraft:shroomlight
fill 302 144 205 305 148 205 minecraft:red_nether_bricks
fill 302 144 213 323 144 213 minecraft:blackstone
fill 303 144 207 303 144 208 minecraft:shroomlight
fill 303 144 210 303 144 211 minecraft:shroomlight
fill 304 144 199 323 144 199 minecraft:blackstone
fill 304 144 200 304 146 200 minecraft:magma_block
fill 304 144 206 304 148 207 minecraft:red_nether_bricks
fill 304 144 208 304 144 210 minecraft:shroomlight
fill 304 144 211 304 146 211 minecraft:magma_block
fill 304 144 212 323 144 212 minecraft:blackstone
fill 305 144 206 305 148 206 minecraft:red_nether_bricks
fill 306 144 200 323 144 200 minecraft:blackstone
fill 306 144 211 323 144 211 minecraft:blackstone
fill 307 144 201 323 144 201 minecraft:blackstone
fill 307 144 203 307 146 203 minecraft:magma_block
fill 307 144 208 307 146 208 minecraft:magma_block
fill 307 144 210 323 144 210 minecraft:blackstone
fill 308 144 202 323 144 203 minecraft:blackstone
fill 308 144 208 323 144 209 minecraft:blackstone
fill 309 144 204 323 144 207 minecraft:blackstone
fill 296 145 208 296 145 209 minecraft:magma_block
fill 297 145 206 297 146 208 minecraft:red_nether_bricks
setblock 297 145 210 minecraft:magma_block
fill 298 145 206 299 148 206 minecraft:red_nether_bricks
fill 299 145 205 301 148 205 minecraft:red_nether_bricks
fill 301 145 206 303 148 206 minecraft:red_nether_bricks
fill 301 145 212 303 145 212 minecraft:magma_block
fill 303 145 207 303 148 208 minecraft:red_nether_bricks
fill 303 145 210 303 145 211 minecraft:red_nether_bricks
fill 304 145 208 304 146 210 minecraft:red_nether_bricks
fill 296 146 204 296 146 208 minecraft:magma_block
fill 297 146 202 297 147 202 minecraft:magma_block
fill 298 146 201 298 147 201 minecraft:magma_block
fill 300 146 200 303 147 200 minecraft:magma_block
fill 303 146 210 303 147 210 minecraft:red_nether_bricks
fill 303 146 211 303 147 211 minecraft:magma_block
fill 305 146 201 305 147 201 minecraft:magma_block
fill 305 146 210 305 147 210 minecraft:magma_block
fill 306 146 202 306 147 202 minecraft:magma_block
fill 306 146 209 306 147 209 minecraft:magma_block
fill 307 146 204 307 147 207 minecraft:magma_block
fill 296 147 204 296 147 207 minecraft:magma_block
setblock 297 147 203 minecraft:magma_block
fill 297 147 206 297 147 207 minecraft:red_nether_bricks
fill 297 147 208 297 147 209 minecraft:magma_block
setblock 298 147 202 minecraft:magma_block
fill 298 147 207 299 147 208 minecraft:red_nether_bricks
fill 298 147 209 298 147 210 minecraft:magma_block
setblock 299 147 201 minecraft:magma_block
setblock 299 147 210 minecraft:magma_block
fill 300 147 206 300 148 207 minecraft:red_nether_bricks
fill 300 147 211 302 147 211 minecraft:magma_block
fill 301 147 207 302 148 207 minecraft:red_nether_bricks
fill 301 147 210 302 147 210 minecraft:red_nether_bricks
fill 302 147 208 302 148 209 minecraft:red_nether_bricks
fill 303 147 209 304 147 209 minecraft:red_nether_bricks
setblock 304 147 201 minecraft:magma_block
fill 304 147 208 304 148 208 minecraft:red_nether_bricks
setblock 304 147 210 minecraft:magma_block
setblock 305 147 202 minecraft:magma_block
setblock 305 147 209 minecraft:magma_block
setblock 306 147 203 minecraft:magma_block
setblock 306 147 208 minecraft:magma_block
fill 283 148 182 283 148 185 minecraft:red_nether_bricks
fill 283 148 197 283 148 200 minecraft:red_nether_bricks
setblock 283 148 201 minecraft:polished_blackstone
fill 283 148 202 283 149 204 minecraft:red_nether_bricks
fill 283 148 213 283 148 215 minecraft:red_nether_bricks
setblock 283 148 216 minecraft:polished_blackstone
fill 283 148 217 283 148 220 minecraft:red_nether_bricks
setblock 283 148 221 minecraft:polished_blackstone
fill 283 148 222 286 148 222 minecraft:red_nether_bricks
fill 284 148 182 285 148 183 minecraft:red_nether_bricks
setblock 284 148 215 minecraft:polished_blackstone
fill 284 148 216 284 148 219 minecraft:red_nether_bricks
setblock 284 148 220 minecraft:polished_blackstone
fill 284 148 221 287 148 221 minecraft:red_nether_bricks
setblock 285 148 184 minecraft:light[level=14]
setblock 285 148 192 minecraft:light[level=14]
setblock 285 148 200 minecraft:light[level=14]
setblock 285 148 208 minecraft:light[level=14]
setblock 285 148 216 minecraft:light[level=14]
fill 285 148 217 285 148 218 minecraft:red_nether_bricks
setblock 285 148 219 minecraft:polished_blackstone
fill 285 148 220 288 148 220 minecraft:red_nether_bricks
setblock 286 148 182 minecraft:red_nether_bricks
setblock 286 148 183 minecraft:polished_blackstone
fill 286 148 219 289 148 219 minecraft:red_nether_bricks
setblock 287 148 182 minecraft:polished_blackstone
fill 287 148 183 289 149 183 minecraft:red_nether_bricks
setblock 287 148 222 minecraft:polished_blackstone
fill 288 148 182 291 148 182 minecraft:red_nether_bricks
setblock 288 148 221 minecraft:polished_blackstone
fill 288 148 222 291 148 222 minecraft:red_nether_bricks
setblock 289 148 220 minecraft:polished_blackstone
fill 289 148 221 292 148 221 minecraft:red_nether_bricks
setblock 290 148 219 minecraft:polished_blackstone
fill 290 148 220 292 148 220 minecraft:red_nether_bricks
setblock 292 148 182 minecraft:polished_blackstone
setblock 292 148 222 minecraft:polished_blackstone
setblock 293 148 182 minecraft:red_nether_bricks
setblock 293 148 184 minecraft:light[level=14]
setblock 293 148 192 minecraft:light[level=14]
setblock 293 148 200 minecraft:light[level=14]
setblock 293 148 208 minecraft:light[level=14]
setblock 293 148 216 minecraft:light[level=14]
setblock 293 148 221 minecraft:polished_blackstone
fill 293 148 222 296 148 222 minecraft:red_nether_bricks
setblock 294 148 221 minecraft:red_nether_bricks
fill 297 148 204 297 148 207 minecraft:magma_block
setblock 297 148 222 minecraft:polished_blackstone
fill 298 148 203 298 148 204 minecraft:magma_block
fill 298 148 207 298 148 208 minecraft:magma_block
fill 299 148 202 300 148 202 minecraft:magma_block
fill 299 148 207 299 148 208 minecraft:red_nether_bricks
fill 300 148 201 303 148 201 minecraft:magma_block
setblock 301 148 184 minecraft:light[level=14]
setblock 301 148 192 minecraft:light[level=14]
setblock 301 148 200 minecraft:light[level=14]
fill 301 148 210 303 148 210 minecraft:magma_block
setblock 301 148 216 minecraft:light[level=14]
setblock 301 148 222 minecraft:red_nether_bricks
setblock 302 148 222 minecraft:polished_blackstone
fill 303 148 202 304 148 202 minecraft:magma_block
fill 303 148 209 304 148 209 minecraft:magma_block
fill 303 148 222 306 148 222 minecraft:red_nether_bricks
fill 304 148 182 306 148 182 minecraft:red_nether_bricks
fill 305 148 203 305 148 204 minecraft:magma_block
fill 305 148 207 305 148 208 minecraft:magma_block
fill 305 148 221 307 148 221 minecraft:red_nether_bricks
setblock 306 148 183 minecraft:polished_blackstone
fill 306 148 204 306 148 207 minecraft:magma_block
setblock 307 148 182 minecraft:polished_blackstone
fill 307 148 183 310 148 183 minecraft:red_nether_bricks
setblock 307 148 222 minecraft:polished_blackstone
fill 308 148 182 311 148 182 minecraft:red_nether_bricks
setblock 308 148 221 minecraft:polished_blackstone
fill 308 148 222 311 148 222 minecraft:red_nether_bricks
setblock 309 148 184 minecraft:light[level=14]
setblock 309 148 192 minecraft:light[level=14]
setblock 309 148 200 minecraft:light[level=14]
setblock 309 148 208 minecraft:light[level=14]
setblock 309 148 216 minecraft:light[level=14]
fill 309 148 221 312 148 221 minecraft:red_nether_bricks
setblock 311 148 183 minecraft:polished_blackstone
fill 311 148 184 311 153 184 minecraft:gilded_blackstone
setblock 312 148 182 minecraft:polished_blackstone
fill 312 148 183 314 148 183 minecraft:red_nether_bricks
setblock 312 148 222 minecraft:polished_blackstone
fill 313 148 182 316 148 182 minecraft:red_nether_bricks
fill 313 148 222 316 148 222 minecraft:red_nether_bricks
setblock 317 148 182 minecraft:polished_blackstone
setblock 317 148 184 minecraft:light[level=14]
setblock 317 148 192 minecraft:light[level=14]
setblock 317 148 200 minecraft:light[level=14]
setblock 317 148 208 minecraft:light[level=14]
setblock 317 148 216 minecraft:light[level=14]
setblock 317 148 222 minecraft:polished_blackstone
fill 318 148 182 321 148 182 minecraft:red_nether_bricks
fill 318 148 203 320 211 205 minecraft:gilded_blackstone
fill 318 148 222 321 148 222 minecraft:red_nether_bricks
setblock 321 148 183 minecraft:polished_blackstone
setblock 322 148 182 minecraft:polished_blackstone
fill 322 148 183 323 150 183 minecraft:red_nether_bricks
fill 322 148 220 322 148 221 minecraft:red_nether_bricks
setblock 322 148 222 minecraft:polished_blackstone
fill 323 148 182 323 151 182 minecraft:red_nether_bricks
fill 323 148 184 323 148 185 minecraft:red_nether_bricks
setblock 323 148 186 minecraft:polished_blackstone
fill 323 148 187 323 151 187 minecraft:red_nether_bricks
fill 323 148 194 323 148 195 minecraft:red_nether_bricks
setblock 323 148 196 minecraft:polished_blackstone
fill 323 148 197 323 148 200 minecraft:red_nether_bricks
setblock 323 148 201 minecraft:polished_blackstone
fill 323 148 202 323 151 202 minecraft:red_nether_bricks
fill 323 148 217 323 148 220 minecraft:red_nether_bricks
setblock 323 148 221 minecraft:polished_blackstone
fill 323 148 222 323 151 222 minecraft:red_nether_bricks
fill 283 149 182 283 149 184 minecraft:red_nether_bricks
setblock 283 149 185 minecraft:polished_blackstone
fill 283 149 198 283 149 199 minecraft:red_nether_bricks
setblock 283 149 200 minecraft:polished_blackstone
fill 283 149 201 283 152 201 minecraft:red_nether_bricks
setblock 283 149 205 minecraft:polished_blackstone
fill 283 149 206 283 152 206 minecraft:red_nether_bricks
setblock 283 149 214 minecraft:red_nether_bricks
setblock 283 149 215 minecraft:polished_blackstone
fill 283 149 216 283 149 219 minecraft:red_nether_bricks
setblock 283 149 220 minecraft:polished_blackstone
fill 283 149 221 285 149 222 minecraft:red_nether_bricks
fill 284 149 182 284 149 183 minecraft:red_nether_bricks
fill 284 149 202 284 150 202 minecraft:red_nether_bricks
fill 284 149 215 284 149 218 minecraft:red_nether_bricks
setblock 284 149 219 minecraft:polished_blackstone
fill 284 149 220 287 149 220 minecraft:red_nether_bricks
setblock 285 149 182 minecraft:red_nether_bricks
setblock 285 149 183 minecraft:polished_blackstone
setblock 285 149 217 minecraft:red_nether_bricks
setblock 285 149 218 minecraft:polished_blackstone
fill 285 149 219 285 152 219 minecraft:red_nether_bricks
setblock 286 149 182 minecraft:polished_blackstone
fill 286 149 183 286 152 183 minecraft:red_nether_bricks
setblock 286 149 221 minecraft:red_nether_bricks
setblock 286 149 222 minecraft:polished_blackstone
fill 287 149 182 290 149 182 minecraft:red_nether_bricks
setblock 287 149 221 minecraft:polished_blackstone
fill 287 149 222 290 149 222 minecraft:red_nether_bricks
setblock 288 149 220 minecraft:polished_blackstone
fill 288 149 221 291 149 221 minecraft:red_nether_bricks
fill 289 149 220 291 149 220 minecraft:red_nether_bricks
setblock 291 149 182 minecraft:polished_blackstone
setblock 291 149 222 minecraft:polished_blackstone
fill 292 149 182 292 150 182 minecraft:red_nether_bricks
setblock 292 149 221 minecraft:polished_blackstone
fill 292 149 222 295 149 222 minecraft:red_nether_bricks
setblock 293 149 221 minecraft:red_nether_bricks
setblock 296 149 222 minecraft:polished_blackstone
fill 298 149 205 305 149 206 minecraft:magma_block
fill 299 149 203 304 149 204 minecraft:magma_block
fill 299 149 207 299 149 208 minecraft:magma_block
fill 300 149 207 304 149 207 minecraft:magma_block
fill 301 149 202 302 149 202 minecraft:magma_block
fill 302 149 208 302 149 209 minecraft:magma_block
fill 302 149 222 305 149 222 minecraft:red_nether_bricks
fill 303 149 182 305 149 182 minecraft:red_nether_bricks
fill 303 149 208 304 149 208 minecraft:magma_block
setblock 306 149 182 minecraft:polished_blackstone
fill 306 149 183 309 149 183 minecraft:red_nether_bricks
setblock 306 149 221 minecraft:red_nether_bricks
setblock 306 149 222 minecraft:polished_blackstone
fill 307 149 182 310 149 182 minecraft:red_nether_bricks
setblock 307 149 221 minecraft:polished_blackstone
fill 307 149 222 310 149 222 minecraft:red_nether_bricks
fill 308 149 221 310 149 221 minecraft:red_nether_bricks
setblock 310 149 183 minecraft:polished_blackstone
setblock 311 149 182 minecraft:polished_blackstone
fill 311 149 183 313 150 183 minecraft:red_nether_bricks
setblock 311 149 222 minecraft:polished_blackstone
fill 312 149 182 315 149 182 minecraft:red_nether_bricks
fill 312 149 222 315 149 222 minecraft:red_nether_bricks
setblock 316 149 182 minecraft:polished_blackstone
setblock 316 149 222 minecraft:polished_blackstone
fill 317 149 182 320 149 182 minecraft:red_nether_bricks
fill 317 149 222 320 149 222 minecraft:red_nether_bricks
setblock 321 149 182 minecraft:polished_blackstone
fill 321 149 183 321 152 183 minecraft:red_nether_bricks
setblock 321 149 222 minecraft:polished_blackstone
fill 322 149 182 322 152 182 minecraft:red_nether_bricks
fill 322 149 184 323 149 184 minecraft:red_nether_bricks
setblock 322 149 221 minecraft:polished_blackstone
fill 322 149 222 322 152 222 minecraft:red_nether_bricks
setblock 323 149 185 minecraft:polished_blackstone
fill 323 149 186 323 152 186 minecraft:red_nether_bricks
fill 323 149 196 323 149 199 minecraft:red_nether_bricks
setblock 323 149 200 minecraft:polished_blackstone
fill 323 149 201 323 152 201 minecraft:red_nether_bricks
fill 323 149 203 323 150 203 minecraft:red_nether_bricks
fill 323 149 217 323 149 219 minecraft:red_nether_bricks
setblock 323 149 220 minecraft:polished_blackstone
fill 323 149 221 323 152 221 minecraft:red_nether_bricks
fill 283 150 182 283 150 183 minecraft:red_nether_bricks
setblock 283 150 184 minecraft:polished_blackstone
fill 283 150 185 283 153 185 minecraft:red_nether_bricks
setblock 283 150 199 minecraft:polished_blackstone
fill 283 150 200 283 153 200 minecraft:red_nether_bricks
fill 283 150 202 283 150 203 minecraft:red_nether_bricks
setblock 283 150 204 minecraft:polished_blackstone
fill 283 150 205 284 152 205 minecraft:red_nether_bricks
fill 283 150 207 283 150 208 minecraft:red_nether_bricks
setblock 283 150 213 minecraft:red_nether_bricks
setblock 283 150 214 minecraft:polished_blackstone
fill 283 150 215 283 150 218 minecraft:red_nether_bricks
setblock 283 150 219 minecraft:polished_blackstone
fill 283 150 220 284 150 222 minecraft:red_nether_bricks
setblock 284 150 182 minecraft:red_nether_bricks
setblock 284 150 183 minecraft:polished_blackstone
fill 284 150 184 284 153 184 minecraft:red_nether_bricks
fill 284 150 201 284 151 201 minecraft:red_nether_bricks
setblock 284 150 203 minecraft:polished_blackstone
fill 284 150 204 284 153 204 minecraft:red_nether_bricks
fill 284 150 216 284 150 217 minecraft:red_nether_bricks
setblock 284 150 218 minecraft:polished_blackstone
fill 284 150 219 284 153 219 minecraft:red_nether_bricks
setblock 285 150 182 minecraft:polished_blackstone
fill 285 150 183 285 153 183 minecraft:red_nether_bricks
setblock 285 150 218 minecraft:red_nether_bricks
fill 285 150 220 285 150 221 minecraft:red_nether_bricks
setblock 285 150 222 minecraft:polished_blackstone
fill 286 150 182 289 150 182 minecraft:red_nether_bricks
setblock 286 150 220 minecraft:red_nether_bricks
setblock 286 150 221 minecraft:polished_blackstone
fill 286 150 222 289 150 222 minecraft:red_nether_bricks
fill 287 150 183 288 150 183 minecraft:red_nether_bricks
setblock 287 150 220 minecraft:polished_blackstone
fill 287 150 221 290 150 221 minecraft:red_nether_bricks
fill 288 150 220 290 150 220 minecraft:red_nether_bricks
setblock 290 150 182 minecraft:polished_blackstone
setblock 290 150 222 minecraft:polished_blackstone
fill 291 150 182 291 153 182 minecraft:red_nether_bricks
setblock 291 150 221 minecraft:polished_blackstone
fill 291 150 222 294 150 222 minecraft:red_nether_bricks
setblock 292 150 221 minecraft:red_nether_bricks
setblock 295 150 222 minecraft:polished_blackstone
fill 302 150 182 304 150 182 minecraft:red_nether_bricks
fill 302 150 222 304 150 222 minecraft:red_nether_bricks
setblock 305 150 182 minecraft:polished_blackstone
fill 305 150 183 308 150 183 minecraft:red_nether_bricks
setblock 305 150 222 minecraft:polished_blackstone
fill 306 150 182 309 150 182 minecraft:red_nether_bricks
fill 306 150 222 309 150 222 minecraft:red_nether_bricks
setblock 309 150 183 minecraft:polished_blackstone
setblock 310 150 182 minecraft:polished_blackstone
fill 310 150 183 310 153 183 minecraft:red_nether_bricks
fill 310 150 184 310 150 185 minecraft:polished_blackstone
setblock 310 150 222 minecraft:polished_blackstone
fill 311 150 182 314 150 182 minecraft:red_nether_bricks
fill 311 150 185 312 150 185 minecraft:polished_blackstone
fill 311 150 222 314 150 222 minecraft:red_nether_bricks
setblock 312 150 184 minecraft:polished_blackstone
setblock 315 150 182 minecraft:polished_blackstone
fill 316 150 182 319 150 182 minecraft:red_nether_bricks
fill 317 150 203 317 150 205 minecraft:polished_blackstone
fill 318 150 202 320 150 202 minecraft:polished_blackstone
fill 318 150 206 320 150 206 minecraft:polished_blackstone
fill 318 150 222 319 150 222 minecraft:red_nether_bricks
setblock 320 150 182 minecraft:polished_blackstone
fill 320 150 183 320 153 183 minecraft:red_nether_bricks
setblock 320 150 222 minecraft:polished_blackstone
fill 321 150 182 321 153 182 minecraft:red_nether_bricks
fill 321 150 203 321 150 205 minecraft:polished_blackstone
fill 321 150 222 321 153 222 minecraft:red_nether_bricks
setblock 322 150 184 minecraft:red_nether_bricks
setblock 322 150 185 minecraft:polished_blackstone
fill 322 150 221 322 153 221 minecraft:red_nether_bricks
setblock 323 150 184 minecraft:polished_blackstone
fill 323 150 185 323 153 185 minecraft:red_nether_bricks
setblock 323 150 188 minecraft:red_nether_bricks
setblock 323 150 198 minecraft:red_nether_bricks
setblock 323 150 199 minecraft:polished_blackstone
fill 323 150 200 323 153 200 minecraft:red_nether_bricks
setblock 323 150 204 minecraft:polished_blackstone
fill 323 150 217 323 150 218 minecraft:red_nether_bricks
setblock 323 150 219 minecraft:polished_blackstone
fill 323 150 220 323 153 220 minecraft:red_nether_bricks
setblock 283 151 182 minecraft:red_nether_bricks
setblock 283 151 183 minecraft:polished_blackstone
fill 283 151 184 283 154 184 minecraft:red_nether_bricks
fill 283 151 186 283 152 186 minecraft:red_nether_bricks
fill 283 151 199 283 154 199 minecraft:red_nether_bricks
setblock 283 151 202 minecraft:red_nether_bricks
setblock 283 151 203 minecraft:polished_blackstone
fill 283 151 204 283 154 204 minecraft:red_nether_bricks
setblock 283 151 207 minecraft:red_nether_bricks
setblock 283 151 208 minecraft:polished_blackstone
fill 283 151 209 283 151 212 minecraft:red_nether_bricks
setblock 283 151 213 minecraft:polished_blackstone
fill 283 151 214 283 151 217 minecraft:red_nether_bricks
setblock 283 151 218 minecraft:polished_blackstone
fill 283 151 219 283 151 222 minecraft:red_nether_bricks
setblock 284 151 182 minecraft:polished_blackstone
fill 284 151 183 284 154 183 minecraft:red_nether_bricks
setblock 284 151 202 minecraft:polished_blackstone
fill 284 151 203 284 154 203 minecraft:red_nether_bricks
setblock 284 151 206 minecraft:red_nether_bricks
setblock 284 151 207 minecraft:polished_blackstone
setblock 284 151 216 minecraft:red_nether_bricks
setblock 284 151 217 minecraft:polished_blackstone
fill 284 151 218 284 154 218 minecraft:red_nether_bricks
fill 284 151 220 284 151 221 minecraft:red_nether_bricks
setblock 284 151 222 minecraft:polished_blackstone
fill 285 151 182 288 151 182 minecraft:red_nether_bricks
setblock 285 151 220 minecraft:red_nether_bricks
setblock 285 151 221 minecraft:polished_blackstone
fill 285 151 222 288 151 222 minecraft:red_nether_bricks
setblock 286 151 220 minecraft:polished_blackstone
fill 286 151 221 289 151 221 minecraft:red_nether_bricks
setblock 287 151 183 minecraft:red_nether_bricks
fill 287 151 220 288 151 220 minecraft:red_nether_bricks
setblock 288 151 183 minecraft:polished_blackstone
setblock 289 151 182 minecraft:polished_blackstone
setblock 289 151 222 minecraft:polished_blackstone
fill 290 151 182 290 154 182 minecraft:red_nether_bricks
setblock 290 151 221 minecraft:polished_blackstone
fill 290 151 222 293 151 222 minecraft:red_nether_bricks
setblock 291 151 221 minecraft:red_nether_bricks
setblock 294 151 222 minecraft:polished_blackstone
fill 302 151 182 303 151 182 minecraft:red_nether_bricks
fill 302 151 222 303 151 222 minecraft:red_nether_bricks
setblock 304 151 182 minecraft:polished_blackstone
fill 304 151 183 307 151 183 minecraft:red_nether_bricks
setblock 304 151 222 minecraft:polished_blackstone
fill 305 151 182 308 151 182 minecraft:red_nether_bricks
fill 305 151 222 308 151 222 minecraft:red_nether_bricks
setblock 308 151 183 minecraft:polished_blackstone
setblock 309 151 182 minecraft:polished_blackstone
fill 309 151 183 309 154 183 minecraft:red_nether_bricks
setblock 309 151 222 minecraft:polished_blackstone
fill 310 151 182 313 151 182 minecraft:red_nether_bricks
fill 310 151 222 313 151 222 minecraft:red_nether_bricks
fill 311 151 183 312 151 183 minecraft:red_nether_bricks
setblock 313 151 183 minecraft:polished_blackstone
setblock 314 151 182 minecraft:polished_blackstone
fill 314 151 183 314 154 183 minecraft:red_nether_bricks
fill 315 151 182 318 151 182 minecraft:red_nether_bricks
setblock 318 151 222 minecraft:red_nether_bricks
setblock 319 151 182 minecraft:polished_blackstone
fill 319 151 183 319 154 183 minecraft:red_nether_bricks
setblock 319 151 222 minecraft:polished_blackstone
fill 320 151 182 320 154 182 minecraft:red_nether_bricks
fill 320 151 222 320 154 222 minecraft:red_nether_bricks
fill 321 151 203 322 152 205 minecraft:gilded_blackstone
setblock 322 151 183 minecraft:red_nether_bricks
setblock 322 151 184 minecraft:polished_blackstone
fill 322 151 185 322 154 185 minecraft:red_nether_bricks
fill 322 151 220 322 154 220 minecraft:red_nether_bricks
setblock 323 151 183 minecraft:polished_blackstone
fill 323 151 184 323 154 184 minecraft:red_nether_bricks
setblock 323 151 188 minecraft:polished_blackstone
fill 323 151 199 323 154 199 minecraft:red_nether_bricks
setblock 323 151 203 minecraft:polished_blackstone
fill 323 151 204 323 153 205 minecraft:red_nether_bricks
setblock 323 151 217 minecraft:red_nether_bricks
setblock 323 151 218 minecraft:polished_blackstone
fill 323 151 219 323 154 219 minecraft:red_nether_bricks
setblock 283 152 182 minecraft:polished_blackstone
fill 283 152 183 283 155 183 minecraft:red_nether_bricks
setblock 283 152 187 minecraft:polished_blackstone
setblock 283 152 202 minecraft:polished_blackstone
fill 283 152 203 283 155 203 minecraft:red_nether_bricks
setblock 283 152 207 minecraft:polished_blackstone
fill 283 152 208 283 152 211 minecraft:red_nether_bricks
setblock 283 152 212 minecraft:polished_blackstone
fill 283 152 213 283 152 216 minecraft:red_nether_bricks
setblock 283 152 217 minecraft:polished_blackstone
fill 283 152 218 283 152 221 minecraft:red_nether_bricks
setblock 283 152 222 minecraft:polished_blackstone
fill 284 152 182 287 152 182 minecraft:red_nether_bricks
setblock 284 152 185 minecraft:red_nether_bricks
setblock 284 152 201 minecraft:polished_blackstone
fill 284 152 202 284 155 202 minecraft:red_nether_bricks
setblock 284 152 206 minecraft:polished_blackstone
fill 284 152 207 284 152 210 minecraft:red_nether_bricks
setblock 284 152 215 minecraft:red_nether_bricks
setblock 284 152 216 minecraft:polished_blackstone
fill 284 152 217 284 155 217 minecraft:red_nether_bricks
setblock 284 152 220 minecraft:red_nether_bricks
setblock 284 152 221 minecraft:polished_blackstone
fill 284 152 222 287 152 222 minecraft:red_nether_bricks
fill 285 152 203 285 152 204 minecraft:red_nether_bricks
setblock 285 152 205 minecraft:polished_blackstone
fill 285 152 206 285 155 206 minecraft:red_nether_bricks
setblock 285 152 220 minecraft:polished_blackstone
fill 285 152 221 288 152 221 minecraft:red_nether_bricks
fill 286 152 220 287 153 220 minecraft:red_nether_bricks
setblock 287 152 183 minecraft:polished_blackstone
setblock 288 152 182 minecraft:polished_blackstone
fill 288 152 183 288 155 183 minecraft:red_nether_bricks
setblock 288 152 222 minecraft:polished_blackstone
fill 289 152 182 289 155 182 minecraft:red_nether_bricks
setblock 289 152 221 minecraft:polished_blackstone
fill 289 152 222 292 152 222 minecraft:red_nether_bricks
fill 290 152 221 290 153 221 minecraft:red_nether_bricks
setblock 293 152 222 minecraft:polished_blackstone
fill 301 152 182 302 152 182 minecraft:red_nether_bricks
setblock 302 152 222 minecraft:red_nether_bricks
setblock 303 152 182 minecraft:polished_blackstone
fill 303 152 183 306 152 183 minecraft:red_nether_bricks
setblock 303 152 222 minecraft:polished_blackstone
fill 304 152 182 307 152 182 minecraft:red_nether_bricks
fill 304 152 222 307 152 222 minecraft:red_nether_bricks
setblock 306 152 184 minecraft:polished_blackstone
setblock 307 152 183 minecraft:polished_blackstone
fill 307 152 184 309 153 184 minecraft:red_nether_bricks
setblock 308 152 182 minecraft:polished_blackstone
fill 308 152 183 308 155 183 minecraft:red_nether_bricks
setblock 308 152 222 minecraft:polished_blackstone
fill 309 152 182 312 152 182 minecraft:red_nether_bricks
fill 309 152 222 312 152 222 minecraft:red_nether_bricks
setblock 311 152 183 minecraft:red_nether_bricks
setblock 312 152 183 minecraft:polished_blackstone
setblock 313 152 182 minecraft:polished_blackstone
fill 313 152 183 313 155 183 minecraft:red_nether_bricks
fill 314 152 182 317 152 182 minecraft:red_nether_bricks
fill 315 152 183 316 152 183 minecraft:red_nether_bricks
setblock 317 152 183 minecraft:polished_blackstone
setblock 317 152 204 minecraft:shroomlight
setblock 318 152 182 minecraft:polished_blackstone
fill 318 152 183 318 155 183 minecraft:red_nether_bricks
setblock 318 152 222 minecraft:polished_blackstone
fill 319 152 182 319 155 182 minecraft:red_nether_bricks
fill 319 152 222 319 155 222 minecraft:red_nether_bricks
fill 321 152 221 321 154 221 minecraft:red_nether_bricks
setblock 322 152 183 minecraft:polished_blackstone
fill 322 152 184 322 155 184 minecraft:red_nether_bricks
fill 322 152 186 322 153 186 minecraft:red_nether_bricks
setblock 323 152 182 minecraft:polished_blackstone
fill 323 152 183 323 155 183 minecraft:red_nether_bricks
setblock 323 152 187 minecraft:polished_blackstone
fill 323 152 188 323 154 189 minecraft:red_nether_bricks
setblock 323 152 202 minecraft:polished_blackstone
fill 323 152 203 323 155 203 minecraft:red_nether_bricks
setblock 323 152 206 minecraft:red_nether_bricks
setblock 323 152 207 minecraft:polished_blackstone
setblock 323 152 217 minecraft:polished_blackstone
fill 323 152 218 323 155 218 minecraft:red_nether_bricks
setblock 323 152 222 minecraft:polished_blackstone
fill 283 153 182 286 153 182 minecraft:red_nether_bricks
setblock 283 153 186 minecraft:polished_blackstone
fill 283 153 187 283 155 188 minecraft:red_nether_bricks
fill 283 153 198 283 155 198 minecraft:red_nether_bricks
setblock 283 153 201 minecraft:polished_blackstone
fill 283 153 202 283 156 202 minecraft:red_nether_bricks
setblock 283 153 205 minecraft:red_nether_bricks
setblock 283 153 206 minecraft:polished_blackstone
fill 283 153 207 283 153 210 minecraft:red_nether_bricks
setblock 283 153 211 minecraft:polished_blackstone
fill 283 153 212 283 153 215 minecraft:red_nether_bricks
setblock 283 153 216 minecraft:polished_blackstone
fill 283 153 217 283 153 220 minecraft:red_nether_bricks
setblock 283 153 221 minecraft:polished_blackstone
fill 283 153 222 286 153 222 minecraft:red_nether_bricks
setblock 284 153 185 minecraft:polished_blackstone
fill 284 153 186 284 156 186 minecraft:red_nether_bricks
setblock 284 153 200 minecraft:polished_blackstone
fill 284 153 201 284 156 201 minecraft:red_nether_bricks
setblock 284 153 205 minecraft:polished_blackstone
fill 284 153 206 284 153 209 minecraft:red_nether_bricks
setblock 284 153 210 minecraft:polished_blackstone
fill 284 153 211 284 153 214 minecraft:red_nether_bricks
setblock 284 153 215 minecraft:polished_blackstone
fill 284 153 216 284 156 216 minecraft:red_nether_bricks
setblock 284 153 220 minecraft:polished_blackstone
fill 284 153 221 287 153 221 minecraft:red_nether_bricks
fill 285 153 202 285 153 203 minecraft:red_nether_bricks
setblock 285 153 204 minecraft:polished_blackstone
fill 285 153 205 285 156 205 minecraft:red_nether_bricks
fill 285 153 207 285 153 208 minecraft:red_nether_bricks
setblock 285 153 209 minecraft:polished_blackstone
setblock 285 153 219 minecraft:polished_blackstone
fill 285 153 220 285 156 220 minecraft:red_nether_bricks
setblock 286 153 183 minecraft:polished_blackstone
setblock 287 153 182 minecraft:polished_blackstone
fill 287 153 183 287 156 183 minecraft:red_nether_bricks
setblock 287 153 222 minecraft:polished_blackstone
fill 288 153 182 288 156 182 minecraft:red_nether_bricks
setblock 288 153 221 minecraft:polished_blackstone
fill 288 153 222 291 153 222 minecraft:red_nether_bricks
fill 289 153 221 289 154 221 minecraft:red_nether_bricks
setblock 292 153 222 minecraft:polished_blackstone
fill 300 153 182 301 153 182 minecraft:red_nether_bricks
setblock 302 153 182 minecraft:polished_blackstone
fill 302 153 183 305 153 183 minecraft:red_nether_bricks
setblock 302 153 222 minecraft:polished_blackstone
fill 303 153 182 306 153 182 minecraft:red_nether_bricks
fill 303 153 222 306 153 222 minecraft:red_nether_bricks
setblock 304 153 184 minecraft:red_nether_bricks
setblock 305 153 184 minecraft:polished_blackstone
setblock 306 153 183 minecraft:polished_blackstone
fill 306 153 184 306 156 184 minecraft:red_nether_bricks
setblock 307 153 182 minecraft:polished_blackstone
fill 307 153 183 307 156 183 minecraft:red_nether_bricks
setblock 307 153 222 minecraft:polished_blackstone
fill 308 153 182 311 153 182 minecraft:red_nether_bricks
fill 308 153 222 311 153 222 minecraft:red_nether_bricks
setblock 310 153 184 minecraft:polished_blackstone
setblock 311 153 183 minecraft:polished_blackstone
setblock 312 153 182 minecraft:polished_blackstone
fill 312 153 183 312 156 183 minecraft:red_nether_bricks
fill 313 153 182 316 153 182 minecraft:red_nether_bricks
setblock 315 153 183 minecraft:red_nether_bricks
setblock 316 153 183 minecraft:polished_blackstone
setblock 317 153 182 minecraft:polished_blackstone
fill 317 153 183 317 156 183 minecraft:red_nether_bricks
setblock 317 153 222 minecraft:polished_blackstone
fill 318 153 182 318 156 182 minecraft:red_nether_bricks
fill 318 153 222 318 156 222 minecraft:red_nether_bricks
setblock 321 153 183 minecraft:polished_blackstone
fill 321 153 184 321 156 184 minecraft:red_nether_bricks
setblock 322 153 182 minecraft:polished_blackstone
fill 322 153 183 322 156 183 minecraft:red_nether_bricks
setblock 322 153 187 minecraft:polished_blackstone
setblock 322 153 222 minecraft:polished_blackstone
fill 323 153 182 323 156 182 minecraft:red_nether_bricks
setblock 323 153 186 minecraft:polished_blackstone
fill 323 153 187 323 156 187 minecraft:red_nether_bricks
setblock 323 153 190 minecraft:red_nether_bricks
setblock 323 153 201 minecraft:polished_blackstone
fill 323 153 202 323 156 202 minecraft:red_nether_bricks
setblock 323 153 206 minecraft:polished_blackstone
fill 323 153 207 323 153 210 minecraft:red_nether_bricks
setblock 323 153 216 minecraft:polished_blackstone
fill 323 153 217 323 156 217 minecraft:red_nether_bricks
setblock 323 153 221 minecraft:polished_blackstone
fill 323 153 222 323 156 222 minecraft:red_nether_bricks
fill 283 154 182 285 154 182 minecraft:red_nether_bricks
setblock 283 154 185 minecraft:polished_blackstone
fill 283 154 186 283 157 186 minecraft:red_nether_bricks
setblock 283 154 189 minecraft:red_nether_bricks
setblock 283 154 200 minecraft:polished_blackstone
fill 283 154 201 283 157 201 minecraft:red_nether_bricks
setblock 283 154 205 minecraft:polished_blackstone
fill 283 154 206 283 154 209 minecraft:red_nether_bricks
setblock 283 154 210 minecraft:polished_blackstone
fill 283 154 211 283 154 214 minecraft:red_nether_bricks
setblock 283 154 215 minecraft:polished_blackstone
fill 283 154 216 283 154 219 minecraft:red_nether_bricks
setblock 283 154 220 minecraft:polished_blackstone
fill 283 154 221 285 154 222 minecraft:red_nether_bricks
setblock 284 154 184 minecraft:polished_blackstone
fill 284 154 185 284 157 185 minecraft:red_nether_bricks
fill 284 154 187 284 155 187 minecraft:red_nether_bricks
fill 284 154 200 284 157 200 minecraft:red_nether_bricks
setblock 284 154 204 minecraft:polished_blackstone
fill 284 154 205 284 154 208 minecraft:red_nether_bricks
setblock 284 154 209 minecraft:polished_blackstone
fill 284 154 210 284 154 213 minecraft:red_nether_bricks
setblock 284 154 214 minecraft:polished_blackstone
fill 284 154 215 284 157 215 minecraft:red_nether_bricks
setblock 284 154 219 minecraft:polished_blackstone
fill 284 154 220 284 157 220 minecraft:red_nether_bricks
setblock 285 154 183 minecraft:polished_blackstone
setblock 285 154 202 minecraft:red_nether_bricks
setblock 285 154 203 minecraft:polished_blackstone
fill 285 154 204 285 157 204 minecraft:red_nether_bricks
setblock 285 154 207 minecraft:red_nether_bricks
setblock 285 154 208 minecraft:polished_blackstone
fill 285 154 209 285 155 211 minecraft:red_nether_bricks
fill 285 154 219 285 155 219 minecraft:red_nether_bricks
setblock 286 154 182 minecraft:polished_blackstone
fill 286 154 183 286 157 183 minecraft:red_nether_bricks
fill 286 154 220 286 154 221 minecraft:red_nether_bricks
setblock 286 154 222 minecraft:polished_blackstone
fill 287 154 182 287 157 182 minecraft:red_nether_bricks
setblock 287 154 221 minecraft:polished_blackstone
fill 287 154 222 290 154 222 minecraft:red_nether_bricks
fill 288 154 221 288 156 221 minecraft:red_nether_bricks
setblock 291 154 182 minecraft:polished_blackstone
setblock 291 154 222 minecraft:polished_blackstone
fill 299 154 182 300 154 182 minecraft:red_nether_bricks
setblock 301 154 182 minecraft:polished_blackstone
fill 301 154 183 304 154 183 minecraft:red_nether_bricks
setblock 301 154 222 minecraft:polished_blackstone
fill 302 154 182 305 154 182 minecraft:red_nether_bricks
fill 302 154 222 305 154 222 minecraft:red_nether_bricks
setblock 303 154 184 minecraft:red_nether_bricks
setblock 304 154 184 minecraft:polished_blackstone
setblock 305 154 183 minecraft:polished_blackstone
fill 305 154 184 305 157 184 minecraft:red_nether_bricks
setblock 306 154 182 minecraft:polished_blackstone
fill 306 154 183 306 157 183 minecraft:red_nether_bricks
setblock 306 154 222 minecraft:polished_blackstone
fill 307 154 182 310 154 182 minecraft:red_nether_bricks
fill 307 154 184 308 154 184 minecraft:red_nether_bricks
fill 307 154 222 310 154 222 minecraft:red_nether_bricks
setblock 309 154 184 minecraft:polished_blackstone
setblock 310 154 183 minecraft:polished_blackstone
fill 310 154 184 311 156 184 minecraft:red_nether_bricks
setblock 311 154 182 minecraft:polished_blackstone
fill 311 154 183 311 157 183 minecraft:red_nether_bricks
setblock 311 154 222 minecraft:polished_blackstone
fill 312 154 182 315 154 182 minecraft:red_nether_bricks
setblock 315 154 183 minecraft:polished_blackstone
setblock 316 154 182 minecraft:polished_blackstone
fill 316 154 183 316 157 183 minecraft:red_nether_bricks
fill 317 154 182 317 157 182 minecraft:red_nether_bricks
fill 317 154 222 317 157 222 minecraft:red_nether_bricks
setblock 319 154 184 minecraft:polished_blackstone
setblock 320 154 183 minecraft:polished_blackstone
fill 320 154 184 320 157 184 minecraft:red_nether_bricks
fill 320 154 221 320 155 221 minecraft:red_nether_bricks
setblock 321 154 182 minecraft:polished_blackstone
fill 321 154 183 321 157 183 minecraft:red_nether_bricks
fill 321 154 185 321 154 186 minecraft:red_nether_bricks
setblock 321 154 222 minecraft:polished_blackstone
fill 322 154 182 322 157 182 minecraft:red_nether_bricks
setblock 322 154 186 minecraft:polished_blackstone
fill 322 154 187 322 155 189 minecraft:red_nether_bricks
fill 322 154 204 322 154 205 minecraft:red_nether_bricks
setblock 322 154 206 minecraft:polished_blackstone
fill 322 154 219 322 155 219 minecraft:red_nether_bricks
setblock 322 154 221 minecraft:polished_blackstone
fill 322 154 222 322 157 222 minecraft:red_nether_bricks
setblock 323 154 185 minecraft:polished_blackstone
fill 323 154 186 323 157 186 minecraft:red_nether_bricks
setblock 323 154 190 minecraft:polished_blackstone
fill 323 154 191 323 157 191 minecraft:red_nether_bricks
fill 323 154 198 323 155 198 minecraft:red_nether_bricks
setblock 323 154 200 minecraft:polished_blackstone
fill 323 154 201 323 157 201 minecraft:red_nether_bricks
setblock 323 154 204 minecraft:red_nether_bricks
setblock 323 154 205 minecraft:polished_blackstone
fill 323 154 206 323 154 209 minecraft:red_nether_bricks
setblock 323 154 210 minecraft:polished_blackstone
fill 323 154 211 323 154 214 minecraft:red_nether_bricks
setblock 323 154 215 minecraft:polished_blackstone
fill 323 154 216 323 157 216 minecraft:red_nether_bricks
setblock 323 154 220 minecraft:polished_blackstone
fill 323 154 221 323 157 221 minecraft:red_nether_bricks
fill 283 155 182 284 155 182 minecraft:red_nether_bricks
setblock 283 155 184 minecraft:polished_blackstone
fill 283 155 185 283 158 185 minecraft:red_nether_bricks
setblock 283 155 189 minecraft:polished_blackstone
fill 283 155 190 283 157 191 minecraft:red_nether_bricks
fill 283 155 197 283 156 197 minecraft:red_nether_bricks
setblock 283 155 199 minecraft:polished_blackstone
fill 283 155 200 283 158 200 minecraft:red_nether_bricks
setblock 283 155 204 minecraft:polished_blackstone
fill 283 155 205 283 155 208 minecraft:red_nether_bricks
setblock 283 155 209 minecraft:polished_blackstone
fill 283 155 210 283 155 213 minecraft:red_nether_bricks
setblock 283 155 214 minecraft:polished_blackstone
fill 283 155 215 283 155 218 minecraft:red_nether_bricks
setblock 283 155 219 minecraft:polished_blackstone
fill 283 155 220 283 156 222 minecraft:red_nether_bricks
setblock 284 155 183 minecraft:polished_blackstone
fill 284 155 184 285 157 184 minecraft:red_nether_bricks
setblock 284 155 188 minecraft:polished_blackstone
setblock 284 155 203 minecraft:polished_blackstone
fill 284 155 204 284 155 207 minecraft:red_nether_bricks
setblock 284 155 208 minecraft:polished_blackstone
fill 284 155 209 284 155 212 minecraft:red_nether_bricks
setblock 284 155 213 minecraft:polished_blackstone
fill 284 155 214 284 158 214 minecraft:red_nether_bricks
setblock 284 155 218 minecraft:polished_blackstone
fill 284 155 219 284 158 219 minecraft:red_nether_bricks
fill 284 155 221 284 155 222 minecraft:red_nether_bricks
setblock 285 155 182 minecraft:polished_blackstone
fill 285 155 183 285 158 183 minecraft:red_nether_bricks
setblock 285 155 202 minecraft:polished_blackstone
fill 285 155 203 285 158 203 minecraft:red_nether_bricks
setblock 285 155 207 minecraft:polished_blackstone
fill 285 155 208 286 157 208 minecraft:red_nether_bricks
setblock 285 155 212 minecraft:polished_blackstone
fill 285 155 213 285 158 213 minecraft:red_nether_bricks
setblock 285 155 221 minecraft:red_nether_bricks
setblock 285 155 222 minecraft:polished_blackstone
fill 286 155 182 286 158 182 minecraft:red_nether_bricks
setblock 286 155 205 minecraft:red_nether_bricks
setblock 286 155 206 minecraft:polished_blackstone
fill 286 155 207 286 158 207 minecraft:red_nether_bricks
fill 286 155 209 286 156 209 minecraft:red_nether_bricks
setblock 286 155 221 minecraft:polished_blackstone
fill 286 155 222 289 155 222 minecraft:red_nether_bricks
fill 287 155 221 287 157 221 minecraft:red_nether_bricks
setblock 290 155 182 minecraft:polished_blackstone
setblock 290 155 222 minecraft:polished_blackstone
fill 291 155 182 291 156 182 minecraft:red_nether_bricks
setblock 291 155 222 minecraft:red_nether_bricks
fill 298 155 182 299 155 182 minecraft:red_nether_bricks
setblock 300 155 182 minecraft:polished_blackstone
fill 300 155 183 303 155 183 minecraft:red_nether_bricks
setblock 300 155 222 minecraft:polished_blackstone
fill 301 155 182 304 155 182 minecraft:red_nether_bricks
fill 301 155 222 304 155 222 minecraft:red_nether_bricks
setblock 302 155 184 minecraft:red_nether_bricks
setblock 303 155 184 minecraft:polished_blackstone
setblock 304 155 183 minecraft:polished_blackstone
fill 304 155 184 304 158 184 minecraft:red_nether_bricks
setblock 305 155 182 minecraft:polished_blackstone
fill 305 155 183 305 158 183 minecraft:red_nether_bricks
fill 305 155 185 306 155 185 minecraft:red_nether_bricks
setblock 305 155 222 minecraft:polished_blackstone
fill 306 155 182 309 155 182 minecraft:red_nether_bricks
fill 306 155 222 309 155 222 minecraft:red_nether_bricks
setblock 307 155 184 minecraft:red_nether_bricks
setblock 307 155 185 minecraft:polished_blackstone
setblock 308 155 184 minecraft:polished_blackstone
setblock 309 155 183 minecraft:polished_blackstone
fill 309 155 184 309 158 184 minecraft:red_nether_bricks
setblock 310 155 182 minecraft:polished_blackstone
fill 310 155 183 310 158 183 minecraft:red_nether_bricks
fill 310 155 185 312 155 185 minecraft:polished_blackstone
setblock 310 155 222 minecraft:polished_blackstone
fill 311 155 182 314 155 182 minecraft:red_nether_bricks
fill 312 155 184 312 156 184 minecraft:polished_blackstone
setblock 314 155 183 minecraft:polished_blackstone
setblock 315 155 182 minecraft:polished_blackstone
fill 315 155 183 315 158 183 minecraft:red_nether_bricks
fill 316 155 182 316 158 182 minecraft:red_nether_bricks
fill 316 155 222 316 158 222 minecraft:red_nether_bricks
setblock 317 155 184 minecraft:red_nether_bricks
setblock 318 155 184 minecraft:polished_blackstone
setblock 319 155 183 minecraft:polished_blackstone
fill 319 155 184 319 158 184 minecraft:red_nether_bricks
setblock 320 155 182 minecraft:polished_blackstone
fill 320 155 183 320 158 183 minecraft:red_nether_bricks
setblock 320 155 222 minecraft:polished_blackstone
fill 321 155 182 321 158 182 minecraft:red_nether_bricks
setblock 321 155 185 minecraft:red_nether_bricks
setblock 321 155 186 minecraft:polished_blackstone
fill 321 155 187 321 158 187 minecraft:red_nether_bricks
setblock 321 155 221 minecraft:polished_blackstone
fill 321 155 222 321 158 222 minecraft:red_nether_bricks
setblock 322 155 185 minecraft:polished_blackstone
fill 322 155 186 322 158 186 minecraft:red_nether_bricks
setblock 322 155 190 minecraft:polished_blackstone
fill 322 155 202 322 155 204 minecraft:red_nether_bricks
setblock 322 155 205 minecraft:polished_blackstone
fill 322 155 206 322 155 209 minecraft:red_nether_bricks
setblock 322 155 210 minecraft:polished_blackstone
fill 322 155 218 322 156 218 minecraft:red_nether_bricks
setblock 322 155 220 minecraft:polished_blackstone
fill 322 155 221 322 158 221 minecraft:red_nether_bricks
setblock 323 155 184 minecraft:polished_blackstone
fill 323 155 185 323 158 185 minecraft:red_nether_bricks
setblock 323 155 188 minecraft:red_nether_bricks
setblock 323 155 189 minecraft:polished_blackstone
fill 323 155 190 323 158 190 minecraft:red_nether_bricks
fill 323 155 192 323 155 193 minecraft:red_nether_bricks
setblock 323 155 199 minecraft:polished_blackstone
fill 323 155 200 323 158 200 minecraft:red_nether_bricks
setblock 323 155 204 minecraft:polished_blackstone
fill 323 155 205 323 155 208 minecraft:red_nether_bricks
setblock 323 155 209 minecraft:polished_blackstone
fill 323 155 210 323 155 213 minecraft:red_nether_bricks
setblock 323 155 214 minecraft:polished_blackstone
fill 323 155 215 323 158 215 minecraft:red_nether_bricks
setblock 323 155 219 minecraft:polished_blackstone
fill 323 155 220 323 158 220 minecraft:red_nether_bricks
setblock 283 156 182 minecraft:red_nether_bricks
setblock 283 156 183 minecraft:polished_blackstone
fill 283 156 184 283 159 184 minecraft:red_nether_bricks
setblock 283 156 187 minecraft:red_nether_bricks
setblock 283 156 188 minecraft:polished_blackstone
fill 283 156 189 284 158 189 minecraft:red_nether_bricks
setblock 283 156 192 minecraft:red_nether_bricks
setblock 283 156 193 minecraft:polished_blackstone
setblock 283 156 198 minecraft:polished_blackstone
fill 283 156 199 284 157 199 minecraft:red_nether_bricks
setblock 283 156 203 minecraft:polished_blackstone
fill 283 156 204 283 156 207 minecraft:red_nether_bricks
setblock 283 156 208 minecraft:polished_blackstone
fill 283 156 209 283 156 212 minecraft:red_nether_bricks
setblock 283 156 213 minecraft:polished_blackstone
fill 283 156 214 283 156 217 minecraft:red_nether_bricks
setblock 283 156 218 minecraft:polished_blackstone
fill 283 156 219 283 159 219 minecraft:red_nether_bricks
setblock 284 156 182 minecraft:polished_blackstone
fill 284 156 183 284 159 183 minecraft:red_nether_bricks
setblock 284 156 187 minecraft:polished_blackstone
fill 284 156 188 284 159 188 minecraft:red_nether_bricks
setblock 284 156 202 minecraft:polished_blackstone
fill 284 156 203 284 156 206 minecraft:red_nether_bricks
setblock 284 156 207 minecraft:polished_blackstone
fill 284 156 208 284 156 211 minecraft:red_nether_bricks
setblock 284 156 212 minecraft:polished_blackstone
fill 284 156 213 284 159 213 minecraft:red_nether_bricks
setblock 284 156 217 minecraft:polished_blackstone
fill 284 156 218 284 159 218 minecraft:red_nether_bricks
setblock 284 156 221 minecraft:red_nether_bricks
setblock 284 156 222 minecraft:polished_blackstone
fill 285 156 182 285 159 182 minecraft:red_nether_bricks
setblock 285 156 185 minecraft:red_nether_bricks
setblock 285 156 192 minecraft:light[level=14]
setblock 285 156 200 minecraft:light[level=14]
fill 285 156 202 285 158 202 minecraft:red_nether_bricks
setblock 285 156 206 minecraft:polished_blackstone
fill 285 156 207 285 159 207 minecraft:red_nether_bricks
fill 285 156 209 285 156 210 minecraft:red_nether_bricks
setblock 285 156 211 minecraft:polished_blackstone
fill 285 156 212 285 159 212 minecraft:red_nether_bricks
fill 285 156 214 285 156 215 minecraft:red_nether_bricks
setblock 285 156 216 minecraft:light[level=14]
setblock 285 156 221 minecraft:polished_blackstone
fill 285 156 222 288 156 222 minecraft:red_nether_bricks
setblock 286 156 204 minecraft:red_nether_bricks
setblock 286 156 205 minecraft:polished_blackstone
fill 286 156 206 286 159 206 minecraft:red_nether_bricks
setblock 286 156 210 minecraft:polished_blackstone
fill 286 156 221 286 158 221 minecraft:red_nether_bricks
setblock 288 156 183 minecraft:polished_blackstone
setblock 289 156 182 minecraft:polished_blackstone
setblock 289 156 222 minecraft:polished_blackstone
fill 290 156 182 290 157 182 minecraft:red_nether_bricks
setblock 290 156 222 minecraft:red_nether_bricks
setblock 293 156 184 minecraft:light[level=14]
setblock 293 156 192 minecraft:light[level=14]
setblock 293 156 200 minecraft:light[level=14]
setblock 293 156 208 minecraft:light[level=14]
setblock 293 156 216 minecraft:light[level=14]
fill 297 156 182 298 156 182 minecraft:red_nether_bricks
setblock 299 156 182 minecraft:polished_blackstone
fill 299 156 183 302 156 183 minecraft:red_nether_bricks
fill 300 156 182 303 156 182 minecraft:red_nether_bricks
fill 300 156 222 303 156 222 minecraft:red_nether_bricks
setblock 301 156 184 minecraft:red_nether_bricks
setblock 301 156 192 minecraft:light[level=14]
setblock 301 156 200 minecraft:light[level=14]
setblock 301 156 216 minecraft:light[level=14]
setblock 302 156 184 minecraft:polished_blackstone
setblock 303 156 183 minecraft:polished_blackstone
fill 303 156 184 303 158 185 minecraft:red_nether_bricks
setblock 304 156 182 minecraft:polished_blackstone
fill 304 156 183 304 159 183 minecraft:red_nether_bricks
fill 304 156 185 305 156 185 minecraft:red_nether_bricks
setblock 304 156 222 minecraft:polished_blackstone
fill 305 156 182 308 156 182 minecraft:red_nether_bricks
fill 305 156 222 308 156 222 minecraft:red_nether_bricks
setblock 306 156 185 minecraft:polished_blackstone
setblock 307 156 184 minecraft:polished_blackstone
fill 307 156 185 308 158 185 minecraft:red_nether_bricks
setblock 308 156 183 minecraft:polished_blackstone
fill 308 156 184 308 159 184 minecraft:red_nether_bricks
setblock 309 156 182 minecraft:polished_blackstone
fill 309 156 183 309 159 183 minecraft:red_nether_bricks
setblock 309 156 192 minecraft:light[level=14]
setblock 309 156 200 minecraft:light[level=14]
setblock 309 156 208 minecraft:light[level=14]
setblock 309 156 216 minecraft:light[level=14]
setblock 309 156 222 minecraft:polished_blackstone
fill 310 156 182 313 156 182 minecraft:red_nether_bricks
setblock 310 156 222 minecraft:red_nether_bricks
setblock 313 156 183 minecraft:polished_blackstone
fill 313 156 184 316 156 184 minecraft:red_nether_bricks
setblock 314 156 182 minecraft:polished_blackstone
fill 314 156 183 314 159 183 minecraft:red_nether_bricks
fill 315 156 182 315 159 182 minecraft:red_nether_bricks
fill 315 156 222 315 159 222 minecraft:red_nether_bricks
setblock 317 156 184 minecraft:polished_blackstone
setblock 317 156 192 minecraft:light[level=14]
setblock 317 156 200 minecraft:light[level=14]
setblock 317 156 208 minecraft:light[level=14]
setblock 317 156 216 minecraft:light[level=14]
setblock 318 156 183 minecraft:polished_blackstone
fill 318 156 184 318 159 184 minecraft:red_nether_bricks
setblock 319 156 182 minecraft:polished_blackstone
fill 319 156 183 319 159 183 minecraft:red_nether_bricks
setblock 319 156 221 minecraft:red_nether_bricks
setblock 319 156 222 minecraft:polished_blackstone
fill 320 156 182 320 159 182 minecraft:red_nether_bricks
setblock 320 156 185 minecraft:red_nether_bricks
setblock 320 156 221 minecraft:polished_blackstone
fill 320 156 222 320 159 222 minecraft:red_nether_bricks
setblock 321 156 185 minecraft:polished_blackstone
fill 321 156 186 321 159 186 minecraft:red_nether_bricks
fill 321 156 188 322 156 188 minecraft:red_nether_bricks
fill 321 156 221 321 159 221 minecraft:red_nether_bricks
setblock 322 156 184 minecraft:polished_blackstone
fill 322 156 185 322 159 185 minecraft:red_nether_bricks
fill 322 156 187 322 157 187 minecraft:red_nether_bricks
setblock 322 156 189 minecraft:polished_blackstone
fill 322 156 190 322 158 191 minecraft:red_nether_bricks
fill 322 156 202 322 156 203 minecraft:red_nether_bricks
setblock 322 156 204 minecraft:polished_blackstone
fill 322 156 205 322 156 208 minecraft:red_nether_bricks
setblock 322 156 209 minecraft:polished_blackstone
fill 322 156 210 322 156 213 minecraft:red_nether_bricks
setblock 322 156 214 minecraft:polished_blackstone
fill 322 156 215 322 157 217 minecraft:red_nether_bricks
setblock 322 156 219 minecraft:polished_blackstone
fill 322 156 220 322 159 220 minecraft:red_nether_bricks
setblock 323 156 183 minecraft:polished_blackstone
fill 323 156 184 323 159 184 minecraft:red_nether_bricks
setblock 323 156 188 minecraft:polished_blackstone
fill 323 156 189 323 159 189 minecraft:red_nether_bricks
setblock 323 156 192 minecraft:red_nether_bricks
setblock 323 156 193 minecraft:polished_blackstone
fill 323 156 194 323 159 194 minecraft:red_nether_bricks
setblock 323 156 197 minecraft:red_nether_bricks
setblock 323 156 198 minecraft:polished_blackstone
fill 323 156 199 323 159 199 minecraft:red_nether_bricks
setblock 323 156 203 minecraft:polished_blackstone
fill 323 156 204 323 156 207 minecraft:red_nether_bricks
setblock 323 156 208 minecraft:polished_blackstone
fill 323 156 209 323 156 212 minecraft:red_nether_bricks
setblock 323 156 213 minecraft:polished_blackstone
fill 323 156 214 323 159 214 minecraft:red_nether_bricks
setblock 323 156 218 minecraft:polished_blackstone
fill 323 156 219 323 159 219 minecraft:red_nether_bricks
setblock 283 157 182 minecraft:polished_blackstone
fill 283 157 183 283 160 183 minecraft:red_nether_bricks
setblock 283 157 187 minecraft:polished_blackstone
fill 283 157 188 283 160 188 minecraft:red_nether_bricks
setblock 283 157 192 minecraft:polished_blackstone
fill 283 157 193 283 157 196 minecraft:red_nether_bricks
setblock 283 157 197 minecraft:polished_blackstone
fill 283 157 198 283 160 198 minecraft:red_nether_bricks
setblock 283 157 202 minecraft:polished_blackstone
fill 283 157 203 283 157 206 minecraft:red_nether_bricks
setblock 283 157 207 minecraft:polished_blackstone
fill 283 157 208 283 157 211 minecraft:red_nether_bricks
setblock 283 157 212 minecraft:polished_blackstone
fill 283 157 213 283 157 216 minecraft:red_nether_bricks
setblock 283 157 217 minecraft:polished_blackstone
fill 283 157 218 283 160 218 minecraft:red_nether_bricks
fill 283 157 220 283 157 221 minecraft:red_nether_bricks
setblock 283 157 222 minecraft:polished_blackstone
fill 284 157 182 284 160 182 minecraft:red_nether_bricks
setblock 284 157 186 minecraft:polished_blackstone
fill 284 157 187 284 160 187 minecraft:red_nether_bricks
setblock 284 157 190 minecraft:red_nether_bricks
setblock 284 157 201 minecraft:polished_blackstone
fill 284 157 202 284 157 205 minecraft:red_nether_bricks
setblock 284 157 206 minecraft:polished_blackstone
fill 284 157 207 284 157 210 minecraft:red_nether_bricks
setblock 284 157 211 minecraft:polished_blackstone
fill 284 157 212 284 160 212 minecraft:red_nether_bricks
setblock 284 157 216 minecraft:polished_blackstone
fill 284 157 217 284 160 217 minecraft:red_nether_bricks
setblock 284 157 221 minecraft:polished_blackstone
fill 284 157 222 287 157 222 minecraft:red_nether_bricks
setblock 285 157 185 minecraft:polished_blackstone
setblock 285 157 186 minecraft:red_nether_bricks
setblock 285 157 205 minecraft:polished_blackstone
fill 285 157 206 285 160 206 minecraft:red_nether_bricks
setblock 285 157 209 minecraft:red_nether_bricks
setblock 285 157 210 minecraft:polished_blackstone
fill 285 157 211 286 159 211 minecraft:red_nether_bricks
setblock 285 157 214 minecraft:red_nether_bricks
setblock 285 157 215 minecraft:polished_blackstone
fill 285 157 216 285 158 216 minecraft:red_nether_bricks
fill 285 157 221 285 159 221 minecraft:red_nether_bricks
setblock 286 157 204 minecraft:polished_blackstone
fill 286 157 205 286 158 205 minecraft:red_nether_bricks
setblock 286 157 209 minecraft:polished_blackstone
fill 286 157 210 286 160 210 minecraft:red_nether_bricks
setblock 287 157 183 minecraft:polished_blackstone
setblock 288 157 182 minecraft:polished_blackstone
setblock 288 157 183 minecraft:red_nether_bricks
setblock 288 157 222 minecraft:polished_blackstone
fill 289 157 182 289 158 182 minecraft:red_nether_bricks
fill 289 157 222 289 158 222 minecraft:red_nether_bricks
fill 296 157 182 297 157 182 minecraft:red_nether_bricks
setblock 298 157 182 minecraft:polished_blackstone
fill 298 157 183 301 157 183 minecraft:red_nether_bricks
fill 299 157 182 302 157 182 minecraft:red_nether_bricks
setblock 300 157 184 minecraft:red_nether_bricks
fill 300 157 222 302 157 222 minecraft:red_nether_bricks
setblock 301 157 184 minecraft:polished_blackstone
setblock 302 157 183 minecraft:polished_blackstone
fill 302 157 184 302 159 185 minecraft:red_nether_bricks
setblock 303 157 182 minecraft:polished_blackstone
fill 303 157 183 303 160 183 minecraft:red_nether_bricks
setblock 303 157 222 minecraft:polished_blackstone
fill 304 157 182 307 157 182 minecraft:red_nether_bricks
setblock 304 157 185 minecraft:red_nether_bricks
fill 304 157 222 307 157 222 minecraft:red_nether_bricks
setblock 305 157 185 minecraft:polished_blackstone
setblock 306 157 184 minecraft:polished_blackstone
fill 306 157 185 306 159 185 minecraft:red_nether_bricks
setblock 307 157 183 minecraft:polished_blackstone
fill 307 157 184 307 160 184 minecraft:red_nether_bricks
setblock 308 157 182 minecraft:polished_blackstone
fill 308 157 183 308 160 183 minecraft:red_nether_bricks
setblock 308 157 222 minecraft:polished_blackstone
fill 309 157 182 312 157 182 minecraft:red_nether_bricks
setblock 309 157 222 minecraft:red_nether_bricks
setblock 310 157 184 minecraft:red_nether_bricks
setblock 311 157 184 minecraft:polished_blackstone
setblock 312 157 183 minecraft:polished_blackstone
fill 312 157 184 315 157 184 minecraft:red_nether_bricks
setblock 313 157 182 minecraft:polished_blackstone
fill 313 157 183 313 160 183 minecraft:red_nether_bricks
fill 314 157 182 314 160 182 minecraft:red_nether_bricks
setblock 316 157 184 minecraft:polished_blackstone
setblock 317 157 183 minecraft:polished_blackstone
fill 317 157 184 317 160 184 minecraft:red_nether_bricks
fill 317 157 203 317 157 205 minecraft:polished_blackstone
setblock 318 157 182 minecraft:polished_blackstone
fill 318 157 183 318 160 183 minecraft:red_nether_bricks
fill 318 157 202 320 157 202 minecraft:polished_blackstone
fill 318 157 206 320 157 206 minecraft:polished_blackstone
setblock 318 157 222 minecraft:polished_blackstone
fill 319 157 182 319 160 182 minecraft:red_nether_bricks
setblock 319 157 185 minecraft:red_nether_bricks
setblock 319 157 221 minecraft:polished_blackstone
fill 319 157 222 319 160 222 minecraft:red_nether_bricks
setblock 320 157 185 minecraft:polished_blackstone
fill 320 157 186 320 160 186 minecraft:red_nether_bricks
fill 320 157 221 320 160 221 minecraft:red_nether_bricks
setblock 321 157 184 minecraft:polished_blackstone
fill 321 157 185 321 160 185 minecraft:red_nether_bricks
setblock 321 157 188 minecraft:red_nether_bricks
setblock 321 157 189 minecraft:polished_blackstone
fill 321 157 203 321 157 205 minecraft:polished_blackstone
fill 321 157 207 321 157 208 minecraft:red_nether_bricks
setblock 321 157 209 minecraft:polished_blackstone
setblock 322 157 183 minecraft:polished_blackstone
fill 322 157 184 322 160 184 minecraft:red_nether_bricks
setblock 322 157 188 minecraft:polished_blackstone
fill 322 157 189 322 160 189 minecraft:red_nether_bricks
setblock 322 157 192 minecraft:red_nether_bricks
setblock 322 157 202 minecraft:red_nether_bricks
setblock 322 157 203 minecraft:polished_blackstone
fill 322 157 204 322 157 207 minecraft:red_nether_bricks
setblock 322 157 208 minecraft:polished_blackstone
fill 322 157 209 322 157 212 minecraft:red_nether_bricks
setblock 322 157 213 minecraft:polished_blackstone
fill 322 157 214 322 160 214 minecraft:red_nether_bricks
setblock 322 157 218 minecraft:polished_blackstone
fill 322 157 219 322 160 219 minecraft:red_nether_bricks
setblock 323 157 182 minecraft:polished_blackstone
fill 323 157 183 323 160 183 minecraft:red_nether_bricks
setblock 323 157 187 minecraft:polished_blackstone
fill 323 157 188 323 160 188 minecraft:red_nether_bricks
setblock 323 157 192 minecraft:polished_blackstone
fill 323 157 193 323 160 193 minecraft:red_nether_bricks
fill 323 157 195 323 157 196 minecraft:red_nether_bricks
setblock 323 157 197 minecraft:polished_blackstone
fill 323 157 198 323 159 198 minecraft:red_nether_bricks
setblock 323 157 202 minecraft:polished_blackstone
fill 323 157 203 323 157 206 minecraft:red_nether_bricks
setblock 323 157 207 minecraft:polished_blackstone
fill 323 157 208 323 157 211 minecraft:red_nether_bricks
setblock 323 157 212 minecraft:polished_blackstone
fill 323 157 213 323 160 213 minecraft:red_nether_bricks
setblock 323 157 217 minecraft:polished_blackstone
fill 323 157 218 323 160 218 minecraft:red_nether_bricks
setblock 323 157 222 minecraft:polished_blackstone
fill 283 158 182 283 161 182 minecraft:red_nether_bricks
setblock 283 158 186 minecraft:polished_blackstone
fill 283 158 187 283 161 187 minecraft:red_nether_bricks
setblock 283 158 190 minecraft:red_nether_bricks
setblock 283 158 191 minecraft:polished_blackstone
fill 283 158 192 283 158 195 minecraft:red_nether_bricks
setblock 283 158 196 minecraft:polished_blackstone
fill 283 158 197 283 161 197 minecraft:red_nether_bricks
fill 283 158 199 283 159 199 minecraft:red_nether_bricks
setblock 283 158 201 minecraft:polished_blackstone
fill 283 158 202 283 158 205 minecraft:red_nether_bricks
setblock 283 158 206 minecraft:polished_blackstone
fill 283 158 207 283 158 210 minecraft:red_nether_bricks
setblock 283 158 211 minecraft:polished_blackstone
fill 283 158 212 283 158 215 minecraft:red_nether_bricks
setblock 283 158 216 minecraft:polished_blackstone
fill 283 158 217 283 161 217 minecraft:red_nether_bricks
setblock 283 158 220 minecraft:red_nether_bricks
setblock 283 158 221 minecraft:polished_blackstone
fill 283 158 222 286 158 222 minecraft:red_nether_bricks
setblock 284 158 184 minecraft:red_nether_bricks
setblock 284 158 185 minecraft:polished_blackstone
fill 284 158 186 284 161 186 minecraft:red_nether_bricks
setblock 284 158 190 minecraft:polished_blackstone
fill 284 158 191 284 161 191 minecraft:red_nether_bricks
setblock 284 158 200 minecraft:polished_blackstone
fill 284 158 201 284 158 204 minecraft:red_nether_bricks
setblock 284 158 205 minecraft:polished_blackstone
fill 284 158 206 284 158 209 minecraft:red_nether_bricks
setblock 284 158 210 minecraft:polished_blackstone
fill 284 158 211 284 161 211 minecraft:red_nether_bricks
setblock 284 158 215 minecraft:polished_blackstone
fill 284 158 216 284 161 216 minecraft:red_nether_bricks
setblock 284 158 220 minecraft:polished_blackstone
fill 284 158 221 284 160 221 minecraft:red_nether_bricks
setblock 285 158 184 minecraft:polished_blackstone
setblock 285 158 185 minecraft:red_nether_bricks
setblock 285 158 204 minecraft:polished_blackstone
fill 285 158 205 285 161 205 minecraft:red_nether_bricks
setblock 285 158 208 minecraft:red_nether_bricks
setblock 285 158 209 minecraft:polished_blackstone
fill 285 158 210 285 161 210 minecraft:red_nether_bricks
setblock 285 158 214 minecraft:polished_blackstone
fill 285 158 215 285 161 215 minecraft:red_nether_bricks
setblock 286 158 183 minecraft:polished_blackstone
setblock 286 158 208 minecraft:polished_blackstone
fill 286 158 209 286 160 209 minecraft:red_nether_bricks
setblock 286 158 212 minecraft:red_nether_bricks
setblock 287 158 182 minecraft:polished_blackstone
setblock 287 158 183 minecraft:red_nether_bricks
setblock 287 158 222 minecraft:polished_blackstone
fill 288 158 182 288 159 182 minecraft:red_nether_bricks
setblock 288 158 222 minecraft:red_nether_bricks
setblock 296 158 182 minecraft:red_nether_bricks
setblock 297 158 182 minecraft:polished_blackstone
fill 298 158 182 300 158 183 minecraft:red_nether_bricks
setblock 299 158 184 minecraft:red_nether_bricks
setblock 300 158 184 minecraft:polished_blackstone
fill 300 158 222 301 158 222 minecraft:red_nether_bricks
setblock 301 158 182 minecraft:red_nether_bricks
setblock 301 158 183 minecraft:polished_blackstone
fill 301 158 184 301 160 185 minecraft:red_nether_bricks
setblock 302 158 182 minecraft:polished_blackstone
fill 302 158 183 302 161 183 minecraft:red_nether_bricks
setblock 302 158 222 minecraft:polished_blackstone
fill 303 158 182 306 158 182 minecraft:red_nether_bricks
fill 303 158 222 306 158 222 minecraft:red_nether_bricks
setblock 304 158 185 minecraft:polished_blackstone
setblock 305 158 184 minecraft:polished_blackstone
fill 305 158 185 305 160 185 minecraft:red_nether_bricks
setblock 306 158 183 minecraft:polished_blackstone
fill 306 158 184 306 161 184 minecraft:red_nether_bricks
setblock 307 158 182 minecraft:polished_blackstone
fill 307 158 183 307 161 183 minecraft:red_nether_bricks
setblock 307 158 222 minecraft:polished_blackstone
fill 308 158 182 311 158 182 minecraft:red_nether_bricks
setblock 308 158 222 minecraft:red_nether_bricks
setblock 310 158 184 minecraft:polished_blackstone
setblock 311 158 183 minecraft:polished_blackstone
fill 311 158 184 314 158 184 minecraft:red_nether_bricks
setblock 312 158 182 minecraft:polished_blackstone
fill 312 158 183 312 160 183 minecraft:red_nether_bricks
fill 313 158 182 313 161 182 minecraft:red_nether_bricks
setblock 315 158 184 minecraft:polished_blackstone
setblock 316 158 183 minecraft:polished_blackstone
fill 316 158 184 316 161 184 minecraft:red_nether_bricks
setblock 317 158 182 minecraft:polished_blackstone
fill 317 158 183 317 161 183 minecraft:red_nether_bricks
setblock 317 158 222 minecraft:polished_blackstone
fill 318 158 182 318 161 182 minecraft:red_nether_bricks
setblock 318 158 185 minecraft:red_nether_bricks
setblock 318 158 221 minecraft:polished_blackstone
fill 318 158 222 318 161 222 minecraft:red_nether_bricks
setblock 319 158 185 minecraft:polished_blackstone
fill 319 158 221 319 161 221 minecraft:red_nether_bricks
setblock 320 158 184 minecraft:polished_blackstone
fill 320 158 185 320 160 185 minecraft:red_nether_bricks
fill 320 158 187 320 159 187 minecraft:red_nether_bricks
setblock 321 158 183 minecraft:polished_blackstone
fill 321 158 184 321 161 184 minecraft:red_nether_bricks
setblock 321 158 188 minecraft:polished_blackstone
fill 321 158 189 321 160 190 minecraft:red_nether_bricks
fill 321 158 206 321 158 207 minecraft:red_nether_bricks
setblock 321 158 208 minecraft:polished_blackstone
fill 321 158 209 321 158 212 minecraft:red_nether_bricks
setblock 322 158 182 minecraft:polished_blackstone
fill 322 158 183 322 161 183 minecraft:red_nether_bricks
setblock 322 158 187 minecraft:polished_blackstone
fill 322 158 188 322 161 188 minecraft:red_nether_bricks
setblock 322 158 192 minecraft:polished_blackstone
setblock 322 158 202 minecraft:polished_blackstone
fill 322 158 203 322 158 206 minecraft:red_nether_bricks
setblock 322 158 207 minecraft:polished_blackstone
fill 322 158 208 322 158 211 minecraft:red_nether_bricks
setblock 322 158 212 minecraft:polished_blackstone
fill 322 158 213 322 161 213 minecraft:red_nether_bricks
fill 322 158 215 322 158 216 minecraft:red_nether_bricks
setblock 322 158 217 minecraft:polished_blackstone
fill 322 158 218 322 161 218 minecraft:red_nether_bricks
setblock 322 158 222 minecraft:polished_blackstone
fill 323 158 182 323 161 182 minecraft:red_nether_bricks
setblock 323 158 186 minecraft:polished_blackstone
fill 323 158 187 323 161 187 minecraft:red_nether_bricks
setblock 323 158 191 minecraft:polished_blackstone
fill 323 158 192 323 161 192 minecraft:red_nether_bricks
setblock 323 158 195 minecraft:red_nether_bricks
setblock 323 158 196 minecraft:polished_blackstone
fill 323 158 197 323 159 197 minecraft:red_nether_bricks
setblock 323 158 201 minecraft:polished_blackstone
fill 323 158 202 323 158 205 minecraft:red_nether_bricks
setblock 323 158 206 minecraft:polished_blackstone
fill 323 158 207 323 158 210 minecraft:red_nether_bricks
setblock 323 158 211 minecraft:polished_blackstone
fill 323 158 212 323 161 212 minecraft:red_nether_bricks
setblock 323 158 216 minecraft:polished_blackstone
fill 323 158 217 323 161 217 minecraft:red_nether_bricks
setblock 323 158 221 minecraft:polished_blackstone
fill 323 158 222 323 161 222 minecraft:red_nether_bricks
setblock 283 159 185 minecraft:polished_blackstone
fill 283 159 186 283 162 186 minecraft:red_nether_bricks
setblock 283 159 189 minecraft:red_nether_bricks
setblock 283 159 190 minecraft:polished_blackstone
fill 283 159 191 283 159 194 minecraft:red_nether_bricks
setblock 283 159 195 minecraft:polished_blackstone
fill 283 159 196 283 162 196 minecraft:red_nether_bricks
setblock 283 159 200 minecraft:polished_blackstone
fill 283 159 201 283 159 204 minecraft:red_nether_bricks
setblock 283 159 205 minecraft:polished_blackstone
fill 283 159 206 283 159 209 minecraft:red_nether_bricks
setblock 283 159 210 minecraft:polished_blackstone
fill 283 159 211 283 159 214 minecraft:red_nether_bricks
setblock 283 159 215 minecraft:polished_blackstone
fill 283 159 216 283 162 216 minecraft:red_nether_bricks
setblock 283 159 220 minecraft:polished_blackstone
fill 283 159 221 283 161 222 minecraft:red_nether_bricks
setblock 284 159 184 minecraft:polished_blackstone
fill 284 159 185 284 161 185 minecraft:red_nether_bricks
setblock 284 159 189 minecraft:polished_blackstone
fill 284 159 190 284 162 190 minecraft:red_nether_bricks
fill 284 159 200 284 159 203 minecraft:red_nether_bricks
setblock 284 159 204 minecraft:polished_blackstone
fill 284 159 205 284 159 208 minecraft:red_nether_bricks
setblock 284 159 209 minecraft:polished_blackstone
fill 284 159 210 284 162 210 minecraft:red_nether_bricks
setblock 284 159 214 minecraft:polished_blackstone
fill 284 159 215 284 162 215 minecraft:red_nether_bricks
setblock 284 159 219 minecraft:polished_blackstone
fill 284 159 220 284 160 220 minecraft:red_nether_bricks
fill 284 159 222 285 159 222 minecraft:red_nether_bricks
setblock 285 159 183 minecraft:polished_blackstone
setblock 285 159 203 minecraft:polished_blackstone
fill 285 159 204 285 160 204 minecraft:red_nether_bricks
setblock 285 159 208 minecraft:polished_blackstone
fill 285 159 209 285 162 209 minecraft:red_nether_bricks
setblock 285 159 213 minecraft:polished_blackstone
fill 285 159 214 285 162 214 minecraft:red_nether_bricks
setblock 286 159 182 minecraft:polished_blackstone
setblock 286 159 183 minecraft:red_nether_bricks
setblock 286 159 207 minecraft:polished_blackstone
fill 286 159 208 286 160 208 minecraft:red_nether_bricks
setblock 286 159 212 minecraft:polished_blackstone
setblock 286 159 222 minecraft:polished_blackstone
setblock 287 159 182 minecraft:red_nether_bricks
setblock 287 159 222 minecraft:red_nether_bricks
fill 294 159 195 295 160 195 minecraft:blackstone
fill 295 159 194 295 160 194 minecraft:blackstone
fill 295 159 196 295 160 196 minecraft:blackstone
setblock 296 159 182 minecraft:polished_blackstone
fill 297 159 182 299 159 183 minecraft:red_nether_bricks
setblock 299 159 184 minecraft:polished_blackstone
setblock 300 159 182 minecraft:red_nether_bricks
setblock 300 159 183 minecraft:polished_blackstone
fill 300 159 184 300 162 184 minecraft:red_nether_bricks
setblock 300 159 222 minecraft:red_nether_bricks
setblock 301 159 182 minecraft:polished_blackstone
fill 301 159 183 301 162 183 minecraft:red_nether_bricks
setblock 301 159 222 minecraft:polished_blackstone
fill 302 159 182 305 159 182 minecraft:red_nether_bricks
fill 302 159 222 305 159 222 minecraft:red_nether_bricks
setblock 303 159 184 minecraft:red_nether_bricks
setblock 303 159 185 minecraft:polished_blackstone
setblock 304 159 184 minecraft:polished_blackstone
fill 304 159 185 304 160 185 minecraft:red_nether_bricks
setblock 305 159 183 minecraft:polished_blackstone
fill 305 159 184 305 161 184 minecraft:red_nether_bricks
setblock 306 159 182 minecraft:polished_blackstone
fill 306 159 183 306 162 183 minecraft:red_nether_bricks
setblock 306 159 222 minecraft:polished_blackstone
fill 307 159 182 310 159 182 minecraft:red_nether_bricks
setblock 307 159 185 minecraft:red_nether_bricks
setblock 309 159 184 minecraft:polished_blackstone
setblock 310 159 183 minecraft:polished_blackstone
fill 310 159 184 311 159 184 minecraft:red_nether_bricks
setblock 311 159 182 minecraft:polished_blackstone
fill 311 159 183 311 160 183 minecraft:red_nether_bricks
fill 312 159 182 312 162 182 minecraft:red_nether_bricks
setblock 314 159 184 minecraft:polished_blackstone
setblock 315 159 183 minecraft:polished_blackstone
fill 315 159 184 315 160 184 minecraft:red_nether_bricks
setblock 316 159 182 minecraft:polished_blackstone
fill 316 159 183 316 162 183 minecraft:red_nether_bricks
setblock 316 159 222 minecraft:polished_blackstone
fill 317 159 182 317 162 182 minecraft:red_nether_bricks
fill 317 159 222 317 162 222 minecraft:red_nether_bricks
setblock 318 159 185 minecraft:polished_blackstone
fill 318 159 221 318 162 221 minecraft:red_nether_bricks
setblock 319 159 184 minecraft:polished_blackstone
fill 319 159 185 319 160 185 minecraft:red_nether_bricks
setblock 320 159 183 minecraft:polished_blackstone
fill 320 159 184 320 162 184 minecraft:red_nether_bricks
setblock 320 159 188 minecraft:polished_blackstone
setblock 321 159 182 minecraft:polished_blackstone
fill 321 159 183 321 162 183 minecraft:red_nether_bricks
setblock 321 159 187 minecraft:polished_blackstone
fill 321 159 188 321 162 188 minecraft:red_nether_bricks
setblock 321 159 206 minecraft:red_nether_bricks
setblock 321 159 207 minecraft:polished_blackstone
fill 321 159 208 321 159 211 minecraft:red_nether_bricks
setblock 321 159 212 minecraft:polished_blackstone
fill 321 159 213 321 160 215 minecraft:red_nether_bricks
setblock 321 159 222 minecraft:polished_blackstone
fill 322 159 182 322 162 182 minecraft:red_nether_bricks
setblock 322 159 186 minecraft:polished_blackstone
fill 322 159 187 322 162 187 minecraft:red_nether_bricks
setblock 322 159 190 minecraft:red_nether_bricks
setblock 322 159 191 minecraft:polished_blackstone
fill 322 159 192 322 161 193 minecraft:red_nether_bricks
fill 322 159 203 322 159 205 minecraft:red_nether_bricks
setblock 322 159 206 minecraft:polished_blackstone
fill 322 159 207 322 159 210 minecraft:red_nether_bricks
setblock 322 159 211 minecraft:polished_blackstone
fill 322 159 212 322 162 212 minecraft:red_nether_bricks
setblock 322 159 215 minecraft:red_nether_bricks
setblock 322 159 216 minecraft:polished_blackstone
fill 322 159 217 322 162 217 minecraft:red_nether_bricks
setblock 322 159 221 minecraft:polished_blackstone
fill 322 159 222 322 162 222 minecraft:red_nether_bricks
setblock 323 159 185 minecraft:polished_blackstone
fill 323 159 186 323 162 186 minecraft:red_nether_bricks
setblock 323 159 190 minecraft:polished_blackstone
fill 323 159 191 323 162 191 minecraft:red_nether_bricks
setblock 323 159 195 minecraft:polished_blackstone
fill 323 159 196 323 160 196 minecraft:red_nether_bricks
setblock 323 159 200 minecraft:polished_blackstone
fill 323 159 201 323 159 204 minecraft:red_nether_bricks
setblock 323 159 205 minecraft:polished_blackstone
fill 323 159 206 323 159 209 minecraft:red_nether_bricks
setblock 323 159 210 minecraft:polished_blackstone
fill 323 159 211 323 162 211 minecraft:red_nether_bricks
setblock 323 159 215 minecraft:polished_blackstone
fill 323 159 216 323 162 216 minecraft:red_nether_bricks
setblock 323 159 220 minecraft:polished_blackstone
fill 323 159 221 323 162 221 minecraft:red_nether_bricks
setblock 283 160 184 minecraft:polished_blackstone
fill 283 160 185 283 163 185 minecraft:red_nether_bricks
setblock 283 160 189 minecraft:polished_blackstone
fill 283 160 190 283 160 193 minecraft:red_nether_bricks
setblock 283 160 194 minecraft:polished_blackstone
fill 283 160 195 283 163 195 minecraft:red_nether_bricks
setblock 283 160 199 minecraft:polished_blackstone
fill 283 160 200 283 160 203 minecraft:red_nether_bricks
setblock 283 160 204 minecraft:polished_blackstone
fill 283 160 205 283 160 208 minecraft:red_nether_bricks
setblock 283 160 209 minecraft:polished_blackstone
fill 283 160 210 283 160 213 minecraft:red_nether_bricks
setblock 283 160 214 minecraft:polished_blackstone
fill 283 160 215 283 163 215 minecraft:red_nether_bricks
setblock 283 160 219 minecraft:polished_blackstone
fill 283 160 220 283 163 220 minecraft:red_nether_bricks
setblock 284 160 183 minecraft:polished_blackstone
setblock 284 160 184 minecraft:red_nether_bricks
setblock 284 160 188 minecraft:polished_blackstone
fill 284 160 189 284 162 189 minecraft:red_nether_bricks
fill 284 160 201 284 160 202 minecraft:red_nether_bricks
setblock 284 160 203 minecraft:polished_blackstone
fill 284 160 204 284 160 207 minecraft:red_nether_bricks
setblock 284 160 208 minecraft:polished_blackstone
fill 284 160 209 284 163 209 minecraft:red_nether_bricks
setblock 284 160 213 minecraft:polished_blackstone
fill 284 160 214 284 163 214 minecraft:red_nether_bricks
setblock 284 160 218 minecraft:polished_blackstone
fill 284 160 219 284 161 219 minecraft:red_nether_bricks
setblock 284 160 222 minecraft:red_nether_bricks
setblock 285 160 182 minecraft:polished_blackstone
setblock 285 160 207 minecraft:polished_blackstone
fill 285 160 208 285 163 208 minecraft:red_nether_bricks
setblock 285 160 211 minecraft:red_nether_bricks
setblock 285 160 212 minecraft:polished_blackstone
schedule function dropper:buildpart/42_7 1t
