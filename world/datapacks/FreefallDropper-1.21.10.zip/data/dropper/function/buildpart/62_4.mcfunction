fill 111 213 277 111 213 279 minecraft:red_terracotta
fill 112 213 277 113 213 277 minecraft:red_terracotta
fill 112 213 279 113 213 279 minecraft:red_terracotta
setblock 113 213 278 minecraft:red_terracotta
fill 94 214 275 94 215 276 minecraft:white_concrete
fill 94 214 277 94 215 278 minecraft:red_concrete
fill 94 214 279 94 215 279 minecraft:white_concrete
fill 94 214 280 94 219 280 minecraft:shroomlight
fill 94 214 281 94 215 282 minecraft:red_concrete
fill 94 214 283 94 215 284 minecraft:white_concrete
fill 94 214 285 94 215 286 minecraft:red_concrete
fill 94 214 287 94 215 287 minecraft:white_concrete
fill 94 214 288 94 219 288 minecraft:shroomlight
fill 94 214 289 94 215 290 minecraft:red_concrete
fill 94 214 291 94 215 292 minecraft:white_concrete
fill 94 214 293 94 215 294 minecraft:red_concrete
fill 94 214 295 94 215 295 minecraft:white_concrete
fill 94 214 296 94 219 296 minecraft:shroomlight
fill 94 214 297 94 215 298 minecraft:red_concrete
fill 94 214 299 94 215 300 minecraft:white_concrete
fill 94 214 301 94 215 302 minecraft:red_concrete
fill 94 214 303 94 215 303 minecraft:white_concrete
fill 94 214 304 94 219 304 minecraft:shroomlight
fill 94 214 305 94 215 306 minecraft:red_concrete
fill 94 214 307 94 215 308 minecraft:white_concrete
fill 94 214 309 94 215 310 minecraft:red_concrete
fill 94 214 311 94 215 311 minecraft:white_concrete
fill 94 214 312 94 219 312 minecraft:shroomlight
fill 94 214 313 94 215 314 minecraft:red_concrete
fill 94 214 315 94 215 316 minecraft:white_concrete
fill 95 214 275 95 215 275 minecraft:white_concrete
fill 95 214 317 95 215 317 minecraft:white_concrete
fill 96 214 275 97 215 275 minecraft:red_concrete
fill 96 214 317 96 215 317 minecraft:red_concrete
fill 97 214 317 97 219 317 minecraft:shroomlight
fill 98 214 275 99 215 275 minecraft:white_concrete
fill 98 214 317 99 215 317 minecraft:white_concrete
fill 100 214 275 100 215 275 minecraft:red_concrete
fill 100 214 317 101 215 317 minecraft:red_concrete
fill 101 214 275 101 219 275 minecraft:shroomlight
fill 102 214 275 103 215 275 minecraft:white_concrete
fill 102 214 317 103 215 317 minecraft:white_concrete
fill 104 214 275 105 215 275 minecraft:red_concrete
fill 104 214 317 104 215 317 minecraft:red_concrete
fill 105 214 317 105 219 317 minecraft:shroomlight
fill 106 214 275 107 215 275 minecraft:white_concrete
fill 106 214 317 107 215 317 minecraft:white_concrete
fill 108 214 275 108 215 275 minecraft:red_concrete
fill 108 214 317 109 215 317 minecraft:red_concrete
fill 109 214 275 109 219 275 minecraft:shroomlight
fill 110 214 275 111 215 275 minecraft:white_concrete
fill 110 214 317 111 215 317 minecraft:white_concrete
fill 111 214 277 111 217 279 minecraft:iron_block
fill 112 214 275 113 215 275 minecraft:red_concrete
fill 112 214 277 112 217 277 minecraft:iron_block
fill 112 214 279 112 217 279 minecraft:iron_block
fill 112 214 317 112 215 317 minecraft:red_concrete
fill 113 214 317 113 219 317 minecraft:shroomlight
fill 114 214 275 115 215 275 minecraft:white_concrete
fill 114 214 317 115 215 317 minecraft:white_concrete
fill 116 214 275 116 215 275 minecraft:red_concrete
fill 116 214 317 117 215 317 minecraft:red_concrete
fill 117 214 275 117 219 275 minecraft:shroomlight
fill 118 214 275 119 215 275 minecraft:white_concrete
fill 118 214 317 119 215 317 minecraft:white_concrete
fill 120 214 275 121 215 275 minecraft:red_concrete
fill 120 214 317 120 215 317 minecraft:red_concrete
fill 121 214 317 121 219 317 minecraft:shroomlight
fill 122 214 275 123 215 275 minecraft:white_concrete
fill 122 214 317 123 215 317 minecraft:white_concrete
fill 124 214 275 124 215 275 minecraft:red_concrete
fill 124 214 317 125 215 317 minecraft:red_concrete
fill 125 214 275 125 219 275 minecraft:shroomlight
fill 126 214 275 127 215 275 minecraft:white_concrete
fill 126 214 317 127 215 317 minecraft:white_concrete
fill 128 214 275 129 215 275 minecraft:red_concrete
fill 128 214 317 128 215 317 minecraft:red_concrete
fill 129 214 317 129 219 317 minecraft:shroomlight
fill 130 214 275 131 215 275 minecraft:white_concrete
fill 130 214 317 131 215 317 minecraft:white_concrete
fill 132 214 275 132 215 275 minecraft:red_concrete
fill 132 214 317 133 215 317 minecraft:red_concrete
fill 133 214 275 133 219 275 minecraft:shroomlight
fill 134 214 275 135 215 275 minecraft:white_concrete
fill 134 214 317 135 215 317 minecraft:white_concrete
fill 136 214 276 136 215 276 minecraft:white_concrete
fill 136 214 277 136 215 278 minecraft:red_concrete
fill 136 214 279 136 215 279 minecraft:white_concrete
fill 136 214 280 136 219 280 minecraft:shroomlight
fill 136 214 281 136 215 282 minecraft:red_concrete
fill 136 214 283 136 215 284 minecraft:white_concrete
fill 136 214 285 136 215 286 minecraft:red_concrete
fill 136 214 287 136 215 287 minecraft:white_concrete
fill 136 214 288 136 219 288 minecraft:shroomlight
fill 136 214 289 136 215 290 minecraft:red_concrete
fill 136 214 291 136 215 292 minecraft:white_concrete
fill 136 214 293 136 215 294 minecraft:red_concrete
fill 136 214 295 136 215 295 minecraft:white_concrete
fill 136 214 296 136 219 296 minecraft:shroomlight
fill 136 214 297 136 215 298 minecraft:red_concrete
fill 136 214 299 136 215 300 minecraft:white_concrete
fill 136 214 301 136 215 302 minecraft:red_concrete
fill 136 214 303 136 215 303 minecraft:white_concrete
fill 136 214 304 136 219 304 minecraft:shroomlight
fill 136 214 305 136 215 306 minecraft:red_concrete
fill 136 214 307 136 215 308 minecraft:white_concrete
fill 136 214 309 136 215 310 minecraft:red_concrete
fill 136 214 311 136 215 311 minecraft:white_concrete
fill 136 214 312 136 219 312 minecraft:shroomlight
fill 136 214 313 136 215 314 minecraft:red_concrete
fill 136 214 315 136 215 316 minecraft:white_concrete
fill 136 214 317 136 215 317 minecraft:red_concrete
fill 94 216 275 94 217 276 minecraft:red_concrete
fill 94 216 277 94 217 278 minecraft:white_concrete
fill 94 216 279 94 217 279 minecraft:red_concrete
fill 94 216 281 94 217 282 minecraft:white_concrete
fill 94 216 283 94 217 284 minecraft:red_concrete
fill 94 216 285 94 217 286 minecraft:white_concrete
fill 94 216 287 94 217 287 minecraft:red_concrete
fill 94 216 289 94 217 290 minecraft:white_concrete
fill 94 216 291 94 217 292 minecraft:red_concrete
fill 94 216 293 94 217 294 minecraft:white_concrete
fill 94 216 295 94 217 295 minecraft:red_concrete
fill 94 216 297 94 217 298 minecraft:white_concrete
fill 94 216 299 94 217 300 minecraft:red_concrete
fill 94 216 301 94 217 302 minecraft:white_concrete
fill 94 216 303 94 217 303 minecraft:red_concrete
fill 94 216 305 94 217 306 minecraft:white_concrete
fill 94 216 307 94 217 308 minecraft:red_concrete
fill 94 216 309 94 217 310 minecraft:white_concrete
fill 94 216 311 94 217 311 minecraft:red_concrete
fill 94 216 313 94 217 314 minecraft:white_concrete
fill 94 216 315 94 217 316 minecraft:red_concrete
fill 95 216 275 95 217 275 minecraft:red_concrete
fill 95 216 317 95 217 317 minecraft:red_concrete
fill 96 216 275 97 217 275 minecraft:white_concrete
fill 96 216 317 96 217 317 minecraft:white_concrete
fill 98 216 275 99 217 275 minecraft:red_concrete
fill 98 216 317 99 217 317 minecraft:red_concrete
fill 100 216 275 100 217 275 minecraft:white_concrete
fill 100 216 317 101 217 317 minecraft:white_concrete
fill 102 216 275 103 217 275 minecraft:red_concrete
fill 102 216 317 103 217 317 minecraft:red_concrete
fill 104 216 275 105 217 275 minecraft:white_concrete
fill 104 216 317 104 217 317 minecraft:white_concrete
fill 106 216 275 107 217 275 minecraft:red_concrete
fill 106 216 317 107 217 317 minecraft:red_concrete
fill 108 216 275 108 217 275 minecraft:white_concrete
fill 108 216 290 108 217 291 minecraft:brown_terracotta
fill 108 216 317 109 217 317 minecraft:white_concrete
fill 110 216 275 111 217 275 minecraft:red_concrete
fill 110 216 317 111 217 317 minecraft:red_concrete
fill 112 216 275 113 217 275 minecraft:white_concrete
fill 112 216 317 112 217 317 minecraft:white_concrete
fill 114 216 275 115 217 275 minecraft:red_concrete
fill 114 216 292 115 216 293 minecraft:yellow_concrete
fill 114 216 317 115 217 317 minecraft:red_concrete
fill 115 216 291 119 216 291 minecraft:yellow_concrete
fill 115 216 310 115 217 310 minecraft:green_concrete
fill 116 216 275 116 217 275 minecraft:white_concrete
fill 116 216 290 118 216 290 minecraft:yellow_concrete
fill 116 216 317 117 217 317 minecraft:white_concrete
fill 117 216 295 118 216 295 minecraft:yellow_concrete
fill 118 216 275 119 217 275 minecraft:red_concrete
fill 118 216 294 119 216 294 minecraft:yellow_concrete
fill 118 216 317 119 217 317 minecraft:red_concrete
fill 119 216 292 119 217 293 minecraft:yellow_concrete
fill 120 216 275 121 217 275 minecraft:white_concrete
fill 120 216 279 121 216 282 minecraft:yellow_concrete
fill 120 216 317 120 217 317 minecraft:white_concrete
fill 121 216 277 123 216 278 minecraft:yellow_concrete
fill 121 216 283 127 216 283 minecraft:yellow_concrete
fill 122 216 275 123 217 275 minecraft:red_concrete
fill 122 216 279 122 218 279 minecraft:yellow_concrete
fill 122 216 282 122 218 282 minecraft:yellow_concrete
fill 122 216 284 126 216 284 minecraft:yellow_concrete
fill 122 216 317 123 217 317 minecraft:red_concrete
fill 123 216 276 125 216 276 minecraft:yellow_concrete
fill 124 216 275 124 217 275 minecraft:white_concrete
fill 124 216 277 127 216 277 minecraft:yellow_concrete
fill 124 216 317 125 217 317 minecraft:white_concrete
fill 126 216 275 127 217 275 minecraft:red_concrete
fill 126 216 278 128 216 278 minecraft:yellow_concrete
fill 126 216 282 128 216 282 minecraft:yellow_concrete
fill 126 216 317 127 217 317 minecraft:red_concrete
fill 127 216 279 128 216 281 minecraft:yellow_concrete
fill 128 216 275 129 217 275 minecraft:white_concrete
fill 128 216 317 128 217 317 minecraft:white_concrete
fill 130 216 275 131 217 275 minecraft:red_concrete
fill 130 216 317 131 217 317 minecraft:red_concrete
fill 132 216 275 132 217 275 minecraft:white_concrete
fill 132 216 317 133 217 317 minecraft:white_concrete
fill 134 216 275 135 217 275 minecraft:red_concrete
fill 134 216 317 135 217 317 minecraft:red_concrete
fill 136 216 276 136 217 276 minecraft:red_concrete
fill 136 216 277 136 217 278 minecraft:white_concrete
fill 136 216 279 136 217 279 minecraft:red_concrete
fill 136 216 281 136 217 282 minecraft:white_concrete
fill 136 216 283 136 217 284 minecraft:red_concrete
fill 136 216 285 136 217 286 minecraft:white_concrete
fill 136 216 287 136 217 287 minecraft:red_concrete
fill 136 216 289 136 217 290 minecraft:white_concrete
fill 136 216 291 136 217 292 minecraft:red_concrete
fill 136 216 293 136 217 294 minecraft:white_concrete
fill 136 216 295 136 217 295 minecraft:red_concrete
fill 136 216 297 136 217 298 minecraft:white_concrete
fill 136 216 299 136 217 300 minecraft:red_concrete
fill 136 216 301 136 217 302 minecraft:white_concrete
fill 136 216 303 136 217 303 minecraft:red_concrete
fill 136 216 305 136 217 306 minecraft:white_concrete
fill 136 216 307 136 217 308 minecraft:red_concrete
fill 136 216 309 136 217 310 minecraft:white_concrete
fill 136 216 311 136 217 311 minecraft:red_concrete
fill 136 216 313 136 217 314 minecraft:white_concrete
fill 136 216 315 136 217 316 minecraft:red_concrete
fill 136 216 317 136 217 317 minecraft:white_concrete
fill 109 217 277 109 217 279 minecraft:red_terracotta
fill 110 217 276 111 217 276 minecraft:red_terracotta
fill 110 217 280 112 217 280 minecraft:red_terracotta
fill 113 217 277 113 218 279 minecraft:red_terracotta
fill 115 217 291 115 217 293 minecraft:yellow_concrete
fill 116 217 291 118 218 291 minecraft:yellow_concrete
setblock 117 217 295 minecraft:yellow_concrete
fill 118 217 294 118 218 294 minecraft:yellow_concrete
fill 121 217 279 121 217 282 minecraft:yellow_concrete
fill 122 217 278 123 218 278 minecraft:yellow_concrete
fill 122 217 283 126 217 283 minecraft:yellow_concrete
fill 123 217 277 126 217 277 minecraft:yellow_concrete
setblock 124 217 284 minecraft:yellow_concrete
fill 126 217 278 127 217 278 minecraft:yellow_concrete
fill 126 217 282 127 217 282 minecraft:yellow_concrete
fill 127 217 279 127 217 281 minecraft:yellow_concrete
fill 131 217 297 131 217 299 minecraft:red_terracotta
setblock 131 217 306 minecraft:red_terracotta
setblock 131 217 308 minecraft:red_terracotta
fill 132 217 297 133 217 297 minecraft:red_terracotta
fill 132 217 299 133 217 299 minecraft:red_terracotta
setblock 133 217 298 minecraft:red_terracotta
setblock 133 217 306 minecraft:red_terracotta
setblock 133 217 308 minecraft:red_terracotta
fill 94 218 275 94 219 276 minecraft:white_concrete
fill 94 218 277 94 219 278 minecraft:red_concrete
fill 94 218 279 94 219 279 minecraft:white_concrete
fill 94 218 281 94 219 282 minecraft:red_concrete
fill 94 218 283 94 219 284 minecraft:white_concrete
fill 94 218 285 94 219 286 minecraft:red_concrete
fill 94 218 287 94 219 287 minecraft:white_concrete
fill 94 218 289 94 219 290 minecraft:red_concrete
fill 94 218 291 94 219 292 minecraft:white_concrete
fill 94 218 293 94 219 294 minecraft:red_concrete
fill 94 218 295 94 219 295 minecraft:white_concrete
fill 94 218 297 94 219 298 minecraft:red_concrete
fill 94 218 299 94 219 300 minecraft:white_concrete
fill 94 218 301 94 219 302 minecraft:red_concrete
fill 94 218 303 94 219 303 minecraft:white_concrete
fill 94 218 305 94 219 306 minecraft:red_concrete
fill 94 218 307 94 219 308 minecraft:white_concrete
fill 94 218 309 94 219 310 minecraft:red_concrete
fill 94 218 311 94 219 311 minecraft:white_concrete
fill 94 218 313 94 219 314 minecraft:red_concrete
fill 94 218 315 94 219 316 minecraft:white_concrete
fill 95 218 275 95 219 275 minecraft:white_concrete
fill 95 218 317 95 219 317 minecraft:white_concrete
fill 96 218 275 97 219 275 minecraft:red_concrete
fill 96 218 317 96 219 317 minecraft:red_concrete
setblock 97 218 278 minecraft:light[level=15]
setblock 97 218 285 minecraft:light[level=12]
setblock 97 218 286 minecraft:light[level=15]
setblock 97 218 292 minecraft:light[level=12]
setblock 97 218 294 minecraft:light[level=15]
setblock 97 218 299 minecraft:light[level=12]
setblock 97 218 302 minecraft:light[level=15]
setblock 97 218 306 minecraft:light[level=12]
setblock 97 218 310 minecraft:light[level=15]
setblock 97 218 313 minecraft:light[level=12]
fill 98 218 275 99 219 275 minecraft:white_concrete
fill 98 218 317 99 219 317 minecraft:white_concrete
fill 100 218 275 100 219 275 minecraft:red_concrete
fill 100 218 317 101 219 317 minecraft:red_concrete
fill 102 218 275 103 219 275 minecraft:white_concrete
fill 102 218 317 103 219 317 minecraft:white_concrete
fill 104 218 275 105 219 275 minecraft:red_concrete
setblock 104 218 278 minecraft:light[level=12]
setblock 104 218 285 minecraft:light[level=12]
setblock 104 218 292 minecraft:light[level=12]
setblock 104 218 299 minecraft:light[level=12]
setblock 104 218 306 minecraft:light[level=12]
setblock 104 218 313 minecraft:light[level=12]
fill 104 218 317 104 219 317 minecraft:red_concrete
setblock 105 218 278 minecraft:light[level=15]
setblock 105 218 286 minecraft:light[level=15]
setblock 105 218 294 minecraft:light[level=15]
setblock 105 218 302 minecraft:light[level=15]
setblock 105 218 310 minecraft:light[level=15]
fill 106 218 275 107 219 275 minecraft:white_concrete
fill 106 218 317 107 219 317 minecraft:white_concrete
fill 108 218 275 108 219 275 minecraft:red_concrete
fill 108 218 317 109 219 317 minecraft:red_concrete
fill 110 218 275 111 219 275 minecraft:white_concrete
fill 110 218 317 111 219 317 minecraft:white_concrete
fill 111 218 277 111 218 279 minecraft:red_terracotta
setblock 111 218 285 minecraft:light[level=12]
setblock 111 218 292 minecraft:light[level=12]
setblock 111 218 299 minecraft:light[level=12]
setblock 111 218 306 minecraft:light[level=12]
setblock 111 218 313 minecraft:light[level=12]
fill 112 218 275 113 219 275 minecraft:red_concrete
setblock 112 218 277 minecraft:red_terracotta
setblock 112 218 279 minecraft:red_terracotta
fill 112 218 317 112 219 317 minecraft:red_concrete
setblock 113 218 286 minecraft:light[level=15]
setblock 113 218 294 minecraft:light[level=15]
setblock 113 218 302 minecraft:light[level=15]
setblock 113 218 310 minecraft:light[level=15]
fill 114 218 275 115 219 275 minecraft:white_concrete
fill 114 218 317 115 219 317 minecraft:white_concrete
fill 115 218 292 115 218 293 minecraft:yellow_concrete
fill 116 218 275 116 219 275 minecraft:red_concrete
fill 116 218 317 117 219 317 minecraft:red_concrete
fill 118 218 275 119 219 275 minecraft:white_concrete
setblock 118 218 278 minecraft:light[level=12]
setblock 118 218 285 minecraft:light[level=12]
setblock 118 218 299 minecraft:light[level=12]
setblock 118 218 306 minecraft:light[level=12]
setblock 118 218 313 minecraft:light[level=12]
fill 118 218 317 119 219 317 minecraft:white_concrete
fill 120 218 275 121 219 275 minecraft:red_concrete
fill 120 218 317 120 219 317 minecraft:red_concrete
setblock 121 218 278 minecraft:light[level=15]
setblock 121 218 286 minecraft:light[level=15]
setblock 121 218 294 minecraft:light[level=15]
setblock 121 218 302 minecraft:light[level=15]
setblock 121 218 310 minecraft:light[level=15]
fill 122 218 275 123 219 275 minecraft:white_concrete
fill 122 218 317 123 219 317 minecraft:white_concrete
fill 123 218 283 125 218 283 minecraft:yellow_concrete
fill 124 218 275 124 219 275 minecraft:red_concrete
fill 124 218 317 125 219 317 minecraft:red_concrete
setblock 125 218 285 minecraft:light[level=12]
setblock 125 218 292 minecraft:light[level=12]
setblock 125 218 299 minecraft:light[level=12]
setblock 125 218 306 minecraft:light[level=12]
setblock 125 218 313 minecraft:light[level=12]
fill 126 218 275 127 219 275 minecraft:white_concrete
setblock 126 218 278 minecraft:yellow_concrete
setblock 126 218 282 minecraft:yellow_concrete
fill 126 218 317 127 219 317 minecraft:white_concrete
fill 127 218 280 127 218 281 minecraft:yellow_concrete
fill 128 218 275 129 219 275 minecraft:red_concrete
fill 128 218 317 128 219 317 minecraft:red_concrete
setblock 129 218 278 minecraft:light[level=15]
setblock 129 218 286 minecraft:light[level=15]
setblock 129 218 294 minecraft:light[level=15]
setblock 129 218 302 minecraft:light[level=15]
setblock 129 218 310 minecraft:light[level=15]
fill 130 218 275 131 219 275 minecraft:white_concrete
fill 130 218 317 131 219 317 minecraft:white_concrete
fill 132 218 275 132 219 275 minecraft:red_concrete
setblock 132 218 278 minecraft:light[level=12]
setblock 132 218 285 minecraft:light[level=12]
setblock 132 218 292 minecraft:light[level=12]
setblock 132 218 299 minecraft:light[level=12]
setblock 132 218 313 minecraft:light[level=12]
fill 132 218 317 133 219 317 minecraft:red_concrete
fill 134 218 275 135 219 275 minecraft:white_concrete
fill 134 218 317 135 219 317 minecraft:white_concrete
fill 136 218 276 136 219 276 minecraft:white_concrete
fill 136 218 277 136 219 278 minecraft:red_concrete
fill 136 218 279 136 219 279 minecraft:white_concrete
fill 136 218 281 136 219 282 minecraft:red_concrete
fill 136 218 283 136 219 284 minecraft:white_concrete
fill 136 218 285 136 219 286 minecraft:red_concrete
fill 136 218 287 136 219 287 minecraft:white_concrete
fill 136 218 289 136 219 290 minecraft:red_concrete
fill 136 218 291 136 219 292 minecraft:white_concrete
fill 136 218 293 136 219 294 minecraft:red_concrete
fill 136 218 295 136 219 295 minecraft:white_concrete
fill 136 218 297 136 219 298 minecraft:red_concrete
fill 136 218 299 136 219 300 minecraft:white_concrete
fill 136 218 301 136 219 302 minecraft:red_concrete
fill 136 218 303 136 219 303 minecraft:white_concrete
fill 136 218 305 136 219 306 minecraft:red_concrete
fill 136 218 307 136 219 308 minecraft:white_concrete
fill 136 218 309 136 219 310 minecraft:red_concrete
fill 136 218 311 136 219 311 minecraft:white_concrete
fill 136 218 313 136 219 314 minecraft:red_concrete
fill 136 218 315 136 219 316 minecraft:white_concrete
fill 136 218 317 136 219 317 minecraft:red_concrete
fill 111 219 277 111 219 279 minecraft:iron_block
setblock 112 219 277 minecraft:iron_block
setblock 112 219 279 minecraft:iron_block
fill 94 220 275 94 221 276 minecraft:red_concrete
fill 94 220 277 94 221 278 minecraft:white_concrete
fill 94 220 279 94 221 280 minecraft:red_concrete
fill 94 220 281 94 221 282 minecraft:white_concrete
fill 94 220 283 94 221 284 minecraft:red_concrete
fill 94 220 285 94 221 286 minecraft:white_concrete
fill 94 220 287 94 221 288 minecraft:red_concrete
fill 94 220 289 94 221 290 minecraft:white_concrete
fill 94 220 291 94 221 292 minecraft:red_concrete
fill 94 220 293 94 221 294 minecraft:white_concrete
fill 94 220 295 94 221 296 minecraft:red_concrete
fill 94 220 297 94 221 298 minecraft:white_concrete
fill 94 220 299 94 221 300 minecraft:red_concrete
fill 94 220 301 94 221 302 minecraft:white_concrete
fill 94 220 303 94 221 304 minecraft:red_concrete
fill 94 220 305 94 221 306 minecraft:white_concrete
fill 94 220 307 94 221 308 minecraft:red_concrete
fill 94 220 309 94 221 310 minecraft:white_concrete
fill 94 220 311 94 221 312 minecraft:red_concrete
fill 94 220 313 94 221 314 minecraft:white_concrete
fill 94 220 315 94 221 316 minecraft:red_concrete
fill 95 220 275 95 221 275 minecraft:red_concrete
fill 95 220 317 95 221 317 minecraft:red_concrete
fill 96 220 275 97 221 275 minecraft:white_concrete
fill 96 220 317 97 221 317 minecraft:white_concrete
fill 98 220 275 99 221 275 minecraft:red_concrete
fill 98 220 317 99 221 317 minecraft:red_concrete
fill 100 220 275 101 221 275 minecraft:white_concrete
fill 100 220 317 101 221 317 minecraft:white_concrete
fill 102 220 275 103 221 275 minecraft:red_concrete
fill 102 220 317 103 221 317 minecraft:red_concrete
fill 104 220 275 105 221 275 minecraft:white_concrete
fill 104 220 317 105 221 317 minecraft:white_concrete
fill 106 220 275 107 221 275 minecraft:red_concrete
fill 106 220 317 107 221 317 minecraft:red_concrete
fill 108 220 275 109 221 275 minecraft:white_concrete
fill 108 220 317 109 221 317 minecraft:white_concrete
fill 110 220 275 111 221 275 minecraft:red_concrete
fill 110 220 317 111 221 317 minecraft:red_concrete
fill 112 220 275 113 221 275 minecraft:white_concrete
fill 112 220 317 113 221 317 minecraft:white_concrete
fill 114 220 275 115 221 275 minecraft:red_concrete
fill 114 220 317 115 221 317 minecraft:red_concrete
fill 116 220 275 117 221 275 minecraft:white_concrete
fill 116 220 317 117 221 317 minecraft:white_concrete
fill 118 220 275 119 221 275 minecraft:red_concrete
fill 118 220 317 119 221 317 minecraft:red_concrete
fill 120 220 275 121 221 275 minecraft:white_concrete
fill 120 220 317 121 221 317 minecraft:white_concrete
fill 122 220 275 123 221 275 minecraft:red_concrete
fill 122 220 317 123 221 317 minecraft:red_concrete
fill 124 220 275 125 221 275 minecraft:white_concrete
fill 124 220 317 125 221 317 minecraft:white_concrete
fill 126 220 275 127 221 275 minecraft:red_concrete
fill 126 220 317 127 221 317 minecraft:red_concrete
fill 128 220 275 129 221 275 minecraft:white_concrete
fill 128 220 317 129 221 317 minecraft:white_concrete
fill 130 220 275 131 221 275 minecraft:red_concrete
fill 130 220 317 131 221 317 minecraft:red_concrete
fill 132 220 275 133 221 275 minecraft:white_concrete
fill 132 220 317 133 221 317 minecraft:white_concrete
fill 134 220 275 135 221 275 minecraft:red_concrete
fill 134 220 317 135 221 317 minecraft:red_concrete
fill 136 220 276 136 221 276 minecraft:red_concrete
fill 136 220 277 136 221 278 minecraft:white_concrete
fill 136 220 279 136 221 280 minecraft:red_concrete
fill 136 220 281 136 221 282 minecraft:white_concrete
fill 136 220 283 136 221 284 minecraft:red_concrete
fill 136 220 285 136 221 286 minecraft:white_concrete
fill 136 220 287 136 221 288 minecraft:red_concrete
fill 136 220 289 136 221 290 minecraft:white_concrete
fill 136 220 291 136 221 292 minecraft:red_concrete
fill 136 220 293 136 221 294 minecraft:white_concrete
fill 136 220 295 136 221 296 minecraft:red_concrete
fill 136 220 297 136 221 298 minecraft:white_concrete
fill 136 220 299 136 221 300 minecraft:red_concrete
fill 136 220 301 136 221 302 minecraft:white_concrete
fill 136 220 303 136 221 304 minecraft:red_concrete
fill 136 220 305 136 221 306 minecraft:white_concrete
fill 136 220 307 136 221 308 minecraft:red_concrete
fill 136 220 309 136 221 310 minecraft:white_concrete
fill 136 220 311 136 221 312 minecraft:red_concrete
fill 136 220 313 136 221 314 minecraft:white_concrete
fill 136 220 315 136 221 316 minecraft:red_concrete
fill 136 220 317 136 221 317 minecraft:white_concrete
fill 94 222 275 94 223 276 minecraft:white_concrete
fill 94 222 277 94 223 278 minecraft:red_concrete
fill 94 222 279 94 223 280 minecraft:white_concrete
fill 94 222 281 94 223 282 minecraft:red_concrete
fill 94 222 283 94 223 284 minecraft:white_concrete
fill 94 222 285 94 223 286 minecraft:red_concrete
fill 94 222 287 94 223 288 minecraft:white_concrete
fill 94 222 289 94 223 290 minecraft:red_concrete
fill 94 222 291 94 223 292 minecraft:white_concrete
fill 94 222 293 94 223 294 minecraft:red_concrete
fill 94 222 295 94 223 296 minecraft:white_concrete
fill 94 222 297 94 223 298 minecraft:red_concrete
fill 94 222 299 94 223 300 minecraft:white_concrete
fill 94 222 301 94 223 302 minecraft:red_concrete
fill 94 222 303 94 223 304 minecraft:white_concrete
fill 94 222 305 94 223 306 minecraft:red_concrete
fill 94 222 307 94 223 308 minecraft:white_concrete
fill 94 222 309 94 223 310 minecraft:red_concrete
fill 94 222 311 94 223 312 minecraft:white_concrete
fill 94 222 313 94 223 314 minecraft:red_concrete
fill 94 222 315 94 223 316 minecraft:white_concrete
fill 95 222 275 95 223 275 minecraft:white_concrete
fill 95 222 317 95 223 317 minecraft:white_concrete
fill 96 222 275 97 223 275 minecraft:red_concrete
fill 96 222 317 97 223 317 minecraft:red_concrete
fill 98 222 275 99 223 275 minecraft:white_concrete
fill 98 222 317 99 223 317 minecraft:white_concrete
fill 100 222 275 101 223 275 minecraft:red_concrete
setblock 100 222 312 minecraft:iron_block
fill 100 222 317 101 223 317 minecraft:red_concrete
setblock 101 222 311 minecraft:iron_block
fill 101 222 312 103 222 312 minecraft:black_concrete
setblock 101 222 313 minecraft:iron_block
fill 102 222 275 103 223 275 minecraft:white_concrete
setblock 102 222 310 minecraft:iron_block
setblock 102 222 311 minecraft:black_concrete
setblock 102 222 313 minecraft:black_concrete
setblock 102 222 314 minecraft:iron_block
fill 102 222 317 103 223 317 minecraft:white_concrete
setblock 103 222 311 minecraft:iron_block
setblock 103 222 313 minecraft:iron_block
fill 104 222 275 105 223 275 minecraft:red_concrete
setblock 104 222 312 minecraft:iron_block
fill 104 222 317 105 223 317 minecraft:red_concrete
fill 106 222 275 107 223 275 minecraft:white_concrete
fill 106 222 317 107 223 317 minecraft:white_concrete
fill 108 222 275 109 223 275 minecraft:red_concrete
fill 108 222 317 109 223 317 minecraft:red_concrete
fill 110 222 275 111 223 275 minecraft:white_concrete
fill 110 222 317 111 223 317 minecraft:white_concrete
fill 112 222 275 113 223 275 minecraft:red_concrete
fill 112 222 317 113 223 317 minecraft:red_concrete
fill 114 222 275 115 223 275 minecraft:white_concrete
fill 114 222 317 115 223 317 minecraft:white_concrete
fill 116 222 275 117 223 275 minecraft:red_concrete
fill 116 222 317 117 223 317 minecraft:red_concrete
fill 118 222 275 119 223 275 minecraft:white_concrete
fill 118 222 317 119 223 317 minecraft:white_concrete
fill 120 222 275 121 223 275 minecraft:red_concrete
fill 120 222 317 121 223 317 minecraft:red_concrete
fill 122 222 275 123 223 275 minecraft:white_concrete
fill 122 222 317 123 223 317 minecraft:white_concrete
fill 124 222 275 125 223 275 minecraft:red_concrete
fill 124 222 317 125 223 317 minecraft:red_concrete
fill 126 222 275 127 223 275 minecraft:white_concrete
fill 126 222 317 127 223 317 minecraft:white_concrete
fill 128 222 275 129 223 275 minecraft:red_concrete
fill 128 222 317 129 223 317 minecraft:red_concrete
fill 130 222 275 131 223 275 minecraft:white_concrete
fill 130 222 317 131 223 317 minecraft:white_concrete
fill 132 222 275 133 223 275 minecraft:red_concrete
fill 132 222 317 133 223 317 minecraft:red_concrete
fill 134 222 275 135 223 275 minecraft:white_concrete
fill 134 222 317 135 223 317 minecraft:white_concrete
fill 136 222 276 136 223 276 minecraft:white_concrete
fill 136 222 277 136 223 278 minecraft:red_concrete
fill 136 222 279 136 223 280 minecraft:white_concrete
fill 136 222 281 136 223 282 minecraft:red_concrete
fill 136 222 283 136 223 284 minecraft:white_concrete
fill 136 222 285 136 223 286 minecraft:red_concrete
fill 136 222 287 136 223 288 minecraft:white_concrete
fill 136 222 289 136 223 290 minecraft:red_concrete
fill 136 222 291 136 223 292 minecraft:white_concrete
fill 136 222 293 136 223 294 minecraft:red_concrete
fill 136 222 295 136 223 296 minecraft:white_concrete
fill 136 222 297 136 223 298 minecraft:red_concrete
fill 136 222 299 136 223 300 minecraft:white_concrete
fill 136 222 301 136 223 302 minecraft:red_concrete
fill 136 222 303 136 223 304 minecraft:white_concrete
fill 136 222 305 136 223 306 minecraft:red_concrete
fill 136 222 307 136 223 308 minecraft:white_concrete
fill 136 222 309 136 223 310 minecraft:red_concrete
fill 136 222 311 136 223 312 minecraft:white_concrete
fill 136 222 313 136 223 314 minecraft:red_concrete
fill 136 222 315 136 223 316 minecraft:white_concrete
fill 136 222 317 136 223 317 minecraft:red_concrete
fill 94 224 275 94 225 276 minecraft:red_concrete
fill 94 224 277 94 225 278 minecraft:white_concrete
fill 94 224 279 94 225 280 minecraft:red_concrete
fill 94 224 281 94 225 282 minecraft:white_concrete
fill 94 224 283 94 225 284 minecraft:red_concrete
fill 94 224 285 94 225 286 minecraft:white_concrete
fill 94 224 287 94 225 288 minecraft:red_concrete
fill 94 224 289 94 225 290 minecraft:white_concrete
fill 94 224 291 94 225 292 minecraft:red_concrete
fill 94 224 293 94 225 294 minecraft:white_concrete
fill 94 224 295 94 225 296 minecraft:red_concrete
fill 94 224 297 94 225 298 minecraft:white_concrete
fill 94 224 299 94 225 300 minecraft:red_concrete
fill 94 224 301 94 225 302 minecraft:white_concrete
fill 94 224 303 94 225 304 minecraft:red_concrete
fill 94 224 305 94 225 306 minecraft:white_concrete
fill 94 224 307 94 225 308 minecraft:red_concrete
fill 94 224 309 94 225 310 minecraft:white_concrete
fill 94 224 311 94 225 312 minecraft:red_concrete
fill 94 224 313 94 225 314 minecraft:white_concrete
fill 94 224 315 94 225 316 minecraft:red_concrete
fill 95 224 275 95 225 275 minecraft:red_concrete
fill 95 224 317 95 225 317 minecraft:red_concrete
fill 96 224 275 97 225 275 minecraft:white_concrete
fill 96 224 317 97 225 317 minecraft:white_concrete
setblock 97 224 278 minecraft:light[level=12]
setblock 97 224 285 minecraft:light[level=12]
setblock 97 224 292 minecraft:light[level=12]
setblock 97 224 299 minecraft:light[level=12]
setblock 97 224 306 minecraft:light[level=12]
setblock 97 224 313 minecraft:light[level=12]
fill 98 224 275 99 225 275 minecraft:red_concrete
fill 98 224 317 99 225 317 minecraft:red_concrete
fill 100 224 275 101 225 275 minecraft:white_concrete
fill 100 224 317 101 225 317 minecraft:white_concrete
fill 102 224 275 103 225 275 minecraft:red_concrete
fill 102 224 317 103 225 317 minecraft:red_concrete
fill 104 224 275 105 225 275 minecraft:white_concrete
setblock 104 224 278 minecraft:light[level=12]
setblock 104 224 285 minecraft:light[level=12]
setblock 104 224 292 minecraft:light[level=12]
setblock 104 224 299 minecraft:light[level=12]
setblock 104 224 306 minecraft:light[level=12]
setblock 104 224 313 minecraft:light[level=12]
fill 104 224 317 105 225 317 minecraft:white_concrete
fill 106 224 275 107 225 275 minecraft:red_concrete
fill 106 224 317 107 225 317 minecraft:red_concrete
fill 108 224 275 109 225 275 minecraft:white_concrete
fill 108 224 317 109 225 317 minecraft:white_concrete
fill 110 224 275 111 225 275 minecraft:red_concrete
fill 110 224 317 111 225 317 minecraft:red_concrete
setblock 111 224 278 minecraft:light[level=12]
setblock 111 224 285 minecraft:light[level=12]
setblock 111 224 292 minecraft:light[level=12]
setblock 111 224 299 minecraft:light[level=12]
setblock 111 224 306 minecraft:light[level=12]
setblock 111 224 313 minecraft:light[level=12]
fill 112 224 275 113 225 275 minecraft:white_concrete
fill 112 224 317 113 225 317 minecraft:white_concrete
fill 114 224 275 115 225 275 minecraft:red_concrete
fill 114 224 317 115 225 317 minecraft:red_concrete
fill 116 224 275 117 225 275 minecraft:white_concrete
fill 116 224 317 117 225 317 minecraft:white_concrete
fill 118 224 275 119 225 275 minecraft:red_concrete
setblock 118 224 278 minecraft:light[level=12]
setblock 118 224 285 minecraft:light[level=12]
setblock 118 224 292 minecraft:light[level=12]
setblock 118 224 299 minecraft:light[level=12]
setblock 118 224 306 minecraft:light[level=12]
setblock 118 224 313 minecraft:light[level=12]
fill 118 224 317 119 225 317 minecraft:red_concrete
fill 120 224 275 121 225 275 minecraft:white_concrete
fill 120 224 317 121 225 317 minecraft:white_concrete
fill 122 224 275 123 225 275 minecraft:red_concrete
fill 122 224 317 123 225 317 minecraft:red_concrete
fill 124 224 275 125 225 275 minecraft:white_concrete
fill 124 224 317 125 225 317 minecraft:white_concrete
setblock 125 224 278 minecraft:light[level=12]
setblock 125 224 285 minecraft:light[level=12]
setblock 125 224 292 minecraft:light[level=12]
setblock 125 224 299 minecraft:light[level=12]
setblock 125 224 306 minecraft:light[level=12]
setblock 125 224 313 minecraft:light[level=12]
fill 126 224 275 127 225 275 minecraft:red_concrete
fill 126 224 317 127 225 317 minecraft:red_concrete
fill 128 224 275 129 225 275 minecraft:white_concrete
fill 128 224 317 129 225 317 minecraft:white_concrete
fill 130 224 275 131 225 275 minecraft:red_concrete
fill 130 224 317 131 225 317 minecraft:red_concrete
fill 132 224 275 133 225 275 minecraft:white_concrete
setblock 132 224 278 minecraft:light[level=12]
setblock 132 224 285 minecraft:light[level=12]
setblock 132 224 292 minecraft:light[level=12]
setblock 132 224 299 minecraft:light[level=12]
setblock 132 224 306 minecraft:light[level=12]
setblock 132 224 313 minecraft:light[level=12]
fill 132 224 317 133 225 317 minecraft:white_concrete
fill 134 224 275 135 225 275 minecraft:red_concrete
fill 134 224 317 135 225 317 minecraft:red_concrete
fill 136 224 276 136 225 276 minecraft:red_concrete
fill 136 224 277 136 225 278 minecraft:white_concrete
fill 136 224 279 136 225 280 minecraft:red_concrete
fill 136 224 281 136 225 282 minecraft:white_concrete
fill 136 224 283 136 225 284 minecraft:red_concrete
fill 136 224 285 136 225 286 minecraft:white_concrete
fill 136 224 287 136 225 288 minecraft:red_concrete
fill 136 224 289 136 225 290 minecraft:white_concrete
fill 136 224 291 136 225 292 minecraft:red_concrete
fill 136 224 293 136 225 294 minecraft:white_concrete
fill 136 224 295 136 225 296 minecraft:red_concrete
fill 136 224 297 136 225 298 minecraft:white_concrete
fill 136 224 299 136 225 300 minecraft:red_concrete
fill 136 224 301 136 225 302 minecraft:white_concrete
fill 136 224 303 136 225 304 minecraft:red_concrete
fill 136 224 305 136 225 306 minecraft:white_concrete
fill 136 224 307 136 225 308 minecraft:red_concrete
fill 136 224 309 136 225 310 minecraft:white_concrete
fill 136 224 311 136 225 312 minecraft:red_concrete
fill 136 224 313 136 225 314 minecraft:white_concrete
fill 136 224 315 136 225 316 minecraft:red_concrete
fill 136 224 317 136 225 317 minecraft:white_concrete
fill 102 225 296 108 225 296 minecraft:iron_block
fill 103 225 292 103 226 292 minecraft:iron_block
fill 103 225 294 109 225 294 minecraft:iron_block
fill 103 225 297 109 225 297 minecraft:iron_block
fill 103 225 299 103 226 299 minecraft:iron_block
fill 104 225 291 104 226 291 minecraft:iron_block
fill 104 225 293 111 225 293 minecraft:iron_block
fill 104 225 300 118 225 300 minecraft:iron_block
fill 104 225 302 104 226 302 minecraft:iron_block
fill 105 225 290 105 226 290 minecraft:iron_block
fill 105 225 295 109 225 295 minecraft:iron_block
fill 105 225 298 109 225 299 minecraft:iron_block
fill 105 225 301 118 226 301 minecraft:iron_block
fill 106 225 288 106 226 288 minecraft:iron_block
fill 106 225 291 119 225 292 minecraft:iron_block
fill 106 225 303 106 226 303 minecraft:iron_block
fill 107 225 289 115 226 290 minecraft:iron_block
fill 107 225 302 117 226 302 minecraft:iron_block
fill 107 225 304 107 226 304 minecraft:iron_block
fill 108 225 288 108 226 288 minecraft:iron_block
fill 108 225 305 108 226 305 minecraft:iron_block
fill 109 225 287 109 226 287 minecraft:iron_block
fill 109 225 303 110 226 304 minecraft:iron_block
fill 110 225 299 111 225 299 minecraft:iron_block
fill 110 225 305 110 226 305 minecraft:iron_block
fill 111 225 287 112 226 288 minecraft:iron_block
fill 111 225 303 117 226 303 minecraft:iron_block
fill 112 225 286 112 226 286 minecraft:iron_block
fill 112 225 304 112 226 306 minecraft:iron_block
fill 113 225 293 119 225 293 minecraft:iron_block
fill 113 225 299 120 225 299 minecraft:iron_block
fill 113 225 304 113 226 305 minecraft:iron_block
fill 114 225 287 114 226 288 minecraft:iron_block
fill 115 225 288 115 226 288 minecraft:iron_block
fill 115 225 294 119 225 295 minecraft:iron_block
fill 115 225 297 119 225 298 minecraft:iron_block
fill 115 225 305 115 226 305 minecraft:iron_block
fill 116 225 287 116 226 287 minecraft:iron_block
fill 116 225 290 117 226 290 minecraft:iron_block
fill 116 225 296 122 225 296 minecraft:iron_block
fill 116 225 304 116 226 304 minecraft:iron_block
fill 117 225 288 117 226 288 minecraft:iron_block
fill 118 225 289 118 226 289 minecraft:iron_block
fill 118 225 304 118 226 304 minecraft:iron_block
fill 119 225 302 119 226 302 minecraft:iron_block
fill 120 225 290 120 226 290 minecraft:iron_block
fill 120 225 292 120 226 292 minecraft:iron_block
fill 120 225 295 121 226 295 minecraft:iron_block
fill 120 225 298 121 226 298 minecraft:iron_block
fill 120 225 301 120 226 301 minecraft:iron_block
fill 121 225 293 121 226 293 minecraft:iron_block
fill 121 225 300 121 226 300 minecraft:iron_block
fill 94 226 275 94 227 276 minecraft:white_concrete
fill 94 226 277 94 227 278 minecraft:red_concrete
fill 94 226 279 94 227 280 minecraft:white_concrete
fill 94 226 281 94 227 282 minecraft:red_concrete
fill 94 226 283 94 227 284 minecraft:white_concrete
fill 94 226 285 94 227 286 minecraft:red_concrete
fill 94 226 287 94 227 288 minecraft:white_concrete
fill 94 226 289 94 227 290 minecraft:red_concrete
fill 94 226 291 94 227 292 minecraft:white_concrete
fill 94 226 293 94 227 294 minecraft:red_concrete
fill 94 226 295 94 227 296 minecraft:white_concrete
fill 94 226 297 94 227 298 minecraft:red_concrete
fill 94 226 299 94 227 300 minecraft:white_concrete
fill 94 226 301 94 227 302 minecraft:red_concrete
fill 94 226 303 94 227 304 minecraft:white_concrete
fill 94 226 305 94 227 306 minecraft:red_concrete
fill 94 226 307 94 227 308 minecraft:white_concrete
fill 94 226 309 94 227 310 minecraft:red_concrete
fill 94 226 311 94 227 312 minecraft:white_concrete
fill 94 226 313 94 227 314 minecraft:red_concrete
fill 94 226 315 94 227 316 minecraft:white_concrete
fill 95 226 275 95 227 275 minecraft:white_concrete
fill 95 226 276 95 226 277 minecraft:white_wool
setblock 95 226 278 minecraft:white_concrete
fill 95 226 279 95 226 281 minecraft:white_wool
setblock 95 226 282 minecraft:white_concrete
fill 95 226 283 95 226 285 minecraft:white_wool
setblock 95 226 286 minecraft:white_concrete
fill 95 226 287 95 226 289 minecraft:white_wool
setblock 95 226 290 minecraft:white_concrete
fill 95 226 291 95 226 293 minecraft:white_wool
setblock 95 226 294 minecraft:white_concrete
fill 95 226 295 95 226 297 minecraft:white_wool
setblock 95 226 298 minecraft:white_concrete
fill 95 226 299 95 226 301 minecraft:white_wool
setblock 95 226 302 minecraft:white_concrete
fill 95 226 303 95 226 305 minecraft:white_wool
setblock 95 226 306 minecraft:white_concrete
fill 95 226 307 95 226 309 minecraft:white_wool
setblock 95 226 310 minecraft:white_concrete
fill 95 226 311 95 226 313 minecraft:white_wool
setblock 95 226 314 minecraft:white_concrete
fill 95 226 315 96 226 316 minecraft:white_wool
fill 95 226 317 95 227 317 minecraft:white_concrete
fill 96 226 275 97 227 275 minecraft:red_concrete
setblock 96 226 276 minecraft:white_wool
setblock 96 226 277 minecraft:white_concrete
fill 96 226 278 96 226 280 minecraft:white_wool
setblock 96 226 281 minecraft:white_concrete
fill 96 226 282 96 226 284 minecraft:white_wool
setblock 96 226 285 minecraft:white_concrete
fill 96 226 286 96 226 288 minecraft:white_wool
setblock 96 226 289 minecraft:white_concrete
fill 96 226 290 96 226 292 minecraft:white_wool
setblock 96 226 293 minecraft:white_concrete
fill 96 226 294 96 226 296 minecraft:white_wool
setblock 96 226 297 minecraft:white_concrete
fill 96 226 298 96 226 300 minecraft:white_wool
setblock 96 226 301 minecraft:white_concrete
fill 96 226 302 96 226 304 minecraft:white_wool
setblock 96 226 305 minecraft:white_concrete
fill 96 226 306 96 226 308 minecraft:white_wool
setblock 96 226 309 minecraft:white_concrete
fill 96 226 310 96 226 312 minecraft:white_wool
setblock 96 226 313 minecraft:white_concrete
fill 96 226 314 98 226 314 minecraft:white_wool
fill 96 226 317 97 227 317 minecraft:red_concrete
setblock 97 226 276 minecraft:white_concrete
fill 97 226 277 97 226 279 minecraft:white_wool
setblock 97 226 280 minecraft:white_concrete
fill 97 226 281 97 226 283 minecraft:white_wool
setblock 97 226 284 minecraft:white_concrete
fill 97 226 285 97 226 287 minecraft:white_wool
setblock 97 226 288 minecraft:white_concrete
fill 97 226 289 97 226 291 minecraft:white_wool
setblock 97 226 292 minecraft:white_concrete
fill 97 226 293 97 226 295 minecraft:white_wool
setblock 97 226 296 minecraft:white_concrete
fill 97 226 297 97 226 299 minecraft:white_wool
setblock 97 226 300 minecraft:white_concrete
fill 97 226 301 97 226 303 minecraft:white_wool
setblock 97 226 304 minecraft:white_concrete
fill 97 226 305 97 226 307 minecraft:white_wool
setblock 97 226 308 minecraft:white_concrete
fill 97 226 309 97 226 311 minecraft:white_wool
setblock 97 226 312 minecraft:white_concrete
fill 97 226 313 99 226 313 minecraft:white_wool
setblock 97 226 315 minecraft:white_wool
setblock 97 226 316 minecraft:white_concrete
fill 98 226 275 99 227 275 minecraft:white_concrete
fill 98 226 276 98 226 278 minecraft:white_wool
setblock 98 226 279 minecraft:white_concrete
fill 98 226 280 98 226 282 minecraft:white_wool
setblock 98 226 283 minecraft:white_concrete
fill 98 226 284 98 226 286 minecraft:white_wool
setblock 98 226 287 minecraft:white_concrete
fill 98 226 288 98 226 290 minecraft:white_wool
setblock 98 226 291 minecraft:white_concrete
fill 98 226 292 98 226 294 minecraft:white_wool
setblock 98 226 295 minecraft:white_concrete
fill 98 226 296 98 226 298 minecraft:white_wool
setblock 98 226 299 minecraft:white_concrete
fill 98 226 300 98 226 302 minecraft:white_wool
setblock 98 226 303 minecraft:white_concrete
fill 98 226 304 98 226 306 minecraft:white_wool
setblock 98 226 307 minecraft:white_concrete
fill 98 226 308 98 226 310 minecraft:white_wool
setblock 98 226 311 minecraft:white_concrete
fill 98 226 312 100 226 312 minecraft:white_wool
setblock 98 226 315 minecraft:white_concrete
fill 98 226 316 100 226 316 minecraft:white_wool
fill 98 226 317 99 227 317 minecraft:white_concrete
fill 99 226 276 99 226 277 minecraft:white_wool
setblock 99 226 278 minecraft:white_concrete
fill 99 226 279 99 226 281 minecraft:white_wool
setblock 99 226 282 minecraft:white_concrete
fill 99 226 283 99 226 285 minecraft:white_wool
setblock 99 226 286 minecraft:white_concrete
fill 99 226 287 99 226 289 minecraft:white_wool
setblock 99 226 290 minecraft:white_concrete
fill 99 226 291 99 226 293 minecraft:white_wool
setblock 99 226 294 minecraft:white_concrete
fill 99 226 295 99 226 297 minecraft:white_wool
setblock 99 226 298 minecraft:white_concrete
fill 99 226 299 99 226 301 minecraft:white_wool
setblock 99 226 302 minecraft:white_concrete
fill 99 226 303 99 226 305 minecraft:white_wool
setblock 99 226 306 minecraft:white_concrete
fill 99 226 307 99 226 309 minecraft:white_wool
setblock 99 226 310 minecraft:white_concrete
fill 99 226 311 101 226 311 minecraft:white_wool
setblock 99 226 314 minecraft:white_concrete
fill 99 226 315 101 226 315 minecraft:white_wool
fill 100 226 275 101 227 275 minecraft:red_concrete
setblock 100 226 276 minecraft:white_wool
setblock 100 226 277 minecraft:white_concrete
fill 100 226 278 100 226 280 minecraft:white_wool
setblock 100 226 281 minecraft:white_concrete
fill 100 226 282 100 226 284 minecraft:white_wool
setblock 100 226 285 minecraft:white_concrete
fill 100 226 286 100 226 288 minecraft:white_wool
setblock 100 226 289 minecraft:white_concrete
fill 100 226 290 100 226 292 minecraft:white_wool
setblock 100 226 293 minecraft:white_concrete
fill 100 226 294 100 226 296 minecraft:white_wool
setblock 100 226 297 minecraft:white_concrete
fill 100 226 298 100 226 300 minecraft:white_wool
setblock 100 226 301 minecraft:white_concrete
fill 100 226 302 100 226 304 minecraft:white_wool
setblock 100 226 305 minecraft:white_concrete
fill 100 226 306 100 226 308 minecraft:white_wool
setblock 100 226 309 minecraft:white_concrete
fill 100 226 310 102 226 310 minecraft:white_wool
setblock 100 226 313 minecraft:white_concrete
fill 100 226 314 102 226 314 minecraft:white_wool
fill 100 226 317 101 227 317 minecraft:red_concrete
setblock 101 226 276 minecraft:white_concrete
fill 101 226 277 101 226 279 minecraft:white_wool
setblock 101 226 280 minecraft:white_concrete
fill 101 226 281 101 226 283 minecraft:white_wool
setblock 101 226 284 minecraft:white_concrete
fill 101 226 285 101 226 287 minecraft:white_wool
setblock 101 226 288 minecraft:white_concrete
fill 101 226 289 101 226 291 minecraft:white_wool
setblock 101 226 292 minecraft:white_concrete
fill 101 226 293 101 226 295 minecraft:white_wool
setblock 101 226 296 minecraft:white_concrete
fill 101 226 297 101 226 299 minecraft:white_wool
setblock 101 226 300 minecraft:white_concrete
fill 101 226 301 101 226 303 minecraft:white_wool
setblock 101 226 304 minecraft:white_concrete
fill 101 226 305 101 226 307 minecraft:white_wool
setblock 101 226 308 minecraft:white_concrete
fill 101 226 309 103 226 309 minecraft:white_wool
setblock 101 226 312 minecraft:white_concrete
fill 101 226 313 103 226 313 minecraft:white_wool
setblock 101 226 316 minecraft:white_concrete
fill 102 226 275 103 227 275 minecraft:white_concrete
fill 102 226 276 102 226 278 minecraft:white_wool
setblock 102 226 279 minecraft:white_concrete
fill 102 226 280 102 226 282 minecraft:white_wool
setblock 102 226 283 minecraft:white_concrete
fill 102 226 284 102 226 286 minecraft:white_wool
setblock 102 226 287 minecraft:white_concrete
fill 102 226 288 102 226 290 minecraft:white_wool
setblock 102 226 291 minecraft:white_concrete
fill 102 226 292 102 226 294 minecraft:white_wool
setblock 102 226 295 minecraft:white_concrete
fill 102 226 296 107 226 296 minecraft:iron_block
fill 102 226 297 102 226 298 minecraft:white_wool
setblock 102 226 299 minecraft:white_concrete
fill 102 226 300 102 226 302 minecraft:white_wool
setblock 102 226 303 minecraft:white_concrete
fill 102 226 304 102 226 306 minecraft:white_wool
setblock 102 226 307 minecraft:white_concrete
fill 102 226 308 104 226 308 minecraft:white_wool
setblock 102 226 311 minecraft:white_concrete
fill 102 226 312 104 226 312 minecraft:white_wool
setblock 102 226 315 minecraft:white_concrete
fill 102 226 316 104 226 316 minecraft:white_wool
fill 102 226 317 103 227 317 minecraft:white_concrete
fill 103 226 276 103 226 277 minecraft:white_wool
setblock 103 226 278 minecraft:white_concrete
fill 103 226 279 103 226 281 minecraft:white_wool
setblock 103 226 282 minecraft:white_concrete
fill 103 226 283 103 226 285 minecraft:white_wool
setblock 103 226 286 minecraft:white_concrete
fill 103 226 287 103 226 289 minecraft:white_wool
setblock 103 226 290 minecraft:white_concrete
setblock 103 226 291 minecraft:white_wool
setblock 103 226 293 minecraft:white_wool
fill 103 226 294 108 226 294 minecraft:iron_block
fill 103 226 295 104 226 295 minecraft:white_wool
fill 103 226 297 106 226 297 minecraft:iron_block
setblock 103 226 298 minecraft:white_concrete
fill 103 226 300 103 226 301 minecraft:white_wool
setblock 103 226 302 minecraft:white_concrete
fill 103 226 303 103 226 305 minecraft:white_wool
setblock 103 226 306 minecraft:white_concrete
fill 103 226 307 105 226 307 minecraft:white_wool
setblock 103 226 310 minecraft:white_concrete
fill 103 226 311 105 226 311 minecraft:white_wool
setblock 103 226 314 minecraft:white_concrete
fill 103 226 315 105 226 315 minecraft:white_wool
fill 104 226 275 105 227 275 minecraft:red_concrete
setblock 104 226 276 minecraft:white_wool
setblock 104 226 277 minecraft:white_concrete
fill 104 226 278 104 226 280 minecraft:white_wool
setblock 104 226 281 minecraft:white_concrete
fill 104 226 282 104 226 284 minecraft:white_wool
setblock 104 226 285 minecraft:white_concrete
fill 104 226 286 104 226 288 minecraft:white_wool
setblock 104 226 289 minecraft:white_concrete
setblock 104 226 290 minecraft:white_wool
setblock 104 226 292 minecraft:white_wool
fill 104 226 293 108 226 293 minecraft:iron_block
fill 104 226 298 104 226 299 minecraft:white_wool
fill 104 226 300 108 226 300 minecraft:iron_block
setblock 104 226 301 minecraft:white_concrete
fill 104 226 303 104 226 304 minecraft:white_wool
setblock 104 226 305 minecraft:white_concrete
fill 104 226 306 106 226 306 minecraft:white_wool
setblock 104 226 309 minecraft:white_concrete
fill 104 226 310 106 226 310 minecraft:white_wool
setblock 104 226 313 minecraft:white_concrete
fill 104 226 314 106 226 314 minecraft:white_wool
fill 104 226 317 105 227 317 minecraft:red_concrete
setblock 105 226 276 minecraft:white_concrete
fill 105 226 277 105 226 279 minecraft:white_wool
setblock 105 226 280 minecraft:white_concrete
fill 105 226 281 105 226 283 minecraft:white_wool
setblock 105 226 284 minecraft:white_concrete
fill 105 226 285 105 226 287 minecraft:white_wool
setblock 105 226 288 minecraft:white_concrete
fill 105 226 289 106 226 289 minecraft:white_wool
setblock 105 226 291 minecraft:white_wool
setblock 105 226 292 minecraft:white_concrete
fill 105 226 295 107 226 295 minecraft:iron_block
fill 105 226 298 106 226 299 minecraft:iron_block
fill 105 226 302 105 226 303 minecraft:white_wool
setblock 105 226 304 minecraft:white_concrete
fill 105 226 305 107 226 305 minecraft:white_wool
setblock 105 226 308 minecraft:white_concrete
fill 105 226 309 107 226 309 minecraft:white_wool
setblock 105 226 312 minecraft:white_concrete
fill 105 226 313 107 226 313 minecraft:white_wool
setblock 105 226 316 minecraft:white_concrete
fill 106 226 275 107 227 275 minecraft:white_concrete
fill 106 226 276 106 226 278 minecraft:white_wool
setblock 106 226 279 minecraft:white_concrete
fill 106 226 280 106 226 282 minecraft:white_wool
setblock 106 226 283 minecraft:white_concrete
fill 106 226 284 106 226 286 minecraft:white_wool
setblock 106 226 287 minecraft:white_concrete
setblock 106 226 290 minecraft:white_wool
fill 106 226 291 109 226 292 minecraft:iron_block
setblock 106 226 302 minecraft:white_wool
setblock 106 226 304 minecraft:white_wool
setblock 106 226 307 minecraft:white_concrete
fill 106 226 308 108 226 308 minecraft:white_wool
setblock 106 226 311 minecraft:white_concrete
fill 106 226 312 108 226 312 minecraft:white_wool
setblock 106 226 315 minecraft:white_concrete
fill 106 226 316 108 226 316 minecraft:white_wool
fill 106 226 317 107 227 317 minecraft:white_concrete
fill 107 226 276 107 226 277 minecraft:white_wool
setblock 107 226 278 minecraft:white_concrete
fill 107 226 279 107 226 281 minecraft:white_wool
setblock 107 226 282 minecraft:white_concrete
fill 107 226 283 107 226 285 minecraft:white_wool
setblock 107 226 286 minecraft:white_concrete
fill 107 226 287 107 226 288 minecraft:white_wool
fill 107 226 297 107 226 298 minecraft:light_gray_concrete
setblock 107 226 299 minecraft:iron_block
fill 107 226 303 108 226 303 minecraft:white_wool
setblock 107 226 306 minecraft:white_concrete
fill 107 226 307 109 226 307 minecraft:white_wool
setblock 107 226 310 minecraft:white_concrete
fill 107 226 311 109 226 311 minecraft:white_wool
setblock 107 226 314 minecraft:white_concrete
fill 107 226 315 109 226 315 minecraft:white_wool
fill 108 226 275 109 227 275 minecraft:red_concrete
setblock 108 226 276 minecraft:white_wool
setblock 108 226 277 minecraft:white_concrete
fill 108 226 278 108 226 280 minecraft:white_wool
setblock 108 226 281 minecraft:white_concrete
fill 108 226 282 108 226 284 minecraft:white_wool
setblock 108 226 285 minecraft:white_concrete
fill 108 226 286 108 226 287 minecraft:white_wool
fill 108 226 295 108 226 297 minecraft:red_concrete
fill 108 226 298 108 226 299 minecraft:light_gray_concrete
setblock 108 226 304 minecraft:white_wool
fill 108 226 306 110 226 306 minecraft:white_wool
setblock 108 226 309 minecraft:white_concrete
fill 108 226 310 110 226 310 minecraft:white_wool
setblock 108 226 313 minecraft:white_concrete
fill 108 226 314 110 226 314 minecraft:white_wool
fill 108 226 317 109 227 317 minecraft:red_concrete
setblock 109 226 276 minecraft:white_concrete
fill 109 226 277 109 226 279 minecraft:white_wool
setblock 109 226 280 minecraft:white_concrete
fill 109 226 281 109 226 283 minecraft:white_wool
setblock 109 226 284 minecraft:white_concrete
fill 109 226 285 110 226 286 minecraft:white_wool
setblock 109 226 288 minecraft:white_concrete
setblock 109 226 293 minecraft:red_concrete
fill 109 226 294 109 226 295 minecraft:shroomlight
fill 109 226 297 109 226 298 minecraft:shroomlight
setblock 109 226 299 minecraft:red_concrete
setblock 109 226 300 minecraft:light_gray_concrete
setblock 109 226 305 minecraft:white_wool
setblock 109 226 308 minecraft:white_concrete
fill 109 226 309 111 226 309 minecraft:white_wool
setblock 109 226 312 minecraft:white_concrete
fill 109 226 313 111 226 313 minecraft:white_wool
setblock 109 226 316 minecraft:white_concrete
fill 110 226 275 111 227 275 minecraft:white_concrete
fill 110 226 276 110 226 278 minecraft:white_wool
setblock 110 226 279 minecraft:white_concrete
fill 110 226 280 110 226 282 minecraft:white_wool
setblock 110 226 283 minecraft:white_concrete
fill 110 226 284 112 226 284 minecraft:white_wool
setblock 110 226 287 minecraft:white_concrete
setblock 110 226 288 minecraft:white_wool
fill 110 226 291 110 226 292 minecraft:light_gray_concrete
fill 110 226 293 111 226 293 minecraft:shroomlight
fill 110 226 299 111 226 299 minecraft:shroomlight
setblock 110 226 300 minecraft:iron_block
setblock 110 226 307 minecraft:white_concrete
fill 110 226 308 112 226 308 minecraft:white_wool
setblock 110 226 311 minecraft:white_concrete
fill 110 226 312 112 226 312 minecraft:white_wool
setblock 110 226 315 minecraft:white_concrete
fill 110 226 316 112 226 316 minecraft:white_wool
fill 110 226 317 111 227 317 minecraft:white_concrete
fill 111 226 276 111 226 277 minecraft:white_wool
setblock 111 226 278 minecraft:white_concrete
fill 111 226 279 111 226 281 minecraft:white_wool
setblock 111 226 282 minecraft:white_concrete
fill 111 226 283 113 226 283 minecraft:white_wool
setblock 111 226 285 minecraft:white_wool
setblock 111 226 286 minecraft:white_concrete
fill 111 226 291 114 226 291 minecraft:light_gray_concrete
fill 111 226 292 113 226 292 minecraft:red_concrete
fill 111 226 300 113 226 300 minecraft:red_concrete
fill 111 226 304 111 226 305 minecraft:white_wool
setblock 111 226 306 minecraft:white_concrete
fill 111 226 307 113 226 307 minecraft:white_wool
setblock 111 226 310 minecraft:white_concrete
fill 111 226 311 113 226 311 minecraft:white_wool
setblock 111 226 314 minecraft:white_concrete
fill 111 226 315 113 226 315 minecraft:white_wool
fill 112 226 275 113 227 275 minecraft:red_concrete
setblock 112 226 276 minecraft:white_wool
setblock 112 226 277 minecraft:white_concrete
fill 112 226 278 112 226 280 minecraft:white_wool
setblock 112 226 281 minecraft:white_concrete
fill 112 226 282 114 226 282 minecraft:white_wool
setblock 112 226 285 minecraft:white_concrete
setblock 112 226 309 minecraft:white_concrete
fill 112 226 310 114 226 310 minecraft:white_wool
setblock 112 226 313 minecraft:white_concrete
fill 112 226 314 114 226 314 minecraft:white_wool
fill 112 226 317 113 227 317 minecraft:red_concrete
setblock 113 226 276 minecraft:white_concrete
fill 113 226 277 113 226 279 minecraft:white_wool
setblock 113 226 280 minecraft:white_concrete
fill 113 226 281 115 226 281 minecraft:white_wool
setblock 113 226 284 minecraft:white_concrete
fill 113 226 285 113 226 287 minecraft:white_wool
setblock 113 226 288 minecraft:white_concrete
fill 113 226 293 114 226 293 minecraft:shroomlight
fill 113 226 299 114 226 299 minecraft:shroomlight
fill 113 226 306 114 226 306 minecraft:white_wool
setblock 113 226 308 minecraft:white_concrete
fill 113 226 309 115 226 309 minecraft:white_wool
setblock 113 226 312 minecraft:white_concrete
fill 113 226 313 115 226 313 minecraft:white_wool
setblock 113 226 316 minecraft:white_concrete
fill 114 226 275 115 227 275 minecraft:white_concrete
fill 114 226 276 114 226 278 minecraft:white_wool
setblock 114 226 279 minecraft:white_concrete
fill 114 226 280 116 226 280 minecraft:white_wool
setblock 114 226 283 minecraft:white_concrete
fill 114 226 284 114 226 286 minecraft:white_wool
setblock 114 226 292 minecraft:light_gray_concrete
setblock 114 226 300 minecraft:iron_block
fill 114 226 304 114 226 305 minecraft:white_wool
setblock 114 226 307 minecraft:white_concrete
fill 114 226 308 116 226 308 minecraft:white_wool
setblock 114 226 311 minecraft:white_concrete
fill 114 226 312 116 226 312 minecraft:white_wool
setblock 114 226 315 minecraft:white_concrete
fill 114 226 316 116 226 316 minecraft:white_wool
fill 114 226 317 115 227 317 minecraft:white_concrete
fill 115 226 276 115 226 277 minecraft:white_wool
setblock 115 226 278 minecraft:white_concrete
fill 115 226 279 117 226 279 minecraft:white_wool
setblock 115 226 282 minecraft:white_concrete
fill 115 226 283 115 226 285 minecraft:white_wool
setblock 115 226 286 minecraft:white_concrete
setblock 115 226 287 minecraft:white_wool
fill 115 226 291 119 226 292 minecraft:iron_block
setblock 115 226 293 minecraft:red_concrete
fill 115 226 294 115 226 295 minecraft:shroomlight
fill 115 226 297 115 226 298 minecraft:shroomlight
setblock 115 226 299 minecraft:red_concrete
setblock 115 226 300 minecraft:light_gray_concrete
setblock 115 226 304 minecraft:white_wool
setblock 115 226 306 minecraft:white_concrete
fill 115 226 307 117 226 307 minecraft:white_wool
setblock 115 226 310 minecraft:white_concrete
fill 115 226 311 117 226 311 minecraft:white_wool
setblock 115 226 314 minecraft:white_concrete
fill 115 226 315 117 226 315 minecraft:white_wool
fill 116 226 275 117 227 275 minecraft:red_concrete
setblock 116 226 276 minecraft:white_wool
setblock 116 226 277 minecraft:white_concrete
fill 116 226 278 118 226 278 minecraft:white_wool
setblock 116 226 281 minecraft:white_concrete
fill 116 226 282 116 226 284 minecraft:white_wool
setblock 116 226 285 minecraft:white_concrete
fill 116 226 286 118 226 286 minecraft:white_wool
setblock 116 226 288 minecraft:white_wool
setblock 116 226 289 minecraft:white_concrete
fill 116 226 293 119 226 294 minecraft:iron_block
fill 116 226 295 116 226 297 minecraft:red_concrete
fill 116 226 298 116 226 299 minecraft:light_gray_concrete
fill 116 226 300 118 226 300 minecraft:iron_block
setblock 116 226 305 minecraft:white_concrete
fill 116 226 306 118 226 306 minecraft:white_wool
setblock 116 226 309 minecraft:white_concrete
fill 116 226 310 118 226 310 minecraft:white_wool
setblock 116 226 313 minecraft:white_concrete
fill 116 226 314 118 226 314 minecraft:white_wool
fill 116 226 317 117 227 317 minecraft:red_concrete
setblock 117 226 276 minecraft:white_concrete
fill 117 226 277 119 226 277 minecraft:white_wool
setblock 117 226 280 minecraft:white_concrete
fill 117 226 281 117 226 283 minecraft:white_wool
setblock 117 226 284 minecraft:white_concrete
fill 117 226 285 119 226 285 minecraft:white_wool
setblock 117 226 287 minecraft:white_wool
setblock 117 226 289 minecraft:white_wool
fill 117 226 295 119 226 295 minecraft:iron_block
fill 117 226 296 117 226 298 minecraft:light_gray_concrete
fill 117 226 299 120 226 299 minecraft:iron_block
setblock 117 226 304 minecraft:white_concrete
fill 117 226 305 119 226 305 minecraft:white_wool
setblock 117 226 308 minecraft:white_concrete
fill 117 226 309 119 226 309 minecraft:white_wool
setblock 117 226 312 minecraft:white_concrete
fill 117 226 313 119 226 313 minecraft:white_wool
setblock 117 226 316 minecraft:white_concrete
fill 118 226 275 119 227 275 minecraft:white_concrete
fill 118 226 276 120 226 276 minecraft:white_wool
setblock 118 226 279 minecraft:white_concrete
fill 118 226 280 118 226 282 minecraft:white_wool
setblock 118 226 283 minecraft:white_concrete
fill 118 226 284 120 226 284 minecraft:white_wool
setblock 118 226 287 minecraft:white_concrete
fill 118 226 288 120 226 288 minecraft:white_wool
setblock 118 226 290 minecraft:white_wool
fill 118 226 296 119 226 298 minecraft:iron_block
setblock 118 226 302 minecraft:white_wool
setblock 118 226 303 minecraft:white_concrete
setblock 118 226 307 minecraft:white_concrete
fill 118 226 308 120 226 308 minecraft:white_wool
setblock 118 226 311 minecraft:white_concrete
fill 118 226 312 120 226 312 minecraft:white_wool
setblock 118 226 315 minecraft:white_concrete
fill 118 226 316 120 226 316 minecraft:white_wool
fill 118 226 317 119 227 317 minecraft:white_concrete
setblock 119 226 278 minecraft:white_concrete
fill 119 226 279 119 226 281 minecraft:white_wool
setblock 119 226 282 minecraft:white_concrete
fill 119 226 283 121 226 283 minecraft:white_wool
setblock 119 226 286 minecraft:white_concrete
fill 119 226 287 121 226 287 minecraft:white_wool
setblock 119 226 289 minecraft:white_wool
setblock 119 226 290 minecraft:white_concrete
fill 119 226 300 119 226 301 minecraft:white_wool
fill 119 226 303 120 226 304 minecraft:white_wool
setblock 119 226 306 minecraft:white_concrete
fill 119 226 307 121 226 307 minecraft:white_wool
setblock 119 226 310 minecraft:white_concrete
fill 119 226 311 121 226 311 minecraft:white_wool
setblock 119 226 314 minecraft:white_concrete
fill 119 226 315 121 226 315 minecraft:white_wool
fill 120 226 275 121 227 275 minecraft:red_concrete
setblock 120 226 277 minecraft:white_concrete
fill 120 226 278 120 226 280 minecraft:white_wool
setblock 120 226 281 minecraft:white_concrete
fill 120 226 282 122 226 282 minecraft:white_wool
setblock 120 226 285 minecraft:white_concrete
fill 120 226 286 122 226 286 minecraft:white_wool
setblock 120 226 289 minecraft:white_concrete
fill 120 226 291 121 226 291 minecraft:white_wool
setblock 120 226 293 minecraft:white_concrete
fill 120 226 294 122 226 294 minecraft:white_wool
fill 120 226 296 122 226 296 minecraft:iron_block
setblock 120 226 297 minecraft:white_concrete
setblock 120 226 300 minecraft:white_wool
fill 120 226 302 122 226 302 minecraft:white_wool
setblock 120 226 305 minecraft:white_concrete
fill 120 226 306 122 226 306 minecraft:white_wool
setblock 120 226 309 minecraft:white_concrete
fill 120 226 310 122 226 310 minecraft:white_wool
setblock 120 226 313 minecraft:white_concrete
fill 120 226 314 122 226 314 minecraft:white_wool
fill 120 226 317 121 227 317 minecraft:red_concrete
setblock 121 226 276 minecraft:white_concrete
fill 121 226 277 121 226 279 minecraft:white_wool
setblock 121 226 280 minecraft:white_concrete
fill 121 226 281 123 226 281 minecraft:white_wool
setblock 121 226 284 minecraft:white_concrete
fill 121 226 285 123 226 285 minecraft:white_wool
setblock 121 226 288 minecraft:white_concrete
fill 121 226 289 122 226 290 minecraft:white_wool
setblock 121 226 292 minecraft:white_concrete
fill 121 226 297 123 226 297 minecraft:white_wool
setblock 121 226 299 minecraft:white_wool
fill 121 226 301 123 226 301 minecraft:white_wool
setblock 121 226 303 minecraft:white_wool
setblock 121 226 304 minecraft:white_concrete
fill 121 226 305 123 226 305 minecraft:white_wool
setblock 121 226 308 minecraft:white_concrete
fill 121 226 309 123 226 309 minecraft:white_wool
setblock 121 226 312 minecraft:white_concrete
fill 121 226 313 123 226 313 minecraft:white_wool
setblock 121 226 316 minecraft:white_concrete
fill 122 226 275 123 227 275 minecraft:white_concrete
fill 122 226 276 122 226 278 minecraft:white_wool
setblock 122 226 279 minecraft:white_concrete
fill 122 226 280 124 226 280 minecraft:white_wool
setblock 122 226 283 minecraft:white_concrete
fill 122 226 284 124 226 284 minecraft:white_wool
setblock 122 226 287 minecraft:white_concrete
fill 122 226 288 124 226 288 minecraft:white_wool
setblock 122 226 291 minecraft:white_concrete
fill 122 226 292 123 226 293 minecraft:white_wool
setblock 122 226 295 minecraft:white_concrete
setblock 122 226 298 minecraft:white_wool
setblock 122 226 299 minecraft:white_concrete
fill 122 226 300 124 226 300 minecraft:white_wool
setblock 122 226 303 minecraft:white_concrete
fill 122 226 304 124 226 304 minecraft:white_wool
setblock 122 226 307 minecraft:white_concrete
fill 122 226 308 124 226 308 minecraft:white_wool
setblock 122 226 311 minecraft:white_concrete
fill 122 226 312 124 226 312 minecraft:white_wool
setblock 122 226 315 minecraft:white_concrete
fill 122 226 316 124 226 316 minecraft:white_wool
fill 122 226 317 123 227 317 minecraft:white_concrete
fill 123 226 276 123 226 277 minecraft:white_wool
setblock 123 226 278 minecraft:white_concrete
fill 123 226 279 125 226 279 minecraft:white_wool
setblock 123 226 282 minecraft:white_concrete
fill 123 226 283 125 226 283 minecraft:white_wool
setblock 123 226 286 minecraft:white_concrete
fill 123 226 287 125 226 287 minecraft:white_wool
setblock 123 226 289 minecraft:white_wool
setblock 123 226 290 minecraft:white_concrete
fill 123 226 291 125 226 291 minecraft:white_wool
setblock 123 226 294 minecraft:white_concrete
fill 123 226 295 124 226 296 minecraft:white_wool
setblock 123 226 298 minecraft:white_concrete
fill 123 226 299 125 226 299 minecraft:white_wool
setblock 123 226 302 minecraft:white_concrete
fill 123 226 303 125 226 303 minecraft:white_wool
setblock 123 226 306 minecraft:white_concrete
fill 123 226 307 125 226 307 minecraft:white_wool
setblock 123 226 310 minecraft:white_concrete
fill 123 226 311 125 226 311 minecraft:white_wool
setblock 123 226 314 minecraft:white_concrete
fill 123 226 315 125 226 315 minecraft:white_wool
fill 124 226 275 125 227 275 minecraft:red_concrete
setblock 124 226 276 minecraft:white_wool
setblock 124 226 277 minecraft:white_concrete
fill 124 226 278 126 226 278 minecraft:white_wool
setblock 124 226 281 minecraft:white_concrete
fill 124 226 282 126 226 282 minecraft:white_wool
setblock 124 226 285 minecraft:white_concrete
fill 124 226 286 126 226 286 minecraft:white_wool
setblock 124 226 289 minecraft:white_concrete
fill 124 226 290 126 226 290 minecraft:white_wool
setblock 124 226 292 minecraft:white_wool
setblock 124 226 293 minecraft:white_concrete
fill 124 226 294 126 226 294 minecraft:white_wool
setblock 124 226 297 minecraft:white_concrete
fill 124 226 298 126 226 298 minecraft:white_wool
setblock 124 226 301 minecraft:white_concrete
fill 124 226 302 126 226 302 minecraft:white_wool
setblock 124 226 305 minecraft:white_concrete
fill 124 226 306 126 226 306 minecraft:white_wool
setblock 124 226 309 minecraft:white_concrete
fill 124 226 310 126 226 310 minecraft:white_wool
setblock 124 226 313 minecraft:white_concrete
fill 124 226 314 126 226 314 minecraft:white_wool
fill 124 226 317 125 227 317 minecraft:red_concrete
setblock 125 226 276 minecraft:white_concrete
fill 125 226 277 127 226 277 minecraft:white_wool
setblock 125 226 280 minecraft:white_concrete
fill 125 226 281 127 226 281 minecraft:white_wool
setblock 125 226 284 minecraft:white_concrete
fill 125 226 285 127 226 285 minecraft:white_wool
setblock 125 226 288 minecraft:white_concrete
fill 125 226 289 127 226 289 minecraft:white_wool
setblock 125 226 292 minecraft:white_concrete
fill 125 226 293 127 226 293 minecraft:white_wool
setblock 125 226 295 minecraft:white_wool
setblock 125 226 296 minecraft:white_concrete
fill 125 226 297 127 226 297 minecraft:white_wool
setblock 125 226 300 minecraft:white_concrete
fill 125 226 301 127 226 301 minecraft:white_wool
setblock 125 226 304 minecraft:white_concrete
fill 125 226 305 127 226 305 minecraft:white_wool
setblock 125 226 308 minecraft:white_concrete
fill 125 226 309 127 226 309 minecraft:white_wool
setblock 125 226 312 minecraft:white_concrete
fill 125 226 313 127 226 313 minecraft:white_wool
setblock 125 226 316 minecraft:white_concrete
fill 126 226 275 127 227 275 minecraft:white_concrete
fill 126 226 276 128 226 276 minecraft:white_wool
setblock 126 226 279 minecraft:white_concrete
fill 126 226 280 128 226 280 minecraft:white_wool
setblock 126 226 283 minecraft:white_concrete
fill 126 226 284 128 226 284 minecraft:white_wool
setblock 126 226 287 minecraft:white_concrete
fill 126 226 288 128 226 288 minecraft:white_wool
setblock 126 226 291 minecraft:white_concrete
fill 126 226 292 128 226 292 minecraft:white_wool
setblock 126 226 295 minecraft:white_concrete
fill 126 226 296 128 226 296 minecraft:white_wool
setblock 126 226 299 minecraft:white_concrete
fill 126 226 300 128 226 300 minecraft:white_wool
setblock 126 226 303 minecraft:white_concrete
fill 126 226 304 128 226 304 minecraft:white_wool
setblock 126 226 307 minecraft:white_concrete
fill 126 226 308 128 226 308 minecraft:white_wool
setblock 126 226 311 minecraft:white_concrete
fill 126 226 312 128 226 312 minecraft:white_wool
setblock 126 226 315 minecraft:white_concrete
fill 126 226 316 128 226 316 minecraft:white_wool
fill 126 226 317 127 227 317 minecraft:white_concrete
setblock 127 226 278 minecraft:white_concrete
fill 127 226 279 129 226 279 minecraft:white_wool
setblock 127 226 282 minecraft:white_concrete
fill 127 226 283 129 226 283 minecraft:white_wool
setblock 127 226 286 minecraft:white_concrete
fill 127 226 287 129 226 287 minecraft:white_wool
setblock 127 226 290 minecraft:white_concrete
fill 127 226 291 129 226 291 minecraft:white_wool
setblock 127 226 294 minecraft:white_concrete
fill 127 226 295 129 226 295 minecraft:white_wool
setblock 127 226 298 minecraft:white_concrete
fill 127 226 299 129 226 299 minecraft:white_wool
setblock 127 226 302 minecraft:white_concrete
fill 127 226 303 129 226 303 minecraft:white_wool
setblock 127 226 306 minecraft:white_concrete
fill 127 226 307 129 226 307 minecraft:white_wool
setblock 127 226 310 minecraft:white_concrete
fill 127 226 311 129 226 311 minecraft:white_wool
setblock 127 226 314 minecraft:white_concrete
fill 127 226 315 129 226 315 minecraft:white_wool
fill 128 226 275 129 227 275 minecraft:red_concrete
setblock 128 226 277 minecraft:white_concrete
fill 128 226 278 130 226 278 minecraft:white_wool
setblock 128 226 281 minecraft:white_concrete
fill 128 226 282 130 226 282 minecraft:white_wool
setblock 128 226 285 minecraft:white_concrete
fill 128 226 286 130 226 286 minecraft:white_wool
setblock 128 226 289 minecraft:white_concrete
fill 128 226 290 130 226 290 minecraft:white_wool
setblock 128 226 293 minecraft:white_concrete
fill 128 226 294 130 226 294 minecraft:white_wool
setblock 128 226 297 minecraft:white_concrete
fill 128 226 298 130 226 298 minecraft:white_wool
setblock 128 226 301 minecraft:white_concrete
fill 128 226 302 130 226 302 minecraft:white_wool
setblock 128 226 305 minecraft:white_concrete
fill 128 226 306 130 226 306 minecraft:white_wool
setblock 128 226 309 minecraft:white_concrete
fill 128 226 310 130 226 310 minecraft:white_wool
setblock 128 226 313 minecraft:white_concrete
fill 128 226 314 130 226 314 minecraft:white_wool
fill 128 226 317 129 227 317 minecraft:red_concrete
setblock 129 226 276 minecraft:white_concrete
fill 129 226 277 131 226 277 minecraft:white_wool
setblock 129 226 280 minecraft:white_concrete
fill 129 226 281 131 226 281 minecraft:white_wool
setblock 129 226 284 minecraft:white_concrete
fill 129 226 285 131 226 285 minecraft:white_wool
setblock 129 226 288 minecraft:white_concrete
fill 129 226 289 131 226 289 minecraft:white_wool
setblock 129 226 292 minecraft:white_concrete
fill 129 226 293 131 226 293 minecraft:white_wool
setblock 129 226 296 minecraft:white_concrete
fill 129 226 297 131 226 297 minecraft:white_wool
setblock 129 226 300 minecraft:white_concrete
fill 129 226 301 131 226 301 minecraft:white_wool
setblock 129 226 304 minecraft:white_concrete
fill 129 226 305 131 226 305 minecraft:white_wool
setblock 129 226 308 minecraft:white_concrete
fill 129 226 309 131 226 309 minecraft:white_wool
setblock 129 226 312 minecraft:white_concrete
fill 129 226 313 131 226 313 minecraft:white_wool
setblock 129 226 316 minecraft:white_concrete
fill 130 226 275 131 227 275 minecraft:white_concrete
fill 130 226 276 132 226 276 minecraft:white_wool
setblock 130 226 279 minecraft:white_concrete
fill 130 226 280 132 226 280 minecraft:white_wool
setblock 130 226 283 minecraft:white_concrete
fill 130 226 284 132 226 284 minecraft:white_wool
setblock 130 226 287 minecraft:white_concrete
fill 130 226 288 132 226 288 minecraft:white_wool
setblock 130 226 291 minecraft:white_concrete
fill 130 226 292 132 226 292 minecraft:white_wool
setblock 130 226 295 minecraft:white_concrete
fill 130 226 296 132 226 296 minecraft:white_wool
setblock 130 226 299 minecraft:white_concrete
fill 130 226 300 132 226 300 minecraft:white_wool
setblock 130 226 303 minecraft:white_concrete
fill 130 226 304 132 226 304 minecraft:white_wool
setblock 130 226 307 minecraft:white_concrete
fill 130 226 308 132 226 308 minecraft:white_wool
setblock 130 226 311 minecraft:white_concrete
fill 130 226 312 132 226 312 minecraft:white_wool
setblock 130 226 315 minecraft:white_concrete
fill 130 226 316 132 226 316 minecraft:white_wool
fill 130 226 317 131 227 317 minecraft:white_concrete
setblock 131 226 278 minecraft:white_concrete
fill 131 226 279 133 226 279 minecraft:white_wool
setblock 131 226 282 minecraft:white_concrete
fill 131 226 283 133 226 283 minecraft:white_wool
setblock 131 226 286 minecraft:white_concrete
fill 131 226 287 133 226 287 minecraft:white_wool
setblock 131 226 290 minecraft:white_concrete
fill 131 226 291 133 226 291 minecraft:white_wool
setblock 131 226 294 minecraft:white_concrete
fill 131 226 295 133 226 295 minecraft:white_wool
setblock 131 226 298 minecraft:white_concrete
fill 131 226 299 133 226 299 minecraft:white_wool
setblock 131 226 302 minecraft:white_concrete
fill 131 226 303 133 226 303 minecraft:white_wool
setblock 131 226 306 minecraft:white_concrete
fill 131 226 307 133 226 307 minecraft:white_wool
setblock 131 226 310 minecraft:white_concrete
fill 131 226 311 133 226 311 minecraft:white_wool
setblock 131 226 314 minecraft:white_concrete
fill 131 226 315 133 226 315 minecraft:white_wool
fill 132 226 275 133 227 275 minecraft:red_concrete
setblock 132 226 277 minecraft:white_concrete
fill 132 226 278 134 226 278 minecraft:white_wool
setblock 132 226 281 minecraft:white_concrete
fill 132 226 282 134 226 282 minecraft:white_wool
setblock 132 226 285 minecraft:white_concrete
fill 132 226 286 134 226 286 minecraft:white_wool
setblock 132 226 289 minecraft:white_concrete
fill 132 226 290 134 226 290 minecraft:white_wool
setblock 132 226 293 minecraft:white_concrete
fill 132 226 294 134 226 294 minecraft:white_wool
setblock 132 226 297 minecraft:white_concrete
fill 132 226 298 134 226 298 minecraft:white_wool
setblock 132 226 301 minecraft:white_concrete
fill 132 226 302 134 226 302 minecraft:white_wool
setblock 132 226 305 minecraft:white_concrete
fill 132 226 306 134 226 306 minecraft:white_wool
setblock 132 226 309 minecraft:white_concrete
fill 132 226 310 134 226 310 minecraft:white_wool
setblock 132 226 313 minecraft:white_concrete
fill 132 226 314 134 226 314 minecraft:white_wool
fill 132 226 317 133 227 317 minecraft:red_concrete
setblock 133 226 276 minecraft:white_concrete
fill 133 226 277 135 226 277 minecraft:white_wool
setblock 133 226 280 minecraft:white_concrete
fill 133 226 281 135 226 281 minecraft:white_wool
setblock 133 226 284 minecraft:white_concrete
fill 133 226 285 135 226 285 minecraft:white_wool
setblock 133 226 288 minecraft:white_concrete
fill 133 226 289 135 226 289 minecraft:white_wool
setblock 133 226 292 minecraft:white_concrete
fill 133 226 293 135 226 293 minecraft:white_wool
setblock 133 226 296 minecraft:white_concrete
fill 133 226 297 135 226 297 minecraft:white_wool
setblock 133 226 300 minecraft:white_concrete
fill 133 226 301 135 226 301 minecraft:white_wool
setblock 133 226 304 minecraft:white_concrete
fill 133 226 305 135 226 305 minecraft:white_wool
setblock 133 226 308 minecraft:white_concrete
fill 133 226 309 135 226 309 minecraft:white_wool
setblock 133 226 312 minecraft:white_concrete
fill 133 226 313 135 226 313 minecraft:white_wool
setblock 133 226 316 minecraft:white_concrete
fill 134 226 275 135 227 275 minecraft:white_concrete
fill 134 226 276 135 226 276 minecraft:white_wool
setblock 134 226 279 minecraft:white_concrete
fill 134 226 280 135 226 280 minecraft:white_wool
setblock 134 226 283 minecraft:white_concrete
fill 134 226 284 135 226 284 minecraft:white_wool
setblock 134 226 287 minecraft:white_concrete
fill 134 226 288 135 226 288 minecraft:white_wool
setblock 134 226 291 minecraft:white_concrete
fill 134 226 292 135 226 292 minecraft:white_wool
setblock 134 226 295 minecraft:white_concrete
fill 134 226 296 135 226 296 minecraft:white_wool
setblock 134 226 299 minecraft:white_concrete
fill 134 226 300 135 226 300 minecraft:white_wool
setblock 134 226 303 minecraft:white_concrete
fill 134 226 304 135 226 304 minecraft:white_wool
setblock 134 226 307 minecraft:white_concrete
fill 134 226 308 135 226 308 minecraft:white_wool
setblock 134 226 311 minecraft:white_concrete
fill 134 226 312 135 226 312 minecraft:white_wool
setblock 134 226 315 minecraft:white_concrete
fill 134 226 316 135 226 316 minecraft:white_wool
fill 134 226 317 135 227 317 minecraft:white_concrete
setblock 135 226 278 minecraft:white_concrete
setblock 135 226 279 minecraft:white_wool
setblock 135 226 282 minecraft:white_concrete
setblock 135 226 283 minecraft:white_wool
setblock 135 226 286 minecraft:white_concrete
setblock 135 226 287 minecraft:white_wool
setblock 135 226 290 minecraft:white_concrete
setblock 135 226 291 minecraft:white_wool
setblock 135 226 294 minecraft:white_concrete
setblock 135 226 295 minecraft:white_wool
setblock 135 226 298 minecraft:white_concrete
setblock 135 226 299 minecraft:white_wool
setblock 135 226 302 minecraft:white_concrete
setblock 135 226 303 minecraft:white_wool
setblock 135 226 306 minecraft:white_concrete
setblock 135 226 307 minecraft:white_wool
setblock 135 226 310 minecraft:white_concrete
setblock 135 226 311 minecraft:white_wool
setblock 135 226 314 minecraft:white_concrete
setblock 135 226 315 minecraft:white_wool
fill 136 226 276 136 227 276 minecraft:white_concrete
fill 136 226 277 136 227 278 minecraft:red_concrete
fill 136 226 279 136 227 280 minecraft:white_concrete
fill 136 226 281 136 227 282 minecraft:red_concrete
fill 136 226 283 136 227 284 minecraft:white_concrete
fill 136 226 285 136 227 286 minecraft:red_concrete
fill 136 226 287 136 227 288 minecraft:white_concrete
fill 136 226 289 136 227 290 minecraft:red_concrete
fill 136 226 291 136 227 292 minecraft:white_concrete
fill 136 226 293 136 227 294 minecraft:red_concrete
fill 136 226 295 136 227 296 minecraft:white_concrete
fill 136 226 297 136 227 298 minecraft:red_concrete
fill 136 226 299 136 227 300 minecraft:white_concrete
fill 136 226 301 136 227 302 minecraft:red_concrete
fill 136 226 303 136 227 304 minecraft:white_concrete
fill 136 226 305 136 227 306 minecraft:red_concrete
fill 136 226 307 136 227 308 minecraft:white_concrete
fill 136 226 309 136 227 310 minecraft:red_concrete
fill 136 226 311 136 227 312 minecraft:white_concrete
fill 136 226 313 136 227 314 minecraft:red_concrete
fill 136 226 315 136 227 316 minecraft:white_concrete
fill 136 226 317 136 227 317 minecraft:red_concrete
fill 95 227 279 95 227 313 minecraft:basalt
fill 96 227 278 98 227 279 minecraft:basalt
setblock 96 227 280 minecraft:magma_block
fill 96 227 281 98 229 282 minecraft:basalt
setblock 96 227 283 minecraft:magma_block
fill 96 227 284 98 232 285 minecraft:basalt
setblock 96 227 286 minecraft:magma_block
fill 96 227 287 98 234 288 minecraft:basalt
setblock 96 227 289 minecraft:magma_block
fill 96 227 290 97 235 291 minecraft:basalt
setblock 96 227 292 minecraft:magma_block
fill 96 227 293 96 236 294 minecraft:basalt
setblock 96 227 295 minecraft:magma_block
fill 96 227 296 96 236 297 minecraft:basalt
setblock 96 227 298 minecraft:magma_block
fill 96 227 299 96 236 300 minecraft:basalt
setblock 96 227 301 minecraft:magma_block
fill 96 227 302 97 235 303 minecraft:basalt
setblock 96 227 304 minecraft:magma_block
fill 96 227 305 98 233 306 minecraft:basalt
setblock 96 227 307 minecraft:magma_block
fill 96 227 308 98 231 309 minecraft:basalt
setblock 96 227 310 minecraft:magma_block
fill 96 227 311 98 229 312 minecraft:basalt
setblock 96 227 313 minecraft:magma_block
fill 96 227 314 101 227 314 minecraft:basalt
fill 97 227 277 104 227 277 minecraft:basalt
fill 97 227 280 104 230 280 minecraft:basalt
fill 97 227 283 103 232 283 minecraft:basalt
fill 97 227 286 99 234 286 minecraft:basalt
fill 97 227 289 97 236 289 minecraft:basalt
fill 97 227 301 97 237 301 minecraft:basalt
fill 97 227 304 98 235 304 minecraft:basalt
fill 97 227 307 100 233 307 minecraft:basalt
fill 97 227 310 104 231 310 minecraft:basalt
fill 97 227 313 104 228 313 minecraft:basalt
fill 97 227 315 98 227 315 minecraft:basalt
setblock 98 227 276 minecraft:basalt
fill 98 227 316 104 227 316 minecraft:basalt
setblock 99 227 276 minecraft:magma_block
fill 99 227 278 101 229 278 minecraft:basalt
setblock 99 227 279 minecraft:magma_block
fill 99 227 281 101 232 281 minecraft:basalt
setblock 99 227 282 minecraft:magma_block
fill 99 227 284 101 234 284 minecraft:basalt
setblock 99 227 285 minecraft:magma_block
fill 99 227 287 99 237 287 minecraft:basalt
fill 99 227 305 99 237 305 minecraft:basalt
setblock 99 227 306 minecraft:magma_block
fill 99 227 308 101 234 308 minecraft:basalt
setblock 99 227 309 minecraft:magma_block
fill 99 227 311 101 232 311 minecraft:basalt
setblock 99 227 312 minecraft:magma_block
setblock 99 227 315 minecraft:magma_block
fill 100 227 276 107 228 276 minecraft:basalt
fill 100 227 279 107 230 279 minecraft:basalt
fill 100 227 282 104 233 282 minecraft:basalt
fill 100 227 285 100 236 285 minecraft:basalt
fill 100 227 309 103 234 309 minecraft:basalt
fill 100 227 312 107 232 312 minecraft:basalt
fill 100 227 315 107 228 315 minecraft:basalt
setblock 102 227 278 minecraft:magma_block
setblock 102 227 281 minecraft:magma_block
setblock 102 227 311 minecraft:magma_block
setblock 102 227 314 minecraft:magma_block
fill 103 227 278 110 232 278 minecraft:basalt
fill 103 227 281 107 227 281 minecraft:basalt
fill 103 227 311 107 227 311 minecraft:basalt
fill 103 227 314 110 232 314 minecraft:basalt
setblock 105 227 277 minecraft:magma_block
setblock 105 227 280 minecraft:magma_block
setblock 105 227 313 minecraft:magma_block
setblock 105 227 316 minecraft:magma_block
fill 106 227 277 113 232 277 minecraft:basalt
fill 106 227 280 113 235 280 minecraft:basalt
fill 106 227 313 113 234 313 minecraft:basalt
fill 106 227 316 113 230 316 minecraft:basalt
setblock 108 227 276 minecraft:magma_block
setblock 108 227 279 minecraft:magma_block
setblock 108 227 312 minecraft:magma_block
setblock 108 227 315 minecraft:magma_block
fill 109 227 276 116 230 276 minecraft:basalt
fill 109 227 279 116 233 279 minecraft:basalt
fill 109 227 312 116 227 312 minecraft:basalt
fill 109 227 315 116 231 315 minecraft:basalt
setblock 111 227 278 minecraft:magma_block
setblock 111 227 314 minecraft:magma_block
fill 112 227 278 119 232 278 minecraft:basalt
fill 112 227 314 119 232 314 minecraft:basalt
setblock 114 227 277 minecraft:magma_block
setblock 114 227 280 minecraft:magma_block
setblock 114 227 313 minecraft:magma_block
setblock 114 227 316 minecraft:magma_block
fill 115 227 277 122 230 277 minecraft:basalt
fill 115 227 280 122 233 280 minecraft:basalt
fill 115 227 313 122 232 313 minecraft:basalt
fill 115 227 316 122 229 316 minecraft:basalt
setblock 117 227 276 minecraft:magma_block
setblock 117 227 279 minecraft:magma_block
fill 117 227 281 119 236 281 minecraft:basalt
fill 117 227 311 119 236 311 minecraft:basalt
setblock 117 227 312 minecraft:magma_block
setblock 117 227 315 minecraft:magma_block
fill 118 227 276 125 227 276 minecraft:basalt
fill 118 227 279 125 230 279 minecraft:basalt
fill 118 227 312 125 231 312 minecraft:basalt
fill 118 227 315 125 228 315 minecraft:basalt
setblock 120 227 278 minecraft:magma_block
setblock 120 227 281 minecraft:magma_block
fill 120 227 282 125 233 282 minecraft:basalt
fill 120 227 310 122 235 310 minecraft:basalt
setblock 120 227 311 minecraft:magma_block
setblock 120 227 314 minecraft:magma_block
fill 121 227 278 128 227 278 minecraft:basalt
fill 121 227 281 128 230 281 minecraft:basalt
fill 121 227 283 122 236 283 minecraft:basalt
fill 121 227 309 125 233 309 minecraft:basalt
fill 121 227 311 128 230 311 minecraft:basalt
fill 121 227 314 128 227 314 minecraft:basalt
setblock 123 227 277 minecraft:magma_block
setblock 123 227 280 minecraft:magma_block
setblock 123 227 283 minecraft:magma_block
fill 123 227 284 128 232 284 minecraft:basalt
fill 123 227 308 128 232 308 minecraft:basalt
setblock 123 227 310 minecraft:magma_block
setblock 123 227 313 minecraft:magma_block
setblock 123 227 316 minecraft:magma_block
fill 124 227 277 127 227 277 minecraft:basalt
fill 124 227 280 130 227 280 minecraft:basalt
fill 124 227 283 131 228 283 minecraft:basalt
fill 124 227 285 125 235 285 minecraft:basalt
fill 124 227 307 131 229 307 minecraft:basalt
fill 124 227 310 131 228 310 minecraft:basalt
fill 124 227 313 129 227 313 minecraft:basalt
fill 124 227 316 126 227 316 minecraft:basalt
fill 125 227 286 128 227 287 minecraft:basalt
fill 125 227 305 125 227 306 minecraft:basalt
setblock 126 227 276 minecraft:magma_block
setblock 126 227 279 minecraft:magma_block
setblock 126 227 282 minecraft:magma_block
setblock 126 227 285 minecraft:magma_block
setblock 126 227 288 minecraft:magma_block
fill 126 227 304 128 233 305 minecraft:basalt
setblock 126 227 306 minecraft:magma_block
setblock 126 227 309 minecraft:magma_block
setblock 126 227 312 minecraft:magma_block
setblock 126 227 315 minecraft:magma_block
fill 127 227 279 129 227 279 minecraft:basalt
fill 127 227 282 132 227 282 minecraft:basalt
fill 127 227 285 133 227 285 minecraft:basalt
fill 127 227 288 128 234 291 minecraft:basalt
fill 127 227 301 128 235 303 minecraft:basalt
fill 127 227 306 134 227 306 minecraft:basalt
fill 127 227 309 132 227 309 minecraft:basalt
fill 127 227 312 130 227 312 minecraft:basalt
setblock 127 227 315 minecraft:basalt
fill 128 227 292 128 227 300 minecraft:basalt
setblock 129 227 281 minecraft:magma_block
setblock 129 227 284 minecraft:magma_block
fill 129 227 286 131 230 286 minecraft:basalt
setblock 129 227 287 minecraft:magma_block
fill 129 227 288 131 231 289 minecraft:basalt
setblock 129 227 290 minecraft:magma_block
fill 129 227 291 131 232 292 minecraft:basalt
setblock 129 227 293 minecraft:magma_block
fill 129 227 294 131 233 295 minecraft:basalt
setblock 129 227 296 minecraft:magma_block
fill 129 227 297 131 233 298 minecraft:basalt
setblock 129 227 299 minecraft:magma_block
fill 129 227 300 131 232 301 minecraft:basalt
setblock 129 227 302 minecraft:magma_block
fill 129 227 303 131 231 304 minecraft:basalt
setblock 129 227 305 minecraft:magma_block
setblock 129 227 308 minecraft:magma_block
setblock 129 227 311 minecraft:magma_block
fill 130 227 281 131 227 281 minecraft:basalt
fill 130 227 284 133 227 284 minecraft:basalt
fill 130 227 287 134 227 287 minecraft:basalt
fill 130 227 290 135 227 290 minecraft:basalt
fill 130 227 293 135 228 293 minecraft:basalt
fill 130 227 296 135 228 296 minecraft:basalt
fill 130 227 299 135 228 299 minecraft:basalt
fill 130 227 302 135 227 302 minecraft:basalt
fill 130 227 305 134 227 305 minecraft:basalt
fill 130 227 308 133 227 308 minecraft:basalt
fill 130 227 311 131 227 311 minecraft:basalt
setblock 132 227 283 minecraft:magma_block
setblock 132 227 286 minecraft:magma_block
fill 132 227 288 134 228 288 minecraft:basalt
setblock 132 227 289 minecraft:magma_block
fill 132 227 291 134 229 291 minecraft:basalt
setblock 132 227 292 minecraft:magma_block
fill 132 227 294 134 229 294 minecraft:basalt
setblock 132 227 295 minecraft:magma_block
fill 132 227 297 134 229 297 minecraft:basalt
setblock 132 227 298 minecraft:magma_block
fill 132 227 300 134 229 300 minecraft:basalt
setblock 132 227 301 minecraft:magma_block
fill 132 227 303 134 228 303 minecraft:basalt
setblock 132 227 304 minecraft:magma_block
setblock 132 227 307 minecraft:magma_block
setblock 132 227 310 minecraft:magma_block
fill 133 227 286 134 227 286 minecraft:basalt
fill 133 227 289 135 227 289 minecraft:basalt
fill 133 227 292 135 228 292 minecraft:basalt
fill 133 227 295 135 228 295 minecraft:basalt
fill 133 227 298 135 228 298 minecraft:basalt
fill 133 227 301 135 228 301 minecraft:basalt
fill 133 227 304 135 227 304 minecraft:basalt
setblock 133 227 307 minecraft:basalt
setblock 135 227 288 minecraft:magma_block
setblock 135 227 291 minecraft:magma_block
setblock 135 227 294 minecraft:magma_block
setblock 135 227 297 minecraft:magma_block
setblock 135 227 300 minecraft:magma_block
setblock 135 227 303 minecraft:magma_block
fill 94 228 275 94 229 276 minecraft:red_concrete
fill 94 228 277 94 229 278 minecraft:white_concrete
fill 94 228 279 94 229 280 minecraft:red_concrete
fill 94 228 281 94 229 282 minecraft:white_concrete
fill 94 228 283 94 229 284 minecraft:red_concrete
fill 94 228 285 94 229 286 minecraft:white_concrete
fill 94 228 287 94 229 288 minecraft:red_concrete
fill 94 228 289 94 229 290 minecraft:white_concrete
fill 94 228 291 94 229 292 minecraft:red_concrete
fill 94 228 293 94 229 294 minecraft:white_concrete
fill 94 228 295 94 229 296 minecraft:red_concrete
fill 94 228 297 94 229 298 minecraft:white_concrete
fill 94 228 299 94 229 300 minecraft:red_concrete
fill 94 228 301 94 229 302 minecraft:white_concrete
fill 94 228 303 94 229 304 minecraft:red_concrete
fill 94 228 305 94 229 306 minecraft:white_concrete
fill 94 228 307 94 229 308 minecraft:red_concrete
fill 94 228 309 94 229 310 minecraft:white_concrete
fill 94 228 311 94 229 312 minecraft:red_concrete
fill 94 228 313 94 229 314 minecraft:white_concrete
fill 94 228 315 94 229 316 minecraft:red_concrete
fill 95 228 275 95 229 275 minecraft:red_concrete
fill 95 228 280 95 228 311 minecraft:basalt
setblock 95 228 312 minecraft:magma_block
fill 95 228 317 95 229 317 minecraft:red_concrete
fill 96 228 275 97 229 275 minecraft:white_concrete
fill 96 228 279 96 228 280 minecraft:basalt
fill 96 228 283 96 231 283 minecraft:basalt
fill 96 228 286 96 233 286 minecraft:basalt
fill 96 228 289 96 235 289 minecraft:basalt
fill 96 228 292 97 235 292 minecraft:basalt
fill 96 228 295 96 235 295 minecraft:basalt
fill 96 228 298 97 228 298 minecraft:basalt
fill 96 228 301 96 235 301 minecraft:basalt
fill 96 228 304 96 234 304 minecraft:basalt
fill 96 228 307 96 232 307 minecraft:basalt
fill 96 228 310 96 230 310 minecraft:basalt
setblock 96 228 313 minecraft:basalt
fill 96 228 317 97 229 317 minecraft:white_concrete
fill 97 228 278 98 228 279 minecraft:basalt
fill 97 228 293 97 237 294 minecraft:basalt
fill 97 228 299 97 237 300 minecraft:basalt
fill 97 228 314 102 228 314 minecraft:basalt
fill 98 228 275 99 229 275 minecraft:red_concrete
fill 98 228 277 105 228 277 minecraft:basalt
fill 98 228 289 98 237 289 minecraft:basalt
setblock 98 228 290 minecraft:magma_block
setblock 98 228 302 minecraft:magma_block
fill 98 228 303 98 237 303 minecraft:basalt
fill 98 228 315 99 228 315 minecraft:basalt
fill 98 228 317 99 229 317 minecraft:red_concrete
fill 99 228 279 99 230 279 minecraft:basalt
fill 99 228 282 99 233 282 minecraft:basalt
fill 99 228 285 99 235 285 minecraft:basalt
fill 99 228 288 99 237 288 minecraft:basalt
fill 99 228 304 99 237 304 minecraft:basalt
fill 99 228 306 100 235 306 minecraft:basalt
fill 99 228 309 99 234 309 minecraft:basalt
fill 99 228 312 99 231 312 minecraft:basalt
fill 100 228 275 101 229 275 minecraft:white_concrete
fill 100 228 286 100 237 286 minecraft:basalt
setblock 100 228 316 minecraft:basalt
fill 100 228 317 101 229 317 minecraft:white_concrete
fill 101 228 285 101 237 285 minecraft:basalt
setblock 101 228 307 minecraft:magma_block
setblock 101 228 316 minecraft:magma_block
fill 102 228 275 103 229 275 minecraft:red_concrete
fill 102 228 278 102 231 278 minecraft:basalt
fill 102 228 281 106 234 281 minecraft:basalt
fill 102 228 284 102 237 284 minecraft:basalt
fill 102 228 308 102 237 308 minecraft:basalt
fill 102 228 311 106 234 311 minecraft:basalt
fill 102 228 316 105 229 316 minecraft:basalt
fill 102 228 317 103 229 317 minecraft:red_concrete
fill 104 228 275 105 229 275 minecraft:white_concrete
fill 104 228 283 104 237 283 minecraft:basalt
setblock 104 228 309 minecraft:magma_block
fill 104 228 317 105 229 317 minecraft:white_concrete
fill 105 228 280 105 235 280 minecraft:basalt
fill 105 228 282 106 237 282 minecraft:basalt
fill 105 228 310 106 228 310 minecraft:basalt
fill 105 228 313 105 234 313 minecraft:basalt
fill 106 228 275 107 229 275 minecraft:red_concrete
fill 106 228 317 107 229 317 minecraft:red_concrete
setblock 107 228 281 minecraft:magma_block
setblock 107 228 311 minecraft:magma_block
fill 108 228 275 109 229 275 minecraft:white_concrete
fill 108 228 276 108 231 276 minecraft:basalt
fill 108 228 279 108 235 279 minecraft:basalt
fill 108 228 281 110 237 281 minecraft:basalt
fill 108 228 311 110 235 312 minecraft:basalt
fill 108 228 315 108 232 315 minecraft:basalt
fill 108 228 317 109 229 317 minecraft:white_concrete
fill 110 228 275 111 229 275 minecraft:red_concrete
fill 110 228 317 111 229 317 minecraft:red_concrete
fill 111 228 278 111 234 278 minecraft:basalt
fill 111 228 312 112 236 312 minecraft:basalt
fill 111 228 314 111 234 314 minecraft:basalt
fill 112 228 275 113 229 275 minecraft:white_concrete
fill 112 228 317 113 229 317 minecraft:white_concrete
setblock 113 228 312 minecraft:magma_block
fill 114 228 275 115 229 275 minecraft:red_concrete
fill 114 228 277 114 233 277 minecraft:basalt
fill 114 228 280 114 235 281 minecraft:basalt
fill 114 228 311 114 235 313 minecraft:basalt
fill 114 228 316 114 232 316 minecraft:basalt
fill 114 228 317 115 229 317 minecraft:red_concrete
fill 115 228 281 115 237 281 minecraft:basalt
fill 115 228 311 115 236 312 minecraft:basalt
fill 116 228 275 117 229 275 minecraft:white_concrete
setblock 116 228 281 minecraft:magma_block
setblock 116 228 311 minecraft:magma_block
fill 116 228 312 117 235 312 minecraft:basalt
fill 116 228 317 117 229 317 minecraft:white_concrete
fill 117 228 276 124 228 276 minecraft:basalt
fill 117 228 279 117 234 279 minecraft:basalt
fill 117 228 315 117 232 315 minecraft:basalt
fill 118 228 275 119 229 275 minecraft:red_concrete
fill 118 228 282 119 228 282 minecraft:basalt
fill 118 228 310 118 237 310 minecraft:basalt
fill 118 228 317 119 229 317 minecraft:red_concrete
setblock 119 228 310 minecraft:magma_block
fill 120 228 275 121 229 275 minecraft:white_concrete
fill 120 228 278 127 228 278 minecraft:basalt
fill 120 228 281 120 235 281 minecraft:basalt
fill 120 228 283 120 237 283 minecraft:basalt
fill 120 228 309 120 237 309 minecraft:basalt
fill 120 228 311 120 235 311 minecraft:basalt
fill 120 228 314 127 228 314 minecraft:basalt
fill 120 228 317 121 229 317 minecraft:white_concrete
fill 122 228 275 123 229 275 minecraft:red_concrete
fill 122 228 284 122 237 284 minecraft:basalt
fill 122 228 308 122 237 308 minecraft:basalt
fill 122 228 317 123 229 317 minecraft:red_concrete
fill 123 228 277 126 228 277 minecraft:basalt
fill 123 228 280 129 228 280 minecraft:basalt
fill 123 228 283 123 235 283 minecraft:basalt
fill 123 228 285 123 237 285 minecraft:basalt
fill 123 228 307 123 237 307 minecraft:basalt
fill 123 228 310 123 234 310 minecraft:basalt
fill 123 228 313 127 229 313 minecraft:basalt
fill 123 228 316 124 228 316 minecraft:basalt
fill 124 228 275 125 229 275 minecraft:white_concrete
fill 124 228 286 128 233 286 minecraft:basalt
fill 124 228 306 133 228 306 minecraft:basalt
fill 124 228 317 125 229 317 minecraft:white_concrete
setblock 125 228 287 minecraft:magma_block
fill 125 228 288 126 235 288 minecraft:basalt
fill 125 228 304 125 237 304 minecraft:basalt
setblock 125 228 305 minecraft:magma_block
fill 126 228 275 127 229 275 minecraft:red_concrete
fill 126 228 279 128 228 279 minecraft:basalt
fill 126 228 282 130 229 282 minecraft:basalt
fill 126 228 285 132 228 285 minecraft:basalt
fill 126 228 287 133 228 287 minecraft:basalt
fill 126 228 289 126 237 290 minecraft:basalt
fill 126 228 302 126 237 303 minecraft:basalt
fill 126 228 309 130 229 309 minecraft:basalt
fill 126 228 312 129 228 312 minecraft:basalt
setblock 126 228 315 minecraft:basalt
fill 126 228 317 127 229 317 minecraft:red_concrete
fill 127 228 292 128 228 294 minecraft:basalt
fill 127 228 298 128 236 300 minecraft:basalt
fill 128 228 275 129 229 275 minecraft:white_concrete
setblock 128 228 295 minecraft:magma_block
fill 128 228 296 128 236 297 minecraft:basalt
setblock 128 228 313 minecraft:magma_block
fill 128 228 317 129 229 317 minecraft:white_concrete
fill 129 228 281 130 228 281 minecraft:basalt
fill 129 228 284 132 228 284 minecraft:basalt
fill 129 228 290 133 230 290 minecraft:basalt
fill 129 228 293 129 235 293 minecraft:basalt
fill 129 228 296 129 235 296 minecraft:basalt
fill 129 228 299 129 235 299 minecraft:basalt
fill 129 228 302 133 230 302 minecraft:basalt
fill 129 228 305 133 228 305 minecraft:basalt
fill 129 228 308 132 228 308 minecraft:basalt
fill 129 228 311 130 228 311 minecraft:basalt
fill 130 228 275 131 229 275 minecraft:red_concrete
fill 130 228 317 131 229 317 minecraft:red_concrete
setblock 131 228 282 minecraft:magma_block
setblock 131 228 309 minecraft:magma_block
fill 132 228 275 133 229 275 minecraft:white_concrete
fill 132 228 286 133 228 286 minecraft:basalt
fill 132 228 289 134 228 289 minecraft:basalt
fill 132 228 292 132 231 292 minecraft:basalt
fill 132 228 295 132 232 295 minecraft:basalt
fill 132 228 298 132 232 298 minecraft:basalt
fill 132 228 301 132 231 301 minecraft:basalt
fill 132 228 304 134 228 304 minecraft:basalt
setblock 132 228 307 minecraft:basalt
fill 132 228 317 133 229 317 minecraft:white_concrete
fill 134 228 275 135 229 275 minecraft:red_concrete
setblock 134 228 290 minecraft:magma_block
setblock 134 228 302 minecraft:magma_block
fill 134 228 317 135 229 317 minecraft:red_concrete
setblock 135 228 291 minecraft:basalt
setblock 135 228 294 minecraft:basalt
setblock 135 228 297 minecraft:basalt
setblock 135 228 300 minecraft:basalt
fill 136 228 276 136 229 276 minecraft:red_concrete
fill 136 228 277 136 229 278 minecraft:white_concrete
fill 136 228 279 136 229 280 minecraft:red_concrete
fill 136 228 281 136 229 282 minecraft:white_concrete
fill 136 228 283 136 229 284 minecraft:red_concrete
fill 136 228 285 136 229 286 minecraft:white_concrete
fill 136 228 287 136 229 288 minecraft:red_concrete
fill 136 228 289 136 229 290 minecraft:white_concrete
fill 136 228 291 136 229 292 minecraft:red_concrete
fill 136 228 293 136 229 294 minecraft:white_concrete
fill 136 228 295 136 229 296 minecraft:red_concrete
fill 136 228 297 136 229 298 minecraft:white_concrete
fill 136 228 299 136 229 300 minecraft:red_concrete
fill 136 228 301 136 229 302 minecraft:white_concrete
fill 136 228 303 136 229 304 minecraft:red_concrete
fill 136 228 305 136 229 306 minecraft:white_concrete
fill 136 228 307 136 229 308 minecraft:red_concrete
fill 136 228 309 136 229 310 minecraft:white_concrete
fill 136 228 311 136 229 312 minecraft:red_concrete
fill 136 228 313 136 229 314 minecraft:white_concrete
fill 136 228 315 136 229 316 minecraft:red_concrete
fill 136 228 317 136 229 317 minecraft:white_concrete
fill 95 229 281 95 229 311 minecraft:basalt
setblock 96 229 280 minecraft:basalt
fill 96 229 298 96 235 298 minecraft:basalt
fill 97 229 279 98 229 279 minecraft:basalt
setblock 97 229 295 minecraft:magma_block
fill 97 229 296 97 237 297 minecraft:basalt
setblock 97 229 298 minecraft:magma_block
setblock 97 229 313 minecraft:magma_block
setblock 98 229 278 minecraft:basalt
fill 98 229 290 98 236 292 minecraft:basalt
fill 98 229 300 98 236 302 minecraft:basalt
fill 98 229 313 102 229 314 minecraft:basalt
fill 99 229 289 99 238 289 minecraft:basalt
fill 99 229 303 99 238 303 minecraft:basalt
fill 100 229 277 105 229 277 minecraft:basalt
fill 100 229 287 100 237 287 minecraft:basalt
fill 100 229 305 100 237 305 minecraft:basalt
setblock 100 229 315 minecraft:magma_block
fill 101 229 286 101 238 286 minecraft:basalt
fill 101 229 306 101 236 307 minecraft:basalt
fill 101 229 315 107 229 315 minecraft:basalt
fill 102 229 276 107 229 276 minecraft:basalt
fill 102 229 285 102 238 285 minecraft:basalt
fill 102 229 307 102 238 307 minecraft:basalt
setblock 103 229 284 minecraft:magma_block
setblock 103 229 308 minecraft:magma_block
fill 103 229 313 104 233 313 minecraft:basalt
fill 104 229 309 105 236 309 minecraft:basalt
fill 105 229 283 105 238 283 minecraft:basalt
fill 105 229 310 105 237 310 minecraft:basalt
setblock 106 229 310 minecraft:magma_block
fill 107 229 281 107 236 282 minecraft:basalt
fill 107 229 310 107 236 311 minecraft:basalt
fill 108 229 282 108 238 282 minecraft:basalt
fill 108 229 310 108 238 310 minecraft:basalt
fill 111 229 281 111 237 281 minecraft:basalt
fill 111 229 311 111 237 311 minecraft:basalt
setblock 112 229 281 minecraft:magma_block
setblock 112 229 311 minecraft:magma_block
fill 113 229 281 113 237 281 minecraft:basalt
fill 113 229 311 113 236 312 minecraft:basalt
fill 116 229 281 116 236 282 minecraft:basalt
fill 116 229 310 116 236 311 minecraft:basalt
fill 117 229 276 122 229 276 minecraft:basalt
fill 117 229 282 117 238 282 minecraft:basalt
fill 117 229 310 117 238 310 minecraft:basalt
setblock 118 229 282 minecraft:magma_block
fill 118 229 315 124 229 315 minecraft:basalt
fill 119 229 282 119 237 283 minecraft:basalt
fill 119 229 309 119 236 310 minecraft:basalt
fill 120 229 278 126 229 278 minecraft:basalt
fill 120 229 314 126 229 314 minecraft:basalt
setblock 121 229 284 minecraft:magma_block
setblock 121 229 308 minecraft:magma_block
fill 122 229 285 122 238 285 minecraft:basalt
fill 122 229 307 122 238 307 minecraft:basalt
setblock 123 229 277 minecraft:basalt
fill 123 229 280 128 229 280 minecraft:basalt
fill 123 229 286 123 238 286 minecraft:basalt
fill 123 229 306 132 229 306 minecraft:basalt
setblock 124 229 277 minecraft:magma_block
fill 124 229 283 130 229 283 minecraft:basalt
fill 124 229 287 132 230 287 minecraft:basalt
fill 124 229 305 125 236 305 minecraft:basalt
fill 124 229 310 130 229 310 minecraft:basalt
fill 125 229 289 125 238 289 minecraft:basalt
fill 125 229 303 125 238 303 minecraft:basalt
setblock 126 229 279 minecraft:basalt
fill 126 229 285 131 229 285 minecraft:basalt
fill 126 229 291 126 238 292 minecraft:basalt
fill 126 229 300 126 238 301 minecraft:basalt
fill 126 229 312 128 229 312 minecraft:basalt
setblock 127 229 279 minecraft:magma_block
fill 127 229 292 128 236 293 minecraft:basalt
setblock 127 229 294 minecraft:magma_block
fill 127 229 295 127 237 296 minecraft:basalt
setblock 127 229 297 minecraft:magma_block
fill 128 229 294 128 236 295 minecraft:basalt
setblock 129 229 281 minecraft:basalt
fill 129 229 284 131 229 284 minecraft:basalt
fill 129 229 305 132 230 305 minecraft:basalt
fill 129 229 308 131 229 308 minecraft:basalt
setblock 129 229 311 minecraft:basalt
fill 130 229 293 134 229 293 minecraft:basalt
fill 130 229 296 134 229 296 minecraft:basalt
fill 130 229 299 134 229 299 minecraft:basalt
setblock 132 229 286 minecraft:basalt
fill 132 229 288 132 229 289 minecraft:basalt
fill 132 229 303 132 229 304 minecraft:basalt
setblock 133 229 288 minecraft:basalt
setblock 133 229 289 minecraft:magma_block
fill 133 229 292 134 229 292 minecraft:basalt
fill 133 229 295 134 229 295 minecraft:basalt
fill 133 229 298 134 229 298 minecraft:basalt
fill 133 229 301 134 229 301 minecraft:basalt
setblock 133 229 303 minecraft:basalt
setblock 133 229 304 minecraft:magma_block
setblock 134 229 290 minecraft:basalt
setblock 134 229 302 minecraft:basalt
fill 94 230 275 94 231 276 minecraft:white_concrete
fill 94 230 277 94 231 278 minecraft:red_concrete
fill 94 230 279 94 231 279 minecraft:white_concrete
fill 94 230 280 94 233 280 minecraft:shroomlight
fill 94 230 281 94 231 282 minecraft:red_concrete
fill 94 230 283 94 231 284 minecraft:white_concrete
fill 94 230 285 94 231 286 minecraft:red_concrete
fill 94 230 287 94 231 287 minecraft:white_concrete
fill 94 230 288 94 233 288 minecraft:shroomlight
fill 94 230 289 94 231 290 minecraft:red_concrete
fill 94 230 291 94 231 292 minecraft:white_concrete
fill 94 230 293 94 231 294 minecraft:red_concrete
fill 94 230 295 94 231 295 minecraft:white_concrete
fill 94 230 296 94 233 296 minecraft:shroomlight
fill 94 230 297 94 231 298 minecraft:red_concrete
fill 94 230 299 94 231 300 minecraft:white_concrete
fill 94 230 301 94 231 302 minecraft:red_concrete
fill 94 230 303 94 231 303 minecraft:white_concrete
fill 94 230 304 94 233 304 minecraft:shroomlight
fill 94 230 305 94 231 306 minecraft:red_concrete
fill 94 230 307 94 231 308 minecraft:white_concrete
fill 94 230 309 94 231 310 minecraft:red_concrete
fill 94 230 311 94 231 311 minecraft:white_concrete
fill 94 230 312 94 233 312 minecraft:shroomlight
fill 94 230 313 94 231 314 minecraft:red_concrete
fill 94 230 315 94 231 316 minecraft:white_concrete
fill 95 230 275 95 231 275 minecraft:white_concrete
fill 95 230 282 95 272 282 minecraft:red_terracotta
fill 95 230 283 95 230 309 minecraft:basalt
fill 95 230 314 95 272 315 minecraft:red_terracotta
fill 95 230 317 95 231 317 minecraft:white_concrete
fill 96 230 275 97 231 275 minecraft:red_concrete
fill 96 230 276 97 272 276 minecraft:red_terracotta
fill 96 230 281 98 230 281 minecraft:basalt
setblock 96 230 282 minecraft:magma_block
fill 96 230 311 98 230 311 minecraft:basalt
fill 96 230 317 96 231 317 minecraft:red_concrete
setblock 97 230 278 minecraft:light[level=12]
fill 97 230 282 98 231 282 minecraft:basalt
fill 97 230 295 98 230 295 minecraft:basalt
fill 97 230 298 98 230 298 minecraft:basalt
fill 97 230 312 98 230 312 minecraft:basalt
setblock 97 230 313 minecraft:light[level=12]
fill 97 230 317 97 233 317 minecraft:shroomlight
fill 98 230 275 99 231 275 minecraft:white_concrete
fill 98 230 293 98 238 294 minecraft:basalt
fill 98 230 296 98 239 297 minecraft:basalt
fill 98 230 299 98 238 299 minecraft:basalt
fill 98 230 317 99 231 317 minecraft:white_concrete
setblock 99 230 290 minecraft:magma_block
fill 99 230 291 99 239 291 minecraft:basalt
fill 99 230 301 99 239 301 minecraft:basalt
setblock 99 230 302 minecraft:magma_block
fill 99 230 313 102 230 313 minecraft:basalt
fill 100 230 275 100 231 275 minecraft:red_concrete
fill 100 230 278 101 230 278 minecraft:basalt
fill 100 230 288 100 237 289 minecraft:basalt
fill 100 230 303 100 238 304 minecraft:basalt
fill 100 230 314 102 230 314 minecraft:basalt
fill 100 230 317 101 231 317 minecraft:red_concrete
fill 101 230 275 101 233 275 minecraft:shroomlight
fill 101 230 287 101 238 287 minecraft:basalt
fill 101 230 305 101 238 305 minecraft:basalt
fill 101 230 316 102 272 316 minecraft:red_terracotta
fill 102 230 275 103 231 275 minecraft:white_concrete
setblock 102 230 277 minecraft:magma_block
setblock 102 230 286 minecraft:magma_block
fill 102 230 306 102 238 306 minecraft:basalt
fill 102 230 315 107 230 315 minecraft:basalt
fill 102 230 317 103 231 317 minecraft:white_concrete
fill 103 230 276 104 230 277 minecraft:basalt
fill 103 230 284 103 237 285 minecraft:basalt
fill 103 230 307 103 237 308 minecraft:basalt
fill 103 230 316 105 230 316 minecraft:basalt
fill 104 230 275 105 231 275 minecraft:red_concrete
fill 104 230 284 105 238 284 minecraft:basalt
setblock 104 230 285 minecraft:light[level=12]
setblock 104 230 292 minecraft:light[level=12]
setblock 104 230 299 minecraft:light[level=12]
setblock 104 230 306 minecraft:light[level=12]
fill 104 230 308 105 238 308 minecraft:basalt
fill 104 230 317 104 231 317 minecraft:red_concrete
setblock 105 230 276 minecraft:magma_block
fill 105 230 277 105 231 277 minecraft:basalt
fill 105 230 317 105 233 317 minecraft:shroomlight
fill 106 230 275 107 231 275 minecraft:white_concrete
fill 106 230 276 107 231 276 minecraft:basalt
fill 106 230 283 107 230 283 minecraft:basalt
fill 106 230 309 106 237 310 minecraft:basalt
fill 106 230 317 107 231 317 minecraft:white_concrete
fill 107 230 309 107 239 309 minecraft:basalt
fill 108 230 275 108 231 275 minecraft:red_concrete
fill 108 230 317 109 231 317 minecraft:red_concrete
fill 109 230 275 109 233 275 minecraft:shroomlight
fill 109 230 282 113 230 282 minecraft:basalt
fill 109 230 310 110 238 310 minecraft:basalt
fill 110 230 275 111 231 275 minecraft:white_concrete
fill 110 230 317 111 231 317 minecraft:white_concrete
setblock 111 230 285 minecraft:light[level=12]
setblock 111 230 292 minecraft:light[level=12]
setblock 111 230 299 minecraft:light[level=12]
setblock 111 230 306 minecraft:light[level=12]
setblock 111 230 310 minecraft:magma_block
fill 112 230 275 113 231 275 minecraft:red_concrete
fill 112 230 281 112 237 281 minecraft:basalt
fill 112 230 310 112 237 311 minecraft:basalt
fill 112 230 317 112 231 317 minecraft:red_concrete
fill 113 230 310 115 237 310 minecraft:basalt
fill 113 230 317 113 233 317 minecraft:shroomlight
fill 114 230 275 115 231 275 minecraft:white_concrete
setblock 114 230 282 minecraft:magma_block
fill 114 230 317 115 231 317 minecraft:white_concrete
fill 115 230 282 115 238 282 minecraft:basalt
fill 115 230 316 119 230 316 minecraft:basalt
fill 116 230 275 116 231 275 minecraft:red_concrete
fill 116 230 317 117 231 317 minecraft:red_concrete
fill 117 230 275 117 233 275 minecraft:shroomlight
fill 117 230 276 121 230 276 minecraft:basalt
fill 117 230 283 118 238 283 minecraft:basalt
fill 117 230 309 118 237 309 minecraft:basalt
fill 118 230 275 119 231 275 minecraft:white_concrete
fill 118 230 282 118 237 282 minecraft:basalt
setblock 118 230 285 minecraft:light[level=12]
setblock 118 230 292 minecraft:light[level=12]
setblock 118 230 299 minecraft:light[level=12]
setblock 118 230 306 minecraft:light[level=12]
fill 118 230 315 122 230 315 minecraft:basalt
fill 118 230 317 119 231 317 minecraft:white_concrete
fill 119 230 284 121 237 284 minecraft:basalt
fill 119 230 308 121 237 308 minecraft:basalt
fill 120 230 275 121 231 275 minecraft:red_concrete
fill 120 230 278 124 230 278 minecraft:basalt
fill 120 230 314 124 230 314 minecraft:basalt
setblock 120 230 316 minecraft:magma_block
fill 120 230 317 120 231 317 minecraft:red_concrete
fill 121 230 285 121 238 285 minecraft:basalt
fill 121 230 307 121 238 307 minecraft:basalt
setblock 121 230 316 minecraft:basalt
fill 121 230 317 121 233 317 minecraft:shroomlight
fill 122 230 275 123 231 275 minecraft:white_concrete
fill 122 230 286 122 238 286 minecraft:basalt
fill 122 230 306 131 230 306 minecraft:basalt
fill 122 230 317 123 231 317 minecraft:white_concrete
fill 123 230 280 127 230 280 minecraft:basalt
fill 123 230 287 123 238 287 minecraft:basalt
fill 123 230 305 123 238 305 minecraft:basalt
fill 123 230 313 125 230 313 minecraft:basalt
fill 124 230 275 124 231 275 minecraft:red_concrete
fill 124 230 283 128 231 283 minecraft:basalt
fill 124 230 288 124 238 289 minecraft:basalt
fill 124 230 303 124 237 304 minecraft:basalt
fill 124 230 307 130 230 307 minecraft:basalt
fill 124 230 310 128 230 310 minecraft:basalt
fill 124 230 317 125 231 317 minecraft:red_concrete
fill 125 230 275 125 233 275 minecraft:shroomlight
setblock 125 230 278 minecraft:light[level=12]
fill 125 230 290 125 238 291 minecraft:basalt
setblock 125 230 292 minecraft:light[level=12]
setblock 125 230 299 minecraft:light[level=12]
fill 125 230 301 125 230 302 minecraft:basalt
fill 125 230 316 126 272 316 minecraft:red_terracotta
fill 126 230 275 127 231 275 minecraft:white_concrete
fill 126 230 282 128 230 282 minecraft:basalt
fill 126 230 285 130 230 285 minecraft:basalt
setblock 126 230 293 minecraft:magma_block
fill 126 230 294 126 238 295 minecraft:basalt
setblock 126 230 296 minecraft:magma_block
fill 126 230 297 126 238 298 minecraft:basalt
setblock 126 230 299 minecraft:magma_block
fill 126 230 309 129 230 309 minecraft:basalt
fill 126 230 312 127 230 312 minecraft:basalt
fill 126 230 317 127 231 317 minecraft:white_concrete
fill 127 230 294 127 237 294 minecraft:basalt
fill 127 230 297 127 237 297 minecraft:basalt
fill 128 230 275 129 231 275 minecraft:red_concrete
fill 128 230 276 129 272 276 minecraft:red_terracotta
fill 128 230 317 128 231 317 minecraft:red_concrete
setblock 129 230 283 minecraft:magma_block
fill 129 230 284 130 230 284 minecraft:basalt
fill 129 230 308 130 230 308 minecraft:basalt
fill 129 230 317 129 233 317 minecraft:shroomlight
fill 130 230 275 131 231 275 minecraft:white_concrete
fill 130 230 293 133 230 293 minecraft:basalt
fill 130 230 296 133 231 296 minecraft:basalt
fill 130 230 299 133 230 299 minecraft:basalt
fill 130 230 317 131 231 317 minecraft:white_concrete
fill 132 230 275 132 231 275 minecraft:red_concrete
setblock 132 230 278 minecraft:light[level=12]
setblock 132 230 285 minecraft:light[level=12]
setblock 132 230 288 minecraft:magma_block
setblock 132 230 289 minecraft:basalt
fill 132 230 291 133 230 291 minecraft:basalt
fill 132 230 294 133 230 294 minecraft:basalt
fill 132 230 297 133 231 297 minecraft:basalt
fill 132 230 300 133 230 300 minecraft:basalt
setblock 132 230 303 minecraft:magma_block
setblock 132 230 304 minecraft:basalt
setblock 132 230 306 minecraft:light[level=12]
setblock 132 230 313 minecraft:light[level=12]
fill 132 230 317 133 231 317 minecraft:red_concrete
fill 133 230 275 133 233 275 minecraft:shroomlight
setblock 133 230 292 minecraft:basalt
fill 133 230 295 133 231 295 minecraft:basalt
setblock 133 230 298 minecraft:basalt
setblock 133 230 301 minecraft:basalt
fill 133 230 316 134 272 316 minecraft:red_terracotta
fill 134 230 275 135 231 275 minecraft:white_concrete
fill 134 230 317 135 231 317 minecraft:white_concrete
fill 135 230 277 135 272 278 minecraft:red_terracotta
fill 135 230 285 135 272 286 minecraft:red_terracotta
fill 135 230 293 135 272 294 minecraft:red_terracotta
fill 135 230 301 135 261 302 minecraft:red_terracotta
fill 135 230 309 135 272 310 minecraft:red_terracotta
fill 136 230 276 136 231 276 minecraft:white_concrete
fill 136 230 277 136 231 278 minecraft:red_concrete
fill 136 230 279 136 231 279 minecraft:white_concrete
fill 136 230 280 136 233 280 minecraft:shroomlight
fill 136 230 281 136 231 282 minecraft:red_concrete
fill 136 230 283 136 231 284 minecraft:white_concrete
fill 136 230 285 136 231 286 minecraft:red_concrete
fill 136 230 287 136 231 287 minecraft:white_concrete
fill 136 230 288 136 233 288 minecraft:shroomlight
fill 136 230 289 136 231 290 minecraft:red_concrete
fill 136 230 291 136 231 292 minecraft:white_concrete
fill 136 230 293 136 231 294 minecraft:red_concrete
fill 136 230 295 136 231 295 minecraft:white_concrete
fill 136 230 296 136 233 296 minecraft:shroomlight
fill 136 230 297 136 231 298 minecraft:red_concrete
fill 136 230 299 136 231 300 minecraft:white_concrete
fill 136 230 301 136 231 302 minecraft:red_concrete
fill 136 230 303 136 231 303 minecraft:white_concrete
fill 136 230 304 136 233 304 minecraft:shroomlight
fill 136 230 305 136 231 306 minecraft:red_concrete
fill 136 230 307 136 231 308 minecraft:white_concrete
fill 136 230 309 136 231 310 minecraft:red_concrete
fill 136 230 311 136 231 311 minecraft:white_concrete
fill 136 230 312 136 233 312 minecraft:shroomlight
fill 136 230 313 136 231 314 minecraft:red_concrete
fill 136 230 315 136 231 316 minecraft:white_concrete
fill 136 230 317 136 231 317 minecraft:red_concrete
fill 95 231 283 95 272 283 minecraft:red_terracotta
setblock 95 231 284 minecraft:magma_block
fill 95 231 285 95 231 307 minecraft:basalt
setblock 95 231 308 minecraft:magma_block
fill 97 231 295 97 237 295 minecraft:basalt
fill 97 231 298 97 237 298 minecraft:basalt
setblock 98 231 281 minecraft:basalt
setblock 98 231 295 minecraft:magma_block
setblock 98 231 298 minecraft:magma_block
setblock 98 231 311 minecraft:basalt
fill 99 231 280 104 231 280 minecraft:basalt
fill 99 231 290 100 231 290 minecraft:basalt
fill 99 231 292 99 238 293 minecraft:basalt
fill 99 231 299 99 238 300 minecraft:basalt
fill 99 231 302 100 231 302 minecraft:basalt
setblock 100 231 279 minecraft:basalt
fill 100 231 313 102 231 313 minecraft:basalt
setblock 101 231 279 minecraft:magma_block
setblock 101 231 288 minecraft:magma_block
fill 101 231 304 101 239 304 minecraft:basalt
fill 102 231 279 107 232 279 minecraft:basalt
fill 102 231 286 102 238 287 minecraft:basalt
fill 102 231 305 102 239 305 minecraft:basalt
setblock 102 231 314 minecraft:basalt
fill 103 231 277 104 231 277 minecraft:basalt
fill 103 231 286 103 239 286 minecraft:basalt
fill 103 231 306 103 239 306 minecraft:basalt
fill 103 231 315 107 231 315 minecraft:basalt
fill 104 231 276 105 272 276 minecraft:red_terracotta
fill 104 231 285 104 239 285 minecraft:basalt
fill 104 231 307 104 239 307 minecraft:basalt
fill 106 231 283 106 237 284 minecraft:basalt
fill 106 231 308 106 239 308 minecraft:basalt
setblock 106 231 316 minecraft:basalt
setblock 107 231 283 minecraft:magma_block
setblock 107 231 316 minecraft:magma_block
fill 108 231 283 109 239 283 minecraft:basalt
fill 108 231 309 109 239 309 minecraft:basalt
fill 108 231 316 113 231 316 minecraft:basalt
setblock 109 231 276 minecraft:basalt
fill 109 231 282 109 237 282 minecraft:basalt
setblock 110 231 276 minecraft:magma_block
setblock 110 231 282 minecraft:magma_block
fill 111 231 276 118 231 276 minecraft:basalt
fill 111 231 282 114 238 282 minecraft:basalt
fill 111 231 310 111 238 310 minecraft:basalt
fill 115 231 277 121 231 277 minecraft:basalt
fill 115 231 283 115 239 283 minecraft:basalt
fill 115 231 309 116 231 309 minecraft:basalt
setblock 115 231 316 minecraft:basalt
setblock 116 231 283 minecraft:magma_block
setblock 116 231 316 minecraft:magma_block
fill 117 231 316 118 231 316 minecraft:basalt
fill 118 231 279 124 231 279 minecraft:basalt
setblock 118 231 284 minecraft:basalt
setblock 118 231 308 minecraft:basalt
fill 118 231 315 118 232 315 minecraft:basalt
setblock 119 231 315 minecraft:magma_block
fill 120 231 276 121 272 276 minecraft:red_terracotta
fill 120 231 278 121 232 278 minecraft:basalt
fill 120 231 285 120 239 285 minecraft:basalt
fill 120 231 307 120 238 307 minecraft:basalt
fill 120 231 314 121 231 315 minecraft:basalt
fill 121 231 281 126 231 281 minecraft:basalt
fill 121 231 286 121 239 286 minecraft:basalt
fill 121 231 306 130 231 306 minecraft:basalt
fill 121 231 311 126 231 311 minecraft:basalt
setblock 122 231 278 minecraft:magma_block
setblock 122 231 287 minecraft:magma_block
setblock 122 231 305 minecraft:magma_block
setblock 122 231 314 minecraft:magma_block
fill 123 231 280 124 232 280 minecraft:basalt
fill 123 231 288 123 238 288 minecraft:basalt
fill 123 231 304 123 239 304 minecraft:basalt
fill 123 231 313 124 231 313 minecraft:basalt
fill 124 231 287 130 232 287 minecraft:basalt
fill 124 231 290 124 239 290 minecraft:basalt
fill 124 231 302 125 238 302 minecraft:basalt
fill 124 231 307 129 231 307 minecraft:basalt
fill 124 231 310 127 231 310 minecraft:basalt
setblock 125 231 280 minecraft:magma_block
setblock 125 231 292 minecraft:magma_block
fill 125 231 293 126 238 293 minecraft:basalt
fill 125 231 299 125 239 300 minecraft:basalt
setblock 125 231 301 minecraft:magma_block
fill 126 231 282 127 231 282 minecraft:basalt
fill 126 231 285 129 231 285 minecraft:basalt
fill 126 231 296 126 238 296 minecraft:basalt
fill 126 231 299 126 238 299 minecraft:basalt
fill 126 231 309 127 232 309 minecraft:basalt
setblock 128 231 309 minecraft:magma_block
setblock 129 231 284 minecraft:basalt
fill 129 231 286 130 231 286 minecraft:basalt
fill 129 231 290 132 231 290 minecraft:basalt
fill 129 231 302 132 231 302 minecraft:basalt
fill 129 231 305 130 232 305 minecraft:basalt
setblock 129 231 308 minecraft:basalt
fill 130 231 293 132 231 293 minecraft:basalt
fill 130 231 299 132 231 299 minecraft:basalt
schedule function dropper:buildpart/62_5 1t
