setblock 473 85 286 minecraft:light[level=13]
setblock 473 85 291 minecraft:cobbled_deepslate
fill 473 85 292 473 86 292 minecraft:deepslate_tiles
setblock 473 85 294 minecraft:light[level=13]
setblock 473 85 299 minecraft:light[level=12]
setblock 473 85 302 minecraft:light[level=13]
setblock 473 85 306 minecraft:light[level=12]
setblock 473 85 310 minecraft:light[level=13]
setblock 473 85 313 minecraft:light[level=12]
fill 473 85 314 473 86 314 minecraft:deepslate_tiles
setblock 473 85 316 minecraft:cobbled_deepslate
fill 474 85 276 474 88 276 minecraft:deepslate_tiles
setblock 474 85 315 minecraft:cobbled_deepslate
fill 474 85 316 474 88 316 minecraft:deepslate_tiles
fill 475 85 315 475 88 315 minecraft:deepslate_tiles
setblock 476 85 277 minecraft:deepslate_tiles
fill 477 85 302 477 85 314 minecraft:white_wool
setblock 478 85 276 minecraft:cobbled_deepslate
setblock 478 85 316 minecraft:cobbled_deepslate
fill 479 85 276 482 85 276 minecraft:deepslate_tiles
setblock 479 85 315 minecraft:cobbled_deepslate
fill 479 85 316 482 85 316 minecraft:deepslate_tiles
setblock 480 85 278 minecraft:light[level=12]
setblock 480 85 285 minecraft:light[level=12]
setblock 480 85 292 minecraft:light[level=12]
setblock 480 85 299 minecraft:light[level=12]
setblock 480 85 306 minecraft:light[level=12]
setblock 480 85 313 minecraft:light[level=12]
fill 480 85 315 483 85 315 minecraft:deepslate_tiles
setblock 481 85 278 minecraft:light[level=13]
setblock 481 85 286 minecraft:light[level=13]
setblock 481 85 294 minecraft:light[level=13]
setblock 481 85 302 minecraft:light[level=13]
setblock 481 85 310 minecraft:light[level=13]
setblock 483 85 276 minecraft:cobbled_deepslate
setblock 483 85 316 minecraft:cobbled_deepslate
fill 484 85 276 487 85 276 minecraft:deepslate_tiles
setblock 484 85 314 minecraft:deepslate_tiles
setblock 484 85 315 minecraft:cobbled_deepslate
fill 484 85 316 487 85 316 minecraft:deepslate_tiles
setblock 485 85 314 minecraft:cobbled_deepslate
fill 485 85 315 488 85 315 minecraft:deepslate_tiles
fill 486 85 314 486 88 314 minecraft:deepslate_tiles
setblock 487 85 278 minecraft:light[level=12]
setblock 487 85 285 minecraft:light[level=12]
setblock 487 85 292 minecraft:light[level=12]
setblock 487 85 299 minecraft:light[level=12]
setblock 487 85 306 minecraft:light[level=12]
setblock 487 85 313 minecraft:light[level=12]
setblock 488 85 276 minecraft:cobbled_deepslate
fill 488 85 313 488 87 313 minecraft:deepslate_tiles
setblock 488 85 316 minecraft:cobbled_deepslate
setblock 489 85 275 minecraft:white_wool
fill 489 85 276 489 88 276 minecraft:deepslate_tiles
setblock 489 85 278 minecraft:light[level=13]
setblock 489 85 286 minecraft:light[level=13]
setblock 489 85 294 minecraft:light[level=13]
setblock 489 85 302 minecraft:light[level=13]
setblock 489 85 310 minecraft:light[level=13]
setblock 489 85 315 minecraft:cobbled_deepslate
fill 489 85 316 489 88 316 minecraft:deepslate_tiles
setblock 490 85 314 minecraft:cobbled_deepslate
fill 490 85 315 490 88 315 minecraft:deepslate_tiles
setblock 491 85 313 minecraft:cobbled_deepslate
fill 491 85 314 491 88 314 minecraft:deepslate_tiles
fill 492 85 313 492 87 313 minecraft:deepslate_tiles
setblock 493 85 276 minecraft:cobbled_deepslate
setblock 493 85 316 minecraft:cobbled_deepslate
fill 494 85 276 494 88 276 minecraft:deepslate_tiles
setblock 494 85 278 minecraft:light[level=12]
setblock 494 85 285 minecraft:light[level=12]
setblock 494 85 292 minecraft:light[level=12]
setblock 494 85 299 minecraft:light[level=12]
setblock 494 85 306 minecraft:light[level=12]
setblock 494 85 313 minecraft:light[level=12]
setblock 494 85 315 minecraft:cobbled_deepslate
fill 494 85 316 494 88 316 minecraft:deepslate_tiles
setblock 495 85 314 minecraft:cobbled_deepslate
fill 495 85 315 495 88 315 minecraft:deepslate_tiles
fill 496 85 275 496 86 275 minecraft:cobbled_deepslate
setblock 497 85 278 minecraft:light[level=13]
setblock 497 85 286 minecraft:light[level=13]
setblock 497 85 294 minecraft:light[level=13]
setblock 497 85 302 minecraft:light[level=13]
setblock 497 85 310 minecraft:light[level=13]
setblock 498 85 316 minecraft:cobbled_deepslate
fill 499 85 316 499 88 316 minecraft:deepslate_tiles
setblock 501 85 278 minecraft:light[level=12]
setblock 501 85 285 minecraft:light[level=12]
setblock 501 85 292 minecraft:light[level=12]
setblock 501 85 299 minecraft:light[level=12]
setblock 501 85 306 minecraft:light[level=12]
setblock 501 85 313 minecraft:light[level=12]
setblock 505 85 278 minecraft:light[level=13]
setblock 505 85 286 minecraft:light[level=13]
setblock 505 85 294 minecraft:light[level=13]
setblock 505 85 302 minecraft:light[level=13]
setblock 505 85 310 minecraft:light[level=13]
fill 505 85 316 507 85 316 minecraft:deepslate_tiles
setblock 507 85 276 minecraft:deepslate_tiles
setblock 508 85 276 minecraft:cobbled_deepslate
setblock 508 85 278 minecraft:light[level=12]
setblock 508 85 285 minecraft:light[level=12]
setblock 508 85 291 minecraft:cobbled_deepslate
fill 508 85 292 508 86 294 minecraft:deepslate_tiles
setblock 508 85 299 minecraft:light[level=12]
setblock 508 85 306 minecraft:light[level=12]
fill 508 85 308 510 86 308 minecraft:black_concrete
setblock 508 85 313 minecraft:light[level=12]
setblock 508 85 315 minecraft:deepslate_tiles
setblock 508 85 316 minecraft:cobbled_deepslate
fill 509 85 276 509 88 276 minecraft:deepslate_tiles
setblock 509 85 290 minecraft:cobbled_deepslate
fill 509 85 291 509 88 291 minecraft:deepslate_tiles
setblock 509 85 295 minecraft:cobbled_deepslate
fill 509 85 296 509 87 297 minecraft:deepslate_tiles
fill 509 85 307 509 86 307 minecraft:black_concrete
setblock 509 85 309 minecraft:white_wool
fill 509 85 313 509 85 314 minecraft:white_wool
setblock 509 85 315 minecraft:cobbled_deepslate
fill 509 85 316 509 88 316 minecraft:deepslate_tiles
setblock 510 85 283 minecraft:deepslate_tiles
setblock 510 85 284 minecraft:cobbled_deepslate
fill 510 85 285 510 88 285 minecraft:deepslate_tiles
setblock 510 85 289 minecraft:cobbled_deepslate
fill 510 85 290 510 88 290 minecraft:deepslate_tiles
setblock 510 85 294 minecraft:cobbled_deepslate
fill 510 85 295 510 88 295 minecraft:deepslate_tiles
setblock 510 85 299 minecraft:cobbled_deepslate
fill 510 85 300 510 88 300 minecraft:deepslate_tiles
setblock 510 85 314 minecraft:cobbled_deepslate
fill 510 85 315 510 88 315 minecraft:deepslate_tiles
setblock 511 85 277 minecraft:deepslate_tiles
setblock 511 85 278 minecraft:cobbled_deepslate
fill 511 85 279 511 88 279 minecraft:deepslate_tiles
fill 511 85 283 512 85 283 minecraft:cobbled_deepslate
fill 511 85 284 511 88 284 minecraft:deepslate_tiles
setblock 511 85 288 minecraft:cobbled_deepslate
fill 511 85 289 511 88 289 minecraft:deepslate_tiles
setblock 511 85 293 minecraft:cobbled_deepslate
fill 511 85 294 511 88 294 minecraft:deepslate_tiles
setblock 511 85 298 minecraft:cobbled_deepslate
fill 511 85 299 511 88 299 minecraft:deepslate_tiles
setblock 511 85 303 minecraft:cobbled_deepslate
fill 511 85 304 511 88 304 minecraft:deepslate_tiles
setblock 511 85 308 minecraft:cobbled_deepslate
fill 511 85 309 511 88 309 minecraft:deepslate_tiles
setblock 511 85 313 minecraft:cobbled_deepslate
fill 511 85 314 511 88 314 minecraft:deepslate_tiles
setblock 512 85 280 minecraft:white_wool
fill 512 85 281 512 94 282 minecraft:cobbled_deepslate
setblock 512 85 284 minecraft:redstone_block
setblock 512 85 305 minecraft:redstone_block
setblock 471 86 276 minecraft:deepslate_tiles
setblock 471 86 277 minecraft:cobbled_deepslate
fill 471 86 278 471 86 281 minecraft:deepslate_tiles
setblock 471 86 282 minecraft:cobbled_deepslate
fill 471 86 283 471 86 286 minecraft:deepslate_tiles
setblock 471 86 287 minecraft:cobbled_deepslate
fill 471 86 288 471 86 291 minecraft:deepslate_tiles
setblock 471 86 292 minecraft:cobbled_deepslate
fill 471 86 293 471 89 293 minecraft:deepslate_tiles
setblock 471 86 297 minecraft:cobbled_deepslate
fill 471 86 298 471 89 298 minecraft:deepslate_tiles
fill 471 86 300 471 87 300 minecraft:deepslate_tiles
fill 471 86 308 471 89 308 minecraft:deepslate_tiles
setblock 471 86 312 minecraft:cobbled_deepslate
fill 471 86 313 471 89 313 minecraft:deepslate_tiles
setblock 472 86 276 minecraft:cobbled_deepslate
fill 472 86 277 472 89 277 minecraft:deepslate_tiles
setblock 472 86 281 minecraft:cobbled_deepslate
fill 472 86 282 472 89 282 minecraft:deepslate_tiles
setblock 472 86 286 minecraft:cobbled_deepslate
fill 472 86 287 472 89 287 minecraft:deepslate_tiles
setblock 472 86 291 minecraft:cobbled_deepslate
fill 472 86 292 472 89 292 minecraft:deepslate_tiles
setblock 472 86 296 minecraft:cobbled_deepslate
fill 472 86 297 472 89 297 minecraft:deepslate_tiles
setblock 472 86 311 minecraft:cobbled_deepslate
fill 472 86 312 472 89 312 minecraft:deepslate_tiles
setblock 472 86 316 minecraft:cobbled_deepslate
fill 473 86 276 473 89 276 minecraft:deepslate_tiles
setblock 473 86 315 minecraft:cobbled_deepslate
fill 473 86 316 473 89 316 minecraft:deepslate_tiles
fill 474 86 315 474 89 315 minecraft:deepslate_tiles
setblock 476 86 277 minecraft:cobbled_deepslate
setblock 477 86 276 minecraft:cobbled_deepslate
setblock 477 86 316 minecraft:cobbled_deepslate
fill 478 86 276 481 86 276 minecraft:deepslate_tiles
setblock 478 86 315 minecraft:cobbled_deepslate
fill 478 86 316 481 86 316 minecraft:deepslate_tiles
fill 479 86 315 482 86 315 minecraft:deepslate_tiles
setblock 482 86 276 minecraft:cobbled_deepslate
setblock 482 86 316 minecraft:cobbled_deepslate
fill 483 86 276 486 86 276 minecraft:deepslate_tiles
setblock 483 86 314 minecraft:deepslate_tiles
setblock 483 86 315 minecraft:cobbled_deepslate
fill 483 86 316 486 86 316 minecraft:deepslate_tiles
setblock 484 86 314 minecraft:cobbled_deepslate
fill 484 86 315 487 86 315 minecraft:deepslate_tiles
fill 485 86 314 485 89 314 minecraft:deepslate_tiles
setblock 486 86 277 minecraft:cobbled_deepslate
setblock 487 86 276 minecraft:cobbled_deepslate
fill 487 86 277 490 86 277 minecraft:deepslate_tiles
fill 487 86 313 487 88 313 minecraft:deepslate_tiles
setblock 487 86 316 minecraft:cobbled_deepslate
fill 488 86 276 488 89 276 minecraft:deepslate_tiles
setblock 488 86 315 minecraft:cobbled_deepslate
fill 488 86 316 488 89 316 minecraft:deepslate_tiles
fill 489 86 275 489 90 275 minecraft:cobbled_deepslate
setblock 489 86 314 minecraft:cobbled_deepslate
fill 489 86 315 489 89 315 minecraft:deepslate_tiles
setblock 490 86 313 minecraft:cobbled_deepslate
fill 490 86 314 490 89 314 minecraft:deepslate_tiles
setblock 491 86 277 minecraft:cobbled_deepslate
fill 491 86 313 491 89 313 minecraft:deepslate_tiles
setblock 492 86 276 minecraft:cobbled_deepslate
setblock 492 86 312 minecraft:black_concrete
setblock 492 86 316 minecraft:cobbled_deepslate
fill 493 86 276 493 89 276 minecraft:deepslate_tiles
setblock 493 86 313 minecraft:black_concrete
setblock 493 86 315 minecraft:cobbled_deepslate
fill 493 86 316 493 89 316 minecraft:deepslate_tiles
setblock 494 86 314 minecraft:cobbled_deepslate
fill 494 86 315 494 89 315 minecraft:deepslate_tiles
fill 495 86 276 495 87 276 minecraft:deepslate_tiles
setblock 495 86 314 minecraft:deepslate_tiles
setblock 497 86 316 minecraft:cobbled_deepslate
fill 498 86 316 498 89 316 minecraft:deepslate_tiles
fill 503 86 316 506 86 316 minecraft:deepslate_tiles
setblock 506 86 276 minecraft:deepslate_tiles
setblock 507 86 276 minecraft:cobbled_deepslate
setblock 507 86 315 minecraft:deepslate_tiles
setblock 507 86 316 minecraft:cobbled_deepslate
fill 508 86 276 508 88 277 minecraft:deepslate_tiles
setblock 508 86 290 minecraft:cobbled_deepslate
fill 508 86 291 508 89 291 minecraft:deepslate_tiles
setblock 508 86 295 minecraft:cobbled_deepslate
fill 508 86 296 508 89 296 minecraft:deepslate_tiles
setblock 508 86 315 minecraft:cobbled_deepslate
fill 508 86 316 508 89 316 minecraft:deepslate_tiles
fill 509 86 277 510 86 277 minecraft:deepslate_tiles
setblock 509 86 289 minecraft:cobbled_deepslate
fill 509 86 290 509 89 290 minecraft:deepslate_tiles
setblock 509 86 294 minecraft:cobbled_deepslate
fill 509 86 295 509 89 295 minecraft:deepslate_tiles
setblock 509 86 298 minecraft:deepslate_tiles
setblock 509 86 299 minecraft:cobbled_deepslate
setblock 509 86 309 minecraft:black_concrete
fill 509 86 315 509 89 315 minecraft:deepslate_tiles
setblock 510 86 278 minecraft:cobbled_deepslate
fill 510 86 279 510 86 282 minecraft:deepslate_tiles
setblock 510 86 283 minecraft:cobbled_deepslate
fill 510 86 284 510 89 284 minecraft:deepslate_tiles
setblock 510 86 288 minecraft:cobbled_deepslate
fill 510 86 289 510 89 289 minecraft:deepslate_tiles
setblock 510 86 293 minecraft:cobbled_deepslate
fill 510 86 294 510 89 294 minecraft:deepslate_tiles
setblock 510 86 298 minecraft:cobbled_deepslate
fill 510 86 299 510 89 299 minecraft:deepslate_tiles
fill 510 86 301 510 87 301 minecraft:deepslate_tiles
setblock 510 86 312 minecraft:deepslate_tiles
setblock 510 86 313 minecraft:cobbled_deepslate
fill 510 86 314 510 89 314 minecraft:deepslate_tiles
setblock 511 86 277 minecraft:cobbled_deepslate
fill 511 86 278 511 89 278 minecraft:deepslate_tiles
setblock 511 86 282 minecraft:cobbled_deepslate
fill 511 86 283 511 89 283 minecraft:deepslate_tiles
setblock 511 86 287 minecraft:cobbled_deepslate
fill 511 86 288 511 89 288 minecraft:deepslate_tiles
setblock 511 86 292 minecraft:cobbled_deepslate
fill 511 86 293 511 89 293 minecraft:deepslate_tiles
setblock 511 86 297 minecraft:cobbled_deepslate
fill 511 86 298 511 89 298 minecraft:deepslate_tiles
setblock 511 86 302 minecraft:cobbled_deepslate
fill 511 86 303 511 89 303 minecraft:deepslate_tiles
setblock 511 86 307 minecraft:cobbled_deepslate
fill 511 86 308 511 88 308 minecraft:deepslate_tiles
setblock 511 86 312 minecraft:cobbled_deepslate
fill 511 86 313 511 89 313 minecraft:deepslate_tiles
fill 512 86 280 512 90 280 minecraft:cobbled_deepslate
fill 512 86 283 512 94 284 minecraft:cobbled_deepslate
fill 512 86 305 512 92 305 minecraft:cobbled_deepslate
setblock 471 87 276 minecraft:cobbled_deepslate
fill 471 87 277 471 87 280 minecraft:deepslate_tiles
setblock 471 87 281 minecraft:cobbled_deepslate
fill 471 87 282 471 87 285 minecraft:deepslate_tiles
setblock 471 87 286 minecraft:cobbled_deepslate
fill 471 87 287 471 87 290 minecraft:deepslate_tiles
setblock 471 87 291 minecraft:cobbled_deepslate
fill 471 87 292 471 90 292 minecraft:deepslate_tiles
setblock 471 87 296 minecraft:cobbled_deepslate
fill 471 87 297 471 90 297 minecraft:deepslate_tiles
setblock 471 87 301 minecraft:cobbled_deepslate
setblock 471 87 311 minecraft:cobbled_deepslate
fill 471 87 312 471 90 312 minecraft:deepslate_tiles
setblock 471 87 316 minecraft:cobbled_deepslate
fill 472 87 276 472 90 276 minecraft:deepslate_tiles
setblock 472 87 280 minecraft:cobbled_deepslate
fill 472 87 281 472 90 281 minecraft:deepslate_tiles
setblock 472 87 285 minecraft:cobbled_deepslate
fill 472 87 286 472 88 286 minecraft:deepslate_tiles
setblock 472 87 290 minecraft:cobbled_deepslate
fill 472 87 291 472 90 291 minecraft:deepslate_tiles
setblock 472 87 295 minecraft:cobbled_deepslate
fill 472 87 296 472 90 296 minecraft:deepslate_tiles
fill 472 87 298 472 88 298 minecraft:deepslate_tiles
fill 472 87 311 472 88 311 minecraft:deepslate_tiles
setblock 472 87 315 minecraft:cobbled_deepslate
fill 472 87 316 472 90 316 minecraft:deepslate_tiles
setblock 473 87 278 minecraft:deepslate_tiles
setblock 473 87 314 minecraft:cobbled_deepslate
fill 473 87 315 473 90 315 minecraft:deepslate_tiles
setblock 474 87 277 minecraft:deepslate_tiles
fill 474 87 314 474 88 314 minecraft:deepslate_tiles
setblock 475 87 277 minecraft:cobbled_deepslate
setblock 476 87 276 minecraft:cobbled_deepslate
fill 476 87 277 477 89 277 minecraft:deepslate_tiles
setblock 476 87 316 minecraft:cobbled_deepslate
fill 477 87 276 480 87 276 minecraft:deepslate_tiles
setblock 477 87 315 minecraft:cobbled_deepslate
fill 477 87 316 480 87 316 minecraft:deepslate_tiles
fill 478 87 315 481 87 315 minecraft:deepslate_tiles
setblock 481 87 276 minecraft:cobbled_deepslate
setblock 481 87 316 minecraft:cobbled_deepslate
fill 482 87 276 485 87 276 minecraft:deepslate_tiles
setblock 482 87 314 minecraft:deepslate_tiles
setblock 482 87 315 minecraft:cobbled_deepslate
fill 482 87 316 485 87 316 minecraft:deepslate_tiles
setblock 483 87 314 minecraft:cobbled_deepslate
fill 483 87 315 486 87 315 minecraft:deepslate_tiles
setblock 484 87 277 minecraft:deepslate_tiles
fill 484 87 314 484 90 314 minecraft:deepslate_tiles
setblock 485 87 277 minecraft:cobbled_deepslate
setblock 486 87 276 minecraft:cobbled_deepslate
fill 486 87 277 489 87 277 minecraft:deepslate_tiles
fill 486 87 313 486 89 313 minecraft:deepslate_tiles
setblock 486 87 316 minecraft:cobbled_deepslate
fill 487 87 276 487 90 276 minecraft:deepslate_tiles
setblock 487 87 315 minecraft:cobbled_deepslate
fill 487 87 316 487 90 316 minecraft:deepslate_tiles
setblock 488 87 314 minecraft:cobbled_deepslate
fill 488 87 315 488 90 315 minecraft:deepslate_tiles
setblock 489 87 313 minecraft:cobbled_deepslate
fill 489 87 314 489 90 314 minecraft:deepslate_tiles
setblock 490 87 277 minecraft:cobbled_deepslate
fill 490 87 313 490 89 313 minecraft:deepslate_tiles
setblock 491 87 276 minecraft:cobbled_deepslate
fill 491 87 277 492 89 277 minecraft:deepslate_tiles
setblock 491 87 316 minecraft:cobbled_deepslate
fill 492 87 276 492 90 276 minecraft:deepslate_tiles
setblock 492 87 315 minecraft:cobbled_deepslate
fill 492 87 316 492 90 316 minecraft:deepslate_tiles
setblock 493 87 314 minecraft:cobbled_deepslate
fill 493 87 315 493 90 315 minecraft:deepslate_tiles
fill 494 87 314 494 88 314 minecraft:deepslate_tiles
setblock 496 87 275 minecraft:redstone_block
setblock 496 87 316 minecraft:cobbled_deepslate
setblock 497 87 315 minecraft:cobbled_deepslate
fill 497 87 316 497 90 316 minecraft:deepslate_tiles
setblock 500 87 316 minecraft:deepslate_tiles
setblock 501 87 316 minecraft:cobbled_deepslate
fill 502 87 316 505 87 316 minecraft:deepslate_tiles
fill 504 87 276 505 87 276 minecraft:deepslate_tiles
fill 505 87 315 506 87 315 minecraft:deepslate_tiles
setblock 506 87 276 minecraft:cobbled_deepslate
setblock 506 87 316 minecraft:cobbled_deepslate
fill 507 87 276 507 89 277 minecraft:deepslate_tiles
setblock 507 87 315 minecraft:cobbled_deepslate
fill 507 87 316 507 90 316 minecraft:deepslate_tiles
setblock 508 87 278 minecraft:black_concrete
fill 508 87 290 508 90 290 minecraft:deepslate_tiles
fill 508 87 292 508 87 293 minecraft:deepslate_tiles
setblock 508 87 294 minecraft:cobbled_deepslate
fill 508 87 295 508 90 295 minecraft:deepslate_tiles
fill 508 87 297 508 88 297 minecraft:deepslate_tiles
fill 508 87 315 508 90 315 minecraft:deepslate_tiles
setblock 509 87 277 minecraft:deepslate_tiles
fill 509 87 286 509 88 286 minecraft:deepslate_tiles
setblock 509 87 288 minecraft:cobbled_deepslate
fill 509 87 289 509 90 289 minecraft:deepslate_tiles
setblock 509 87 293 minecraft:cobbled_deepslate
fill 509 87 294 509 90 294 minecraft:deepslate_tiles
setblock 509 87 298 minecraft:cobbled_deepslate
fill 509 87 299 509 89 300 minecraft:deepslate_tiles
setblock 510 87 276 minecraft:deepslate_tiles
setblock 510 87 277 minecraft:cobbled_deepslate
fill 510 87 278 510 87 281 minecraft:deepslate_tiles
setblock 510 87 282 minecraft:cobbled_deepslate
fill 510 87 283 510 90 283 minecraft:deepslate_tiles
setblock 510 87 287 minecraft:cobbled_deepslate
fill 510 87 288 510 90 288 minecraft:deepslate_tiles
setblock 510 87 292 minecraft:cobbled_deepslate
fill 510 87 293 510 90 293 minecraft:deepslate_tiles
setblock 510 87 297 minecraft:cobbled_deepslate
fill 510 87 298 510 90 298 minecraft:deepslate_tiles
setblock 510 87 302 minecraft:cobbled_deepslate
setblock 510 87 312 minecraft:cobbled_deepslate
fill 510 87 313 510 90 313 minecraft:deepslate_tiles
setblock 511 87 276 minecraft:cobbled_deepslate
fill 511 87 277 511 90 277 minecraft:deepslate_tiles
setblock 511 87 281 minecraft:cobbled_deepslate
fill 511 87 282 511 90 282 minecraft:deepslate_tiles
setblock 511 87 286 minecraft:cobbled_deepslate
fill 511 87 287 511 90 287 minecraft:deepslate_tiles
setblock 511 87 291 minecraft:cobbled_deepslate
fill 511 87 292 511 90 292 minecraft:deepslate_tiles
setblock 511 87 296 minecraft:cobbled_deepslate
fill 511 87 297 511 90 297 minecraft:deepslate_tiles
setblock 511 87 301 minecraft:cobbled_deepslate
fill 511 87 302 511 90 302 minecraft:deepslate_tiles
setblock 511 87 306 minecraft:cobbled_deepslate
fill 511 87 307 511 88 307 minecraft:deepslate_tiles
setblock 511 87 311 minecraft:cobbled_deepslate
fill 511 87 312 511 90 312 minecraft:deepslate_tiles
setblock 511 87 316 minecraft:cobbled_deepslate
fill 471 88 276 471 88 279 minecraft:deepslate_tiles
setblock 471 88 280 minecraft:cobbled_deepslate
fill 471 88 281 471 88 284 minecraft:deepslate_tiles
setblock 471 88 285 minecraft:cobbled_deepslate
fill 471 88 286 471 88 289 minecraft:deepslate_tiles
setblock 471 88 290 minecraft:cobbled_deepslate
fill 471 88 291 471 91 291 minecraft:deepslate_tiles
setblock 471 88 295 minecraft:cobbled_deepslate
fill 471 88 296 471 91 296 minecraft:deepslate_tiles
setblock 471 88 300 minecraft:cobbled_deepslate
fill 471 88 301 471 90 302 minecraft:deepslate_tiles
setblock 471 88 310 minecraft:cobbled_deepslate
fill 471 88 311 471 91 311 minecraft:deepslate_tiles
setblock 471 88 315 minecraft:cobbled_deepslate
fill 471 88 316 471 91 316 minecraft:deepslate_tiles
setblock 472 88 279 minecraft:cobbled_deepslate
fill 472 88 280 472 91 280 minecraft:deepslate_tiles
setblock 472 88 284 minecraft:cobbled_deepslate
fill 472 88 285 472 89 285 minecraft:deepslate_tiles
setblock 472 88 289 minecraft:cobbled_deepslate
fill 472 88 290 472 89 290 minecraft:deepslate_tiles
setblock 472 88 294 minecraft:cobbled_deepslate
fill 472 88 295 472 91 295 minecraft:deepslate_tiles
setblock 472 88 314 minecraft:cobbled_deepslate
fill 472 88 315 472 91 315 minecraft:deepslate_tiles
setblock 473 88 278 minecraft:cobbled_deepslate
fill 473 88 279 473 91 279 minecraft:deepslate_tiles
fill 473 88 314 473 89 314 minecraft:deepslate_tiles
setblock 474 88 277 minecraft:cobbled_deepslate
fill 474 88 278 474 91 278 minecraft:deepslate_tiles
setblock 475 88 276 minecraft:cobbled_deepslate
fill 475 88 277 475 91 277 minecraft:deepslate_tiles
setblock 475 88 316 minecraft:cobbled_deepslate
fill 476 88 276 479 88 276 minecraft:deepslate_tiles
setblock 476 88 315 minecraft:cobbled_deepslate
fill 476 88 316 479 88 316 minecraft:deepslate_tiles
fill 477 88 315 480 88 315 minecraft:deepslate_tiles
setblock 478 88 277 minecraft:deepslate_tiles
setblock 479 88 277 minecraft:cobbled_deepslate
setblock 480 88 276 minecraft:cobbled_deepslate
fill 480 88 277 483 88 277 minecraft:deepslate_tiles
setblock 480 88 316 minecraft:cobbled_deepslate
fill 481 88 276 484 88 276 minecraft:deepslate_tiles
setblock 481 88 314 minecraft:deepslate_tiles
setblock 481 88 315 minecraft:cobbled_deepslate
fill 481 88 316 484 88 316 minecraft:deepslate_tiles
setblock 482 88 314 minecraft:cobbled_deepslate
fill 482 88 315 485 88 315 minecraft:deepslate_tiles
fill 483 88 314 483 91 314 minecraft:deepslate_tiles
setblock 484 88 277 minecraft:cobbled_deepslate
setblock 485 88 276 minecraft:cobbled_deepslate
fill 485 88 277 488 88 277 minecraft:deepslate_tiles
fill 485 88 313 485 90 313 minecraft:deepslate_tiles
setblock 485 88 316 minecraft:cobbled_deepslate
fill 486 88 276 486 91 276 minecraft:deepslate_tiles
setblock 486 88 315 minecraft:cobbled_deepslate
fill 486 88 316 486 91 316 minecraft:deepslate_tiles
setblock 487 88 314 minecraft:cobbled_deepslate
fill 487 88 315 487 91 315 minecraft:deepslate_tiles
setblock 488 88 313 minecraft:cobbled_deepslate
fill 488 88 314 488 91 314 minecraft:deepslate_tiles
setblock 489 88 277 minecraft:cobbled_deepslate
fill 489 88 313 489 90 313 minecraft:deepslate_tiles
setblock 490 88 276 minecraft:cobbled_deepslate
fill 490 88 277 490 91 277 minecraft:deepslate_tiles
setblock 490 88 316 minecraft:cobbled_deepslate
fill 491 88 276 491 91 276 minecraft:deepslate_tiles
setblock 491 88 315 minecraft:cobbled_deepslate
fill 491 88 316 491 91 316 minecraft:deepslate_tiles
setblock 492 88 314 minecraft:cobbled_deepslate
fill 492 88 315 492 91 315 minecraft:deepslate_tiles
fill 493 88 314 493 89 314 minecraft:deepslate_tiles
setblock 494 88 275 minecraft:redstone_block
setblock 495 88 276 minecraft:cobbled_deepslate
setblock 495 88 316 minecraft:cobbled_deepslate
fill 496 88 275 496 90 275 minecraft:cobbled_deepslate
fill 496 88 276 496 91 276 minecraft:deepslate_tiles
setblock 496 88 315 minecraft:cobbled_deepslate
fill 496 88 316 496 91 316 minecraft:deepslate_tiles
setblock 500 88 316 minecraft:cobbled_deepslate
fill 501 88 316 504 88 316 minecraft:deepslate_tiles
fill 502 88 276 504 88 276 minecraft:deepslate_tiles
setblock 505 88 276 minecraft:cobbled_deepslate
fill 505 88 277 506 90 277 minecraft:deepslate_tiles
setblock 505 88 315 minecraft:deepslate_tiles
setblock 505 88 316 minecraft:cobbled_deepslate
fill 506 88 276 506 91 276 minecraft:deepslate_tiles
setblock 506 88 315 minecraft:cobbled_deepslate
fill 506 88 316 506 91 316 minecraft:deepslate_tiles
fill 507 88 315 507 91 315 minecraft:deepslate_tiles
setblock 508 88 278 minecraft:cobbled_deepslate
setblock 508 88 289 minecraft:deepslate_tiles
setblock 508 88 292 minecraft:deepslate_tiles
setblock 508 88 293 minecraft:cobbled_deepslate
fill 508 88 294 508 91 294 minecraft:deepslate_tiles
setblock 508 88 298 minecraft:cobbled_deepslate
setblock 509 88 277 minecraft:cobbled_deepslate
fill 509 88 278 510 88 280 minecraft:deepslate_tiles
setblock 509 88 287 minecraft:cobbled_deepslate
fill 509 88 288 509 91 288 minecraft:deepslate_tiles
setblock 509 88 292 minecraft:cobbled_deepslate
fill 509 88 293 509 91 293 minecraft:deepslate_tiles
setblock 509 88 296 minecraft:deepslate_tiles
setblock 509 88 297 minecraft:cobbled_deepslate
fill 509 88 298 509 91 298 minecraft:deepslate_tiles
setblock 510 88 276 minecraft:cobbled_deepslate
fill 510 88 277 510 91 277 minecraft:deepslate_tiles
setblock 510 88 281 minecraft:cobbled_deepslate
fill 510 88 282 510 91 282 minecraft:deepslate_tiles
setblock 510 88 286 minecraft:cobbled_deepslate
fill 510 88 287 510 91 287 minecraft:deepslate_tiles
setblock 510 88 291 minecraft:cobbled_deepslate
fill 510 88 292 510 91 292 minecraft:deepslate_tiles
setblock 510 88 296 minecraft:cobbled_deepslate
fill 510 88 297 510 91 297 minecraft:deepslate_tiles
setblock 510 88 301 minecraft:cobbled_deepslate
fill 510 88 302 510 91 302 minecraft:deepslate_tiles
setblock 510 88 311 minecraft:cobbled_deepslate
fill 510 88 312 510 89 312 minecraft:deepslate_tiles
setblock 510 88 316 minecraft:cobbled_deepslate
fill 511 88 276 511 91 276 minecraft:deepslate_tiles
setblock 511 88 280 minecraft:cobbled_deepslate
fill 511 88 281 511 91 281 minecraft:deepslate_tiles
setblock 511 88 285 minecraft:cobbled_deepslate
fill 511 88 286 511 91 286 minecraft:deepslate_tiles
setblock 511 88 290 minecraft:cobbled_deepslate
fill 511 88 291 511 91 291 minecraft:deepslate_tiles
setblock 511 88 295 minecraft:cobbled_deepslate
fill 511 88 296 511 91 296 minecraft:deepslate_tiles
setblock 511 88 300 minecraft:cobbled_deepslate
fill 511 88 301 511 91 301 minecraft:deepslate_tiles
setblock 511 88 305 minecraft:cobbled_deepslate
setblock 511 88 306 minecraft:deepslate_tiles
setblock 511 88 310 minecraft:cobbled_deepslate
fill 511 88 311 511 90 311 minecraft:deepslate_tiles
setblock 511 88 315 minecraft:cobbled_deepslate
fill 511 88 316 511 91 316 minecraft:deepslate_tiles
setblock 470 89 306 minecraft:white_wool
fill 471 89 276 471 89 278 minecraft:deepslate_tiles
setblock 471 89 279 minecraft:cobbled_deepslate
fill 471 89 280 471 89 283 minecraft:deepslate_tiles
setblock 471 89 284 minecraft:cobbled_deepslate
fill 471 89 285 471 89 288 minecraft:deepslate_tiles
setblock 471 89 289 minecraft:cobbled_deepslate
fill 471 89 290 471 92 290 minecraft:deepslate_tiles
setblock 471 89 294 minecraft:cobbled_deepslate
fill 471 89 295 471 92 295 minecraft:deepslate_tiles
setblock 471 89 299 minecraft:cobbled_deepslate
fill 471 89 300 471 92 300 minecraft:deepslate_tiles
setblock 471 89 303 minecraft:deepslate_tiles
setblock 471 89 309 minecraft:cobbled_deepslate
fill 471 89 310 471 91 310 minecraft:deepslate_tiles
setblock 471 89 314 minecraft:cobbled_deepslate
fill 471 89 315 471 92 315 minecraft:deepslate_tiles
setblock 472 89 278 minecraft:cobbled_deepslate
fill 472 89 279 472 92 279 minecraft:deepslate_tiles
setblock 472 89 283 minecraft:cobbled_deepslate
setblock 472 89 284 minecraft:deepslate_tiles
setblock 472 89 288 minecraft:cobbled_deepslate
setblock 472 89 289 minecraft:deepslate_tiles
setblock 472 89 293 minecraft:cobbled_deepslate
fill 472 89 294 472 91 294 minecraft:deepslate_tiles
setblock 472 89 298 minecraft:cobbled_deepslate
fill 472 89 299 472 90 299 minecraft:deepslate_tiles
setblock 472 89 313 minecraft:cobbled_deepslate
fill 472 89 314 472 92 314 minecraft:deepslate_tiles
setblock 473 89 277 minecraft:cobbled_deepslate
fill 473 89 278 473 92 278 minecraft:deepslate_tiles
setblock 474 89 276 minecraft:cobbled_deepslate
fill 474 89 277 474 92 277 minecraft:deepslate_tiles
setblock 474 89 316 minecraft:cobbled_deepslate
fill 475 89 276 478 89 276 minecraft:deepslate_tiles
setblock 475 89 315 minecraft:cobbled_deepslate
fill 475 89 316 478 89 316 minecraft:deepslate_tiles
fill 476 89 315 479 89 315 minecraft:deepslate_tiles
setblock 478 89 277 minecraft:cobbled_deepslate
setblock 479 89 276 minecraft:cobbled_deepslate
fill 479 89 277 482 89 277 minecraft:deepslate_tiles
setblock 479 89 316 minecraft:cobbled_deepslate
fill 480 89 276 483 89 276 minecraft:deepslate_tiles
setblock 480 89 315 minecraft:cobbled_deepslate
fill 480 89 316 483 89 316 minecraft:deepslate_tiles
setblock 481 89 314 minecraft:cobbled_deepslate
fill 481 89 315 484 89 315 minecraft:deepslate_tiles
fill 482 89 314 482 92 314 minecraft:deepslate_tiles
setblock 483 89 277 minecraft:cobbled_deepslate
setblock 484 89 276 minecraft:cobbled_deepslate
fill 484 89 277 487 89 277 minecraft:deepslate_tiles
setblock 484 89 316 minecraft:cobbled_deepslate
fill 485 89 276 485 92 276 minecraft:deepslate_tiles
setblock 485 89 315 minecraft:cobbled_deepslate
fill 485 89 316 485 92 316 minecraft:deepslate_tiles
setblock 486 89 314 minecraft:cobbled_deepslate
fill 486 89 315 486 92 315 minecraft:deepslate_tiles
setblock 487 89 278 minecraft:cobbled_deepslate
setblock 487 89 313 minecraft:cobbled_deepslate
fill 487 89 314 487 92 314 minecraft:deepslate_tiles
setblock 488 89 277 minecraft:cobbled_deepslate
fill 488 89 313 488 91 313 minecraft:deepslate_tiles
setblock 489 89 276 minecraft:cobbled_deepslate
fill 489 89 277 489 92 277 minecraft:deepslate_tiles
setblock 489 89 316 minecraft:cobbled_deepslate
fill 490 89 276 490 92 276 minecraft:deepslate_tiles
setblock 490 89 315 minecraft:cobbled_deepslate
fill 490 89 316 490 92 316 minecraft:deepslate_tiles
setblock 491 89 314 minecraft:cobbled_deepslate
fill 491 89 315 491 92 315 minecraft:deepslate_tiles
fill 492 89 314 492 90 314 minecraft:deepslate_tiles
fill 494 89 275 494 89 276 minecraft:cobbled_deepslate
setblock 494 89 316 minecraft:cobbled_deepslate
fill 495 89 276 495 91 276 minecraft:deepslate_tiles
setblock 495 89 315 minecraft:cobbled_deepslate
fill 495 89 316 495 92 316 minecraft:deepslate_tiles
setblock 496 89 315 minecraft:deepslate_tiles
setblock 499 89 316 minecraft:cobbled_deepslate
fill 500 89 316 503 89 316 minecraft:deepslate_tiles
fill 501 89 276 503 89 276 minecraft:deepslate_tiles
setblock 504 89 276 minecraft:cobbled_deepslate
fill 504 89 277 504 92 277 minecraft:deepslate_tiles
setblock 504 89 315 minecraft:deepslate_tiles
setblock 504 89 316 minecraft:cobbled_deepslate
fill 505 89 276 505 92 276 minecraft:deepslate_tiles
setblock 505 89 315 minecraft:cobbled_deepslate
fill 505 89 316 505 92 316 minecraft:deepslate_tiles
setblock 506 89 278 minecraft:deepslate_tiles
fill 506 89 315 506 92 315 minecraft:deepslate_tiles
setblock 507 89 278 minecraft:cobbled_deepslate
fill 507 89 294 507 90 296 minecraft:deepslate_tiles
setblock 508 89 276 minecraft:deepslate_tiles
setblock 508 89 277 minecraft:cobbled_deepslate
fill 508 89 278 510 90 278 minecraft:deepslate_tiles
setblock 508 89 292 minecraft:cobbled_deepslate
fill 508 89 293 508 92 293 minecraft:deepslate_tiles
setblock 508 89 297 minecraft:cobbled_deepslate
fill 508 89 298 508 91 299 minecraft:deepslate_tiles
setblock 509 89 276 minecraft:cobbled_deepslate
fill 509 89 277 509 92 277 minecraft:deepslate_tiles
fill 509 89 279 509 89 280 minecraft:deepslate_tiles
setblock 509 89 281 minecraft:cobbled_deepslate
fill 509 89 282 509 89 285 minecraft:deepslate_tiles
setblock 509 89 286 minecraft:cobbled_deepslate
fill 509 89 287 509 91 287 minecraft:deepslate_tiles
setblock 509 89 291 minecraft:cobbled_deepslate
fill 509 89 292 509 92 292 minecraft:deepslate_tiles
setblock 509 89 296 minecraft:cobbled_deepslate
fill 509 89 297 509 92 297 minecraft:deepslate_tiles
setblock 509 89 301 minecraft:cobbled_deepslate
setblock 509 89 316 minecraft:cobbled_deepslate
fill 510 89 276 510 92 276 minecraft:deepslate_tiles
setblock 510 89 279 minecraft:deepslate_tiles
setblock 510 89 280 minecraft:cobbled_deepslate
fill 510 89 281 510 92 281 minecraft:deepslate_tiles
setblock 510 89 285 minecraft:cobbled_deepslate
fill 510 89 286 510 92 286 minecraft:deepslate_tiles
setblock 510 89 290 minecraft:cobbled_deepslate
fill 510 89 291 510 92 291 minecraft:deepslate_tiles
setblock 510 89 295 minecraft:cobbled_deepslate
fill 510 89 296 510 92 296 minecraft:deepslate_tiles
setblock 510 89 300 minecraft:cobbled_deepslate
fill 510 89 301 510 92 301 minecraft:deepslate_tiles
fill 510 89 303 510 90 303 minecraft:deepslate_tiles
setblock 510 89 315 minecraft:cobbled_deepslate
fill 510 89 316 510 92 316 minecraft:deepslate_tiles
setblock 511 89 279 minecraft:cobbled_deepslate
fill 511 89 280 511 92 280 minecraft:deepslate_tiles
setblock 511 89 284 minecraft:cobbled_deepslate
fill 511 89 285 511 92 285 minecraft:deepslate_tiles
setblock 511 89 289 minecraft:cobbled_deepslate
fill 511 89 290 511 92 290 minecraft:deepslate_tiles
setblock 511 89 294 minecraft:cobbled_deepslate
fill 511 89 295 511 92 295 minecraft:deepslate_tiles
setblock 511 89 299 minecraft:cobbled_deepslate
fill 511 89 300 511 92 300 minecraft:deepslate_tiles
setblock 511 89 304 minecraft:cobbled_deepslate
fill 511 89 305 511 90 305 minecraft:deepslate_tiles
setblock 511 89 309 minecraft:cobbled_deepslate
fill 511 89 310 511 90 310 minecraft:deepslate_tiles
setblock 511 89 314 minecraft:cobbled_deepslate
fill 511 89 315 511 92 315 minecraft:deepslate_tiles
setblock 470 90 306 minecraft:cobbled_deepslate
fill 471 90 276 471 90 277 minecraft:deepslate_tiles
setblock 471 90 278 minecraft:cobbled_deepslate
fill 471 90 279 471 90 282 minecraft:deepslate_tiles
setblock 471 90 283 minecraft:cobbled_deepslate
fill 471 90 284 471 90 287 minecraft:deepslate_tiles
setblock 471 90 288 minecraft:cobbled_deepslate
fill 471 90 289 471 92 289 minecraft:deepslate_tiles
setblock 471 90 293 minecraft:cobbled_deepslate
fill 471 90 294 471 93 294 minecraft:deepslate_tiles
setblock 471 90 298 minecraft:cobbled_deepslate
fill 471 90 299 471 93 299 minecraft:deepslate_tiles
setblock 471 90 303 minecraft:cobbled_deepslate
setblock 471 90 309 minecraft:deepslate_tiles
setblock 471 90 313 minecraft:cobbled_deepslate
fill 471 90 314 471 93 314 minecraft:deepslate_tiles
setblock 472 90 277 minecraft:cobbled_deepslate
fill 472 90 278 472 93 278 minecraft:deepslate_tiles
setblock 472 90 282 minecraft:cobbled_deepslate
fill 472 90 283 472 91 283 minecraft:deepslate_tiles
setblock 472 90 292 minecraft:cobbled_deepslate
setblock 472 90 293 minecraft:deepslate_tiles
setblock 472 90 297 minecraft:cobbled_deepslate
fill 472 90 298 472 91 298 minecraft:deepslate_tiles
setblock 472 90 312 minecraft:cobbled_deepslate
fill 472 90 313 472 91 313 minecraft:deepslate_tiles
setblock 473 90 276 minecraft:cobbled_deepslate
fill 473 90 277 473 93 277 minecraft:deepslate_tiles
setblock 473 90 316 minecraft:cobbled_deepslate
fill 474 90 276 477 90 276 minecraft:deepslate_tiles
setblock 474 90 315 minecraft:cobbled_deepslate
fill 474 90 316 477 90 316 minecraft:deepslate_tiles
fill 475 90 315 478 90 315 minecraft:deepslate_tiles
setblock 476 90 277 minecraft:deepslate_tiles
setblock 477 90 277 minecraft:cobbled_deepslate
setblock 478 90 276 minecraft:cobbled_deepslate
fill 478 90 277 481 90 277 minecraft:deepslate_tiles
setblock 478 90 316 minecraft:cobbled_deepslate
fill 479 90 276 482 90 276 minecraft:deepslate_tiles
setblock 479 90 315 minecraft:cobbled_deepslate
fill 479 90 316 482 90 316 minecraft:deepslate_tiles
fill 480 90 315 483 90 315 minecraft:deepslate_tiles
fill 481 90 314 481 91 314 minecraft:deepslate_tiles
setblock 482 90 277 minecraft:cobbled_deepslate
setblock 483 90 276 minecraft:cobbled_deepslate
fill 483 90 277 486 90 277 minecraft:deepslate_tiles
setblock 483 90 316 minecraft:cobbled_deepslate
fill 484 90 276 484 93 276 minecraft:deepslate_tiles
setblock 484 90 315 minecraft:cobbled_deepslate
fill 484 90 316 484 93 316 minecraft:deepslate_tiles
setblock 485 90 278 minecraft:deepslate_tiles
setblock 485 90 314 minecraft:cobbled_deepslate
fill 485 90 315 485 93 315 minecraft:deepslate_tiles
setblock 486 90 278 minecraft:cobbled_deepslate
setblock 486 90 313 minecraft:cobbled_deepslate
fill 486 90 314 486 93 314 minecraft:deepslate_tiles
setblock 487 90 277 minecraft:cobbled_deepslate
fill 487 90 278 488 91 278 minecraft:deepslate_tiles
fill 487 90 313 487 91 313 minecraft:deepslate_tiles
setblock 488 90 276 minecraft:cobbled_deepslate
fill 488 90 277 488 93 277 minecraft:deepslate_tiles
setblock 488 90 316 minecraft:cobbled_deepslate
fill 489 90 276 489 93 276 minecraft:deepslate_tiles
setblock 489 90 315 minecraft:cobbled_deepslate
fill 489 90 316 489 93 316 minecraft:deepslate_tiles
setblock 490 90 314 minecraft:cobbled_deepslate
fill 490 90 315 490 93 315 minecraft:deepslate_tiles
setblock 491 90 277 minecraft:deepslate_tiles
fill 491 90 314 491 91 314 minecraft:deepslate_tiles
setblock 492 90 277 minecraft:cobbled_deepslate
setblock 493 90 276 minecraft:cobbled_deepslate
setblock 493 90 316 minecraft:cobbled_deepslate
fill 494 90 275 494 94 275 minecraft:cobbled_deepslate
fill 494 90 276 494 92 276 minecraft:deepslate_tiles
setblock 494 90 315 minecraft:cobbled_deepslate
fill 494 90 316 494 92 316 minecraft:deepslate_tiles
setblock 495 90 315 minecraft:deepslate_tiles
setblock 498 90 316 minecraft:cobbled_deepslate
fill 499 90 276 502 90 276 minecraft:deepslate_tiles
fill 499 90 316 502 90 316 minecraft:deepslate_tiles
setblock 503 90 276 minecraft:cobbled_deepslate
fill 503 90 277 503 93 277 minecraft:deepslate_tiles
setblock 503 90 316 minecraft:cobbled_deepslate
fill 504 90 276 504 93 276 minecraft:deepslate_tiles
setblock 504 90 315 minecraft:cobbled_deepslate
fill 504 90 316 504 93 316 minecraft:deepslate_tiles
setblock 505 90 278 minecraft:deepslate_tiles
fill 505 90 315 505 92 315 minecraft:deepslate_tiles
setblock 506 90 278 minecraft:cobbled_deepslate
setblock 507 90 276 minecraft:deepslate_tiles
setblock 507 90 277 minecraft:cobbled_deepslate
fill 507 90 278 507 93 278 minecraft:deepslate_tiles
setblock 508 90 276 minecraft:cobbled_deepslate
fill 508 90 277 508 93 277 minecraft:deepslate_tiles
setblock 508 90 291 minecraft:cobbled_deepslate
fill 508 90 292 508 91 292 minecraft:deepslate_tiles
setblock 508 90 296 minecraft:cobbled_deepslate
fill 508 90 297 508 92 297 minecraft:deepslate_tiles
setblock 508 90 316 minecraft:cobbled_deepslate
fill 509 90 276 509 93 276 minecraft:deepslate_tiles
setblock 509 90 279 minecraft:deepslate_tiles
setblock 509 90 280 minecraft:cobbled_deepslate
fill 509 90 281 509 90 284 minecraft:deepslate_tiles
setblock 509 90 285 minecraft:cobbled_deepslate
fill 509 90 286 509 91 286 minecraft:deepslate_tiles
setblock 509 90 290 minecraft:cobbled_deepslate
fill 509 90 291 509 92 291 minecraft:deepslate_tiles
setblock 509 90 295 minecraft:cobbled_deepslate
fill 509 90 296 509 93 296 minecraft:deepslate_tiles
setblock 509 90 299 minecraft:deepslate_tiles
setblock 509 90 300 minecraft:cobbled_deepslate
fill 509 90 301 509 92 301 minecraft:deepslate_tiles
setblock 509 90 315 minecraft:cobbled_deepslate
fill 509 90 316 509 93 316 minecraft:deepslate_tiles
setblock 510 90 279 minecraft:cobbled_deepslate
fill 510 90 280 510 93 280 minecraft:deepslate_tiles
setblock 510 90 284 minecraft:cobbled_deepslate
fill 510 90 285 510 93 285 minecraft:deepslate_tiles
setblock 510 90 289 minecraft:cobbled_deepslate
fill 510 90 290 510 93 290 minecraft:deepslate_tiles
setblock 510 90 294 minecraft:cobbled_deepslate
fill 510 90 295 510 93 295 minecraft:deepslate_tiles
setblock 510 90 299 minecraft:cobbled_deepslate
fill 510 90 300 510 93 300 minecraft:deepslate_tiles
setblock 510 90 314 minecraft:cobbled_deepslate
fill 510 90 315 510 92 315 minecraft:deepslate_tiles
setblock 511 90 278 minecraft:cobbled_deepslate
fill 511 90 279 511 93 279 minecraft:deepslate_tiles
setblock 511 90 283 minecraft:cobbled_deepslate
fill 511 90 284 511 93 284 minecraft:deepslate_tiles
setblock 511 90 288 minecraft:cobbled_deepslate
fill 511 90 289 511 93 289 minecraft:deepslate_tiles
setblock 511 90 293 minecraft:cobbled_deepslate
fill 511 90 294 511 93 294 minecraft:deepslate_tiles
setblock 511 90 298 minecraft:cobbled_deepslate
fill 511 90 299 511 93 299 minecraft:deepslate_tiles
setblock 511 90 303 minecraft:cobbled_deepslate
fill 511 90 304 511 92 304 minecraft:deepslate_tiles
setblock 511 90 313 minecraft:cobbled_deepslate
fill 511 90 314 511 92 314 minecraft:deepslate_tiles
setblock 470 91 280 minecraft:black_concrete
fill 470 91 281 470 91 282 minecraft:cobbled_deepslate
fill 470 91 283 470 92 283 minecraft:black_concrete
fill 470 91 284 470 95 284 minecraft:cobbled_deepslate
setblock 470 91 294 minecraft:black_concrete
fill 470 91 299 470 91 301 minecraft:cobbled_deepslate
setblock 470 91 302 minecraft:redstone_block
setblock 470 91 306 minecraft:black_concrete
setblock 470 91 308 minecraft:black_concrete
fill 470 91 310 470 92 311 minecraft:cobbled_deepslate
setblock 470 91 312 minecraft:black_concrete
fill 470 91 316 470 94 316 minecraft:cobbled_deepslate
setblock 470 91 317 minecraft:black_concrete
setblock 471 91 276 minecraft:deepslate_tiles
setblock 471 91 277 minecraft:cobbled_deepslate
fill 471 91 278 471 91 281 minecraft:deepslate_tiles
setblock 471 91 282 minecraft:cobbled_deepslate
fill 471 91 283 471 91 286 minecraft:deepslate_tiles
setblock 471 91 287 minecraft:cobbled_deepslate
fill 471 91 288 471 92 288 minecraft:deepslate_tiles
setblock 471 91 292 minecraft:cobbled_deepslate
fill 471 91 293 471 93 293 minecraft:deepslate_tiles
setblock 471 91 297 minecraft:cobbled_deepslate
fill 471 91 298 471 94 298 minecraft:deepslate_tiles
setblock 471 91 301 minecraft:deepslate_tiles
setblock 471 91 302 minecraft:cobbled_deepslate
fill 471 91 303 471 92 303 minecraft:deepslate_tiles
setblock 471 91 312 minecraft:cobbled_deepslate
fill 471 91 313 471 93 313 minecraft:deepslate_tiles
fill 471 91 317 474 92 317 minecraft:cobbled_deepslate
setblock 472 91 276 minecraft:cobbled_deepslate
fill 472 91 277 472 94 277 minecraft:deepslate_tiles
setblock 472 91 281 minecraft:cobbled_deepslate
fill 472 91 282 472 92 282 minecraft:deepslate_tiles
setblock 472 91 296 minecraft:cobbled_deepslate
setblock 472 91 297 minecraft:deepslate_tiles
setblock 472 91 316 minecraft:cobbled_deepslate
fill 473 91 276 476 91 276 minecraft:deepslate_tiles
setblock 473 91 285 minecraft:light[level=12]
setblock 473 91 292 minecraft:light[level=12]
setblock 473 91 299 minecraft:light[level=12]
setblock 473 91 306 minecraft:light[level=12]
setblock 473 91 313 minecraft:light[level=12]
setblock 473 91 315 minecraft:cobbled_deepslate
fill 473 91 316 476 91 316 minecraft:deepslate_tiles
fill 474 91 315 477 91 315 minecraft:deepslate_tiles
setblock 475 91 317 minecraft:black_concrete
setblock 476 91 277 minecraft:cobbled_deepslate
fill 476 91 317 476 94 317 minecraft:cobbled_deepslate
setblock 477 91 276 minecraft:cobbled_deepslate
fill 477 91 277 480 91 277 minecraft:deepslate_tiles
setblock 477 91 316 minecraft:cobbled_deepslate
fill 478 91 276 481 91 276 minecraft:deepslate_tiles
setblock 478 91 315 minecraft:cobbled_deepslate
fill 478 91 316 481 91 316 minecraft:deepslate_tiles
fill 479 91 315 482 91 315 minecraft:deepslate_tiles
fill 479 91 317 481 94 317 minecraft:cobbled_deepslate
setblock 480 91 278 minecraft:light[level=12]
setblock 480 91 285 minecraft:light[level=12]
setblock 480 91 292 minecraft:light[level=12]
setblock 480 91 299 minecraft:light[level=12]
setblock 480 91 306 minecraft:light[level=12]
setblock 480 91 313 minecraft:light[level=12]
setblock 481 91 277 minecraft:cobbled_deepslate
setblock 482 91 276 minecraft:cobbled_deepslate
fill 482 91 277 485 91 277 minecraft:deepslate_tiles
setblock 482 91 316 minecraft:cobbled_deepslate
setblock 482 91 317 minecraft:black_concrete
fill 483 91 276 483 94 276 minecraft:deepslate_tiles
setblock 483 91 315 minecraft:cobbled_deepslate
fill 483 91 316 483 94 316 minecraft:deepslate_tiles
setblock 484 91 278 minecraft:deepslate_tiles
setblock 484 91 314 minecraft:cobbled_deepslate
fill 484 91 315 484 94 315 minecraft:deepslate_tiles
setblock 485 91 278 minecraft:cobbled_deepslate
fill 485 91 314 485 94 314 minecraft:deepslate_tiles
setblock 486 91 277 minecraft:cobbled_deepslate
fill 486 91 278 486 93 278 minecraft:deepslate_tiles
setblock 486 91 313 minecraft:deepslate_tiles
setblock 487 91 276 minecraft:cobbled_deepslate
fill 487 91 277 487 94 277 minecraft:deepslate_tiles
setblock 487 91 285 minecraft:light[level=12]
setblock 487 91 292 minecraft:light[level=12]
setblock 487 91 299 minecraft:light[level=12]
setblock 487 91 306 minecraft:light[level=12]
setblock 487 91 316 minecraft:cobbled_deepslate
fill 488 91 276 488 94 276 minecraft:deepslate_tiles
setblock 488 91 315 minecraft:cobbled_deepslate
fill 488 91 316 488 94 316 minecraft:deepslate_tiles
setblock 489 91 275 minecraft:black_concrete
setblock 489 91 314 minecraft:cobbled_deepslate
fill 489 91 315 489 94 315 minecraft:deepslate_tiles
fill 490 91 314 490 92 314 minecraft:deepslate_tiles
setblock 491 91 277 minecraft:cobbled_deepslate
setblock 492 91 276 minecraft:cobbled_deepslate
setblock 492 91 277 minecraft:deepslate_tiles
setblock 492 91 316 minecraft:cobbled_deepslate
fill 493 91 276 493 93 276 minecraft:deepslate_tiles
setblock 493 91 315 minecraft:cobbled_deepslate
fill 493 91 316 493 93 316 minecraft:deepslate_tiles
setblock 494 91 278 minecraft:light[level=12]
setblock 494 91 285 minecraft:light[level=12]
setblock 494 91 292 minecraft:light[level=12]
setblock 494 91 299 minecraft:light[level=12]
setblock 494 91 306 minecraft:light[level=12]
setblock 494 91 313 minecraft:light[level=12]
setblock 494 91 315 minecraft:deepslate_tiles
fill 495 91 275 496 91 275 minecraft:black_concrete
setblock 497 91 316 minecraft:cobbled_deepslate
fill 498 91 316 501 91 316 minecraft:deepslate_tiles
fill 499 91 276 501 91 276 minecraft:deepslate_tiles
setblock 499 91 317 minecraft:black_concrete
setblock 501 91 278 minecraft:light[level=12]
setblock 501 91 285 minecraft:light[level=12]
setblock 501 91 292 minecraft:light[level=12]
setblock 501 91 299 minecraft:light[level=12]
setblock 501 91 306 minecraft:light[level=12]
setblock 501 91 313 minecraft:light[level=12]
fill 501 91 317 501 94 317 minecraft:cobbled_deepslate
setblock 502 91 276 minecraft:cobbled_deepslate
fill 502 91 277 502 94 277 minecraft:deepslate_tiles
setblock 502 91 316 minecraft:cobbled_deepslate
fill 502 91 317 503 91 317 minecraft:black_concrete
fill 503 91 276 503 94 276 minecraft:deepslate_tiles
fill 503 91 316 503 94 316 minecraft:deepslate_tiles
setblock 504 91 278 minecraft:deepslate_tiles
setblock 504 91 315 minecraft:deepslate_tiles
fill 504 91 317 504 95 317 minecraft:cobbled_deepslate
setblock 505 91 277 minecraft:deepslate_tiles
setblock 505 91 278 minecraft:cobbled_deepslate
setblock 506 91 277 minecraft:cobbled_deepslate
fill 506 91 278 506 94 278 minecraft:deepslate_tiles
setblock 507 91 276 minecraft:cobbled_deepslate
fill 507 91 277 507 94 277 minecraft:deepslate_tiles
fill 507 91 316 507 91 317 minecraft:cobbled_deepslate
fill 508 91 276 508 94 276 minecraft:deepslate_tiles
fill 508 91 278 508 91 279 minecraft:deepslate_tiles
setblock 508 91 285 minecraft:light[level=12]
setblock 508 91 291 minecraft:deepslate_tiles
setblock 508 91 295 minecraft:cobbled_deepslate
fill 508 91 296 508 92 296 minecraft:deepslate_tiles
setblock 508 91 306 minecraft:light[level=12]
setblock 508 91 313 minecraft:light[level=12]
setblock 508 91 315 minecraft:cobbled_deepslate
fill 508 91 316 508 94 316 minecraft:deepslate_tiles
fill 508 91 317 508 92 317 minecraft:cobbled_deepslate
setblock 509 91 278 minecraft:deepslate_tiles
setblock 509 91 279 minecraft:cobbled_deepslate
fill 509 91 280 509 91 283 minecraft:deepslate_tiles
setblock 509 91 284 minecraft:cobbled_deepslate
setblock 509 91 285 minecraft:deepslate_tiles
setblock 509 91 289 minecraft:cobbled_deepslate
fill 509 91 290 509 92 290 minecraft:deepslate_tiles
setblock 509 91 294 minecraft:cobbled_deepslate
fill 509 91 295 509 93 295 minecraft:deepslate_tiles
setblock 509 91 299 minecraft:cobbled_deepslate
fill 509 91 300 509 93 300 minecraft:deepslate_tiles
fill 509 91 315 509 92 315 minecraft:deepslate_tiles
setblock 509 91 317 minecraft:black_concrete
setblock 510 91 278 minecraft:cobbled_deepslate
fill 510 91 279 510 94 279 minecraft:deepslate_tiles
setblock 510 91 283 minecraft:cobbled_deepslate
fill 510 91 284 510 94 284 minecraft:deepslate_tiles
setblock 510 91 288 minecraft:cobbled_deepslate
fill 510 91 289 510 93 289 minecraft:deepslate_tiles
setblock 510 91 293 minecraft:cobbled_deepslate
fill 510 91 294 510 94 294 minecraft:deepslate_tiles
setblock 510 91 298 minecraft:cobbled_deepslate
fill 510 91 299 510 94 299 minecraft:deepslate_tiles
setblock 510 91 303 minecraft:cobbled_deepslate
setblock 510 91 314 minecraft:deepslate_tiles
fill 511 91 277 512 91 277 minecraft:cobbled_deepslate
fill 511 91 278 511 94 278 minecraft:deepslate_tiles
setblock 511 91 282 minecraft:cobbled_deepslate
fill 511 91 283 511 94 283 minecraft:deepslate_tiles
setblock 511 91 287 minecraft:cobbled_deepslate
fill 511 91 288 511 94 288 minecraft:deepslate_tiles
setblock 511 91 292 minecraft:cobbled_deepslate
fill 511 91 293 511 94 293 minecraft:deepslate_tiles
setblock 511 91 297 minecraft:cobbled_deepslate
fill 511 91 298 511 94 298 minecraft:deepslate_tiles
setblock 511 91 302 minecraft:cobbled_deepslate
fill 511 91 303 511 93 303 minecraft:deepslate_tiles
setblock 511 91 312 minecraft:cobbled_deepslate
fill 511 91 313 511 92 313 minecraft:deepslate_tiles
setblock 512 91 275 minecraft:black_concrete
fill 512 91 276 512 94 276 minecraft:cobbled_deepslate
setblock 512 91 278 minecraft:black_concrete
setblock 512 91 280 minecraft:black_concrete
fill 512 91 290 512 94 290 minecraft:cobbled_deepslate
fill 512 91 291 512 92 291 minecraft:black_concrete
setblock 512 91 300 minecraft:black_concrete
setblock 470 92 279 minecraft:black_concrete
fill 470 92 280 470 94 281 minecraft:cobbled_deepslate
setblock 470 92 282 minecraft:black_concrete
fill 470 92 294 470 94 294 minecraft:cobbled_deepslate
fill 470 92 299 470 94 300 minecraft:cobbled_deepslate
setblock 470 92 301 minecraft:black_concrete
fill 470 92 302 470 94 302 minecraft:cobbled_deepslate
setblock 470 92 303 minecraft:black_concrete
fill 470 92 306 470 95 306 minecraft:cobbled_deepslate
fill 470 92 308 470 95 308 minecraft:cobbled_deepslate
fill 470 92 312 470 94 312 minecraft:cobbled_deepslate
fill 470 92 317 470 94 317 minecraft:cobbled_deepslate
setblock 471 92 275 minecraft:black_concrete
setblock 471 92 276 minecraft:cobbled_deepslate
fill 471 92 277 471 92 280 minecraft:deepslate_tiles
setblock 471 92 281 minecraft:cobbled_deepslate
fill 471 92 282 471 92 285 minecraft:deepslate_tiles
setblock 471 92 286 minecraft:cobbled_deepslate
setblock 471 92 287 minecraft:deepslate_tiles
setblock 471 92 291 minecraft:cobbled_deepslate
setblock 471 92 292 minecraft:deepslate_tiles
setblock 471 92 296 minecraft:cobbled_deepslate
fill 471 92 297 471 94 297 minecraft:deepslate_tiles
setblock 471 92 301 minecraft:cobbled_deepslate
fill 471 92 302 471 93 302 minecraft:deepslate_tiles
setblock 471 92 311 minecraft:cobbled_deepslate
setblock 471 92 312 minecraft:deepslate_tiles
setblock 471 92 316 minecraft:cobbled_deepslate
fill 472 92 276 475 92 276 minecraft:deepslate_tiles
setblock 472 92 280 minecraft:cobbled_deepslate
fill 472 92 281 472 94 281 minecraft:deepslate_tiles
setblock 472 92 315 minecraft:cobbled_deepslate
fill 472 92 316 475 92 316 minecraft:deepslate_tiles
setblock 473 92 279 minecraft:cobbled_deepslate
fill 473 92 315 476 92 315 minecraft:deepslate_tiles
setblock 475 92 277 minecraft:cobbled_deepslate
fill 475 92 317 475 94 317 minecraft:cobbled_deepslate
setblock 476 92 276 minecraft:cobbled_deepslate
fill 476 92 277 479 92 277 minecraft:deepslate_tiles
fill 476 92 313 476 93 313 minecraft:black_concrete
setblock 476 92 316 minecraft:cobbled_deepslate
fill 477 92 276 480 92 276 minecraft:deepslate_tiles
setblock 477 92 315 minecraft:cobbled_deepslate
fill 477 92 316 480 92 316 minecraft:deepslate_tiles
fill 478 92 315 481 92 315 minecraft:deepslate_tiles
setblock 480 92 277 minecraft:cobbled_deepslate
setblock 481 92 275 minecraft:black_concrete
setblock 481 92 276 minecraft:cobbled_deepslate
fill 481 92 277 484 92 277 minecraft:deepslate_tiles
setblock 481 92 316 minecraft:cobbled_deepslate
fill 482 92 276 482 95 276 minecraft:deepslate_tiles
setblock 482 92 315 minecraft:cobbled_deepslate
fill 482 92 316 482 95 316 minecraft:deepslate_tiles
fill 482 92 317 482 94 317 minecraft:cobbled_deepslate
setblock 483 92 278 minecraft:deepslate_tiles
setblock 483 92 314 minecraft:cobbled_deepslate
fill 483 92 315 483 95 315 minecraft:deepslate_tiles
setblock 484 92 278 minecraft:cobbled_deepslate
fill 484 92 314 484 93 314 minecraft:deepslate_tiles
setblock 485 92 277 minecraft:cobbled_deepslate
fill 485 92 278 485 93 278 minecraft:deepslate_tiles
fill 486 92 275 486 93 275 minecraft:black_concrete
setblock 486 92 276 minecraft:cobbled_deepslate
fill 486 92 277 486 95 277 minecraft:deepslate_tiles
setblock 486 92 316 minecraft:cobbled_deepslate
fill 487 92 276 487 95 276 minecraft:deepslate_tiles
setblock 487 92 278 minecraft:deepslate_tiles
setblock 487 92 315 minecraft:cobbled_deepslate
fill 487 92 316 487 95 316 minecraft:deepslate_tiles
setblock 488 92 314 minecraft:cobbled_deepslate
fill 488 92 315 488 94 315 minecraft:deepslate_tiles
fill 489 92 275 489 95 275 minecraft:cobbled_deepslate
setblock 489 92 314 minecraft:deepslate_tiles
setblock 490 92 277 minecraft:cobbled_deepslate
setblock 491 92 276 minecraft:cobbled_deepslate
setblock 491 92 277 minecraft:deepslate_tiles
setblock 491 92 316 minecraft:cobbled_deepslate
setblock 492 92 275 minecraft:black_concrete
fill 492 92 276 492 93 276 minecraft:deepslate_tiles
setblock 492 92 315 minecraft:cobbled_deepslate
fill 492 92 316 492 94 316 minecraft:deepslate_tiles
fill 495 92 275 496 94 275 minecraft:cobbled_deepslate
fill 499 92 276 500 92 276 minecraft:deepslate_tiles
fill 499 92 317 499 94 317 minecraft:cobbled_deepslate
setblock 501 92 276 minecraft:cobbled_deepslate
setblock 501 92 316 minecraft:cobbled_deepslate
fill 502 92 276 502 95 276 minecraft:deepslate_tiles
fill 502 92 316 502 93 316 minecraft:deepslate_tiles
fill 502 92 317 503 92 317 minecraft:cobbled_deepslate
setblock 504 92 278 minecraft:cobbled_deepslate
setblock 505 92 277 minecraft:cobbled_deepslate
fill 505 92 278 505 95 278 minecraft:deepslate_tiles
setblock 506 92 276 minecraft:cobbled_deepslate
fill 506 92 277 506 95 277 minecraft:deepslate_tiles
setblock 506 92 316 minecraft:cobbled_deepslate
fill 507 92 275 507 93 275 minecraft:black_concrete
fill 507 92 276 507 95 276 minecraft:deepslate_tiles
setblock 507 92 279 minecraft:deepslate_tiles
setblock 507 92 315 minecraft:cobbled_deepslate
fill 507 92 316 507 95 316 minecraft:deepslate_tiles
fill 507 92 317 507 95 317 minecraft:cobbled_deepslate
setblock 508 92 278 minecraft:deepslate_tiles
setblock 508 92 279 minecraft:cobbled_deepslate
setblock 508 92 294 minecraft:cobbled_deepslate
setblock 508 92 295 minecraft:deepslate_tiles
setblock 508 92 298 minecraft:deepslate_tiles
setblock 508 92 299 minecraft:cobbled_deepslate
setblock 508 92 315 minecraft:deepslate_tiles
setblock 509 92 278 minecraft:cobbled_deepslate
fill 509 92 279 509 92 282 minecraft:deepslate_tiles
setblock 509 92 283 minecraft:cobbled_deepslate
setblock 509 92 284 minecraft:deepslate_tiles
setblock 509 92 293 minecraft:cobbled_deepslate
fill 509 92 294 509 93 294 minecraft:deepslate_tiles
setblock 509 92 298 minecraft:cobbled_deepslate
fill 509 92 299 509 93 299 minecraft:deepslate_tiles
fill 509 92 317 509 94 317 minecraft:cobbled_deepslate
setblock 510 92 277 minecraft:cobbled_deepslate
fill 510 92 278 510 95 278 minecraft:deepslate_tiles
setblock 510 92 282 minecraft:cobbled_deepslate
fill 510 92 283 510 95 283 minecraft:deepslate_tiles
setblock 510 92 287 minecraft:cobbled_deepslate
fill 510 92 288 510 93 288 minecraft:deepslate_tiles
setblock 510 92 292 minecraft:cobbled_deepslate
fill 510 92 293 510 94 293 minecraft:deepslate_tiles
setblock 510 92 297 minecraft:cobbled_deepslate
fill 510 92 298 510 95 298 minecraft:deepslate_tiles
setblock 510 92 302 minecraft:cobbled_deepslate
setblock 511 92 276 minecraft:cobbled_deepslate
fill 511 92 277 511 95 277 minecraft:deepslate_tiles
setblock 511 92 281 minecraft:cobbled_deepslate
fill 511 92 282 511 95 282 minecraft:deepslate_tiles
setblock 511 92 286 minecraft:cobbled_deepslate
fill 511 92 287 511 95 287 minecraft:deepslate_tiles
setblock 511 92 291 minecraft:cobbled_deepslate
fill 511 92 292 511 94 292 minecraft:deepslate_tiles
fill 511 92 296 512 92 296 minecraft:cobbled_deepslate
fill 511 92 297 511 95 297 minecraft:deepslate_tiles
setblock 511 92 301 minecraft:cobbled_deepslate
fill 511 92 302 511 95 302 minecraft:deepslate_tiles
setblock 511 92 316 minecraft:cobbled_deepslate
fill 512 92 275 512 94 275 minecraft:cobbled_deepslate
setblock 512 92 277 minecraft:redstone_block
fill 512 92 278 512 95 278 minecraft:cobbled_deepslate
fill 512 92 280 512 94 280 minecraft:cobbled_deepslate
setblock 512 92 292 minecraft:black_concrete
fill 512 92 293 512 92 295 minecraft:cobbled_deepslate
fill 512 92 298 512 94 298 minecraft:cobbled_deepslate
fill 512 92 299 512 93 299 minecraft:black_concrete
fill 512 92 300 512 94 300 minecraft:cobbled_deepslate
setblock 512 92 301 minecraft:black_concrete
setblock 470 93 275 minecraft:black_concrete
fill 470 93 276 470 94 279 minecraft:cobbled_deepslate
fill 470 93 282 470 94 283 minecraft:cobbled_deepslate
setblock 470 93 285 minecraft:black_concrete
setblock 470 93 293 minecraft:black_concrete
setblock 470 93 298 minecraft:black_concrete
fill 470 93 301 470 94 301 minecraft:cobbled_deepslate
fill 470 93 303 470 94 303 minecraft:cobbled_deepslate
fill 470 93 310 470 94 310 minecraft:cobbled_deepslate
setblock 470 93 311 minecraft:white_wool
setblock 470 93 315 minecraft:redstone_block
fill 471 93 275 471 94 275 minecraft:cobbled_deepslate
fill 471 93 276 471 93 279 minecraft:deepslate_tiles
setblock 471 93 280 minecraft:cobbled_deepslate
fill 471 93 281 471 93 284 minecraft:deepslate_tiles
setblock 471 93 285 minecraft:cobbled_deepslate
setblock 471 93 295 minecraft:cobbled_deepslate
setblock 471 93 296 minecraft:deepslate_tiles
setblock 471 93 300 minecraft:cobbled_deepslate
fill 471 93 301 471 94 301 minecraft:deepslate_tiles
setblock 471 93 315 minecraft:cobbled_deepslate
fill 471 93 316 474 93 316 minecraft:deepslate_tiles
fill 471 93 317 473 94 317 minecraft:cobbled_deepslate
fill 472 93 276 474 93 276 minecraft:deepslate_tiles
setblock 472 93 279 minecraft:cobbled_deepslate
fill 472 93 280 472 95 280 minecraft:deepslate_tiles
setblock 472 93 315 minecraft:deepslate_tiles
setblock 473 93 278 minecraft:light[level=13]
setblock 473 93 286 minecraft:light[level=13]
setblock 473 93 294 minecraft:light[level=13]
setblock 473 93 302 minecraft:light[level=13]
setblock 473 93 310 minecraft:light[level=13]
setblock 474 93 277 minecraft:cobbled_deepslate
setblock 474 93 317 minecraft:black_concrete
setblock 475 93 276 minecraft:cobbled_deepslate
fill 475 93 277 478 93 277 minecraft:deepslate_tiles
setblock 475 93 316 minecraft:cobbled_deepslate
fill 476 93 276 479 93 276 minecraft:deepslate_tiles
fill 476 93 316 479 93 316 minecraft:deepslate_tiles
setblock 479 93 277 minecraft:cobbled_deepslate
fill 479 93 315 480 93 315 minecraft:deepslate_tiles
setblock 480 93 276 minecraft:cobbled_deepslate
fill 480 93 277 483 93 277 minecraft:deepslate_tiles
setblock 480 93 316 minecraft:cobbled_deepslate
fill 481 93 275 481 94 275 minecraft:cobbled_deepslate
fill 481 93 276 481 96 276 minecraft:deepslate_tiles
setblock 481 93 278 minecraft:light[level=13]
setblock 481 93 286 minecraft:light[level=13]
setblock 481 93 294 minecraft:light[level=13]
setblock 481 93 302 minecraft:light[level=13]
setblock 481 93 310 minecraft:light[level=13]
setblock 481 93 315 minecraft:cobbled_deepslate
fill 481 93 316 481 96 316 minecraft:deepslate_tiles
fill 482 93 315 482 96 315 minecraft:deepslate_tiles
setblock 483 93 314 minecraft:deepslate_tiles
setblock 484 93 277 minecraft:cobbled_deepslate
setblock 484 93 278 minecraft:deepslate_tiles
setblock 485 93 276 minecraft:cobbled_deepslate
fill 485 93 277 485 96 277 minecraft:deepslate_tiles
setblock 485 93 316 minecraft:cobbled_deepslate
fill 486 93 276 486 96 276 minecraft:deepslate_tiles
setblock 486 93 315 minecraft:cobbled_deepslate
fill 486 93 316 486 96 316 minecraft:deepslate_tiles
setblock 487 93 314 minecraft:cobbled_deepslate
fill 487 93 315 487 95 315 minecraft:deepslate_tiles
setblock 488 93 314 minecraft:deepslate_tiles
setblock 489 93 277 minecraft:cobbled_deepslate
setblock 489 93 278 minecraft:light[level=13]
setblock 489 93 286 minecraft:light[level=13]
setblock 489 93 294 minecraft:light[level=13]
setblock 489 93 302 minecraft:light[level=13]
setblock 489 93 310 minecraft:light[level=13]
setblock 490 93 276 minecraft:cobbled_deepslate
setblock 490 93 277 minecraft:deepslate_tiles
setblock 490 93 316 minecraft:cobbled_deepslate
fill 491 93 276 491 94 276 minecraft:deepslate_tiles
setblock 491 93 315 minecraft:cobbled_deepslate
fill 491 93 316 491 94 316 minecraft:deepslate_tiles
fill 492 93 275 492 94 275 minecraft:cobbled_deepslate
setblock 492 93 317 minecraft:black_concrete
setblock 497 93 278 minecraft:light[level=13]
setblock 497 93 286 minecraft:light[level=13]
setblock 497 93 294 minecraft:light[level=13]
setblock 497 93 302 minecraft:light[level=13]
setblock 497 93 310 minecraft:light[level=13]
setblock 499 93 276 minecraft:deepslate_tiles
setblock 500 93 276 minecraft:cobbled_deepslate
fill 501 93 276 501 96 276 minecraft:deepslate_tiles
fill 502 93 275 504 94 275 minecraft:cobbled_deepslate
setblock 502 93 317 minecraft:black_concrete
fill 503 93 317 503 94 317 minecraft:cobbled_deepslate
setblock 504 93 277 minecraft:cobbled_deepslate
fill 504 93 278 504 96 278 minecraft:deepslate_tiles
setblock 505 93 275 minecraft:black_concrete
setblock 505 93 276 minecraft:cobbled_deepslate
fill 505 93 277 505 96 277 minecraft:deepslate_tiles
setblock 505 93 286 minecraft:light[level=13]
setblock 505 93 294 minecraft:light[level=13]
setblock 505 93 302 minecraft:light[level=13]
setblock 505 93 310 minecraft:light[level=13]
setblock 505 93 316 minecraft:cobbled_deepslate
setblock 505 93 317 minecraft:black_concrete
fill 506 93 276 506 96 276 minecraft:deepslate_tiles
fill 506 93 316 506 96 316 minecraft:deepslate_tiles
setblock 507 93 279 minecraft:cobbled_deepslate
setblock 508 93 278 minecraft:cobbled_deepslate
fill 508 93 279 509 93 279 minecraft:deepslate_tiles
setblock 508 93 317 minecraft:black_concrete
setblock 509 93 277 minecraft:cobbled_deepslate
fill 509 93 278 509 96 278 minecraft:deepslate_tiles
fill 509 93 280 509 93 281 minecraft:deepslate_tiles
setblock 509 93 282 minecraft:cobbled_deepslate
fill 509 93 283 509 94 283 minecraft:deepslate_tiles
setblock 509 93 293 minecraft:deepslate_tiles
setblock 509 93 297 minecraft:cobbled_deepslate
fill 509 93 298 509 94 298 minecraft:deepslate_tiles
setblock 510 93 276 minecraft:cobbled_deepslate
fill 510 93 277 510 96 277 minecraft:deepslate_tiles
setblock 510 93 281 minecraft:cobbled_deepslate
fill 510 93 282 510 96 282 minecraft:deepslate_tiles
setblock 510 93 286 minecraft:cobbled_deepslate
setblock 510 93 287 minecraft:deepslate_tiles
setblock 510 93 291 minecraft:cobbled_deepslate
setblock 510 93 292 minecraft:deepslate_tiles
setblock 510 93 296 minecraft:cobbled_deepslate
fill 510 93 297 510 94 297 minecraft:deepslate_tiles
setblock 510 93 301 minecraft:cobbled_deepslate
setblock 510 93 302 minecraft:deepslate_tiles
setblock 510 93 316 minecraft:cobbled_deepslate
setblock 511 93 275 minecraft:black_concrete
fill 511 93 276 511 96 276 minecraft:deepslate_tiles
setblock 511 93 280 minecraft:cobbled_deepslate
fill 511 93 281 511 96 281 minecraft:deepslate_tiles
setblock 511 93 285 minecraft:cobbled_deepslate
fill 511 93 286 511 96 286 minecraft:deepslate_tiles
setblock 511 93 290 minecraft:cobbled_deepslate
fill 511 93 291 511 94 291 minecraft:deepslate_tiles
setblock 511 93 295 minecraft:cobbled_deepslate
fill 511 93 296 511 95 296 minecraft:deepslate_tiles
setblock 511 93 300 minecraft:cobbled_deepslate
fill 511 93 301 511 95 301 minecraft:deepslate_tiles
setblock 511 93 315 minecraft:cobbled_deepslate
fill 511 93 316 511 94 316 minecraft:deepslate_tiles
fill 512 93 277 512 94 277 minecraft:cobbled_deepslate
setblock 512 93 285 minecraft:black_concrete
setblock 512 93 287 minecraft:black_concrete
fill 512 93 291 512 94 294 minecraft:cobbled_deepslate
setblock 512 93 295 minecraft:black_concrete
fill 512 93 296 512 94 296 minecraft:cobbled_deepslate
fill 512 93 301 512 94 301 minecraft:cobbled_deepslate
setblock 512 93 305 minecraft:black_concrete
setblock 512 93 308 minecraft:black_concrete
setblock 512 93 313 minecraft:black_concrete
fill 470 94 275 470 95 275 minecraft:cobbled_deepslate
setblock 470 94 285 minecraft:cobbled_deepslate
setblock 470 94 293 minecraft:cobbled_deepslate
setblock 470 94 298 minecraft:cobbled_deepslate
setblock 470 94 311 minecraft:cobbled_deepslate
setblock 470 94 315 minecraft:white_wool
fill 471 94 276 471 94 278 minecraft:deepslate_tiles
setblock 471 94 279 minecraft:cobbled_deepslate
fill 471 94 280 471 94 283 minecraft:deepslate_tiles
setblock 471 94 284 minecraft:cobbled_deepslate
setblock 471 94 299 minecraft:cobbled_deepslate
setblock 471 94 300 minecraft:deepslate_tiles
setblock 471 94 314 minecraft:cobbled_deepslate
fill 471 94 315 471 95 316 minecraft:deepslate_tiles
fill 472 94 276 473 94 276 minecraft:deepslate_tiles
setblock 472 94 278 minecraft:cobbled_deepslate
fill 472 94 279 472 96 279 minecraft:deepslate_tiles
fill 472 94 316 473 94 316 minecraft:deepslate_tiles
setblock 473 94 277 minecraft:cobbled_deepslate
setblock 474 94 276 minecraft:cobbled_deepslate
fill 474 94 277 477 94 277 minecraft:deepslate_tiles
fill 474 94 316 474 94 317 minecraft:cobbled_deepslate
fill 475 94 276 478 94 276 minecraft:deepslate_tiles
setblock 475 94 312 minecraft:white_wool
fill 475 94 316 478 94 316 minecraft:deepslate_tiles
setblock 476 94 313 minecraft:white_wool
setblock 477 94 314 minecraft:white_wool
setblock 478 94 277 minecraft:cobbled_deepslate
setblock 478 94 315 minecraft:white_wool
setblock 479 94 276 minecraft:cobbled_deepslate
fill 479 94 277 482 94 277 minecraft:deepslate_tiles
setblock 479 94 316 minecraft:cobbled_deepslate
fill 480 94 276 480 97 276 minecraft:deepslate_tiles
setblock 480 94 315 minecraft:cobbled_deepslate
fill 480 94 316 480 97 316 minecraft:deepslate_tiles
fill 481 94 315 481 96 315 minecraft:deepslate_tiles
setblock 483 94 277 minecraft:cobbled_deepslate
setblock 484 94 276 minecraft:cobbled_deepslate
fill 484 94 277 484 97 277 minecraft:deepslate_tiles
setblock 484 94 316 minecraft:cobbled_deepslate
fill 485 94 276 485 97 276 minecraft:deepslate_tiles
setblock 485 94 315 minecraft:cobbled_deepslate
fill 485 94 316 485 97 316 minecraft:deepslate_tiles
fill 486 94 275 486 95 275 minecraft:cobbled_deepslate
fill 486 94 315 486 96 315 minecraft:deepslate_tiles
setblock 488 94 277 minecraft:cobbled_deepslate
setblock 489 94 276 minecraft:cobbled_deepslate
setblock 489 94 277 minecraft:deepslate_tiles
setblock 489 94 316 minecraft:cobbled_deepslate
fill 490 94 276 490 95 276 minecraft:deepslate_tiles
fill 490 94 316 490 95 316 minecraft:deepslate_tiles
setblock 492 94 317 minecraft:cobbled_deepslate
fill 500 94 276 500 97 276 minecraft:deepslate_tiles
fill 501 94 277 501 95 277 minecraft:deepslate_tiles
setblock 502 94 317 minecraft:cobbled_deepslate
setblock 503 94 277 minecraft:cobbled_deepslate
fill 503 94 278 503 97 278 minecraft:deepslate_tiles
setblock 504 94 276 minecraft:cobbled_deepslate
fill 504 94 277 504 97 277 minecraft:deepslate_tiles
setblock 504 94 316 minecraft:cobbled_deepslate
setblock 505 94 275 minecraft:cobbled_deepslate
fill 505 94 276 505 97 276 minecraft:deepslate_tiles
fill 505 94 316 505 96 316 minecraft:deepslate_tiles
setblock 505 94 317 minecraft:cobbled_deepslate
setblock 507 94 275 minecraft:cobbled_deepslate
setblock 507 94 278 minecraft:cobbled_deepslate
setblock 508 94 277 minecraft:cobbled_deepslate
fill 508 94 278 508 97 278 minecraft:deepslate_tiles
setblock 508 94 317 minecraft:cobbled_deepslate
setblock 509 94 276 minecraft:cobbled_deepslate
fill 509 94 277 509 97 277 minecraft:deepslate_tiles
fill 509 94 279 509 94 280 minecraft:deepslate_tiles
setblock 509 94 281 minecraft:cobbled_deepslate
fill 509 94 282 509 97 282 minecraft:deepslate_tiles
setblock 509 94 297 minecraft:deepslate_tiles
setblock 509 94 316 minecraft:cobbled_deepslate
fill 510 94 276 510 97 276 minecraft:deepslate_tiles
setblock 510 94 280 minecraft:cobbled_deepslate
fill 510 94 281 510 97 281 minecraft:deepslate_tiles
setblock 510 94 285 minecraft:cobbled_deepslate
setblock 510 94 295 minecraft:cobbled_deepslate
setblock 510 94 296 minecraft:deepslate_tiles
setblock 510 94 300 minecraft:cobbled_deepslate
setblock 510 94 301 minecraft:deepslate_tiles
setblock 510 94 316 minecraft:deepslate_tiles
setblock 511 94 275 minecraft:cobbled_deepslate
setblock 511 94 279 minecraft:cobbled_deepslate
fill 511 94 280 511 97 280 minecraft:deepslate_tiles
setblock 511 94 284 minecraft:cobbled_deepslate
fill 511 94 285 511 97 285 minecraft:deepslate_tiles
setblock 511 94 289 minecraft:cobbled_deepslate
setblock 511 94 290 minecraft:deepslate_tiles
setblock 511 94 294 minecraft:cobbled_deepslate
fill 511 94 295 511 95 295 minecraft:deepslate_tiles
fill 511 94 299 512 94 299 minecraft:cobbled_deepslate
fill 511 94 300 511 96 300 minecraft:deepslate_tiles
setblock 512 94 285 minecraft:cobbled_deepslate
setblock 512 94 287 minecraft:cobbled_deepslate
setblock 512 94 295 minecraft:cobbled_deepslate
setblock 512 94 305 minecraft:cobbled_deepslate
setblock 512 94 308 minecraft:cobbled_deepslate
setblock 512 94 313 minecraft:cobbled_deepslate
fill 470 95 276 470 96 280 minecraft:black_concrete
fill 470 95 281 470 96 281 minecraft:cobbled_deepslate
fill 470 95 282 470 137 283 minecraft:black_concrete
fill 470 95 285 470 96 295 minecraft:black_concrete
setblock 470 95 296 minecraft:cobbled_deepslate
fill 470 95 297 470 201 298 minecraft:black_concrete
setblock 470 95 299 minecraft:cobbled_deepslate
fill 470 95 300 470 173 302 minecraft:black_concrete
setblock 470 95 303 minecraft:white_wool
fill 470 95 304 470 96 305 minecraft:black_concrete
fill 470 95 307 470 189 307 minecraft:black_concrete
fill 470 95 309 470 95 317 minecraft:black_concrete
fill 471 95 275 479 95 275 minecraft:black_concrete
fill 471 95 276 471 95 277 minecraft:deepslate_tiles
setblock 471 95 278 minecraft:cobbled_deepslate
fill 471 95 279 471 95 282 minecraft:deepslate_tiles
setblock 471 95 283 minecraft:cobbled_deepslate
setblock 471 95 284 minecraft:deepslate_tiles
setblock 471 95 308 minecraft:white_wool
fill 471 95 317 476 95 317 minecraft:black_concrete
setblock 472 95 276 minecraft:deepslate_tiles
setblock 472 95 277 minecraft:cobbled_deepslate
fill 472 95 278 472 96 278 minecraft:deepslate_tiles
setblock 472 95 309 minecraft:white_wool
setblock 472 95 316 minecraft:deepslate_tiles
setblock 473 95 276 minecraft:cobbled_deepslate
fill 473 95 277 474 95 277 minecraft:deepslate_tiles
setblock 473 95 310 minecraft:white_wool
setblock 473 95 316 minecraft:cobbled_deepslate
fill 474 95 276 477 95 276 minecraft:deepslate_tiles
setblock 474 95 311 minecraft:white_wool
fill 474 95 316 477 95 316 minecraft:deepslate_tiles
fill 476 95 313 476 101 313 minecraft:black_concrete
setblock 478 95 276 minecraft:cobbled_deepslate
setblock 478 95 316 minecraft:cobbled_deepslate
fill 478 95 317 488 96 317 minecraft:black_concrete
fill 479 95 276 479 95 277 minecraft:deepslate_tiles
fill 479 95 316 479 98 316 minecraft:deepslate_tiles
fill 480 95 277 481 95 277 minecraft:deepslate_tiles
fill 481 95 275 485 132 275 minecraft:black_concrete
setblock 482 95 277 minecraft:cobbled_deepslate
setblock 483 95 276 minecraft:cobbled_deepslate
fill 483 95 277 483 98 277 minecraft:deepslate_tiles
setblock 483 95 316 minecraft:cobbled_deepslate
fill 484 95 276 484 98 276 minecraft:deepslate_tiles
setblock 484 95 315 minecraft:cobbled_deepslate
fill 484 95 316 484 98 316 minecraft:deepslate_tiles
fill 485 95 315 485 96 315 minecraft:deepslate_tiles
fill 487 95 275 488 112 275 minecraft:black_concrete
setblock 487 95 277 minecraft:cobbled_deepslate
setblock 488 95 276 minecraft:cobbled_deepslate
setblock 488 95 277 minecraft:deepslate_tiles
setblock 488 95 316 minecraft:cobbled_deepslate
fill 489 95 276 489 96 276 minecraft:deepslate_tiles
fill 489 95 316 489 96 316 minecraft:deepslate_tiles
setblock 489 95 317 minecraft:cobbled_deepslate
fill 490 95 275 495 96 275 minecraft:black_concrete
fill 491 95 317 493 95 317 minecraft:black_concrete
setblock 494 95 317 minecraft:cobbled_deepslate
fill 495 95 317 497 96 317 minecraft:black_concrete
setblock 496 95 275 minecraft:cobbled_deepslate
fill 497 95 275 512 95 275 minecraft:black_concrete
fill 499 95 317 499 201 317 minecraft:black_concrete
fill 501 95 317 503 96 317 minecraft:black_concrete
setblock 502 95 277 minecraft:cobbled_deepslate
setblock 503 95 276 minecraft:cobbled_deepslate
fill 503 95 277 503 98 277 minecraft:deepslate_tiles
fill 504 95 276 504 98 276 minecraft:deepslate_tiles
setblock 504 95 316 minecraft:deepslate_tiles
fill 505 95 317 506 95 317 minecraft:black_concrete
setblock 506 95 278 minecraft:cobbled_deepslate
setblock 507 95 277 minecraft:cobbled_deepslate
fill 507 95 278 507 98 278 minecraft:deepslate_tiles
setblock 508 95 276 minecraft:cobbled_deepslate
fill 508 95 277 508 98 277 minecraft:deepslate_tiles
setblock 508 95 316 minecraft:cobbled_deepslate
fill 508 95 317 512 95 317 minecraft:black_concrete
fill 509 95 276 509 98 276 minecraft:deepslate_tiles
setblock 509 95 279 minecraft:deepslate_tiles
setblock 509 95 280 minecraft:cobbled_deepslate
fill 509 95 281 509 98 281 minecraft:deepslate_tiles
setblock 509 95 316 minecraft:deepslate_tiles
setblock 510 95 279 minecraft:cobbled_deepslate
fill 510 95 280 510 98 280 minecraft:deepslate_tiles
setblock 510 95 284 minecraft:cobbled_deepslate
setblock 510 95 285 minecraft:deepslate_tiles
setblock 511 95 278 minecraft:cobbled_deepslate
fill 511 95 279 511 98 279 minecraft:deepslate_tiles
setblock 511 95 283 minecraft:cobbled_deepslate
fill 511 95 284 511 98 284 minecraft:deepslate_tiles
setblock 511 95 294 minecraft:deepslate_tiles
setblock 511 95 298 minecraft:cobbled_deepslate
fill 511 95 299 511 96 299 minecraft:deepslate_tiles
fill 512 95 276 512 96 277 minecraft:black_concrete
fill 512 95 280 512 95 316 minecraft:black_concrete
fill 470 96 275 470 201 275 minecraft:black_concrete
fill 470 96 284 470 104 284 minecraft:black_concrete
fill 470 96 296 470 201 296 minecraft:black_concrete
fill 470 96 299 470 201 299 minecraft:black_concrete
fill 470 96 303 470 157 303 minecraft:black_concrete
setblock 470 96 306 minecraft:black_concrete
fill 470 96 308 470 110 316 minecraft:black_concrete
setblock 470 96 317 minecraft:cobbled_deepslate
setblock 471 96 275 minecraft:cobbled_deepslate
setblock 471 96 276 minecraft:deepslate_tiles
setblock 471 96 277 minecraft:cobbled_deepslate
fill 471 96 278 471 96 281 minecraft:deepslate_tiles
setblock 471 96 282 minecraft:cobbled_deepslate
fill 471 96 283 471 99 283 minecraft:deepslate_tiles
setblock 471 96 316 minecraft:deepslate_tiles
fill 471 96 317 472 198 317 minecraft:black_concrete
fill 472 96 275 473 198 275 minecraft:black_concrete
setblock 472 96 276 minecraft:cobbled_deepslate
setblock 472 96 277 minecraft:deepslate_tiles
fill 473 96 276 476 96 276 minecraft:deepslate_tiles
setblock 473 96 317 minecraft:white_wool
fill 474 96 275 475 96 275 minecraft:cobbled_deepslate
fill 474 96 317 477 126 317 minecraft:black_concrete
fill 475 96 313 475 101 313 minecraft:black_concrete
fill 476 96 275 478 148 275 minecraft:black_concrete
fill 476 96 312 476 101 312 minecraft:black_concrete
fill 476 96 314 476 101 314 minecraft:black_concrete
setblock 477 96 276 minecraft:cobbled_deepslate
fill 477 96 313 477 101 313 minecraft:black_concrete
setblock 477 96 316 minecraft:cobbled_deepslate
fill 478 96 276 479 98 276 minecraft:deepslate_tiles
fill 478 96 316 478 99 316 minecraft:deepslate_tiles
setblock 479 96 275 minecraft:cobbled_deepslate
setblock 480 96 275 minecraft:black_concrete
setblock 480 96 277 minecraft:deepslate_tiles
setblock 481 96 277 minecraft:cobbled_deepslate
setblock 482 96 276 minecraft:cobbled_deepslate
fill 482 96 277 482 99 277 minecraft:deepslate_tiles
setblock 482 96 316 minecraft:cobbled_deepslate
fill 483 96 276 483 99 276 minecraft:deepslate_tiles
setblock 483 96 315 minecraft:cobbled_deepslate
fill 483 96 316 483 99 316 minecraft:deepslate_tiles
fill 484 96 315 484 97 315 minecraft:deepslate_tiles
fill 486 96 275 486 201 275 minecraft:black_concrete
setblock 486 96 277 minecraft:cobbled_deepslate
setblock 487 96 276 minecraft:cobbled_deepslate
setblock 487 96 316 minecraft:cobbled_deepslate
fill 488 96 276 488 97 276 minecraft:deepslate_tiles
setblock 488 96 316 minecraft:deepslate_tiles
fill 489 96 275 489 98 275 minecraft:black_concrete
fill 489 96 317 492 118 317 minecraft:black_concrete
setblock 493 96 317 minecraft:cobbled_deepslate
fill 494 96 317 494 141 317 minecraft:black_concrete
fill 496 96 275 504 181 275 minecraft:black_concrete
fill 498 96 317 498 110 317 minecraft:black_concrete
fill 500 96 317 500 197 317 minecraft:black_concrete
setblock 501 96 277 minecraft:cobbled_deepslate
setblock 502 96 276 minecraft:cobbled_deepslate
fill 502 96 277 502 99 277 minecraft:deepslate_tiles
fill 503 96 276 503 99 276 minecraft:deepslate_tiles
fill 504 96 317 505 164 317 minecraft:black_concrete
setblock 505 96 275 minecraft:cobbled_deepslate
setblock 505 96 278 minecraft:cobbled_deepslate
fill 506 96 275 507 179 275 minecraft:black_concrete
setblock 506 96 277 minecraft:cobbled_deepslate
fill 506 96 278 506 99 278 minecraft:deepslate_tiles
setblock 506 96 317 minecraft:cobbled_deepslate
setblock 507 96 276 minecraft:cobbled_deepslate
fill 507 96 277 507 99 277 minecraft:deepslate_tiles
fill 507 96 317 509 114 317 minecraft:black_concrete
setblock 508 96 275 minecraft:cobbled_deepslate
fill 508 96 276 508 99 276 minecraft:deepslate_tiles
fill 509 96 275 512 197 275 minecraft:black_concrete
setblock 509 96 279 minecraft:cobbled_deepslate
fill 509 96 280 509 99 280 minecraft:deepslate_tiles
setblock 510 96 278 minecraft:cobbled_deepslate
fill 510 96 279 510 99 279 minecraft:deepslate_tiles
setblock 510 96 283 minecraft:cobbled_deepslate
fill 510 96 284 510 99 284 minecraft:deepslate_tiles
setblock 510 96 317 minecraft:cobbled_deepslate
setblock 511 96 277 minecraft:cobbled_deepslate
fill 511 96 278 511 99 278 minecraft:deepslate_tiles
setblock 511 96 282 minecraft:cobbled_deepslate
fill 511 96 283 511 99 283 minecraft:deepslate_tiles
setblock 511 96 298 minecraft:deepslate_tiles
fill 511 96 317 511 119 317 minecraft:black_concrete
fill 512 96 278 512 96 299 minecraft:black_concrete
fill 512 96 300 512 96 301 minecraft:cobbled_deepslate
fill 512 96 302 512 96 310 minecraft:black_concrete
setblock 512 96 311 minecraft:cobbled_deepslate
fill 512 96 312 512 96 316 minecraft:black_concrete
setblock 512 96 317 minecraft:cobbled_deepslate
fill 470 97 276 470 165 277 minecraft:black_concrete
setblock 470 97 278 minecraft:cobbled_deepslate
fill 470 97 279 470 177 281 minecraft:black_concrete
fill 470 97 285 470 118 287 minecraft:black_concrete
setblock 470 97 288 minecraft:cobbled_deepslate
fill 470 97 289 470 169 290 minecraft:black_concrete
setblock 470 97 291 minecraft:cobbled_deepslate
fill 470 97 292 470 117 295 minecraft:black_concrete
setblock 470 97 304 minecraft:cobbled_deepslate
fill 470 97 305 470 101 305 minecraft:black_concrete
setblock 470 97 306 minecraft:cobbled_deepslate
fill 470 97 317 470 199 317 minecraft:black_concrete
fill 471 97 275 471 197 275 minecraft:black_concrete
setblock 471 97 276 minecraft:cobbled_deepslate
fill 471 97 277 471 97 280 minecraft:deepslate_tiles
setblock 471 97 281 minecraft:cobbled_deepslate
fill 471 97 282 471 100 282 minecraft:deepslate_tiles
fill 472 97 276 475 97 276 minecraft:deepslate_tiles
setblock 473 97 278 minecraft:light[level=12]
setblock 473 97 285 minecraft:light[level=12]
setblock 473 97 292 minecraft:light[level=12]
setblock 473 97 299 minecraft:light[level=12]
setblock 473 97 306 minecraft:light[level=12]
setblock 473 97 313 minecraft:light[level=12]
fill 473 97 317 473 144 317 minecraft:black_concrete
fill 474 97 275 475 180 275 minecraft:black_concrete
setblock 476 97 276 minecraft:cobbled_deepslate
fill 477 97 276 477 100 276 minecraft:deepslate_tiles
fill 477 97 316 477 100 316 minecraft:deepslate_tiles
fill 478 97 317 480 197 317 minecraft:black_concrete
fill 479 97 275 479 169 275 minecraft:black_concrete
setblock 480 97 275 minecraft:white_wool
setblock 480 97 277 minecraft:cobbled_deepslate
setblock 480 97 278 minecraft:light[level=12]
setblock 480 97 285 minecraft:light[level=12]
setblock 480 97 292 minecraft:light[level=12]
setblock 480 97 299 minecraft:light[level=12]
setblock 480 97 306 minecraft:light[level=12]
setblock 480 97 313 minecraft:light[level=12]
setblock 481 97 276 minecraft:cobbled_deepslate
fill 481 97 277 481 100 277 minecraft:deepslate_tiles
fill 481 97 316 481 97 317 minecraft:cobbled_deepslate
fill 482 97 276 482 100 276 minecraft:deepslate_tiles
setblock 482 97 315 minecraft:cobbled_deepslate
fill 482 97 316 482 100 316 minecraft:deepslate_tiles
fill 482 97 317 482 105 317 minecraft:black_concrete
fill 483 97 315 483 98 315 minecraft:deepslate_tiles
fill 483 97 317 484 97 317 minecraft:cobbled_deepslate
setblock 485 97 277 minecraft:cobbled_deepslate
fill 485 97 317 488 141 317 minecraft:black_concrete
setblock 486 97 276 minecraft:cobbled_deepslate
setblock 486 97 316 minecraft:cobbled_deepslate
fill 487 97 276 487 98 276 minecraft:deepslate_tiles
setblock 487 97 278 minecraft:light[level=12]
setblock 487 97 285 minecraft:light[level=12]
setblock 487 97 292 minecraft:light[level=12]
setblock 487 97 299 minecraft:light[level=12]
setblock 487 97 306 minecraft:light[level=12]
setblock 487 97 313 minecraft:light[level=12]
fill 487 97 316 487 98 316 minecraft:deepslate_tiles
setblock 490 97 275 minecraft:cobbled_deepslate
fill 491 97 275 495 134 275 minecraft:black_concrete
fill 493 97 317 493 197 317 minecraft:black_concrete
setblock 494 97 278 minecraft:light[level=12]
setblock 494 97 285 minecraft:light[level=12]
setblock 494 97 292 minecraft:light[level=12]
setblock 494 97 299 minecraft:light[level=12]
setblock 494 97 306 minecraft:light[level=12]
setblock 494 97 313 minecraft:light[level=12]
setblock 495 97 317 minecraft:cobbled_deepslate
fill 496 97 317 497 154 317 minecraft:black_concrete
setblock 501 97 276 minecraft:cobbled_deepslate
fill 501 97 277 501 100 277 minecraft:deepslate_tiles
setblock 501 97 278 minecraft:light[level=12]
setblock 501 97 285 minecraft:light[level=12]
setblock 501 97 292 minecraft:light[level=12]
setblock 501 97 299 minecraft:light[level=12]
setblock 501 97 306 minecraft:light[level=12]
setblock 501 97 313 minecraft:light[level=12]
fill 501 97 317 501 116 317 minecraft:black_concrete
fill 502 97 276 502 100 276 minecraft:deepslate_tiles
setblock 502 97 317 minecraft:cobbled_deepslate
fill 503 97 317 503 201 317 minecraft:black_concrete
setblock 504 97 278 minecraft:cobbled_deepslate
fill 505 97 275 505 198 275 minecraft:black_concrete
setblock 505 97 277 minecraft:cobbled_deepslate
fill 505 97 278 505 100 278 minecraft:deepslate_tiles
setblock 506 97 276 minecraft:cobbled_deepslate
fill 506 97 277 506 100 277 minecraft:deepslate_tiles
fill 506 97 317 506 106 317 minecraft:black_concrete
fill 507 97 276 507 100 276 minecraft:deepslate_tiles
fill 508 97 275 508 151 275 minecraft:black_concrete
setblock 508 97 285 minecraft:light[level=12]
setblock 508 97 292 minecraft:light[level=12]
setblock 508 97 299 minecraft:light[level=12]
setblock 508 97 306 minecraft:light[level=12]
setblock 508 97 313 minecraft:light[level=12]
setblock 509 97 278 minecraft:cobbled_deepslate
fill 509 97 279 509 98 279 minecraft:deepslate_tiles
setblock 510 97 277 minecraft:cobbled_deepslate
fill 510 97 278 510 100 278 minecraft:deepslate_tiles
setblock 510 97 282 minecraft:cobbled_deepslate
fill 510 97 283 510 100 283 minecraft:deepslate_tiles
fill 510 97 317 510 198 317 minecraft:black_concrete
fill 511 97 276 512 97 276 minecraft:cobbled_deepslate
fill 511 97 277 511 100 277 minecraft:deepslate_tiles
setblock 511 97 281 minecraft:cobbled_deepslate
fill 511 97 282 511 100 282 minecraft:deepslate_tiles
setblock 511 97 286 minecraft:cobbled_deepslate
fill 512 97 277 512 105 278 minecraft:black_concrete
fill 512 97 279 512 97 280 minecraft:cobbled_deepslate
fill 512 97 281 512 197 284 minecraft:black_concrete
setblock 512 97 285 minecraft:cobbled_deepslate
fill 512 97 286 512 147 287 minecraft:black_concrete
setblock 512 97 288 minecraft:cobbled_deepslate
fill 512 97 289 512 183 295 minecraft:black_concrete
setblock 512 97 296 minecraft:cobbled_deepslate
fill 512 97 297 512 118 299 minecraft:black_concrete
setblock 512 97 300 minecraft:cobbled_deepslate
fill 512 97 301 512 97 304 minecraft:black_concrete
setblock 512 97 305 minecraft:cobbled_deepslate
fill 512 97 306 512 197 306 minecraft:black_concrete
setblock 512 97 307 minecraft:cobbled_deepslate
fill 512 97 308 512 134 312 minecraft:black_concrete
fill 512 97 313 512 97 314 minecraft:cobbled_deepslate
fill 512 97 315 512 201 317 minecraft:black_concrete
fill 470 98 278 470 201 278 minecraft:black_concrete
fill 470 98 288 470 189 288 minecraft:black_concrete
fill 470 98 291 470 176 291 minecraft:black_concrete
fill 470 98 304 470 174 304 minecraft:black_concrete
fill 470 98 306 470 201 306 minecraft:black_concrete
fill 471 98 276 471 98 279 minecraft:deepslate_tiles
setblock 471 98 280 minecraft:cobbled_deepslate
fill 471 98 281 471 101 281 minecraft:deepslate_tiles
fill 472 98 276 474 98 276 minecraft:deepslate_tiles
setblock 475 98 276 minecraft:cobbled_deepslate
fill 475 98 312 475 101 312 minecraft:black_concrete
fill 475 98 314 475 101 314 minecraft:black_concrete
fill 476 98 276 476 101 276 minecraft:deepslate_tiles
fill 477 98 312 477 101 312 minecraft:black_concrete
fill 477 98 314 477 101 314 minecraft:black_concrete
fill 480 98 275 480 199 275 minecraft:black_concrete
setblock 480 98 276 minecraft:cobbled_deepslate
fill 480 98 277 480 101 277 minecraft:deepslate_tiles
setblock 480 98 316 minecraft:cobbled_deepslate
fill 481 98 276 481 101 276 minecraft:deepslate_tiles
fill 481 98 316 481 101 316 minecraft:deepslate_tiles
fill 481 98 317 481 202 317 minecraft:black_concrete
fill 482 98 315 482 101 315 minecraft:deepslate_tiles
fill 483 98 317 484 111 317 minecraft:black_concrete
setblock 484 98 277 minecraft:cobbled_deepslate
setblock 485 98 276 minecraft:cobbled_deepslate
setblock 485 98 316 minecraft:cobbled_deepslate
fill 486 98 276 486 99 276 minecraft:deepslate_tiles
fill 486 98 316 486 99 316 minecraft:deepslate_tiles
fill 490 98 275 490 105 275 minecraft:black_concrete
fill 495 98 317 495 163 317 minecraft:black_concrete
setblock 500 98 276 minecraft:cobbled_deepslate
fill 501 98 276 501 101 276 minecraft:deepslate_tiles
setblock 502 98 278 minecraft:deepslate_tiles
fill 502 98 317 502 103 317 minecraft:black_concrete
setblock 503 98 278 minecraft:cobbled_deepslate
setblock 504 98 277 minecraft:cobbled_deepslate
fill 504 98 278 504 101 278 minecraft:deepslate_tiles
setblock 505 98 276 minecraft:cobbled_deepslate
fill 505 98 277 505 101 277 minecraft:deepslate_tiles
fill 506 98 276 506 101 276 minecraft:deepslate_tiles
setblock 508 98 278 minecraft:cobbled_deepslate
setblock 509 98 277 minecraft:cobbled_deepslate
setblock 509 98 282 minecraft:cobbled_deepslate
setblock 510 98 276 minecraft:cobbled_deepslate
fill 510 98 277 510 99 277 minecraft:deepslate_tiles
setblock 510 98 281 minecraft:cobbled_deepslate
fill 510 98 282 510 101 282 minecraft:deepslate_tiles
fill 511 98 276 511 101 276 minecraft:deepslate_tiles
setblock 511 98 280 minecraft:cobbled_deepslate
fill 511 98 281 511 101 281 minecraft:deepslate_tiles
setblock 511 98 285 minecraft:cobbled_deepslate
fill 511 98 286 511 101 286 minecraft:deepslate_tiles
fill 512 98 276 512 176 276 minecraft:black_concrete
fill 512 98 279 512 192 280 minecraft:black_concrete
fill 512 98 285 512 175 285 minecraft:black_concrete
fill 512 98 288 512 167 288 minecraft:black_concrete
fill 512 98 296 512 130 296 minecraft:black_concrete
fill 512 98 300 512 117 302 minecraft:black_concrete
setblock 512 98 303 minecraft:redstone_block
fill 512 98 304 512 201 305 minecraft:black_concrete
fill 512 98 307 512 154 307 minecraft:black_concrete
fill 512 98 313 512 199 314 minecraft:black_concrete
fill 471 99 276 471 99 278 minecraft:deepslate_tiles
setblock 471 99 279 minecraft:cobbled_deepslate
fill 471 99 280 471 102 280 minecraft:deepslate_tiles
fill 472 99 276 473 99 276 minecraft:deepslate_tiles
fill 475 99 276 475 102 276 minecraft:deepslate_tiles
setblock 478 99 276 minecraft:deepslate_tiles
setblock 479 99 276 minecraft:cobbled_deepslate
setblock 479 99 316 minecraft:cobbled_deepslate
fill 480 99 276 480 102 276 minecraft:deepslate_tiles
fill 480 99 316 480 102 316 minecraft:deepslate_tiles
fill 481 99 315 481 102 315 minecraft:deepslate_tiles
setblock 483 99 277 minecraft:cobbled_deepslate
setblock 484 99 276 minecraft:cobbled_deepslate
setblock 484 99 316 minecraft:cobbled_deepslate
fill 485 99 276 485 101 276 minecraft:deepslate_tiles
fill 485 99 316 485 102 316 minecraft:deepslate_tiles
setblock 489 99 275 minecraft:white_wool
setblock 499 99 276 minecraft:cobbled_deepslate
fill 500 99 276 500 101 277 minecraft:deepslate_tiles
setblock 502 99 278 minecraft:cobbled_deepslate
setblock 503 99 277 minecraft:cobbled_deepslate
fill 503 99 278 503 102 278 minecraft:deepslate_tiles
setblock 504 99 276 minecraft:cobbled_deepslate
fill 504 99 277 504 102 277 minecraft:deepslate_tiles
fill 505 99 276 505 102 276 minecraft:deepslate_tiles
setblock 507 99 278 minecraft:cobbled_deepslate
setblock 508 99 277 minecraft:cobbled_deepslate
setblock 509 99 276 minecraft:cobbled_deepslate
fill 509 99 277 509 101 277 minecraft:deepslate_tiles
setblock 509 99 281 minecraft:cobbled_deepslate
fill 509 99 282 509 102 282 minecraft:deepslate_tiles
fill 510 99 276 510 102 276 minecraft:deepslate_tiles
setblock 510 99 280 minecraft:cobbled_deepslate
fill 510 99 281 510 102 281 minecraft:deepslate_tiles
setblock 510 99 285 minecraft:cobbled_deepslate
setblock 511 99 279 minecraft:cobbled_deepslate
fill 511 99 280 511 102 280 minecraft:deepslate_tiles
setblock 511 99 284 minecraft:cobbled_deepslate
fill 511 99 285 511 102 285 minecraft:deepslate_tiles
fill 512 99 303 512 126 303 minecraft:black_concrete
fill 471 100 276 471 100 277 minecraft:deepslate_tiles
setblock 471 100 278 minecraft:cobbled_deepslate
fill 471 100 279 471 103 279 minecraft:deepslate_tiles
setblock 471 100 283 minecraft:cobbled_deepslate
fill 471 100 284 471 103 284 minecraft:deepslate_tiles
fill 471 100 304 471 101 306 minecraft:deepslate_tiles
setblock 472 100 276 minecraft:deepslate_tiles
fill 476 100 316 476 101 316 minecraft:deepslate_tiles
setblock 478 100 276 minecraft:cobbled_deepslate
setblock 478 100 316 minecraft:cobbled_deepslate
fill 479 100 276 479 103 276 minecraft:deepslate_tiles
fill 479 100 316 479 103 316 minecraft:deepslate_tiles
fill 480 100 315 480 103 315 minecraft:deepslate_tiles
setblock 482 100 277 minecraft:cobbled_deepslate
setblock 483 100 276 minecraft:cobbled_deepslate
setblock 483 100 315 minecraft:deepslate_tiles
setblock 483 100 316 minecraft:cobbled_deepslate
fill 484 100 276 484 102 276 minecraft:deepslate_tiles
fill 484 100 316 484 103 316 minecraft:deepslate_tiles
fill 489 100 275 489 121 275 minecraft:black_concrete
fill 499 100 276 499 103 276 minecraft:deepslate_tiles
setblock 501 100 278 minecraft:cobbled_deepslate
setblock 502 100 277 minecraft:cobbled_deepslate
fill 502 100 278 502 103 278 minecraft:deepslate_tiles
setblock 503 100 276 minecraft:cobbled_deepslate
fill 503 100 277 503 103 277 minecraft:deepslate_tiles
fill 504 100 276 504 103 276 minecraft:deepslate_tiles
setblock 506 100 278 minecraft:cobbled_deepslate
setblock 507 100 277 minecraft:cobbled_deepslate
setblock 507 100 278 minecraft:deepslate_tiles
setblock 508 100 276 minecraft:cobbled_deepslate
fill 508 100 277 508 103 277 minecraft:deepslate_tiles
fill 509 100 276 509 103 276 minecraft:deepslate_tiles
setblock 509 100 280 minecraft:cobbled_deepslate
fill 509 100 281 509 102 281 minecraft:deepslate_tiles
fill 509 100 283 509 101 283 minecraft:deepslate_tiles
setblock 510 100 279 minecraft:cobbled_deepslate
fill 510 100 280 510 103 280 minecraft:deepslate_tiles
setblock 510 100 284 minecraft:cobbled_deepslate
fill 510 100 285 510 103 285 minecraft:deepslate_tiles
setblock 511 100 278 minecraft:cobbled_deepslate
fill 511 100 279 511 103 279 minecraft:deepslate_tiles
setblock 511 100 283 minecraft:cobbled_deepslate
fill 511 100 284 511 103 284 minecraft:deepslate_tiles
setblock 511 100 287 minecraft:deepslate_tiles
setblock 471 101 276 minecraft:deepslate_tiles
setblock 471 101 277 minecraft:cobbled_deepslate
fill 471 101 278 471 104 278 minecraft:deepslate_tiles
setblock 471 101 282 minecraft:cobbled_deepslate
fill 471 101 283 471 104 283 minecraft:deepslate_tiles
fill 471 101 285 471 102 285 minecraft:deepslate_tiles
fill 471 101 303 471 104 303 minecraft:deepslate_tiles
setblock 471 101 307 minecraft:cobbled_deepslate
fill 471 101 308 471 103 309 minecraft:deepslate_tiles
setblock 473 101 278 minecraft:light[level=13]
setblock 473 101 286 minecraft:light[level=13]
setblock 473 101 294 minecraft:light[level=13]
setblock 473 101 302 minecraft:light[level=13]
setblock 473 101 310 minecraft:light[level=13]
setblock 474 101 313 minecraft:black_concrete
fill 475 101 316 475 102 316 minecraft:deepslate_tiles
setblock 476 101 311 minecraft:black_concrete
setblock 476 101 315 minecraft:black_concrete
setblock 477 101 276 minecraft:cobbled_deepslate
setblock 477 101 316 minecraft:cobbled_deepslate
fill 478 101 276 478 104 276 minecraft:deepslate_tiles
setblock 478 101 313 minecraft:black_concrete
fill 478 101 316 478 104 316 minecraft:deepslate_tiles
fill 479 101 315 479 104 315 minecraft:deepslate_tiles
setblock 481 101 277 minecraft:cobbled_deepslate
setblock 481 101 278 minecraft:light[level=13]
setblock 481 101 286 minecraft:light[level=13]
setblock 481 101 294 minecraft:light[level=13]
setblock 481 101 302 minecraft:light[level=13]
setblock 481 101 310 minecraft:light[level=13]
setblock 482 101 276 minecraft:cobbled_deepslate
setblock 482 101 277 minecraft:deepslate_tiles
setblock 482 101 316 minecraft:cobbled_deepslate
fill 483 101 276 483 104 276 minecraft:deepslate_tiles
setblock 483 101 315 minecraft:cobbled_deepslate
fill 483 101 316 483 104 316 minecraft:deepslate_tiles
setblock 489 101 278 minecraft:light[level=13]
setblock 489 101 286 minecraft:light[level=13]
setblock 489 101 294 minecraft:light[level=13]
setblock 489 101 302 minecraft:light[level=13]
setblock 489 101 310 minecraft:light[level=13]
setblock 497 101 278 minecraft:light[level=13]
setblock 497 101 286 minecraft:light[level=13]
setblock 497 101 294 minecraft:light[level=13]
setblock 497 101 302 minecraft:light[level=13]
setblock 497 101 310 minecraft:light[level=13]
fill 498 101 276 498 104 276 minecraft:deepslate_tiles
fill 499 101 277 499 102 277 minecraft:deepslate_tiles
setblock 501 101 277 minecraft:cobbled_deepslate
fill 501 101 278 501 104 278 minecraft:deepslate_tiles
setblock 502 101 276 minecraft:cobbled_deepslate
fill 502 101 277 502 104 277 minecraft:deepslate_tiles
fill 503 101 276 503 104 276 minecraft:deepslate_tiles
setblock 505 101 278 minecraft:cobbled_deepslate
setblock 505 101 286 minecraft:light[level=13]
setblock 505 101 294 minecraft:light[level=13]
setblock 505 101 302 minecraft:light[level=13]
setblock 505 101 310 minecraft:light[level=13]
setblock 506 101 277 minecraft:cobbled_deepslate
fill 506 101 278 506 102 278 minecraft:deepslate_tiles
setblock 507 101 276 minecraft:cobbled_deepslate
fill 507 101 277 507 103 277 minecraft:deepslate_tiles
fill 508 101 276 508 104 276 minecraft:deepslate_tiles
setblock 509 101 280 minecraft:deepslate_tiles
setblock 509 101 284 minecraft:cobbled_deepslate
setblock 510 101 278 minecraft:cobbled_deepslate
fill 510 101 279 510 104 279 minecraft:deepslate_tiles
setblock 510 101 283 minecraft:cobbled_deepslate
fill 510 101 284 510 104 284 minecraft:deepslate_tiles
fill 510 101 286 510 102 286 minecraft:deepslate_tiles
setblock 511 101 277 minecraft:cobbled_deepslate
fill 511 101 278 511 104 278 minecraft:deepslate_tiles
setblock 511 101 282 minecraft:cobbled_deepslate
fill 511 101 283 511 104 283 minecraft:deepslate_tiles
setblock 511 101 287 minecraft:cobbled_deepslate
setblock 470 102 305 minecraft:redstone_block
fill 471 102 277 471 103 277 minecraft:deepslate_tiles
setblock 471 102 281 minecraft:cobbled_deepslate
fill 471 102 282 471 105 282 minecraft:deepslate_tiles
fill 471 102 302 471 105 302 minecraft:deepslate_tiles
fill 471 102 304 471 102 305 minecraft:deepslate_tiles
setblock 471 102 306 minecraft:cobbled_deepslate
fill 471 102 307 472 104 307 minecraft:deepslate_tiles
setblock 471 102 310 minecraft:deepslate_tiles
setblock 471 102 311 minecraft:cobbled_deepslate
fill 471 102 312 471 105 312 minecraft:deepslate_tiles
fill 472 102 306 472 105 306 minecraft:deepslate_tiles
fill 474 102 276 474 103 276 minecraft:deepslate_tiles
fill 474 102 316 474 103 316 minecraft:deepslate_tiles
setblock 476 102 276 minecraft:cobbled_deepslate
setblock 476 102 316 minecraft:cobbled_deepslate
fill 477 102 276 477 105 276 minecraft:deepslate_tiles
setblock 477 102 315 minecraft:cobbled_deepslate
fill 477 102 316 477 105 316 minecraft:deepslate_tiles
fill 478 102 315 478 105 315 minecraft:deepslate_tiles
setblock 479 102 277 minecraft:deepslate_tiles
setblock 480 102 277 minecraft:cobbled_deepslate
setblock 481 102 276 minecraft:cobbled_deepslate
setblock 481 102 277 minecraft:deepslate_tiles
setblock 481 102 316 minecraft:cobbled_deepslate
fill 482 102 276 482 105 276 minecraft:deepslate_tiles
setblock 482 102 315 minecraft:cobbled_deepslate
fill 482 102 316 482 105 316 minecraft:deepslate_tiles
fill 483 102 315 483 105 315 minecraft:deepslate_tiles
fill 497 102 276 497 105 276 minecraft:deepslate_tiles
setblock 500 102 276 minecraft:deepslate_tiles
setblock 500 102 277 minecraft:cobbled_deepslate
fill 500 102 278 500 105 278 minecraft:deepslate_tiles
setblock 501 102 276 minecraft:cobbled_deepslate
fill 501 102 277 501 105 277 minecraft:deepslate_tiles
fill 502 102 276 502 105 276 minecraft:deepslate_tiles
fill 502 102 316 503 104 316 minecraft:deepslate_tiles
setblock 504 102 278 minecraft:cobbled_deepslate
setblock 505 102 277 minecraft:cobbled_deepslate
fill 505 102 278 505 103 278 minecraft:deepslate_tiles
setblock 506 102 276 minecraft:cobbled_deepslate
fill 506 102 277 506 104 277 minecraft:deepslate_tiles
fill 507 102 276 507 105 276 minecraft:deepslate_tiles
setblock 509 102 283 minecraft:cobbled_deepslate
fill 509 102 284 509 104 284 minecraft:deepslate_tiles
setblock 510 102 278 minecraft:deepslate_tiles
setblock 510 102 282 minecraft:cobbled_deepslate
fill 510 102 283 510 105 283 minecraft:deepslate_tiles
setblock 511 102 276 minecraft:cobbled_deepslate
fill 511 102 277 511 105 277 minecraft:deepslate_tiles
setblock 511 102 281 minecraft:cobbled_deepslate
fill 511 102 282 511 105 282 minecraft:deepslate_tiles
setblock 511 102 286 minecraft:cobbled_deepslate
fill 511 102 287 511 104 288 minecraft:deepslate_tiles
fill 470 103 305 470 145 305 minecraft:black_concrete
setblock 471 103 280 minecraft:cobbled_deepslate
fill 471 103 281 471 105 281 minecraft:deepslate_tiles
setblock 471 103 285 minecraft:cobbled_deepslate
fill 471 103 286 471 106 286 minecraft:deepslate_tiles
setblock 471 103 304 minecraft:deepslate_tiles
setblock 471 103 305 minecraft:cobbled_deepslate
fill 471 103 306 471 106 306 minecraft:deepslate_tiles
setblock 471 103 310 minecraft:cobbled_deepslate
fill 471 103 311 471 106 311 minecraft:deepslate_tiles
fill 471 103 313 471 103 314 minecraft:deepslate_tiles
setblock 471 103 315 minecraft:cobbled_deepslate
setblock 472 103 304 minecraft:cobbled_deepslate
fill 472 103 305 472 106 305 minecraft:deepslate_tiles
setblock 472 103 308 minecraft:deepslate_tiles
setblock 472 103 309 minecraft:cobbled_deepslate
fill 472 103 310 472 106 310 minecraft:deepslate_tiles
fill 472 103 316 473 104 316 minecraft:deepslate_tiles
setblock 473 103 278 minecraft:light[level=12]
setblock 473 103 285 minecraft:light[level=12]
setblock 473 103 292 minecraft:light[level=12]
setblock 473 103 299 minecraft:light[level=12]
setblock 473 103 306 minecraft:light[level=12]
setblock 473 103 313 minecraft:light[level=12]
setblock 475 103 276 minecraft:cobbled_deepslate
setblock 475 103 316 minecraft:cobbled_deepslate
fill 476 103 276 476 106 276 minecraft:deepslate_tiles
setblock 476 103 315 minecraft:cobbled_deepslate
fill 476 103 316 476 106 316 minecraft:deepslate_tiles
fill 477 103 315 477 106 315 minecraft:deepslate_tiles
fill 479 103 314 480 104 314 minecraft:deepslate_tiles
setblock 480 103 276 minecraft:cobbled_deepslate
setblock 480 103 278 minecraft:light[level=12]
setblock 480 103 285 minecraft:light[level=12]
setblock 480 103 292 minecraft:light[level=12]
setblock 480 103 299 minecraft:light[level=12]
setblock 480 103 306 minecraft:light[level=12]
setblock 480 103 313 minecraft:light[level=12]
setblock 480 103 316 minecraft:cobbled_deepslate
fill 481 103 276 481 105 276 minecraft:deepslate_tiles
setblock 481 103 315 minecraft:cobbled_deepslate
fill 481 103 316 481 106 316 minecraft:deepslate_tiles
fill 482 103 315 482 106 315 minecraft:deepslate_tiles
setblock 485 103 316 minecraft:cobbled_deepslate
setblock 487 103 278 minecraft:light[level=12]
setblock 487 103 285 minecraft:light[level=12]
setblock 487 103 292 minecraft:light[level=12]
setblock 487 103 299 minecraft:light[level=12]
setblock 487 103 306 minecraft:light[level=12]
setblock 487 103 313 minecraft:light[level=12]
setblock 494 103 278 minecraft:light[level=12]
setblock 494 103 285 minecraft:light[level=12]
setblock 494 103 292 minecraft:light[level=12]
setblock 494 103 299 minecraft:light[level=12]
setblock 494 103 306 minecraft:light[level=12]
setblock 494 103 313 minecraft:light[level=12]
setblock 498 103 277 minecraft:deepslate_tiles
setblock 499 103 277 minecraft:cobbled_deepslate
setblock 500 103 276 minecraft:cobbled_deepslate
fill 500 103 277 500 106 277 minecraft:deepslate_tiles
setblock 500 103 316 minecraft:cobbled_deepslate
fill 501 103 276 501 106 276 minecraft:deepslate_tiles
setblock 501 103 285 minecraft:light[level=12]
setblock 501 103 292 minecraft:light[level=12]
setblock 501 103 299 minecraft:light[level=12]
setblock 501 103 306 minecraft:light[level=12]
setblock 501 103 313 minecraft:light[level=12]
fill 501 103 316 501 106 316 minecraft:deepslate_tiles
setblock 503 103 278 minecraft:cobbled_deepslate
setblock 504 103 277 minecraft:cobbled_deepslate
fill 504 103 278 504 104 278 minecraft:deepslate_tiles
setblock 504 103 316 minecraft:deepslate_tiles
setblock 505 103 276 minecraft:cobbled_deepslate
fill 505 103 277 505 105 277 minecraft:deepslate_tiles
fill 506 103 276 506 106 276 minecraft:deepslate_tiles
setblock 508 103 278 minecraft:light[level=12]
setblock 508 103 285 minecraft:light[level=12]
setblock 508 103 292 minecraft:light[level=12]
setblock 508 103 299 minecraft:light[level=12]
setblock 508 103 306 minecraft:light[level=12]
setblock 508 103 313 minecraft:light[level=12]
setblock 509 103 282 minecraft:cobbled_deepslate
fill 509 103 283 509 104 283 minecraft:deepslate_tiles
setblock 509 103 285 minecraft:deepslate_tiles
setblock 510 103 276 minecraft:cobbled_deepslate
setblock 510 103 281 minecraft:cobbled_deepslate
fill 510 103 282 510 106 282 minecraft:deepslate_tiles
setblock 510 103 286 minecraft:cobbled_deepslate
fill 510 103 287 510 106 287 minecraft:deepslate_tiles
fill 511 103 276 511 106 276 minecraft:deepslate_tiles
setblock 511 103 280 minecraft:cobbled_deepslate
fill 511 103 281 511 106 281 minecraft:deepslate_tiles
setblock 511 103 285 minecraft:cobbled_deepslate
fill 511 103 286 511 106 286 minecraft:deepslate_tiles
setblock 511 103 289 minecraft:deepslate_tiles
setblock 511 103 305 minecraft:cobbled_deepslate
fill 511 103 306 511 104 308 minecraft:deepslate_tiles
setblock 471 104 279 minecraft:cobbled_deepslate
fill 471 104 280 471 105 280 minecraft:deepslate_tiles
setblock 471 104 284 minecraft:cobbled_deepslate
fill 471 104 285 471 107 285 minecraft:deepslate_tiles
fill 471 104 287 471 105 287 minecraft:deepslate_tiles
setblock 471 104 304 minecraft:cobbled_deepslate
fill 471 104 305 471 107 305 minecraft:deepslate_tiles
setblock 471 104 308 minecraft:deepslate_tiles
setblock 471 104 309 minecraft:cobbled_deepslate
fill 471 104 310 471 107 310 minecraft:deepslate_tiles
setblock 471 104 313 minecraft:deepslate_tiles
setblock 471 104 314 minecraft:cobbled_deepslate
fill 471 104 315 471 106 316 minecraft:deepslate_tiles
fill 472 104 304 472 107 304 minecraft:deepslate_tiles
setblock 472 104 308 minecraft:cobbled_deepslate
fill 472 104 309 473 106 309 minecraft:deepslate_tiles
fill 472 104 311 472 104 312 minecraft:deepslate_tiles
setblock 473 104 306 minecraft:deepslate_tiles
setblock 473 104 307 minecraft:cobbled_deepslate
fill 473 104 308 473 107 308 minecraft:deepslate_tiles
setblock 474 104 276 minecraft:cobbled_deepslate
setblock 474 104 316 minecraft:cobbled_deepslate
fill 475 104 276 475 106 276 minecraft:deepslate_tiles
setblock 475 104 315 minecraft:cobbled_deepslate
fill 475 104 316 475 107 316 minecraft:deepslate_tiles
fill 476 104 315 476 107 315 minecraft:deepslate_tiles
fill 477 104 314 478 106 314 minecraft:deepslate_tiles
setblock 479 104 276 minecraft:cobbled_deepslate
setblock 479 104 316 minecraft:cobbled_deepslate
fill 480 104 276 480 106 276 minecraft:deepslate_tiles
setblock 480 104 315 minecraft:cobbled_deepslate
fill 480 104 316 480 107 316 minecraft:deepslate_tiles
setblock 481 104 314 minecraft:cobbled_deepslate
fill 481 104 315 481 107 315 minecraft:deepslate_tiles
setblock 484 104 316 minecraft:cobbled_deepslate
fill 496 104 276 496 106 276 minecraft:deepslate_tiles
setblock 498 104 277 minecraft:cobbled_deepslate
setblock 499 104 276 minecraft:cobbled_deepslate
fill 499 104 277 499 104 278 minecraft:deepslate_tiles
setblock 499 104 316 minecraft:cobbled_deepslate
fill 500 104 276 500 107 276 minecraft:deepslate_tiles
fill 500 104 316 500 107 316 minecraft:deepslate_tiles
setblock 502 104 278 minecraft:cobbled_deepslate
setblock 502 104 317 minecraft:white_wool
setblock 503 104 277 minecraft:cobbled_deepslate
setblock 503 104 278 minecraft:deepslate_tiles
setblock 504 104 276 minecraft:cobbled_deepslate
fill 504 104 277 504 106 277 minecraft:deepslate_tiles
setblock 504 104 316 minecraft:cobbled_deepslate
fill 505 104 276 505 107 276 minecraft:deepslate_tiles
setblock 509 104 276 minecraft:cobbled_deepslate
fill 510 104 276 510 105 276 minecraft:deepslate_tiles
setblock 510 104 280 minecraft:cobbled_deepslate
fill 510 104 281 510 105 281 minecraft:deepslate_tiles
setblock 510 104 285 minecraft:cobbled_deepslate
fill 510 104 286 510 107 286 minecraft:deepslate_tiles
setblock 511 104 279 minecraft:cobbled_deepslate
fill 511 104 280 511 107 280 minecraft:deepslate_tiles
setblock 511 104 284 minecraft:cobbled_deepslate
fill 511 104 285 511 107 285 minecraft:deepslate_tiles
setblock 511 104 289 minecraft:cobbled_deepslate
fill 511 104 305 511 106 305 minecraft:deepslate_tiles
setblock 511 104 309 minecraft:cobbled_deepslate
fill 511 104 310 511 106 311 minecraft:deepslate_tiles
setblock 470 105 284 minecraft:white_wool
setblock 471 105 283 minecraft:cobbled_deepslate
fill 471 105 284 471 107 284 minecraft:deepslate_tiles
setblock 471 105 303 minecraft:cobbled_deepslate
fill 471 105 304 471 108 304 minecraft:deepslate_tiles
setblock 471 105 307 minecraft:deepslate_tiles
setblock 471 105 308 minecraft:cobbled_deepslate
fill 471 105 309 471 108 309 minecraft:deepslate_tiles
setblock 471 105 313 minecraft:cobbled_deepslate
fill 471 105 314 471 108 314 minecraft:deepslate_tiles
setblock 472 105 307 minecraft:cobbled_deepslate
fill 472 105 308 472 108 308 minecraft:deepslate_tiles
setblock 472 105 311 minecraft:deepslate_tiles
setblock 472 105 312 minecraft:cobbled_deepslate
fill 472 105 313 472 108 313 minecraft:deepslate_tiles
setblock 472 105 316 minecraft:deepslate_tiles
setblock 473 105 305 minecraft:deepslate_tiles
setblock 473 105 306 minecraft:cobbled_deepslate
fill 473 105 307 473 108 307 minecraft:deepslate_tiles
setblock 473 105 310 minecraft:deepslate_tiles
setblock 473 105 311 minecraft:cobbled_deepslate
setblock 473 105 316 minecraft:cobbled_deepslate
setblock 474 105 315 minecraft:cobbled_deepslate
fill 474 105 316 474 108 316 minecraft:deepslate_tiles
fill 475 105 315 475 108 315 minecraft:deepslate_tiles
fill 476 105 314 476 108 314 minecraft:deepslate_tiles
setblock 478 105 276 minecraft:cobbled_deepslate
setblock 478 105 316 minecraft:cobbled_deepslate
fill 479 105 276 479 107 276 minecraft:deepslate_tiles
setblock 479 105 314 minecraft:deepslate_tiles
setblock 479 105 315 minecraft:cobbled_deepslate
fill 479 105 316 479 108 316 minecraft:deepslate_tiles
setblock 480 105 314 minecraft:cobbled_deepslate
fill 480 105 315 480 108 315 minecraft:deepslate_tiles
fill 481 105 314 481 106 314 minecraft:deepslate_tiles
setblock 483 105 316 minecraft:cobbled_deepslate
setblock 484 105 316 minecraft:deepslate_tiles
setblock 498 105 276 minecraft:cobbled_deepslate
fill 498 105 277 499 107 277 minecraft:deepslate_tiles
setblock 498 105 316 minecraft:cobbled_deepslate
fill 499 105 276 499 108 276 minecraft:deepslate_tiles
fill 499 105 316 499 108 316 minecraft:deepslate_tiles
setblock 501 105 278 minecraft:cobbled_deepslate
setblock 502 105 277 minecraft:cobbled_deepslate
setblock 502 105 278 minecraft:deepslate_tiles
setblock 502 105 316 minecraft:deepslate_tiles
fill 502 105 317 502 194 317 minecraft:black_concrete
setblock 503 105 276 minecraft:cobbled_deepslate
fill 503 105 277 503 106 277 minecraft:deepslate_tiles
setblock 503 105 316 minecraft:cobbled_deepslate
fill 504 105 276 504 108 276 minecraft:deepslate_tiles
fill 504 105 278 504 115 278 minecraft:white_wool
fill 504 105 316 504 106 316 minecraft:deepslate_tiles
setblock 508 105 276 minecraft:cobbled_deepslate
setblock 509 105 276 minecraft:deepslate_tiles
setblock 510 105 280 minecraft:deepslate_tiles
setblock 510 105 284 minecraft:cobbled_deepslate
fill 510 105 285 510 107 285 minecraft:deepslate_tiles
setblock 511 105 278 minecraft:cobbled_deepslate
fill 511 105 279 511 107 279 minecraft:deepslate_tiles
setblock 511 105 283 minecraft:cobbled_deepslate
fill 511 105 284 511 108 284 minecraft:deepslate_tiles
setblock 511 105 287 minecraft:deepslate_tiles
setblock 511 105 288 minecraft:cobbled_deepslate
fill 511 105 289 511 108 289 minecraft:deepslate_tiles
fill 511 105 306 511 105 307 minecraft:deepslate_tiles
setblock 511 105 308 minecraft:cobbled_deepslate
fill 511 105 309 511 108 309 minecraft:deepslate_tiles
setblock 511 105 312 minecraft:deepslate_tiles
setblock 511 105 313 minecraft:cobbled_deepslate
fill 470 106 284 470 199 284 minecraft:black_concrete
setblock 471 106 282 minecraft:cobbled_deepslate
setblock 471 106 283 minecraft:deepslate_tiles
setblock 471 106 287 minecraft:cobbled_deepslate
fill 471 106 288 471 107 288 minecraft:deepslate_tiles
fill 471 106 303 471 107 303 minecraft:deepslate_tiles
setblock 471 106 307 minecraft:cobbled_deepslate
fill 471 106 308 471 109 308 minecraft:deepslate_tiles
setblock 471 106 312 minecraft:cobbled_deepslate
fill 471 106 313 471 109 313 minecraft:deepslate_tiles
fill 472 106 284 472 112 284 minecraft:cobbled_deepslate
setblock 472 106 306 minecraft:cobbled_deepslate
fill 472 106 307 472 109 307 minecraft:deepslate_tiles
setblock 472 106 311 minecraft:cobbled_deepslate
fill 472 106 312 473 108 312 minecraft:deepslate_tiles
fill 472 106 314 472 107 314 minecraft:deepslate_tiles
setblock 472 106 316 minecraft:cobbled_deepslate
setblock 473 106 305 minecraft:cobbled_deepslate
fill 473 106 306 473 108 306 minecraft:deepslate_tiles
setblock 473 106 310 minecraft:cobbled_deepslate
fill 473 106 311 473 109 311 minecraft:deepslate_tiles
setblock 473 106 315 minecraft:cobbled_deepslate
fill 473 106 316 473 109 316 minecraft:deepslate_tiles
setblock 474 106 308 minecraft:deepslate_tiles
setblock 474 106 309 minecraft:cobbled_deepslate
fill 474 106 315 474 109 315 minecraft:deepslate_tiles
fill 475 106 314 475 109 314 minecraft:deepslate_tiles
setblock 477 106 276 minecraft:cobbled_deepslate
setblock 477 106 316 minecraft:cobbled_deepslate
fill 478 106 276 478 107 276 minecraft:deepslate_tiles
setblock 478 106 315 minecraft:cobbled_deepslate
fill 478 106 316 478 109 316 minecraft:deepslate_tiles
setblock 479 106 314 minecraft:cobbled_deepslate
fill 479 106 315 479 109 315 minecraft:deepslate_tiles
fill 480 106 314 480 108 314 minecraft:deepslate_tiles
setblock 482 106 316 minecraft:cobbled_deepslate
setblock 482 106 317 minecraft:redstone_block
fill 483 106 316 483 107 316 minecraft:deepslate_tiles
setblock 490 106 275 minecraft:redstone_block
setblock 497 106 276 minecraft:cobbled_deepslate
setblock 497 106 316 minecraft:cobbled_deepslate
fill 498 106 276 498 109 276 minecraft:deepslate_tiles
fill 498 106 316 498 109 316 minecraft:deepslate_tiles
setblock 501 106 277 minecraft:cobbled_deepslate
setblock 502 106 276 minecraft:cobbled_deepslate
fill 502 106 277 502 107 277 minecraft:deepslate_tiles
setblock 502 106 316 minecraft:cobbled_deepslate
fill 503 106 276 503 109 276 minecraft:deepslate_tiles
fill 503 106 316 503 108 316 minecraft:deepslate_tiles
setblock 507 106 276 minecraft:cobbled_deepslate
setblock 508 106 276 minecraft:deepslate_tiles
setblock 510 106 283 minecraft:cobbled_deepslate
fill 510 106 284 510 107 284 minecraft:deepslate_tiles
setblock 511 106 277 minecraft:cobbled_deepslate
setblock 511 106 278 minecraft:deepslate_tiles
setblock 511 106 282 minecraft:cobbled_deepslate
fill 511 106 283 511 109 283 minecraft:deepslate_tiles
setblock 511 106 287 minecraft:cobbled_deepslate
fill 511 106 288 511 109 288 minecraft:deepslate_tiles
fill 511 106 290 511 107 290 minecraft:deepslate_tiles
setblock 511 106 306 minecraft:deepslate_tiles
setblock 511 106 307 minecraft:cobbled_deepslate
fill 511 106 308 511 109 308 minecraft:deepslate_tiles
setblock 511 106 312 minecraft:cobbled_deepslate
fill 511 106 313 511 108 314 minecraft:deepslate_tiles
setblock 512 106 277 minecraft:white_wool
fill 512 106 278 512 201 278 minecraft:black_concrete
setblock 471 107 286 minecraft:cobbled_deepslate
fill 471 107 287 471 108 287 minecraft:deepslate_tiles
setblock 471 107 306 minecraft:cobbled_deepslate
fill 471 107 307 471 110 307 minecraft:deepslate_tiles
setblock 471 107 311 minecraft:cobbled_deepslate
fill 471 107 312 471 110 312 minecraft:deepslate_tiles
setblock 471 107 315 minecraft:deepslate_tiles
setblock 471 107 316 minecraft:cobbled_deepslate
setblock 472 107 305 minecraft:cobbled_deepslate
fill 472 107 306 472 110 306 minecraft:deepslate_tiles
setblock 472 107 309 minecraft:deepslate_tiles
setblock 472 107 310 minecraft:cobbled_deepslate
fill 472 107 311 472 110 311 minecraft:deepslate_tiles
setblock 472 107 315 minecraft:cobbled_deepslate
fill 472 107 316 472 110 316 minecraft:deepslate_tiles
setblock 473 107 309 minecraft:cobbled_deepslate
fill 473 107 310 474 109 310 minecraft:deepslate_tiles
setblock 473 107 313 minecraft:deepslate_tiles
fill 473 107 315 473 110 315 minecraft:deepslate_tiles
setblock 474 107 308 minecraft:cobbled_deepslate
fill 474 107 309 474 109 309 minecraft:deepslate_tiles
setblock 476 107 276 minecraft:cobbled_deepslate
setblock 476 107 316 minecraft:cobbled_deepslate
setblock 477 107 276 minecraft:deepslate_tiles
setblock 477 107 314 minecraft:deepslate_tiles
setblock 477 107 315 minecraft:cobbled_deepslate
fill 477 107 316 477 110 316 minecraft:deepslate_tiles
setblock 478 107 314 minecraft:cobbled_deepslate
fill 478 107 315 478 110 315 minecraft:deepslate_tiles
fill 479 107 314 479 109 314 minecraft:deepslate_tiles
setblock 481 107 316 minecraft:cobbled_deepslate
setblock 482 107 315 minecraft:cobbled_deepslate
fill 482 107 316 482 109 316 minecraft:deepslate_tiles
fill 482 107 317 482 199 317 minecraft:black_concrete
fill 490 107 275 490 123 275 minecraft:black_concrete
setblock 496 107 276 minecraft:cobbled_deepslate
fill 497 107 276 497 110 276 minecraft:deepslate_tiles
fill 497 107 316 497 110 316 minecraft:deepslate_tiles
setblock 500 107 277 minecraft:cobbled_deepslate
setblock 501 107 276 minecraft:cobbled_deepslate
setblock 501 107 277 minecraft:deepslate_tiles
setblock 501 107 316 minecraft:cobbled_deepslate
fill 502 107 276 502 110 276 minecraft:deepslate_tiles
fill 502 107 316 502 110 316 minecraft:deepslate_tiles
fill 505 107 290 505 108 290 minecraft:white_wool
setblock 506 107 276 minecraft:cobbled_deepslate
setblock 506 107 317 minecraft:white_wool
setblock 511 107 281 minecraft:cobbled_deepslate
fill 511 107 282 511 108 282 minecraft:deepslate_tiles
setblock 511 107 286 minecraft:cobbled_deepslate
fill 511 107 287 511 110 287 minecraft:deepslate_tiles
setblock 511 107 306 minecraft:cobbled_deepslate
fill 511 107 307 511 110 307 minecraft:deepslate_tiles
setblock 511 107 310 minecraft:deepslate_tiles
setblock 511 107 311 minecraft:cobbled_deepslate
fill 511 107 312 511 110 312 minecraft:deepslate_tiles
setblock 511 107 315 minecraft:deepslate_tiles
setblock 511 107 316 minecraft:cobbled_deepslate
fill 512 107 277 512 199 277 minecraft:black_concrete
setblock 471 108 305 minecraft:cobbled_deepslate
fill 471 108 306 471 111 306 minecraft:deepslate_tiles
setblock 471 108 310 minecraft:cobbled_deepslate
fill 471 108 311 471 111 311 minecraft:deepslate_tiles
setblock 471 108 315 minecraft:cobbled_deepslate
fill 471 108 316 471 111 316 minecraft:deepslate_tiles
fill 472 108 305 472 109 305 minecraft:deepslate_tiles
setblock 472 108 309 minecraft:cobbled_deepslate
fill 472 108 310 472 111 310 minecraft:deepslate_tiles
setblock 472 108 314 minecraft:cobbled_deepslate
fill 472 108 315 472 111 315 minecraft:deepslate_tiles
setblock 473 108 308 minecraft:cobbled_deepslate
fill 473 108 309 473 111 309 minecraft:deepslate_tiles
setblock 473 108 313 minecraft:cobbled_deepslate
setblock 474 108 308 minecraft:deepslate_tiles
setblock 474 108 311 minecraft:deepslate_tiles
fill 474 108 314 474 110 314 minecraft:deepslate_tiles
setblock 475 108 316 minecraft:cobbled_deepslate
setblock 476 108 315 minecraft:cobbled_deepslate
fill 476 108 316 476 111 316 minecraft:deepslate_tiles
setblock 477 108 314 minecraft:cobbled_deepslate
fill 477 108 315 477 111 315 minecraft:deepslate_tiles
fill 478 108 314 478 111 314 minecraft:deepslate_tiles
setblock 480 108 316 minecraft:cobbled_deepslate
setblock 481 108 315 minecraft:cobbled_deepslate
fill 481 108 316 481 111 316 minecraft:deepslate_tiles
fill 496 108 276 496 111 276 minecraft:deepslate_tiles
setblock 499 108 277 minecraft:cobbled_deepslate
setblock 500 108 276 minecraft:cobbled_deepslate
setblock 500 108 277 minecraft:deepslate_tiles
setblock 500 108 316 minecraft:cobbled_deepslate
fill 501 108 276 501 111 276 minecraft:deepslate_tiles
fill 501 108 316 501 111 316 minecraft:deepslate_tiles
fill 506 108 317 506 114 317 minecraft:black_concrete
setblock 511 108 281 minecraft:deepslate_tiles
setblock 511 108 285 minecraft:cobbled_deepslate
fill 511 108 286 511 110 286 minecraft:deepslate_tiles
setblock 511 108 290 minecraft:cobbled_deepslate
setblock 511 108 310 minecraft:cobbled_deepslate
fill 511 108 311 511 111 311 minecraft:deepslate_tiles
setblock 511 108 315 minecraft:cobbled_deepslate
fill 511 108 316 511 111 316 minecraft:deepslate_tiles
fill 471 109 284 471 112 284 minecraft:cobbled_deepslate
setblock 471 109 304 minecraft:cobbled_deepslate
fill 471 109 305 471 112 305 minecraft:deepslate_tiles
setblock 471 109 309 minecraft:cobbled_deepslate
fill 471 109 310 471 112 310 minecraft:deepslate_tiles
setblock 471 109 314 minecraft:cobbled_deepslate
fill 471 109 315 471 112 315 minecraft:deepslate_tiles
fill 472 109 283 472 112 283 minecraft:cobbled_deepslate
fill 472 109 285 472 112 285 minecraft:cobbled_deepslate
setblock 472 109 308 minecraft:cobbled_deepslate
fill 472 109 309 472 112 309 minecraft:deepslate_tiles
setblock 472 109 312 minecraft:deepslate_tiles
setblock 472 109 313 minecraft:cobbled_deepslate
fill 472 109 314 472 112 314 minecraft:deepslate_tiles
setblock 473 109 278 minecraft:light[level=13]
fill 473 109 284 473 112 284 minecraft:cobbled_deepslate
setblock 473 109 285 minecraft:light[level=12]
setblock 473 109 286 minecraft:light[level=13]
setblock 473 109 292 minecraft:light[level=12]
setblock 473 109 294 minecraft:light[level=13]
setblock 473 109 299 minecraft:light[level=12]
setblock 473 109 302 minecraft:light[level=13]
setblock 473 109 306 minecraft:light[level=12]
setblock 473 109 307 minecraft:cobbled_deepslate
fill 473 109 308 473 112 308 minecraft:deepslate_tiles
setblock 473 109 312 minecraft:cobbled_deepslate
fill 473 109 313 473 112 313 minecraft:deepslate_tiles
setblock 474 109 311 minecraft:cobbled_deepslate
setblock 474 109 316 minecraft:cobbled_deepslate
setblock 475 109 315 minecraft:cobbled_deepslate
fill 475 109 316 475 112 316 minecraft:deepslate_tiles
setblock 476 109 314 minecraft:cobbled_deepslate
fill 476 109 315 476 112 315 minecraft:deepslate_tiles
fill 477 109 314 477 112 314 minecraft:deepslate_tiles
fill 479 109 299 480 110 299 minecraft:white_wool
setblock 479 109 316 minecraft:cobbled_deepslate
setblock 480 109 278 minecraft:light[level=12]
setblock 480 109 285 minecraft:light[level=12]
setblock 480 109 292 minecraft:light[level=12]
setblock 480 109 306 minecraft:light[level=12]
setblock 480 109 313 minecraft:light[level=12]
setblock 480 109 315 minecraft:cobbled_deepslate
fill 480 109 316 480 112 316 minecraft:deepslate_tiles
setblock 481 109 278 minecraft:light[level=13]
setblock 481 109 286 minecraft:light[level=13]
setblock 481 109 294 minecraft:light[level=13]
setblock 481 109 302 minecraft:light[level=13]
setblock 481 109 310 minecraft:light[level=13]
setblock 487 109 278 minecraft:light[level=12]
setblock 487 109 285 minecraft:light[level=12]
setblock 487 109 292 minecraft:light[level=12]
setblock 487 109 299 minecraft:light[level=12]
setblock 487 109 306 minecraft:light[level=12]
setblock 487 109 313 minecraft:light[level=12]
setblock 489 109 278 minecraft:light[level=13]
setblock 489 109 286 minecraft:light[level=13]
setblock 489 109 294 minecraft:light[level=13]
setblock 489 109 302 minecraft:light[level=13]
setblock 489 109 310 minecraft:light[level=13]
setblock 494 109 278 minecraft:light[level=12]
setblock 494 109 285 minecraft:light[level=12]
setblock 494 109 292 minecraft:light[level=12]
setblock 494 109 299 minecraft:light[level=12]
setblock 494 109 306 minecraft:light[level=12]
setblock 494 109 313 minecraft:light[level=12]
fill 496 109 316 496 111 316 minecraft:deepslate_tiles
setblock 497 109 278 minecraft:light[level=13]
setblock 497 109 286 minecraft:light[level=13]
setblock 497 109 294 minecraft:light[level=13]
setblock 497 109 302 minecraft:light[level=13]
setblock 497 109 310 minecraft:light[level=13]
setblock 499 109 276 minecraft:cobbled_deepslate
setblock 499 109 316 minecraft:cobbled_deepslate
fill 500 109 276 500 112 276 minecraft:deepslate_tiles
fill 500 109 316 500 112 316 minecraft:deepslate_tiles
setblock 501 109 278 minecraft:light[level=12]
setblock 501 109 285 minecraft:light[level=12]
setblock 501 109 292 minecraft:light[level=12]
schedule function dropper:buildpart/70_5 1t
