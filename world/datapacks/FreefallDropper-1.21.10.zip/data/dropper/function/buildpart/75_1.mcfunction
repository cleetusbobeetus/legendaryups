setblock 168 -19 357 minecraft:light[level=13]
setblock 168 -19 363 minecraft:dark_prismarine
fill 169 -19 323 169 -16 323 minecraft:blue_terracotta
setblock 169 -19 361 minecraft:blue_terracotta
setblock 169 -19 362 minecraft:dark_prismarine
fill 169 -19 363 169 -16 363 minecraft:blue_terracotta
setblock 170 -19 325 minecraft:blue_terracotta
setblock 170 -19 361 minecraft:dark_prismarine
fill 170 -19 362 170 -16 362 minecraft:blue_terracotta
setblock 171 -19 325 minecraft:dark_prismarine
setblock 171 -19 361 minecraft:blue_terracotta
setblock 172 -19 324 minecraft:dark_prismarine
fill 172 -19 325 172 -16 325 minecraft:blue_terracotta
fill 172 -19 336 172 14 336 minecraft:magenta_terracotta
setblock 172 -19 339 minecraft:light[level=12]
setblock 172 -19 346 minecraft:light[level=12]
setblock 172 -19 353 minecraft:light[level=12]
setblock 172 -19 360 minecraft:light[level=12]
setblock 173 -19 323 minecraft:dark_prismarine
fill 173 -19 324 173 -16 324 minecraft:blue_terracotta
setblock 173 -19 363 minecraft:dark_prismarine
fill 174 -19 323 177 -19 323 minecraft:blue_terracotta
setblock 174 -19 362 minecraft:dark_prismarine
fill 174 -19 363 174 -16 363 minecraft:blue_terracotta
fill 175 -19 362 175 -17 362 minecraft:blue_terracotta
setblock 176 -19 324 minecraft:blue_terracotta
setblock 176 -19 325 minecraft:light[level=13]
setblock 176 -19 333 minecraft:light[level=13]
setblock 176 -19 341 minecraft:light[level=13]
setblock 176 -19 357 minecraft:light[level=13]
setblock 177 -19 324 minecraft:dark_prismarine
setblock 178 -19 323 minecraft:dark_prismarine
fill 178 -19 324 178 -16 324 minecraft:blue_terracotta
setblock 178 -19 363 minecraft:dark_prismarine
fill 179 -19 323 179 -16 323 minecraft:blue_terracotta
setblock 179 -19 325 minecraft:light[level=12]
setblock 179 -19 332 minecraft:light[level=12]
setblock 179 -19 339 minecraft:light[level=12]
setblock 179 -19 346 minecraft:light[level=12]
setblock 179 -19 353 minecraft:light[level=12]
setblock 179 -19 360 minecraft:light[level=12]
setblock 179 -19 362 minecraft:dark_prismarine
fill 179 -19 363 179 -16 363 minecraft:blue_terracotta
fill 180 -19 362 180 -16 362 minecraft:blue_terracotta
setblock 181 -19 325 minecraft:dark_prismarine
setblock 181 -19 360 minecraft:dark_prismarine
fill 181 -19 361 181 -16 361 minecraft:blue_terracotta
fill 181 -19 364 181 132 364 minecraft:black_concrete
setblock 182 -19 324 minecraft:dark_prismarine
fill 182 -19 325 182 -16 325 minecraft:blue_terracotta
setblock 182 -19 328 minecraft:purple_concrete
setblock 182 -19 339 minecraft:dark_prismarine
fill 182 -19 340 182 -16 340 minecraft:blue_terracotta
setblock 182 -19 343 minecraft:blue_terracotta
setblock 182 -19 344 minecraft:dark_prismarine
fill 182 -19 345 182 -16 345 minecraft:blue_terracotta
setblock 182 -19 347 minecraft:purple_concrete
fill 182 -19 355 182 -17 355 minecraft:blue_terracotta
setblock 182 -19 359 minecraft:dark_prismarine
fill 182 -19 360 182 -16 360 minecraft:blue_terracotta
fill 183 -19 341 183 -18 346 minecraft:black_concrete
setblock 183 -19 347 minecraft:cyan_concrete
fill 183 -19 348 183 -19 353 minecraft:black_concrete
setblock 142 -18 323 minecraft:dark_prismarine
fill 142 -18 324 145 -18 324 minecraft:blue_terracotta
setblock 142 -18 338 minecraft:dark_prismarine
fill 142 -18 339 142 -15 339 minecraft:blue_terracotta
setblock 142 -18 342 minecraft:blue_terracotta
setblock 142 -18 343 minecraft:dark_prismarine
fill 142 -18 344 142 -15 344 minecraft:blue_terracotta
setblock 142 -18 348 minecraft:dark_prismarine
fill 142 -18 349 142 -15 349 minecraft:blue_terracotta
setblock 142 -18 353 minecraft:dark_prismarine
fill 142 -18 354 142 -15 354 minecraft:blue_terracotta
setblock 142 -18 358 minecraft:dark_prismarine
fill 142 -18 359 142 -18 362 minecraft:blue_terracotta
setblock 142 -18 363 minecraft:dark_prismarine
fill 143 -18 323 146 -18 323 minecraft:blue_terracotta
setblock 143 -18 342 minecraft:dark_prismarine
fill 143 -18 343 143 -15 343 minecraft:blue_terracotta
setblock 143 -18 347 minecraft:dark_prismarine
fill 143 -18 348 144 -16 348 minecraft:blue_terracotta
setblock 143 -18 351 minecraft:blue_terracotta
setblock 143 -18 352 minecraft:dark_prismarine
fill 143 -18 353 143 -15 353 minecraft:blue_terracotta
setblock 143 -18 357 minecraft:dark_prismarine
fill 143 -18 358 143 -15 358 minecraft:blue_terracotta
fill 143 -18 360 143 -18 361 minecraft:blue_terracotta
setblock 143 -18 362 minecraft:dark_prismarine
fill 143 -18 363 143 -15 363 minecraft:blue_terracotta
fill 144 -18 336 145 18 336 minecraft:magenta_terracotta
setblock 144 -18 340 minecraft:blue_terracotta
setblock 144 -18 341 minecraft:dark_prismarine
fill 144 -18 342 144 -15 342 minecraft:blue_terracotta
setblock 144 -18 345 minecraft:blue_terracotta
setblock 144 -18 346 minecraft:dark_prismarine
fill 144 -18 347 144 -15 347 minecraft:blue_terracotta
setblock 144 -18 357 minecraft:blue_terracotta
setblock 144 -18 360 minecraft:blue_terracotta
setblock 144 -18 361 minecraft:dark_prismarine
fill 144 -18 362 144 -15 362 minecraft:blue_terracotta
fill 145 -18 343 145 -18 344 minecraft:blue_terracotta
fill 145 -18 361 145 -16 361 minecraft:blue_terracotta
setblock 146 -18 324 minecraft:dark_prismarine
fill 146 -18 336 146 -17 336 minecraft:pink_terracotta
setblock 146 -18 360 minecraft:blue_terracotta
setblock 147 -18 323 minecraft:dark_prismarine
fill 147 -18 324 147 -15 324 minecraft:blue_terracotta
fill 147 -18 336 148 -18 336 minecraft:magenta_terracotta
setblock 147 -18 363 minecraft:dark_prismarine
fill 148 -18 323 148 -15 323 minecraft:blue_terracotta
setblock 148 -18 362 minecraft:dark_prismarine
fill 148 -18 363 148 -15 363 minecraft:blue_terracotta
setblock 149 -18 361 minecraft:dark_prismarine
fill 149 -18 362 149 -16 362 minecraft:blue_terracotta
fill 150 -18 352 150 -18 354 minecraft:magenta_terracotta
setblock 150 -18 361 minecraft:blue_terracotta
fill 151 -18 352 151 -17 352 minecraft:pink_terracotta
fill 151 -18 353 152 -15 354 minecraft:magenta_terracotta
setblock 152 -18 323 minecraft:dark_prismarine
fill 152 -18 352 152 4 352 minecraft:magenta_terracotta
setblock 152 -18 363 minecraft:dark_prismarine
fill 153 -18 323 153 -17 323 minecraft:blue_terracotta
setblock 153 -18 362 minecraft:dark_prismarine
fill 153 -18 363 153 -17 363 minecraft:blue_terracotta
fill 155 -18 327 156 -17 327 minecraft:magenta_terracotta
setblock 156 -18 323 minecraft:purple_concrete
fill 156 -18 326 159 -18 326 minecraft:magenta_terracotta
fill 157 -18 327 158 -17 327 minecraft:pink_terracotta
fill 158 -18 329 158 33 329 minecraft:magenta_terracotta
fill 159 -18 323 161 -18 323 minecraft:blue_terracotta
fill 159 -18 327 159 7 327 minecraft:magenta_terracotta
fill 160 -18 363 161 -18 363 minecraft:blue_terracotta
setblock 162 -18 323 minecraft:dark_prismarine
fill 162 -18 324 162 -15 324 minecraft:blue_terracotta
setblock 162 -18 363 minecraft:dark_prismarine
fill 163 -18 323 163 -15 323 minecraft:blue_terracotta
fill 163 -18 363 166 -18 363 minecraft:blue_terracotta
fill 164 -18 362 167 -18 362 minecraft:blue_terracotta
setblock 165 -18 325 minecraft:dark_prismarine
fill 165 -18 359 165 -15 361 minecraft:magenta_terracotta
setblock 166 -18 324 minecraft:dark_prismarine
fill 166 -18 325 166 -15 325 minecraft:blue_terracotta
fill 166 -18 359 167 -17 359 minecraft:pink_terracotta
fill 166 -18 360 168 -18 361 minecraft:magenta_terracotta
setblock 167 -18 323 minecraft:dark_prismarine
fill 167 -18 324 167 -15 324 minecraft:blue_terracotta
setblock 167 -18 363 minecraft:dark_prismarine
fill 168 -18 323 168 -15 323 minecraft:blue_terracotta
fill 168 -18 359 169 -15 359 minecraft:magenta_terracotta
setblock 168 -18 362 minecraft:dark_prismarine
fill 168 -18 363 168 -15 363 minecraft:blue_terracotta
setblock 169 -18 361 minecraft:dark_prismarine
fill 169 -18 362 169 -15 362 minecraft:blue_terracotta
setblock 170 -18 325 minecraft:dark_prismarine
setblock 171 -18 324 minecraft:dark_prismarine
fill 171 -18 325 171 -15 325 minecraft:blue_terracotta
fill 171 -18 334 172 -18 334 minecraft:magenta_terracotta
setblock 172 -18 323 minecraft:dark_prismarine
fill 172 -18 324 172 -15 324 minecraft:blue_terracotta
setblock 172 -18 363 minecraft:dark_prismarine
fill 173 -18 323 176 -18 323 minecraft:blue_terracotta
fill 173 -18 334 173 -17 334 minecraft:pink_terracotta
setblock 173 -18 362 minecraft:dark_prismarine
fill 173 -18 363 173 -15 363 minecraft:blue_terracotta
setblock 174 -18 334 minecraft:magenta_terracotta
fill 174 -18 336 174 7 336 minecraft:magenta_terracotta
fill 174 -18 362 174 -17 362 minecraft:blue_terracotta
setblock 176 -18 324 minecraft:dark_prismarine
fill 176 -18 349 177 -18 351 minecraft:magenta_terracotta
setblock 177 -18 323 minecraft:dark_prismarine
fill 177 -18 324 177 -15 324 minecraft:blue_terracotta
setblock 177 -18 363 minecraft:dark_prismarine
fill 178 -18 323 178 -15 323 minecraft:blue_terracotta
fill 178 -18 349 179 33 349 minecraft:magenta_terracotta
fill 178 -18 350 178 -17 350 minecraft:pink_terracotta
fill 178 -18 351 179 -18 351 minecraft:magenta_terracotta
setblock 178 -18 362 minecraft:dark_prismarine
fill 178 -18 363 178 -15 363 minecraft:blue_terracotta
fill 179 -18 324 180 -18 324 minecraft:blue_terracotta
setblock 179 -18 350 minecraft:magenta_terracotta
fill 179 -18 362 179 -15 362 minecraft:blue_terracotta
setblock 181 -18 324 minecraft:dark_prismarine
fill 181 -18 325 181 -15 325 minecraft:blue_terracotta
setblock 181 -18 359 minecraft:dark_prismarine
fill 181 -18 360 181 -15 360 minecraft:blue_terracotta
setblock 182 -18 323 minecraft:dark_prismarine
fill 182 -18 324 182 -15 324 minecraft:blue_terracotta
setblock 182 -18 338 minecraft:dark_prismarine
fill 182 -18 339 182 -17 339 minecraft:blue_terracotta
setblock 182 -18 343 minecraft:dark_prismarine
fill 182 -18 344 182 -15 344 minecraft:blue_terracotta
fill 182 -18 346 182 -18 347 minecraft:blue_terracotta
setblock 182 -18 358 minecraft:dark_prismarine
fill 182 -18 359 182 -15 359 minecraft:blue_terracotta
setblock 182 -18 363 minecraft:dark_prismarine
fill 183 -18 347 183 -18 352 minecraft:black_concrete
setblock 183 -18 353 minecraft:cyan_concrete
fill 142 -17 323 144 -17 324 minecraft:blue_terracotta
setblock 142 -17 326 minecraft:blue_terracotta
fill 142 -17 338 142 -16 338 minecraft:blue_terracotta
setblock 142 -17 342 minecraft:dark_prismarine
fill 142 -17 343 142 -14 343 minecraft:blue_terracotta
setblock 142 -17 346 minecraft:blue_terracotta
setblock 142 -17 347 minecraft:dark_prismarine
fill 142 -17 348 142 -14 348 minecraft:blue_terracotta
setblock 142 -17 352 minecraft:dark_prismarine
fill 142 -17 353 142 -14 353 minecraft:blue_terracotta
setblock 142 -17 357 minecraft:dark_prismarine
fill 142 -17 358 142 -17 361 minecraft:blue_terracotta
setblock 142 -17 362 minecraft:dark_prismarine
fill 142 -17 363 142 -14 363 minecraft:blue_terracotta
setblock 143 -17 341 minecraft:dark_prismarine
fill 143 -17 342 143 -14 342 minecraft:blue_terracotta
setblock 143 -17 346 minecraft:dark_prismarine
fill 143 -17 347 143 -14 347 minecraft:blue_terracotta
setblock 143 -17 351 minecraft:dark_prismarine
fill 143 -17 352 143 -14 352 minecraft:blue_terracotta
setblock 143 -17 356 minecraft:dark_prismarine
fill 143 -17 357 143 -15 357 minecraft:blue_terracotta
setblock 143 -17 360 minecraft:blue_terracotta
setblock 143 -17 361 minecraft:dark_prismarine
fill 143 -17 362 143 -14 362 minecraft:blue_terracotta
fill 144 -17 341 144 -16 341 minecraft:blue_terracotta
setblock 144 -17 345 minecraft:dark_prismarine
fill 144 -17 346 144 -14 346 minecraft:blue_terracotta
setblock 144 -17 349 minecraft:blue_terracotta
setblock 144 -17 360 minecraft:dark_prismarine
fill 144 -17 361 144 -16 361 minecraft:blue_terracotta
setblock 145 -17 323 minecraft:blue_terracotta
setblock 145 -17 324 minecraft:dark_prismarine
fill 145 -17 335 145 33 335 minecraft:magenta_terracotta
setblock 145 -17 343 minecraft:blue_terracotta
setblock 145 -17 344 minecraft:dark_prismarine
fill 145 -17 345 145 -14 345 minecraft:blue_terracotta
setblock 146 -17 323 minecraft:dark_prismarine
fill 146 -17 324 146 -14 324 minecraft:blue_terracotta
fill 146 -17 335 147 -17 335 minecraft:pink_terracotta
setblock 146 -17 363 minecraft:dark_prismarine
fill 147 -17 323 147 -14 323 minecraft:blue_terracotta
setblock 147 -17 336 minecraft:pink_terracotta
fill 147 -17 345 149 28 347 minecraft:dark_prismarine
setblock 147 -17 362 minecraft:dark_prismarine
fill 147 -17 363 147 -14 363 minecraft:blue_terracotta
fill 148 -17 335 148 33 336 minecraft:magenta_terracotta
fill 148 -17 348 149 19 348 minecraft:dark_prismarine
setblock 148 -17 361 minecraft:dark_prismarine
fill 148 -17 362 148 -15 362 minecraft:blue_terracotta
setblock 149 -17 324 minecraft:blue_terracotta
setblock 149 -17 361 minecraft:blue_terracotta
setblock 150 -17 352 minecraft:pink_terracotta
fill 150 -17 353 150 -10 354 minecraft:magenta_terracotta
setblock 151 -17 323 minecraft:dark_prismarine
setblock 151 -17 351 minecraft:pink_terracotta
setblock 151 -17 363 minecraft:dark_prismarine
fill 152 -17 323 152 -16 323 minecraft:blue_terracotta
fill 152 -17 351 152 10 351 minecraft:magenta_terracotta
fill 152 -17 363 152 -16 363 minecraft:blue_terracotta
fill 156 -17 326 156 0 326 minecraft:magenta_terracotta
fill 157 -17 326 158 -17 326 minecraft:pink_terracotta
fill 159 -17 323 160 -17 323 minecraft:blue_terracotta
fill 159 -17 326 159 24 326 minecraft:magenta_terracotta
setblock 161 -17 323 minecraft:dark_prismarine
setblock 161 -17 363 minecraft:dark_prismarine
fill 162 -17 323 162 -14 323 minecraft:blue_terracotta
fill 162 -17 363 165 -17 363 minecraft:blue_terracotta
setblock 164 -17 325 minecraft:dark_prismarine
fill 164 -17 362 166 -17 362 minecraft:blue_terracotta
setblock 165 -17 324 minecraft:dark_prismarine
fill 165 -17 325 165 -14 325 minecraft:blue_terracotta
setblock 166 -17 323 minecraft:dark_prismarine
fill 166 -17 324 166 -14 324 minecraft:blue_terracotta
fill 166 -17 360 167 -17 360 minecraft:pink_terracotta
fill 166 -17 361 168 -15 361 minecraft:magenta_terracotta
setblock 166 -17 363 minecraft:dark_prismarine
fill 167 -17 323 167 -14 323 minecraft:blue_terracotta
setblock 167 -17 362 minecraft:dark_prismarine
fill 167 -17 363 167 -14 363 minecraft:blue_terracotta
fill 168 -17 360 168 -3 360 minecraft:magenta_terracotta
fill 168 -17 362 168 -15 362 minecraft:blue_terracotta
setblock 169 -17 325 minecraft:dark_prismarine
setblock 170 -17 324 minecraft:dark_prismarine
fill 170 -17 325 170 -14 325 minecraft:blue_terracotta
setblock 171 -17 323 minecraft:dark_prismarine
fill 171 -17 324 171 -14 324 minecraft:blue_terracotta
fill 171 -17 333 171 -12 334 minecraft:magenta_terracotta
setblock 171 -17 363 minecraft:dark_prismarine
fill 172 -17 323 175 -17 323 minecraft:blue_terracotta
fill 172 -17 333 172 -1 333 minecraft:magenta_terracotta
setblock 172 -17 334 minecraft:pink_terracotta
fill 172 -17 335 172 14 335 minecraft:magenta_terracotta
setblock 172 -17 362 minecraft:dark_prismarine
fill 172 -17 363 172 -14 363 minecraft:blue_terracotta
setblock 173 -17 333 minecraft:pink_terracotta
setblock 173 -17 335 minecraft:pink_terracotta
setblock 173 -17 362 minecraft:blue_terracotta
fill 174 -17 333 175 6 333 minecraft:magenta_terracotta
setblock 174 -17 334 minecraft:pink_terracotta
setblock 175 -17 324 minecraft:dark_prismarine
setblock 176 -17 323 minecraft:dark_prismarine
fill 176 -17 324 176 -15 324 minecraft:blue_terracotta
fill 176 -17 349 176 6 351 minecraft:magenta_terracotta
setblock 176 -17 363 minecraft:dark_prismarine
fill 177 -17 323 177 -14 323 minecraft:blue_terracotta
fill 177 -17 349 177 33 349 minecraft:magenta_terracotta
setblock 177 -17 350 minecraft:pink_terracotta
fill 177 -17 351 177 33 351 minecraft:magenta_terracotta
setblock 177 -17 362 minecraft:dark_prismarine
fill 177 -17 363 177 -14 363 minecraft:blue_terracotta
setblock 178 -17 351 minecraft:pink_terracotta
setblock 178 -17 362 minecraft:blue_terracotta
setblock 179 -17 324 minecraft:blue_terracotta
setblock 179 -17 350 minecraft:pink_terracotta
fill 179 -17 351 179 33 351 minecraft:magenta_terracotta
setblock 180 -17 324 minecraft:dark_prismarine
setblock 181 -17 323 minecraft:dark_prismarine
fill 181 -17 324 181 -14 324 minecraft:blue_terracotta
setblock 181 -17 359 minecraft:blue_terracotta
setblock 181 -17 363 minecraft:dark_prismarine
fill 182 -17 323 182 -14 323 minecraft:blue_terracotta
setblock 182 -17 326 minecraft:blue_terracotta
setblock 182 -17 327 minecraft:dark_prismarine
fill 182 -17 328 182 -14 328 minecraft:blue_terracotta
setblock 182 -17 335 minecraft:purple_concrete
setblock 182 -17 342 minecraft:dark_prismarine
fill 182 -17 343 182 -14 343 minecraft:blue_terracotta
setblock 182 -17 346 minecraft:blue_terracotta
setblock 182 -17 347 minecraft:dark_prismarine
fill 182 -17 348 182 -14 348 minecraft:blue_terracotta
setblock 182 -17 357 minecraft:dark_prismarine
fill 182 -17 358 182 -14 358 minecraft:blue_terracotta
setblock 182 -17 362 minecraft:dark_prismarine
fill 182 -17 363 182 -14 363 minecraft:blue_terracotta
fill 183 -17 341 183 101 344 minecraft:black_concrete
setblock 183 -17 345 minecraft:cyan_concrete
fill 183 -17 346 183 20 350 minecraft:black_concrete
setblock 183 -17 351 minecraft:cyan_concrete
fill 183 -17 352 183 -11 353 minecraft:black_concrete
fill 142 -16 323 143 -16 324 minecraft:blue_terracotta
setblock 142 -16 326 minecraft:dark_prismarine
setblock 142 -16 332 minecraft:purple_concrete
setblock 142 -16 341 minecraft:dark_prismarine
fill 142 -16 342 142 -13 342 minecraft:blue_terracotta
setblock 142 -16 346 minecraft:dark_prismarine
fill 142 -16 347 142 -13 347 minecraft:blue_terracotta
setblock 142 -16 350 minecraft:blue_terracotta
setblock 142 -16 351 minecraft:dark_prismarine
fill 142 -16 352 142 -13 352 minecraft:blue_terracotta
setblock 142 -16 356 minecraft:dark_prismarine
fill 142 -16 357 142 -16 360 minecraft:blue_terracotta
setblock 142 -16 361 minecraft:dark_prismarine
fill 142 -16 362 142 -13 362 minecraft:blue_terracotta
setblock 143 -16 340 minecraft:dark_prismarine
fill 143 -16 341 143 -13 341 minecraft:blue_terracotta
setblock 143 -16 345 minecraft:dark_prismarine
fill 143 -16 346 143 -13 346 minecraft:blue_terracotta
setblock 143 -16 350 minecraft:dark_prismarine
fill 143 -16 351 143 -13 351 minecraft:blue_terracotta
setblock 143 -16 355 minecraft:dark_prismarine
setblock 143 -16 356 minecraft:blue_terracotta
setblock 143 -16 360 minecraft:dark_prismarine
fill 143 -16 361 143 -13 361 minecraft:blue_terracotta
setblock 144 -16 323 minecraft:blue_terracotta
setblock 144 -16 324 minecraft:dark_prismarine
setblock 144 -16 344 minecraft:dark_prismarine
fill 144 -16 345 144 -13 345 minecraft:blue_terracotta
setblock 144 -16 349 minecraft:dark_prismarine
setblock 144 -16 360 minecraft:blue_terracotta
setblock 145 -16 323 minecraft:dark_prismarine
fill 145 -16 324 145 -13 324 minecraft:blue_terracotta
fill 145 -16 344 145 -15 344 minecraft:blue_terracotta
fill 145 -16 346 145 -15 346 minecraft:blue_terracotta
setblock 145 -16 363 minecraft:dark_prismarine
fill 146 -16 323 146 -13 323 minecraft:blue_terracotta
fill 146 -16 335 147 7 336 minecraft:magenta_terracotta
fill 146 -16 345 146 -15 347 minecraft:black_concrete
setblock 146 -16 362 minecraft:dark_prismarine
fill 146 -16 363 146 -13 363 minecraft:blue_terracotta
fill 147 -16 344 149 -15 344 minecraft:black_concrete
fill 147 -16 348 147 -15 348 minecraft:black_concrete
setblock 147 -16 361 minecraft:dark_prismarine
fill 147 -16 362 147 -14 362 minecraft:blue_terracotta
fill 148 -16 349 148 -15 349 minecraft:black_concrete
setblock 150 -16 323 minecraft:dark_prismarine
fill 150 -16 345 150 -15 348 minecraft:black_concrete
fill 150 -16 352 151 17 352 minecraft:magenta_terracotta
setblock 150 -16 363 minecraft:dark_prismarine
fill 151 -16 323 151 -15 323 minecraft:blue_terracotta
fill 151 -16 351 151 26 351 minecraft:magenta_terracotta
fill 151 -16 363 151 -15 363 minecraft:blue_terracotta
setblock 155 -16 363 minecraft:purple_concrete
fill 156 -16 327 158 6 327 minecraft:magenta_terracotta
fill 157 -16 326 158 11 326 minecraft:magenta_terracotta
setblock 159 -16 323 minecraft:blue_terracotta
setblock 160 -16 323 minecraft:dark_prismarine
fill 161 -16 323 161 -14 324 minecraft:blue_terracotta
fill 161 -16 363 164 -16 363 minecraft:blue_terracotta
setblock 163 -16 325 minecraft:dark_prismarine
setblock 164 -16 324 minecraft:dark_prismarine
fill 164 -16 325 164 -13 325 minecraft:blue_terracotta
fill 164 -16 362 165 -16 362 minecraft:blue_terracotta
setblock 165 -16 323 minecraft:dark_prismarine
fill 165 -16 324 165 -13 324 minecraft:blue_terracotta
setblock 165 -16 363 minecraft:dark_prismarine
fill 166 -16 323 166 -13 323 minecraft:blue_terracotta
fill 166 -16 359 167 8 360 minecraft:magenta_terracotta
setblock 166 -16 362 minecraft:dark_prismarine
fill 166 -16 363 166 -13 363 minecraft:blue_terracotta
fill 167 -16 362 167 -15 362 minecraft:blue_terracotta
setblock 168 -16 325 minecraft:dark_prismarine
setblock 169 -16 324 minecraft:dark_prismarine
fill 169 -16 325 169 -13 325 minecraft:blue_terracotta
setblock 170 -16 323 minecraft:dark_prismarine
fill 170 -16 324 170 -13 324 minecraft:blue_terracotta
setblock 170 -16 363 minecraft:dark_prismarine
fill 171 -16 323 174 -16 323 minecraft:blue_terracotta
setblock 171 -16 362 minecraft:dark_prismarine
fill 171 -16 363 171 -13 363 minecraft:blue_terracotta
fill 172 -16 334 174 9 334 minecraft:magenta_terracotta
setblock 172 -16 362 minecraft:blue_terracotta
fill 173 -16 333 173 7 333 minecraft:magenta_terracotta
fill 173 -16 335 173 29 335 minecraft:magenta_terracotta
setblock 174 -16 324 minecraft:dark_prismarine
setblock 175 -16 323 minecraft:dark_prismarine
fill 175 -16 324 175 -14 324 minecraft:blue_terracotta
setblock 175 -16 363 minecraft:dark_prismarine
fill 176 -16 323 176 -13 323 minecraft:blue_terracotta
fill 176 -16 363 176 -13 363 minecraft:blue_terracotta
fill 177 -16 350 179 7 350 minecraft:magenta_terracotta
fill 178 -16 351 178 6 351 minecraft:magenta_terracotta
setblock 179 -16 324 minecraft:dark_prismarine
setblock 180 -16 323 minecraft:dark_prismarine
fill 180 -16 324 180 -13 324 minecraft:blue_terracotta
setblock 180 -16 363 minecraft:dark_prismarine
fill 181 -16 323 181 -13 323 minecraft:blue_terracotta
setblock 181 -16 362 minecraft:dark_prismarine
fill 181 -16 363 181 -13 363 minecraft:blue_terracotta
setblock 182 -16 326 minecraft:dark_prismarine
fill 182 -16 327 182 -13 327 minecraft:blue_terracotta
setblock 182 -16 329 minecraft:purple_concrete
setblock 182 -16 341 minecraft:dark_prismarine
fill 182 -16 342 182 -13 342 minecraft:blue_terracotta
setblock 182 -16 346 minecraft:dark_prismarine
fill 182 -16 347 182 -13 347 minecraft:blue_terracotta
fill 182 -16 349 182 -16 350 minecraft:blue_terracotta
setblock 182 -16 354 minecraft:purple_concrete
setblock 182 -16 356 minecraft:dark_prismarine
fill 182 -16 357 182 -13 357 minecraft:blue_terracotta
setblock 182 -16 361 minecraft:dark_prismarine
fill 182 -16 362 182 -13 362 minecraft:blue_terracotta
fill 183 -16 345 183 23 345 minecraft:black_concrete
fill 183 -16 351 183 36 351 minecraft:black_concrete
fill 142 -15 323 142 -15 324 minecraft:blue_terracotta
setblock 142 -15 325 minecraft:dark_prismarine
fill 142 -15 326 142 -12 326 minecraft:blue_terracotta
setblock 142 -15 338 minecraft:purple_concrete
setblock 142 -15 340 minecraft:dark_prismarine
fill 142 -15 341 142 -12 341 minecraft:blue_terracotta
setblock 142 -15 345 minecraft:dark_prismarine
fill 142 -15 346 142 -12 346 minecraft:blue_terracotta
setblock 142 -15 350 minecraft:dark_prismarine
fill 142 -15 351 142 -12 351 minecraft:blue_terracotta
setblock 142 -15 355 minecraft:dark_prismarine
fill 142 -15 356 142 -15 359 minecraft:blue_terracotta
setblock 142 -15 360 minecraft:dark_prismarine
fill 142 -15 361 142 -12 361 minecraft:blue_terracotta
setblock 143 -15 323 minecraft:blue_terracotta
setblock 143 -15 324 minecraft:dark_prismarine
fill 143 -15 340 143 -14 340 minecraft:blue_terracotta
setblock 143 -15 344 minecraft:dark_prismarine
fill 143 -15 345 143 -12 345 minecraft:blue_terracotta
setblock 143 -15 348 minecraft:blue_terracotta
setblock 143 -15 349 minecraft:dark_prismarine
fill 143 -15 350 144 -13 350 minecraft:blue_terracotta
setblock 143 -15 354 minecraft:dark_prismarine
setblock 143 -15 359 minecraft:dark_prismarine
fill 143 -15 360 143 -14 360 minecraft:blue_terracotta
setblock 144 -15 323 minecraft:dark_prismarine
fill 144 -15 324 144 -12 324 minecraft:blue_terracotta
setblock 144 -15 343 minecraft:dark_prismarine
fill 144 -15 344 144 -12 344 minecraft:blue_terracotta
setblock 144 -15 348 minecraft:dark_prismarine
fill 144 -15 349 144 -12 349 minecraft:blue_terracotta
setblock 144 -15 363 minecraft:dark_prismarine
fill 145 -15 323 145 -12 323 minecraft:blue_terracotta
setblock 145 -15 347 minecraft:black_concrete
setblock 145 -15 362 minecraft:dark_prismarine
fill 145 -15 363 145 -12 363 minecraft:blue_terracotta
setblock 146 -15 344 minecraft:black_concrete
fill 146 -15 348 146 -15 349 minecraft:black_concrete
fill 146 -15 362 146 -14 362 minecraft:blue_terracotta
setblock 147 -15 349 minecraft:black_concrete
setblock 148 -15 343 minecraft:black_concrete
setblock 149 -15 323 minecraft:dark_prismarine
fill 149 -15 349 150 -15 349 minecraft:black_concrete
setblock 149 -15 363 minecraft:dark_prismarine
fill 150 -15 323 150 -14 323 minecraft:blue_terracotta
setblock 150 -15 344 minecraft:black_concrete
fill 150 -15 363 150 -14 363 minecraft:blue_terracotta
fill 151 -15 345 151 -15 348 minecraft:black_concrete
fill 153 -15 351 153 -15 352 minecraft:magenta_terracotta
fill 157 -15 323 157 -14 323 minecraft:purple_concrete
setblock 158 -15 323 minecraft:blue_terracotta
setblock 159 -15 323 minecraft:dark_prismarine
fill 160 -15 323 160 -12 323 minecraft:blue_terracotta
fill 160 -15 327 160 33 327 minecraft:magenta_terracotta
fill 161 -15 363 163 -15 363 minecraft:blue_terracotta
setblock 163 -15 324 minecraft:dark_prismarine
fill 163 -15 325 163 -12 325 minecraft:blue_terracotta
setblock 164 -15 323 minecraft:dark_prismarine
fill 164 -15 324 164 -12 324 minecraft:blue_terracotta
setblock 164 -15 363 minecraft:dark_prismarine
fill 165 -15 323 165 -12 323 minecraft:blue_terracotta
setblock 165 -15 362 minecraft:dark_prismarine
fill 165 -15 363 165 -12 363 minecraft:blue_terracotta
setblock 166 -15 362 minecraft:blue_terracotta
setblock 167 -15 325 minecraft:dark_prismarine
setblock 168 -15 324 minecraft:dark_prismarine
fill 168 -15 325 168 -12 325 minecraft:blue_terracotta
setblock 169 -15 323 minecraft:dark_prismarine
fill 169 -15 324 169 -12 324 minecraft:blue_terracotta
setblock 169 -15 363 minecraft:dark_prismarine
fill 170 -15 323 173 -15 323 minecraft:blue_terracotta
fill 170 -15 363 170 -12 363 minecraft:blue_terracotta
setblock 173 -15 324 minecraft:dark_prismarine
setblock 174 -15 323 minecraft:dark_prismarine
fill 174 -15 324 174 -12 324 minecraft:blue_terracotta
setblock 174 -15 363 minecraft:dark_prismarine
fill 175 -15 323 175 -12 323 minecraft:blue_terracotta
fill 175 -15 363 175 -12 363 minecraft:blue_terracotta
setblock 178 -15 324 minecraft:dark_prismarine
setblock 179 -15 323 minecraft:dark_prismarine
fill 179 -15 324 179 -12 324 minecraft:blue_terracotta
setblock 179 -15 363 minecraft:dark_prismarine
fill 180 -15 323 180 -12 323 minecraft:blue_terracotta
setblock 180 -15 362 minecraft:dark_prismarine
fill 180 -15 363 180 -12 363 minecraft:blue_terracotta
setblock 181 -15 361 minecraft:dark_prismarine
fill 181 -15 362 181 -12 362 minecraft:blue_terracotta
setblock 182 -15 325 minecraft:dark_prismarine
fill 182 -15 326 182 -12 326 minecraft:blue_terracotta
fill 182 -15 341 182 -14 341 minecraft:blue_terracotta
setblock 182 -15 345 minecraft:dark_prismarine
fill 182 -15 346 182 -12 346 minecraft:blue_terracotta
setblock 182 -15 349 minecraft:blue_terracotta
setblock 182 -15 350 minecraft:dark_prismarine
fill 182 -15 351 182 -13 352 minecraft:blue_terracotta
setblock 182 -15 355 minecraft:dark_prismarine
fill 182 -15 356 182 -12 356 minecraft:blue_terracotta
setblock 182 -15 360 minecraft:dark_prismarine
fill 182 -15 361 182 -12 361 minecraft:blue_terracotta
setblock 142 -14 323 minecraft:blue_terracotta
setblock 142 -14 324 minecraft:dark_prismarine
fill 142 -14 325 142 -11 325 minecraft:blue_terracotta
fill 142 -14 327 142 -13 327 minecraft:blue_terracotta
setblock 142 -14 339 minecraft:dark_prismarine
fill 142 -14 340 142 -11 340 minecraft:blue_terracotta
setblock 142 -14 344 minecraft:dark_prismarine
fill 142 -14 345 142 -11 345 minecraft:blue_terracotta
setblock 142 -14 349 minecraft:dark_prismarine
fill 142 -14 350 142 -11 350 minecraft:blue_terracotta
setblock 142 -14 354 minecraft:dark_prismarine
fill 142 -14 355 142 -14 358 minecraft:blue_terracotta
setblock 142 -14 359 minecraft:dark_prismarine
fill 142 -14 360 142 -11 360 minecraft:blue_terracotta
setblock 142 -14 364 minecraft:cyan_concrete
setblock 143 -14 323 minecraft:dark_prismarine
fill 143 -14 324 143 -11 324 minecraft:blue_terracotta
setblock 143 -14 343 minecraft:dark_prismarine
fill 143 -14 344 143 -11 344 minecraft:blue_terracotta
setblock 143 -14 348 minecraft:dark_prismarine
fill 143 -14 349 143 -11 349 minecraft:blue_terracotta
setblock 143 -14 353 minecraft:dark_prismarine
fill 143 -14 354 143 -11 354 minecraft:blue_terracotta
setblock 143 -14 359 minecraft:blue_terracotta
setblock 143 -14 363 minecraft:dark_prismarine
fill 143 -14 364 148 5 364 minecraft:black_concrete
fill 144 -14 323 144 -11 323 minecraft:blue_terracotta
setblock 144 -14 342 minecraft:dark_prismarine
fill 144 -14 343 144 -11 343 minecraft:blue_terracotta
setblock 144 -14 347 minecraft:dark_prismarine
fill 144 -14 348 144 -11 348 minecraft:blue_terracotta
setblock 144 -14 351 minecraft:blue_terracotta
setblock 144 -14 362 minecraft:dark_prismarine
fill 144 -14 363 144 -11 363 minecraft:blue_terracotta
setblock 145 -14 346 minecraft:dark_prismarine
fill 145 -14 347 145 -11 347 minecraft:blue_terracotta
fill 145 -14 362 145 -13 362 minecraft:blue_terracotta
setblock 148 -14 323 minecraft:dark_prismarine
setblock 148 -14 363 minecraft:dark_prismarine
fill 149 -14 323 149 -12 323 minecraft:blue_terracotta
setblock 149 -14 363 minecraft:blue_terracotta
setblock 151 -14 323 minecraft:purple_concrete
fill 151 -14 353 151 -10 354 minecraft:magenta_terracotta
fill 152 -14 353 152 -4 353 minecraft:magenta_terracotta
fill 153 -14 352 153 -11 352 minecraft:magenta_terracotta
setblock 158 -14 323 minecraft:dark_prismarine
fill 159 -14 323 159 -11 323 minecraft:blue_terracotta
fill 160 -14 324 160 -13 324 minecraft:blue_terracotta
setblock 162 -14 324 minecraft:dark_prismarine
fill 162 -14 325 162 -11 325 minecraft:blue_terracotta
setblock 162 -14 363 minecraft:blue_terracotta
setblock 163 -14 323 minecraft:dark_prismarine
fill 163 -14 324 163 -11 324 minecraft:blue_terracotta
setblock 163 -14 363 minecraft:dark_prismarine
fill 164 -14 323 164 -11 323 minecraft:blue_terracotta
fill 164 -14 363 164 -11 363 minecraft:blue_terracotta
fill 165 -14 359 165 19 360 minecraft:magenta_terracotta
setblock 166 -14 325 minecraft:dark_prismarine
fill 166 -14 361 167 -7 361 minecraft:magenta_terracotta
setblock 167 -14 324 minecraft:dark_prismarine
fill 167 -14 325 167 -11 325 minecraft:blue_terracotta
setblock 168 -14 323 minecraft:dark_prismarine
fill 168 -14 324 168 -11 324 minecraft:blue_terracotta
fill 168 -14 359 168 4 359 minecraft:magenta_terracotta
setblock 168 -14 363 minecraft:dark_prismarine
fill 169 -14 323 172 -14 323 minecraft:blue_terracotta
fill 169 -14 363 169 -11 363 minecraft:blue_terracotta
setblock 172 -14 324 minecraft:dark_prismarine
setblock 173 -14 323 minecraft:dark_prismarine
fill 173 -14 324 173 -11 324 minecraft:blue_terracotta
setblock 173 -14 363 minecraft:dark_prismarine
fill 174 -14 323 174 -11 323 minecraft:blue_terracotta
fill 174 -14 363 174 -13 363 minecraft:blue_terracotta
setblock 177 -14 324 minecraft:dark_prismarine
setblock 178 -14 323 minecraft:dark_prismarine
fill 178 -14 324 178 -11 324 minecraft:blue_terracotta
setblock 178 -14 363 minecraft:dark_prismarine
fill 179 -14 323 179 -11 323 minecraft:blue_terracotta
fill 179 -14 363 179 -11 363 minecraft:blue_terracotta
fill 180 -14 362 180 -11 362 minecraft:blue_terracotta
setblock 181 -14 325 minecraft:dark_prismarine
fill 181 -14 326 181 -11 326 minecraft:blue_terracotta
fill 181 -14 361 181 -11 361 minecraft:blue_terracotta
setblock 182 -14 324 minecraft:dark_prismarine
fill 182 -14 325 182 -11 325 minecraft:blue_terracotta
fill 182 -14 336 182 -13 336 minecraft:purple_concrete
setblock 182 -14 344 minecraft:dark_prismarine
fill 182 -14 345 182 -11 345 minecraft:blue_terracotta
setblock 182 -14 349 minecraft:dark_prismarine
fill 182 -14 350 182 -11 350 minecraft:blue_terracotta
setblock 182 -14 353 minecraft:blue_terracotta
setblock 182 -14 354 minecraft:dark_prismarine
fill 182 -14 355 182 -11 355 minecraft:blue_terracotta
setblock 182 -14 359 minecraft:dark_prismarine
fill 182 -14 360 182 -11 360 minecraft:blue_terracotta
setblock 142 -13 323 minecraft:dark_prismarine
fill 142 -13 324 142 -10 324 minecraft:blue_terracotta
setblock 142 -13 328 minecraft:dark_prismarine
setblock 142 -13 331 minecraft:purple_concrete
fill 142 -13 339 142 -10 339 minecraft:blue_terracotta
setblock 142 -13 343 minecraft:dark_prismarine
fill 142 -13 344 142 -10 344 minecraft:blue_terracotta
setblock 142 -13 348 minecraft:dark_prismarine
fill 142 -13 349 142 -10 349 minecraft:blue_terracotta
setblock 142 -13 353 minecraft:dark_prismarine
fill 142 -13 354 142 -13 357 minecraft:blue_terracotta
setblock 142 -13 358 minecraft:dark_prismarine
fill 142 -13 359 142 -10 359 minecraft:blue_terracotta
setblock 142 -13 363 minecraft:dark_prismarine
fill 142 -13 364 142 131 364 minecraft:black_concrete
fill 143 -13 323 143 -10 323 minecraft:blue_terracotta
fill 143 -13 325 143 -12 325 minecraft:blue_terracotta
setblock 143 -13 342 minecraft:dark_prismarine
fill 143 -13 343 143 -10 343 minecraft:blue_terracotta
setblock 143 -13 347 minecraft:dark_prismarine
fill 143 -13 348 143 -10 348 minecraft:blue_terracotta
setblock 143 -13 352 minecraft:dark_prismarine
fill 143 -13 353 143 -10 353 minecraft:blue_terracotta
fill 143 -13 355 143 -12 355 minecraft:blue_terracotta
setblock 143 -13 362 minecraft:dark_prismarine
fill 143 -13 363 143 -10 363 minecraft:blue_terracotta
setblock 144 -13 325 minecraft:light[level=12]
setblock 144 -13 332 minecraft:light[level=12]
setblock 144 -13 339 minecraft:light[level=12]
fill 144 -13 342 144 -10 342 minecraft:blue_terracotta
setblock 144 -13 346 minecraft:dark_prismarine
fill 144 -13 347 144 -10 347 minecraft:blue_terracotta
setblock 144 -13 351 minecraft:dark_prismarine
setblock 144 -13 353 minecraft:light[level=12]
setblock 144 -13 360 minecraft:light[level=12]
fill 144 -13 362 144 -12 362 minecraft:blue_terracotta
setblock 145 -13 345 minecraft:dark_prismarine
fill 145 -13 346 145 -10 346 minecraft:blue_terracotta
fill 145 -13 348 145 -12 348 minecraft:blue_terracotta
setblock 146 -13 324 minecraft:dark_prismarine
setblock 147 -13 323 minecraft:dark_prismarine
setblock 147 -13 363 minecraft:dark_prismarine
fill 148 -13 323 148 -10 323 minecraft:blue_terracotta
setblock 148 -13 363 minecraft:blue_terracotta
fill 149 -13 350 149 7 350 minecraft:magenta_terracotta
setblock 151 -13 325 minecraft:light[level=12]
setblock 151 -13 332 minecraft:light[level=12]
setblock 151 -13 339 minecraft:light[level=12]
setblock 151 -13 346 minecraft:light[level=12]
setblock 151 -13 360 minecraft:light[level=12]
setblock 154 -13 363 minecraft:purple_concrete
fill 158 -13 323 158 -10 323 minecraft:blue_terracotta
setblock 158 -13 332 minecraft:light[level=12]
setblock 158 -13 339 minecraft:light[level=12]
setblock 158 -13 346 minecraft:light[level=12]
setblock 158 -13 353 minecraft:light[level=12]
setblock 158 -13 360 minecraft:light[level=12]
setblock 161 -13 323 minecraft:blue_terracotta
setblock 161 -13 324 minecraft:dark_prismarine
setblock 162 -13 323 minecraft:dark_prismarine
fill 162 -13 324 162 -10 324 minecraft:blue_terracotta
setblock 162 -13 363 minecraft:dark_prismarine
fill 163 -13 323 163 -10 323 minecraft:blue_terracotta
fill 163 -13 363 163 -10 363 minecraft:blue_terracotta
fill 164 -13 359 164 33 359 minecraft:magenta_terracotta
setblock 165 -13 325 minecraft:dark_prismarine
fill 165 -13 326 166 -11 326 minecraft:blue_terracotta
setblock 165 -13 332 minecraft:light[level=12]
setblock 165 -13 339 minecraft:light[level=12]
setblock 165 -13 346 minecraft:light[level=12]
setblock 165 -13 353 minecraft:light[level=12]
fill 165 -13 357 165 33 357 minecraft:magenta_terracotta
setblock 166 -13 324 minecraft:dark_prismarine
fill 166 -13 325 166 -10 325 minecraft:blue_terracotta
setblock 167 -13 323 minecraft:dark_prismarine
fill 167 -13 324 167 -10 324 minecraft:blue_terracotta
setblock 167 -13 363 minecraft:dark_prismarine
fill 168 -13 323 171 -13 323 minecraft:blue_terracotta
fill 168 -13 363 168 -10 363 minecraft:blue_terracotta
setblock 170 -13 325 minecraft:dark_prismarine
setblock 171 -13 324 minecraft:dark_prismarine
setblock 172 -13 323 minecraft:dark_prismarine
fill 172 -13 324 172 -10 324 minecraft:blue_terracotta
setblock 172 -13 325 minecraft:light[level=12]
setblock 172 -13 339 minecraft:light[level=12]
setblock 172 -13 346 minecraft:light[level=12]
setblock 172 -13 353 minecraft:light[level=12]
setblock 172 -13 360 minecraft:light[level=12]
setblock 172 -13 363 minecraft:dark_prismarine
fill 173 -13 323 173 -10 323 minecraft:blue_terracotta
setblock 173 -13 363 minecraft:blue_terracotta
setblock 177 -13 323 minecraft:dark_prismarine
fill 177 -13 324 177 -10 324 minecraft:blue_terracotta
setblock 177 -13 363 minecraft:dark_prismarine
fill 178 -13 323 178 -10 323 minecraft:blue_terracotta
fill 178 -13 363 178 -10 363 minecraft:blue_terracotta
setblock 179 -13 325 minecraft:light[level=12]
setblock 179 -13 332 minecraft:light[level=12]
setblock 179 -13 339 minecraft:light[level=12]
setblock 179 -13 346 minecraft:light[level=12]
setblock 179 -13 353 minecraft:light[level=12]
setblock 179 -13 360 minecraft:light[level=12]
setblock 181 -13 324 minecraft:dark_prismarine
fill 181 -13 325 181 -10 325 minecraft:blue_terracotta
setblock 182 -13 323 minecraft:dark_prismarine
fill 182 -13 324 182 -10 324 minecraft:blue_terracotta
setblock 182 -13 328 minecraft:dark_prismarine
fill 182 -13 329 182 -10 329 minecraft:blue_terracotta
setblock 182 -13 330 minecraft:purple_concrete
setblock 182 -13 343 minecraft:dark_prismarine
fill 182 -13 344 182 -10 344 minecraft:blue_terracotta
setblock 182 -13 348 minecraft:dark_prismarine
fill 182 -13 349 182 -10 349 minecraft:blue_terracotta
setblock 182 -13 353 minecraft:dark_prismarine
fill 182 -13 354 182 -10 354 minecraft:blue_terracotta
setblock 182 -13 358 minecraft:dark_prismarine
fill 182 -13 359 182 -10 359 minecraft:blue_terracotta
setblock 182 -13 363 minecraft:dark_prismarine
fill 142 -12 323 142 -9 323 minecraft:blue_terracotta
setblock 142 -12 327 minecraft:dark_prismarine
fill 142 -12 328 142 -10 329 minecraft:blue_terracotta
setblock 142 -12 337 minecraft:purple_concrete
setblock 142 -12 342 minecraft:dark_prismarine
fill 142 -12 343 142 -9 343 minecraft:blue_terracotta
setblock 142 -12 347 minecraft:dark_prismarine
fill 142 -12 348 142 -9 348 minecraft:blue_terracotta
setblock 142 -12 352 minecraft:dark_prismarine
fill 142 -12 353 142 -12 356 minecraft:blue_terracotta
setblock 142 -12 357 minecraft:dark_prismarine
fill 142 -12 358 142 -9 358 minecraft:blue_terracotta
setblock 142 -12 362 minecraft:dark_prismarine
fill 142 -12 363 142 -9 363 minecraft:blue_terracotta
setblock 143 -12 326 minecraft:dark_prismarine
setblock 143 -12 340 minecraft:blue_terracotta
setblock 143 -12 341 minecraft:dark_prismarine
fill 143 -12 342 143 -9 342 minecraft:blue_terracotta
setblock 143 -12 346 minecraft:dark_prismarine
fill 143 -12 347 143 -9 347 minecraft:blue_terracotta
setblock 143 -12 350 minecraft:blue_terracotta
setblock 143 -12 351 minecraft:dark_prismarine
fill 143 -12 352 144 -10 352 minecraft:blue_terracotta
setblock 143 -12 356 minecraft:dark_prismarine
fill 143 -12 362 143 -11 362 minecraft:blue_terracotta
setblock 144 -12 345 minecraft:dark_prismarine
fill 144 -12 346 144 -9 346 minecraft:blue_terracotta
setblock 144 -12 350 minecraft:dark_prismarine
fill 144 -12 351 144 -9 351 minecraft:blue_terracotta
setblock 145 -12 324 minecraft:dark_prismarine
fill 145 -12 345 145 -9 345 minecraft:blue_terracotta
setblock 145 -12 349 minecraft:dark_prismarine
setblock 146 -12 323 minecraft:dark_prismarine
setblock 146 -12 363 minecraft:dark_prismarine
fill 147 -12 323 147 -9 323 minecraft:blue_terracotta
fill 147 -12 363 147 -11 363 minecraft:blue_terracotta
fill 155 -12 328 155 -11 329 minecraft:dark_prismarine
fill 156 -12 329 156 -11 329 minecraft:dark_prismarine
fill 157 -12 323 157 -9 323 minecraft:blue_terracotta
setblock 159 -12 324 minecraft:blue_terracotta
setblock 160 -12 324 minecraft:dark_prismarine
setblock 160 -12 363 minecraft:purple_concrete
setblock 161 -12 323 minecraft:dark_prismarine
fill 161 -12 324 161 -10 325 minecraft:blue_terracotta
setblock 161 -12 363 minecraft:dark_prismarine
fill 162 -12 323 162 -9 323 minecraft:blue_terracotta
fill 162 -12 363 162 -9 363 minecraft:blue_terracotta
setblock 163 -12 326 minecraft:dark_prismarine
setblock 164 -12 325 minecraft:dark_prismarine
fill 164 -12 326 164 -9 326 minecraft:blue_terracotta
setblock 165 -12 324 minecraft:dark_prismarine
fill 165 -12 325 165 -9 325 minecraft:blue_terracotta
setblock 166 -12 323 minecraft:dark_prismarine
fill 166 -12 324 166 -9 324 minecraft:blue_terracotta
setblock 166 -12 363 minecraft:dark_prismarine
fill 167 -12 323 170 -12 323 minecraft:blue_terracotta
fill 167 -12 363 167 -9 363 minecraft:blue_terracotta
setblock 169 -12 325 minecraft:dark_prismarine
setblock 170 -12 324 minecraft:dark_prismarine
fill 170 -12 325 170 -10 325 minecraft:blue_terracotta
setblock 171 -12 323 minecraft:dark_prismarine
fill 171 -12 324 171 -9 324 minecraft:blue_terracotta
setblock 171 -12 363 minecraft:dark_prismarine
fill 172 -12 323 172 -9 323 minecraft:blue_terracotta
setblock 172 -12 363 minecraft:blue_terracotta
setblock 176 -12 323 minecraft:dark_prismarine
fill 176 -12 324 176 -9 324 minecraft:blue_terracotta
setblock 176 -12 363 minecraft:dark_prismarine
fill 177 -12 323 177 -9 323 minecraft:blue_terracotta
fill 177 -12 363 177 -9 363 minecraft:blue_terracotta
setblock 180 -12 324 minecraft:dark_prismarine
setblock 181 -12 323 minecraft:dark_prismarine
fill 181 -12 324 181 -9 324 minecraft:blue_terracotta
setblock 181 -12 327 minecraft:blue_terracotta
fill 181 -12 345 181 -12 347 minecraft:blue_terracotta
setblock 181 -12 348 minecraft:dark_prismarine
fill 181 -12 349 181 -11 351 minecraft:blue_terracotta
setblock 181 -12 363 minecraft:dark_prismarine
fill 182 -12 323 182 -9 323 minecraft:blue_terracotta
setblock 182 -12 327 minecraft:dark_prismarine
fill 182 -12 328 182 -9 328 minecraft:blue_terracotta
fill 182 -12 330 182 -11 330 minecraft:blue_terracotta
setblock 182 -12 341 minecraft:blue_terracotta
setblock 182 -12 342 minecraft:dark_prismarine
fill 182 -12 343 182 -9 343 minecraft:blue_terracotta
setblock 182 -12 347 minecraft:dark_prismarine
fill 182 -12 348 182 -9 348 minecraft:blue_terracotta
setblock 182 -12 351 minecraft:blue_terracotta
setblock 182 -12 352 minecraft:dark_prismarine
fill 182 -12 353 182 -9 353 minecraft:blue_terracotta
setblock 182 -12 357 minecraft:dark_prismarine
fill 182 -12 358 182 -9 358 minecraft:blue_terracotta
setblock 182 -12 362 minecraft:dark_prismarine
fill 182 -12 363 182 -9 363 minecraft:blue_terracotta
setblock 142 -11 326 minecraft:dark_prismarine
fill 142 -11 327 143 -9 327 minecraft:blue_terracotta
setblock 142 -11 330 minecraft:blue_terracotta
setblock 142 -11 331 minecraft:dark_prismarine
fill 142 -11 338 142 -9 338 minecraft:blue_terracotta
setblock 142 -11 341 minecraft:dark_prismarine
fill 142 -11 342 142 -8 342 minecraft:blue_terracotta
setblock 142 -11 346 minecraft:dark_prismarine
fill 142 -11 347 142 -8 347 minecraft:blue_terracotta
setblock 142 -11 351 minecraft:dark_prismarine
fill 142 -11 352 142 -11 355 minecraft:blue_terracotta
setblock 142 -11 356 minecraft:dark_prismarine
fill 142 -11 357 143 -9 357 minecraft:blue_terracotta
setblock 142 -11 361 minecraft:dark_prismarine
fill 142 -11 362 142 -8 362 minecraft:blue_terracotta
setblock 143 -11 325 minecraft:dark_prismarine
fill 143 -11 326 143 -8 326 minecraft:blue_terracotta
fill 143 -11 328 143 -10 328 minecraft:blue_terracotta
setblock 143 -11 340 minecraft:dark_prismarine
fill 143 -11 341 143 -8 341 minecraft:blue_terracotta
setblock 143 -11 345 minecraft:dark_prismarine
fill 143 -11 346 143 -8 346 minecraft:blue_terracotta
setblock 143 -11 350 minecraft:dark_prismarine
fill 143 -11 351 143 -8 351 minecraft:blue_terracotta
setblock 143 -11 355 minecraft:dark_prismarine
fill 143 -11 356 143 -8 356 minecraft:blue_terracotta
setblock 144 -11 324 minecraft:dark_prismarine
setblock 144 -11 325 minecraft:light[level=13]
setblock 144 -11 333 minecraft:light[level=13]
setblock 144 -11 341 minecraft:light[level=13]
setblock 144 -11 344 minecraft:dark_prismarine
fill 144 -11 345 144 -8 345 minecraft:blue_terracotta
setblock 144 -11 349 minecraft:dark_prismarine
fill 144 -11 350 145 -9 350 minecraft:blue_terracotta
setblock 144 -11 353 minecraft:blue_terracotta
setblock 144 -11 357 minecraft:light[level=13]
setblock 145 -11 323 minecraft:dark_prismarine
fill 145 -11 324 145 -8 324 minecraft:blue_terracotta
setblock 145 -11 348 minecraft:dark_prismarine
fill 145 -11 349 145 -8 349 minecraft:blue_terracotta
setblock 145 -11 363 minecraft:dark_prismarine
fill 146 -11 323 146 -8 323 minecraft:blue_terracotta
fill 146 -11 363 146 -10 363 minecraft:blue_terracotta
setblock 152 -11 325 minecraft:light[level=13]
setblock 152 -11 333 minecraft:light[level=13]
setblock 152 -11 341 minecraft:light[level=13]
setblock 152 -11 349 minecraft:light[level=13]
setblock 152 -11 357 minecraft:light[level=13]
fill 155 -11 364 156 21 364 minecraft:black_concrete
fill 157 -11 325 159 -4 325 minecraft:magenta_terracotta
setblock 157 -11 364 minecraft:light_blue_wool
setblock 158 -11 324 minecraft:blue_terracotta
setblock 159 -11 324 minecraft:dark_prismarine
setblock 160 -11 323 minecraft:dark_prismarine
fill 160 -11 324 160 -9 325 minecraft:blue_terracotta
setblock 160 -11 333 minecraft:light[level=13]
setblock 160 -11 341 minecraft:light[level=13]
setblock 160 -11 349 minecraft:light[level=13]
setblock 160 -11 357 minecraft:light[level=13]
fill 161 -11 323 161 -8 323 minecraft:blue_terracotta
fill 161 -11 363 161 -8 363 minecraft:blue_terracotta
setblock 162 -11 326 minecraft:dark_prismarine
setblock 163 -11 325 minecraft:dark_prismarine
fill 163 -11 326 163 -8 326 minecraft:blue_terracotta
setblock 164 -11 324 minecraft:dark_prismarine
fill 164 -11 325 164 -8 325 minecraft:blue_terracotta
setblock 165 -11 323 minecraft:dark_prismarine
fill 165 -11 324 165 -8 324 minecraft:blue_terracotta
setblock 165 -11 363 minecraft:dark_prismarine
fill 166 -11 323 169 -11 323 minecraft:blue_terracotta
fill 166 -11 363 166 -8 363 minecraft:blue_terracotta
setblock 167 -11 326 minecraft:dark_prismarine
setblock 168 -11 325 minecraft:dark_prismarine
setblock 168 -11 333 minecraft:light[level=13]
setblock 168 -11 341 minecraft:light[level=13]
setblock 168 -11 349 minecraft:light[level=13]
setblock 168 -11 357 minecraft:light[level=13]
setblock 169 -11 324 minecraft:dark_prismarine
fill 169 -11 325 169 -8 325 minecraft:blue_terracotta
setblock 170 -11 323 minecraft:dark_prismarine
fill 170 -11 324 170 -8 324 minecraft:blue_terracotta
setblock 170 -11 363 minecraft:dark_prismarine
fill 171 -11 323 171 -8 323 minecraft:blue_terracotta
fill 171 -11 334 171 -7 334 minecraft:magenta_terracotta
setblock 171 -11 363 minecraft:blue_terracotta
fill 173 -11 332 174 -8 332 minecraft:magenta_terracotta
setblock 174 -11 324 minecraft:dark_prismarine
setblock 175 -11 323 minecraft:dark_prismarine
fill 175 -11 324 175 -8 324 minecraft:blue_terracotta
setblock 175 -11 363 minecraft:dark_prismarine
fill 176 -11 323 176 -8 323 minecraft:blue_terracotta
setblock 176 -11 325 minecraft:light[level=13]
setblock 176 -11 333 minecraft:light[level=13]
setblock 176 -11 341 minecraft:light[level=13]
setblock 176 -11 357 minecraft:light[level=13]
fill 176 -11 363 176 -8 363 minecraft:blue_terracotta
setblock 179 -11 324 minecraft:dark_prismarine
setblock 180 -11 323 minecraft:dark_prismarine
fill 180 -11 324 180 -8 324 minecraft:blue_terracotta
setblock 180 -11 363 minecraft:dark_prismarine
fill 181 -11 323 181 -8 323 minecraft:blue_terracotta
setblock 181 -11 327 minecraft:dark_prismarine
fill 181 -11 328 181 -8 328 minecraft:blue_terracotta
fill 181 -11 345 181 -11 346 minecraft:blue_terracotta
setblock 181 -11 347 minecraft:dark_prismarine
fill 181 -11 348 181 -8 348 minecraft:blue_terracotta
setblock 181 -11 352 minecraft:dark_prismarine
fill 181 -11 353 181 -9 354 minecraft:blue_terracotta
fill 181 -11 360 181 -10 360 minecraft:blue_terracotta
setblock 181 -11 362 minecraft:dark_prismarine
fill 181 -11 363 181 -8 363 minecraft:blue_terracotta
setblock 182 -11 326 minecraft:dark_prismarine
fill 182 -11 327 182 -8 327 minecraft:blue_terracotta
setblock 182 -11 331 minecraft:dark_prismarine
setblock 182 -11 341 minecraft:dark_prismarine
fill 182 -11 342 182 -8 342 minecraft:blue_terracotta
setblock 182 -11 346 minecraft:dark_prismarine
fill 182 -11 347 182 -8 347 minecraft:blue_terracotta
setblock 182 -11 351 minecraft:dark_prismarine
fill 182 -11 352 182 -8 352 minecraft:blue_terracotta
setblock 182 -11 356 minecraft:dark_prismarine
fill 182 -11 357 182 -8 357 minecraft:blue_terracotta
setblock 182 -11 361 minecraft:dark_prismarine
fill 182 -11 362 182 -8 362 minecraft:blue_terracotta
setblock 142 -10 325 minecraft:dark_prismarine
fill 142 -10 326 142 -7 326 minecraft:blue_terracotta
setblock 142 -10 330 minecraft:dark_prismarine
fill 142 -10 331 142 -10 334 minecraft:blue_terracotta
setblock 142 -10 335 minecraft:dark_prismarine
fill 142 -10 336 142 -8 337 minecraft:blue_terracotta
setblock 142 -10 340 minecraft:dark_prismarine
fill 142 -10 341 142 -7 341 minecraft:blue_terracotta
setblock 142 -10 345 minecraft:dark_prismarine
fill 142 -10 346 142 -7 346 minecraft:blue_terracotta
setblock 142 -10 350 minecraft:dark_prismarine
fill 142 -10 351 142 -10 354 minecraft:blue_terracotta
setblock 142 -10 355 minecraft:dark_prismarine
fill 142 -10 356 142 -7 356 minecraft:blue_terracotta
setblock 142 -10 360 minecraft:dark_prismarine
fill 142 -10 361 142 -7 361 minecraft:blue_terracotta
setblock 143 -10 324 minecraft:dark_prismarine
fill 143 -10 325 143 -7 325 minecraft:blue_terracotta
setblock 143 -10 329 minecraft:dark_prismarine
fill 143 -10 330 143 -7 330 minecraft:blue_terracotta
fill 143 -10 340 143 -7 340 minecraft:blue_terracotta
setblock 143 -10 344 minecraft:dark_prismarine
fill 143 -10 345 143 -7 345 minecraft:blue_terracotta
setblock 143 -10 349 minecraft:dark_prismarine
fill 143 -10 350 143 -7 350 minecraft:blue_terracotta
setblock 143 -10 354 minecraft:dark_prismarine
fill 143 -10 355 143 -7 355 minecraft:blue_terracotta
setblock 143 -10 358 minecraft:blue_terracotta
setblock 144 -10 323 minecraft:dark_prismarine
fill 144 -10 324 144 -7 324 minecraft:blue_terracotta
setblock 144 -10 343 minecraft:dark_prismarine
fill 144 -10 344 144 -7 344 minecraft:blue_terracotta
setblock 144 -10 348 minecraft:dark_prismarine
fill 144 -10 349 144 -7 349 minecraft:blue_terracotta
setblock 144 -10 353 minecraft:dark_prismarine
fill 144 -10 354 144 -7 354 minecraft:blue_terracotta
setblock 144 -10 363 minecraft:dark_prismarine
fill 145 -10 323 145 -7 323 minecraft:blue_terracotta
setblock 145 -10 347 minecraft:dark_prismarine
fill 145 -10 348 145 -7 348 minecraft:blue_terracotta
setblock 145 -10 351 minecraft:blue_terracotta
fill 145 -10 363 145 -8 363 minecraft:blue_terracotta
fill 146 -10 338 146 -7 338 minecraft:magenta_terracotta
setblock 152 -10 323 minecraft:purple_concrete
setblock 153 -10 363 minecraft:purple_concrete
fill 156 -10 323 156 -8 323 minecraft:blue_terracotta
setblock 157 -10 324 minecraft:blue_terracotta
fill 157 -10 364 157 10 364 minecraft:black_concrete
setblock 158 -10 324 minecraft:dark_prismarine
setblock 159 -10 323 minecraft:dark_prismarine
fill 159 -10 324 159 -7 324 minecraft:blue_terracotta
fill 160 -10 323 160 -7 323 minecraft:blue_terracotta
setblock 161 -10 326 minecraft:dark_prismarine
setblock 162 -10 325 minecraft:dark_prismarine
fill 162 -10 326 162 -7 326 minecraft:blue_terracotta
setblock 163 -10 324 minecraft:dark_prismarine
fill 163 -10 325 163 -7 325 minecraft:blue_terracotta
setblock 164 -10 323 minecraft:dark_prismarine
fill 164 -10 324 164 -7 324 minecraft:blue_terracotta
setblock 164 -10 363 minecraft:dark_prismarine
fill 165 -10 323 168 -10 323 minecraft:blue_terracotta
setblock 165 -10 326 minecraft:blue_terracotta
fill 165 -10 363 165 -7 363 minecraft:blue_terracotta
setblock 166 -10 326 minecraft:dark_prismarine
setblock 167 -10 325 minecraft:dark_prismarine
fill 167 -10 326 167 -8 326 minecraft:blue_terracotta
setblock 168 -10 324 minecraft:dark_prismarine
fill 168 -10 325 168 -7 325 minecraft:blue_terracotta
setblock 169 -10 323 minecraft:dark_prismarine
fill 169 -10 324 169 -7 324 minecraft:blue_terracotta
setblock 169 -10 363 minecraft:dark_prismarine
fill 170 -10 323 170 -7 323 minecraft:blue_terracotta
fill 170 -10 363 170 -7 363 minecraft:blue_terracotta
setblock 172 -10 363 minecraft:purple_concrete
setblock 173 -10 324 minecraft:dark_prismarine
setblock 174 -10 323 minecraft:dark_prismarine
fill 174 -10 324 174 -7 324 minecraft:blue_terracotta
setblock 174 -10 363 minecraft:dark_prismarine
fill 175 -10 323 175 -7 323 minecraft:blue_terracotta
fill 175 -10 363 175 -7 363 minecraft:blue_terracotta
fill 177 -10 348 178 -8 348 minecraft:magenta_terracotta
setblock 178 -10 324 minecraft:dark_prismarine
setblock 179 -10 323 minecraft:dark_prismarine
fill 179 -10 324 179 -7 324 minecraft:blue_terracotta
setblock 179 -10 362 minecraft:blue_terracotta
setblock 179 -10 363 minecraft:dark_prismarine
fill 180 -10 323 180 -7 323 minecraft:blue_terracotta
fill 180 -10 325 180 -9 325 minecraft:blue_terracotta
setblock 180 -10 362 minecraft:dark_prismarine
fill 180 -10 363 180 -7 363 minecraft:blue_terracotta
setblock 181 -10 326 minecraft:dark_prismarine
fill 181 -10 327 181 -7 327 minecraft:blue_terracotta
fill 181 -10 329 181 -9 329 minecraft:blue_terracotta
fill 181 -10 344 181 -10 345 minecraft:blue_terracotta
setblock 181 -10 346 minecraft:dark_prismarine
fill 181 -10 347 181 -7 347 minecraft:blue_terracotta
fill 181 -10 349 181 -10 350 minecraft:blue_terracotta
setblock 181 -10 351 minecraft:dark_prismarine
fill 181 -10 352 181 -7 352 minecraft:blue_terracotta
setblock 181 -10 355 minecraft:blue_terracotta
setblock 181 -10 356 minecraft:dark_prismarine
fill 181 -10 357 181 -9 359 minecraft:blue_terracotta
setblock 181 -10 361 minecraft:dark_prismarine
fill 181 -10 362 181 -7 362 minecraft:blue_terracotta
setblock 182 -10 325 minecraft:dark_prismarine
fill 182 -10 326 182 -7 326 minecraft:blue_terracotta
setblock 182 -10 330 minecraft:dark_prismarine
fill 182 -10 331 182 -8 332 minecraft:blue_terracotta
setblock 182 -10 337 minecraft:purple_concrete
fill 182 -10 341 182 -7 341 minecraft:blue_terracotta
setblock 182 -10 345 minecraft:dark_prismarine
fill 182 -10 346 182 -7 346 minecraft:blue_terracotta
setblock 182 -10 350 minecraft:dark_prismarine
fill 182 -10 351 182 -7 351 minecraft:blue_terracotta
setblock 182 -10 355 minecraft:dark_prismarine
fill 182 -10 356 182 -7 356 minecraft:blue_terracotta
setblock 182 -10 360 minecraft:dark_prismarine
fill 182 -10 361 182 -7 361 minecraft:blue_terracotta
fill 183 -10 352 183 42 352 minecraft:black_concrete
setblock 183 -10 353 minecraft:cyan_concrete
setblock 142 -9 324 minecraft:dark_prismarine
fill 142 -9 325 142 -6 325 minecraft:blue_terracotta
setblock 142 -9 328 minecraft:blue_terracotta
setblock 142 -9 329 minecraft:dark_prismarine
fill 142 -9 330 142 -9 333 minecraft:blue_terracotta
setblock 142 -9 334 minecraft:dark_prismarine
fill 142 -9 335 142 -6 335 minecraft:blue_terracotta
setblock 142 -9 339 minecraft:dark_prismarine
fill 142 -9 340 142 -6 340 minecraft:blue_terracotta
setblock 142 -9 344 minecraft:dark_prismarine
fill 142 -9 345 142 -6 345 minecraft:blue_terracotta
setblock 142 -9 349 minecraft:dark_prismarine
fill 142 -9 350 142 -9 353 minecraft:blue_terracotta
setblock 142 -9 354 minecraft:dark_prismarine
fill 142 -9 355 142 -6 355 minecraft:blue_terracotta
setblock 142 -9 359 minecraft:dark_prismarine
fill 142 -9 360 142 -6 360 minecraft:blue_terracotta
setblock 143 -9 323 minecraft:dark_prismarine
fill 143 -9 324 143 -6 324 minecraft:blue_terracotta
setblock 143 -9 328 minecraft:dark_prismarine
fill 143 -9 329 143 -6 329 minecraft:blue_terracotta
fill 143 -9 331 143 -9 332 minecraft:blue_terracotta
setblock 143 -9 333 minecraft:dark_prismarine
fill 143 -9 339 143 -6 339 minecraft:blue_terracotta
setblock 143 -9 343 minecraft:dark_prismarine
fill 143 -9 344 143 -6 344 minecraft:blue_terracotta
setblock 143 -9 348 minecraft:dark_prismarine
fill 143 -9 349 143 -6 349 minecraft:blue_terracotta
setblock 143 -9 352 minecraft:blue_terracotta
setblock 143 -9 353 minecraft:dark_prismarine
fill 143 -9 354 143 -6 354 minecraft:blue_terracotta
setblock 143 -9 358 minecraft:dark_prismarine
setblock 143 -9 363 minecraft:dark_prismarine
fill 144 -9 323 144 -6 323 minecraft:blue_terracotta
setblock 144 -9 342 minecraft:dark_prismarine
fill 144 -9 343 144 -6 343 minecraft:blue_terracotta
setblock 144 -9 347 minecraft:dark_prismarine
fill 144 -9 348 144 -6 348 minecraft:blue_terracotta
setblock 144 -9 352 minecraft:dark_prismarine
fill 144 -9 353 144 -6 353 minecraft:blue_terracotta
fill 144 -9 355 144 -8 355 minecraft:blue_terracotta
fill 144 -9 363 144 -6 363 minecraft:blue_terracotta
setblock 145 -9 346 minecraft:dark_prismarine
fill 145 -9 347 145 -6 347 minecraft:blue_terracotta
setblock 145 -9 351 minecraft:dark_prismarine
fill 150 -9 353 151 4 353 minecraft:magenta_terracotta
fill 155 -9 323 155 -7 323 minecraft:blue_terracotta
setblock 157 -9 324 minecraft:dark_prismarine
setblock 158 -9 323 minecraft:dark_prismarine
fill 158 -9 324 158 -6 324 minecraft:blue_terracotta
fill 159 -9 323 159 -6 323 minecraft:blue_terracotta
fill 159 -9 329 159 33 329 minecraft:magenta_terracotta
setblock 159 -9 363 minecraft:purple_concrete
setblock 160 -9 326 minecraft:dark_prismarine
fill 160 -9 363 160 -7 363 minecraft:blue_terracotta
setblock 161 -9 324 minecraft:blue_terracotta
setblock 161 -9 325 minecraft:dark_prismarine
fill 161 -9 326 161 -6 326 minecraft:blue_terracotta
setblock 162 -9 324 minecraft:dark_prismarine
fill 162 -9 325 162 -6 325 minecraft:blue_terracotta
setblock 163 -9 323 minecraft:dark_prismarine
fill 163 -9 324 163 -6 324 minecraft:blue_terracotta
setblock 163 -9 363 minecraft:dark_prismarine
fill 164 -9 323 167 -9 323 minecraft:blue_terracotta
fill 164 -9 358 164 33 358 minecraft:magenta_terracotta
fill 164 -9 363 164 -6 363 minecraft:blue_terracotta
setblock 165 -9 326 minecraft:dark_prismarine
setblock 166 -9 325 minecraft:dark_prismarine
fill 166 -9 326 166 -7 326 minecraft:blue_terracotta
setblock 167 -9 324 minecraft:dark_prismarine
fill 167 -9 325 167 -6 325 minecraft:blue_terracotta
setblock 168 -9 323 minecraft:dark_prismarine
fill 168 -9 324 168 -6 324 minecraft:blue_terracotta
setblock 168 -9 363 minecraft:dark_prismarine
fill 169 -9 323 169 -6 323 minecraft:blue_terracotta
fill 169 -9 363 169 -6 363 minecraft:blue_terracotta
setblock 172 -9 324 minecraft:dark_prismarine
setblock 173 -9 323 minecraft:dark_prismarine
fill 173 -9 324 173 -6 324 minecraft:blue_terracotta
fill 174 -9 323 174 -6 323 minecraft:blue_terracotta
fill 174 -9 363 174 -6 363 minecraft:blue_terracotta
fill 175 -9 336 175 32 336 minecraft:magenta_terracotta
setblock 177 -9 324 minecraft:dark_prismarine
setblock 178 -9 323 minecraft:dark_prismarine
fill 178 -9 324 178 -6 324 minecraft:blue_terracotta
setblock 178 -9 362 minecraft:blue_terracotta
setblock 178 -9 363 minecraft:dark_prismarine
fill 179 -9 323 179 -6 323 minecraft:blue_terracotta
fill 179 -9 325 179 -8 325 minecraft:blue_terracotta
setblock 179 -9 362 minecraft:dark_prismarine
fill 179 -9 363 179 -6 363 minecraft:blue_terracotta
setblock 180 -9 326 minecraft:dark_prismarine
fill 180 -9 327 180 -6 327 minecraft:blue_terracotta
fill 180 -9 347 180 -7 348 minecraft:blue_terracotta
fill 180 -9 352 180 -8 354 minecraft:blue_terracotta
fill 180 -9 362 180 -6 362 minecraft:blue_terracotta
setblock 181 -9 325 minecraft:dark_prismarine
fill 181 -9 326 181 -6 326 minecraft:blue_terracotta
setblock 181 -9 330 minecraft:dark_prismarine
fill 181 -9 331 181 -6 331 minecraft:blue_terracotta
fill 181 -9 343 181 -9 344 minecraft:blue_terracotta
setblock 181 -9 345 minecraft:dark_prismarine
fill 181 -9 346 181 -6 346 minecraft:blue_terracotta
setblock 181 -9 349 minecraft:blue_terracotta
setblock 181 -9 350 minecraft:dark_prismarine
fill 181 -9 351 181 -6 351 minecraft:blue_terracotta
setblock 181 -9 355 minecraft:dark_prismarine
fill 181 -9 356 181 -6 356 minecraft:blue_terracotta
setblock 181 -9 360 minecraft:dark_prismarine
fill 181 -9 361 181 -6 361 minecraft:blue_terracotta
setblock 182 -9 324 minecraft:dark_prismarine
fill 182 -9 325 182 -6 325 minecraft:blue_terracotta
setblock 182 -9 329 minecraft:dark_prismarine
fill 182 -9 330 182 -6 330 minecraft:blue_terracotta
setblock 182 -9 333 minecraft:blue_terracotta
setblock 182 -9 334 minecraft:dark_prismarine
fill 182 -9 340 182 -6 340 minecraft:blue_terracotta
setblock 182 -9 344 minecraft:dark_prismarine
fill 182 -9 345 182 -6 345 minecraft:blue_terracotta
setblock 182 -9 349 minecraft:dark_prismarine
fill 182 -9 350 182 -6 350 minecraft:blue_terracotta
setblock 182 -9 354 minecraft:dark_prismarine
fill 182 -9 355 182 -6 355 minecraft:blue_terracotta
setblock 182 -9 359 minecraft:dark_prismarine
fill 182 -9 360 182 -6 360 minecraft:blue_terracotta
fill 183 -9 337 183 131 338 minecraft:black_concrete
setblock 183 -9 339 minecraft:cyan_concrete
fill 183 -9 353 183 131 353 minecraft:black_concrete
setblock 183 -9 360 minecraft:light_blue_wool
setblock 142 -8 323 minecraft:dark_prismarine
fill 142 -8 324 142 -5 324 minecraft:blue_terracotta
setblock 142 -8 327 minecraft:blue_terracotta
setblock 142 -8 328 minecraft:dark_prismarine
fill 142 -8 329 142 -8 332 minecraft:blue_terracotta
setblock 142 -8 333 minecraft:dark_prismarine
fill 142 -8 334 143 -6 334 minecraft:blue_terracotta
setblock 142 -8 338 minecraft:dark_prismarine
fill 142 -8 339 142 -5 339 minecraft:blue_terracotta
setblock 142 -8 343 minecraft:dark_prismarine
fill 142 -8 344 142 -5 344 minecraft:blue_terracotta
setblock 142 -8 348 minecraft:dark_prismarine
fill 142 -8 349 142 -8 352 minecraft:blue_terracotta
setblock 142 -8 353 minecraft:dark_prismarine
fill 142 -8 354 142 -5 354 minecraft:blue_terracotta
setblock 142 -8 357 minecraft:blue_terracotta
setblock 142 -8 358 minecraft:dark_prismarine
fill 142 -8 359 143 -6 359 minecraft:blue_terracotta
setblock 142 -8 363 minecraft:dark_prismarine
fill 143 -8 323 143 -5 323 minecraft:blue_terracotta
setblock 143 -8 327 minecraft:dark_prismarine
fill 143 -8 328 143 -5 328 minecraft:blue_terracotta
setblock 143 -8 331 minecraft:blue_terracotta
setblock 143 -8 332 minecraft:dark_prismarine
fill 143 -8 333 143 -5 333 minecraft:blue_terracotta
fill 143 -8 335 143 -8 336 minecraft:blue_terracotta
setblock 143 -8 337 minecraft:dark_prismarine
fill 143 -8 338 143 -5 338 minecraft:blue_terracotta
setblock 143 -8 342 minecraft:dark_prismarine
fill 143 -8 343 143 -5 343 minecraft:blue_terracotta
setblock 143 -8 347 minecraft:dark_prismarine
fill 143 -8 348 143 -5 348 minecraft:blue_terracotta
setblock 143 -8 352 minecraft:dark_prismarine
fill 143 -8 353 143 -5 353 minecraft:blue_terracotta
setblock 143 -8 357 minecraft:dark_prismarine
fill 143 -8 358 143 -5 358 minecraft:blue_terracotta
fill 143 -8 363 143 -5 363 minecraft:blue_terracotta
setblock 144 -8 342 minecraft:blue_terracotta
setblock 144 -8 346 minecraft:dark_prismarine
fill 144 -8 347 144 -5 347 minecraft:blue_terracotta
setblock 144 -8 350 minecraft:blue_terracotta
setblock 144 -8 351 minecraft:dark_prismarine
fill 144 -8 352 145 -6 352 minecraft:blue_terracotta
fill 145 -8 346 145 -7 346 minecraft:blue_terracotta
setblock 145 -8 350 minecraft:dark_prismarine
fill 145 -8 351 145 -5 351 minecraft:blue_terracotta
setblock 147 -8 323 minecraft:dark_prismarine
setblock 156 -8 324 minecraft:dark_prismarine
setblock 157 -8 323 minecraft:dark_prismarine
fill 157 -8 324 157 -5 324 minecraft:blue_terracotta
fill 158 -8 323 158 -5 323 minecraft:blue_terracotta
fill 159 -8 363 159 -6 363 minecraft:blue_terracotta
setblock 160 -8 324 minecraft:blue_terracotta
setblock 160 -8 325 minecraft:dark_prismarine
fill 160 -8 326 160 -7 326 minecraft:magenta_terracotta
setblock 161 -8 324 minecraft:dark_prismarine
fill 161 -8 325 161 -5 325 minecraft:blue_terracotta
fill 161 -8 327 162 -8 327 minecraft:blue_terracotta
setblock 162 -8 323 minecraft:dark_prismarine
fill 162 -8 324 162 -5 324 minecraft:blue_terracotta
setblock 162 -8 363 minecraft:dark_prismarine
fill 163 -8 323 166 -8 323 minecraft:blue_terracotta
setblock 163 -8 327 minecraft:dark_prismarine
fill 163 -8 363 163 -5 363 minecraft:blue_terracotta
setblock 164 -8 326 minecraft:dark_prismarine
setblock 164 -8 327 minecraft:blue_terracotta
setblock 165 -8 325 minecraft:dark_prismarine
fill 165 -8 326 165 -6 326 minecraft:blue_terracotta
setblock 166 -8 324 minecraft:dark_prismarine
fill 166 -8 325 166 -5 325 minecraft:blue_terracotta
setblock 167 -8 323 minecraft:dark_prismarine
fill 167 -8 324 167 -5 324 minecraft:blue_terracotta
setblock 167 -8 363 minecraft:dark_prismarine
fill 168 -8 323 168 -5 323 minecraft:blue_terracotta
fill 168 -8 363 168 -6 363 minecraft:blue_terracotta
setblock 171 -8 324 minecraft:dark_prismarine
setblock 172 -8 323 minecraft:dark_prismarine
fill 172 -8 324 172 -7 324 minecraft:blue_terracotta
fill 173 -8 323 173 -5 323 minecraft:blue_terracotta
fill 173 -8 363 173 -5 363 minecraft:blue_terracotta
setblock 176 -8 324 minecraft:dark_prismarine
setblock 177 -8 323 minecraft:dark_prismarine
fill 177 -8 324 177 -5 324 minecraft:blue_terracotta
setblock 177 -8 363 minecraft:dark_prismarine
fill 178 -8 323 178 -5 323 minecraft:blue_terracotta
fill 178 -8 325 178 -7 325 minecraft:blue_terracotta
setblock 178 -8 362 minecraft:dark_prismarine
fill 178 -8 363 178 -5 363 minecraft:blue_terracotta
fill 179 -8 362 179 -5 362 minecraft:blue_terracotta
setblock 180 -8 325 minecraft:dark_prismarine
fill 180 -8 326 180 -5 326 minecraft:blue_terracotta
fill 180 -8 328 180 -8 329 minecraft:blue_terracotta
fill 180 -8 346 180 -5 346 minecraft:blue_terracotta
setblock 180 -8 355 minecraft:dark_prismarine
fill 180 -8 356 180 -6 357 minecraft:blue_terracotta
setblock 181 -8 324 minecraft:dark_prismarine
fill 181 -8 325 181 -5 325 minecraft:blue_terracotta
setblock 181 -8 329 minecraft:dark_prismarine
fill 181 -8 330 181 -5 330 minecraft:blue_terracotta
fill 181 -8 332 181 -7 332 minecraft:blue_terracotta
setblock 181 -8 343 minecraft:blue_terracotta
setblock 181 -8 344 minecraft:dark_prismarine
fill 181 -8 345 181 -5 345 minecraft:blue_terracotta
setblock 181 -8 349 minecraft:dark_prismarine
fill 181 -8 350 181 -5 350 minecraft:blue_terracotta
setblock 181 -8 353 minecraft:blue_terracotta
setblock 181 -8 354 minecraft:dark_prismarine
fill 181 -8 355 181 -5 355 minecraft:blue_terracotta
fill 181 -8 357 181 -8 358 minecraft:blue_terracotta
setblock 181 -8 359 minecraft:dark_prismarine
fill 181 -8 360 181 -5 360 minecraft:blue_terracotta
setblock 182 -8 323 minecraft:dark_prismarine
fill 182 -8 324 182 -5 324 minecraft:blue_terracotta
setblock 182 -8 328 minecraft:dark_prismarine
fill 182 -8 329 182 -5 329 minecraft:blue_terracotta
setblock 182 -8 333 minecraft:dark_prismarine
fill 182 -8 334 182 -8 337 minecraft:blue_terracotta
setblock 182 -8 338 minecraft:dark_prismarine
fill 182 -8 339 182 -5 339 minecraft:blue_terracotta
setblock 182 -8 343 minecraft:dark_prismarine
fill 182 -8 344 182 -5 344 minecraft:blue_terracotta
setblock 182 -8 348 minecraft:dark_prismarine
fill 182 -8 349 182 -5 349 minecraft:blue_terracotta
setblock 182 -8 353 minecraft:dark_prismarine
fill 182 -8 354 182 -5 354 minecraft:blue_terracotta
setblock 182 -8 358 minecraft:dark_prismarine
fill 182 -8 359 182 -5 359 minecraft:blue_terracotta
setblock 182 -8 363 minecraft:dark_prismarine
fill 183 -8 339 183 131 339 minecraft:black_concrete
fill 183 -8 360 183 131 360 minecraft:black_concrete
fill 142 -7 323 142 -4 323 minecraft:blue_terracotta
setblock 142 -7 327 minecraft:dark_prismarine
fill 142 -7 328 142 -7 331 minecraft:blue_terracotta
setblock 142 -7 332 minecraft:dark_prismarine
fill 142 -7 333 142 -4 333 minecraft:blue_terracotta
setblock 142 -7 336 minecraft:blue_terracotta
setblock 142 -7 337 minecraft:dark_prismarine
fill 142 -7 338 142 -4 338 minecraft:blue_terracotta
setblock 142 -7 342 minecraft:dark_prismarine
fill 142 -7 343 142 -4 343 minecraft:blue_terracotta
setblock 142 -7 347 minecraft:dark_prismarine
fill 142 -7 348 142 -7 351 minecraft:blue_terracotta
setblock 142 -7 352 minecraft:dark_prismarine
fill 142 -7 353 142 -4 353 minecraft:blue_terracotta
setblock 142 -7 357 minecraft:dark_prismarine
fill 142 -7 358 142 -4 358 minecraft:blue_terracotta
setblock 142 -7 362 minecraft:dark_prismarine
fill 142 -7 363 142 -4 363 minecraft:blue_terracotta
setblock 143 -7 326 minecraft:dark_prismarine
fill 143 -7 327 143 -4 327 minecraft:blue_terracotta
setblock 143 -7 331 minecraft:dark_prismarine
fill 143 -7 332 143 -4 332 minecraft:blue_terracotta
setblock 143 -7 335 minecraft:blue_terracotta
setblock 143 -7 336 minecraft:dark_prismarine
fill 143 -7 337 143 -4 337 minecraft:blue_terracotta
setblock 143 -7 341 minecraft:dark_prismarine
fill 143 -7 342 143 -4 342 minecraft:blue_terracotta
setblock 143 -7 346 minecraft:dark_prismarine
fill 143 -7 347 143 -4 347 minecraft:blue_terracotta
setblock 143 -7 351 minecraft:dark_prismarine
fill 143 -7 352 143 -4 352 minecraft:blue_terracotta
setblock 143 -7 356 minecraft:dark_prismarine
fill 143 -7 357 143 -4 357 minecraft:blue_terracotta
setblock 144 -7 325 minecraft:light[level=12]
fill 144 -7 328 144 -7 329 minecraft:blue_terracotta
setblock 144 -7 330 minecraft:dark_prismarine
fill 144 -7 331 144 -4 331 minecraft:blue_terracotta
setblock 144 -7 332 minecraft:light[level=12]
setblock 144 -7 339 minecraft:light[level=12]
setblock 144 -7 345 minecraft:dark_prismarine
fill 144 -7 346 144 -4 346 minecraft:blue_terracotta
setblock 144 -7 350 minecraft:dark_prismarine
fill 144 -7 351 144 -4 351 minecraft:blue_terracotta
setblock 144 -7 355 minecraft:dark_prismarine
setblock 144 -7 360 minecraft:light[level=12]
setblock 145 -7 349 minecraft:dark_prismarine
fill 145 -7 350 145 -5 350 minecraft:blue_terracotta
setblock 146 -7 323 minecraft:dark_prismarine
setblock 146 -7 363 minecraft:purple_concrete
fill 148 -7 351 148 -7 352 minecraft:magenta_terracotta
setblock 151 -7 325 minecraft:light[level=12]
setblock 151 -7 332 minecraft:light[level=12]
setblock 151 -7 339 minecraft:light[level=12]
setblock 151 -7 346 minecraft:light[level=12]
setblock 151 -7 360 minecraft:light[level=12]
setblock 153 -7 323 minecraft:purple_concrete
fill 154 -7 323 154 -6 323 minecraft:blue_terracotta
setblock 156 -7 323 minecraft:dark_prismarine
fill 156 -7 324 156 -4 324 minecraft:blue_terracotta
fill 157 -7 323 157 -4 323 minecraft:blue_terracotta
setblock 158 -7 332 minecraft:light[level=12]
setblock 158 -7 339 minecraft:light[level=12]
setblock 158 -7 346 minecraft:light[level=12]
setblock 158 -7 353 minecraft:light[level=12]
setblock 158 -7 360 minecraft:light[level=12]
setblock 160 -7 324 minecraft:dark_prismarine
fill 160 -7 325 160 -4 325 minecraft:blue_terracotta
fill 160 -7 328 160 33 328 minecraft:magenta_terracotta
setblock 161 -7 323 minecraft:dark_prismarine
fill 161 -7 324 161 -4 324 minecraft:blue_terracotta
setblock 161 -7 327 minecraft:blue_terracotta
setblock 161 -7 363 minecraft:dark_prismarine
fill 162 -7 323 165 -7 323 minecraft:blue_terracotta
setblock 162 -7 327 minecraft:dark_prismarine
fill 162 -7 363 162 -4 363 minecraft:blue_terracotta
setblock 163 -7 326 minecraft:dark_prismarine
fill 163 -7 327 163 -6 327 minecraft:blue_terracotta
setblock 164 -7 325 minecraft:dark_prismarine
fill 164 -7 326 164 -5 326 minecraft:blue_terracotta
setblock 165 -7 324 minecraft:dark_prismarine
fill 165 -7 325 165 -4 325 minecraft:blue_terracotta
setblock 165 -7 332 minecraft:light[level=12]
setblock 165 -7 339 minecraft:light[level=12]
setblock 165 -7 346 minecraft:light[level=12]
setblock 165 -7 353 minecraft:light[level=12]
setblock 166 -7 323 minecraft:dark_prismarine
fill 166 -7 324 166 -4 324 minecraft:blue_terracotta
setblock 166 -7 363 minecraft:dark_prismarine
fill 167 -7 322 173 -7 322 minecraft:black_concrete
fill 167 -7 323 167 -4 323 minecraft:blue_terracotta
fill 167 -7 363 167 -5 363 minecraft:blue_terracotta
setblock 170 -7 324 minecraft:dark_prismarine
setblock 171 -7 323 minecraft:dark_prismarine
fill 171 -7 324 171 -6 324 minecraft:blue_terracotta
fill 171 -7 329 171 -6 329 minecraft:black_concrete
setblock 171 -7 363 minecraft:purple_concrete
fill 172 -7 323 172 -4 323 minecraft:blue_terracotta
setblock 172 -7 325 minecraft:light[level=12]
setblock 172 -7 332 minecraft:light[level=12]
setblock 172 -7 339 minecraft:light[level=12]
setblock 172 -7 346 minecraft:light[level=12]
setblock 172 -7 353 minecraft:light[level=12]
setblock 172 -7 360 minecraft:light[level=12]
fill 172 -7 363 172 -4 363 minecraft:blue_terracotta
setblock 173 -7 332 minecraft:magenta_terracotta
setblock 174 -7 322 minecraft:cyan_concrete
fill 175 -7 322 177 58 322 minecraft:black_concrete
setblock 175 -7 324 minecraft:dark_prismarine
setblock 176 -7 323 minecraft:dark_prismarine
fill 176 -7 324 176 -4 324 minecraft:blue_terracotta
setblock 176 -7 363 minecraft:dark_prismarine
fill 177 -7 323 177 -4 323 minecraft:blue_terracotta
setblock 177 -7 362 minecraft:dark_prismarine
fill 177 -7 363 177 -4 363 minecraft:blue_terracotta
fill 178 -7 348 178 10 348 minecraft:magenta_terracotta
fill 178 -7 362 178 -4 362 minecraft:blue_terracotta
setblock 179 -7 325 minecraft:dark_prismarine
setblock 179 -7 332 minecraft:light[level=12]
setblock 179 -7 339 minecraft:light[level=12]
setblock 179 -7 346 minecraft:light[level=12]
fill 179 -7 353 180 -7 353 minecraft:blue_terracotta
setblock 179 -7 360 minecraft:light[level=12]
setblock 180 -7 324 minecraft:dark_prismarine
fill 180 -7 325 180 -6 325 minecraft:blue_terracotta
setblock 180 -7 328 minecraft:blue_terracotta
setblock 180 -7 329 minecraft:dark_prismarine
fill 180 -7 330 180 -4 330 minecraft:blue_terracotta
fill 180 -7 352 180 -6 352 minecraft:blue_terracotta
setblock 180 -7 354 minecraft:dark_prismarine
fill 180 -7 355 180 -4 355 minecraft:blue_terracotta
setblock 180 -7 358 minecraft:blue_terracotta
setblock 180 -7 359 minecraft:dark_prismarine
fill 180 -7 360 180 -4 360 minecraft:blue_terracotta
setblock 181 -7 323 minecraft:dark_prismarine
fill 181 -7 324 181 -4 324 minecraft:blue_terracotta
setblock 181 -7 328 minecraft:dark_prismarine
fill 181 -7 329 181 -4 329 minecraft:blue_terracotta
setblock 181 -7 333 minecraft:dark_prismarine
setblock 181 -7 343 minecraft:dark_prismarine
fill 181 -7 344 181 -4 344 minecraft:blue_terracotta
setblock 181 -7 348 minecraft:dark_prismarine
fill 181 -7 349 181 -4 349 minecraft:blue_terracotta
setblock 181 -7 353 minecraft:dark_prismarine
fill 181 -7 354 181 -4 354 minecraft:blue_terracotta
setblock 181 -7 357 minecraft:blue_terracotta
setblock 181 -7 358 minecraft:dark_prismarine
fill 181 -7 359 181 -4 359 minecraft:blue_terracotta
setblock 181 -7 363 minecraft:dark_prismarine
fill 182 -7 323 182 -4 323 minecraft:blue_terracotta
setblock 182 -7 327 minecraft:dark_prismarine
fill 182 -7 328 182 -4 328 minecraft:blue_terracotta
setblock 182 -7 331 minecraft:blue_terracotta
setblock 182 -7 332 minecraft:dark_prismarine
fill 182 -7 333 182 -7 336 minecraft:blue_terracotta
setblock 182 -7 337 minecraft:dark_prismarine
fill 182 -7 338 182 -4 338 minecraft:blue_terracotta
setblock 182 -7 342 minecraft:dark_prismarine
fill 182 -7 343 182 -4 343 minecraft:blue_terracotta
setblock 182 -7 347 minecraft:dark_prismarine
fill 182 -7 348 182 -4 348 minecraft:blue_terracotta
setblock 182 -7 352 minecraft:dark_prismarine
fill 182 -7 353 182 -4 353 minecraft:blue_terracotta
setblock 182 -7 357 minecraft:dark_prismarine
fill 182 -7 358 182 -4 358 minecraft:blue_terracotta
setblock 182 -7 362 minecraft:dark_prismarine
fill 182 -7 363 182 -4 363 minecraft:blue_terracotta
setblock 142 -6 326 minecraft:dark_prismarine
fill 142 -6 327 142 -6 330 minecraft:blue_terracotta
setblock 142 -6 331 minecraft:dark_prismarine
fill 142 -6 332 142 -3 332 minecraft:blue_terracotta
setblock 142 -6 336 minecraft:dark_prismarine
fill 142 -6 337 142 -3 337 minecraft:blue_terracotta
setblock 142 -6 341 minecraft:dark_prismarine
fill 142 -6 342 142 -3 342 minecraft:blue_terracotta
setblock 142 -6 346 minecraft:dark_prismarine
fill 142 -6 347 142 -6 350 minecraft:blue_terracotta
setblock 142 -6 351 minecraft:dark_prismarine
fill 142 -6 352 142 -3 352 minecraft:blue_terracotta
setblock 142 -6 356 minecraft:dark_prismarine
fill 142 -6 357 142 -3 357 minecraft:blue_terracotta
setblock 142 -6 361 minecraft:dark_prismarine
fill 142 -6 362 142 -4 362 minecraft:blue_terracotta
setblock 143 -6 325 minecraft:dark_prismarine
fill 143 -6 326 143 -5 326 minecraft:blue_terracotta
setblock 143 -6 330 minecraft:dark_prismarine
fill 143 -6 331 143 -3 331 minecraft:blue_terracotta
setblock 143 -6 335 minecraft:dark_prismarine
fill 143 -6 336 143 -3 336 minecraft:blue_terracotta
setblock 143 -6 340 minecraft:dark_prismarine
fill 143 -6 341 143 -3 341 minecraft:blue_terracotta
setblock 143 -6 345 minecraft:dark_prismarine
fill 143 -6 346 143 -3 346 minecraft:blue_terracotta
setblock 143 -6 350 minecraft:dark_prismarine
fill 143 -6 351 143 -3 351 minecraft:blue_terracotta
setblock 143 -6 355 minecraft:dark_prismarine
fill 143 -6 356 144 -6 356 minecraft:blue_terracotta
setblock 144 -6 328 minecraft:blue_terracotta
setblock 144 -6 329 minecraft:dark_prismarine
fill 144 -6 330 144 -5 330 minecraft:blue_terracotta
fill 144 -6 332 144 -6 333 minecraft:blue_terracotta
setblock 144 -6 344 minecraft:dark_prismarine
fill 144 -6 345 144 -5 345 minecraft:blue_terracotta
setblock 144 -6 349 minecraft:dark_prismarine
fill 144 -6 350 144 -3 350 minecraft:blue_terracotta
setblock 144 -6 354 minecraft:dark_prismarine
fill 144 -6 355 144 -4 355 minecraft:blue_terracotta
setblock 145 -6 323 minecraft:dark_prismarine
setblock 145 -6 348 minecraft:dark_prismarine
setblock 145 -6 349 minecraft:blue_terracotta
setblock 147 -6 323 minecraft:purple_concrete
fill 148 -6 351 148 33 351 minecraft:magenta_terracotta
setblock 152 -6 363 minecraft:purple_concrete
setblock 155 -6 323 minecraft:dark_prismarine
fill 155 -6 324 155 -4 324 minecraft:blue_terracotta
fill 156 -6 323 156 -3 323 minecraft:blue_terracotta
fill 156 -6 325 156 -5 325 minecraft:blue_terracotta
fill 158 -6 363 158 -5 363 minecraft:blue_terracotta
setblock 159 -6 324 minecraft:dark_prismarine
setblock 160 -6 323 minecraft:dark_prismarine
fill 160 -6 324 160 -3 324 minecraft:blue_terracotta
setblock 160 -6 326 minecraft:blue_terracotta
setblock 160 -6 363 minecraft:dark_prismarine
fill 161 -6 323 164 -6 323 minecraft:blue_terracotta
setblock 161 -6 327 minecraft:dark_prismarine
fill 161 -6 363 161 -3 363 minecraft:blue_terracotta
setblock 162 -6 326 minecraft:dark_prismarine
setblock 162 -6 327 minecraft:blue_terracotta
setblock 163 -6 325 minecraft:dark_prismarine
fill 163 -6 326 163 -4 326 minecraft:blue_terracotta
setblock 164 -6 324 minecraft:dark_prismarine
fill 164 -6 325 164 -4 325 minecraft:blue_terracotta
setblock 165 -6 323 minecraft:dark_prismarine
fill 165 -6 324 165 -3 324 minecraft:blue_terracotta
setblock 165 -6 363 minecraft:dark_prismarine
fill 166 -6 323 166 -3 323 minecraft:blue_terracotta
fill 166 -6 361 166 -4 361 minecraft:magenta_terracotta
fill 166 -6 363 166 -4 363 minecraft:blue_terracotta
fill 167 -6 322 169 17 322 minecraft:black_concrete
setblock 169 -6 324 minecraft:dark_prismarine
setblock 170 -6 322 minecraft:light_blue_wool
setblock 170 -6 323 minecraft:dark_prismarine
setblock 170 -6 324 minecraft:blue_terracotta
fill 171 -6 322 174 63 322 minecraft:black_concrete
fill 171 -6 323 171 -4 323 minecraft:blue_terracotta
setblock 174 -6 324 minecraft:dark_prismarine
setblock 175 -6 323 minecraft:dark_prismarine
fill 175 -6 324 175 -5 324 minecraft:blue_terracotta
setblock 175 -6 363 minecraft:dark_prismarine
fill 176 -6 323 176 -3 323 minecraft:blue_terracotta
setblock 176 -6 362 minecraft:dark_prismarine
fill 176 -6 363 176 -3 363 minecraft:blue_terracotta
fill 177 -6 362 177 -3 362 minecraft:blue_terracotta
setblock 178 -6 325 minecraft:dark_prismarine
setblock 179 -6 324 minecraft:dark_prismarine
setblock 179 -6 325 minecraft:blue_terracotta
setblock 179 -6 353 minecraft:blue_terracotta
setblock 179 -6 354 minecraft:dark_prismarine
fill 179 -6 355 179 -4 356 minecraft:blue_terracotta
setblock 180 -6 323 minecraft:dark_prismarine
fill 180 -6 324 180 -4 324 minecraft:blue_terracotta
setblock 180 -6 328 minecraft:dark_prismarine
fill 180 -6 329 180 -4 329 minecraft:blue_terracotta
fill 180 -6 331 180 -5 331 minecraft:blue_terracotta
setblock 180 -6 347 minecraft:blue_terracotta
setblock 180 -6 348 minecraft:dark_prismarine
setblock 180 -6 353 minecraft:dark_prismarine
fill 180 -6 354 180 -3 354 minecraft:blue_terracotta
setblock 180 -6 358 minecraft:dark_prismarine
fill 180 -6 359 180 -3 359 minecraft:blue_terracotta
fill 180 -6 361 180 -5 361 minecraft:blue_terracotta
setblock 180 -6 363 minecraft:dark_prismarine
fill 181 -6 323 181 -3 323 minecraft:blue_terracotta
setblock 181 -6 327 minecraft:dark_prismarine
fill 181 -6 328 181 -3 328 minecraft:blue_terracotta
setblock 181 -6 332 minecraft:dark_prismarine
fill 181 -6 333 182 -5 334 minecraft:blue_terracotta
fill 181 -6 343 181 -5 343 minecraft:blue_terracotta
setblock 181 -6 347 minecraft:dark_prismarine
fill 181 -6 348 181 -3 348 minecraft:blue_terracotta
setblock 181 -6 352 minecraft:dark_prismarine
fill 181 -6 353 181 -3 353 minecraft:blue_terracotta
setblock 181 -6 357 minecraft:dark_prismarine
fill 181 -6 358 181 -3 358 minecraft:blue_terracotta
setblock 181 -6 362 minecraft:dark_prismarine
fill 181 -6 363 181 -3 363 minecraft:blue_terracotta
setblock 182 -6 326 minecraft:dark_prismarine
fill 182 -6 327 182 -3 327 minecraft:blue_terracotta
setblock 182 -6 331 minecraft:dark_prismarine
fill 182 -6 332 182 -3 332 minecraft:blue_terracotta
setblock 182 -6 335 minecraft:blue_terracotta
setblock 182 -6 336 minecraft:dark_prismarine
fill 182 -6 337 182 -3 337 minecraft:blue_terracotta
setblock 182 -6 341 minecraft:dark_prismarine
fill 182 -6 342 182 -3 342 minecraft:blue_terracotta
setblock 182 -6 346 minecraft:dark_prismarine
fill 182 -6 347 182 -3 347 minecraft:blue_terracotta
setblock 182 -6 351 minecraft:dark_prismarine
fill 182 -6 352 182 -3 352 minecraft:blue_terracotta
setblock 182 -6 356 minecraft:dark_prismarine
fill 182 -6 357 182 -3 357 minecraft:blue_terracotta
setblock 182 -6 361 minecraft:dark_prismarine
fill 182 -6 362 182 -3 362 minecraft:blue_terracotta
fill 141 -5 326 141 1 343 minecraft:black_concrete
setblock 141 -5 344 minecraft:light_blue_wool
fill 141 -5 345 141 89 347 minecraft:black_concrete
setblock 142 -5 325 minecraft:dark_prismarine
fill 142 -5 326 142 -5 329 minecraft:blue_terracotta
setblock 142 -5 330 minecraft:dark_prismarine
fill 142 -5 331 142 -2 331 minecraft:blue_terracotta
setblock 142 -5 334 minecraft:blue_terracotta
setblock 142 -5 335 minecraft:dark_prismarine
fill 142 -5 336 142 -2 336 minecraft:blue_terracotta
setblock 142 -5 340 minecraft:dark_prismarine
fill 142 -5 341 142 -2 341 minecraft:blue_terracotta
setblock 142 -5 345 minecraft:dark_prismarine
fill 142 -5 346 142 -5 349 minecraft:blue_terracotta
setblock 142 -5 350 minecraft:dark_prismarine
fill 142 -5 351 142 -2 351 minecraft:blue_terracotta
setblock 142 -5 355 minecraft:dark_prismarine
fill 142 -5 356 143 -3 356 minecraft:blue_terracotta
setblock 142 -5 359 minecraft:blue_terracotta
setblock 142 -5 360 minecraft:dark_prismarine
fill 142 -5 361 142 -3 361 minecraft:blue_terracotta
setblock 143 -5 325 minecraft:blue_terracotta
setblock 143 -5 329 minecraft:dark_prismarine
fill 143 -5 330 143 -2 330 minecraft:blue_terracotta
setblock 143 -5 334 minecraft:dark_prismarine
fill 143 -5 335 143 -2 335 minecraft:blue_terracotta
setblock 143 -5 339 minecraft:dark_prismarine
fill 143 -5 340 143 -3 340 minecraft:blue_terracotta
setblock 143 -5 344 minecraft:dark_prismarine
fill 143 -5 345 143 -3 345 minecraft:blue_terracotta
setblock 143 -5 349 minecraft:dark_prismarine
fill 143 -5 350 143 -2 350 minecraft:blue_terracotta
setblock 143 -5 354 minecraft:dark_prismarine
fill 143 -5 355 143 -2 355 minecraft:blue_terracotta
setblock 143 -5 359 minecraft:dark_prismarine
setblock 144 -5 323 minecraft:dark_prismarine
setblock 144 -5 329 minecraft:blue_terracotta
setblock 144 -5 332 minecraft:blue_terracotta
setblock 144 -5 333 minecraft:dark_prismarine
fill 144 -5 334 144 -4 334 minecraft:blue_terracotta
setblock 144 -5 344 minecraft:blue_terracotta
setblock 144 -5 348 minecraft:dark_prismarine
fill 144 -5 349 144 -3 349 minecraft:blue_terracotta
setblock 144 -5 352 minecraft:blue_terracotta
setblock 144 -5 353 minecraft:dark_prismarine
fill 144 -5 354 144 -3 354 minecraft:blue_terracotta
fill 148 -5 352 148 31 352 minecraft:magenta_terracotta
fill 149 -5 328 149 8 328 minecraft:green_terracotta
fill 150 -5 349 150 33 349 minecraft:magenta_terracotta
setblock 154 -5 323 minecraft:dark_prismarine
fill 155 -5 323 155 -2 323 minecraft:blue_terracotta
setblock 158 -5 324 minecraft:dark_prismarine
setblock 159 -5 323 minecraft:dark_prismarine
fill 159 -5 324 159 -2 324 minecraft:blue_terracotta
setblock 159 -5 363 minecraft:dark_prismarine
fill 160 -5 323 163 -5 323 minecraft:blue_terracotta
fill 160 -5 326 160 14 326 minecraft:magenta_terracotta
fill 160 -5 363 160 -2 363 minecraft:blue_terracotta
setblock 161 -5 326 minecraft:dark_prismarine
setblock 161 -5 327 minecraft:blue_terracotta
setblock 162 -5 325 minecraft:dark_prismarine
fill 162 -5 326 162 -4 326 minecraft:blue_terracotta
setblock 163 -5 324 minecraft:dark_prismarine
fill 163 -5 325 163 -3 325 minecraft:blue_terracotta
setblock 164 -5 323 minecraft:dark_prismarine
fill 164 -5 324 164 -3 324 minecraft:blue_terracotta
setblock 164 -5 363 minecraft:dark_prismarine
fill 165 -5 323 165 -2 323 minecraft:blue_terracotta
fill 165 -5 363 165 -3 363 minecraft:blue_terracotta
setblock 168 -5 324 minecraft:dark_prismarine
setblock 169 -5 323 minecraft:dark_prismarine
setblock 169 -5 324 minecraft:blue_terracotta
fill 170 -5 322 170 60 322 minecraft:black_concrete
fill 170 -5 323 170 -4 323 minecraft:blue_terracotta
setblock 174 -5 323 minecraft:dark_prismarine
setblock 174 -5 363 minecraft:dark_prismarine
fill 175 -5 323 175 -2 323 minecraft:blue_terracotta
fill 175 -5 363 175 -2 363 minecraft:blue_terracotta
fill 176 -5 362 176 -2 362 minecraft:blue_terracotta
setblock 178 -5 324 minecraft:dark_prismarine
setblock 179 -5 323 minecraft:dark_prismarine
fill 179 -5 324 179 -4 324 minecraft:blue_terracotta
setblock 179 -5 353 minecraft:dark_prismarine
fill 179 -5 354 179 -2 354 minecraft:blue_terracotta
setblock 179 -5 357 minecraft:blue_terracotta
fill 179 -5 361 179 -4 361 minecraft:blue_terracotta
setblock 179 -5 363 minecraft:dark_prismarine
fill 180 -5 323 180 -2 323 minecraft:blue_terracotta
setblock 180 -5 327 minecraft:dark_prismarine
fill 180 -5 328 180 -4 328 minecraft:blue_terracotta
setblock 180 -5 347 minecraft:dark_prismarine
fill 180 -5 348 180 -2 348 minecraft:blue_terracotta
setblock 180 -5 352 minecraft:dark_prismarine
fill 180 -5 353 180 -2 353 minecraft:blue_terracotta
setblock 180 -5 356 minecraft:blue_terracotta
setblock 180 -5 357 minecraft:dark_prismarine
fill 180 -5 358 180 -2 358 minecraft:blue_terracotta
setblock 180 -5 362 minecraft:dark_prismarine
fill 180 -5 363 180 -2 363 minecraft:blue_terracotta
setblock 181 -5 326 minecraft:dark_prismarine
fill 181 -5 327 181 -3 327 minecraft:blue_terracotta
setblock 181 -5 331 minecraft:dark_prismarine
fill 181 -5 332 181 -2 332 minecraft:blue_terracotta
setblock 181 -5 335 minecraft:blue_terracotta
setblock 181 -5 346 minecraft:dark_prismarine
fill 181 -5 347 181 -2 347 minecraft:blue_terracotta
setblock 181 -5 351 minecraft:dark_prismarine
fill 181 -5 352 181 -2 352 minecraft:blue_terracotta
setblock 181 -5 356 minecraft:dark_prismarine
fill 181 -5 357 181 -2 357 minecraft:blue_terracotta
setblock 181 -5 361 minecraft:dark_prismarine
fill 181 -5 362 181 -2 362 minecraft:blue_terracotta
setblock 182 -5 325 minecraft:dark_prismarine
fill 182 -5 326 182 -2 326 minecraft:blue_terracotta
setblock 182 -5 330 minecraft:dark_prismarine
fill 182 -5 331 182 -2 331 minecraft:blue_terracotta
setblock 182 -5 335 minecraft:dark_prismarine
fill 182 -5 336 182 -2 336 minecraft:blue_terracotta
setblock 182 -5 340 minecraft:dark_prismarine
fill 182 -5 341 182 -2 341 minecraft:blue_terracotta
setblock 182 -5 345 minecraft:dark_prismarine
fill 182 -5 346 182 -2 346 minecraft:blue_terracotta
setblock 182 -5 350 minecraft:dark_prismarine
fill 182 -5 351 182 -2 351 minecraft:blue_terracotta
setblock 182 -5 355 minecraft:dark_prismarine
fill 182 -5 356 182 -2 356 minecraft:blue_terracotta
setblock 182 -5 360 minecraft:dark_prismarine
fill 182 -5 361 182 -2 361 minecraft:blue_terracotta
fill 141 -4 344 141 131 344 minecraft:black_concrete
setblock 142 -4 324 minecraft:dark_prismarine
fill 142 -4 325 142 -4 328 minecraft:blue_terracotta
setblock 142 -4 329 minecraft:dark_prismarine
fill 142 -4 330 142 -1 330 minecraft:blue_terracotta
setblock 142 -4 334 minecraft:dark_prismarine
fill 142 -4 335 142 -1 335 minecraft:blue_terracotta
setblock 142 -4 339 minecraft:dark_prismarine
fill 142 -4 340 142 -1 340 minecraft:blue_terracotta
setblock 142 -4 344 minecraft:dark_prismarine
fill 142 -4 345 142 -4 348 minecraft:blue_terracotta
setblock 142 -4 349 minecraft:dark_prismarine
fill 142 -4 350 142 -1 350 minecraft:blue_terracotta
setblock 142 -4 354 minecraft:dark_prismarine
fill 142 -4 355 142 -1 355 minecraft:blue_terracotta
setblock 142 -4 359 minecraft:dark_prismarine
fill 142 -4 360 142 -1 360 minecraft:blue_terracotta
setblock 143 -4 328 minecraft:dark_prismarine
fill 143 -4 329 143 -2 329 minecraft:blue_terracotta
setblock 143 -4 333 minecraft:dark_prismarine
fill 143 -4 334 143 -1 334 minecraft:blue_terracotta
setblock 143 -4 338 minecraft:dark_prismarine
fill 143 -4 339 143 -2 339 minecraft:blue_terracotta
setblock 143 -4 343 minecraft:dark_prismarine
fill 143 -4 344 143 -3 344 minecraft:blue_terracotta
setblock 143 -4 348 minecraft:dark_prismarine
fill 143 -4 349 143 -1 349 minecraft:blue_terracotta
setblock 143 -4 353 minecraft:dark_prismarine
fill 143 -4 354 143 -1 354 minecraft:blue_terracotta
setblock 143 -4 358 minecraft:dark_prismarine
setblock 144 -4 332 minecraft:dark_prismarine
setblock 144 -4 333 minecraft:blue_terracotta
setblock 144 -4 344 minecraft:black_concrete
setblock 144 -4 347 minecraft:dark_prismarine
setblock 144 -4 348 minecraft:blue_terracotta
setblock 144 -4 352 minecraft:dark_prismarine
fill 144 -4 353 144 -3 353 minecraft:blue_terracotta
setblock 145 -4 363 minecraft:purple_concrete
fill 151 -4 349 151 25 349 minecraft:magenta_terracotta
fill 154 -4 323 154 -3 323 minecraft:blue_terracotta
setblock 157 -4 324 minecraft:dark_prismarine
setblock 158 -4 323 minecraft:dark_prismarine
fill 158 -4 324 158 -1 324 minecraft:blue_terracotta
setblock 158 -4 363 minecraft:dark_prismarine
fill 159 -4 323 162 -4 323 minecraft:blue_terracotta
fill 159 -4 363 159 -1 363 minecraft:blue_terracotta
setblock 161 -4 325 minecraft:dark_prismarine
setblock 161 -4 326 minecraft:blue_terracotta
setblock 162 -4 324 minecraft:dark_prismarine
fill 162 -4 325 162 -3 325 minecraft:blue_terracotta
setblock 163 -4 323 minecraft:dark_prismarine
fill 163 -4 324 163 -2 324 minecraft:blue_terracotta
setblock 163 -4 363 minecraft:dark_prismarine
fill 164 -4 323 164 -1 323 minecraft:blue_terracotta
fill 164 -4 363 164 -2 363 minecraft:blue_terracotta
setblock 167 -4 324 minecraft:dark_prismarine
setblock 168 -4 323 minecraft:dark_prismarine
setblock 169 -4 323 minecraft:blue_terracotta
setblock 173 -4 323 minecraft:dark_prismarine
setblock 173 -4 363 minecraft:dark_prismarine
fill 174 -4 323 174 -3 323 minecraft:blue_terracotta
fill 174 -4 363 174 -1 363 minecraft:blue_terracotta
setblock 177 -4 324 minecraft:dark_prismarine
setblock 178 -4 323 minecraft:dark_prismarine
setblock 178 -4 324 minecraft:blue_terracotta
setblock 178 -4 363 minecraft:dark_prismarine
fill 179 -4 323 179 -2 323 minecraft:blue_terracotta
fill 179 -4 353 179 -1 353 minecraft:blue_terracotta
setblock 179 -4 357 minecraft:dark_prismarine
setblock 179 -4 362 minecraft:dark_prismarine
fill 179 -4 363 179 -1 363 minecraft:blue_terracotta
setblock 180 -4 331 minecraft:dark_prismarine
setblock 180 -4 346 minecraft:dark_prismarine
fill 180 -4 347 180 -3 347 minecraft:blue_terracotta
fill 180 -4 352 180 -1 352 minecraft:blue_terracotta
setblock 180 -4 356 minecraft:dark_prismarine
fill 180 -4 357 180 -1 357 minecraft:blue_terracotta
setblock 180 -4 361 minecraft:dark_prismarine
fill 180 -4 362 180 -1 362 minecraft:blue_terracotta
setblock 181 -4 325 minecraft:dark_prismarine
fill 181 -4 326 181 -3 326 minecraft:blue_terracotta
setblock 181 -4 330 minecraft:dark_prismarine
fill 181 -4 331 181 -1 331 minecraft:blue_terracotta
fill 181 -4 333 181 -4 334 minecraft:blue_terracotta
setblock 181 -4 335 minecraft:dark_prismarine
fill 181 -4 336 181 -1 336 minecraft:blue_terracotta
setblock 181 -4 345 minecraft:dark_prismarine
fill 181 -4 346 181 -2 346 minecraft:blue_terracotta
setblock 181 -4 350 minecraft:dark_prismarine
fill 181 -4 351 181 -1 351 minecraft:blue_terracotta
setblock 181 -4 355 minecraft:dark_prismarine
fill 181 -4 356 181 -1 356 minecraft:blue_terracotta
setblock 181 -4 360 minecraft:dark_prismarine
fill 181 -4 361 181 -1 361 minecraft:blue_terracotta
setblock 182 -4 324 minecraft:dark_prismarine
fill 182 -4 325 182 -3 325 minecraft:blue_terracotta
setblock 182 -4 329 minecraft:dark_prismarine
fill 182 -4 330 182 -1 330 minecraft:blue_terracotta
setblock 182 -4 333 minecraft:blue_terracotta
setblock 182 -4 334 minecraft:dark_prismarine
fill 182 -4 335 182 -1 335 minecraft:blue_terracotta
setblock 182 -4 339 minecraft:dark_prismarine
fill 182 -4 340 182 -1 340 minecraft:blue_terracotta
setblock 182 -4 344 minecraft:dark_prismarine
fill 182 -4 345 182 -1 345 minecraft:blue_terracotta
setblock 182 -4 349 minecraft:dark_prismarine
fill 182 -4 350 182 -1 350 minecraft:blue_terracotta
setblock 182 -4 354 minecraft:dark_prismarine
fill 182 -4 355 182 -1 355 minecraft:blue_terracotta
setblock 182 -4 359 minecraft:dark_prismarine
fill 182 -4 360 182 -1 360 minecraft:blue_terracotta
fill 142 -3 325 142 -3 327 minecraft:blue_terracotta
setblock 142 -3 328 minecraft:dark_prismarine
fill 142 -3 329 142 0 329 minecraft:blue_terracotta
setblock 142 -3 333 minecraft:dark_prismarine
fill 142 -3 334 142 0 334 minecraft:blue_terracotta
setblock 142 -3 338 minecraft:dark_prismarine
fill 142 -3 339 142 0 339 minecraft:blue_terracotta
setblock 142 -3 343 minecraft:dark_prismarine
fill 142 -3 344 142 -3 347 minecraft:blue_terracotta
setblock 142 -3 348 minecraft:dark_prismarine
fill 142 -3 349 142 0 349 minecraft:blue_terracotta
setblock 142 -3 353 minecraft:dark_prismarine
fill 142 -3 354 142 0 354 minecraft:blue_terracotta
setblock 142 -3 358 minecraft:dark_prismarine
fill 142 -3 359 142 0 359 minecraft:blue_terracotta
setblock 143 -3 328 minecraft:blue_terracotta
setblock 143 -3 332 minecraft:dark_prismarine
fill 143 -3 333 143 0 333 minecraft:blue_terracotta
setblock 143 -3 337 minecraft:dark_prismarine
fill 143 -3 338 143 0 338 minecraft:blue_terracotta
setblock 143 -3 342 minecraft:dark_prismarine
setblock 143 -3 343 minecraft:blue_terracotta
setblock 143 -3 347 minecraft:dark_prismarine
fill 143 -3 348 143 -1 348 minecraft:blue_terracotta
setblock 143 -3 352 minecraft:dark_prismarine
fill 143 -3 353 143 0 353 minecraft:blue_terracotta
setblock 143 -3 357 minecraft:dark_prismarine
setblock 143 -3 358 minecraft:blue_terracotta
setblock 144 -3 325 minecraft:light[level=13]
setblock 144 -3 333 minecraft:light[level=13]
setblock 144 -3 341 minecraft:light[level=13]
setblock 144 -3 351 minecraft:dark_prismarine
setblock 144 -3 352 minecraft:blue_terracotta
setblock 144 -3 357 minecraft:light[level=13]
setblock 148 -3 323 minecraft:purple_concrete
setblock 151 -3 363 minecraft:purple_concrete
setblock 152 -3 325 minecraft:light[level=13]
setblock 152 -3 333 minecraft:light[level=13]
setblock 152 -3 341 minecraft:light[level=13]
setblock 152 -3 349 minecraft:light[level=13]
setblock 152 -3 357 minecraft:light[level=13]
setblock 156 -3 324 minecraft:dark_prismarine
setblock 157 -3 323 minecraft:dark_prismarine
fill 157 -3 324 157 0 324 minecraft:blue_terracotta
fill 157 -3 325 158 -2 325 minecraft:magenta_terracotta
fill 158 -3 323 161 -3 323 minecraft:blue_terracotta
fill 158 -3 363 158 0 363 minecraft:blue_terracotta
setblock 159 -3 325 minecraft:blue_terracotta
setblock 160 -3 325 minecraft:dark_prismarine
setblock 160 -3 333 minecraft:light[level=13]
setblock 160 -3 341 minecraft:light[level=13]
setblock 160 -3 349 minecraft:light[level=13]
setblock 160 -3 357 minecraft:light[level=13]
setblock 161 -3 324 minecraft:dark_prismarine
fill 161 -3 325 161 -2 325 minecraft:blue_terracotta
setblock 162 -3 323 minecraft:dark_prismarine
fill 162 -3 324 162 -2 324 minecraft:blue_terracotta
setblock 162 -3 363 minecraft:dark_prismarine
fill 163 -3 323 163 0 323 minecraft:blue_terracotta
fill 163 -3 363 163 -1 363 minecraft:blue_terracotta
setblock 167 -3 323 minecraft:dark_prismarine
setblock 168 -3 323 minecraft:blue_terracotta
setblock 168 -3 325 minecraft:light[level=13]
setblock 168 -3 333 minecraft:light[level=13]
setblock 168 -3 341 minecraft:light[level=13]
setblock 168 -3 349 minecraft:light[level=13]
setblock 168 -3 357 minecraft:light[level=13]
setblock 170 -3 363 minecraft:purple_concrete
setblock 172 -3 363 minecraft:dark_prismarine
setblock 173 -3 323 minecraft:blue_terracotta
fill 173 -3 363 173 0 363 minecraft:blue_terracotta
fill 174 -3 337 174 33 337 minecraft:magenta_terracotta
fill 175 -3 362 175 -1 362 minecraft:blue_terracotta
setblock 176 -3 325 minecraft:light[level=13]
setblock 176 -3 333 minecraft:light[level=13]
setblock 176 -3 341 minecraft:light[level=13]
setblock 176 -3 357 minecraft:light[level=13]
setblock 177 -3 323 minecraft:dark_prismarine
setblock 177 -3 363 minecraft:dark_prismarine
fill 178 -3 323 178 -1 323 minecraft:blue_terracotta
setblock 178 -3 361 minecraft:blue_terracotta
setblock 178 -3 362 minecraft:dark_prismarine
fill 178 -3 363 178 0 363 minecraft:blue_terracotta
setblock 179 -3 355 minecraft:blue_terracotta
setblock 179 -3 356 minecraft:dark_prismarine
fill 179 -3 357 179 -1 358 minecraft:blue_terracotta
setblock 179 -3 361 minecraft:dark_prismarine
fill 179 -3 362 179 0 362 minecraft:blue_terracotta
setblock 180 -3 355 minecraft:dark_prismarine
fill 180 -3 356 180 0 356 minecraft:blue_terracotta
setblock 180 -3 360 minecraft:dark_prismarine
setblock 180 -3 361 minecraft:blue_terracotta
setblock 181 -3 329 minecraft:dark_prismarine
fill 181 -3 330 181 -2 330 minecraft:blue_terracotta
setblock 181 -3 333 minecraft:blue_terracotta
setblock 181 -3 334 minecraft:dark_prismarine
fill 181 -3 335 181 0 335 minecraft:blue_terracotta
setblock 181 -3 345 minecraft:blue_terracotta
setblock 181 -3 349 minecraft:dark_prismarine
fill 181 -3 350 181 0 350 minecraft:blue_terracotta
setblock 181 -3 354 minecraft:dark_prismarine
fill 181 -3 355 181 0 355 minecraft:blue_terracotta
setblock 181 -3 359 minecraft:dark_prismarine
fill 181 -3 360 181 0 360 minecraft:blue_terracotta
setblock 182 -3 323 minecraft:dark_prismarine
setblock 182 -3 324 minecraft:blue_terracotta
setblock 182 -3 328 minecraft:dark_prismarine
fill 182 -3 329 182 -1 329 minecraft:blue_terracotta
setblock 182 -3 333 minecraft:dark_prismarine
fill 182 -3 334 182 0 334 minecraft:blue_terracotta
setblock 182 -3 338 minecraft:dark_prismarine
fill 182 -3 339 182 0 339 minecraft:blue_terracotta
setblock 182 -3 343 minecraft:dark_prismarine
fill 182 -3 344 182 -1 344 minecraft:blue_terracotta
setblock 182 -3 348 minecraft:dark_prismarine
fill 182 -3 349 182 0 349 minecraft:blue_terracotta
setblock 182 -3 353 minecraft:dark_prismarine
fill 182 -3 354 182 0 354 minecraft:blue_terracotta
setblock 182 -3 358 minecraft:dark_prismarine
fill 182 -3 359 182 0 359 minecraft:blue_terracotta
setblock 182 -3 363 minecraft:dark_prismarine
setblock 142 -2 326 minecraft:blue_terracotta
setblock 142 -2 327 minecraft:dark_prismarine
fill 142 -2 328 142 -1 328 minecraft:blue_terracotta
setblock 142 -2 332 minecraft:dark_prismarine
fill 142 -2 333 142 1 333 minecraft:blue_terracotta
setblock 142 -2 337 minecraft:dark_prismarine
fill 142 -2 338 142 1 338 minecraft:blue_terracotta
setblock 142 -2 342 minecraft:dark_prismarine
fill 142 -2 343 142 -2 346 minecraft:blue_terracotta
setblock 142 -2 347 minecraft:dark_prismarine
fill 142 -2 348 142 1 348 minecraft:blue_terracotta
setblock 142 -2 352 minecraft:dark_prismarine
fill 142 -2 353 142 1 353 minecraft:blue_terracotta
setblock 142 -2 356 minecraft:blue_terracotta
setblock 142 -2 357 minecraft:dark_prismarine
fill 142 -2 358 142 1 358 minecraft:blue_terracotta
setblock 143 -2 331 minecraft:dark_prismarine
fill 143 -2 332 143 0 332 minecraft:blue_terracotta
setblock 143 -2 336 minecraft:dark_prismarine
fill 143 -2 337 143 1 337 minecraft:blue_terracotta
setblock 143 -2 346 minecraft:dark_prismarine
setblock 143 -2 347 minecraft:blue_terracotta
setblock 143 -2 351 minecraft:dark_prismarine
fill 143 -2 352 143 0 352 minecraft:blue_terracotta
setblock 143 -2 356 minecraft:dark_prismarine
setblock 143 -2 357 minecraft:blue_terracotta
setblock 156 -2 323 minecraft:dark_prismarine
fill 156 -2 324 156 -1 324 minecraft:blue_terracotta
fill 157 -2 323 160 -2 323 minecraft:blue_terracotta
fill 157 -2 363 157 1 363 minecraft:blue_terracotta
setblock 159 -2 325 minecraft:dark_prismarine
setblock 160 -2 324 minecraft:dark_prismarine
setblock 160 -2 325 minecraft:blue_terracotta
setblock 161 -2 323 minecraft:dark_prismarine
fill 161 -2 324 161 -1 324 minecraft:blue_terracotta
setblock 161 -2 363 minecraft:dark_prismarine
fill 162 -2 323 162 1 323 minecraft:blue_terracotta
fill 162 -2 363 162 1 363 minecraft:blue_terracotta
setblock 166 -2 323 minecraft:dark_prismarine
setblock 167 -2 323 minecraft:purple_concrete
fill 172 -2 363 172 1 363 minecraft:blue_terracotta
fill 173 -2 337 173 32 337 minecraft:magenta_terracotta
setblock 176 -2 323 minecraft:dark_prismarine
setblock 176 -2 363 minecraft:dark_prismarine
fill 177 -2 323 177 -1 323 minecraft:blue_terracotta
setblock 177 -2 362 minecraft:dark_prismarine
fill 177 -2 363 177 1 363 minecraft:blue_terracotta
fill 178 -2 362 178 1 362 minecraft:blue_terracotta
setblock 179 -2 355 minecraft:dark_prismarine
fill 179 -2 356 179 1 356 minecraft:blue_terracotta
setblock 180 -2 354 minecraft:dark_prismarine
fill 180 -2 355 180 1 355 minecraft:blue_terracotta
setblock 180 -2 359 minecraft:dark_prismarine
fill 180 -2 360 180 -1 360 minecraft:blue_terracotta
setblock 181 -2 329 minecraft:blue_terracotta
setblock 181 -2 333 minecraft:dark_prismarine
fill 181 -2 334 181 0 334 minecraft:blue_terracotta
setblock 181 -2 348 minecraft:dark_prismarine
fill 181 -2 349 181 1 349 minecraft:blue_terracotta
setblock 181 -2 353 minecraft:dark_prismarine
fill 181 -2 354 181 1 354 minecraft:blue_terracotta
setblock 181 -2 358 minecraft:dark_prismarine
fill 181 -2 359 181 1 359 minecraft:blue_terracotta
setblock 181 -2 363 minecraft:dark_prismarine
setblock 182 -2 327 minecraft:dark_prismarine
fill 182 -2 328 182 -1 328 minecraft:blue_terracotta
setblock 182 -2 332 minecraft:dark_prismarine
fill 182 -2 333 182 1 333 minecraft:blue_terracotta
setblock 182 -2 337 minecraft:dark_prismarine
fill 182 -2 338 182 1 338 minecraft:blue_terracotta
setblock 182 -2 342 minecraft:dark_prismarine
fill 182 -2 343 182 -1 343 minecraft:blue_terracotta
setblock 182 -2 347 minecraft:dark_prismarine
fill 182 -2 348 182 1 348 minecraft:blue_terracotta
setblock 182 -2 352 minecraft:dark_prismarine
fill 182 -2 353 182 1 353 minecraft:blue_terracotta
setblock 182 -2 357 minecraft:dark_prismarine
fill 182 -2 358 182 1 358 minecraft:blue_terracotta
setblock 182 -2 362 minecraft:dark_prismarine
fill 182 -2 363 182 -1 363 minecraft:blue_terracotta
setblock 142 -1 331 minecraft:dark_prismarine
fill 142 -1 332 142 2 332 minecraft:blue_terracotta
setblock 142 -1 336 minecraft:dark_prismarine
fill 142 -1 337 142 2 337 minecraft:blue_terracotta
setblock 142 -1 341 minecraft:dark_prismarine
fill 142 -1 342 142 -1 345 minecraft:blue_terracotta
setblock 142 -1 346 minecraft:dark_prismarine
fill 142 -1 347 142 1 347 minecraft:blue_terracotta
setblock 142 -1 351 minecraft:dark_prismarine
fill 142 -1 352 142 2 352 minecraft:blue_terracotta
setblock 142 -1 356 minecraft:dark_prismarine
fill 142 -1 357 142 2 357 minecraft:blue_terracotta
setblock 143 -1 331 minecraft:blue_terracotta
setblock 143 -1 335 minecraft:dark_prismarine
fill 143 -1 336 143 2 336 minecraft:blue_terracotta
setblock 143 -1 350 minecraft:dark_prismarine
setblock 143 -1 351 minecraft:blue_terracotta
setblock 143 -1 355 minecraft:dark_prismarine
setblock 143 -1 356 minecraft:blue_terracotta
setblock 144 -1 325 minecraft:light[level=12]
setblock 144 -1 332 minecraft:light[level=12]
setblock 144 -1 339 minecraft:light[level=12]
setblock 144 -1 346 minecraft:light[level=12]
setblock 144 -1 353 minecraft:light[level=12]
setblock 144 -1 360 minecraft:light[level=12]
setblock 144 -1 363 minecraft:purple_concrete
setblock 151 -1 325 minecraft:light[level=12]
setblock 151 -1 332 minecraft:light[level=12]
setblock 151 -1 339 minecraft:light[level=12]
setblock 151 -1 346 minecraft:light[level=12]
setblock 151 -1 360 minecraft:light[level=12]
setblock 155 -1 323 minecraft:dark_prismarine
fill 156 -1 323 159 -1 323 minecraft:blue_terracotta
fill 158 -1 325 158 2 325 minecraft:magenta_terracotta
setblock 158 -1 332 minecraft:light[level=12]
setblock 158 -1 339 minecraft:light[level=12]
setblock 158 -1 346 minecraft:light[level=12]
setblock 158 -1 353 minecraft:light[level=12]
setblock 158 -1 360 minecraft:light[level=12]
setblock 158 -1 364 minecraft:light_blue_wool
setblock 159 -1 324 minecraft:dark_prismarine
setblock 160 -1 323 minecraft:dark_prismarine
fill 160 -1 324 160 0 324 minecraft:blue_terracotta
setblock 160 -1 363 minecraft:dark_prismarine
fill 161 -1 323 161 2 323 minecraft:blue_terracotta
fill 161 -1 363 161 2 363 minecraft:blue_terracotta
setblock 165 -1 325 minecraft:light[level=12]
setblock 165 -1 332 minecraft:light[level=12]
setblock 165 -1 339 minecraft:light[level=12]
setblock 165 -1 346 minecraft:light[level=12]
setblock 165 -1 353 minecraft:light[level=12]
setblock 172 -1 325 minecraft:light[level=12]
setblock 172 -1 332 minecraft:light[level=12]
setblock 172 -1 339 minecraft:light[level=12]
setblock 172 -1 346 minecraft:light[level=12]
setblock 172 -1 353 minecraft:light[level=12]
setblock 172 -1 360 minecraft:light[level=12]
setblock 175 -1 363 minecraft:dark_prismarine
setblock 176 -1 323 minecraft:blue_terracotta
fill 176 -1 335 176 33 335 minecraft:magenta_terracotta
setblock 176 -1 362 minecraft:dark_prismarine
fill 176 -1 363 176 2 363 minecraft:blue_terracotta
fill 177 -1 362 177 2 362 minecraft:blue_terracotta
fill 178 -1 356 178 4 356 minecraft:purple_concrete
setblock 179 -1 325 minecraft:light[level=12]
setblock 179 -1 332 minecraft:light[level=12]
setblock 179 -1 339 minecraft:light[level=12]
setblock 179 -1 346 minecraft:light[level=12]
setblock 179 -1 354 minecraft:dark_prismarine
fill 179 -1 355 179 2 355 minecraft:blue_terracotta
setblock 179 -1 360 minecraft:light[level=12]
setblock 180 -1 323 minecraft:purple_concrete
setblock 180 -1 353 minecraft:dark_prismarine
fill 180 -1 354 180 2 354 minecraft:blue_terracotta
setblock 180 -1 358 minecraft:dark_prismarine
fill 180 -1 359 180 2 359 minecraft:blue_terracotta
setblock 180 -1 363 minecraft:dark_prismarine
setblock 181 -1 332 minecraft:dark_prismarine
setblock 181 -1 333 minecraft:blue_terracotta
setblock 181 -1 347 minecraft:dark_prismarine
fill 181 -1 348 181 0 348 minecraft:blue_terracotta
setblock 181 -1 352 minecraft:dark_prismarine
fill 181 -1 353 181 2 353 minecraft:blue_terracotta
setblock 181 -1 357 minecraft:dark_prismarine
fill 181 -1 358 181 2 358 minecraft:blue_terracotta
fill 181 -1 363 181 2 363 minecraft:blue_terracotta
setblock 182 -1 331 minecraft:dark_prismarine
fill 182 -1 332 182 1 332 minecraft:blue_terracotta
setblock 182 -1 336 minecraft:dark_prismarine
fill 182 -1 337 182 2 337 minecraft:blue_terracotta
setblock 182 -1 341 minecraft:dark_prismarine
setblock 182 -1 342 minecraft:blue_terracotta
setblock 182 -1 346 minecraft:dark_prismarine
fill 182 -1 347 182 2 347 minecraft:blue_terracotta
setblock 182 -1 351 minecraft:dark_prismarine
fill 182 -1 352 182 2 352 minecraft:blue_terracotta
setblock 182 -1 356 minecraft:dark_prismarine
fill 182 -1 357 182 2 357 minecraft:blue_terracotta
setblock 182 -1 361 minecraft:dark_prismarine
fill 182 -1 362 182 2 362 minecraft:blue_terracotta
setblock 142 0 327 minecraft:purple_concrete
setblock 142 0 330 minecraft:dark_prismarine
fill 142 0 331 142 3 331 minecraft:blue_terracotta
setblock 142 0 335 minecraft:dark_prismarine
fill 142 0 336 142 3 336 minecraft:blue_terracotta
setblock 142 0 340 minecraft:dark_prismarine
fill 142 0 341 142 0 344 minecraft:blue_terracotta
setblock 142 0 345 minecraft:dark_prismarine
fill 142 0 346 142 1 346 minecraft:blue_terracotta
setblock 142 0 350 minecraft:dark_prismarine
fill 142 0 351 142 2 351 minecraft:blue_terracotta
setblock 142 0 355 minecraft:dark_prismarine
fill 142 0 356 142 3 356 minecraft:blue_terracotta
setblock 143 0 334 minecraft:dark_prismarine
fill 143 0 335 143 3 335 minecraft:blue_terracotta
setblock 143 0 354 minecraft:dark_prismarine
setblock 143 0 355 minecraft:blue_terracotta
fill 148 0 350 148 33 350 minecraft:magenta_terracotta
fill 149 0 349 149 33 349 minecraft:magenta_terracotta
setblock 150 0 363 minecraft:purple_concrete
fill 155 0 323 158 0 323 minecraft:blue_terracotta
setblock 158 0 324 minecraft:dark_prismarine
fill 158 0 364 158 131 364 minecraft:black_concrete
setblock 159 0 323 minecraft:dark_prismarine
setblock 159 0 324 minecraft:blue_terracotta
setblock 159 0 363 minecraft:dark_prismarine
fill 160 0 323 160 3 323 minecraft:blue_terracotta
fill 160 0 363 160 3 363 minecraft:blue_terracotta
fill 164 0 357 164 32 357 minecraft:magenta_terracotta
setblock 169 0 363 minecraft:purple_concrete
setblock 174 0 323 minecraft:purple_concrete
setblock 174 0 362 minecraft:blue_terracotta
setblock 174 0 363 minecraft:dark_prismarine
setblock 175 0 362 minecraft:dark_prismarine
fill 175 0 363 175 3 363 minecraft:blue_terracotta
fill 176 0 362 176 3 362 minecraft:blue_terracotta
fill 177 0 356 177 4 356 minecraft:purple_concrete
setblock 179 0 353 minecraft:dark_prismarine
fill 179 0 354 179 1 354 minecraft:blue_terracotta
setblock 179 0 357 minecraft:blue_terracotta
setblock 179 0 363 minecraft:dark_prismarine
setblock 180 0 352 minecraft:dark_prismarine
fill 180 0 353 180 3 353 minecraft:blue_terracotta
setblock 180 0 357 minecraft:dark_prismarine
fill 180 0 358 180 3 358 minecraft:blue_terracotta
setblock 180 0 362 minecraft:dark_prismarine
fill 180 0 363 180 3 363 minecraft:blue_terracotta
setblock 181 0 351 minecraft:dark_prismarine
fill 181 0 352 181 3 352 minecraft:blue_terracotta
setblock 181 0 356 minecraft:dark_prismarine
fill 181 0 357 181 3 357 minecraft:blue_terracotta
setblock 181 0 361 minecraft:dark_prismarine
setblock 182 0 330 minecraft:dark_prismarine
setblock 182 0 331 minecraft:blue_terracotta
setblock 182 0 335 minecraft:dark_prismarine
fill 182 0 336 182 3 336 minecraft:blue_terracotta
setblock 182 0 340 minecraft:dark_prismarine
setblock 182 0 345 minecraft:dark_prismarine
fill 182 0 346 182 1 346 minecraft:blue_terracotta
setblock 182 0 350 minecraft:dark_prismarine
fill 182 0 351 182 3 351 minecraft:blue_terracotta
setblock 182 0 355 minecraft:dark_prismarine
fill 182 0 356 182 3 356 minecraft:blue_terracotta
setblock 182 0 360 minecraft:dark_prismarine
fill 182 0 361 182 3 361 minecraft:blue_terracotta
fill 142 1 330 142 2 330 minecraft:blue_terracotta
setblock 142 1 334 minecraft:dark_prismarine
fill 142 1 335 142 4 335 minecraft:blue_terracotta
setblock 142 1 339 minecraft:dark_prismarine
fill 142 1 340 142 1 343 minecraft:blue_terracotta
setblock 142 1 344 minecraft:dark_prismarine
setblock 142 1 345 minecraft:blue_terracotta
setblock 142 1 349 minecraft:dark_prismarine
fill 142 1 350 142 2 350 minecraft:blue_terracotta
setblock 142 1 354 minecraft:dark_prismarine
fill 142 1 355 142 4 355 minecraft:blue_terracotta
setblock 142 1 359 minecraft:dark_prismarine
setblock 143 1 333 minecraft:dark_prismarine
fill 143 1 334 143 4 334 minecraft:blue_terracotta
setblock 143 1 338 minecraft:dark_prismarine
setblock 149 1 323 minecraft:purple_concrete
fill 154 1 323 157 1 323 minecraft:blue_terracotta
fill 156 1 363 156 2 363 minecraft:blue_terracotta
setblock 157 1 324 minecraft:dark_prismarine
setblock 158 1 323 minecraft:dark_prismarine
fill 158 1 324 158 4 324 minecraft:blue_terracotta
setblock 158 1 363 minecraft:dark_prismarine
fill 159 1 323 159 4 323 minecraft:blue_terracotta
fill 159 1 324 159 4 324 minecraft:black_concrete
fill 159 1 363 159 4 363 minecraft:blue_terracotta
fill 166 1 356 166 33 356 minecraft:magenta_terracotta
setblock 168 1 323 minecraft:purple_concrete
fill 171 1 363 171 2 363 minecraft:blue_terracotta
setblock 173 1 362 minecraft:blue_terracotta
setblock 173 1 363 minecraft:dark_prismarine
setblock 174 1 362 minecraft:dark_prismarine
fill 174 1 363 174 4 363 minecraft:blue_terracotta
fill 175 1 362 175 4 362 minecraft:blue_terracotta
fill 176 1 361 178 2 361 minecraft:blue_terracotta
fill 177 1 355 178 4 355 minecraft:purple_concrete
fill 177 1 357 178 4 357 minecraft:purple_concrete
setblock 178 1 363 minecraft:dark_prismarine
setblock 179 1 357 minecraft:dark_prismarine
setblock 179 1 362 minecraft:dark_prismarine
fill 179 1 363 179 4 363 minecraft:blue_terracotta
fill 180 1 352 180 2 352 minecraft:blue_terracotta
setblock 180 1 356 minecraft:dark_prismarine
fill 180 1 357 180 4 357 minecraft:blue_terracotta
fill 180 1 362 180 4 362 minecraft:blue_terracotta
setblock 181 1 350 minecraft:dark_prismarine
fill 181 1 351 181 3 351 minecraft:blue_terracotta
setblock 181 1 355 minecraft:dark_prismarine
fill 181 1 356 181 4 356 minecraft:blue_terracotta
setblock 181 1 360 minecraft:dark_prismarine
fill 181 1 361 181 4 361 minecraft:blue_terracotta
setblock 182 1 334 minecraft:dark_prismarine
fill 182 1 335 182 4 335 minecraft:blue_terracotta
setblock 182 1 339 minecraft:dark_prismarine
fill 182 1 340 182 3 341 minecraft:blue_terracotta
setblock 182 1 349 minecraft:dark_prismarine
fill 182 1 350 182 4 350 minecraft:blue_terracotta
setblock 182 1 354 minecraft:dark_prismarine
fill 182 1 355 182 4 355 minecraft:blue_terracotta
setblock 182 1 359 minecraft:dark_prismarine
fill 182 1 360 182 4 360 minecraft:blue_terracotta
fill 183 1 323 183 12 333 minecraft:black_concrete
setblock 183 1 334 minecraft:light_blue_wool
fill 183 1 335 183 129 335 minecraft:black_concrete
fill 141 2 326 141 41 331 minecraft:black_concrete
setblock 141 2 332 minecraft:cyan_concrete
fill 141 2 333 141 7 343 minecraft:black_concrete
setblock 142 2 333 minecraft:dark_prismarine
fill 142 2 334 142 5 334 minecraft:blue_terracotta
setblock 142 2 338 minecraft:dark_prismarine
fill 142 2 339 142 2 342 minecraft:blue_terracotta
setblock 142 2 343 minecraft:dark_prismarine
setblock 142 2 353 minecraft:dark_prismarine
fill 142 2 354 142 4 354 minecraft:blue_terracotta
setblock 142 2 358 minecraft:dark_prismarine
fill 142 2 359 142 5 359 minecraft:blue_terracotta
setblock 143 2 323 minecraft:purple_concrete
setblock 143 2 337 minecraft:dark_prismarine
fill 143 2 338 143 5 338 minecraft:blue_terracotta
fill 154 2 323 156 2 323 minecraft:blue_terracotta
fill 155 2 363 155 3 363 minecraft:blue_terracotta
setblock 157 2 323 minecraft:dark_prismarine
fill 157 2 324 157 5 324 minecraft:blue_terracotta
setblock 157 2 363 minecraft:dark_prismarine
fill 158 2 323 158 5 323 minecraft:blue_terracotta
fill 158 2 363 158 5 363 minecraft:blue_terracotta
fill 159 2 325 159 5 325 minecraft:black_concrete
fill 160 2 324 160 5 324 minecraft:black_concrete
setblock 162 2 323 minecraft:purple_concrete
setblock 162 2 363 minecraft:dark_prismarine
fill 170 2 363 170 3 363 minecraft:blue_terracotta
setblock 172 2 362 minecraft:blue_terracotta
setblock 172 2 363 minecraft:dark_prismarine
setblock 173 2 362 minecraft:dark_prismarine
fill 173 2 363 173 5 363 minecraft:blue_terracotta
setblock 174 2 361 minecraft:dark_prismarine
fill 174 2 362 174 5 362 minecraft:blue_terracotta
fill 175 2 361 175 5 361 minecraft:blue_terracotta
fill 176 2 355 176 4 357 minecraft:purple_concrete
setblock 177 2 363 minecraft:dark_prismarine
setblock 178 2 322 minecraft:cyan_concrete
fill 178 2 354 178 4 354 minecraft:purple_concrete
fill 178 2 358 178 4 358 minecraft:purple_concrete
setblock 178 2 362 minecraft:dark_prismarine
fill 178 2 363 178 5 363 minecraft:blue_terracotta
setblock 179 2 356 minecraft:dark_prismarine
setblock 179 2 357 minecraft:blue_terracotta
fill 179 2 362 179 5 362 minecraft:blue_terracotta
fill 180 2 350 180 27 350 minecraft:magenta_terracotta
setblock 180 2 355 minecraft:dark_prismarine
fill 180 2 356 180 5 356 minecraft:blue_terracotta
setblock 181 2 350 minecraft:blue_terracotta
setblock 181 2 354 minecraft:dark_prismarine
fill 181 2 355 181 5 355 minecraft:blue_terracotta
setblock 181 2 359 minecraft:dark_prismarine
fill 181 2 360 181 5 360 minecraft:blue_terracotta
setblock 182 2 328 minecraft:purple_concrete
setblock 182 2 333 minecraft:dark_prismarine
fill 182 2 334 182 5 334 minecraft:blue_terracotta
setblock 182 2 338 minecraft:dark_prismarine
fill 182 2 339 182 5 339 minecraft:blue_terracotta
setblock 182 2 348 minecraft:dark_prismarine
fill 182 2 349 182 5 349 minecraft:blue_terracotta
setblock 182 2 353 minecraft:dark_prismarine
fill 182 2 354 182 5 354 minecraft:blue_terracotta
setblock 182 2 358 minecraft:dark_prismarine
fill 182 2 359 182 5 359 minecraft:blue_terracotta
fill 183 2 334 183 117 334 minecraft:black_concrete
fill 141 3 332 141 71 332 minecraft:black_concrete
setblock 142 3 332 minecraft:dark_prismarine
fill 142 3 333 142 6 333 minecraft:blue_terracotta
setblock 142 3 337 minecraft:dark_prismarine
fill 142 3 338 142 3 341 minecraft:blue_terracotta
setblock 142 3 342 minecraft:dark_prismarine
fill 142 3 343 142 6 343 minecraft:blue_terracotta
setblock 142 3 345 minecraft:purple_concrete
setblock 142 3 352 minecraft:dark_prismarine
setblock 142 3 353 minecraft:blue_terracotta
setblock 142 3 357 minecraft:dark_prismarine
fill 142 3 358 142 6 358 minecraft:blue_terracotta
setblock 143 3 336 minecraft:dark_prismarine
fill 143 3 337 143 6 337 minecraft:blue_terracotta
fill 143 3 339 143 4 339 minecraft:blue_terracotta
setblock 143 3 363 minecraft:purple_concrete
fill 153 3 323 155 3 323 minecraft:blue_terracotta
fill 153 3 363 154 4 363 minecraft:blue_terracotta
setblock 155 3 324 minecraft:dark_prismarine
setblock 156 3 323 minecraft:dark_prismarine
fill 156 3 324 156 6 324 minecraft:blue_terracotta
setblock 156 3 362 minecraft:blue_terracotta
setblock 156 3 363 minecraft:dark_prismarine
fill 157 3 323 157 6 323 minecraft:blue_terracotta
setblock 157 3 362 minecraft:dark_prismarine
fill 157 3 363 157 6 363 minecraft:blue_terracotta
fill 158 3 362 160 4 362 minecraft:blue_terracotta
setblock 161 3 323 minecraft:dark_prismarine
setblock 161 3 363 minecraft:dark_prismarine
fill 162 3 363 164 4 363 minecraft:blue_terracotta
fill 167 3 363 169 4 363 minecraft:blue_terracotta
fill 169 3 364 175 41 364 minecraft:black_concrete
fill 170 3 362 171 3 362 minecraft:blue_terracotta
setblock 171 3 363 minecraft:dark_prismarine
setblock 172 3 362 minecraft:dark_prismarine
fill 172 3 363 172 6 363 minecraft:blue_terracotta
setblock 173 3 361 minecraft:dark_prismarine
fill 173 3 362 173 6 362 minecraft:blue_terracotta
fill 174 3 361 174 6 361 minecraft:blue_terracotta
fill 176 3 361 177 3 361 minecraft:blue_terracotta
setblock 176 3 363 minecraft:dark_prismarine
setblock 176 3 364 minecraft:cyan_concrete
fill 177 3 354 177 4 354 minecraft:purple_concrete
fill 177 3 358 177 4 358 minecraft:purple_concrete
setblock 177 3 362 minecraft:dark_prismarine
fill 177 3 363 177 6 363 minecraft:blue_terracotta
fill 177 3 364 180 69 364 minecraft:black_concrete
fill 178 3 322 178 131 322 minecraft:black_concrete
setblock 178 3 361 minecraft:dark_prismarine
fill 178 3 362 178 6 362 minecraft:blue_terracotta
fill 179 3 354 179 4 358 minecraft:purple_concrete
setblock 180 3 354 minecraft:dark_prismarine
fill 180 3 355 180 5 355 minecraft:blue_terracotta
setblock 180 3 359 minecraft:dark_prismarine
setblock 181 3 323 minecraft:purple_concrete
setblock 181 3 337 minecraft:blue_terracotta
setblock 181 3 353 minecraft:dark_prismarine
fill 181 3 354 181 6 354 minecraft:blue_terracotta
setblock 181 3 358 minecraft:dark_prismarine
fill 181 3 359 181 6 359 minecraft:blue_terracotta
setblock 181 3 363 minecraft:dark_prismarine
fill 182 3 333 182 4 333 minecraft:blue_terracotta
setblock 182 3 337 minecraft:dark_prismarine
fill 182 3 338 182 6 338 minecraft:blue_terracotta
setblock 182 3 342 minecraft:dark_prismarine
fill 182 3 343 182 6 343 minecraft:blue_terracotta
setblock 182 3 348 minecraft:blue_terracotta
setblock 182 3 352 minecraft:dark_prismarine
fill 182 3 353 182 6 353 minecraft:blue_terracotta
setblock 182 3 357 minecraft:dark_prismarine
fill 182 3 358 182 6 358 minecraft:blue_terracotta
setblock 182 3 362 minecraft:dark_prismarine
setblock 142 4 326 minecraft:purple_concrete
setblock 142 4 331 minecraft:dark_prismarine
fill 142 4 332 142 7 332 minecraft:blue_terracotta
setblock 142 4 336 minecraft:dark_prismarine
fill 142 4 337 142 4 340 minecraft:blue_terracotta
setblock 142 4 341 minecraft:dark_prismarine
fill 142 4 342 142 7 342 minecraft:blue_terracotta
fill 142 4 344 142 5 344 minecraft:blue_terracotta
setblock 142 4 351 minecraft:purple_concrete
setblock 142 4 356 minecraft:dark_prismarine
fill 142 4 357 142 6 357 minecraft:blue_terracotta
setblock 143 4 335 minecraft:dark_prismarine
fill 143 4 336 143 7 336 minecraft:blue_terracotta
setblock 143 4 340 minecraft:dark_prismarine
setblock 149 4 363 minecraft:purple_concrete
setblock 150 4 323 minecraft:purple_concrete
fill 151 4 323 154 4 323 minecraft:blue_terracotta
fill 152 4 363 152 6 363 minecraft:blue_terracotta
setblock 154 4 324 minecraft:dark_prismarine
fill 154 4 362 155 4 362 minecraft:blue_terracotta
setblock 155 4 323 minecraft:dark_prismarine
fill 155 4 324 155 7 324 minecraft:blue_terracotta
setblock 155 4 363 minecraft:dark_prismarine
fill 156 4 323 156 7 323 minecraft:blue_terracotta
setblock 156 4 362 minecraft:dark_prismarine
fill 156 4 363 156 7 363 minecraft:blue_terracotta
fill 157 4 362 157 7 362 minecraft:blue_terracotta
fill 158 4 325 158 5 325 minecraft:black_concrete
setblock 160 4 323 minecraft:dark_prismarine
fill 160 4 325 160 5 325 minecraft:black_concrete
fill 160 4 329 160 32 329 minecraft:magenta_terracotta
setblock 160 4 363 minecraft:dark_prismarine
fill 161 4 323 162 6 323 minecraft:blue_terracotta
schedule function dropper:buildpart/75_2 1t
