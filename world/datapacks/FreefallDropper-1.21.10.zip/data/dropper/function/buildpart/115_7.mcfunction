fill 351 236 479 351 237 480 minecraft:red_concrete
setblock 351 236 482 minecraft:black_concrete
setblock 351 236 484 minecraft:black_concrete
fill 351 236 486 351 237 487 minecraft:red_concrete
fill 351 236 488 351 237 488 minecraft:orange_concrete
fill 351 236 489 353 237 489 minecraft:white_concrete
fill 352 236 478 352 237 478 minecraft:red_concrete
fill 352 236 479 352 237 479 minecraft:orange_concrete
fill 352 236 480 352 236 482 minecraft:red_concrete
setblock 352 236 483 minecraft:black_concrete
fill 352 236 484 352 236 486 minecraft:red_concrete
fill 352 236 487 352 237 487 minecraft:orange_concrete
fill 352 236 488 352 237 488 minecraft:red_concrete
fill 353 236 474 359 237 474 minecraft:red_terracotta
fill 353 236 478 361 237 478 minecraft:white_concrete
fill 353 236 479 353 237 480 minecraft:red_concrete
fill 353 236 481 353 237 481 minecraft:orange_concrete
fill 353 236 482 353 237 484 minecraft:red_concrete
fill 353 236 485 353 237 485 minecraft:orange_concrete
fill 353 236 486 353 237 487 minecraft:red_concrete
fill 353 236 488 361 237 488 minecraft:white_concrete
fill 353 236 492 359 237 492 minecraft:red_terracotta
fill 354 236 477 354 237 477 minecraft:red_concrete
fill 354 236 479 362 237 479 minecraft:white_concrete
fill 354 236 480 354 237 480 minecraft:orange_concrete
fill 354 236 481 354 237 481 minecraft:red_concrete
fill 354 236 482 355 237 482 minecraft:orange_concrete
fill 354 236 483 355 237 483 minecraft:red_concrete
fill 354 236 484 355 237 484 minecraft:orange_concrete
fill 354 236 485 354 237 485 minecraft:red_concrete
fill 354 236 486 354 237 486 minecraft:orange_concrete
fill 354 236 487 362 237 487 minecraft:white_concrete
fill 354 236 489 354 237 489 minecraft:red_concrete
fill 355 236 477 360 237 477 minecraft:white_concrete
fill 355 236 480 363 237 481 minecraft:white_concrete
fill 355 236 485 363 237 486 minecraft:white_concrete
fill 355 236 489 360 237 489 minecraft:white_concrete
fill 356 236 482 363 237 484 minecraft:white_concrete
fill 357 236 475 361 237 475 minecraft:red_terracotta
fill 357 236 491 361 237 491 minecraft:red_terracotta
fill 359 236 476 362 237 476 minecraft:red_terracotta
fill 359 236 490 362 237 490 minecraft:red_terracotta
fill 361 236 477 363 237 477 minecraft:red_terracotta
fill 361 236 489 363 237 489 minecraft:red_terracotta
fill 362 236 478 364 237 478 minecraft:red_terracotta
fill 362 236 488 364 237 488 minecraft:red_terracotta
fill 363 236 479 364 237 479 minecraft:red_terracotta
fill 363 236 487 364 237 487 minecraft:red_terracotta
fill 364 236 480 365 237 482 minecraft:red_terracotta
fill 364 236 483 364 237 483 minecraft:white_concrete
fill 364 236 484 365 237 486 minecraft:red_terracotta
fill 365 236 483 366 237 483 minecraft:red_terracotta
fill 330 237 464 331 237 504 minecraft:red_terracotta
fill 332 237 464 332 237 482 minecraft:red_terracotta
fill 332 237 484 332 237 504 minecraft:red_terracotta
fill 333 237 464 333 237 479 minecraft:red_terracotta
fill 333 237 487 333 237 504 minecraft:red_terracotta
fill 334 237 464 334 237 477 minecraft:red_terracotta
fill 334 237 489 334 237 504 minecraft:red_terracotta
fill 335 237 464 335 237 476 minecraft:red_terracotta
fill 335 237 490 335 237 504 minecraft:red_terracotta
fill 336 237 464 336 237 475 minecraft:red_terracotta
fill 336 237 491 336 237 504 minecraft:red_terracotta
fill 337 237 464 338 237 474 minecraft:red_terracotta
fill 337 237 492 338 237 504 minecraft:red_terracotta
fill 339 237 464 341 237 473 minecraft:red_terracotta
fill 339 237 493 341 237 504 minecraft:red_terracotta
fill 342 237 464 345 237 472 minecraft:red_terracotta
fill 342 237 494 345 237 504 minecraft:red_terracotta
setblock 345 237 482 minecraft:red_concrete
setblock 345 237 484 minecraft:red_concrete
fill 346 237 464 370 237 471 minecraft:red_terracotta
fill 346 237 482 346 237 484 minecraft:shroomlight
fill 346 237 495 370 237 504 minecraft:red_terracotta
fill 347 237 481 347 237 482 minecraft:shroomlight
fill 347 237 484 347 237 485 minecraft:shroomlight
fill 348 237 480 348 237 481 minecraft:shroomlight
fill 348 237 485 348 237 486 minecraft:shroomlight
fill 349 237 480 350 237 480 minecraft:shroomlight
fill 349 237 486 350 237 486 minecraft:shroomlight
fill 350 237 481 351 237 481 minecraft:shroomlight
fill 350 237 485 351 237 485 minecraft:shroomlight
fill 351 237 482 352 237 482 minecraft:shroomlight
fill 351 237 484 352 237 484 minecraft:shroomlight
fill 352 237 480 352 237 481 minecraft:red_concrete
setblock 352 237 483 minecraft:shroomlight
fill 352 237 485 352 237 486 minecraft:red_concrete
fill 353 237 472 370 237 472 minecraft:red_terracotta
fill 353 237 494 370 237 494 minecraft:red_terracotta
fill 357 237 473 370 237 473 minecraft:red_terracotta
fill 357 237 493 370 237 493 minecraft:red_terracotta
fill 360 237 474 370 237 474 minecraft:red_terracotta
fill 360 237 492 370 237 492 minecraft:red_terracotta
fill 362 237 475 370 237 475 minecraft:red_terracotta
fill 362 237 491 370 237 491 minecraft:red_terracotta
fill 363 237 476 370 237 476 minecraft:red_terracotta
fill 363 237 490 370 237 490 minecraft:red_terracotta
fill 364 237 477 370 237 477 minecraft:red_terracotta
fill 364 237 489 370 237 489 minecraft:red_terracotta
fill 365 237 478 370 237 479 minecraft:red_terracotta
fill 365 237 487 370 237 488 minecraft:red_terracotta
fill 366 237 480 370 237 482 minecraft:red_terracotta
fill 366 237 484 370 237 486 minecraft:red_terracotta
fill 367 237 483 370 237 483 minecraft:red_terracotta
setblock 330 241 465 minecraft:white_concrete
fill 330 241 483 330 242 483 minecraft:pink_terracotta
setblock 330 241 490 minecraft:white_concrete
fill 330 241 496 330 241 499 minecraft:pink_terracotta
setblock 330 241 500 minecraft:red_nether_bricks
fill 330 241 501 330 241 504 minecraft:pink_terracotta
setblock 331 241 499 minecraft:red_nether_bricks
fill 331 241 500 331 241 503 minecraft:pink_terracotta
setblock 331 241 504 minecraft:red_nether_bricks
setblock 332 241 466 minecraft:light[level=12]
setblock 332 241 474 minecraft:light[level=12]
setblock 332 241 482 minecraft:light[level=12]
setblock 332 241 490 minecraft:light[level=12]
setblock 332 241 498 minecraft:light[level=12]
setblock 332 241 503 minecraft:red_nether_bricks
fill 332 241 504 335 241 504 minecraft:pink_terracotta
fill 333 241 503 336 241 503 minecraft:pink_terracotta
fill 334 241 464 335 241 464 minecraft:pink_terracotta
fill 334 241 502 337 241 502 minecraft:pink_terracotta
setblock 336 241 464 minecraft:red_nether_bricks
setblock 336 241 504 minecraft:red_nether_bricks
fill 337 241 464 340 241 464 minecraft:pink_terracotta
setblock 337 241 503 minecraft:red_nether_bricks
fill 337 241 504 340 241 504 minecraft:pink_terracotta
setblock 338 241 502 minecraft:red_nether_bricks
fill 338 241 503 341 241 503 minecraft:pink_terracotta
setblock 339 241 502 minecraft:pink_terracotta
setblock 340 241 466 minecraft:light[level=12]
setblock 340 241 474 minecraft:light[level=12]
setblock 340 241 482 minecraft:light[level=12]
setblock 340 241 490 minecraft:light[level=12]
setblock 340 241 498 minecraft:light[level=12]
setblock 341 241 464 minecraft:red_nether_bricks
setblock 341 241 504 minecraft:red_nether_bricks
fill 342 241 504 343 242 504 minecraft:pink_terracotta
setblock 348 241 466 minecraft:light[level=12]
setblock 348 241 474 minecraft:light[level=12]
setblock 348 241 482 minecraft:light[level=12]
setblock 348 241 490 minecraft:light[level=12]
setblock 348 241 498 minecraft:light[level=12]
fill 352 241 464 355 241 464 minecraft:pink_terracotta
fill 353 241 504 355 241 504 minecraft:pink_terracotta
setblock 354 241 465 minecraft:pink_terracotta
setblock 355 241 465 minecraft:red_nether_bricks
fill 355 241 503 356 241 503 minecraft:pink_terracotta
setblock 356 241 464 minecraft:red_nether_bricks
fill 356 241 465 359 241 465 minecraft:pink_terracotta
setblock 356 241 466 minecraft:light[level=12]
setblock 356 241 474 minecraft:light[level=12]
setblock 356 241 482 minecraft:light[level=12]
setblock 356 241 490 minecraft:light[level=12]
setblock 356 241 498 minecraft:light[level=12]
setblock 356 241 504 minecraft:red_nether_bricks
fill 357 241 464 360 241 464 minecraft:pink_terracotta
setblock 357 241 503 minecraft:red_nether_bricks
fill 357 241 504 360 241 504 minecraft:pink_terracotta
fill 358 241 503 361 241 503 minecraft:pink_terracotta
setblock 359 241 466 minecraft:red_nether_bricks
setblock 360 241 465 minecraft:red_nether_bricks
setblock 361 241 464 minecraft:red_nether_bricks
fill 361 241 465 364 241 465 minecraft:pink_terracotta
setblock 361 241 504 minecraft:red_nether_bricks
fill 362 241 464 365 241 464 minecraft:pink_terracotta
setblock 362 241 503 minecraft:red_nether_bricks
fill 362 241 504 365 241 504 minecraft:pink_terracotta
fill 363 241 503 366 241 503 minecraft:pink_terracotta
setblock 364 241 466 minecraft:light[level=12]
setblock 364 241 474 minecraft:light[level=12]
setblock 364 241 482 minecraft:light[level=12]
setblock 364 241 490 minecraft:light[level=12]
setblock 364 241 498 minecraft:light[level=12]
setblock 366 241 464 minecraft:red_nether_bricks
setblock 366 241 504 minecraft:red_nether_bricks
fill 367 241 464 370 241 464 minecraft:pink_terracotta
setblock 367 241 503 minecraft:red_nether_bricks
fill 367 241 504 370 241 504 minecraft:pink_terracotta
fill 368 241 503 370 242 503 minecraft:pink_terracotta
fill 369 241 502 370 242 502 minecraft:pink_terracotta
setblock 370 241 478 minecraft:white_concrete
fill 370 241 498 370 241 499 minecraft:pink_terracotta
setblock 370 241 500 minecraft:red_nether_bricks
fill 370 241 501 370 244 501 minecraft:pink_terracotta
setblock 330 242 471 minecraft:white_concrete
fill 330 242 482 330 243 482 minecraft:pink_terracotta
setblock 330 242 484 minecraft:red_nether_bricks
fill 330 242 485 330 245 485 minecraft:pink_terracotta
setblock 330 242 496 minecraft:white_concrete
fill 330 242 497 330 242 498 minecraft:pink_terracotta
setblock 330 242 499 minecraft:red_nether_bricks
fill 330 242 500 330 242 503 minecraft:pink_terracotta
setblock 330 242 504 minecraft:red_nether_bricks
fill 331 242 500 331 242 502 minecraft:pink_terracotta
setblock 331 242 503 minecraft:red_nether_bricks
fill 331 242 504 334 242 504 minecraft:pink_terracotta
fill 332 242 503 335 242 503 minecraft:pink_terracotta
fill 333 242 464 334 242 464 minecraft:pink_terracotta
fill 334 242 502 336 242 502 minecraft:pink_terracotta
setblock 335 242 464 minecraft:red_nether_bricks
setblock 335 242 504 minecraft:red_nether_bricks
fill 336 242 464 339 242 464 minecraft:pink_terracotta
setblock 336 242 503 minecraft:red_nether_bricks
fill 336 242 504 339 242 504 minecraft:pink_terracotta
setblock 337 242 502 minecraft:red_nether_bricks
fill 337 242 503 340 242 503 minecraft:pink_terracotta
setblock 340 242 464 minecraft:red_nether_bricks
setblock 340 242 504 minecraft:red_nether_bricks
fill 341 242 464 341 245 464 minecraft:pink_terracotta
fill 341 242 504 341 245 504 minecraft:pink_terracotta
fill 345 242 475 346 243 476 minecraft:pink_concrete
fill 346 242 477 346 243 477 minecraft:pink_concrete
fill 351 242 464 354 242 464 minecraft:pink_terracotta
fill 352 242 504 354 242 504 minecraft:pink_terracotta
setblock 354 242 465 minecraft:red_nether_bricks
setblock 355 242 464 minecraft:red_nether_bricks
fill 355 242 465 358 242 465 minecraft:pink_terracotta
setblock 355 242 503 minecraft:pink_terracotta
setblock 355 242 504 minecraft:red_nether_bricks
fill 356 242 464 359 242 464 minecraft:pink_terracotta
setblock 356 242 503 minecraft:red_nether_bricks
fill 356 242 504 359 242 504 minecraft:pink_terracotta
setblock 357 242 466 minecraft:pink_terracotta
fill 357 242 503 360 242 503 minecraft:pink_terracotta
setblock 358 242 466 minecraft:red_nether_bricks
setblock 359 242 465 minecraft:red_nether_bricks
fill 359 242 466 359 245 466 minecraft:pink_terracotta
setblock 360 242 464 minecraft:red_nether_bricks
fill 360 242 465 363 242 465 minecraft:pink_terracotta
setblock 360 242 504 minecraft:red_nether_bricks
fill 361 242 464 364 242 464 minecraft:pink_terracotta
setblock 361 242 503 minecraft:red_nether_bricks
fill 361 242 504 364 242 504 minecraft:pink_terracotta
fill 362 242 503 365 242 503 minecraft:pink_terracotta
setblock 365 242 464 minecraft:red_nether_bricks
setblock 365 242 504 minecraft:red_nether_bricks
fill 366 242 464 369 242 464 minecraft:pink_terracotta
fill 366 242 504 369 242 504 minecraft:pink_terracotta
setblock 370 242 464 minecraft:red_nether_bricks
fill 370 242 465 370 245 465 minecraft:pink_terracotta
setblock 370 242 472 minecraft:white_concrete
setblock 370 242 497 minecraft:white_concrete
setblock 370 242 499 minecraft:red_nether_bricks
fill 370 242 500 370 245 500 minecraft:pink_terracotta
setblock 370 242 504 minecraft:red_nether_bricks
setblock 330 243 477 minecraft:white_concrete
fill 330 243 481 330 244 481 minecraft:pink_terracotta
setblock 330 243 483 minecraft:red_nether_bricks
fill 330 243 484 330 246 484 minecraft:pink_terracotta
fill 330 243 486 330 243 487 minecraft:pink_terracotta
setblock 330 243 488 minecraft:red_nether_bricks
setblock 330 243 497 minecraft:pink_terracotta
setblock 330 243 498 minecraft:red_nether_bricks
fill 330 243 499 330 243 502 minecraft:pink_terracotta
setblock 330 243 503 minecraft:red_nether_bricks
fill 330 243 504 333 243 504 minecraft:pink_terracotta
fill 331 243 500 331 243 501 minecraft:pink_terracotta
setblock 331 243 502 minecraft:red_nether_bricks
fill 331 243 503 334 243 503 minecraft:pink_terracotta
fill 332 243 464 333 243 464 minecraft:pink_terracotta
setblock 334 243 464 minecraft:red_nether_bricks
setblock 334 243 504 minecraft:red_nether_bricks
fill 335 243 464 338 243 464 minecraft:pink_terracotta
setblock 335 243 502 minecraft:pink_terracotta
setblock 335 243 503 minecraft:red_nether_bricks
fill 335 243 504 338 243 504 minecraft:pink_terracotta
setblock 336 243 502 minecraft:red_nether_bricks
fill 336 243 503 339 243 503 minecraft:pink_terracotta
setblock 339 243 464 minecraft:red_nether_bricks
setblock 339 243 504 minecraft:red_nether_bricks
fill 340 243 464 340 246 464 minecraft:pink_terracotta
setblock 340 243 503 minecraft:red_nether_bricks
fill 340 243 504 340 246 504 minecraft:pink_terracotta
setblock 342 243 504 minecraft:pink_terracotta
fill 347 243 464 347 244 464 minecraft:white_concrete
setblock 347 243 504 minecraft:white_concrete
fill 350 243 464 353 243 464 minecraft:pink_terracotta
fill 352 243 504 353 243 504 minecraft:pink_terracotta
setblock 353 243 465 minecraft:red_nether_bricks
setblock 354 243 464 minecraft:red_nether_bricks
fill 354 243 465 357 243 465 minecraft:pink_terracotta
setblock 354 243 503 minecraft:pink_terracotta
setblock 354 243 504 minecraft:red_nether_bricks
fill 355 243 464 358 243 464 minecraft:pink_terracotta
setblock 355 243 503 minecraft:red_nether_bricks
fill 355 243 504 358 243 504 minecraft:pink_terracotta
setblock 356 243 466 minecraft:pink_terracotta
fill 356 243 503 359 243 503 minecraft:pink_terracotta
setblock 357 243 466 minecraft:red_nether_bricks
setblock 358 243 465 minecraft:red_nether_bricks
fill 358 243 466 358 246 466 minecraft:pink_terracotta
setblock 359 243 464 minecraft:red_nether_bricks
fill 359 243 465 362 243 465 minecraft:pink_terracotta
setblock 359 243 504 minecraft:red_nether_bricks
fill 360 243 464 363 243 464 minecraft:pink_terracotta
setblock 360 243 503 minecraft:red_nether_bricks
fill 360 243 504 363 243 504 minecraft:pink_terracotta
fill 361 243 503 364 243 503 minecraft:pink_terracotta
setblock 363 243 465 minecraft:red_nether_bricks
setblock 364 243 464 minecraft:red_nether_bricks
setblock 364 243 504 minecraft:red_nether_bricks
fill 365 243 464 368 243 464 minecraft:pink_terracotta
fill 365 243 504 368 243 504 minecraft:pink_terracotta
setblock 369 243 464 minecraft:red_nether_bricks
setblock 369 243 503 minecraft:pink_terracotta
setblock 369 243 504 minecraft:red_nether_bricks
fill 370 243 464 370 246 464 minecraft:pink_terracotta
setblock 370 243 466 minecraft:white_concrete
setblock 370 243 491 minecraft:white_concrete
fill 370 243 499 370 246 499 minecraft:pink_terracotta
setblock 370 243 502 minecraft:pink_terracotta
setblock 370 243 503 minecraft:red_nether_bricks
fill 370 243 504 370 246 504 minecraft:pink_terracotta
setblock 330 244 464 minecraft:white_concrete
setblock 330 244 482 minecraft:red_nether_bricks
fill 330 244 483 331 246 483 minecraft:pink_terracotta
setblock 330 244 486 minecraft:pink_terracotta
setblock 330 244 487 minecraft:red_nether_bricks
fill 330 244 488 330 245 490 minecraft:pink_terracotta
setblock 330 244 497 minecraft:red_nether_bricks
fill 330 244 498 330 244 501 minecraft:pink_terracotta
setblock 330 244 502 minecraft:red_nether_bricks
fill 330 244 503 332 244 504 minecraft:pink_terracotta
fill 331 244 464 332 244 464 minecraft:pink_terracotta
fill 331 244 482 331 247 482 minecraft:pink_terracotta
fill 331 244 484 331 244 485 minecraft:pink_terracotta
setblock 331 244 486 minecraft:red_nether_bricks
fill 331 244 487 331 246 488 minecraft:pink_terracotta
setblock 331 244 500 minecraft:pink_terracotta
setblock 331 244 501 minecraft:red_nether_bricks
fill 331 244 502 331 247 502 minecraft:pink_terracotta
setblock 333 244 464 minecraft:red_nether_bricks
setblock 333 244 503 minecraft:pink_terracotta
setblock 333 244 504 minecraft:red_nether_bricks
fill 334 244 464 337 244 464 minecraft:pink_terracotta
setblock 334 244 503 minecraft:red_nether_bricks
fill 334 244 504 337 244 504 minecraft:pink_terracotta
fill 335 244 503 338 244 503 minecraft:pink_terracotta
setblock 338 244 464 minecraft:red_nether_bricks
setblock 338 244 504 minecraft:red_nether_bricks
fill 339 244 464 339 247 464 minecraft:pink_terracotta
setblock 339 244 503 minecraft:red_nether_bricks
fill 339 244 504 339 247 504 minecraft:pink_terracotta
fill 349 244 464 352 244 464 minecraft:pink_terracotta
fill 351 244 504 352 244 504 minecraft:pink_terracotta
setblock 352 244 465 minecraft:red_nether_bricks
setblock 353 244 464 minecraft:red_nether_bricks
fill 353 244 465 356 244 465 minecraft:pink_terracotta
setblock 353 244 504 minecraft:red_nether_bricks
fill 354 244 464 357 244 464 minecraft:pink_terracotta
fill 354 244 466 355 244 466 minecraft:pink_terracotta
setblock 354 244 503 minecraft:red_nether_bricks
fill 354 244 504 357 244 504 minecraft:pink_terracotta
fill 355 244 503 358 244 503 minecraft:pink_terracotta
setblock 356 244 466 minecraft:red_nether_bricks
setblock 357 244 465 minecraft:red_nether_bricks
fill 357 244 466 357 247 466 minecraft:pink_terracotta
setblock 358 244 464 minecraft:red_nether_bricks
fill 358 244 465 361 244 465 minecraft:pink_terracotta
setblock 358 244 504 minecraft:red_nether_bricks
fill 359 244 464 362 244 464 minecraft:pink_terracotta
setblock 359 244 503 minecraft:red_nether_bricks
fill 359 244 504 362 244 504 minecraft:pink_terracotta
setblock 360 244 466 minecraft:pink_terracotta
fill 360 244 503 363 244 503 minecraft:pink_terracotta
setblock 362 244 465 minecraft:red_nether_bricks
setblock 363 244 464 minecraft:red_nether_bricks
fill 363 244 465 363 247 465 minecraft:pink_terracotta
setblock 363 244 504 minecraft:red_nether_bricks
fill 364 244 464 367 244 464 minecraft:pink_terracotta
fill 364 244 504 367 244 504 minecraft:pink_terracotta
setblock 368 244 464 minecraft:red_nether_bricks
setblock 368 244 503 minecraft:pink_terracotta
setblock 368 244 504 minecraft:red_nether_bricks
fill 369 244 464 369 247 464 minecraft:pink_terracotta
setblock 369 244 502 minecraft:pink_terracotta
setblock 369 244 503 minecraft:red_nether_bricks
fill 369 244 504 369 247 504 minecraft:pink_terracotta
setblock 370 244 466 minecraft:pink_terracotta
fill 370 244 479 370 245 479 minecraft:white_concrete
setblock 370 244 485 minecraft:white_concrete
setblock 370 244 502 minecraft:red_nether_bricks
fill 370 244 503 370 247 503 minecraft:pink_terracotta
fill 330 245 464 330 245 465 minecraft:pink_terracotta
setblock 330 245 470 minecraft:white_concrete
setblock 330 245 480 minecraft:pink_terracotta
setblock 330 245 481 minecraft:red_nether_bricks
fill 330 245 482 330 248 482 minecraft:pink_terracotta
setblock 330 245 486 minecraft:red_nether_bricks
fill 330 245 487 330 248 487 minecraft:pink_terracotta
setblock 330 245 491 minecraft:red_nether_bricks
fill 330 245 492 330 245 495 minecraft:pink_terracotta
setblock 330 245 496 minecraft:red_nether_bricks
fill 330 245 497 330 245 500 minecraft:pink_terracotta
setblock 330 245 501 minecraft:red_nether_bricks
fill 330 245 502 330 246 504 minecraft:pink_terracotta
setblock 331 245 464 minecraft:pink_terracotta
setblock 331 245 484 minecraft:pink_terracotta
setblock 331 245 485 minecraft:red_nether_bricks
fill 331 245 486 332 247 486 minecraft:pink_terracotta
setblock 331 245 489 minecraft:pink_terracotta
setblock 331 245 490 minecraft:red_nether_bricks
setblock 331 245 500 minecraft:red_nether_bricks
fill 331 245 501 331 248 501 minecraft:pink_terracotta
fill 331 245 503 331 245 504 minecraft:pink_terracotta
setblock 332 245 464 minecraft:red_nether_bricks
setblock 332 245 483 minecraft:pink_terracotta
setblock 332 245 484 minecraft:red_nether_bricks
fill 332 245 485 332 248 485 minecraft:pink_terracotta
fill 332 245 487 332 245 488 minecraft:pink_terracotta
setblock 332 245 503 minecraft:pink_terracotta
setblock 332 245 504 minecraft:red_nether_bricks
fill 333 245 464 336 245 464 minecraft:pink_terracotta
setblock 333 245 503 minecraft:red_nether_bricks
fill 333 245 504 336 245 504 minecraft:pink_terracotta
fill 334 245 503 337 245 503 minecraft:pink_terracotta
setblock 335 245 465 minecraft:pink_terracotta
setblock 336 245 465 minecraft:red_nether_bricks
setblock 337 245 464 minecraft:red_nether_bricks
setblock 337 245 504 minecraft:red_nether_bricks
fill 338 245 464 338 248 464 minecraft:pink_terracotta
setblock 338 245 503 minecraft:red_nether_bricks
fill 338 245 504 338 248 504 minecraft:pink_terracotta
fill 348 245 464 351 245 464 minecraft:pink_terracotta
setblock 350 245 465 minecraft:pink_terracotta
fill 350 245 504 351 245 504 minecraft:pink_terracotta
setblock 351 245 465 minecraft:red_nether_bricks
setblock 352 245 464 minecraft:red_nether_bricks
fill 352 245 465 355 245 465 minecraft:pink_terracotta
setblock 352 245 504 minecraft:red_nether_bricks
fill 353 245 464 356 245 464 minecraft:pink_terracotta
fill 353 245 466 354 245 466 minecraft:pink_terracotta
setblock 353 245 503 minecraft:red_nether_bricks
fill 353 245 504 356 245 504 minecraft:pink_terracotta
fill 354 245 503 357 245 503 minecraft:pink_terracotta
setblock 355 245 466 minecraft:red_nether_bricks
setblock 356 245 465 minecraft:red_nether_bricks
fill 356 245 466 356 248 466 minecraft:pink_terracotta
setblock 357 245 464 minecraft:red_nether_bricks
fill 357 245 465 360 245 465 minecraft:pink_terracotta
setblock 357 245 504 minecraft:red_nether_bricks
fill 358 245 464 361 245 464 minecraft:pink_terracotta
setblock 358 245 503 minecraft:red_nether_bricks
fill 358 245 504 361 245 504 minecraft:pink_terracotta
fill 359 245 503 362 245 503 minecraft:pink_terracotta
setblock 360 245 466 minecraft:red_nether_bricks
setblock 361 245 465 minecraft:red_nether_bricks
setblock 362 245 464 minecraft:red_nether_bricks
fill 362 245 465 362 248 465 minecraft:pink_terracotta
setblock 362 245 504 minecraft:red_nether_bricks
fill 363 245 464 366 245 464 minecraft:pink_terracotta
setblock 363 245 503 minecraft:red_nether_bricks
fill 363 245 504 366 245 504 minecraft:pink_terracotta
fill 364 245 465 364 246 465 minecraft:pink_terracotta
setblock 367 245 464 minecraft:red_nether_bricks
setblock 367 245 504 minecraft:red_nether_bricks
fill 368 245 464 368 248 464 minecraft:pink_terracotta
setblock 368 245 503 minecraft:red_nether_bricks
fill 368 245 504 368 248 504 minecraft:pink_terracotta
setblock 369 245 502 minecraft:red_nether_bricks
fill 369 245 503 369 248 503 minecraft:pink_terracotta
setblock 370 245 466 minecraft:red_nether_bricks
fill 370 245 467 370 248 467 minecraft:pink_terracotta
setblock 370 245 473 minecraft:white_concrete
fill 370 245 484 370 245 485 minecraft:pink_terracotta
setblock 370 245 486 minecraft:red_nether_bricks
fill 370 245 487 370 248 487 minecraft:pink_terracotta
fill 370 245 498 370 247 498 minecraft:pink_terracotta
setblock 370 245 501 minecraft:red_nether_bricks
fill 370 245 502 370 248 502 minecraft:pink_terracotta
setblock 330 246 464 minecraft:pink_terracotta
setblock 330 246 465 minecraft:red_nether_bricks
fill 330 246 466 330 249 466 minecraft:pink_terracotta
setblock 330 246 476 minecraft:white_concrete
setblock 330 246 480 minecraft:red_nether_bricks
fill 330 246 481 331 248 481 minecraft:pink_terracotta
setblock 330 246 485 minecraft:red_nether_bricks
fill 330 246 486 330 249 486 minecraft:pink_terracotta
fill 330 246 488 330 246 489 minecraft:pink_terracotta
setblock 330 246 490 minecraft:red_nether_bricks
fill 330 246 491 330 246 494 minecraft:pink_terracotta
setblock 330 246 495 minecraft:red_nether_bricks
fill 330 246 496 330 246 499 minecraft:pink_terracotta
setblock 330 246 500 minecraft:red_nether_bricks
fill 330 246 501 330 249 501 minecraft:pink_terracotta
setblock 331 246 464 minecraft:red_nether_bricks
setblock 331 246 484 minecraft:red_nether_bricks
fill 331 246 485 331 249 485 minecraft:pink_terracotta
setblock 331 246 489 minecraft:red_nether_bricks
fill 331 246 490 331 246 493 minecraft:pink_terracotta
fill 331 246 500 331 249 500 minecraft:pink_terracotta
setblock 331 246 503 minecraft:pink_terracotta
setblock 331 246 504 minecraft:red_nether_bricks
fill 332 246 464 334 246 465 minecraft:pink_terracotta
setblock 332 246 482 minecraft:pink_terracotta
setblock 332 246 483 minecraft:red_nether_bricks
fill 332 246 484 333 248 484 minecraft:pink_terracotta
setblock 332 246 487 minecraft:pink_terracotta
setblock 332 246 488 minecraft:red_nether_bricks
fill 332 246 489 332 248 490 minecraft:pink_terracotta
setblock 332 246 503 minecraft:red_nether_bricks
fill 332 246 504 335 246 504 minecraft:pink_terracotta
fill 333 246 485 333 246 486 minecraft:pink_terracotta
setblock 333 246 487 minecraft:red_nether_bricks
fill 333 246 488 333 249 488 minecraft:pink_terracotta
fill 333 246 503 336 246 503 minecraft:pink_terracotta
setblock 335 246 464 minecraft:pink_terracotta
setblock 335 246 465 minecraft:red_nether_bricks
setblock 336 246 464 minecraft:red_nether_bricks
fill 336 246 465 338 247 465 minecraft:pink_terracotta
setblock 336 246 504 minecraft:red_nether_bricks
fill 337 246 464 337 249 464 minecraft:pink_terracotta
setblock 337 246 503 minecraft:red_nether_bricks
fill 337 246 504 337 249 504 minecraft:pink_terracotta
setblock 338 246 503 minecraft:pink_terracotta
setblock 341 246 464 minecraft:red_nether_bricks
setblock 341 246 504 minecraft:red_nether_bricks
fill 342 246 464 343 248 464 minecraft:pink_terracotta
setblock 345 246 464 minecraft:pink_terracotta
setblock 346 246 464 minecraft:red_nether_bricks
setblock 346 246 504 minecraft:white_concrete
fill 347 246 464 350 246 464 minecraft:pink_terracotta
setblock 349 246 465 minecraft:pink_terracotta
setblock 350 246 465 minecraft:red_nether_bricks
setblock 350 246 504 minecraft:pink_terracotta
setblock 351 246 464 minecraft:red_nether_bricks
fill 351 246 465 353 246 466 minecraft:pink_terracotta
setblock 351 246 504 minecraft:red_nether_bricks
fill 352 246 464 355 246 464 minecraft:pink_terracotta
fill 352 246 504 355 246 504 minecraft:pink_terracotta
fill 353 246 503 356 246 503 minecraft:pink_terracotta
setblock 354 246 465 minecraft:pink_terracotta
setblock 354 246 466 minecraft:red_nether_bricks
setblock 355 246 465 minecraft:red_nether_bricks
fill 355 246 466 355 248 467 minecraft:pink_terracotta
setblock 356 246 464 minecraft:red_nether_bricks
fill 356 246 465 359 246 465 minecraft:pink_terracotta
fill 356 246 467 357 246 467 minecraft:pink_terracotta
setblock 356 246 504 minecraft:red_nether_bricks
fill 357 246 464 360 246 464 minecraft:pink_terracotta
setblock 357 246 503 minecraft:red_nether_bricks
fill 357 246 504 360 246 504 minecraft:pink_terracotta
fill 358 246 503 361 246 503 minecraft:pink_terracotta
setblock 359 246 466 minecraft:red_nether_bricks
setblock 360 246 465 minecraft:red_nether_bricks
fill 360 246 466 361 248 466 minecraft:pink_terracotta
setblock 361 246 464 minecraft:red_nether_bricks
fill 361 246 465 361 249 465 minecraft:pink_terracotta
setblock 361 246 504 minecraft:red_nether_bricks
fill 362 246 464 365 246 464 minecraft:pink_terracotta
setblock 362 246 503 minecraft:red_nether_bricks
fill 362 246 504 365 246 504 minecraft:pink_terracotta
setblock 363 246 503 minecraft:pink_terracotta
setblock 365 246 465 minecraft:red_nether_bricks
setblock 366 246 464 minecraft:red_nether_bricks
fill 366 246 465 366 249 465 minecraft:pink_terracotta
setblock 366 246 504 minecraft:red_nether_bricks
fill 367 246 464 367 249 464 minecraft:pink_terracotta
setblock 367 246 503 minecraft:red_nether_bricks
fill 367 246 504 367 249 504 minecraft:pink_terracotta
fill 368 246 465 369 246 465 minecraft:pink_terracotta
fill 368 246 503 368 249 503 minecraft:pink_terracotta
fill 369 246 502 369 249 502 minecraft:pink_terracotta
setblock 370 246 465 minecraft:red_nether_bricks
fill 370 246 466 370 249 466 minecraft:pink_terracotta
fill 370 246 468 370 247 468 minecraft:pink_terracotta
fill 370 246 482 370 246 484 minecraft:pink_terracotta
setblock 370 246 485 minecraft:red_nether_bricks
fill 370 246 486 370 249 486 minecraft:pink_terracotta
fill 370 246 488 370 246 489 minecraft:pink_terracotta
setblock 370 246 490 minecraft:red_nether_bricks
fill 370 246 491 370 249 491 minecraft:pink_terracotta
setblock 370 246 492 minecraft:white_concrete
fill 370 246 497 370 248 497 minecraft:pink_terracotta
setblock 370 246 500 minecraft:red_nether_bricks
fill 370 246 501 370 249 501 minecraft:pink_terracotta
setblock 330 247 464 minecraft:red_nether_bricks
fill 330 247 465 333 247 465 minecraft:pink_terracotta
fill 330 247 467 330 247 468 minecraft:pink_terracotta
setblock 330 247 479 minecraft:red_nether_bricks
fill 330 247 480 331 249 480 minecraft:pink_terracotta
setblock 330 247 483 minecraft:pink_terracotta
setblock 330 247 484 minecraft:red_nether_bricks
fill 330 247 485 330 250 485 minecraft:pink_terracotta
setblock 330 247 488 minecraft:pink_terracotta
setblock 330 247 489 minecraft:red_nether_bricks
fill 330 247 490 330 247 493 minecraft:pink_terracotta
setblock 330 247 494 minecraft:red_nether_bricks
fill 330 247 495 330 247 498 minecraft:pink_terracotta
setblock 330 247 499 minecraft:red_nether_bricks
fill 330 247 500 330 250 500 minecraft:pink_terracotta
fill 330 247 502 330 247 503 minecraft:pink_terracotta
setblock 330 247 504 minecraft:red_nether_bricks
fill 331 247 464 334 247 464 minecraft:pink_terracotta
fill 331 247 466 331 248 466 minecraft:pink_terracotta
setblock 331 247 483 minecraft:red_nether_bricks
fill 331 247 484 331 250 484 minecraft:pink_terracotta
setblock 331 247 487 minecraft:pink_terracotta
setblock 331 247 488 minecraft:red_nether_bricks
fill 331 247 489 331 247 492 minecraft:pink_terracotta
setblock 331 247 493 minecraft:red_nether_bricks
fill 331 247 494 331 247 497 minecraft:pink_terracotta
setblock 331 247 498 minecraft:red_nether_bricks
fill 331 247 499 331 250 499 minecraft:pink_terracotta
setblock 331 247 503 minecraft:red_nether_bricks
fill 331 247 504 334 247 504 minecraft:pink_terracotta
setblock 332 247 482 minecraft:red_nether_bricks
fill 332 247 483 333 249 483 minecraft:pink_terracotta
setblock 332 247 487 minecraft:red_nether_bricks
fill 332 247 488 332 250 488 minecraft:pink_terracotta
setblock 332 247 491 minecraft:pink_terracotta
setblock 332 247 492 minecraft:red_nether_bricks
fill 332 247 503 335 247 503 minecraft:pink_terracotta
setblock 333 247 485 minecraft:pink_terracotta
setblock 333 247 486 minecraft:red_nether_bricks
fill 333 247 487 333 250 487 minecraft:pink_terracotta
fill 333 247 489 333 247 490 minecraft:pink_terracotta
setblock 334 247 465 minecraft:red_nether_bricks
setblock 335 247 464 minecraft:red_nether_bricks
fill 335 247 465 335 250 465 minecraft:pink_terracotta
setblock 335 247 504 minecraft:red_nether_bricks
fill 336 247 464 336 250 464 minecraft:pink_terracotta
setblock 336 247 503 minecraft:red_nether_bricks
fill 336 247 504 336 250 504 minecraft:pink_terracotta
fill 337 247 503 337 248 503 minecraft:pink_terracotta
setblock 339 247 465 minecraft:red_nether_bricks
setblock 340 247 464 minecraft:red_nether_bricks
setblock 340 247 504 minecraft:red_nether_bricks
fill 341 247 464 341 250 464 minecraft:pink_terracotta
setblock 344 247 464 minecraft:pink_terracotta
setblock 345 247 464 minecraft:red_nether_bricks
fill 346 247 464 349 247 464 minecraft:pink_terracotta
fill 347 247 465 348 247 465 minecraft:pink_terracotta
setblock 349 247 465 minecraft:red_nether_bricks
setblock 349 247 504 minecraft:pink_terracotta
setblock 350 247 464 minecraft:red_nether_bricks
fill 350 247 465 352 247 466 minecraft:pink_terracotta
setblock 350 247 504 minecraft:red_nether_bricks
fill 351 247 464 354 247 464 minecraft:pink_terracotta
fill 351 247 504 354 247 504 minecraft:pink_terracotta
setblock 352 247 467 minecraft:red_nether_bricks
fill 352 247 503 355 247 503 minecraft:pink_terracotta
setblock 353 247 465 minecraft:pink_terracotta
setblock 353 247 466 minecraft:red_nether_bricks
fill 353 247 467 354 249 467 minecraft:pink_terracotta
setblock 354 247 465 minecraft:red_nether_bricks
fill 354 247 466 354 250 466 minecraft:pink_terracotta
setblock 355 247 464 minecraft:red_nether_bricks
fill 355 247 465 358 247 465 minecraft:pink_terracotta
setblock 355 247 504 minecraft:red_nether_bricks
fill 356 247 464 359 247 464 minecraft:pink_terracotta
setblock 356 247 467 minecraft:pink_terracotta
setblock 356 247 503 minecraft:red_nether_bricks
fill 356 247 504 359 247 504 minecraft:pink_terracotta
setblock 357 247 467 minecraft:red_nether_bricks
fill 357 247 503 360 247 503 minecraft:pink_terracotta
setblock 358 247 466 minecraft:red_nether_bricks
fill 358 247 467 358 250 467 minecraft:pink_terracotta
setblock 359 247 465 minecraft:red_nether_bricks
fill 359 247 466 359 250 466 minecraft:pink_terracotta
setblock 360 247 464 minecraft:red_nether_bricks
fill 360 247 465 360 250 465 minecraft:pink_terracotta
setblock 360 247 504 minecraft:red_nether_bricks
fill 361 247 464 364 247 464 minecraft:pink_terracotta
setblock 361 247 503 minecraft:red_nether_bricks
fill 361 247 504 364 247 504 minecraft:pink_terracotta
fill 362 247 503 362 248 503 minecraft:pink_terracotta
setblock 364 247 465 minecraft:red_nether_bricks
setblock 365 247 464 minecraft:red_nether_bricks
fill 365 247 465 365 250 465 minecraft:pink_terracotta
setblock 365 247 504 minecraft:red_nether_bricks
fill 366 247 464 366 250 464 minecraft:pink_terracotta
setblock 366 247 503 minecraft:red_nether_bricks
fill 366 247 504 366 250 504 minecraft:pink_terracotta
fill 367 247 465 368 247 465 minecraft:pink_terracotta
fill 367 247 503 367 250 503 minecraft:pink_terracotta
setblock 369 247 465 minecraft:red_nether_bricks
fill 369 247 466 369 250 466 minecraft:pink_terracotta
fill 369 247 501 369 250 501 minecraft:pink_terracotta
setblock 370 247 464 minecraft:red_nether_bricks
fill 370 247 465 370 250 465 minecraft:pink_terracotta
setblock 370 247 469 minecraft:red_nether_bricks
fill 370 247 482 370 247 483 minecraft:pink_terracotta
setblock 370 247 484 minecraft:red_nether_bricks
fill 370 247 485 370 250 485 minecraft:pink_terracotta
setblock 370 247 488 minecraft:pink_terracotta
setblock 370 247 489 minecraft:red_nether_bricks
fill 370 247 490 370 250 490 minecraft:pink_terracotta
fill 370 247 492 370 247 493 minecraft:pink_terracotta
setblock 370 247 494 minecraft:red_nether_bricks
fill 370 247 495 370 249 496 minecraft:pink_terracotta
setblock 370 247 499 minecraft:red_nether_bricks
fill 370 247 500 370 250 500 minecraft:pink_terracotta
setblock 370 247 504 minecraft:red_nether_bricks
fill 330 248 464 332 248 465 minecraft:pink_terracotta
setblock 330 248 467 minecraft:pink_terracotta
setblock 330 248 468 minecraft:red_nether_bricks
fill 330 248 469 330 250 470 minecraft:pink_terracotta
setblock 330 248 478 minecraft:red_nether_bricks
fill 330 248 479 330 251 479 minecraft:pink_terracotta
setblock 330 248 483 minecraft:red_nether_bricks
fill 330 248 484 330 251 484 minecraft:pink_terracotta
setblock 330 248 488 minecraft:red_nether_bricks
fill 330 248 489 330 248 492 minecraft:pink_terracotta
setblock 330 248 493 minecraft:red_nether_bricks
fill 330 248 494 330 248 497 minecraft:pink_terracotta
setblock 330 248 498 minecraft:red_nether_bricks
fill 330 248 499 330 251 499 minecraft:pink_terracotta
setblock 330 248 502 minecraft:pink_terracotta
setblock 330 248 503 minecraft:red_nether_bricks
fill 330 248 504 333 248 504 minecraft:pink_terracotta
setblock 331 248 467 minecraft:red_nether_bricks
fill 331 248 468 331 251 468 minecraft:pink_terracotta
setblock 331 248 482 minecraft:red_nether_bricks
fill 331 248 483 331 251 483 minecraft:pink_terracotta
setblock 331 248 486 minecraft:pink_terracotta
setblock 331 248 487 minecraft:red_nether_bricks
fill 331 248 488 331 248 491 minecraft:pink_terracotta
setblock 331 248 492 minecraft:red_nether_bricks
fill 331 248 493 331 248 496 minecraft:pink_terracotta
setblock 331 248 497 minecraft:red_nether_bricks
fill 331 248 498 331 251 498 minecraft:pink_terracotta
setblock 331 248 502 minecraft:red_nether_bricks
fill 331 248 503 334 248 503 minecraft:pink_terracotta
setblock 332 248 481 minecraft:red_nether_bricks
fill 332 248 482 332 251 482 minecraft:pink_terracotta
setblock 332 248 486 minecraft:red_nether_bricks
fill 332 248 487 332 251 487 minecraft:pink_terracotta
setblock 332 248 491 minecraft:red_nether_bricks
fill 332 248 492 332 249 494 minecraft:pink_terracotta
setblock 333 248 464 minecraft:pink_terracotta
setblock 333 248 465 minecraft:red_nether_bricks
setblock 333 248 485 minecraft:red_nether_bricks
fill 333 248 486 334 250 486 minecraft:pink_terracotta
setblock 333 248 489 minecraft:pink_terracotta
setblock 333 248 490 minecraft:red_nether_bricks
fill 333 248 491 333 251 491 minecraft:pink_terracotta
setblock 334 248 464 minecraft:red_nether_bricks
fill 334 248 465 334 251 465 minecraft:pink_terracotta
fill 334 248 485 334 250 485 minecraft:pink_terracotta
fill 334 248 487 334 248 488 minecraft:pink_terracotta
setblock 334 248 504 minecraft:red_nether_bricks
fill 335 248 464 335 251 464 minecraft:pink_terracotta
setblock 335 248 503 minecraft:red_nether_bricks
fill 335 248 504 335 251 504 minecraft:pink_terracotta
fill 336 248 465 337 248 465 minecraft:pink_terracotta
fill 336 248 503 336 249 503 minecraft:pink_terracotta
setblock 338 248 465 minecraft:red_nether_bricks
setblock 339 248 464 minecraft:red_nether_bricks
fill 339 248 465 339 250 465 minecraft:pink_terracotta
setblock 339 248 504 minecraft:red_nether_bricks
fill 340 248 464 340 251 464 minecraft:pink_terracotta
setblock 340 248 504 minecraft:pink_terracotta
setblock 344 248 464 minecraft:red_nether_bricks
fill 345 248 464 348 248 464 minecraft:pink_terracotta
fill 346 248 465 347 248 465 minecraft:pink_terracotta
setblock 348 248 465 minecraft:red_nether_bricks
setblock 348 248 504 minecraft:pink_terracotta
setblock 349 248 464 minecraft:red_nether_bricks
fill 349 248 465 351 248 466 minecraft:pink_terracotta
setblock 349 248 504 minecraft:red_nether_bricks
fill 350 248 464 353 248 464 minecraft:pink_terracotta
fill 350 248 504 353 248 504 minecraft:pink_terracotta
setblock 351 248 467 minecraft:red_nether_bricks
setblock 352 248 465 minecraft:pink_terracotta
setblock 352 248 466 minecraft:red_nether_bricks
fill 352 248 467 352 251 467 minecraft:pink_terracotta
fill 352 248 503 354 248 503 minecraft:pink_terracotta
setblock 353 248 465 minecraft:red_nether_bricks
fill 353 248 466 353 251 466 minecraft:pink_terracotta
setblock 354 248 464 minecraft:red_nether_bricks
fill 354 248 465 357 248 465 minecraft:pink_terracotta
setblock 354 248 504 minecraft:red_nether_bricks
fill 355 248 464 358 248 464 minecraft:pink_terracotta
setblock 355 248 503 minecraft:red_nether_bricks
fill 355 248 504 358 248 504 minecraft:pink_terracotta
setblock 356 248 467 minecraft:red_nether_bricks
fill 356 248 503 359 248 503 minecraft:pink_terracotta
setblock 357 248 466 minecraft:red_nether_bricks
fill 357 248 467 357 251 467 minecraft:pink_terracotta
setblock 358 248 465 minecraft:red_nether_bricks
fill 358 248 466 358 251 466 minecraft:pink_terracotta
setblock 359 248 464 minecraft:red_nether_bricks
fill 359 248 465 359 251 465 minecraft:pink_terracotta
setblock 359 248 504 minecraft:red_nether_bricks
fill 360 248 464 363 248 464 minecraft:pink_terracotta
setblock 360 248 503 minecraft:red_nether_bricks
fill 360 248 504 363 248 504 minecraft:pink_terracotta
fill 361 248 503 361 249 503 minecraft:pink_terracotta
setblock 363 248 465 minecraft:red_nether_bricks
setblock 364 248 464 minecraft:red_nether_bricks
fill 364 248 465 364 251 465 minecraft:pink_terracotta
setblock 364 248 504 minecraft:red_nether_bricks
fill 365 248 464 365 251 464 minecraft:pink_terracotta
setblock 365 248 503 minecraft:red_nether_bricks
fill 365 248 504 365 251 504 minecraft:pink_terracotta
fill 366 248 503 366 251 503 minecraft:pink_terracotta
setblock 367 248 465 minecraft:pink_terracotta
setblock 368 248 465 minecraft:red_nether_bricks
setblock 369 248 464 minecraft:red_nether_bricks
fill 369 248 465 369 251 465 minecraft:pink_terracotta
fill 369 248 467 369 248 468 minecraft:pink_terracotta
fill 369 248 485 369 248 488 minecraft:pink_terracotta
setblock 369 248 489 minecraft:red_nether_bricks
fill 369 248 490 369 250 491 minecraft:pink_terracotta
fill 369 248 500 369 251 500 minecraft:pink_terracotta
setblock 369 248 504 minecraft:red_nether_bricks
fill 370 248 464 370 251 464 minecraft:pink_terracotta
setblock 370 248 468 minecraft:red_nether_bricks
fill 370 248 469 370 250 470 minecraft:pink_terracotta
setblock 370 248 480 minecraft:white_concrete
fill 370 248 481 370 248 482 minecraft:pink_terracotta
setblock 370 248 483 minecraft:red_nether_bricks
fill 370 248 484 370 251 484 minecraft:pink_terracotta
setblock 370 248 488 minecraft:red_nether_bricks
fill 370 248 489 370 251 489 minecraft:pink_terracotta
setblock 370 248 492 minecraft:pink_terracotta
setblock 370 248 493 minecraft:red_nether_bricks
fill 370 248 494 370 251 494 minecraft:pink_terracotta
setblock 370 248 498 minecraft:red_nether_bricks
fill 370 248 499 370 251 499 minecraft:pink_terracotta
setblock 370 248 503 minecraft:red_nether_bricks
fill 370 248 504 370 251 504 minecraft:pink_terracotta
fill 330 249 464 331 249 465 minecraft:pink_terracotta
setblock 330 249 467 minecraft:red_nether_bricks
fill 330 249 468 330 252 468 minecraft:pink_terracotta
setblock 330 249 471 minecraft:pink_terracotta
setblock 330 249 472 minecraft:red_nether_bricks
fill 330 249 473 330 252 473 minecraft:pink_terracotta
setblock 330 249 475 minecraft:white_concrete
setblock 330 249 477 minecraft:red_nether_bricks
fill 330 249 478 330 252 478 minecraft:pink_terracotta
setblock 330 249 481 minecraft:pink_terracotta
setblock 330 249 482 minecraft:red_nether_bricks
fill 330 249 483 330 252 483 minecraft:pink_terracotta
setblock 330 249 487 minecraft:red_nether_bricks
fill 330 249 488 330 249 491 minecraft:pink_terracotta
setblock 330 249 492 minecraft:red_nether_bricks
fill 330 249 493 330 249 496 minecraft:pink_terracotta
setblock 330 249 497 minecraft:red_nether_bricks
fill 330 249 498 330 252 498 minecraft:pink_terracotta
setblock 330 249 502 minecraft:red_nether_bricks
fill 330 249 503 332 249 504 minecraft:pink_terracotta
setblock 331 249 466 minecraft:red_nether_bricks
fill 331 249 467 331 252 467 minecraft:pink_terracotta
fill 331 249 469 331 249 470 minecraft:pink_terracotta
fill 331 249 479 331 250 479 minecraft:pink_terracotta
setblock 331 249 481 minecraft:red_nether_bricks
fill 331 249 482 331 252 482 minecraft:pink_terracotta
setblock 331 249 486 minecraft:red_nether_bricks
fill 331 249 487 331 249 490 minecraft:pink_terracotta
setblock 331 249 491 minecraft:red_nether_bricks
fill 331 249 492 331 249 495 minecraft:pink_terracotta
setblock 331 249 496 minecraft:red_nether_bricks
fill 331 249 497 331 252 497 minecraft:pink_terracotta
setblock 331 249 501 minecraft:red_nether_bricks
fill 331 249 502 331 252 502 minecraft:pink_terracotta
setblock 332 249 464 minecraft:pink_terracotta
setblock 332 249 465 minecraft:red_nether_bricks
fill 332 249 466 335 249 466 minecraft:pink_terracotta
setblock 332 249 474 minecraft:light[level=12]
fill 332 249 481 332 251 481 minecraft:pink_terracotta
setblock 332 249 484 minecraft:pink_terracotta
setblock 332 249 485 minecraft:red_nether_bricks
fill 332 249 486 332 252 486 minecraft:pink_terracotta
setblock 332 249 489 minecraft:pink_terracotta
setblock 332 249 490 minecraft:red_nether_bricks
fill 332 249 491 332 252 491 minecraft:pink_terracotta
setblock 332 249 495 minecraft:red_nether_bricks
setblock 332 249 498 minecraft:light[level=12]
setblock 333 249 464 minecraft:red_nether_bricks
fill 333 249 465 333 252 465 minecraft:pink_terracotta
setblock 333 249 484 minecraft:red_nether_bricks
fill 333 249 485 333 252 485 minecraft:pink_terracotta
setblock 333 249 489 minecraft:red_nether_bricks
fill 333 249 490 333 252 490 minecraft:pink_terracotta
fill 333 249 492 333 250 492 minecraft:pink_terracotta
setblock 333 249 503 minecraft:pink_terracotta
setblock 333 249 504 minecraft:red_nether_bricks
fill 334 249 464 334 252 464 minecraft:pink_terracotta
setblock 334 249 487 minecraft:pink_terracotta
setblock 334 249 488 minecraft:red_nether_bricks
fill 334 249 489 334 251 489 minecraft:pink_terracotta
setblock 334 249 503 minecraft:red_nether_bricks
fill 334 249 504 334 252 504 minecraft:pink_terracotta
fill 335 249 503 335 250 503 minecraft:pink_terracotta
setblock 336 249 465 minecraft:pink_terracotta
setblock 337 249 465 minecraft:red_nether_bricks
setblock 338 249 464 minecraft:red_nether_bricks
fill 338 249 465 338 251 465 minecraft:pink_terracotta
setblock 338 249 504 minecraft:red_nether_bricks
fill 339 249 464 339 252 464 minecraft:pink_terracotta
setblock 339 249 504 minecraft:pink_terracotta
setblock 340 249 465 minecraft:pink_terracotta
setblock 340 249 466 minecraft:light[level=12]
setblock 340 249 474 minecraft:light[level=12]
setblock 340 249 482 minecraft:light[level=12]
setblock 340 249 490 minecraft:light[level=12]
setblock 340 249 498 minecraft:light[level=12]
setblock 342 249 464 minecraft:pink_terracotta
setblock 343 249 464 minecraft:red_nether_bricks
fill 344 249 464 347 249 464 minecraft:pink_terracotta
fill 345 249 465 346 249 465 minecraft:pink_terracotta
setblock 345 249 504 minecraft:white_concrete
setblock 347 249 465 minecraft:red_nether_bricks
fill 347 249 466 350 249 466 minecraft:pink_terracotta
setblock 348 249 464 minecraft:red_nether_bricks
fill 348 249 465 351 249 465 minecraft:pink_terracotta
setblock 348 249 474 minecraft:light[level=12]
setblock 348 249 482 minecraft:light[level=12]
setblock 348 249 490 minecraft:light[level=12]
setblock 348 249 498 minecraft:light[level=12]
setblock 348 249 504 minecraft:red_nether_bricks
fill 349 249 464 352 249 464 minecraft:pink_terracotta
fill 349 249 504 352 249 504 minecraft:pink_terracotta
setblock 350 249 467 minecraft:red_nether_bricks
setblock 351 249 466 minecraft:red_nether_bricks
fill 351 249 467 351 252 467 minecraft:pink_terracotta
fill 351 249 503 353 249 503 minecraft:pink_terracotta
setblock 352 249 465 minecraft:red_nether_bricks
fill 352 249 466 352 252 466 minecraft:pink_terracotta
setblock 353 249 464 minecraft:red_nether_bricks
fill 353 249 465 356 249 465 minecraft:pink_terracotta
setblock 353 249 468 minecraft:pink_terracotta
setblock 353 249 504 minecraft:red_nether_bricks
fill 354 249 464 357 249 464 minecraft:pink_terracotta
setblock 354 249 468 minecraft:red_nether_bricks
setblock 354 249 503 minecraft:red_nether_bricks
fill 354 249 504 357 249 504 minecraft:pink_terracotta
setblock 355 249 466 minecraft:pink_terracotta
setblock 355 249 467 minecraft:red_nether_bricks
fill 355 249 503 358 249 503 minecraft:pink_terracotta
setblock 356 249 466 minecraft:red_nether_bricks
fill 356 249 467 356 252 467 minecraft:pink_terracotta
setblock 356 249 474 minecraft:light[level=12]
setblock 356 249 482 minecraft:light[level=12]
setblock 356 249 490 minecraft:light[level=12]
setblock 356 249 498 minecraft:light[level=12]
setblock 357 249 465 minecraft:red_nether_bricks
fill 357 249 466 357 252 466 minecraft:pink_terracotta
setblock 358 249 464 minecraft:red_nether_bricks
fill 358 249 465 358 252 465 minecraft:pink_terracotta
setblock 358 249 504 minecraft:red_nether_bricks
fill 359 249 464 362 249 464 minecraft:pink_terracotta
setblock 359 249 503 minecraft:red_nether_bricks
fill 359 249 504 362 249 504 minecraft:pink_terracotta
setblock 360 249 466 minecraft:pink_terracotta
setblock 360 249 503 minecraft:pink_terracotta
setblock 361 249 466 minecraft:red_nether_bricks
setblock 362 249 465 minecraft:red_nether_bricks
setblock 362 249 466 minecraft:pink_terracotta
setblock 363 249 464 minecraft:red_nether_bricks
fill 363 249 465 363 252 465 minecraft:pink_terracotta
setblock 363 249 504 minecraft:red_nether_bricks
fill 364 249 464 364 252 464 minecraft:pink_terracotta
setblock 364 249 466 minecraft:light[level=12]
setblock 364 249 474 minecraft:light[level=12]
setblock 364 249 482 minecraft:light[level=12]
setblock 364 249 490 minecraft:light[level=12]
setblock 364 249 498 minecraft:light[level=12]
fill 364 249 504 364 252 504 minecraft:pink_terracotta
setblock 365 249 503 minecraft:pink_terracotta
setblock 367 249 465 minecraft:red_nether_bricks
setblock 368 249 464 minecraft:red_nether_bricks
fill 368 249 465 368 252 465 minecraft:pink_terracotta
setblock 368 249 504 minecraft:red_nether_bricks
fill 369 249 464 369 252 464 minecraft:pink_terracotta
setblock 369 249 467 minecraft:pink_terracotta
setblock 369 249 468 minecraft:red_nether_bricks
fill 369 249 469 369 252 469 minecraft:pink_terracotta
fill 369 249 484 369 249 487 minecraft:pink_terracotta
setblock 369 249 488 minecraft:red_nether_bricks
fill 369 249 489 369 252 489 minecraft:pink_terracotta
setblock 369 249 492 minecraft:pink_terracotta
setblock 369 249 493 minecraft:red_nether_bricks
fill 369 249 494 369 251 495 minecraft:pink_terracotta
fill 369 249 499 369 252 499 minecraft:pink_terracotta
setblock 369 249 503 minecraft:red_nether_bricks
fill 369 249 504 369 252 504 minecraft:pink_terracotta
setblock 370 249 467 minecraft:red_nether_bricks
fill 370 249 468 370 252 468 minecraft:pink_terracotta
setblock 370 249 471 minecraft:pink_terracotta
setblock 370 249 472 minecraft:red_nether_bricks
setblock 370 249 474 minecraft:white_concrete
setblock 370 249 481 minecraft:pink_terracotta
setblock 370 249 482 minecraft:red_nether_bricks
fill 370 249 483 370 252 483 minecraft:pink_terracotta
setblock 370 249 487 minecraft:red_nether_bricks
fill 370 249 488 370 252 488 minecraft:pink_terracotta
setblock 370 249 492 minecraft:red_nether_bricks
fill 370 249 493 370 252 493 minecraft:pink_terracotta
setblock 370 249 497 minecraft:red_nether_bricks
fill 370 249 498 370 252 498 minecraft:pink_terracotta
setblock 370 249 502 minecraft:red_nether_bricks
fill 370 249 503 370 252 503 minecraft:pink_terracotta
fill 330 250 464 330 250 465 minecraft:pink_terracotta
setblock 330 250 466 minecraft:red_nether_bricks
fill 330 250 467 330 253 467 minecraft:pink_terracotta
setblock 330 250 471 minecraft:red_nether_bricks
fill 330 250 472 331 252 472 minecraft:pink_terracotta
fill 330 250 474 330 250 475 minecraft:pink_terracotta
setblock 330 250 476 minecraft:red_nether_bricks
fill 330 250 477 330 253 477 minecraft:pink_terracotta
setblock 330 250 480 minecraft:pink_terracotta
setblock 330 250 481 minecraft:red_nether_bricks
fill 330 250 482 330 253 482 minecraft:pink_terracotta
setblock 330 250 486 minecraft:red_nether_bricks
fill 330 250 487 330 250 490 minecraft:pink_terracotta
setblock 330 250 491 minecraft:red_nether_bricks
fill 330 250 492 330 250 495 minecraft:pink_terracotta
setblock 330 250 496 minecraft:red_nether_bricks
fill 330 250 497 330 253 497 minecraft:pink_terracotta
setblock 330 250 501 minecraft:red_nether_bricks
fill 330 250 502 330 251 504 minecraft:pink_terracotta
setblock 331 250 464 minecraft:pink_terracotta
setblock 331 250 465 minecraft:red_nether_bricks
fill 331 250 466 334 250 466 minecraft:pink_terracotta
setblock 331 250 469 minecraft:pink_terracotta
setblock 331 250 470 minecraft:red_nether_bricks
fill 331 250 471 331 253 471 minecraft:pink_terracotta
setblock 331 250 480 minecraft:red_nether_bricks
fill 331 250 481 331 253 481 minecraft:pink_terracotta
setblock 331 250 485 minecraft:red_nether_bricks
fill 331 250 486 331 250 489 minecraft:pink_terracotta
setblock 331 250 490 minecraft:red_nether_bricks
fill 331 250 491 331 250 494 minecraft:pink_terracotta
setblock 331 250 495 minecraft:red_nether_bricks
fill 331 250 496 332 252 496 minecraft:pink_terracotta
setblock 331 250 500 minecraft:red_nether_bricks
fill 331 250 501 331 252 501 minecraft:pink_terracotta
fill 331 250 503 331 250 504 minecraft:pink_terracotta
setblock 332 250 464 minecraft:red_nether_bricks
fill 332 250 465 332 253 465 minecraft:pink_terracotta
fill 332 250 467 332 250 468 minecraft:pink_terracotta
setblock 332 250 483 minecraft:pink_terracotta
setblock 332 250 484 minecraft:red_nether_bricks
fill 332 250 485 332 253 485 minecraft:pink_terracotta
setblock 332 250 489 minecraft:red_nether_bricks
fill 332 250 490 332 253 490 minecraft:pink_terracotta
fill 332 250 492 332 250 493 minecraft:pink_terracotta
setblock 332 250 494 minecraft:red_nether_bricks
fill 332 250 495 332 253 495 minecraft:pink_terracotta
setblock 332 250 503 minecraft:pink_terracotta
setblock 332 250 504 minecraft:red_nether_bricks
fill 333 250 464 333 253 464 minecraft:pink_terracotta
setblock 333 250 483 minecraft:red_nether_bricks
fill 333 250 484 333 252 484 minecraft:pink_terracotta
setblock 333 250 488 minecraft:red_nether_bricks
fill 333 250 489 333 253 489 minecraft:pink_terracotta
setblock 333 250 493 minecraft:red_nether_bricks
setblock 333 250 503 minecraft:red_nether_bricks
fill 333 250 504 333 253 504 minecraft:pink_terracotta
setblock 334 250 487 minecraft:red_nether_bricks
fill 334 250 488 334 251 488 minecraft:pink_terracotta
fill 334 250 490 334 251 490 minecraft:pink_terracotta
setblock 334 250 503 minecraft:pink_terracotta
setblock 335 250 466 minecraft:red_nether_bricks
setblock 336 250 465 minecraft:red_nether_bricks
setblock 337 250 464 minecraft:red_nether_bricks
fill 337 250 465 337 252 465 minecraft:pink_terracotta
setblock 337 250 504 minecraft:red_nether_bricks
fill 338 250 464 338 252 464 minecraft:pink_terracotta
setblock 338 250 504 minecraft:pink_terracotta
setblock 342 250 464 minecraft:red_nether_bricks
fill 343 250 464 346 250 464 minecraft:pink_terracotta
fill 344 250 465 345 250 465 minecraft:pink_terracotta
setblock 346 250 465 minecraft:red_nether_bricks
setblock 347 250 464 minecraft:red_nether_bricks
fill 347 250 465 349 250 466 minecraft:pink_terracotta
fill 348 250 464 351 250 464 minecraft:pink_terracotta
fill 348 250 504 351 250 504 minecraft:pink_terracotta
setblock 349 250 467 minecraft:red_nether_bricks
setblock 350 250 465 minecraft:pink_terracotta
setblock 350 250 466 minecraft:red_nether_bricks
fill 350 250 467 350 253 467 minecraft:pink_terracotta
setblock 351 250 465 minecraft:red_nether_bricks
fill 351 250 466 351 253 466 minecraft:pink_terracotta
fill 351 250 493 352 251 494 minecraft:pink_concrete
fill 351 250 503 352 250 503 minecraft:pink_terracotta
setblock 352 250 464 minecraft:red_nether_bricks
fill 352 250 465 355 250 465 minecraft:pink_terracotta
setblock 352 250 468 minecraft:pink_terracotta
setblock 352 250 504 minecraft:red_nether_bricks
fill 353 250 464 356 250 464 minecraft:pink_terracotta
setblock 353 250 467 minecraft:pink_terracotta
setblock 353 250 468 minecraft:red_nether_bricks
setblock 353 250 503 minecraft:red_nether_bricks
fill 353 250 504 356 250 504 minecraft:pink_terracotta
setblock 354 250 467 minecraft:red_nether_bricks
fill 354 250 468 355 251 468 minecraft:pink_terracotta
fill 354 250 503 357 250 503 minecraft:pink_terracotta
setblock 355 250 466 minecraft:red_nether_bricks
fill 355 250 467 355 253 467 minecraft:pink_terracotta
setblock 356 250 465 minecraft:red_nether_bricks
fill 356 250 466 356 253 466 minecraft:pink_terracotta
setblock 357 250 464 minecraft:red_nether_bricks
fill 357 250 465 357 253 465 minecraft:pink_terracotta
setblock 357 250 504 minecraft:red_nether_bricks
fill 358 250 464 361 250 464 minecraft:pink_terracotta
setblock 358 250 503 minecraft:red_nether_bricks
fill 358 250 504 361 250 504 minecraft:pink_terracotta
setblock 359 250 503 minecraft:pink_terracotta
setblock 360 250 466 minecraft:red_nether_bricks
setblock 361 250 465 minecraft:red_nether_bricks
setblock 361 250 466 minecraft:pink_terracotta
setblock 362 250 464 minecraft:red_nether_bricks
fill 362 250 465 362 252 465 minecraft:pink_terracotta
setblock 362 250 504 minecraft:red_nether_bricks
fill 363 250 464 363 253 464 minecraft:pink_terracotta
fill 363 250 504 363 253 504 minecraft:pink_terracotta
setblock 366 250 465 minecraft:red_nether_bricks
setblock 367 250 464 minecraft:red_nether_bricks
fill 367 250 465 367 253 465 minecraft:pink_terracotta
setblock 367 250 504 minecraft:red_nether_bricks
fill 368 250 464 368 253 464 minecraft:pink_terracotta
fill 368 250 466 368 251 466 minecraft:pink_terracotta
setblock 368 250 503 minecraft:red_nether_bricks
fill 368 250 504 368 253 504 minecraft:pink_terracotta
setblock 369 250 467 minecraft:red_nether_bricks
fill 369 250 468 369 253 468 minecraft:pink_terracotta
fill 369 250 470 369 251 470 minecraft:pink_terracotta
fill 369 250 484 369 250 486 minecraft:pink_terracotta
setblock 369 250 487 minecraft:red_nether_bricks
fill 369 250 488 369 253 488 minecraft:pink_terracotta
setblock 369 250 492 minecraft:red_nether_bricks
fill 369 250 493 369 253 493 minecraft:pink_terracotta
setblock 369 250 496 minecraft:pink_terracotta
setblock 369 250 497 minecraft:red_nether_bricks
fill 369 250 498 369 253 498 minecraft:pink_terracotta
setblock 369 250 502 minecraft:red_nether_bricks
fill 369 250 503 369 253 503 minecraft:pink_terracotta
setblock 370 250 466 minecraft:red_nether_bricks
fill 370 250 467 370 253 467 minecraft:pink_terracotta
setblock 370 250 471 minecraft:red_nether_bricks
fill 370 250 472 370 252 473 minecraft:pink_terracotta
setblock 370 250 480 minecraft:pink_terracotta
setblock 370 250 481 minecraft:red_nether_bricks
fill 370 250 482 370 253 482 minecraft:pink_terracotta
setblock 370 250 486 minecraft:red_nether_bricks
fill 370 250 487 370 253 487 minecraft:pink_terracotta
setblock 370 250 491 minecraft:red_nether_bricks
fill 370 250 492 370 253 492 minecraft:pink_terracotta
setblock 370 250 495 minecraft:pink_terracotta
setblock 370 250 496 minecraft:red_nether_bricks
fill 370 250 497 370 253 497 minecraft:pink_terracotta
setblock 370 250 501 minecraft:red_nether_bricks
fill 370 250 502 370 253 502 minecraft:pink_terracotta
setblock 330 251 464 minecraft:pink_terracotta
setblock 330 251 465 minecraft:red_nether_bricks
fill 330 251 466 333 251 466 minecraft:pink_terracotta
setblock 330 251 469 minecraft:pink_terracotta
setblock 330 251 470 minecraft:red_nether_bricks
fill 330 251 471 330 254 471 minecraft:pink_terracotta
setblock 330 251 474 minecraft:pink_terracotta
setblock 330 251 475 minecraft:red_nether_bricks
fill 330 251 476 330 254 476 minecraft:pink_terracotta
setblock 330 251 480 minecraft:red_nether_bricks
fill 330 251 481 330 254 481 minecraft:pink_terracotta
setblock 330 251 485 minecraft:red_nether_bricks
fill 330 251 486 330 251 489 minecraft:pink_terracotta
setblock 330 251 490 minecraft:red_nether_bricks
fill 330 251 491 330 251 494 minecraft:pink_terracotta
setblock 330 251 495 minecraft:red_nether_bricks
fill 330 251 496 330 254 496 minecraft:pink_terracotta
setblock 330 251 500 minecraft:red_nether_bricks
fill 330 251 501 330 254 501 minecraft:pink_terracotta
setblock 331 251 464 minecraft:red_nether_bricks
fill 331 251 465 331 254 465 minecraft:pink_terracotta
setblock 331 251 469 minecraft:red_nether_bricks
fill 331 251 470 332 253 470 minecraft:pink_terracotta
setblock 331 251 473 minecraft:pink_terracotta
setblock 331 251 474 minecraft:red_nether_bricks
setblock 331 251 478 minecraft:pink_terracotta
setblock 331 251 479 minecraft:red_nether_bricks
fill 331 251 480 331 254 480 minecraft:pink_terracotta
setblock 331 251 484 minecraft:red_nether_bricks
fill 331 251 485 331 251 488 minecraft:pink_terracotta
setblock 331 251 489 minecraft:red_nether_bricks
fill 331 251 490 331 251 493 minecraft:pink_terracotta
setblock 331 251 494 minecraft:red_nether_bricks
fill 331 251 495 331 254 495 minecraft:pink_terracotta
setblock 331 251 499 minecraft:red_nether_bricks
fill 331 251 500 331 252 500 minecraft:pink_terracotta
setblock 331 251 503 minecraft:pink_terracotta
setblock 331 251 504 minecraft:red_nether_bricks
fill 332 251 464 332 254 464 minecraft:pink_terracotta
setblock 332 251 467 minecraft:pink_terracotta
setblock 332 251 468 minecraft:red_nether_bricks
fill 332 251 469 332 253 469 minecraft:pink_terracotta
setblock 332 251 483 minecraft:red_nether_bricks
fill 332 251 484 332 254 484 minecraft:pink_terracotta
setblock 332 251 488 minecraft:red_nether_bricks
fill 332 251 489 332 254 489 minecraft:pink_terracotta
setblock 332 251 492 minecraft:pink_terracotta
setblock 332 251 493 minecraft:red_nether_bricks
fill 332 251 494 332 254 494 minecraft:pink_terracotta
setblock 332 251 503 minecraft:red_nether_bricks
fill 332 251 504 332 254 504 minecraft:pink_terracotta
setblock 333 251 483 minecraft:pink_terracotta
setblock 333 251 486 minecraft:pink_terracotta
setblock 333 251 487 minecraft:red_nether_bricks
fill 333 251 488 333 254 488 minecraft:pink_terracotta
setblock 333 251 492 minecraft:red_nether_bricks
fill 333 251 493 333 253 493 minecraft:pink_terracotta
setblock 333 251 503 minecraft:pink_terracotta
setblock 334 251 466 minecraft:red_nether_bricks
setblock 334 251 486 minecraft:red_nether_bricks
setblock 334 251 487 minecraft:pink_terracotta
setblock 335 251 465 minecraft:red_nether_bricks
setblock 335 251 466 minecraft:pink_terracotta
setblock 336 251 464 minecraft:red_nether_bricks
fill 336 251 465 336 252 465 minecraft:pink_terracotta
setblock 336 251 504 minecraft:red_nether_bricks
fill 337 251 464 337 253 464 minecraft:pink_terracotta
fill 337 251 492 338 273 492 minecraft:red_nether_bricks
setblock 337 251 504 minecraft:pink_terracotta
fill 338 251 493 338 273 493 minecraft:red_nether_bricks
setblock 341 251 464 minecraft:red_nether_bricks
fill 342 251 464 345 251 464 minecraft:pink_terracotta
setblock 344 251 465 minecraft:pink_terracotta
setblock 345 251 465 minecraft:red_nether_bricks
setblock 346 251 464 minecraft:red_nether_bricks
fill 346 251 465 348 251 466 minecraft:pink_terracotta
fill 347 251 464 350 251 464 minecraft:pink_terracotta
setblock 348 251 467 minecraft:red_nether_bricks
fill 348 251 504 350 251 504 minecraft:pink_terracotta
setblock 349 251 465 minecraft:pink_terracotta
setblock 349 251 466 minecraft:red_nether_bricks
fill 349 251 467 349 254 467 minecraft:pink_terracotta
setblock 350 251 465 minecraft:red_nether_bricks
fill 350 251 466 350 254 466 minecraft:pink_terracotta
setblock 351 251 464 minecraft:red_nether_bricks
fill 351 251 465 354 251 465 minecraft:pink_terracotta
setblock 351 251 468 minecraft:pink_terracotta
setblock 351 251 503 minecraft:pink_terracotta
setblock 351 251 504 minecraft:red_nether_bricks
fill 352 251 464 355 251 464 minecraft:pink_terracotta
setblock 352 251 468 minecraft:red_nether_bricks
setblock 352 251 503 minecraft:red_nether_bricks
fill 352 251 504 355 251 504 minecraft:pink_terracotta
setblock 353 251 467 minecraft:red_nether_bricks
fill 353 251 468 353 252 468 minecraft:pink_terracotta
fill 353 251 503 356 251 503 minecraft:pink_terracotta
setblock 354 251 466 minecraft:red_nether_bricks
fill 354 251 467 354 254 467 minecraft:pink_terracotta
setblock 355 251 465 minecraft:red_nether_bricks
fill 355 251 466 355 254 466 minecraft:pink_terracotta
setblock 356 251 464 minecraft:red_nether_bricks
fill 356 251 465 356 254 465 minecraft:pink_terracotta
setblock 356 251 504 minecraft:red_nether_bricks
fill 357 251 464 360 251 464 minecraft:pink_terracotta
setblock 357 251 503 minecraft:red_nether_bricks
fill 357 251 504 360 251 504 minecraft:pink_terracotta
setblock 358 251 467 minecraft:red_nether_bricks
setblock 358 251 503 minecraft:pink_terracotta
setblock 359 251 466 minecraft:red_nether_bricks
setblock 360 251 465 minecraft:red_nether_bricks
setblock 360 251 466 minecraft:pink_terracotta
setblock 361 251 464 minecraft:red_nether_bricks
fill 361 251 465 361 253 465 minecraft:pink_terracotta
setblock 361 251 504 minecraft:red_nether_bricks
fill 362 251 464 362 254 464 minecraft:pink_terracotta
fill 362 251 504 362 253 504 minecraft:pink_terracotta
setblock 365 251 465 minecraft:red_nether_bricks
setblock 366 251 464 minecraft:red_nether_bricks
fill 366 251 465 366 253 465 minecraft:pink_terracotta
setblock 366 251 504 minecraft:red_nether_bricks
fill 367 251 464 367 254 464 minecraft:pink_terracotta
setblock 367 251 503 minecraft:red_nether_bricks
fill 367 251 504 367 254 504 minecraft:pink_terracotta
fill 368 251 488 368 251 491 minecraft:pink_terracotta
setblock 368 251 492 minecraft:red_nether_bricks
fill 368 251 493 368 254 493 minecraft:pink_terracotta
fill 368 251 503 368 254 503 minecraft:pink_terracotta
setblock 369 251 466 minecraft:red_nether_bricks
fill 369 251 467 369 254 467 minecraft:pink_terracotta
fill 369 251 484 369 251 485 minecraft:pink_terracotta
setblock 369 251 486 minecraft:red_nether_bricks
fill 369 251 487 369 254 487 minecraft:pink_terracotta
setblock 369 251 490 minecraft:pink_terracotta
setblock 369 251 491 minecraft:red_nether_bricks
fill 369 251 492 369 254 492 minecraft:pink_terracotta
setblock 369 251 496 minecraft:red_nether_bricks
fill 369 251 497 369 254 497 minecraft:pink_terracotta
setblock 369 251 501 minecraft:red_nether_bricks
fill 369 251 502 369 254 502 minecraft:pink_terracotta
setblock 370 251 465 minecraft:red_nether_bricks
fill 370 251 466 370 254 466 minecraft:pink_terracotta
setblock 370 251 469 minecraft:pink_terracotta
setblock 370 251 470 minecraft:red_nether_bricks
fill 370 251 471 370 254 471 minecraft:pink_terracotta
setblock 370 251 474 minecraft:pink_terracotta
setblock 370 251 480 minecraft:red_nether_bricks
fill 370 251 481 370 254 481 minecraft:pink_terracotta
setblock 370 251 485 minecraft:red_nether_bricks
fill 370 251 486 370 254 486 minecraft:pink_terracotta
setblock 370 251 490 minecraft:red_nether_bricks
fill 370 251 491 370 254 491 minecraft:pink_terracotta
setblock 370 251 495 minecraft:red_nether_bricks
fill 370 251 496 370 254 496 minecraft:pink_terracotta
setblock 370 251 500 minecraft:red_nether_bricks
fill 370 251 501 370 254 501 minecraft:pink_terracotta
setblock 330 252 464 minecraft:red_nether_bricks
fill 330 252 465 330 254 466 minecraft:pink_terracotta
setblock 330 252 469 minecraft:red_nether_bricks
fill 330 252 470 330 255 470 minecraft:pink_terracotta
setblock 330 252 474 minecraft:red_nether_bricks
fill 330 252 475 331 254 475 minecraft:pink_terracotta
setblock 330 252 479 minecraft:red_nether_bricks
fill 330 252 480 330 255 480 minecraft:pink_terracotta
setblock 330 252 484 minecraft:red_nether_bricks
fill 330 252 485 330 252 488 minecraft:pink_terracotta
setblock 330 252 489 minecraft:red_nether_bricks
fill 330 252 490 330 252 493 minecraft:pink_terracotta
setblock 330 252 494 minecraft:red_nether_bricks
fill 330 252 495 330 255 495 minecraft:pink_terracotta
setblock 330 252 499 minecraft:red_nether_bricks
fill 330 252 500 330 255 500 minecraft:pink_terracotta
fill 330 252 502 330 252 503 minecraft:pink_terracotta
setblock 330 252 504 minecraft:red_nether_bricks
fill 331 252 464 331 255 464 minecraft:pink_terracotta
fill 331 252 466 332 252 466 minecraft:pink_terracotta
setblock 331 252 468 minecraft:red_nether_bricks
fill 331 252 469 331 255 469 minecraft:pink_terracotta
setblock 331 252 473 minecraft:red_nether_bricks
fill 331 252 474 331 255 474 minecraft:pink_terracotta
fill 331 252 476 331 252 477 minecraft:pink_terracotta
setblock 331 252 478 minecraft:red_nether_bricks
fill 331 252 479 331 254 479 minecraft:pink_terracotta
setblock 331 252 483 minecraft:red_nether_bricks
fill 331 252 484 331 252 487 minecraft:pink_terracotta
setblock 331 252 488 minecraft:red_nether_bricks
fill 331 252 489 331 252 492 minecraft:pink_terracotta
setblock 331 252 493 minecraft:red_nether_bricks
fill 331 252 494 331 255 494 minecraft:pink_terracotta
setblock 331 252 498 minecraft:red_nether_bricks
fill 331 252 499 331 253 499 minecraft:pink_terracotta
setblock 331 252 503 minecraft:red_nether_bricks
fill 331 252 504 331 254 504 minecraft:pink_terracotta
setblock 332 252 467 minecraft:red_nether_bricks
fill 332 252 468 332 253 468 minecraft:pink_terracotta
setblock 332 252 471 minecraft:pink_terracotta
setblock 332 252 482 minecraft:red_nether_bricks
fill 332 252 483 332 253 483 minecraft:pink_terracotta
setblock 332 252 487 minecraft:red_nether_bricks
fill 332 252 488 332 255 488 minecraft:pink_terracotta
setblock 332 252 492 minecraft:red_nether_bricks
fill 332 252 493 332 255 493 minecraft:pink_terracotta
setblock 333 252 466 minecraft:red_nether_bricks
setblock 333 252 486 minecraft:red_nether_bricks
fill 333 252 487 333 254 487 minecraft:pink_terracotta
setblock 333 252 491 minecraft:red_nether_bricks
fill 333 252 492 333 254 492 minecraft:pink_terracotta
setblock 334 252 465 minecraft:red_nether_bricks
setblock 335 252 464 minecraft:red_nether_bricks
fill 335 252 465 335 253 465 minecraft:pink_terracotta
setblock 335 252 504 minecraft:red_nether_bricks
fill 336 252 464 336 253 464 minecraft:pink_terracotta
fill 337 252 493 337 253 493 minecraft:red_terracotta
fill 338 252 491 338 253 491 minecraft:red_terracotta
setblock 338 252 504 minecraft:white_concrete
fill 339 252 492 339 253 492 minecraft:red_terracotta
setblock 340 252 464 minecraft:red_nether_bricks
fill 341 252 464 344 252 464 minecraft:pink_terracotta
setblock 344 252 465 minecraft:red_nether_bricks
setblock 345 252 464 minecraft:red_nether_bricks
fill 345 252 465 348 252 465 minecraft:pink_terracotta
fill 346 252 464 349 252 464 minecraft:pink_terracotta
fill 346 252 466 347 252 466 minecraft:pink_terracotta
setblock 348 252 466 minecraft:red_nether_bricks
fill 348 252 467 348 254 467 minecraft:pink_terracotta
fill 348 252 504 349 252 504 minecraft:pink_terracotta
setblock 349 252 465 minecraft:red_nether_bricks
fill 349 252 466 349 255 466 minecraft:pink_terracotta
setblock 350 252 464 minecraft:red_nether_bricks
fill 350 252 465 353 252 465 minecraft:pink_terracotta
setblock 350 252 468 minecraft:pink_terracotta
setblock 350 252 504 minecraft:red_nether_bricks
fill 351 252 464 354 252 464 minecraft:pink_terracotta
setblock 351 252 468 minecraft:red_nether_bricks
setblock 351 252 503 minecraft:red_nether_bricks
fill 351 252 504 354 252 504 minecraft:pink_terracotta
setblock 352 252 467 minecraft:red_nether_bricks
fill 352 252 468 352 253 468 minecraft:pink_terracotta
fill 352 252 503 355 252 503 minecraft:pink_terracotta
setblock 353 252 466 minecraft:red_nether_bricks
fill 353 252 467 353 254 467 minecraft:pink_terracotta
setblock 354 252 465 minecraft:red_nether_bricks
fill 354 252 466 354 255 466 minecraft:pink_terracotta
setblock 354 252 468 minecraft:pink_terracotta
setblock 355 252 464 minecraft:red_nether_bricks
fill 355 252 465 355 255 465 minecraft:pink_terracotta
setblock 355 252 504 minecraft:red_nether_bricks
fill 356 252 464 359 252 464 minecraft:pink_terracotta
setblock 356 252 503 minecraft:red_nether_bricks
fill 356 252 504 359 252 504 minecraft:pink_terracotta
setblock 357 252 467 minecraft:red_nether_bricks
setblock 358 252 466 minecraft:red_nether_bricks
setblock 359 252 465 minecraft:red_nether_bricks
setblock 359 252 466 minecraft:pink_terracotta
setblock 360 252 464 minecraft:red_nether_bricks
fill 360 252 465 360 253 465 minecraft:pink_terracotta
setblock 360 252 504 minecraft:red_nether_bricks
fill 361 252 464 361 254 464 minecraft:pink_terracotta
fill 361 252 504 361 253 504 minecraft:pink_terracotta
setblock 364 252 465 minecraft:red_nether_bricks
setblock 365 252 464 minecraft:red_nether_bricks
fill 365 252 465 365 253 465 minecraft:pink_terracotta
setblock 365 252 504 minecraft:red_nether_bricks
fill 366 252 464 366 255 464 minecraft:pink_terracotta
fill 366 252 504 366 255 504 minecraft:pink_terracotta
fill 367 252 503 367 253 503 minecraft:pink_terracotta
fill 368 252 488 368 252 490 minecraft:pink_terracotta
setblock 368 252 491 minecraft:red_nether_bricks
fill 368 252 492 368 255 492 minecraft:pink_terracotta
fill 368 252 494 369 252 494 minecraft:pink_terracotta
setblock 369 252 465 minecraft:red_nether_bricks
fill 369 252 466 369 255 466 minecraft:pink_terracotta
setblock 369 252 470 minecraft:red_nether_bricks
fill 369 252 471 369 255 471 minecraft:pink_terracotta
setblock 369 252 484 minecraft:pink_terracotta
setblock 369 252 485 minecraft:red_nether_bricks
fill 369 252 486 369 255 486 minecraft:pink_terracotta
setblock 369 252 490 minecraft:red_nether_bricks
fill 369 252 491 369 255 491 minecraft:pink_terracotta
setblock 369 252 495 minecraft:red_nether_bricks
fill 369 252 496 369 255 496 minecraft:pink_terracotta
setblock 369 252 500 minecraft:red_nether_bricks
fill 369 252 501 369 255 501 minecraft:pink_terracotta
setblock 370 252 464 minecraft:red_nether_bricks
fill 370 252 465 370 255 465 minecraft:pink_terracotta
setblock 370 252 469 minecraft:red_nether_bricks
fill 370 252 470 370 255 470 minecraft:pink_terracotta
setblock 370 252 474 minecraft:red_nether_bricks
fill 370 252 475 370 255 475 minecraft:pink_terracotta
setblock 370 252 480 minecraft:pink_terracotta
setblock 370 252 484 minecraft:red_nether_bricks
fill 370 252 485 370 255 485 minecraft:pink_terracotta
setblock 370 252 489 minecraft:red_nether_bricks
fill 370 252 490 370 255 490 minecraft:pink_terracotta
setblock 370 252 494 minecraft:red_nether_bricks
fill 370 252 495 370 255 495 minecraft:pink_terracotta
setblock 370 252 499 minecraft:red_nether_bricks
fill 370 252 500 370 255 500 minecraft:pink_terracotta
setblock 370 252 504 minecraft:red_nether_bricks
fill 330 253 464 330 255 464 minecraft:pink_terracotta
setblock 330 253 468 minecraft:red_nether_bricks
fill 330 253 469 330 256 469 minecraft:pink_terracotta
setblock 330 253 472 minecraft:pink_terracotta
setblock 330 253 473 minecraft:red_nether_bricks
fill 330 253 474 330 256 474 minecraft:pink_terracotta
setblock 330 253 478 minecraft:red_nether_bricks
fill 330 253 479 330 256 479 minecraft:pink_terracotta
setblock 330 253 483 minecraft:red_nether_bricks
fill 330 253 484 330 253 487 minecraft:pink_terracotta
setblock 330 253 488 minecraft:red_nether_bricks
fill 330 253 489 330 253 492 minecraft:pink_terracotta
setblock 330 253 493 minecraft:red_nether_bricks
fill 330 253 494 330 256 494 minecraft:pink_terracotta
setblock 330 253 498 minecraft:red_nether_bricks
fill 330 253 499 330 256 499 minecraft:pink_terracotta
setblock 330 253 502 minecraft:pink_terracotta
setblock 330 253 503 minecraft:red_nether_bricks
fill 330 253 504 330 254 504 minecraft:pink_terracotta
setblock 331 253 466 minecraft:pink_terracotta
setblock 331 253 467 minecraft:red_nether_bricks
fill 331 253 468 331 256 468 minecraft:pink_terracotta
setblock 331 253 472 minecraft:red_nether_bricks
fill 331 253 473 331 256 473 minecraft:pink_terracotta
setblock 331 253 476 minecraft:pink_terracotta
setblock 331 253 477 minecraft:red_nether_bricks
fill 331 253 478 331 256 478 minecraft:pink_terracotta
setblock 331 253 482 minecraft:red_nether_bricks
fill 331 253 483 331 253 486 minecraft:pink_terracotta
setblock 331 253 487 minecraft:red_nether_bricks
fill 331 253 488 331 253 491 minecraft:pink_terracotta
setblock 331 253 492 minecraft:red_nether_bricks
fill 331 253 493 331 256 493 minecraft:pink_terracotta
setblock 331 253 496 minecraft:pink_terracotta
setblock 331 253 497 minecraft:red_nether_bricks
fill 331 253 498 331 256 498 minecraft:pink_terracotta
setblock 332 253 471 minecraft:red_nether_bricks
setblock 332 253 482 minecraft:pink_terracotta
setblock 332 253 486 minecraft:red_nether_bricks
fill 332 253 487 332 256 487 minecraft:pink_terracotta
setblock 332 253 491 minecraft:red_nether_bricks
fill 332 253 492 332 256 492 minecraft:pink_terracotta
setblock 332 253 496 minecraft:red_nether_bricks
setblock 333 253 465 minecraft:red_nether_bricks
setblock 333 253 485 minecraft:red_nether_bricks
setblock 333 253 486 minecraft:pink_terracotta
setblock 333 253 490 minecraft:red_nether_bricks
fill 333 253 491 333 254 491 minecraft:pink_terracotta
setblock 334 253 464 minecraft:red_nether_bricks
setblock 334 253 465 minecraft:pink_terracotta
setblock 334 253 504 minecraft:red_nether_bricks
fill 335 253 464 335 254 464 minecraft:pink_terracotta
setblock 337 253 491 minecraft:red_terracotta
setblock 339 253 491 minecraft:red_terracotta
setblock 339 253 493 minecraft:red_terracotta
setblock 343 253 464 minecraft:pink_terracotta
setblock 344 253 464 minecraft:red_nether_bricks
setblock 344 253 504 minecraft:white_concrete
fill 345 253 464 347 253 465 minecraft:pink_terracotta
setblock 346 253 466 minecraft:pink_terracotta
setblock 347 253 466 minecraft:red_nether_bricks
setblock 348 253 464 minecraft:pink_terracotta
setblock 348 253 465 minecraft:red_nether_bricks
fill 348 253 466 348 256 466 minecraft:pink_terracotta
setblock 348 253 504 minecraft:pink_terracotta
setblock 349 253 464 minecraft:red_nether_bricks
fill 349 253 465 352 253 465 minecraft:pink_terracotta
setblock 349 253 504 minecraft:red_nether_bricks
fill 350 253 464 353 253 464 minecraft:pink_terracotta
fill 350 253 504 353 253 504 minecraft:pink_terracotta
setblock 351 253 467 minecraft:red_nether_bricks
setblock 351 253 468 minecraft:pink_terracotta
setblock 352 253 466 minecraft:red_nether_bricks
fill 352 253 467 352 255 467 minecraft:pink_terracotta
setblock 353 253 465 minecraft:red_nether_bricks
fill 353 253 466 353 256 466 minecraft:pink_terracotta
setblock 354 253 464 minecraft:red_nether_bricks
fill 354 253 465 354 256 465 minecraft:pink_terracotta
setblock 354 253 504 minecraft:red_nether_bricks
fill 355 253 464 358 253 464 minecraft:pink_terracotta
fill 355 253 504 358 253 504 minecraft:pink_terracotta
setblock 356 253 467 minecraft:red_nether_bricks
setblock 357 253 466 minecraft:red_nether_bricks
setblock 358 253 465 minecraft:red_nether_bricks
setblock 358 253 466 minecraft:pink_terracotta
setblock 359 253 464 minecraft:red_nether_bricks
setblock 359 253 465 minecraft:pink_terracotta
setblock 359 253 504 minecraft:red_nether_bricks
fill 360 253 464 360 254 464 minecraft:pink_terracotta
setblock 360 253 504 minecraft:pink_terracotta
setblock 364 253 464 minecraft:red_nether_bricks
setblock 364 253 504 minecraft:red_nether_bricks
fill 365 253 464 365 255 464 minecraft:pink_terracotta
fill 365 253 504 365 256 504 minecraft:pink_terracotta
setblock 368 253 465 minecraft:red_nether_bricks
fill 368 253 488 368 253 489 minecraft:pink_terracotta
setblock 368 253 490 minecraft:red_nether_bricks
fill 368 253 491 368 256 491 minecraft:pink_terracotta
setblock 368 253 494 minecraft:pink_terracotta
setblock 368 253 495 minecraft:red_nether_bricks
setblock 369 253 464 minecraft:red_nether_bricks
fill 369 253 465 369 254 465 minecraft:pink_terracotta
setblock 369 253 469 minecraft:red_nether_bricks
fill 369 253 470 369 256 470 minecraft:pink_terracotta
setblock 369 253 484 minecraft:red_nether_bricks
fill 369 253 485 369 254 485 minecraft:pink_terracotta
setblock 369 253 489 minecraft:red_nether_bricks
fill 369 253 490 369 256 490 minecraft:pink_terracotta
setblock 369 253 494 minecraft:red_nether_bricks
fill 369 253 495 369 256 495 minecraft:pink_terracotta
setblock 369 253 499 minecraft:red_nether_bricks
fill 369 253 500 369 256 500 minecraft:pink_terracotta
setblock 369 253 504 minecraft:red_nether_bricks
fill 370 253 464 370 256 464 minecraft:pink_terracotta
setblock 370 253 468 minecraft:red_nether_bricks
fill 370 253 469 370 256 469 minecraft:pink_terracotta
setblock 370 253 472 minecraft:pink_terracotta
setblock 370 253 473 minecraft:red_nether_bricks
fill 370 253 474 370 256 474 minecraft:pink_terracotta
fill 370 253 476 370 254 476 minecraft:pink_terracotta
setblock 370 253 483 minecraft:red_nether_bricks
fill 370 253 484 370 256 484 minecraft:pink_terracotta
setblock 370 253 488 minecraft:red_nether_bricks
fill 370 253 489 370 256 489 minecraft:pink_terracotta
setblock 370 253 493 minecraft:red_nether_bricks
fill 370 253 494 370 256 494 minecraft:pink_terracotta
setblock 370 253 498 minecraft:red_nether_bricks
fill 370 253 499 370 256 499 minecraft:pink_terracotta
setblock 370 253 503 minecraft:red_nether_bricks
fill 370 253 504 370 256 504 minecraft:pink_terracotta
setblock 330 254 467 minecraft:red_nether_bricks
fill 330 254 468 330 257 468 minecraft:pink_terracotta
setblock 330 254 472 minecraft:red_nether_bricks
fill 330 254 473 330 257 473 minecraft:pink_terracotta
setblock 330 254 477 minecraft:red_nether_bricks
fill 330 254 478 330 257 478 minecraft:pink_terracotta
setblock 330 254 482 minecraft:red_nether_bricks
fill 330 254 483 330 254 486 minecraft:pink_terracotta
setblock 330 254 487 minecraft:red_nether_bricks
fill 330 254 488 330 254 491 minecraft:pink_terracotta
setblock 330 254 492 minecraft:red_nether_bricks
fill 330 254 493 330 257 493 minecraft:pink_terracotta
setblock 330 254 497 minecraft:red_nether_bricks
fill 330 254 498 330 257 498 minecraft:pink_terracotta
setblock 330 254 502 minecraft:red_nether_bricks
setblock 330 254 503 minecraft:pink_terracotta
setblock 331 254 466 minecraft:red_nether_bricks
fill 331 254 467 331 255 467 minecraft:pink_terracotta
setblock 331 254 470 minecraft:pink_terracotta
setblock 331 254 471 minecraft:red_nether_bricks
fill 331 254 472 331 257 472 minecraft:pink_terracotta
setblock 331 254 476 minecraft:red_nether_bricks
fill 331 254 477 331 257 477 minecraft:pink_terracotta
setblock 331 254 481 minecraft:red_nether_bricks
fill 331 254 482 331 254 485 minecraft:pink_terracotta
setblock 331 254 486 minecraft:red_nether_bricks
fill 331 254 487 331 254 490 minecraft:pink_terracotta
setblock 331 254 491 minecraft:red_nether_bricks
fill 331 254 492 331 257 492 minecraft:pink_terracotta
setblock 331 254 496 minecraft:red_nether_bricks
fill 331 254 497 331 257 497 minecraft:pink_terracotta
setblock 332 254 465 minecraft:red_nether_bricks
setblock 332 254 470 minecraft:red_nether_bricks
setblock 332 254 471 minecraft:pink_terracotta
setblock 332 254 485 minecraft:red_nether_bricks
fill 332 254 486 332 255 486 minecraft:pink_terracotta
setblock 332 254 490 minecraft:red_nether_bricks
fill 332 254 491 332 257 491 minecraft:pink_terracotta
setblock 332 254 495 minecraft:red_nether_bricks
setblock 333 254 464 minecraft:red_nether_bricks
setblock 333 254 489 minecraft:red_nether_bricks
setblock 333 254 490 minecraft:pink_terracotta
setblock 334 254 464 minecraft:pink_terracotta
fill 344 254 464 347 254 464 minecraft:pink_terracotta
fill 345 254 465 346 254 465 minecraft:pink_terracotta
setblock 346 254 466 minecraft:red_nether_bricks
setblock 347 254 465 minecraft:red_nether_bricks
fill 347 254 466 347 256 466 minecraft:pink_terracotta
setblock 348 254 464 minecraft:red_nether_bricks
fill 348 254 465 351 254 465 minecraft:pink_terracotta
setblock 348 254 504 minecraft:red_nether_bricks
fill 349 254 464 352 254 464 minecraft:pink_terracotta
fill 349 254 504 352 254 504 minecraft:pink_terracotta
setblock 350 254 467 minecraft:red_nether_bricks
setblock 351 254 466 minecraft:red_nether_bricks
fill 351 254 467 351 255 467 minecraft:pink_terracotta
setblock 352 254 465 minecraft:red_nether_bricks
fill 352 254 466 352 256 466 minecraft:pink_terracotta
setblock 353 254 464 minecraft:red_nether_bricks
fill 353 254 465 353 257 465 minecraft:pink_terracotta
setblock 353 254 504 minecraft:red_nether_bricks
fill 354 254 464 357 254 464 minecraft:pink_terracotta
fill 354 254 504 357 254 504 minecraft:pink_terracotta
setblock 356 254 466 minecraft:red_nether_bricks
setblock 357 254 465 minecraft:red_nether_bricks
setblock 358 254 464 minecraft:red_nether_bricks
setblock 358 254 465 minecraft:pink_terracotta
setblock 358 254 504 minecraft:red_nether_bricks
fill 359 254 464 359 255 464 minecraft:pink_terracotta
setblock 363 254 464 minecraft:red_nether_bricks
fill 364 254 464 364 255 464 minecraft:pink_terracotta
setblock 364 254 504 minecraft:pink_terracotta
setblock 367 254 465 minecraft:red_nether_bricks
setblock 368 254 464 minecraft:red_nether_bricks
setblock 368 254 465 minecraft:pink_terracotta
setblock 368 254 488 minecraft:pink_terracotta
setblock 368 254 489 minecraft:red_nether_bricks
fill 368 254 490 368 257 490 minecraft:pink_terracotta
setblock 368 254 494 minecraft:red_nether_bricks
fill 368 254 495 368 256 496 minecraft:pink_terracotta
setblock 368 254 504 minecraft:red_nether_bricks
fill 369 254 464 369 257 464 minecraft:pink_terracotta
setblock 369 254 468 minecraft:red_nether_bricks
fill 369 254 469 369 257 469 minecraft:pink_terracotta
setblock 369 254 472 minecraft:pink_terracotta
setblock 369 254 488 minecraft:red_nether_bricks
fill 369 254 489 369 257 489 minecraft:pink_terracotta
setblock 369 254 493 minecraft:red_nether_bricks
fill 369 254 494 369 257 494 minecraft:pink_terracotta
setblock 369 254 498 minecraft:red_nether_bricks
fill 369 254 499 369 257 499 minecraft:pink_terracotta
setblock 369 254 503 minecraft:red_nether_bricks
fill 369 254 504 369 257 504 minecraft:pink_terracotta
setblock 370 254 467 minecraft:red_nether_bricks
fill 370 254 468 370 257 468 minecraft:pink_terracotta
setblock 370 254 472 minecraft:red_nether_bricks
fill 370 254 473 370 257 473 minecraft:pink_terracotta
setblock 370 254 482 minecraft:red_nether_bricks
fill 370 254 483 370 257 483 minecraft:pink_terracotta
setblock 370 254 487 minecraft:red_nether_bricks
fill 370 254 488 370 257 488 minecraft:pink_terracotta
setblock 370 254 492 minecraft:red_nether_bricks
fill 370 254 493 370 257 493 minecraft:pink_terracotta
setblock 370 254 497 minecraft:red_nether_bricks
fill 370 254 498 370 257 498 minecraft:pink_terracotta
setblock 370 254 502 minecraft:red_nether_bricks
fill 370 254 503 370 257 503 minecraft:pink_terracotta
setblock 330 255 465 minecraft:pink_terracotta
setblock 330 255 466 minecraft:red_nether_bricks
fill 330 255 467 330 258 467 minecraft:pink_terracotta
setblock 330 255 471 minecraft:red_nether_bricks
fill 330 255 472 330 258 472 minecraft:pink_terracotta
setblock 330 255 475 minecraft:pink_terracotta
setblock 330 255 476 minecraft:red_nether_bricks
fill 330 255 477 330 258 477 minecraft:pink_terracotta
setblock 330 255 481 minecraft:red_nether_bricks
fill 330 255 482 330 255 485 minecraft:pink_terracotta
setblock 330 255 486 minecraft:red_nether_bricks
fill 330 255 487 330 255 490 minecraft:pink_terracotta
setblock 330 255 491 minecraft:red_nether_bricks
fill 330 255 492 330 258 492 minecraft:pink_terracotta
setblock 330 255 496 minecraft:red_nether_bricks
fill 330 255 497 330 258 497 minecraft:pink_terracotta
setblock 330 255 501 minecraft:red_nether_bricks
setblock 330 255 502 minecraft:pink_terracotta
setblock 331 255 470 minecraft:red_nether_bricks
fill 331 255 471 331 258 471 minecraft:pink_terracotta
setblock 331 255 475 minecraft:red_nether_bricks
fill 331 255 476 331 258 476 minecraft:pink_terracotta
setblock 331 255 480 minecraft:red_nether_bricks
fill 331 255 481 331 255 484 minecraft:pink_terracotta
setblock 331 255 485 minecraft:red_nether_bricks
fill 331 255 486 331 255 489 minecraft:pink_terracotta
setblock 331 255 490 minecraft:red_nether_bricks
fill 331 255 491 331 258 491 minecraft:pink_terracotta
setblock 331 255 495 minecraft:red_nether_bricks
fill 331 255 496 331 258 496 minecraft:pink_terracotta
setblock 332 255 464 minecraft:red_nether_bricks
setblock 332 255 485 minecraft:pink_terracotta
setblock 332 255 489 minecraft:red_nether_bricks
fill 332 255 490 332 257 490 minecraft:pink_terracotta
setblock 332 255 494 minecraft:red_nether_bricks
fill 332 255 495 332 256 495 minecraft:pink_terracotta
setblock 337 255 504 minecraft:white_concrete
setblock 338 255 464 minecraft:white_concrete
fill 344 255 464 346 255 464 minecraft:pink_terracotta
setblock 345 255 465 minecraft:pink_terracotta
setblock 346 255 465 minecraft:red_nether_bricks
setblock 347 255 464 minecraft:red_nether_bricks
fill 347 255 465 350 255 465 minecraft:pink_terracotta
fill 348 255 464 351 255 464 minecraft:pink_terracotta
setblock 349 255 467 minecraft:red_nether_bricks
fill 349 255 504 351 255 504 minecraft:pink_terracotta
setblock 350 255 466 minecraft:red_nether_bricks
setblock 350 255 467 minecraft:pink_terracotta
setblock 351 255 465 minecraft:red_nether_bricks
fill 351 255 466 351 257 466 minecraft:pink_terracotta
setblock 352 255 464 minecraft:red_nether_bricks
fill 352 255 465 352 258 465 minecraft:pink_terracotta
setblock 352 255 504 minecraft:red_nether_bricks
fill 353 255 464 356 255 464 minecraft:pink_terracotta
fill 353 255 504 355 255 504 minecraft:pink_terracotta
setblock 355 255 466 minecraft:red_nether_bricks
setblock 356 255 465 minecraft:red_nether_bricks
setblock 356 255 504 minecraft:white_concrete
setblock 357 255 464 minecraft:red_nether_bricks
setblock 357 255 465 minecraft:pink_terracotta
setblock 358 255 464 minecraft:pink_terracotta
fill 362 255 504 362 256 504 minecraft:white_concrete
setblock 363 255 464 minecraft:white_concrete
setblock 367 255 464 minecraft:red_nether_bricks
setblock 367 255 504 minecraft:red_nether_bricks
fill 368 255 464 368 257 464 minecraft:pink_terracotta
fill 368 255 489 368 258 489 minecraft:pink_terracotta
setblock 368 255 493 minecraft:red_nether_bricks
fill 368 255 494 368 258 494 minecraft:pink_terracotta
setblock 368 255 497 minecraft:pink_terracotta
fill 368 255 504 368 258 504 minecraft:pink_terracotta
setblock 369 255 467 minecraft:red_nether_bricks
fill 369 255 468 369 256 468 minecraft:pink_terracotta
setblock 369 255 472 minecraft:red_nether_bricks
fill 369 255 479 369 260 479 minecraft:white_concrete
setblock 369 255 487 minecraft:red_nether_bricks
fill 369 255 488 369 258 488 minecraft:pink_terracotta
setblock 369 255 492 minecraft:red_nether_bricks
fill 369 255 493 369 258 493 minecraft:pink_terracotta
setblock 369 255 497 minecraft:red_nether_bricks
fill 369 255 498 369 258 498 minecraft:pink_terracotta
setblock 369 255 502 minecraft:red_nether_bricks
setblock 369 255 503 minecraft:pink_terracotta
setblock 370 255 466 minecraft:red_nether_bricks
fill 370 255 467 370 258 467 minecraft:pink_terracotta
setblock 370 255 471 minecraft:red_nether_bricks
fill 370 255 472 370 258 472 minecraft:pink_terracotta
setblock 370 255 476 minecraft:red_nether_bricks
setblock 370 255 482 minecraft:pink_terracotta
setblock 370 255 486 minecraft:red_nether_bricks
fill 370 255 487 370 258 487 minecraft:pink_terracotta
setblock 370 255 491 minecraft:red_nether_bricks
fill 370 255 492 370 258 492 minecraft:pink_terracotta
setblock 370 255 496 minecraft:red_nether_bricks
fill 370 255 497 370 258 497 minecraft:pink_terracotta
setblock 370 255 501 minecraft:red_nether_bricks
fill 370 255 502 370 258 502 minecraft:pink_terracotta
setblock 330 256 465 minecraft:red_nether_bricks
fill 330 256 466 330 257 466 minecraft:pink_terracotta
setblock 330 256 470 minecraft:red_nether_bricks
fill 330 256 471 330 259 471 minecraft:pink_terracotta
setblock 330 256 475 minecraft:red_nether_bricks
fill 330 256 476 330 259 476 minecraft:pink_terracotta
setblock 330 256 480 minecraft:red_nether_bricks
fill 330 256 481 330 256 484 minecraft:pink_terracotta
setblock 330 256 485 minecraft:red_nether_bricks
fill 330 256 486 330 256 489 minecraft:pink_terracotta
setblock 330 256 490 minecraft:red_nether_bricks
fill 330 256 491 330 259 491 minecraft:pink_terracotta
setblock 330 256 495 minecraft:red_nether_bricks
fill 330 256 496 330 259 496 minecraft:pink_terracotta
setblock 330 256 500 minecraft:red_nether_bricks
setblock 330 256 501 minecraft:pink_terracotta
setblock 331 256 469 minecraft:red_nether_bricks
fill 331 256 470 331 259 470 minecraft:pink_terracotta
setblock 331 256 474 minecraft:red_nether_bricks
fill 331 256 475 331 259 475 minecraft:pink_terracotta
fill 331 256 482 331 256 483 minecraft:pink_terracotta
setblock 331 256 484 minecraft:red_nether_bricks
fill 331 256 485 331 256 488 minecraft:pink_terracotta
setblock 331 256 489 minecraft:red_nether_bricks
fill 331 256 490 331 259 490 minecraft:pink_terracotta
setblock 331 256 494 minecraft:red_nether_bricks
fill 331 256 495 331 259 495 minecraft:pink_terracotta
setblock 332 256 464 minecraft:white_concrete
setblock 332 256 488 minecraft:red_nether_bricks
fill 332 256 489 332 257 489 minecraft:pink_terracotta
setblock 332 256 493 minecraft:red_nether_bricks
fill 332 256 494 332 257 494 minecraft:pink_terracotta
setblock 343 256 504 minecraft:white_concrete
setblock 345 256 464 minecraft:pink_terracotta
setblock 346 256 464 minecraft:red_nether_bricks
fill 346 256 465 349 256 465 minecraft:pink_terracotta
fill 347 256 464 350 256 464 minecraft:pink_terracotta
setblock 349 256 466 minecraft:red_nether_bricks
fill 349 256 504 350 256 504 minecraft:pink_terracotta
setblock 350 256 465 minecraft:red_nether_bricks
fill 350 256 466 350 258 466 minecraft:pink_terracotta
setblock 351 256 464 minecraft:red_nether_bricks
fill 351 256 465 351 259 465 minecraft:pink_terracotta
setblock 351 256 504 minecraft:red_nether_bricks
fill 352 256 464 355 256 464 minecraft:pink_terracotta
fill 352 256 504 354 256 504 minecraft:pink_terracotta
setblock 355 256 465 minecraft:red_nether_bricks
setblock 356 256 464 minecraft:red_nether_bricks
setblock 357 256 464 minecraft:pink_terracotta
setblock 366 256 464 minecraft:red_nether_bricks
setblock 366 256 504 minecraft:red_nether_bricks
setblock 367 256 464 minecraft:pink_terracotta
fill 367 256 479 368 259 479 minecraft:white_concrete
fill 367 256 504 367 259 504 minecraft:pink_terracotta
fill 368 256 478 370 256 478 minecraft:white_concrete
fill 368 256 480 370 257 480 minecraft:white_concrete
setblock 368 256 492 minecraft:red_nether_bricks
fill 368 256 493 368 259 493 minecraft:pink_terracotta
setblock 368 256 497 minecraft:red_nether_bricks
setblock 369 256 471 minecraft:red_nether_bricks
fill 369 256 472 369 259 472 minecraft:pink_terracotta
fill 369 256 477 369 259 477 minecraft:white_concrete
fill 369 256 481 369 259 481 minecraft:white_concrete
setblock 369 256 486 minecraft:red_nether_bricks
fill 369 256 487 369 259 487 minecraft:pink_terracotta
setblock 369 256 491 minecraft:red_nether_bricks
fill 369 256 492 369 259 492 minecraft:pink_terracotta
setblock 369 256 496 minecraft:red_nether_bricks
fill 369 256 497 369 259 497 minecraft:pink_terracotta
setblock 369 256 501 minecraft:red_nether_bricks
setblock 370 256 465 minecraft:red_nether_bricks
fill 370 256 466 370 258 466 minecraft:pink_terracotta
setblock 370 256 470 minecraft:red_nether_bricks
fill 370 256 471 370 259 471 minecraft:pink_terracotta
setblock 370 256 475 minecraft:red_nether_bricks
fill 370 256 476 370 258 477 minecraft:pink_terracotta
fill 370 256 479 370 257 479 minecraft:white_concrete
setblock 370 256 485 minecraft:red_nether_bricks
fill 370 256 486 370 259 486 minecraft:pink_terracotta
setblock 370 256 490 minecraft:red_nether_bricks
fill 370 256 491 370 259 491 minecraft:pink_terracotta
setblock 370 256 495 minecraft:red_nether_bricks
fill 370 256 496 370 259 496 minecraft:pink_terracotta
setblock 370 256 500 minecraft:red_nether_bricks
fill 370 256 501 370 259 501 minecraft:pink_terracotta
setblock 330 257 469 minecraft:red_nether_bricks
fill 330 257 470 330 260 470 minecraft:pink_terracotta
setblock 330 257 474 minecraft:red_nether_bricks
fill 330 257 475 330 260 475 minecraft:pink_terracotta
setblock 330 257 479 minecraft:red_nether_bricks
fill 330 257 480 330 257 483 minecraft:pink_terracotta
setblock 330 257 484 minecraft:red_nether_bricks
fill 330 257 485 330 257 488 minecraft:pink_terracotta
setblock 330 257 489 minecraft:red_nether_bricks
fill 330 257 490 330 260 490 minecraft:pink_terracotta
setblock 330 257 494 minecraft:red_nether_bricks
fill 330 257 495 330 260 495 minecraft:pink_terracotta
setblock 330 257 499 minecraft:red_nether_bricks
fill 330 257 500 330 260 500 minecraft:pink_terracotta
setblock 330 257 504 minecraft:white_concrete
fill 331 257 469 331 258 469 minecraft:pink_terracotta
setblock 331 257 473 minecraft:red_nether_bricks
fill 331 257 474 331 260 474 minecraft:pink_terracotta
setblock 331 257 478 minecraft:red_nether_bricks
fill 331 257 484 331 257 487 minecraft:pink_terracotta
setblock 331 257 488 minecraft:red_nether_bricks
fill 331 257 489 331 260 489 minecraft:pink_terracotta
setblock 331 257 493 minecraft:red_nether_bricks
fill 331 257 494 331 260 494 minecraft:pink_terracotta
setblock 332 257 466 minecraft:light[level=12]
setblock 332 257 474 minecraft:light[level=12]
setblock 332 257 482 minecraft:light[level=12]
setblock 332 257 492 minecraft:red_nether_bricks
fill 332 257 493 332 258 493 minecraft:pink_terracotta
setblock 332 257 498 minecraft:light[level=12]
setblock 340 257 466 minecraft:light[level=12]
setblock 340 257 474 minecraft:light[level=12]
setblock 340 257 482 minecraft:light[level=12]
setblock 340 257 490 minecraft:light[level=12]
setblock 340 257 498 minecraft:light[level=12]
setblock 345 257 464 minecraft:red_nether_bricks
fill 346 257 464 348 257 465 minecraft:pink_terracotta
setblock 348 257 466 minecraft:red_nether_bricks
setblock 348 257 474 minecraft:light[level=12]
setblock 348 257 482 minecraft:light[level=12]
setblock 348 257 490 minecraft:light[level=12]
setblock 348 257 498 minecraft:light[level=12]
setblock 349 257 464 minecraft:pink_terracotta
setblock 349 257 465 minecraft:red_nether_bricks
fill 349 257 466 349 258 466 minecraft:pink_terracotta
setblock 349 257 504 minecraft:pink_terracotta
setblock 350 257 464 minecraft:red_nether_bricks
fill 350 257 465 350 260 465 minecraft:pink_terracotta
setblock 350 257 504 minecraft:red_nether_bricks
fill 351 257 464 354 257 464 minecraft:pink_terracotta
fill 351 257 504 353 257 504 minecraft:pink_terracotta
setblock 354 257 465 minecraft:red_nether_bricks
setblock 355 257 464 minecraft:red_nether_bricks
setblock 356 257 464 minecraft:pink_terracotta
setblock 356 257 466 minecraft:light[level=12]
setblock 356 257 474 minecraft:light[level=12]
setblock 356 257 482 minecraft:light[level=12]
setblock 356 257 490 minecraft:light[level=12]
setblock 356 257 498 minecraft:light[level=12]
setblock 364 257 466 minecraft:light[level=12]
setblock 364 257 474 minecraft:light[level=12]
setblock 364 257 482 minecraft:light[level=12]
setblock 364 257 490 minecraft:light[level=12]
setblock 364 257 498 minecraft:light[level=12]
setblock 365 257 504 minecraft:red_nether_bricks
fill 366 257 504 366 260 504 minecraft:pink_terracotta
fill 367 257 478 369 258 478 minecraft:white_concrete
fill 367 257 480 367 258 480 minecraft:white_concrete
fill 368 257 477 368 258 477 minecraft:white_concrete
fill 368 257 481 368 258 481 minecraft:white_concrete
setblock 368 257 491 minecraft:red_nether_bricks
fill 368 257 492 368 260 492 minecraft:pink_terracotta
setblock 368 257 495 minecraft:pink_terracotta
setblock 368 257 496 minecraft:red_nether_bricks
fill 368 257 497 368 259 498 minecraft:pink_terracotta
setblock 369 257 470 minecraft:red_nether_bricks
fill 369 257 471 369 260 471 minecraft:pink_terracotta
fill 369 257 473 369 258 473 minecraft:pink_terracotta
setblock 369 257 486 minecraft:pink_terracotta
setblock 369 257 490 minecraft:red_nether_bricks
fill 369 257 491 369 260 491 minecraft:pink_terracotta
setblock 369 257 495 minecraft:red_nether_bricks
fill 369 257 496 369 260 496 minecraft:pink_terracotta
setblock 369 257 500 minecraft:red_nether_bricks
fill 369 257 501 369 260 501 minecraft:pink_terracotta
setblock 370 257 464 minecraft:white_concrete
setblock 370 257 465 minecraft:pink_terracotta
setblock 370 257 469 minecraft:red_nether_bricks
fill 370 257 470 370 260 470 minecraft:pink_terracotta
setblock 370 257 474 minecraft:red_nether_bricks
fill 370 257 475 370 260 475 minecraft:pink_terracotta
setblock 370 257 478 minecraft:pink_terracotta
fill 370 257 481 370 258 481 minecraft:white_concrete
setblock 370 257 484 minecraft:red_nether_bricks
fill 370 257 485 370 260 485 minecraft:pink_terracotta
setblock 370 257 489 minecraft:red_nether_bricks
fill 370 257 490 370 260 490 minecraft:pink_terracotta
setblock 370 257 494 minecraft:red_nether_bricks
fill 370 257 495 370 260 495 minecraft:pink_terracotta
setblock 370 257 499 minecraft:red_nether_bricks
fill 370 257 500 370 260 500 minecraft:pink_terracotta
setblock 370 257 504 minecraft:red_nether_bricks
setblock 330 258 466 minecraft:white_concrete
setblock 330 258 468 minecraft:red_nether_bricks
fill 330 258 469 330 261 469 minecraft:pink_terracotta
setblock 330 258 473 minecraft:red_nether_bricks
fill 330 258 474 330 261 474 minecraft:pink_terracotta
setblock 330 258 478 minecraft:red_nether_bricks
fill 330 258 479 330 258 482 minecraft:pink_terracotta
setblock 330 258 483 minecraft:red_nether_bricks
fill 330 258 484 330 258 487 minecraft:pink_terracotta
setblock 330 258 488 minecraft:red_nether_bricks
fill 330 258 489 330 261 489 minecraft:pink_terracotta
setblock 330 258 493 minecraft:red_nether_bricks
fill 330 258 494 330 261 494 minecraft:pink_terracotta
setblock 330 258 498 minecraft:red_nether_bricks
fill 330 258 499 330 261 499 minecraft:pink_terracotta
setblock 331 258 472 minecraft:red_nether_bricks
fill 331 258 473 331 261 473 minecraft:pink_terracotta
setblock 331 258 477 minecraft:red_nether_bricks
fill 331 258 478 331 260 479 minecraft:pink_terracotta
fill 331 258 485 331 258 486 minecraft:pink_terracotta
setblock 331 258 487 minecraft:red_nether_bricks
fill 331 258 488 331 261 488 minecraft:pink_terracotta
setblock 331 258 492 minecraft:red_nether_bricks
fill 331 258 493 331 261 493 minecraft:pink_terracotta
setblock 331 258 497 minecraft:red_nether_bricks
setblock 332 258 491 minecraft:red_nether_bricks
setblock 332 258 492 minecraft:pink_terracotta
setblock 336 258 504 minecraft:white_concrete
setblock 344 258 464 minecraft:red_nether_bricks
fill 345 258 464 348 258 464 minecraft:pink_terracotta
fill 346 258 465 347 258 465 minecraft:pink_terracotta
setblock 348 258 465 minecraft:red_nether_bricks
setblock 348 258 466 minecraft:pink_terracotta
setblock 348 258 504 minecraft:pink_terracotta
setblock 349 258 464 minecraft:red_nether_bricks
fill 349 258 465 349 261 465 minecraft:pink_terracotta
setblock 349 258 504 minecraft:red_nether_bricks
fill 350 258 464 353 258 464 minecraft:pink_terracotta
fill 350 258 504 352 259 504 minecraft:pink_terracotta
setblock 354 258 464 minecraft:red_nether_bricks
setblock 355 258 504 minecraft:white_concrete
setblock 364 258 464 minecraft:white_concrete
fill 365 258 504 365 261 504 minecraft:pink_terracotta
setblock 366 258 479 minecraft:black_concrete
fill 367 258 494 367 258 495 minecraft:pink_terracotta
fill 368 258 480 369 259 480 minecraft:white_concrete
setblock 368 258 490 minecraft:red_nether_bricks
fill 368 258 491 368 261 491 minecraft:pink_terracotta
setblock 368 258 495 minecraft:red_nether_bricks
fill 368 258 496 368 261 496 minecraft:pink_terracotta
setblock 368 258 499 minecraft:pink_terracotta
setblock 369 258 470 minecraft:pink_terracotta
setblock 369 258 474 minecraft:red_nether_bricks
setblock 369 258 489 minecraft:red_nether_bricks
fill 369 258 490 369 261 490 minecraft:pink_terracotta
setblock 369 258 494 minecraft:red_nether_bricks
fill 369 258 495 369 261 495 minecraft:pink_terracotta
setblock 369 258 499 minecraft:red_nether_bricks
fill 369 258 500 369 261 500 minecraft:pink_terracotta
setblock 369 258 504 minecraft:red_nether_bricks
setblock 370 258 468 minecraft:red_nether_bricks
fill 370 258 469 370 261 469 minecraft:pink_terracotta
setblock 370 258 473 minecraft:red_nether_bricks
fill 370 258 474 370 261 474 minecraft:pink_terracotta
setblock 370 258 478 minecraft:red_nether_bricks
fill 370 258 479 370 260 480 minecraft:pink_terracotta
setblock 370 258 482 minecraft:pink_terracotta
setblock 370 258 483 minecraft:red_nether_bricks
fill 370 258 484 370 261 484 minecraft:pink_terracotta
setblock 370 258 488 minecraft:red_nether_bricks
fill 370 258 489 370 261 489 minecraft:pink_terracotta
setblock 370 258 493 minecraft:red_nether_bricks
fill 370 258 494 370 261 494 minecraft:pink_terracotta
setblock 370 258 498 minecraft:red_nether_bricks
fill 370 258 499 370 261 499 minecraft:pink_terracotta
setblock 370 258 503 minecraft:red_nether_bricks
fill 370 258 504 370 261 504 minecraft:pink_terracotta
setblock 330 259 467 minecraft:red_nether_bricks
fill 330 259 468 330 262 468 minecraft:pink_terracotta
setblock 330 259 472 minecraft:red_nether_bricks
fill 330 259 473 330 262 473 minecraft:pink_terracotta
setblock 330 259 477 minecraft:red_nether_bricks
fill 330 259 478 330 259 481 minecraft:pink_terracotta
setblock 330 259 482 minecraft:red_nether_bricks
fill 330 259 483 330 259 486 minecraft:pink_terracotta
setblock 330 259 487 minecraft:red_nether_bricks
fill 330 259 488 330 262 488 minecraft:pink_terracotta
setblock 330 259 492 minecraft:red_nether_bricks
fill 330 259 493 330 262 493 minecraft:pink_terracotta
setblock 330 259 497 minecraft:red_nether_bricks
fill 330 259 498 331 261 498 minecraft:pink_terracotta
setblock 330 259 501 minecraft:pink_terracotta
setblock 331 259 471 minecraft:red_nether_bricks
fill 331 259 472 331 262 472 minecraft:pink_terracotta
setblock 331 259 476 minecraft:red_nether_bricks
fill 331 259 477 331 262 477 minecraft:pink_terracotta
setblock 331 259 480 minecraft:pink_terracotta
setblock 331 259 486 minecraft:red_nether_bricks
fill 331 259 487 331 260 487 minecraft:pink_terracotta
setblock 331 259 491 minecraft:red_nether_bricks
fill 331 259 492 331 262 492 minecraft:pink_terracotta
setblock 331 259 496 minecraft:red_nether_bricks
fill 331 259 497 331 262 497 minecraft:pink_terracotta
setblock 339 259 464 minecraft:white_concrete
setblock 342 259 504 minecraft:white_concrete
fill 344 259 464 347 259 464 minecraft:pink_terracotta
setblock 346 259 465 minecraft:pink_terracotta
fill 346 259 473 347 260 473 minecraft:red_concrete
setblock 347 259 465 minecraft:red_nether_bricks
setblock 347 259 504 minecraft:pink_terracotta
setblock 348 259 464 minecraft:red_nether_bricks
fill 348 259 465 348 262 465 minecraft:pink_terracotta
setblock 348 259 504 minecraft:red_nether_bricks
fill 349 259 464 352 259 464 minecraft:pink_terracotta
fill 349 259 504 349 262 504 minecraft:pink_terracotta
setblock 352 259 465 minecraft:red_nether_bricks
setblock 353 259 464 minecraft:red_nether_bricks
setblock 354 259 464 minecraft:pink_terracotta
setblock 358 259 464 minecraft:white_concrete
setblock 361 259 504 minecraft:white_concrete
fill 364 259 504 364 262 504 minecraft:pink_terracotta
fill 367 259 493 367 259 494 minecraft:pink_terracotta
setblock 367 259 495 minecraft:red_nether_bricks
fill 367 259 496 367 262 496 minecraft:pink_terracotta
fill 368 259 478 369 259 478 minecraft:white_concrete
setblock 368 259 489 minecraft:red_nether_bricks
fill 368 259 490 368 262 490 minecraft:pink_terracotta
setblock 368 259 494 minecraft:red_nether_bricks
fill 368 259 495 368 262 495 minecraft:pink_terracotta
setblock 368 259 499 minecraft:red_nether_bricks
fill 368 259 500 368 262 500 minecraft:pink_terracotta
setblock 368 259 504 minecraft:red_nether_bricks
setblock 369 259 473 minecraft:red_nether_bricks
fill 369 259 474 369 260 476 minecraft:pink_terracotta
setblock 369 259 488 minecraft:red_nether_bricks
fill 369 259 489 369 262 489 minecraft:pink_terracotta
setblock 369 259 493 minecraft:red_nether_bricks
fill 369 259 494 369 262 494 minecraft:pink_terracotta
setblock 369 259 498 minecraft:red_nether_bricks
fill 369 259 499 369 262 499 minecraft:pink_terracotta
setblock 369 259 502 minecraft:pink_terracotta
fill 369 259 504 369 262 504 minecraft:pink_terracotta
setblock 370 259 467 minecraft:red_nether_bricks
fill 370 259 468 370 261 468 minecraft:pink_terracotta
setblock 370 259 472 minecraft:red_nether_bricks
fill 370 259 473 370 262 473 minecraft:pink_terracotta
setblock 370 259 476 minecraft:pink_terracotta
setblock 370 259 477 minecraft:red_nether_bricks
fill 370 259 478 370 262 478 minecraft:pink_terracotta
setblock 370 259 481 minecraft:pink_terracotta
setblock 370 259 482 minecraft:red_nether_bricks
fill 370 259 483 370 262 483 minecraft:pink_terracotta
setblock 370 259 487 minecraft:red_nether_bricks
fill 370 259 488 370 262 488 minecraft:pink_terracotta
setblock 370 259 492 minecraft:red_nether_bricks
fill 370 259 493 370 262 493 minecraft:pink_terracotta
setblock 370 259 497 minecraft:red_nether_bricks
fill 370 259 498 370 262 498 minecraft:pink_terracotta
setblock 370 259 502 minecraft:red_nether_bricks
fill 370 259 503 370 262 503 minecraft:pink_terracotta
fill 330 260 467 330 262 467 minecraft:pink_terracotta
setblock 330 260 471 minecraft:red_nether_bricks
fill 330 260 472 330 263 472 minecraft:pink_terracotta
setblock 330 260 476 minecraft:red_nether_bricks
fill 330 260 477 330 260 480 minecraft:pink_terracotta
setblock 330 260 481 minecraft:red_nether_bricks
fill 330 260 482 330 260 485 minecraft:pink_terracotta
setblock 330 260 486 minecraft:red_nether_bricks
fill 330 260 487 330 263 487 minecraft:pink_terracotta
setblock 330 260 491 minecraft:red_nether_bricks
fill 330 260 492 330 263 492 minecraft:pink_terracotta
setblock 330 260 496 minecraft:red_nether_bricks
fill 330 260 497 330 263 497 minecraft:pink_terracotta
setblock 330 260 501 minecraft:red_nether_bricks
setblock 331 260 470 minecraft:red_nether_bricks
fill 331 260 471 331 263 471 minecraft:pink_terracotta
setblock 331 260 475 minecraft:red_nether_bricks
fill 331 260 476 332 262 476 minecraft:pink_terracotta
setblock 331 260 480 minecraft:red_nether_bricks
fill 331 260 481 331 262 482 minecraft:pink_terracotta
setblock 331 260 490 minecraft:red_nether_bricks
fill 331 260 491 331 263 491 minecraft:pink_terracotta
setblock 331 260 495 minecraft:red_nether_bricks
fill 331 260 496 331 263 496 minecraft:pink_terracotta
setblock 332 260 474 minecraft:red_nether_bricks
fill 332 260 475 332 263 475 minecraft:pink_terracotta
fill 332 260 480 332 263 480 minecraft:white_concrete
setblock 333 260 464 minecraft:white_concrete
fill 343 260 464 346 260 464 minecraft:pink_terracotta
setblock 345 260 465 minecraft:pink_terracotta
setblock 346 260 465 minecraft:red_nether_bricks
setblock 346 260 504 minecraft:pink_terracotta
setblock 347 260 464 minecraft:red_nether_bricks
fill 347 260 465 347 263 465 minecraft:pink_terracotta
setblock 347 260 504 minecraft:red_nether_bricks
fill 348 260 464 351 260 464 minecraft:pink_terracotta
fill 348 260 504 348 263 504 minecraft:pink_terracotta
fill 350 260 504 351 260 504 minecraft:pink_terracotta
setblock 351 260 465 minecraft:red_nether_bricks
setblock 352 260 464 minecraft:red_nether_bricks
setblock 352 260 504 minecraft:red_nether_bricks
fill 353 260 464 353 263 464 minecraft:pink_terracotta
fill 353 260 504 353 263 504 minecraft:pink_terracotta
setblock 362 260 504 minecraft:red_nether_bricks
fill 363 260 504 363 263 504 minecraft:pink_terracotta
fill 365 260 503 367 260 503 minecraft:pink_terracotta
fill 367 260 492 367 260 493 minecraft:pink_terracotta
setblock 367 260 494 minecraft:red_nether_bricks
fill 367 260 495 367 263 495 minecraft:pink_terracotta
fill 367 260 497 367 260 498 minecraft:pink_terracotta
setblock 367 260 504 minecraft:red_nether_bricks
fill 368 260 489 368 263 489 minecraft:pink_terracotta
setblock 368 260 493 minecraft:red_nether_bricks
fill 368 260 494 368 263 494 minecraft:pink_terracotta
setblock 368 260 497 minecraft:pink_terracotta
setblock 368 260 498 minecraft:red_nether_bricks
fill 368 260 499 368 263 499 minecraft:pink_terracotta
setblock 368 260 503 minecraft:red_nether_bricks
fill 368 260 504 368 263 504 minecraft:pink_terracotta
setblock 369 260 472 minecraft:red_nether_bricks
fill 369 260 473 369 263 473 minecraft:pink_terracotta
setblock 369 260 477 minecraft:red_nether_bricks
fill 369 260 478 369 263 478 minecraft:pink_terracotta
setblock 369 260 486 minecraft:pink_terracotta
setblock 369 260 487 minecraft:red_nether_bricks
fill 369 260 488 369 263 488 minecraft:pink_terracotta
setblock 369 260 492 minecraft:red_nether_bricks
fill 369 260 493 369 263 493 minecraft:pink_terracotta
setblock 369 260 497 minecraft:red_nether_bricks
fill 369 260 498 369 263 498 minecraft:pink_terracotta
setblock 369 260 502 minecraft:red_nether_bricks
fill 369 260 503 369 263 503 minecraft:pink_terracotta
setblock 370 260 471 minecraft:red_nether_bricks
fill 370 260 472 370 263 472 minecraft:pink_terracotta
setblock 370 260 476 minecraft:red_nether_bricks
fill 370 260 477 370 263 477 minecraft:pink_terracotta
setblock 370 260 481 minecraft:red_nether_bricks
fill 370 260 482 370 263 482 minecraft:pink_terracotta
setblock 370 260 486 minecraft:red_nether_bricks
fill 370 260 487 370 263 487 minecraft:pink_terracotta
setblock 370 260 491 minecraft:red_nether_bricks
fill 370 260 492 370 263 492 minecraft:pink_terracotta
setblock 370 260 496 minecraft:red_nether_bricks
fill 370 260 497 370 263 497 minecraft:pink_terracotta
setblock 370 260 501 minecraft:red_nether_bricks
fill 370 260 502 370 263 502 minecraft:pink_terracotta
setblock 330 261 470 minecraft:red_nether_bricks
fill 330 261 471 330 264 471 minecraft:pink_terracotta
setblock 330 261 475 minecraft:red_nether_bricks
fill 330 261 476 330 261 479 minecraft:pink_terracotta
setblock 330 261 480 minecraft:red_nether_bricks
fill 330 261 481 330 261 484 minecraft:pink_terracotta
setblock 330 261 485 minecraft:red_nether_bricks
fill 330 261 486 330 264 486 minecraft:pink_terracotta
setblock 330 261 490 minecraft:red_nether_bricks
fill 330 261 491 330 264 491 minecraft:pink_terracotta
setblock 330 261 495 minecraft:red_nether_bricks
fill 330 261 496 330 264 496 minecraft:pink_terracotta
setblock 330 261 500 minecraft:red_nether_bricks
fill 330 261 501 330 263 502 minecraft:pink_terracotta
setblock 330 261 503 minecraft:white_concrete
fill 331 261 470 331 263 470 minecraft:pink_terracotta
setblock 331 261 474 minecraft:red_nether_bricks
fill 331 261 475 331 264 475 minecraft:pink_terracotta
setblock 331 261 478 minecraft:pink_terracotta
setblock 331 261 479 minecraft:red_nether_bricks
fill 331 261 480 331 264 480 minecraft:pink_terracotta
setblock 331 261 483 minecraft:pink_terracotta
setblock 331 261 489 minecraft:red_nether_bricks
fill 331 261 490 331 262 490 minecraft:pink_terracotta
setblock 331 261 494 minecraft:red_nether_bricks
fill 331 261 495 331 264 495 minecraft:pink_terracotta
setblock 332 261 473 minecraft:red_nether_bricks
fill 332 261 474 332 264 474 minecraft:pink_terracotta
setblock 332 261 477 minecraft:pink_terracotta
setblock 332 261 479 minecraft:white_concrete
fill 332 261 481 332 262 481 minecraft:white_concrete
fill 333 261 480 333 262 480 minecraft:red_concrete
fill 342 261 464 345 261 464 minecraft:pink_terracotta
setblock 344 261 465 minecraft:pink_terracotta
fill 344 261 504 345 261 504 minecraft:pink_terracotta
setblock 345 261 465 minecraft:red_nether_bricks
setblock 346 261 464 minecraft:red_nether_bricks
fill 346 261 465 346 264 465 minecraft:pink_terracotta
setblock 346 261 504 minecraft:red_nether_bricks
fill 347 261 464 350 261 464 minecraft:pink_terracotta
setblock 347 261 503 minecraft:red_nether_bricks
fill 347 261 504 347 264 504 minecraft:pink_terracotta
fill 348 261 503 350 262 503 minecraft:pink_terracotta
setblock 350 261 465 minecraft:red_nether_bricks
setblock 350 261 504 minecraft:pink_terracotta
setblock 351 261 464 minecraft:red_nether_bricks
setblock 351 261 465 minecraft:pink_terracotta
setblock 351 261 504 minecraft:red_nether_bricks
fill 352 261 464 352 264 464 minecraft:pink_terracotta
fill 352 261 504 352 264 504 minecraft:pink_terracotta
fill 354 261 504 354 262 504 minecraft:pink_terracotta
setblock 360 261 504 minecraft:pink_terracotta
setblock 361 261 504 minecraft:red_nether_bricks
fill 362 261 504 362 264 504 minecraft:pink_terracotta
fill 363 261 503 366 261 503 minecraft:pink_terracotta
fill 366 261 502 367 261 502 minecraft:pink_terracotta
setblock 366 261 504 minecraft:red_nether_bricks
setblock 367 261 492 minecraft:pink_terracotta
setblock 367 261 493 minecraft:red_nether_bricks
fill 367 261 494 367 264 494 minecraft:pink_terracotta
setblock 367 261 497 minecraft:pink_terracotta
setblock 367 261 498 minecraft:red_nether_bricks
fill 367 261 499 367 264 499 minecraft:pink_terracotta
setblock 367 261 503 minecraft:red_nether_bricks
fill 367 261 504 367 264 504 minecraft:pink_terracotta
setblock 368 261 492 minecraft:red_nether_bricks
fill 368 261 493 368 264 493 minecraft:pink_terracotta
setblock 368 261 497 minecraft:red_nether_bricks
fill 368 261 498 368 264 498 minecraft:pink_terracotta
setblock 368 261 501 minecraft:pink_terracotta
fill 368 261 503 368 264 503 minecraft:pink_terracotta
setblock 369 261 471 minecraft:red_nether_bricks
fill 369 261 472 369 264 472 minecraft:pink_terracotta
fill 369 261 474 369 261 475 minecraft:pink_terracotta
setblock 369 261 476 minecraft:red_nether_bricks
fill 369 261 477 369 264 477 minecraft:pink_terracotta
fill 369 261 479 369 261 480 minecraft:pink_terracotta
setblock 369 261 481 minecraft:red_nether_bricks
setblock 369 261 486 minecraft:red_nether_bricks
fill 369 261 487 369 264 487 minecraft:pink_terracotta
setblock 369 261 491 minecraft:red_nether_bricks
fill 369 261 492 369 264 492 minecraft:pink_terracotta
setblock 369 261 496 minecraft:red_nether_bricks
fill 369 261 497 369 264 497 minecraft:pink_terracotta
setblock 369 261 501 minecraft:red_nether_bricks
fill 369 261 502 369 264 502 minecraft:pink_terracotta
setblock 370 261 465 minecraft:white_concrete
setblock 370 261 470 minecraft:red_nether_bricks
fill 370 261 471 370 264 471 minecraft:pink_terracotta
setblock 370 261 475 minecraft:red_nether_bricks
fill 370 261 476 370 264 476 minecraft:pink_terracotta
setblock 370 261 479 minecraft:pink_terracotta
setblock 370 261 480 minecraft:red_nether_bricks
fill 370 261 481 370 264 481 minecraft:pink_terracotta
setblock 370 261 485 minecraft:red_nether_bricks
fill 370 261 486 370 264 486 minecraft:pink_terracotta
setblock 370 261 490 minecraft:red_nether_bricks
fill 370 261 491 370 264 491 minecraft:pink_terracotta
setblock 370 261 495 minecraft:red_nether_bricks
fill 370 261 496 370 264 496 minecraft:pink_terracotta
setblock 370 261 500 minecraft:red_nether_bricks
fill 370 261 501 370 264 501 minecraft:pink_terracotta
setblock 330 262 465 minecraft:white_concrete
setblock 330 262 469 minecraft:red_nether_bricks
fill 330 262 470 330 265 470 minecraft:pink_terracotta
setblock 330 262 474 minecraft:red_nether_bricks
fill 330 262 475 330 262 478 minecraft:pink_terracotta
setblock 330 262 479 minecraft:red_nether_bricks
fill 330 262 480 330 262 483 minecraft:pink_terracotta
setblock 330 262 484 minecraft:red_nether_bricks
fill 330 262 485 330 265 485 minecraft:pink_terracotta
setblock 330 262 489 minecraft:red_nether_bricks
fill 330 262 490 330 265 490 minecraft:pink_terracotta
setblock 330 262 494 minecraft:red_nether_bricks
fill 330 262 495 330 265 495 minecraft:pink_terracotta
setblock 330 262 498 minecraft:pink_terracotta
setblock 330 262 499 minecraft:red_nether_bricks
fill 330 262 500 330 265 500 minecraft:pink_terracotta
setblock 331 262 473 minecraft:red_nether_bricks
fill 331 262 474 331 265 474 minecraft:pink_terracotta
setblock 331 262 478 minecraft:red_nether_bricks
fill 331 262 479 332 264 479 minecraft:pink_terracotta
setblock 331 262 483 minecraft:red_nether_bricks
setblock 331 262 493 minecraft:red_nether_bricks
fill 331 262 494 331 264 494 minecraft:pink_terracotta
setblock 331 262 498 minecraft:red_nether_bricks
fill 331 262 499 331 264 499 minecraft:pink_terracotta
fill 332 262 473 332 263 473 minecraft:pink_terracotta
setblock 332 262 477 minecraft:red_nether_bricks
fill 332 262 478 332 265 478 minecraft:pink_terracotta
setblock 335 262 504 minecraft:white_concrete
setblock 340 262 464 minecraft:white_concrete
fill 341 262 464 344 262 464 minecraft:pink_terracotta
setblock 343 262 465 minecraft:pink_terracotta
fill 343 262 504 344 262 504 minecraft:pink_terracotta
setblock 344 262 465 minecraft:red_nether_bricks
setblock 345 262 464 minecraft:red_nether_bricks
fill 345 262 465 345 265 465 minecraft:pink_terracotta
setblock 345 262 503 minecraft:pink_terracotta
setblock 345 262 504 minecraft:red_nether_bricks
fill 346 262 464 349 262 464 minecraft:pink_terracotta
fill 346 262 466 347 262 466 minecraft:pink_terracotta
setblock 346 262 503 minecraft:red_nether_bricks
fill 346 262 504 346 265 504 minecraft:pink_terracotta
fill 347 262 503 347 265 503 minecraft:pink_terracotta
setblock 349 262 465 minecraft:red_nether_bricks
setblock 350 262 464 minecraft:red_nether_bricks
fill 350 262 465 350 265 465 minecraft:pink_terracotta
setblock 350 262 504 minecraft:red_nether_bricks
fill 351 262 464 351 265 464 minecraft:pink_terracotta
setblock 351 262 503 minecraft:red_nether_bricks
fill 351 262 504 351 265 504 minecraft:pink_terracotta
fill 352 262 503 352 265 503 minecraft:pink_terracotta
setblock 355 262 504 minecraft:red_nether_bricks
fill 356 262 504 359 262 504 minecraft:pink_terracotta
setblock 360 262 504 minecraft:red_nether_bricks
setblock 361 262 503 minecraft:red_nether_bricks
fill 361 262 504 361 265 504 minecraft:pink_terracotta
fill 362 262 503 365 262 503 minecraft:pink_terracotta
fill 363 262 502 366 262 502 minecraft:pink_terracotta
setblock 365 262 464 minecraft:red_nether_bricks
setblock 365 262 504 minecraft:red_nether_bricks
fill 366 262 464 367 264 464 minecraft:pink_terracotta
fill 366 262 496 366 262 497 minecraft:pink_terracotta
setblock 366 262 503 minecraft:red_nether_bricks
fill 366 262 504 366 265 504 minecraft:pink_terracotta
setblock 367 262 492 minecraft:red_nether_bricks
fill 367 262 493 367 265 493 minecraft:pink_terracotta
setblock 367 262 497 minecraft:red_nether_bricks
fill 367 262 498 367 265 498 minecraft:pink_terracotta
fill 367 262 500 367 263 500 minecraft:pink_terracotta
setblock 367 262 502 minecraft:red_nether_bricks
fill 367 262 503 367 265 503 minecraft:pink_terracotta
fill 368 262 474 368 262 475 minecraft:pink_terracotta
setblock 368 262 476 minecraft:red_nether_bricks
fill 368 262 477 368 264 478 minecraft:pink_terracotta
setblock 368 262 491 minecraft:red_nether_bricks
fill 368 262 492 368 265 492 minecraft:pink_terracotta
setblock 368 262 496 minecraft:red_nether_bricks
fill 368 262 497 368 265 497 minecraft:pink_terracotta
setblock 368 262 501 minecraft:red_nether_bricks
fill 368 262 502 368 265 502 minecraft:pink_terracotta
fill 369 262 471 369 263 471 minecraft:pink_terracotta
setblock 369 262 474 minecraft:pink_terracotta
setblock 369 262 475 minecraft:red_nether_bricks
fill 369 262 476 369 265 476 minecraft:pink_terracotta
setblock 369 262 479 minecraft:pink_terracotta
setblock 369 262 480 minecraft:red_nether_bricks
fill 369 262 481 369 262 484 minecraft:pink_terracotta
setblock 369 262 485 minecraft:red_nether_bricks
fill 369 262 486 369 265 486 minecraft:pink_terracotta
setblock 369 262 490 minecraft:red_nether_bricks
fill 369 262 491 369 265 491 minecraft:pink_terracotta
setblock 369 262 495 minecraft:red_nether_bricks
fill 369 262 496 369 265 496 minecraft:pink_terracotta
setblock 369 262 500 minecraft:red_nether_bricks
fill 369 262 501 369 265 501 minecraft:pink_terracotta
setblock 370 262 469 minecraft:red_nether_bricks
fill 370 262 470 370 264 470 minecraft:pink_terracotta
setblock 370 262 474 minecraft:red_nether_bricks
fill 370 262 475 370 265 475 minecraft:pink_terracotta
setblock 370 262 479 minecraft:red_nether_bricks
fill 370 262 480 370 265 480 minecraft:pink_terracotta
setblock 370 262 484 minecraft:red_nether_bricks
fill 370 262 485 370 265 485 minecraft:pink_terracotta
setblock 370 262 489 minecraft:red_nether_bricks
fill 370 262 490 370 265 490 minecraft:pink_terracotta
setblock 370 262 494 minecraft:red_nether_bricks
fill 370 262 495 370 265 495 minecraft:pink_terracotta
setblock 370 262 499 minecraft:red_nether_bricks
fill 370 262 500 370 265 500 minecraft:pink_terracotta
setblock 370 262 504 minecraft:red_nether_bricks
setblock 330 263 468 minecraft:red_nether_bricks
fill 330 263 469 330 266 469 minecraft:pink_terracotta
setblock 330 263 473 minecraft:red_nether_bricks
fill 330 263 474 330 263 477 minecraft:pink_terracotta
setblock 330 263 478 minecraft:red_nether_bricks
fill 330 263 479 330 263 482 minecraft:pink_terracotta
setblock 330 263 483 minecraft:red_nether_bricks
fill 330 263 484 331 265 484 minecraft:pink_terracotta
setblock 330 263 488 minecraft:red_nether_bricks
fill 330 263 489 330 266 489 minecraft:pink_terracotta
setblock 330 263 493 minecraft:red_nether_bricks
fill 330 263 494 330 266 494 minecraft:pink_terracotta
setblock 330 263 498 minecraft:red_nether_bricks
fill 330 263 499 330 266 499 minecraft:pink_terracotta
setblock 330 263 503 minecraft:red_nether_bricks
setblock 331 263 472 minecraft:red_nether_bricks
fill 331 263 473 331 266 473 minecraft:pink_terracotta
setblock 331 263 476 minecraft:pink_terracotta
setblock 331 263 477 minecraft:red_nether_bricks
fill 331 263 478 331 266 478 minecraft:pink_terracotta
setblock 331 263 481 minecraft:pink_terracotta
setblock 331 263 482 minecraft:red_nether_bricks
fill 331 263 483 331 266 483 minecraft:pink_terracotta
setblock 331 263 492 minecraft:red_nether_bricks
fill 331 263 493 331 264 493 minecraft:pink_terracotta
setblock 331 263 497 minecraft:red_nether_bricks
fill 331 263 498 331 265 498 minecraft:pink_terracotta
setblock 332 263 476 minecraft:red_nether_bricks
fill 332 263 477 332 266 477 minecraft:pink_terracotta
setblock 334 263 464 minecraft:white_concrete
fill 340 263 464 343 263 464 minecraft:pink_terracotta
fill 341 263 504 343 263 504 minecraft:pink_terracotta
setblock 342 263 465 minecraft:pink_terracotta
setblock 343 263 465 minecraft:red_nether_bricks
fill 343 263 503 344 263 503 minecraft:pink_terracotta
setblock 344 263 464 minecraft:red_nether_bricks
fill 344 263 465 344 266 465 minecraft:pink_terracotta
setblock 344 263 504 minecraft:red_nether_bricks
fill 345 263 464 348 263 464 minecraft:pink_terracotta
fill 345 263 466 346 263 466 minecraft:pink_terracotta
setblock 345 263 503 minecraft:red_nether_bricks
fill 345 263 504 345 266 504 minecraft:pink_terracotta
setblock 346 263 502 minecraft:red_nether_bricks
fill 346 263 503 346 266 503 minecraft:pink_terracotta
setblock 347 263 466 minecraft:red_nether_bricks
fill 347 263 502 350 263 502 minecraft:pink_terracotta
setblock 348 263 465 minecraft:red_nether_bricks
fill 348 263 503 349 263 503 minecraft:pink_terracotta
setblock 349 263 464 minecraft:red_nether_bricks
fill 349 263 465 349 266 465 minecraft:pink_terracotta
setblock 349 263 504 minecraft:red_nether_bricks
fill 350 263 464 350 266 464 minecraft:pink_terracotta
setblock 350 263 503 minecraft:red_nether_bricks
fill 350 263 504 350 266 504 minecraft:pink_terracotta
fill 351 263 503 351 266 503 minecraft:pink_terracotta
fill 353 263 503 353 264 503 minecraft:pink_terracotta
setblock 354 263 504 minecraft:red_nether_bricks
fill 355 263 504 358 263 504 minecraft:pink_terracotta
fill 358 263 503 359 263 503 minecraft:pink_terracotta
setblock 359 263 464 minecraft:white_concrete
setblock 359 263 504 minecraft:red_nether_bricks
setblock 360 263 503 minecraft:red_nether_bricks
fill 360 263 504 360 266 504 minecraft:pink_terracotta
setblock 361 263 502 minecraft:red_nether_bricks
fill 361 263 503 364 263 503 minecraft:pink_terracotta
fill 362 263 502 365 263 502 minecraft:pink_terracotta
setblock 363 263 464 minecraft:pink_terracotta
fill 363 263 501 366 263 501 minecraft:pink_terracotta
setblock 364 263 464 minecraft:red_nether_bricks
setblock 364 263 504 minecraft:red_nether_bricks
fill 365 263 464 365 266 464 minecraft:pink_terracotta
setblock 365 263 503 minecraft:red_nether_bricks
fill 365 263 504 365 266 504 minecraft:pink_terracotta
fill 366 263 495 366 263 496 minecraft:pink_terracotta
schedule function dropper:buildpart/115_8 1t
