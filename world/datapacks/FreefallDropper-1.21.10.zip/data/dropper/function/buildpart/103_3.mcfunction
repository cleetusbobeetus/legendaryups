setblock 366 175 435 minecraft:white_concrete
fill 330 176 422 330 176 430 minecraft:red_concrete
fill 330 176 436 330 176 437 minecraft:red_concrete
fill 330 176 443 330 176 444 minecraft:red_concrete
fill 330 176 450 330 176 451 minecraft:red_concrete
fill 330 176 457 331 176 457 minecraft:red_concrete
fill 331 176 417 332 176 417 minecraft:red_concrete
fill 331 176 422 336 189 428 minecraft:red_concrete
setblock 332 176 419 minecraft:light[level=12]
setblock 332 176 435 minecraft:light[level=12]
setblock 332 176 443 minecraft:light[level=12]
setblock 332 176 451 minecraft:light[level=12]
setblock 335 176 432 minecraft:white_concrete
fill 335 176 435 335 176 440 minecraft:white_concrete
fill 336 176 430 336 176 431 minecraft:white_concrete
fill 336 176 435 339 177 436 minecraft:white_concrete
fill 336 176 443 338 176 444 minecraft:white_concrete
fill 337 176 428 337 176 430 minecraft:white_concrete
fill 337 176 440 342 176 440 minecraft:white_concrete
fill 337 176 457 338 176 457 minecraft:red_concrete
fill 338 176 417 339 176 417 minecraft:red_concrete
fill 338 176 427 338 176 429 minecraft:white_concrete
fill 338 176 439 342 176 439 minecraft:white_concrete
fill 339 176 426 339 176 428 minecraft:white_concrete
fill 339 176 438 342 176 438 minecraft:white_concrete
fill 339 176 448 342 176 448 minecraft:white_concrete
setblock 340 176 419 minecraft:light[level=12]
fill 340 176 425 340 176 427 minecraft:white_concrete
fill 340 176 435 340 178 435 minecraft:white_concrete
fill 340 176 437 342 176 437 minecraft:white_concrete
fill 340 176 449 342 176 449 minecraft:white_concrete
setblock 340 176 451 minecraft:light[level=12]
fill 341 176 424 341 176 426 minecraft:white_concrete
fill 341 176 436 342 176 436 minecraft:white_concrete
fill 341 176 444 346 176 444 minecraft:white_concrete
setblock 341 176 450 minecraft:white_concrete
fill 342 176 424 342 176 425 minecraft:white_concrete
setblock 342 176 435 minecraft:white_concrete
fill 342 176 443 344 176 443 minecraft:white_concrete
fill 343 176 423 343 176 424 minecraft:white_concrete
fill 343 176 434 343 177 435 minecraft:yellow_concrete
fill 343 176 436 344 176 436 minecraft:red_concrete
fill 343 176 437 343 177 437 minecraft:yellow_concrete
fill 343 176 438 344 176 438 minecraft:red_concrete
fill 343 176 439 343 177 440 minecraft:yellow_concrete
setblock 343 176 442 minecraft:white_concrete
fill 343 176 451 348 176 451 minecraft:white_concrete
setblock 344 176 423 minecraft:white_concrete
fill 344 176 432 345 177 432 minecraft:yellow_concrete
fill 344 176 433 344 176 434 minecraft:red_concrete
setblock 344 176 435 minecraft:yellow_concrete
setblock 344 176 437 minecraft:red_concrete
setblock 344 176 439 minecraft:yellow_concrete
fill 344 176 440 344 176 441 minecraft:red_concrete
fill 344 176 442 345 177 442 minecraft:yellow_concrete
fill 344 176 457 345 176 457 minecraft:red_concrete
fill 345 176 417 346 176 417 minecraft:red_concrete
setblock 345 176 422 minecraft:white_concrete
setblock 345 176 433 minecraft:yellow_concrete
setblock 345 176 434 minecraft:red_concrete
setblock 345 176 441 minecraft:yellow_concrete
setblock 345 176 443 minecraft:red_concrete
fill 345 176 452 347 176 452 minecraft:white_concrete
fill 346 176 431 347 177 431 minecraft:yellow_concrete
setblock 346 176 432 minecraft:red_concrete
fill 346 176 443 347 177 443 minecraft:yellow_concrete
fill 347 176 430 348 176 430 minecraft:red_concrete
fill 347 176 444 348 176 444 minecraft:red_concrete
setblock 348 176 419 minecraft:light[level=12]
fill 348 176 429 349 176 429 minecraft:white_concrete
setblock 348 176 431 minecraft:red_concrete
setblock 348 176 435 minecraft:light[level=12]
setblock 348 176 443 minecraft:light[level=12]
fill 348 176 445 354 176 445 minecraft:red_concrete
fill 349 176 430 349 177 430 minecraft:yellow_concrete
fill 349 176 444 349 177 444 minecraft:yellow_concrete
fill 350 176 429 350 176 430 minecraft:red_concrete
fill 351 176 429 352 176 429 minecraft:red_concrete
fill 351 176 430 351 177 430 minecraft:yellow_concrete
fill 351 176 444 351 177 444 minecraft:yellow_concrete
fill 351 176 457 352 176 457 minecraft:red_concrete
fill 352 176 417 353 176 417 minecraft:red_concrete
fill 352 176 430 355 176 430 minecraft:red_concrete
fill 353 176 429 354 176 429 minecraft:white_concrete
fill 353 176 431 354 177 431 minecraft:yellow_concrete
fill 353 176 443 354 177 443 minecraft:yellow_concrete
fill 354 176 423 357 176 423 minecraft:white_concrete
setblock 355 176 422 minecraft:white_concrete
fill 355 176 431 356 176 431 minecraft:red_concrete
fill 355 176 432 355 176 433 minecraft:yellow_concrete
fill 355 176 441 355 176 442 minecraft:yellow_concrete
setblock 355 176 444 minecraft:red_concrete
setblock 356 176 419 minecraft:light[level=12]
fill 356 176 430 361 176 430 minecraft:white_concrete
fill 356 176 432 356 178 432 minecraft:yellow_concrete
fill 356 176 435 357 176 435 minecraft:yellow_concrete
fill 356 176 439 357 176 439 minecraft:yellow_concrete
fill 356 176 442 356 178 442 minecraft:yellow_concrete
setblock 356 176 443 minecraft:red_concrete
fill 357 176 431 360 176 431 minecraft:white_concrete
setblock 357 176 432 minecraft:red_concrete
fill 357 176 434 357 178 434 minecraft:yellow_concrete
fill 357 176 437 357 177 437 minecraft:yellow_concrete
fill 357 176 440 357 178 440 minecraft:yellow_concrete
setblock 357 176 442 minecraft:red_concrete
fill 358 176 427 362 176 427 minecraft:white_concrete
fill 358 176 432 359 176 432 minecraft:white_concrete
fill 358 176 433 358 176 434 minecraft:red_concrete
setblock 358 176 441 minecraft:red_concrete
fill 358 176 457 359 176 457 minecraft:red_concrete
fill 359 176 417 370 176 417 minecraft:red_concrete
fill 359 176 426 361 176 426 minecraft:white_concrete
fill 359 176 435 359 176 436 minecraft:red_concrete
fill 359 176 439 359 177 440 minecraft:red_concrete
setblock 359 176 450 minecraft:white_concrete
fill 360 176 418 370 177 421 minecraft:red_concrete
setblock 360 176 425 minecraft:white_concrete
fill 360 176 433 365 176 433 minecraft:white_concrete
fill 360 176 435 362 176 436 minecraft:white_concrete
fill 360 176 441 365 176 441 minecraft:white_concrete
setblock 360 176 449 minecraft:white_concrete
fill 360 176 450 370 177 454 minecraft:red_concrete
fill 361 176 432 365 176 432 minecraft:white_concrete
fill 361 176 440 365 176 440 minecraft:white_concrete
setblock 361 176 448 minecraft:white_concrete
fill 361 176 449 370 177 449 minecraft:red_concrete
fill 362 176 431 364 176 431 minecraft:white_concrete
fill 362 176 439 365 176 439 minecraft:white_concrete
setblock 362 176 447 minecraft:white_concrete
fill 362 176 448 370 177 448 minecraft:red_concrete
fill 363 176 430 364 176 430 minecraft:white_concrete
fill 363 176 438 365 176 438 minecraft:white_concrete
setblock 363 176 446 minecraft:white_concrete
fill 363 176 447 370 177 447 minecraft:red_concrete
setblock 364 176 427 minecraft:light[level=12]
fill 364 176 437 365 176 437 minecraft:white_concrete
fill 364 176 445 370 177 446 minecraft:red_concrete
setblock 365 176 436 minecraft:white_concrete
fill 365 176 443 370 177 444 minecraft:red_concrete
fill 365 176 457 366 176 457 minecraft:red_concrete
fill 366 176 442 370 177 442 minecraft:red_concrete
fill 370 176 427 370 176 428 minecraft:red_concrete
fill 370 176 434 370 176 435 minecraft:red_concrete
setblock 370 176 441 minecraft:red_concrete
fill 370 176 455 370 176 456 minecraft:red_concrete
setblock 330 177 417 minecraft:red_concrete
fill 330 177 422 330 190 429 minecraft:red_concrete
setblock 330 177 431 minecraft:red_concrete
fill 330 177 436 330 226 436 minecraft:red_concrete
setblock 330 177 438 minecraft:red_concrete
fill 330 177 443 330 226 443 minecraft:red_concrete
setblock 330 177 445 minecraft:red_concrete
fill 330 177 450 330 226 450 minecraft:red_concrete
setblock 330 177 452 minecraft:red_concrete
fill 330 177 457 330 226 457 minecraft:red_concrete
fill 332 177 417 332 226 417 minecraft:red_concrete
setblock 332 177 457 minecraft:red_concrete
fill 336 177 433 341 177 434 minecraft:white_concrete
fill 336 177 441 341 177 441 minecraft:white_concrete
setblock 337 177 417 minecraft:red_concrete
setblock 337 177 430 minecraft:white_concrete
fill 337 177 432 342 177 432 minecraft:white_concrete
fill 337 177 440 341 177 440 minecraft:white_concrete
fill 337 177 442 338 177 444 minecraft:white_concrete
fill 337 177 457 337 226 457 minecraft:red_concrete
setblock 338 177 429 minecraft:white_concrete
fill 338 177 431 343 177 431 minecraft:white_concrete
fill 338 177 439 341 177 439 minecraft:white_concrete
setblock 338 177 445 minecraft:white_concrete
fill 339 177 417 339 226 417 minecraft:red_concrete
setblock 339 177 428 minecraft:white_concrete
fill 339 177 430 344 177 430 minecraft:white_concrete
fill 339 177 438 340 177 438 minecraft:white_concrete
fill 339 177 442 341 178 442 minecraft:white_concrete
setblock 339 177 457 minecraft:red_concrete
setblock 340 177 427 minecraft:white_concrete
fill 340 177 429 345 177 429 minecraft:white_concrete
setblock 340 177 437 minecraft:white_concrete
fill 340 177 445 345 177 445 minecraft:white_concrete
fill 340 177 447 344 177 447 minecraft:white_concrete
setblock 341 177 426 minecraft:white_concrete
fill 341 177 436 342 177 436 minecraft:red_concrete
fill 341 177 437 342 179 437 minecraft:yellow_concrete
fill 341 177 438 342 177 438 minecraft:red_concrete
fill 341 177 444 343 177 444 minecraft:white_concrete
fill 341 177 448 342 177 448 minecraft:white_concrete
setblock 342 177 425 minecraft:white_concrete
fill 342 177 433 343 177 433 minecraft:red_concrete
fill 342 177 434 342 178 435 minecraft:yellow_concrete
fill 342 177 439 342 178 440 minecraft:yellow_concrete
fill 342 177 441 343 177 441 minecraft:red_concrete
setblock 342 177 443 minecraft:white_concrete
setblock 342 177 449 minecraft:white_concrete
setblock 343 177 424 minecraft:white_concrete
fill 343 177 432 343 179 432 minecraft:yellow_concrete
fill 343 177 442 343 179 442 minecraft:yellow_concrete
setblock 343 177 443 minecraft:red_concrete
setblock 344 177 417 minecraft:red_concrete
fill 344 177 431 344 179 431 minecraft:yellow_concrete
fill 344 177 443 344 179 443 minecraft:yellow_concrete
setblock 344 177 444 minecraft:red_concrete
fill 344 177 457 344 226 457 minecraft:red_concrete
fill 345 177 430 346 179 430 minecraft:yellow_concrete
setblock 345 177 431 minecraft:red_concrete
fill 345 177 444 346 179 444 minecraft:yellow_concrete
fill 346 177 417 346 226 417 minecraft:red_concrete
fill 346 177 429 346 179 429 minecraft:yellow_concrete
fill 346 177 445 346 179 445 minecraft:yellow_concrete
fill 346 177 451 348 177 451 minecraft:white_concrete
setblock 346 177 457 minecraft:red_concrete
setblock 347 177 429 minecraft:red_concrete
setblock 347 177 445 minecraft:red_concrete
setblock 347 177 446 minecraft:white_concrete
fill 348 177 428 352 177 428 minecraft:red_concrete
fill 348 177 429 349 179 429 minecraft:yellow_concrete
fill 348 177 445 349 179 445 minecraft:yellow_concrete
fill 348 177 446 353 177 446 minecraft:red_concrete
fill 350 177 451 354 177 451 minecraft:white_concrete
setblock 351 177 417 minecraft:red_concrete
fill 351 177 429 352 179 429 minecraft:yellow_concrete
fill 351 177 445 352 179 445 minecraft:yellow_concrete
fill 351 177 457 351 226 457 minecraft:red_concrete
fill 353 177 417 353 226 417 minecraft:red_concrete
fill 353 177 424 357 177 424 minecraft:white_concrete
fill 353 177 428 355 177 428 minecraft:white_concrete
setblock 353 177 429 minecraft:red_concrete
setblock 353 177 457 minecraft:red_concrete
setblock 354 177 423 minecraft:white_concrete
fill 354 177 429 354 179 430 minecraft:yellow_concrete
fill 354 177 444 354 179 445 minecraft:yellow_concrete
setblock 355 177 429 minecraft:red_concrete
fill 355 177 430 355 179 430 minecraft:yellow_concrete
setblock 355 177 432 minecraft:yellow_concrete
setblock 355 177 442 minecraft:yellow_concrete
fill 355 177 444 355 179 444 minecraft:yellow_concrete
setblock 355 177 445 minecraft:red_concrete
setblock 356 177 430 minecraft:red_concrete
fill 356 177 431 356 179 431 minecraft:yellow_concrete
fill 356 177 443 356 179 443 minecraft:yellow_concrete
setblock 356 177 444 minecraft:red_concrete
fill 357 177 428 361 177 428 minecraft:white_concrete
fill 357 177 430 361 177 430 minecraft:white_concrete
setblock 357 177 431 minecraft:red_concrete
fill 357 177 432 357 179 432 minecraft:yellow_concrete
fill 357 177 435 358 177 435 minecraft:yellow_concrete
fill 357 177 439 358 177 439 minecraft:yellow_concrete
fill 357 177 442 357 179 442 minecraft:yellow_concrete
setblock 357 177 443 minecraft:red_concrete
setblock 358 177 417 minecraft:red_concrete
fill 358 177 427 360 177 427 minecraft:white_concrete
fill 358 177 431 360 177 431 minecraft:white_concrete
setblock 358 177 432 minecraft:red_concrete
fill 358 177 434 358 179 434 minecraft:yellow_concrete
fill 358 177 437 359 179 437 minecraft:yellow_concrete
fill 358 177 440 358 179 440 minecraft:yellow_concrete
setblock 358 177 442 minecraft:red_concrete
fill 358 177 443 363 177 443 minecraft:white_concrete
fill 358 177 457 358 226 457 minecraft:red_concrete
setblock 359 177 426 minecraft:white_concrete
setblock 359 177 432 minecraft:white_concrete
fill 359 177 433 359 177 435 minecraft:red_concrete
setblock 359 177 441 minecraft:red_concrete
fill 359 177 442 363 177 442 minecraft:white_concrete
fill 360 177 417 370 177 417 minecraft:red_concrete
fill 360 177 433 362 177 435 minecraft:white_concrete
fill 360 177 436 360 177 438 minecraft:red_concrete
fill 360 177 441 364 177 441 minecraft:white_concrete
fill 360 177 448 360 177 449 minecraft:red_concrete
setblock 360 177 457 minecraft:red_concrete
fill 361 177 432 363 177 432 minecraft:white_concrete
fill 361 177 436 361 178 438 minecraft:white_concrete
fill 361 177 440 364 177 440 minecraft:white_concrete
fill 361 177 447 361 177 448 minecraft:red_concrete
fill 362 177 431 363 177 431 minecraft:white_concrete
fill 362 177 436 362 178 436 minecraft:white_concrete
fill 362 177 439 364 177 439 minecraft:white_concrete
fill 362 177 446 362 177 447 minecraft:red_concrete
setblock 363 177 430 minecraft:white_concrete
fill 363 177 433 364 177 434 minecraft:white_concrete
fill 363 177 438 364 177 438 minecraft:white_concrete
fill 363 177 445 363 177 446 minecraft:red_concrete
setblock 364 177 437 minecraft:white_concrete
fill 364 177 442 364 177 444 minecraft:red_concrete
setblock 365 177 442 minecraft:red_concrete
fill 365 177 457 365 226 457 minecraft:red_concrete
setblock 367 177 457 minecraft:red_concrete
setblock 370 177 426 minecraft:red_concrete
fill 370 177 428 370 226 428 minecraft:red_concrete
setblock 370 177 433 minecraft:red_concrete
fill 370 177 435 370 226 435 minecraft:red_concrete
setblock 370 177 440 minecraft:red_concrete
fill 370 177 456 370 226 456 minecraft:red_concrete
setblock 330 178 418 minecraft:red_concrete
setblock 330 178 432 minecraft:red_concrete
setblock 330 178 439 minecraft:red_concrete
setblock 330 178 446 minecraft:red_concrete
setblock 330 178 453 minecraft:red_concrete
setblock 333 178 457 minecraft:red_concrete
setblock 336 178 417 minecraft:red_concrete
fill 337 178 435 339 178 436 minecraft:white_concrete
fill 338 178 432 340 178 434 minecraft:white_concrete
fill 338 178 439 338 178 442 minecraft:white_concrete
fill 339 178 430 341 178 431 minecraft:white_concrete
fill 339 178 438 339 178 441 minecraft:white_concrete
fill 340 178 429 343 178 429 minecraft:white_concrete
setblock 340 178 436 minecraft:red_concrete
fill 340 178 437 340 179 437 minecraft:yellow_concrete
setblock 340 178 438 minecraft:red_concrete
fill 340 178 439 340 178 441 minecraft:white_concrete
fill 340 178 445 343 178 445 minecraft:white_concrete
setblock 340 178 457 minecraft:red_concrete
fill 341 178 428 344 178 428 minecraft:white_concrete
setblock 341 178 432 minecraft:white_concrete
fill 341 178 433 341 179 436 minecraft:yellow_concrete
fill 341 178 438 341 179 441 minecraft:yellow_concrete
fill 341 178 444 342 178 444 minecraft:white_concrete
fill 341 178 446 344 178 446 minecraft:white_concrete
fill 342 178 427 347 178 427 minecraft:white_concrete
setblock 342 178 430 minecraft:white_concrete
fill 342 178 431 343 179 431 minecraft:yellow_concrete
setblock 342 178 432 minecraft:red_concrete
fill 342 178 433 342 179 433 minecraft:yellow_concrete
fill 342 178 441 342 179 441 minecraft:yellow_concrete
setblock 342 178 442 minecraft:red_concrete
fill 342 178 443 343 179 443 minecraft:yellow_concrete
fill 342 178 447 344 178 447 minecraft:white_concrete
setblock 343 178 417 minecraft:red_concrete
fill 343 178 430 343 179 430 minecraft:yellow_concrete
setblock 343 178 434 minecraft:yellow_concrete
setblock 343 178 440 minecraft:yellow_concrete
fill 343 178 444 343 179 444 minecraft:yellow_concrete
fill 344 178 429 344 178 430 minecraft:red_concrete
setblock 344 178 432 minecraft:yellow_concrete
setblock 344 178 442 minecraft:yellow_concrete
setblock 344 178 445 minecraft:red_concrete
fill 345 178 425 350 178 425 minecraft:white_concrete
fill 345 178 428 345 179 429 minecraft:yellow_concrete
fill 345 178 445 345 179 446 minecraft:yellow_concrete
fill 345 178 449 350 178 449 minecraft:white_concrete
fill 346 178 428 346 179 428 minecraft:yellow_concrete
fill 346 178 446 346 179 446 minecraft:yellow_concrete
fill 346 178 447 347 178 447 minecraft:white_concrete
setblock 347 178 428 minecraft:red_concrete
setblock 347 178 446 minecraft:red_concrete
setblock 347 178 457 minecraft:red_concrete
fill 348 178 424 351 178 424 minecraft:white_concrete
fill 348 178 427 349 179 428 minecraft:yellow_concrete
fill 348 178 446 349 179 447 minecraft:yellow_concrete
fill 348 178 450 349 178 450 minecraft:white_concrete
setblock 350 178 417 minecraft:red_concrete
setblock 350 178 427 minecraft:red_concrete
fill 350 178 436 350 179 440 minecraft:white_concrete
setblock 350 178 447 minecraft:red_concrete
fill 351 178 427 352 179 428 minecraft:yellow_concrete
fill 351 178 446 352 179 447 minecraft:yellow_concrete
fill 351 178 450 352 178 450 minecraft:white_concrete
fill 352 178 425 355 178 425 minecraft:white_concrete
fill 352 178 449 355 178 449 minecraft:white_concrete
fill 353 178 427 356 178 427 minecraft:white_concrete
setblock 353 178 428 minecraft:red_concrete
setblock 353 178 447 minecraft:red_concrete
fill 353 178 448 357 178 448 minecraft:white_concrete
fill 354 178 428 355 179 428 minecraft:yellow_concrete
fill 354 178 446 355 179 446 minecraft:yellow_concrete
fill 354 178 447 358 178 447 minecraft:white_concrete
setblock 354 178 457 minecraft:red_concrete
fill 355 178 429 355 179 429 minecraft:yellow_concrete
fill 355 178 445 355 179 445 minecraft:yellow_concrete
setblock 356 178 429 minecraft:red_concrete
setblock 356 178 445 minecraft:red_concrete
fill 356 178 446 359 178 446 minecraft:white_concrete
setblock 357 178 417 minecraft:red_concrete
fill 357 178 428 359 178 429 minecraft:white_concrete
fill 357 178 430 357 179 431 minecraft:yellow_concrete
fill 357 178 443 357 179 444 minecraft:yellow_concrete
fill 357 178 445 359 178 445 minecraft:white_concrete
setblock 358 178 427 minecraft:white_concrete
fill 358 178 430 361 178 430 minecraft:white_concrete
fill 358 178 431 358 179 431 minecraft:yellow_concrete
fill 358 178 433 359 179 433 minecraft:yellow_concrete
fill 358 178 435 359 178 435 minecraft:yellow_concrete
fill 358 178 439 359 178 439 minecraft:yellow_concrete
fill 358 178 441 359 179 441 minecraft:yellow_concrete
fill 358 178 443 358 179 443 minecraft:yellow_concrete
fill 358 178 444 360 178 444 minecraft:white_concrete
fill 359 178 431 360 178 431 minecraft:white_concrete
setblock 359 178 432 minecraft:red_concrete
fill 359 178 434 359 179 434 minecraft:yellow_concrete
fill 359 178 436 359 179 436 minecraft:yellow_concrete
fill 359 178 438 359 179 438 minecraft:yellow_concrete
fill 359 178 440 359 179 440 minecraft:yellow_concrete
setblock 359 178 442 minecraft:red_concrete
setblock 359 178 443 minecraft:white_concrete
setblock 360 178 417 minecraft:jack_o_lantern
fill 360 178 418 360 191 418 minecraft:red_concrete
setblock 360 178 419 minecraft:jack_o_lantern
fill 360 178 420 360 191 420 minecraft:red_concrete
setblock 360 178 421 minecraft:jack_o_lantern
setblock 360 178 429 minecraft:white_concrete
fill 360 178 433 362 178 433 minecraft:white_concrete
fill 360 178 434 360 178 436 minecraft:red_concrete
fill 360 178 437 360 179 437 minecraft:yellow_concrete
fill 360 178 438 360 178 440 minecraft:red_concrete
fill 360 178 441 360 178 442 minecraft:white_concrete
setblock 360 178 443 minecraft:jack_o_lantern
setblock 360 178 445 minecraft:jack_o_lantern
fill 360 178 446 360 196 446 minecraft:red_concrete
setblock 360 178 447 minecraft:jack_o_lantern
fill 360 178 448 360 196 448 minecraft:red_concrete
setblock 360 178 449 minecraft:jack_o_lantern
fill 360 178 450 360 196 450 minecraft:red_concrete
setblock 360 178 451 minecraft:jack_o_lantern
fill 360 178 452 360 196 452 minecraft:red_concrete
setblock 360 178 453 minecraft:jack_o_lantern
fill 360 178 454 360 196 454 minecraft:red_concrete
fill 361 178 417 361 191 417 minecraft:red_concrete
setblock 361 178 418 minecraft:jack_o_lantern
fill 361 178 419 361 191 419 minecraft:red_concrete
setblock 361 178 420 minecraft:jack_o_lantern
fill 361 178 421 361 191 421 minecraft:red_concrete
fill 361 178 432 362 178 432 minecraft:white_concrete
fill 361 178 434 362 178 435 minecraft:white_concrete
fill 361 178 440 362 178 441 minecraft:white_concrete
setblock 361 178 442 minecraft:jack_o_lantern
setblock 361 178 443 minecraft:white_concrete
setblock 361 178 444 minecraft:jack_o_lantern
fill 361 178 445 361 196 445 minecraft:red_concrete
setblock 361 178 446 minecraft:jack_o_lantern
fill 361 178 447 361 196 447 minecraft:red_concrete
setblock 361 178 448 minecraft:jack_o_lantern
fill 361 178 449 361 196 449 minecraft:red_concrete
setblock 361 178 450 minecraft:jack_o_lantern
fill 361 178 451 361 196 451 minecraft:red_concrete
setblock 361 178 452 minecraft:jack_o_lantern
fill 361 178 453 361 196 453 minecraft:red_concrete
setblock 361 178 454 minecraft:jack_o_lantern
setblock 361 178 457 minecraft:red_concrete
setblock 362 178 417 minecraft:jack_o_lantern
fill 362 178 418 362 191 418 minecraft:red_concrete
setblock 362 178 419 minecraft:jack_o_lantern
fill 362 178 420 362 191 420 minecraft:red_concrete
setblock 362 178 421 minecraft:jack_o_lantern
fill 362 178 439 363 178 439 minecraft:white_concrete
setblock 362 178 442 minecraft:white_concrete
setblock 362 178 443 minecraft:jack_o_lantern
fill 362 178 444 362 196 444 minecraft:red_concrete
setblock 362 178 445 minecraft:jack_o_lantern
fill 362 178 446 362 196 446 minecraft:red_concrete
setblock 362 178 447 minecraft:jack_o_lantern
fill 362 178 448 362 196 448 minecraft:red_concrete
setblock 362 178 449 minecraft:jack_o_lantern
fill 362 178 450 362 196 450 minecraft:red_concrete
setblock 362 178 451 minecraft:jack_o_lantern
fill 362 178 452 362 196 452 minecraft:red_concrete
setblock 362 178 453 minecraft:jack_o_lantern
fill 362 178 454 362 196 454 minecraft:red_concrete
fill 363 178 417 363 191 417 minecraft:red_concrete
setblock 363 178 418 minecraft:jack_o_lantern
fill 363 178 419 363 191 419 minecraft:red_concrete
setblock 363 178 420 minecraft:jack_o_lantern
fill 363 178 421 363 191 421 minecraft:red_concrete
setblock 363 178 438 minecraft:white_concrete
setblock 363 178 442 minecraft:jack_o_lantern
fill 363 178 443 363 196 443 minecraft:red_concrete
setblock 363 178 444 minecraft:jack_o_lantern
fill 363 178 445 363 196 445 minecraft:red_concrete
setblock 363 178 446 minecraft:jack_o_lantern
fill 363 178 447 363 196 447 minecraft:red_concrete
setblock 363 178 448 minecraft:jack_o_lantern
fill 363 178 449 363 196 449 minecraft:red_concrete
setblock 363 178 450 minecraft:jack_o_lantern
fill 363 178 451 363 196 451 minecraft:red_concrete
setblock 363 178 452 minecraft:jack_o_lantern
fill 363 178 453 363 196 453 minecraft:red_concrete
setblock 363 178 454 minecraft:jack_o_lantern
setblock 364 178 417 minecraft:jack_o_lantern
fill 364 178 418 364 191 418 minecraft:red_concrete
setblock 364 178 419 minecraft:jack_o_lantern
fill 364 178 420 364 191 420 minecraft:red_concrete
setblock 364 178 421 minecraft:jack_o_lantern
fill 364 178 442 364 196 442 minecraft:red_concrete
setblock 364 178 443 minecraft:jack_o_lantern
fill 364 178 444 364 196 444 minecraft:red_concrete
setblock 364 178 445 minecraft:jack_o_lantern
fill 364 178 446 364 196 446 minecraft:red_concrete
setblock 364 178 447 minecraft:jack_o_lantern
fill 364 178 448 364 196 448 minecraft:red_concrete
setblock 364 178 449 minecraft:jack_o_lantern
fill 364 178 450 364 196 450 minecraft:red_concrete
setblock 364 178 451 minecraft:jack_o_lantern
fill 364 178 452 364 196 452 minecraft:red_concrete
setblock 364 178 453 minecraft:jack_o_lantern
fill 364 178 454 364 196 454 minecraft:red_concrete
fill 365 178 417 365 191 417 minecraft:red_concrete
setblock 365 178 418 minecraft:jack_o_lantern
fill 365 178 419 365 191 419 minecraft:red_concrete
setblock 365 178 420 minecraft:jack_o_lantern
fill 365 178 421 365 191 421 minecraft:red_concrete
setblock 365 178 442 minecraft:jack_o_lantern
fill 365 178 443 365 196 443 minecraft:red_concrete
setblock 365 178 444 minecraft:jack_o_lantern
fill 365 178 445 365 196 445 minecraft:red_concrete
setblock 365 178 446 minecraft:jack_o_lantern
fill 365 178 447 365 196 447 minecraft:red_concrete
setblock 365 178 448 minecraft:jack_o_lantern
fill 365 178 449 365 196 449 minecraft:red_concrete
setblock 365 178 450 minecraft:jack_o_lantern
fill 365 178 451 365 196 451 minecraft:red_concrete
setblock 365 178 452 minecraft:jack_o_lantern
fill 365 178 453 365 196 453 minecraft:red_concrete
setblock 365 178 454 minecraft:jack_o_lantern
setblock 366 178 417 minecraft:jack_o_lantern
fill 366 178 418 366 191 418 minecraft:red_concrete
setblock 366 178 419 minecraft:jack_o_lantern
fill 366 178 420 366 191 420 minecraft:red_concrete
setblock 366 178 421 minecraft:jack_o_lantern
fill 366 178 442 366 196 442 minecraft:red_concrete
setblock 366 178 443 minecraft:jack_o_lantern
fill 366 178 444 366 196 444 minecraft:red_concrete
setblock 366 178 445 minecraft:jack_o_lantern
fill 366 178 446 366 196 446 minecraft:red_concrete
setblock 366 178 447 minecraft:jack_o_lantern
fill 366 178 448 366 196 448 minecraft:red_concrete
setblock 366 178 449 minecraft:jack_o_lantern
fill 366 178 450 366 196 450 minecraft:red_concrete
setblock 366 178 451 minecraft:jack_o_lantern
fill 366 178 452 366 196 452 minecraft:red_concrete
setblock 366 178 453 minecraft:jack_o_lantern
fill 366 178 454 366 196 454 minecraft:red_concrete
fill 367 178 417 367 226 417 minecraft:red_concrete
setblock 367 178 418 minecraft:jack_o_lantern
fill 367 178 419 367 191 419 minecraft:red_concrete
setblock 367 178 420 minecraft:jack_o_lantern
fill 367 178 421 367 191 421 minecraft:red_concrete
setblock 367 178 442 minecraft:jack_o_lantern
fill 367 178 443 367 196 443 minecraft:red_concrete
setblock 367 178 444 minecraft:jack_o_lantern
fill 367 178 445 367 196 445 minecraft:red_concrete
setblock 367 178 446 minecraft:jack_o_lantern
fill 367 178 447 367 196 447 minecraft:red_concrete
setblock 367 178 448 minecraft:jack_o_lantern
fill 367 178 449 367 196 449 minecraft:red_concrete
setblock 367 178 450 minecraft:jack_o_lantern
fill 367 178 451 367 196 451 minecraft:red_concrete
setblock 367 178 452 minecraft:jack_o_lantern
fill 367 178 453 367 196 453 minecraft:red_concrete
setblock 367 178 454 minecraft:jack_o_lantern
setblock 368 178 417 minecraft:jack_o_lantern
fill 368 178 418 368 191 418 minecraft:red_concrete
setblock 368 178 419 minecraft:jack_o_lantern
fill 368 178 420 368 191 420 minecraft:red_concrete
setblock 368 178 421 minecraft:jack_o_lantern
fill 368 178 442 368 196 442 minecraft:red_concrete
setblock 368 178 443 minecraft:jack_o_lantern
fill 368 178 444 368 196 444 minecraft:red_concrete
setblock 368 178 445 minecraft:jack_o_lantern
fill 368 178 446 368 196 446 minecraft:red_concrete
setblock 368 178 447 minecraft:jack_o_lantern
fill 368 178 448 368 196 448 minecraft:red_concrete
setblock 368 178 449 minecraft:jack_o_lantern
fill 368 178 450 368 196 450 minecraft:red_concrete
setblock 368 178 451 minecraft:jack_o_lantern
fill 368 178 452 368 196 452 minecraft:red_concrete
setblock 368 178 453 minecraft:jack_o_lantern
fill 368 178 454 368 196 454 minecraft:red_concrete
setblock 368 178 457 minecraft:red_concrete
fill 369 178 417 369 191 417 minecraft:red_concrete
setblock 369 178 418 minecraft:jack_o_lantern
fill 369 178 419 369 191 419 minecraft:red_concrete
setblock 369 178 420 minecraft:jack_o_lantern
fill 369 178 421 369 191 421 minecraft:red_concrete
setblock 369 178 442 minecraft:jack_o_lantern
fill 369 178 443 369 196 443 minecraft:red_concrete
setblock 369 178 444 minecraft:jack_o_lantern
fill 369 178 445 369 196 445 minecraft:red_concrete
setblock 369 178 446 minecraft:jack_o_lantern
fill 369 178 447 369 196 447 minecraft:red_concrete
setblock 369 178 448 minecraft:jack_o_lantern
fill 369 178 449 369 196 449 minecraft:red_concrete
setblock 369 178 450 minecraft:jack_o_lantern
fill 369 178 451 369 196 451 minecraft:red_concrete
setblock 369 178 452 minecraft:jack_o_lantern
fill 369 178 453 369 196 453 minecraft:red_concrete
setblock 369 178 454 minecraft:jack_o_lantern
setblock 370 178 417 minecraft:jack_o_lantern
fill 370 178 418 370 192 418 minecraft:red_concrete
setblock 370 178 419 minecraft:jack_o_lantern
fill 370 178 420 370 191 420 minecraft:red_concrete
setblock 370 178 421 minecraft:jack_o_lantern
setblock 370 178 425 minecraft:red_concrete
setblock 370 178 432 minecraft:red_concrete
setblock 370 178 439 minecraft:red_concrete
fill 370 178 442 370 226 442 minecraft:red_concrete
setblock 370 178 443 minecraft:jack_o_lantern
fill 370 178 444 370 196 444 minecraft:red_concrete
setblock 370 178 445 minecraft:jack_o_lantern
fill 370 178 446 370 196 446 minecraft:red_concrete
setblock 370 178 447 minecraft:jack_o_lantern
fill 370 178 448 370 197 448 minecraft:red_concrete
setblock 370 178 449 minecraft:jack_o_lantern
fill 370 178 450 370 196 450 minecraft:red_concrete
setblock 370 178 451 minecraft:jack_o_lantern
fill 370 178 452 370 196 452 minecraft:red_concrete
setblock 370 178 453 minecraft:jack_o_lantern
fill 370 178 454 370 196 454 minecraft:red_concrete
fill 371 178 417 371 194 417 minecraft:purple_terracotta
setblock 371 178 418 minecraft:jack_o_lantern
setblock 371 178 420 minecraft:jack_o_lantern
fill 371 178 421 371 196 421 minecraft:purple_terracotta
fill 330 179 419 330 180 419 minecraft:red_concrete
fill 330 179 433 330 180 433 minecraft:red_concrete
fill 330 179 440 330 180 440 minecraft:red_concrete
fill 330 179 447 330 180 447 minecraft:red_concrete
fill 330 179 454 330 180 454 minecraft:red_concrete
fill 334 179 457 334 180 457 minecraft:red_concrete
fill 335 179 417 335 180 417 minecraft:red_concrete
fill 339 179 418 339 190 418 minecraft:red_wool
setblock 339 179 437 minecraft:yellow_concrete
fill 340 179 433 340 179 434 minecraft:yellow_concrete
setblock 340 179 436 minecraft:yellow_concrete
setblock 340 179 438 minecraft:yellow_concrete
fill 340 179 440 340 179 441 minecraft:yellow_concrete
fill 341 179 457 341 180 457 minecraft:red_concrete
fill 342 179 417 342 180 417 minecraft:red_concrete
setblock 342 179 430 minecraft:yellow_concrete
setblock 342 179 432 minecraft:yellow_concrete
setblock 342 179 434 minecraft:yellow_concrete
setblock 342 179 440 minecraft:yellow_concrete
setblock 342 179 442 minecraft:yellow_concrete
setblock 342 179 444 minecraft:yellow_concrete
fill 344 179 428 344 179 429 minecraft:yellow_concrete
fill 344 179 445 344 179 446 minecraft:yellow_concrete
fill 347 179 427 347 179 428 minecraft:yellow_concrete
fill 347 179 446 347 179 447 minecraft:yellow_concrete
fill 348 179 457 348 180 457 minecraft:red_concrete
fill 349 179 417 349 180 417 minecraft:red_concrete
fill 353 179 427 353 179 428 minecraft:yellow_concrete
fill 353 179 446 353 179 447 minecraft:yellow_concrete
fill 355 179 457 355 180 457 minecraft:red_concrete
fill 356 179 417 356 180 417 minecraft:red_concrete
fill 356 179 428 356 179 429 minecraft:yellow_concrete
fill 356 179 445 356 179 446 minecraft:yellow_concrete
setblock 358 179 430 minecraft:yellow_concrete
setblock 358 179 432 minecraft:yellow_concrete
setblock 358 179 442 minecraft:yellow_concrete
setblock 358 179 444 minecraft:yellow_concrete
setblock 359 179 435 minecraft:yellow_concrete
setblock 359 179 439 minecraft:yellow_concrete
fill 360 179 417 360 180 417 minecraft:red_concrete
fill 360 179 419 360 180 419 minecraft:red_concrete
fill 360 179 421 360 180 421 minecraft:red_concrete
fill 360 179 433 360 179 434 minecraft:yellow_concrete
setblock 360 179 436 minecraft:yellow_concrete
setblock 360 179 438 minecraft:yellow_concrete
fill 360 179 440 360 179 441 minecraft:yellow_concrete
fill 360 179 442 360 180 445 minecraft:red_concrete
fill 360 179 447 360 180 447 minecraft:red_concrete
fill 360 179 449 360 180 449 minecraft:red_concrete
fill 360 179 451 360 180 451 minecraft:red_concrete
fill 360 179 453 360 180 453 minecraft:red_concrete
fill 361 179 418 361 180 418 minecraft:red_concrete
fill 361 179 420 361 180 420 minecraft:red_concrete
setblock 361 179 437 minecraft:yellow_concrete
fill 361 179 442 361 180 444 minecraft:red_concrete
fill 361 179 446 361 180 446 minecraft:red_concrete
fill 361 179 448 361 180 448 minecraft:red_concrete
fill 361 179 450 361 180 450 minecraft:red_concrete
fill 361 179 452 361 180 452 minecraft:red_concrete
fill 361 179 454 361 180 454 minecraft:red_concrete
fill 362 179 417 362 180 417 minecraft:red_concrete
fill 362 179 419 362 180 419 minecraft:red_concrete
fill 362 179 421 362 180 421 minecraft:red_concrete
fill 362 179 442 362 180 443 minecraft:red_concrete
fill 362 179 445 362 180 445 minecraft:red_concrete
fill 362 179 447 362 180 447 minecraft:red_concrete
fill 362 179 449 362 180 449 minecraft:red_concrete
fill 362 179 451 362 180 451 minecraft:red_concrete
fill 362 179 453 362 180 453 minecraft:red_concrete
fill 362 179 457 362 180 457 minecraft:red_concrete
fill 363 179 418 363 180 418 minecraft:red_concrete
fill 363 179 420 363 180 420 minecraft:red_concrete
fill 363 179 442 363 180 442 minecraft:red_concrete
fill 363 179 444 363 180 444 minecraft:red_concrete
fill 363 179 446 363 180 446 minecraft:red_concrete
fill 363 179 448 363 180 448 minecraft:red_concrete
fill 363 179 450 363 180 450 minecraft:red_concrete
fill 363 179 452 363 180 452 minecraft:red_concrete
fill 363 179 454 363 180 454 minecraft:red_concrete
fill 364 179 417 364 180 417 minecraft:red_concrete
fill 364 179 419 364 180 419 minecraft:red_concrete
fill 364 179 421 364 180 421 minecraft:red_concrete
fill 364 179 443 364 180 443 minecraft:red_concrete
fill 364 179 445 364 180 445 minecraft:red_concrete
fill 364 179 447 364 180 447 minecraft:red_concrete
fill 364 179 449 364 180 449 minecraft:red_concrete
fill 364 179 451 364 180 451 minecraft:red_concrete
fill 364 179 453 364 180 453 minecraft:red_concrete
fill 365 179 418 365 180 418 minecraft:red_concrete
fill 365 179 420 365 180 420 minecraft:red_concrete
fill 365 179 442 365 180 442 minecraft:red_concrete
fill 365 179 444 365 180 444 minecraft:red_concrete
fill 365 179 446 365 180 446 minecraft:red_concrete
fill 365 179 448 365 180 448 minecraft:red_concrete
fill 365 179 450 365 180 450 minecraft:red_concrete
fill 365 179 452 365 180 452 minecraft:red_concrete
fill 365 179 454 365 180 454 minecraft:red_concrete
fill 366 179 417 366 180 417 minecraft:red_concrete
fill 366 179 419 366 180 419 minecraft:red_concrete
fill 366 179 421 366 180 421 minecraft:red_concrete
fill 366 179 443 366 180 443 minecraft:red_concrete
fill 366 179 445 366 180 445 minecraft:red_concrete
fill 366 179 447 366 180 447 minecraft:red_concrete
fill 366 179 449 366 180 449 minecraft:red_concrete
fill 366 179 451 366 180 451 minecraft:red_concrete
fill 366 179 453 366 180 453 minecraft:red_concrete
fill 367 179 418 367 180 418 minecraft:red_concrete
fill 367 179 420 367 180 420 minecraft:red_concrete
fill 367 179 442 367 180 442 minecraft:red_concrete
fill 367 179 444 367 180 444 minecraft:red_concrete
fill 367 179 446 367 180 446 minecraft:red_concrete
fill 367 179 448 367 180 448 minecraft:red_concrete
fill 367 179 450 367 180 450 minecraft:red_concrete
fill 367 179 452 367 180 452 minecraft:red_concrete
fill 367 179 454 367 180 454 minecraft:red_concrete
fill 368 179 417 368 180 417 minecraft:red_concrete
fill 368 179 419 368 180 419 minecraft:red_concrete
fill 368 179 421 368 180 421 minecraft:red_concrete
fill 368 179 443 368 180 443 minecraft:red_concrete
fill 368 179 445 368 180 445 minecraft:red_concrete
fill 368 179 447 368 180 447 minecraft:red_concrete
fill 368 179 449 368 180 449 minecraft:red_concrete
fill 368 179 451 368 180 451 minecraft:red_concrete
fill 368 179 453 368 180 453 minecraft:red_concrete
fill 369 179 418 369 180 418 minecraft:red_concrete
fill 369 179 420 369 180 420 minecraft:red_concrete
fill 369 179 442 369 180 442 minecraft:red_concrete
fill 369 179 444 369 180 444 minecraft:red_concrete
fill 369 179 446 369 180 446 minecraft:red_concrete
fill 369 179 448 369 180 448 minecraft:red_concrete
fill 369 179 450 369 180 450 minecraft:red_concrete
fill 369 179 452 369 180 452 minecraft:red_concrete
fill 369 179 454 369 180 454 minecraft:red_concrete
fill 369 179 457 369 180 457 minecraft:red_concrete
fill 370 179 417 370 180 417 minecraft:red_concrete
fill 370 179 419 370 180 419 minecraft:red_concrete
fill 370 179 421 370 180 421 minecraft:red_concrete
fill 370 179 424 370 180 424 minecraft:red_concrete
fill 370 179 431 370 180 431 minecraft:red_concrete
fill 370 179 438 370 180 438 minecraft:red_concrete
fill 370 179 443 370 180 443 minecraft:red_concrete
fill 370 179 445 370 180 445 minecraft:red_concrete
fill 370 179 447 370 180 447 minecraft:red_concrete
fill 370 179 449 370 180 449 minecraft:red_concrete
fill 370 179 451 370 180 451 minecraft:red_concrete
fill 370 179 453 370 180 453 minecraft:red_concrete
fill 371 179 418 371 180 418 minecraft:purple_terracotta
fill 371 179 420 371 180 420 minecraft:purple_terracotta
fill 330 180 417 330 180 418 minecraft:red_concrete
fill 330 180 420 330 180 421 minecraft:red_concrete
fill 330 180 430 330 180 432 minecraft:red_concrete
fill 330 180 434 330 180 435 minecraft:red_concrete
fill 330 180 437 330 180 439 minecraft:red_concrete
fill 330 180 441 330 180 442 minecraft:red_concrete
fill 330 180 444 330 180 446 minecraft:red_concrete
fill 330 180 448 330 180 449 minecraft:red_concrete
fill 330 180 451 330 180 453 minecraft:red_concrete
fill 330 180 455 330 180 456 minecraft:red_concrete
setblock 331 180 417 minecraft:red_concrete
fill 331 180 457 333 180 457 minecraft:red_concrete
fill 333 180 417 334 180 417 minecraft:red_concrete
fill 335 180 457 336 180 457 minecraft:red_concrete
fill 336 180 417 338 180 417 minecraft:red_concrete
fill 337 180 418 338 190 418 minecraft:red_wool
fill 338 180 457 340 180 457 minecraft:red_concrete
fill 340 180 417 341 180 417 minecraft:red_concrete
fill 340 180 418 341 190 418 minecraft:red_wool
fill 342 180 457 343 180 457 minecraft:red_concrete
fill 343 180 417 345 180 417 minecraft:red_concrete
fill 345 180 457 347 180 457 minecraft:red_concrete
fill 347 180 417 348 180 417 minecraft:red_concrete
fill 349 180 457 350 180 457 minecraft:red_concrete
fill 350 180 417 352 180 417 minecraft:red_concrete
fill 352 180 457 354 180 457 minecraft:red_concrete
fill 354 180 417 355 180 417 minecraft:red_concrete
fill 356 180 457 357 180 457 minecraft:red_concrete
fill 357 180 417 359 180 417 minecraft:red_concrete
fill 359 180 457 361 180 457 minecraft:red_concrete
fill 363 180 457 364 180 457 minecraft:red_concrete
fill 366 180 457 368 180 457 minecraft:red_concrete
fill 370 180 422 370 180 423 minecraft:red_concrete
fill 370 180 425 370 180 427 minecraft:red_concrete
fill 370 180 429 370 180 430 minecraft:red_concrete
fill 370 180 432 370 180 434 minecraft:red_concrete
fill 370 180 436 370 180 437 minecraft:red_concrete
fill 370 180 439 370 180 441 minecraft:red_concrete
setblock 370 180 455 minecraft:red_concrete
setblock 370 180 457 minecraft:red_concrete
setblock 330 181 421 minecraft:red_concrete
setblock 330 181 435 minecraft:red_concrete
setblock 330 181 442 minecraft:red_concrete
setblock 330 181 449 minecraft:red_concrete
setblock 330 181 456 minecraft:red_concrete
setblock 333 181 417 minecraft:red_concrete
setblock 336 181 457 minecraft:red_concrete
fill 339 181 423 339 182 423 minecraft:yellow_wool
setblock 340 181 417 minecraft:red_concrete
setblock 343 181 457 minecraft:red_concrete
setblock 347 181 417 minecraft:red_concrete
setblock 350 181 457 minecraft:red_concrete
setblock 354 181 417 minecraft:red_concrete
setblock 357 181 457 minecraft:red_concrete
setblock 360 181 417 minecraft:jack_o_lantern
setblock 360 181 419 minecraft:jack_o_lantern
setblock 360 181 421 minecraft:jack_o_lantern
fill 360 181 442 360 196 442 minecraft:red_concrete
setblock 360 181 443 minecraft:jack_o_lantern
fill 360 181 444 360 196 444 minecraft:red_concrete
setblock 360 181 445 minecraft:jack_o_lantern
setblock 360 181 447 minecraft:jack_o_lantern
setblock 360 181 449 minecraft:jack_o_lantern
setblock 360 181 451 minecraft:jack_o_lantern
setblock 360 181 453 minecraft:jack_o_lantern
setblock 361 181 418 minecraft:jack_o_lantern
setblock 361 181 420 minecraft:jack_o_lantern
setblock 361 181 442 minecraft:jack_o_lantern
fill 361 181 443 361 196 443 minecraft:red_concrete
setblock 361 181 444 minecraft:jack_o_lantern
setblock 361 181 446 minecraft:jack_o_lantern
setblock 361 181 448 minecraft:jack_o_lantern
setblock 361 181 450 minecraft:jack_o_lantern
setblock 361 181 452 minecraft:jack_o_lantern
setblock 361 181 454 minecraft:jack_o_lantern
setblock 362 181 417 minecraft:jack_o_lantern
setblock 362 181 419 minecraft:jack_o_lantern
setblock 362 181 421 minecraft:jack_o_lantern
fill 362 181 442 362 196 442 minecraft:red_concrete
setblock 362 181 443 minecraft:jack_o_lantern
setblock 362 181 445 minecraft:jack_o_lantern
setblock 362 181 447 minecraft:jack_o_lantern
setblock 362 181 449 minecraft:jack_o_lantern
setblock 362 181 451 minecraft:jack_o_lantern
setblock 362 181 453 minecraft:jack_o_lantern
setblock 363 181 418 minecraft:jack_o_lantern
setblock 363 181 420 minecraft:jack_o_lantern
setblock 363 181 442 minecraft:jack_o_lantern
setblock 363 181 444 minecraft:jack_o_lantern
setblock 363 181 446 minecraft:jack_o_lantern
setblock 363 181 448 minecraft:jack_o_lantern
setblock 363 181 450 minecraft:jack_o_lantern
setblock 363 181 452 minecraft:jack_o_lantern
setblock 363 181 454 minecraft:jack_o_lantern
setblock 364 181 417 minecraft:jack_o_lantern
setblock 364 181 419 minecraft:jack_o_lantern
setblock 364 181 421 minecraft:jack_o_lantern
setblock 364 181 443 minecraft:jack_o_lantern
setblock 364 181 445 minecraft:jack_o_lantern
setblock 364 181 447 minecraft:jack_o_lantern
setblock 364 181 449 minecraft:jack_o_lantern
setblock 364 181 451 minecraft:jack_o_lantern
setblock 364 181 453 minecraft:jack_o_lantern
setblock 364 181 457 minecraft:red_concrete
setblock 365 181 418 minecraft:jack_o_lantern
setblock 365 181 420 minecraft:jack_o_lantern
setblock 365 181 442 minecraft:jack_o_lantern
setblock 365 181 444 minecraft:jack_o_lantern
setblock 365 181 446 minecraft:jack_o_lantern
setblock 365 181 448 minecraft:jack_o_lantern
setblock 365 181 450 minecraft:jack_o_lantern
setblock 365 181 452 minecraft:jack_o_lantern
setblock 365 181 454 minecraft:jack_o_lantern
setblock 366 181 417 minecraft:jack_o_lantern
setblock 366 181 419 minecraft:jack_o_lantern
setblock 366 181 421 minecraft:jack_o_lantern
setblock 366 181 443 minecraft:jack_o_lantern
setblock 366 181 445 minecraft:jack_o_lantern
setblock 366 181 447 minecraft:jack_o_lantern
setblock 366 181 449 minecraft:jack_o_lantern
setblock 366 181 451 minecraft:jack_o_lantern
setblock 366 181 453 minecraft:jack_o_lantern
setblock 367 181 418 minecraft:jack_o_lantern
setblock 367 181 420 minecraft:jack_o_lantern
setblock 367 181 442 minecraft:jack_o_lantern
setblock 367 181 444 minecraft:jack_o_lantern
setblock 367 181 446 minecraft:jack_o_lantern
setblock 367 181 448 minecraft:jack_o_lantern
setblock 367 181 450 minecraft:jack_o_lantern
setblock 367 181 452 minecraft:jack_o_lantern
setblock 367 181 454 minecraft:jack_o_lantern
setblock 368 181 417 minecraft:jack_o_lantern
setblock 368 181 419 minecraft:jack_o_lantern
setblock 368 181 421 minecraft:jack_o_lantern
setblock 368 181 443 minecraft:jack_o_lantern
setblock 368 181 445 minecraft:jack_o_lantern
setblock 368 181 447 minecraft:jack_o_lantern
setblock 368 181 449 minecraft:jack_o_lantern
setblock 368 181 451 minecraft:jack_o_lantern
setblock 368 181 453 minecraft:jack_o_lantern
setblock 369 181 418 minecraft:jack_o_lantern
setblock 369 181 420 minecraft:jack_o_lantern
setblock 369 181 442 minecraft:jack_o_lantern
setblock 369 181 444 minecraft:jack_o_lantern
setblock 369 181 446 minecraft:jack_o_lantern
setblock 369 181 448 minecraft:jack_o_lantern
setblock 369 181 450 minecraft:jack_o_lantern
setblock 369 181 452 minecraft:jack_o_lantern
setblock 369 181 454 minecraft:jack_o_lantern
setblock 370 181 417 minecraft:jack_o_lantern
setblock 370 181 419 minecraft:jack_o_lantern
setblock 370 181 421 minecraft:jack_o_lantern
setblock 370 181 422 minecraft:red_concrete
setblock 370 181 429 minecraft:red_concrete
setblock 370 181 436 minecraft:red_concrete
setblock 370 181 443 minecraft:jack_o_lantern
setblock 370 181 445 minecraft:jack_o_lantern
setblock 370 181 447 minecraft:jack_o_lantern
setblock 370 181 449 minecraft:jack_o_lantern
setblock 370 181 451 minecraft:jack_o_lantern
setblock 370 181 453 minecraft:jack_o_lantern
setblock 371 181 418 minecraft:jack_o_lantern
setblock 371 181 420 minecraft:jack_o_lantern
fill 360 182 417 360 183 417 minecraft:red_concrete
fill 360 182 419 360 183 419 minecraft:red_concrete
fill 360 182 421 360 183 421 minecraft:red_concrete
fill 360 182 443 360 183 443 minecraft:red_concrete
fill 360 182 445 360 183 445 minecraft:red_concrete
fill 360 182 447 360 183 447 minecraft:red_concrete
fill 360 182 449 360 183 449 minecraft:red_concrete
fill 360 182 451 360 183 451 minecraft:red_concrete
fill 360 182 453 360 183 453 minecraft:red_concrete
fill 361 182 418 361 183 418 minecraft:red_concrete
fill 361 182 420 361 183 420 minecraft:red_concrete
fill 361 182 442 361 183 442 minecraft:red_concrete
fill 361 182 444 361 183 444 minecraft:red_concrete
fill 361 182 446 361 183 446 minecraft:red_concrete
fill 361 182 448 361 183 448 minecraft:red_concrete
fill 361 182 450 361 183 450 minecraft:red_concrete
fill 361 182 452 361 183 452 minecraft:red_concrete
fill 361 182 454 361 183 454 minecraft:red_concrete
fill 362 182 417 362 183 417 minecraft:red_concrete
fill 362 182 419 362 183 419 minecraft:red_concrete
fill 362 182 421 362 183 421 minecraft:red_concrete
fill 362 182 443 362 183 443 minecraft:red_concrete
fill 362 182 445 362 183 445 minecraft:red_concrete
fill 362 182 447 362 183 447 minecraft:red_concrete
fill 362 182 449 362 183 449 minecraft:red_concrete
fill 362 182 451 362 183 451 minecraft:red_concrete
fill 362 182 453 362 183 453 minecraft:red_concrete
fill 363 182 418 363 183 418 minecraft:red_concrete
fill 363 182 420 363 183 420 minecraft:red_concrete
fill 363 182 442 363 183 442 minecraft:red_concrete
fill 363 182 444 363 183 444 minecraft:red_concrete
fill 363 182 446 363 183 446 minecraft:red_concrete
fill 363 182 448 363 183 448 minecraft:red_concrete
fill 363 182 450 363 183 450 minecraft:red_concrete
fill 363 182 452 363 183 452 minecraft:red_concrete
fill 363 182 454 363 183 454 minecraft:red_concrete
fill 364 182 417 364 183 417 minecraft:red_concrete
fill 364 182 419 364 183 419 minecraft:red_concrete
fill 364 182 421 364 183 421 minecraft:red_concrete
fill 364 182 443 364 183 443 minecraft:red_concrete
fill 364 182 445 364 183 445 minecraft:red_concrete
fill 364 182 447 364 183 447 minecraft:red_concrete
fill 364 182 449 364 183 449 minecraft:red_concrete
fill 364 182 451 364 183 451 minecraft:red_concrete
fill 364 182 453 364 183 453 minecraft:red_concrete
fill 365 182 418 365 183 418 minecraft:red_concrete
fill 365 182 420 365 183 420 minecraft:red_concrete
fill 365 182 442 365 183 442 minecraft:red_concrete
fill 365 182 444 365 183 444 minecraft:red_concrete
fill 365 182 446 365 183 446 minecraft:red_concrete
fill 365 182 448 365 183 448 minecraft:red_concrete
fill 365 182 450 365 183 450 minecraft:red_concrete
fill 365 182 452 365 183 452 minecraft:red_concrete
fill 365 182 454 365 183 454 minecraft:red_concrete
fill 366 182 417 366 183 417 minecraft:red_concrete
fill 366 182 419 366 183 419 minecraft:red_concrete
fill 366 182 421 366 183 421 minecraft:red_concrete
fill 366 182 443 366 183 443 minecraft:red_concrete
fill 366 182 445 366 183 445 minecraft:red_concrete
fill 366 182 447 366 183 447 minecraft:red_concrete
fill 366 182 449 366 183 449 minecraft:red_concrete
fill 366 182 451 366 183 451 minecraft:red_concrete
fill 366 182 453 366 183 453 minecraft:red_concrete
fill 367 182 418 367 183 418 minecraft:red_concrete
fill 367 182 420 367 183 420 minecraft:red_concrete
fill 367 182 442 367 183 442 minecraft:red_concrete
fill 367 182 444 367 183 444 minecraft:red_concrete
fill 367 182 446 367 183 446 minecraft:red_concrete
fill 367 182 448 367 183 448 minecraft:red_concrete
fill 367 182 450 367 183 450 minecraft:red_concrete
fill 367 182 452 367 183 452 minecraft:red_concrete
fill 367 182 454 367 183 454 minecraft:red_concrete
fill 368 182 417 368 183 417 minecraft:red_concrete
fill 368 182 419 368 183 419 minecraft:red_concrete
fill 368 182 421 368 183 421 minecraft:red_concrete
fill 368 182 443 368 183 443 minecraft:red_concrete
fill 368 182 445 368 183 445 minecraft:red_concrete
fill 368 182 447 368 183 447 minecraft:red_concrete
fill 368 182 449 368 183 449 minecraft:red_concrete
fill 368 182 451 368 183 451 minecraft:red_concrete
fill 368 182 453 368 183 453 minecraft:red_concrete
fill 369 182 418 369 183 418 minecraft:red_concrete
fill 369 182 420 369 183 420 minecraft:red_concrete
fill 369 182 442 369 183 442 minecraft:red_concrete
fill 369 182 444 369 183 444 minecraft:red_concrete
fill 369 182 446 369 183 446 minecraft:red_concrete
fill 369 182 448 369 183 448 minecraft:red_concrete
fill 369 182 450 369 183 450 minecraft:red_concrete
fill 369 182 452 369 183 452 minecraft:red_concrete
fill 369 182 454 369 183 454 minecraft:red_concrete
fill 370 182 417 370 183 417 minecraft:red_concrete
fill 370 182 419 370 183 419 minecraft:red_concrete
fill 370 182 421 370 183 421 minecraft:red_concrete
fill 370 182 443 370 183 443 minecraft:red_concrete
fill 370 182 445 370 183 445 minecraft:red_concrete
fill 370 182 447 370 183 447 minecraft:red_concrete
fill 370 182 449 370 183 449 minecraft:red_concrete
fill 370 182 451 370 183 451 minecraft:red_concrete
fill 370 182 453 370 183 453 minecraft:red_concrete
fill 371 182 418 371 183 418 minecraft:purple_terracotta
fill 371 182 420 371 183 420 minecraft:purple_terracotta
setblock 330 183 430 minecraft:red_concrete
setblock 330 183 437 minecraft:red_concrete
setblock 330 183 444 minecraft:red_concrete
setblock 330 183 451 minecraft:red_concrete
setblock 331 183 417 minecraft:red_concrete
setblock 331 183 457 minecraft:red_concrete
fill 335 183 455 335 192 455 minecraft:red_wool
setblock 338 183 417 minecraft:red_concrete
setblock 338 183 457 minecraft:red_concrete
setblock 345 183 417 minecraft:red_concrete
setblock 345 183 457 minecraft:red_concrete
fill 348 183 448 349 184 449 minecraft:white_wool
setblock 352 183 417 minecraft:red_concrete
setblock 352 183 457 minecraft:red_concrete
setblock 359 183 417 minecraft:red_concrete
setblock 359 183 457 minecraft:red_concrete
setblock 366 183 457 minecraft:red_concrete
setblock 370 183 427 minecraft:red_concrete
setblock 370 183 434 minecraft:red_concrete
setblock 370 183 441 minecraft:red_concrete
setblock 370 183 455 minecraft:red_concrete
setblock 330 184 417 minecraft:red_concrete
setblock 330 184 431 minecraft:red_concrete
setblock 330 184 438 minecraft:red_concrete
setblock 330 184 445 minecraft:red_concrete
setblock 330 184 452 minecraft:red_concrete
setblock 332 184 419 minecraft:light[level=12]
setblock 332 184 435 minecraft:light[level=12]
setblock 332 184 443 minecraft:light[level=12]
setblock 332 184 451 minecraft:light[level=12]
setblock 332 184 457 minecraft:red_concrete
fill 333 184 455 334 192 455 minecraft:red_wool
fill 336 184 455 337 192 455 minecraft:red_wool
setblock 337 184 417 minecraft:red_concrete
setblock 339 184 457 minecraft:red_concrete
setblock 340 184 419 minecraft:light[level=12]
setblock 340 184 427 minecraft:light[level=12]
setblock 340 184 435 minecraft:light[level=12]
setblock 340 184 443 minecraft:light[level=12]
setblock 340 184 451 minecraft:light[level=12]
setblock 344 184 417 minecraft:red_concrete
setblock 346 184 457 minecraft:red_concrete
setblock 348 184 419 minecraft:light[level=12]
setblock 348 184 427 minecraft:light[level=12]
setblock 348 184 435 minecraft:light[level=12]
setblock 348 184 443 minecraft:light[level=12]
setblock 348 184 451 minecraft:light[level=12]
setblock 351 184 417 minecraft:red_concrete
setblock 353 184 457 minecraft:red_concrete
setblock 356 184 419 minecraft:light[level=12]
setblock 356 184 427 minecraft:light[level=12]
setblock 356 184 435 minecraft:light[level=12]
setblock 356 184 443 minecraft:light[level=12]
setblock 356 184 451 minecraft:light[level=12]
setblock 358 184 417 minecraft:red_concrete
setblock 360 184 417 minecraft:jack_o_lantern
setblock 360 184 419 minecraft:jack_o_lantern
setblock 360 184 421 minecraft:jack_o_lantern
setblock 360 184 443 minecraft:jack_o_lantern
setblock 360 184 445 minecraft:jack_o_lantern
setblock 360 184 447 minecraft:jack_o_lantern
setblock 360 184 449 minecraft:jack_o_lantern
setblock 360 184 451 minecraft:jack_o_lantern
setblock 360 184 453 minecraft:jack_o_lantern
setblock 360 184 457 minecraft:red_concrete
setblock 361 184 418 minecraft:jack_o_lantern
setblock 361 184 420 minecraft:jack_o_lantern
setblock 361 184 442 minecraft:jack_o_lantern
setblock 361 184 444 minecraft:jack_o_lantern
setblock 361 184 446 minecraft:jack_o_lantern
setblock 361 184 448 minecraft:jack_o_lantern
setblock 361 184 450 minecraft:jack_o_lantern
setblock 361 184 452 minecraft:jack_o_lantern
setblock 361 184 454 minecraft:jack_o_lantern
setblock 362 184 417 minecraft:jack_o_lantern
setblock 362 184 419 minecraft:jack_o_lantern
setblock 362 184 421 minecraft:jack_o_lantern
setblock 362 184 443 minecraft:jack_o_lantern
setblock 362 184 445 minecraft:jack_o_lantern
setblock 362 184 447 minecraft:jack_o_lantern
setblock 362 184 449 minecraft:jack_o_lantern
setblock 362 184 451 minecraft:jack_o_lantern
setblock 362 184 453 minecraft:jack_o_lantern
setblock 363 184 418 minecraft:jack_o_lantern
setblock 363 184 420 minecraft:jack_o_lantern
setblock 363 184 442 minecraft:jack_o_lantern
setblock 363 184 444 minecraft:jack_o_lantern
setblock 363 184 446 minecraft:jack_o_lantern
setblock 363 184 448 minecraft:jack_o_lantern
setblock 363 184 450 minecraft:jack_o_lantern
setblock 363 184 452 minecraft:jack_o_lantern
setblock 363 184 454 minecraft:jack_o_lantern
setblock 364 184 417 minecraft:jack_o_lantern
setblock 364 184 419 minecraft:jack_o_lantern
setblock 364 184 421 minecraft:jack_o_lantern
setblock 364 184 427 minecraft:light[level=12]
setblock 364 184 435 minecraft:light[level=12]
setblock 364 184 443 minecraft:jack_o_lantern
setblock 364 184 445 minecraft:jack_o_lantern
setblock 364 184 447 minecraft:jack_o_lantern
setblock 364 184 449 minecraft:jack_o_lantern
setblock 364 184 451 minecraft:jack_o_lantern
setblock 364 184 453 minecraft:jack_o_lantern
setblock 365 184 418 minecraft:jack_o_lantern
setblock 365 184 420 minecraft:jack_o_lantern
setblock 365 184 442 minecraft:jack_o_lantern
setblock 365 184 444 minecraft:jack_o_lantern
setblock 365 184 446 minecraft:jack_o_lantern
setblock 365 184 448 minecraft:jack_o_lantern
setblock 365 184 450 minecraft:jack_o_lantern
setblock 365 184 452 minecraft:jack_o_lantern
setblock 365 184 454 minecraft:jack_o_lantern
setblock 366 184 417 minecraft:jack_o_lantern
setblock 366 184 419 minecraft:jack_o_lantern
setblock 366 184 421 minecraft:jack_o_lantern
setblock 366 184 443 minecraft:jack_o_lantern
setblock 366 184 445 minecraft:jack_o_lantern
setblock 366 184 447 minecraft:jack_o_lantern
setblock 366 184 449 minecraft:jack_o_lantern
setblock 366 184 451 minecraft:jack_o_lantern
setblock 366 184 453 minecraft:jack_o_lantern
setblock 367 184 418 minecraft:jack_o_lantern
setblock 367 184 420 minecraft:jack_o_lantern
setblock 367 184 442 minecraft:jack_o_lantern
setblock 367 184 444 minecraft:jack_o_lantern
setblock 367 184 446 minecraft:jack_o_lantern
setblock 367 184 448 minecraft:jack_o_lantern
setblock 367 184 450 minecraft:jack_o_lantern
setblock 367 184 452 minecraft:jack_o_lantern
setblock 367 184 454 minecraft:jack_o_lantern
setblock 367 184 457 minecraft:red_concrete
setblock 368 184 417 minecraft:jack_o_lantern
setblock 368 184 419 minecraft:jack_o_lantern
setblock 368 184 421 minecraft:jack_o_lantern
setblock 368 184 443 minecraft:jack_o_lantern
setblock 368 184 445 minecraft:jack_o_lantern
setblock 368 184 447 minecraft:jack_o_lantern
setblock 368 184 449 minecraft:jack_o_lantern
setblock 368 184 451 minecraft:jack_o_lantern
setblock 368 184 453 minecraft:jack_o_lantern
setblock 369 184 418 minecraft:jack_o_lantern
setblock 369 184 420 minecraft:jack_o_lantern
setblock 369 184 442 minecraft:jack_o_lantern
setblock 369 184 444 minecraft:jack_o_lantern
setblock 369 184 446 minecraft:jack_o_lantern
setblock 369 184 448 minecraft:jack_o_lantern
setblock 369 184 450 minecraft:jack_o_lantern
setblock 369 184 452 minecraft:jack_o_lantern
setblock 369 184 454 minecraft:jack_o_lantern
setblock 370 184 417 minecraft:jack_o_lantern
setblock 370 184 419 minecraft:jack_o_lantern
setblock 370 184 421 minecraft:jack_o_lantern
setblock 370 184 426 minecraft:red_concrete
setblock 370 184 433 minecraft:red_concrete
setblock 370 184 440 minecraft:red_concrete
setblock 370 184 443 minecraft:jack_o_lantern
setblock 370 184 445 minecraft:jack_o_lantern
setblock 370 184 447 minecraft:jack_o_lantern
setblock 370 184 449 minecraft:jack_o_lantern
setblock 370 184 451 minecraft:jack_o_lantern
setblock 370 184 453 minecraft:jack_o_lantern
setblock 371 184 418 minecraft:jack_o_lantern
setblock 371 184 420 minecraft:jack_o_lantern
setblock 330 185 418 minecraft:red_concrete
setblock 330 185 432 minecraft:red_concrete
setblock 330 185 439 minecraft:red_concrete
setblock 330 185 446 minecraft:red_concrete
setblock 330 185 453 minecraft:red_concrete
setblock 333 185 457 minecraft:red_concrete
setblock 336 185 417 minecraft:red_concrete
setblock 340 185 457 minecraft:red_concrete
setblock 343 185 417 minecraft:red_concrete
setblock 347 185 457 minecraft:red_concrete
setblock 350 185 417 minecraft:red_concrete
setblock 354 185 457 minecraft:red_concrete
setblock 357 185 417 minecraft:red_concrete
fill 360 185 417 360 186 417 minecraft:red_concrete
fill 360 185 419 360 186 419 minecraft:red_concrete
fill 360 185 421 360 186 421 minecraft:red_concrete
fill 360 185 443 360 186 443 minecraft:red_concrete
fill 360 185 445 360 186 445 minecraft:red_concrete
fill 360 185 447 360 186 447 minecraft:red_concrete
fill 360 185 449 360 186 449 minecraft:red_concrete
fill 360 185 451 360 186 451 minecraft:red_concrete
fill 360 185 453 360 186 453 minecraft:red_concrete
fill 361 185 418 361 186 418 minecraft:red_concrete
fill 361 185 420 361 186 420 minecraft:red_concrete
fill 361 185 442 361 186 442 minecraft:red_concrete
fill 361 185 444 361 186 444 minecraft:red_concrete
fill 361 185 446 361 186 446 minecraft:red_concrete
fill 361 185 448 361 186 448 minecraft:red_concrete
fill 361 185 450 361 186 450 minecraft:red_concrete
fill 361 185 452 361 186 452 minecraft:red_concrete
fill 361 185 454 361 186 454 minecraft:red_concrete
setblock 361 185 457 minecraft:red_concrete
fill 362 185 417 362 186 417 minecraft:red_concrete
fill 362 185 419 362 186 419 minecraft:red_concrete
fill 362 185 421 362 186 421 minecraft:red_concrete
fill 362 185 443 362 186 443 minecraft:red_concrete
fill 362 185 445 362 186 445 minecraft:red_concrete
fill 362 185 447 362 186 447 minecraft:red_concrete
fill 362 185 449 362 186 449 minecraft:red_concrete
fill 362 185 451 362 186 451 minecraft:red_concrete
fill 362 185 453 362 186 453 minecraft:red_concrete
fill 363 185 418 363 186 418 minecraft:red_concrete
fill 363 185 420 363 186 420 minecraft:red_concrete
fill 363 185 442 363 186 442 minecraft:red_concrete
fill 363 185 444 363 186 444 minecraft:red_concrete
fill 363 185 446 363 186 446 minecraft:red_concrete
fill 363 185 448 363 186 448 minecraft:red_concrete
fill 363 185 450 363 186 450 minecraft:red_concrete
fill 363 185 452 363 186 452 minecraft:red_concrete
fill 363 185 454 363 186 454 minecraft:red_concrete
fill 364 185 417 364 186 417 minecraft:red_concrete
fill 364 185 419 364 186 419 minecraft:red_concrete
fill 364 185 421 364 186 421 minecraft:red_concrete
fill 364 185 443 364 186 443 minecraft:red_concrete
fill 364 185 445 364 186 445 minecraft:red_concrete
fill 364 185 447 364 186 447 minecraft:red_concrete
fill 364 185 449 364 186 449 minecraft:red_concrete
fill 364 185 451 364 186 451 minecraft:red_concrete
fill 364 185 453 364 186 453 minecraft:red_concrete
fill 365 185 418 365 186 418 minecraft:red_concrete
fill 365 185 420 365 186 420 minecraft:red_concrete
fill 365 185 442 365 186 442 minecraft:red_concrete
fill 365 185 444 365 186 444 minecraft:red_concrete
fill 365 185 446 365 186 446 minecraft:red_concrete
fill 365 185 448 365 186 448 minecraft:red_concrete
fill 365 185 450 365 186 450 minecraft:red_concrete
fill 365 185 452 365 186 452 minecraft:red_concrete
fill 365 185 454 365 186 454 minecraft:red_concrete
fill 366 185 417 366 186 417 minecraft:red_concrete
fill 366 185 419 366 186 419 minecraft:red_concrete
fill 366 185 421 366 186 421 minecraft:red_concrete
fill 366 185 443 366 186 443 minecraft:red_concrete
fill 366 185 445 366 186 445 minecraft:red_concrete
fill 366 185 447 366 186 447 minecraft:red_concrete
fill 366 185 449 366 186 449 minecraft:red_concrete
fill 366 185 451 366 186 451 minecraft:red_concrete
fill 366 185 453 366 186 453 minecraft:red_concrete
fill 367 185 418 367 186 418 minecraft:red_concrete
fill 367 185 420 367 186 420 minecraft:red_concrete
fill 367 185 442 367 186 442 minecraft:red_concrete
fill 367 185 444 367 186 444 minecraft:red_concrete
fill 367 185 446 367 186 446 minecraft:red_concrete
fill 367 185 448 367 186 448 minecraft:red_concrete
fill 367 185 450 367 186 450 minecraft:red_concrete
fill 367 185 452 367 186 452 minecraft:red_concrete
fill 367 185 454 367 186 454 minecraft:red_concrete
fill 368 185 417 368 186 417 minecraft:red_concrete
fill 368 185 419 368 186 419 minecraft:red_concrete
fill 368 185 421 368 186 421 minecraft:red_concrete
fill 368 185 443 368 186 443 minecraft:red_concrete
fill 368 185 445 368 186 445 minecraft:red_concrete
fill 368 185 447 368 186 447 minecraft:red_concrete
fill 368 185 449 368 186 449 minecraft:red_concrete
fill 368 185 451 368 186 451 minecraft:red_concrete
fill 368 185 453 368 186 453 minecraft:red_concrete
setblock 368 185 457 minecraft:red_concrete
fill 369 185 418 369 186 418 minecraft:red_concrete
fill 369 185 420 369 186 420 minecraft:red_concrete
fill 369 185 442 369 186 442 minecraft:red_concrete
fill 369 185 444 369 186 444 minecraft:red_concrete
fill 369 185 446 369 186 446 minecraft:red_concrete
fill 369 185 448 369 186 448 minecraft:red_concrete
fill 369 185 450 369 186 450 minecraft:red_concrete
fill 369 185 452 369 186 452 minecraft:red_concrete
fill 369 185 454 369 186 454 minecraft:red_concrete
fill 370 185 417 370 186 417 minecraft:red_concrete
fill 370 185 419 370 186 419 minecraft:red_concrete
fill 370 185 421 370 186 421 minecraft:red_concrete
setblock 370 185 425 minecraft:red_concrete
setblock 370 185 432 minecraft:red_concrete
setblock 370 185 439 minecraft:red_concrete
fill 370 185 443 370 186 443 minecraft:red_concrete
fill 370 185 445 370 186 445 minecraft:red_concrete
fill 370 185 447 370 186 447 minecraft:red_concrete
fill 370 185 449 370 186 449 minecraft:red_concrete
fill 370 185 451 370 186 451 minecraft:red_concrete
fill 370 185 453 370 186 453 minecraft:red_concrete
fill 371 185 418 371 186 418 minecraft:purple_terracotta
fill 371 185 420 371 186 420 minecraft:purple_terracotta
setblock 330 186 419 minecraft:red_concrete
setblock 330 186 433 minecraft:red_concrete
setblock 330 186 440 minecraft:red_concrete
setblock 330 186 447 minecraft:red_concrete
setblock 330 186 454 minecraft:red_concrete
setblock 334 186 457 minecraft:red_concrete
setblock 335 186 417 minecraft:red_concrete
setblock 341 186 457 minecraft:red_concrete
setblock 342 186 417 minecraft:red_concrete
setblock 348 186 457 minecraft:red_concrete
setblock 349 186 417 minecraft:red_concrete
setblock 355 186 457 minecraft:red_concrete
setblock 356 186 417 minecraft:red_concrete
setblock 362 186 457 minecraft:red_concrete
setblock 369 186 457 minecraft:red_concrete
setblock 370 186 424 minecraft:red_concrete
setblock 370 186 431 minecraft:red_concrete
setblock 370 186 438 minecraft:red_concrete
setblock 330 187 420 minecraft:red_concrete
setblock 330 187 434 minecraft:red_concrete
setblock 330 187 441 minecraft:red_concrete
setblock 330 187 448 minecraft:red_concrete
setblock 330 187 455 minecraft:red_concrete
setblock 334 187 417 minecraft:red_concrete
setblock 335 187 457 minecraft:red_concrete
setblock 341 187 417 minecraft:red_concrete
setblock 342 187 457 minecraft:red_concrete
setblock 348 187 417 minecraft:red_concrete
setblock 349 187 457 minecraft:red_concrete
setblock 355 187 417 minecraft:red_concrete
setblock 356 187 457 minecraft:red_concrete
setblock 360 187 417 minecraft:jack_o_lantern
setblock 360 187 419 minecraft:jack_o_lantern
setblock 360 187 421 minecraft:jack_o_lantern
setblock 360 187 443 minecraft:jack_o_lantern
setblock 360 187 445 minecraft:jack_o_lantern
setblock 360 187 447 minecraft:jack_o_lantern
setblock 360 187 449 minecraft:jack_o_lantern
setblock 360 187 451 minecraft:jack_o_lantern
setblock 360 187 453 minecraft:jack_o_lantern
setblock 361 187 418 minecraft:jack_o_lantern
setblock 361 187 420 minecraft:jack_o_lantern
setblock 361 187 442 minecraft:jack_o_lantern
setblock 361 187 444 minecraft:jack_o_lantern
setblock 361 187 446 minecraft:jack_o_lantern
setblock 361 187 448 minecraft:jack_o_lantern
setblock 361 187 450 minecraft:jack_o_lantern
setblock 361 187 452 minecraft:jack_o_lantern
setblock 361 187 454 minecraft:jack_o_lantern
setblock 362 187 417 minecraft:jack_o_lantern
setblock 362 187 419 minecraft:jack_o_lantern
setblock 362 187 421 minecraft:jack_o_lantern
setblock 362 187 443 minecraft:jack_o_lantern
setblock 362 187 445 minecraft:jack_o_lantern
setblock 362 187 447 minecraft:jack_o_lantern
setblock 362 187 449 minecraft:jack_o_lantern
setblock 362 187 451 minecraft:jack_o_lantern
setblock 362 187 453 minecraft:jack_o_lantern
setblock 363 187 418 minecraft:jack_o_lantern
setblock 363 187 420 minecraft:jack_o_lantern
setblock 363 187 442 minecraft:jack_o_lantern
setblock 363 187 444 minecraft:jack_o_lantern
setblock 363 187 446 minecraft:jack_o_lantern
setblock 363 187 448 minecraft:jack_o_lantern
setblock 363 187 450 minecraft:jack_o_lantern
setblock 363 187 452 minecraft:jack_o_lantern
setblock 363 187 454 minecraft:jack_o_lantern
setblock 363 187 457 minecraft:red_concrete
setblock 364 187 417 minecraft:jack_o_lantern
setblock 364 187 419 minecraft:jack_o_lantern
setblock 364 187 421 minecraft:jack_o_lantern
setblock 364 187 443 minecraft:jack_o_lantern
setblock 364 187 445 minecraft:jack_o_lantern
setblock 364 187 447 minecraft:jack_o_lantern
setblock 364 187 449 minecraft:jack_o_lantern
setblock 364 187 451 minecraft:jack_o_lantern
setblock 364 187 453 minecraft:jack_o_lantern
setblock 365 187 418 minecraft:jack_o_lantern
setblock 365 187 420 minecraft:jack_o_lantern
setblock 365 187 442 minecraft:jack_o_lantern
setblock 365 187 444 minecraft:jack_o_lantern
setblock 365 187 446 minecraft:jack_o_lantern
setblock 365 187 448 minecraft:jack_o_lantern
setblock 365 187 450 minecraft:jack_o_lantern
setblock 365 187 452 minecraft:jack_o_lantern
setblock 365 187 454 minecraft:jack_o_lantern
setblock 366 187 417 minecraft:jack_o_lantern
setblock 366 187 419 minecraft:jack_o_lantern
setblock 366 187 421 minecraft:jack_o_lantern
setblock 366 187 443 minecraft:jack_o_lantern
setblock 366 187 445 minecraft:jack_o_lantern
setblock 366 187 447 minecraft:jack_o_lantern
setblock 366 187 449 minecraft:jack_o_lantern
setblock 366 187 451 minecraft:jack_o_lantern
setblock 366 187 453 minecraft:jack_o_lantern
setblock 367 187 418 minecraft:jack_o_lantern
setblock 367 187 420 minecraft:jack_o_lantern
setblock 367 187 442 minecraft:jack_o_lantern
setblock 367 187 444 minecraft:jack_o_lantern
setblock 367 187 446 minecraft:jack_o_lantern
setblock 367 187 448 minecraft:jack_o_lantern
setblock 367 187 450 minecraft:jack_o_lantern
setblock 367 187 452 minecraft:jack_o_lantern
setblock 367 187 454 minecraft:jack_o_lantern
setblock 368 187 417 minecraft:jack_o_lantern
setblock 368 187 419 minecraft:jack_o_lantern
setblock 368 187 421 minecraft:jack_o_lantern
setblock 368 187 443 minecraft:jack_o_lantern
setblock 368 187 445 minecraft:jack_o_lantern
setblock 368 187 447 minecraft:jack_o_lantern
setblock 368 187 449 minecraft:jack_o_lantern
setblock 368 187 451 minecraft:jack_o_lantern
setblock 368 187 453 minecraft:jack_o_lantern
setblock 369 187 418 minecraft:jack_o_lantern
setblock 369 187 420 minecraft:jack_o_lantern
setblock 369 187 442 minecraft:jack_o_lantern
setblock 369 187 444 minecraft:jack_o_lantern
setblock 369 187 446 minecraft:jack_o_lantern
setblock 369 187 448 minecraft:jack_o_lantern
setblock 369 187 450 minecraft:jack_o_lantern
setblock 369 187 452 minecraft:jack_o_lantern
setblock 369 187 454 minecraft:jack_o_lantern
setblock 370 187 417 minecraft:jack_o_lantern
setblock 370 187 419 minecraft:jack_o_lantern
setblock 370 187 421 minecraft:jack_o_lantern
setblock 370 187 423 minecraft:red_concrete
setblock 370 187 430 minecraft:red_concrete
setblock 370 187 437 minecraft:red_concrete
setblock 370 187 443 minecraft:jack_o_lantern
setblock 370 187 445 minecraft:jack_o_lantern
setblock 370 187 447 minecraft:jack_o_lantern
setblock 370 187 449 minecraft:jack_o_lantern
setblock 370 187 451 minecraft:jack_o_lantern
setblock 370 187 453 minecraft:jack_o_lantern
setblock 370 187 457 minecraft:red_concrete
setblock 371 187 418 minecraft:jack_o_lantern
setblock 371 187 420 minecraft:jack_o_lantern
setblock 330 188 421 minecraft:red_concrete
setblock 330 188 435 minecraft:red_concrete
setblock 330 188 442 minecraft:red_concrete
setblock 330 188 449 minecraft:red_concrete
setblock 330 188 456 minecraft:red_concrete
setblock 333 188 417 minecraft:red_concrete
setblock 336 188 457 minecraft:red_concrete
setblock 340 188 417 minecraft:red_concrete
setblock 343 188 457 minecraft:red_concrete
setblock 347 188 417 minecraft:red_concrete
setblock 350 188 457 minecraft:red_concrete
setblock 354 188 417 minecraft:red_concrete
setblock 357 188 457 minecraft:red_concrete
fill 358 188 433 358 189 434 minecraft:white_wool
fill 360 188 417 360 189 417 minecraft:red_concrete
fill 360 188 419 360 189 419 minecraft:red_concrete
fill 360 188 421 360 189 421 minecraft:red_concrete
fill 360 188 443 360 189 443 minecraft:red_concrete
fill 360 188 445 360 189 445 minecraft:red_concrete
fill 360 188 447 360 189 447 minecraft:red_concrete
fill 360 188 449 360 189 449 minecraft:red_concrete
fill 360 188 451 360 189 451 minecraft:red_concrete
fill 360 188 453 360 189 453 minecraft:red_concrete
fill 361 188 418 361 189 418 minecraft:red_concrete
fill 361 188 420 361 189 420 minecraft:red_concrete
fill 361 188 442 361 189 442 minecraft:red_concrete
fill 361 188 444 361 189 444 minecraft:red_concrete
fill 361 188 446 361 189 446 minecraft:red_concrete
fill 361 188 448 361 189 448 minecraft:red_concrete
fill 361 188 450 361 189 450 minecraft:red_concrete
fill 361 188 452 361 189 452 minecraft:red_concrete
fill 361 188 454 361 189 454 minecraft:red_concrete
fill 362 188 417 362 189 417 minecraft:red_concrete
fill 362 188 419 362 189 419 minecraft:red_concrete
fill 362 188 421 362 189 421 minecraft:red_concrete
fill 362 188 443 362 189 443 minecraft:red_concrete
fill 362 188 445 362 189 445 minecraft:red_concrete
fill 362 188 447 362 189 447 minecraft:red_concrete
fill 362 188 449 362 189 449 minecraft:red_concrete
fill 362 188 451 362 189 451 minecraft:red_concrete
fill 362 188 453 362 189 453 minecraft:red_concrete
fill 363 188 418 363 189 418 minecraft:red_concrete
fill 363 188 420 363 189 420 minecraft:red_concrete
fill 363 188 442 363 189 442 minecraft:red_concrete
fill 363 188 444 363 189 444 minecraft:red_concrete
fill 363 188 446 363 189 446 minecraft:red_concrete
fill 363 188 448 363 189 448 minecraft:red_concrete
fill 363 188 450 363 189 450 minecraft:red_concrete
fill 363 188 452 363 189 452 minecraft:red_concrete
fill 363 188 454 363 189 454 minecraft:red_concrete
fill 364 188 417 364 189 417 minecraft:red_concrete
fill 364 188 419 364 189 419 minecraft:red_concrete
fill 364 188 421 364 189 421 minecraft:red_concrete
fill 364 188 443 364 189 443 minecraft:red_concrete
fill 364 188 445 364 189 445 minecraft:red_concrete
fill 364 188 447 364 189 447 minecraft:red_concrete
fill 364 188 449 364 189 449 minecraft:red_concrete
fill 364 188 451 364 189 451 minecraft:red_concrete
fill 364 188 453 364 189 453 minecraft:red_concrete
setblock 364 188 457 minecraft:red_concrete
fill 365 188 418 365 189 418 minecraft:red_concrete
fill 365 188 420 365 189 420 minecraft:red_concrete
fill 365 188 442 365 189 442 minecraft:red_concrete
fill 365 188 444 365 189 444 minecraft:red_concrete
fill 365 188 446 365 189 446 minecraft:red_concrete
fill 365 188 448 365 189 448 minecraft:red_concrete
fill 365 188 450 365 189 450 minecraft:red_concrete
fill 365 188 452 365 189 452 minecraft:red_concrete
fill 365 188 454 365 189 454 minecraft:red_concrete
fill 366 188 417 366 189 417 minecraft:red_concrete
fill 366 188 419 366 189 419 minecraft:red_concrete
fill 366 188 421 366 189 421 minecraft:red_concrete
fill 366 188 443 366 189 443 minecraft:red_concrete
fill 366 188 445 366 189 445 minecraft:red_concrete
fill 366 188 447 366 189 447 minecraft:red_concrete
fill 366 188 449 366 189 449 minecraft:red_concrete
fill 366 188 451 366 189 451 minecraft:red_concrete
fill 366 188 453 366 189 453 minecraft:red_concrete
fill 367 188 418 367 189 418 minecraft:red_concrete
fill 367 188 420 367 189 420 minecraft:red_concrete
fill 367 188 442 367 189 442 minecraft:red_concrete
fill 367 188 444 367 189 444 minecraft:red_concrete
fill 367 188 446 367 189 446 minecraft:red_concrete
fill 367 188 448 367 189 448 minecraft:red_concrete
fill 367 188 450 367 189 450 minecraft:red_concrete
fill 367 188 452 367 189 452 minecraft:red_concrete
fill 367 188 454 367 189 454 minecraft:red_concrete
fill 368 188 417 368 189 417 minecraft:red_concrete
fill 368 188 419 368 189 419 minecraft:red_concrete
fill 368 188 421 368 189 421 minecraft:red_concrete
fill 368 188 443 368 189 443 minecraft:red_concrete
fill 368 188 445 368 189 445 minecraft:red_concrete
fill 368 188 447 368 189 447 minecraft:red_concrete
fill 368 188 449 368 189 449 minecraft:red_concrete
fill 368 188 451 368 189 451 minecraft:red_concrete
fill 368 188 453 368 189 453 minecraft:red_concrete
fill 369 188 418 369 189 418 minecraft:red_concrete
fill 369 188 420 369 189 420 minecraft:red_concrete
fill 369 188 442 369 189 442 minecraft:red_concrete
fill 369 188 444 369 189 444 minecraft:red_concrete
fill 369 188 446 369 189 446 minecraft:red_concrete
fill 369 188 448 369 189 448 minecraft:red_concrete
fill 369 188 450 369 189 450 minecraft:red_concrete
fill 369 188 452 369 189 452 minecraft:red_concrete
fill 369 188 454 369 189 454 minecraft:red_concrete
fill 370 188 417 370 189 417 minecraft:red_concrete
fill 370 188 419 370 189 419 minecraft:red_concrete
fill 370 188 421 370 188 422 minecraft:red_concrete
setblock 370 188 429 minecraft:red_concrete
setblock 370 188 436 minecraft:red_concrete
fill 370 188 443 370 189 443 minecraft:red_concrete
fill 370 188 445 370 189 445 minecraft:red_concrete
fill 370 188 447 370 189 447 minecraft:red_concrete
fill 370 188 449 370 189 449 minecraft:red_concrete
fill 370 188 451 370 189 451 minecraft:red_concrete
fill 370 188 453 370 189 453 minecraft:red_concrete
fill 371 188 418 371 189 418 minecraft:purple_terracotta
fill 371 188 420 371 189 420 minecraft:purple_terracotta
setblock 370 189 421 minecraft:red_concrete
fill 330 190 417 330 190 421 minecraft:red_concrete
fill 330 190 430 330 190 435 minecraft:red_concrete
fill 330 190 437 330 190 442 minecraft:red_concrete
fill 330 190 444 330 190 449 minecraft:red_concrete
fill 330 190 451 330 190 456 minecraft:red_concrete
setblock 331 190 417 minecraft:red_concrete
fill 331 190 423 335 190 427 minecraft:white_concrete
fill 331 190 457 336 190 457 minecraft:red_concrete
fill 333 190 417 338 190 417 minecraft:red_concrete
fill 338 190 457 343 190 457 minecraft:red_concrete
fill 340 190 417 345 190 417 minecraft:red_concrete
fill 345 190 457 350 190 457 minecraft:red_concrete
fill 347 190 417 352 190 417 minecraft:red_concrete
fill 352 190 457 357 190 457 minecraft:red_concrete
fill 354 190 417 359 190 417 minecraft:red_concrete
fill 359 190 457 364 190 457 minecraft:red_concrete
setblock 360 190 417 minecraft:jack_o_lantern
setblock 360 190 419 minecraft:jack_o_lantern
setblock 360 190 421 minecraft:jack_o_lantern
setblock 360 190 443 minecraft:jack_o_lantern
setblock 360 190 445 minecraft:jack_o_lantern
setblock 360 190 447 minecraft:jack_o_lantern
setblock 360 190 449 minecraft:jack_o_lantern
setblock 360 190 451 minecraft:jack_o_lantern
setblock 360 190 453 minecraft:jack_o_lantern
setblock 361 190 418 minecraft:jack_o_lantern
setblock 361 190 420 minecraft:jack_o_lantern
setblock 361 190 442 minecraft:jack_o_lantern
setblock 361 190 444 minecraft:jack_o_lantern
setblock 361 190 446 minecraft:jack_o_lantern
setblock 361 190 448 minecraft:jack_o_lantern
setblock 361 190 450 minecraft:jack_o_lantern
setblock 361 190 452 minecraft:jack_o_lantern
setblock 361 190 454 minecraft:jack_o_lantern
setblock 362 190 417 minecraft:jack_o_lantern
setblock 362 190 419 minecraft:jack_o_lantern
setblock 362 190 421 minecraft:jack_o_lantern
setblock 362 190 443 minecraft:jack_o_lantern
setblock 362 190 445 minecraft:jack_o_lantern
setblock 362 190 447 minecraft:jack_o_lantern
setblock 362 190 449 minecraft:jack_o_lantern
setblock 362 190 451 minecraft:jack_o_lantern
setblock 362 190 453 minecraft:jack_o_lantern
setblock 363 190 418 minecraft:jack_o_lantern
setblock 363 190 420 minecraft:jack_o_lantern
setblock 363 190 442 minecraft:jack_o_lantern
setblock 363 190 444 minecraft:jack_o_lantern
setblock 363 190 446 minecraft:jack_o_lantern
setblock 363 190 448 minecraft:jack_o_lantern
setblock 363 190 450 minecraft:jack_o_lantern
setblock 363 190 452 minecraft:jack_o_lantern
setblock 363 190 454 minecraft:jack_o_lantern
setblock 364 190 417 minecraft:jack_o_lantern
setblock 364 190 419 minecraft:jack_o_lantern
setblock 364 190 421 minecraft:jack_o_lantern
setblock 364 190 443 minecraft:jack_o_lantern
setblock 364 190 445 minecraft:jack_o_lantern
setblock 364 190 447 minecraft:jack_o_lantern
setblock 364 190 449 minecraft:jack_o_lantern
setblock 364 190 451 minecraft:jack_o_lantern
setblock 364 190 453 minecraft:jack_o_lantern
setblock 365 190 418 minecraft:jack_o_lantern
setblock 365 190 420 minecraft:jack_o_lantern
setblock 365 190 442 minecraft:jack_o_lantern
setblock 365 190 444 minecraft:jack_o_lantern
setblock 365 190 446 minecraft:jack_o_lantern
setblock 365 190 448 minecraft:jack_o_lantern
setblock 365 190 450 minecraft:jack_o_lantern
setblock 365 190 452 minecraft:jack_o_lantern
setblock 365 190 454 minecraft:jack_o_lantern
setblock 366 190 417 minecraft:jack_o_lantern
setblock 366 190 419 minecraft:jack_o_lantern
setblock 366 190 421 minecraft:jack_o_lantern
setblock 366 190 443 minecraft:jack_o_lantern
setblock 366 190 445 minecraft:jack_o_lantern
setblock 366 190 447 minecraft:jack_o_lantern
setblock 366 190 449 minecraft:jack_o_lantern
setblock 366 190 451 minecraft:jack_o_lantern
setblock 366 190 453 minecraft:jack_o_lantern
fill 366 190 457 370 190 457 minecraft:red_concrete
setblock 367 190 418 minecraft:jack_o_lantern
setblock 367 190 420 minecraft:jack_o_lantern
setblock 367 190 442 minecraft:jack_o_lantern
setblock 367 190 444 minecraft:jack_o_lantern
setblock 367 190 446 minecraft:jack_o_lantern
setblock 367 190 448 minecraft:jack_o_lantern
setblock 367 190 450 minecraft:jack_o_lantern
setblock 367 190 452 minecraft:jack_o_lantern
setblock 367 190 454 minecraft:jack_o_lantern
setblock 368 190 417 minecraft:jack_o_lantern
setblock 368 190 419 minecraft:jack_o_lantern
setblock 368 190 421 minecraft:jack_o_lantern
setblock 368 190 443 minecraft:jack_o_lantern
setblock 368 190 445 minecraft:jack_o_lantern
setblock 368 190 447 minecraft:jack_o_lantern
setblock 368 190 449 minecraft:jack_o_lantern
setblock 368 190 451 minecraft:jack_o_lantern
setblock 368 190 453 minecraft:jack_o_lantern
setblock 369 190 418 minecraft:jack_o_lantern
setblock 369 190 420 minecraft:jack_o_lantern
setblock 369 190 442 minecraft:jack_o_lantern
setblock 369 190 444 minecraft:jack_o_lantern
setblock 369 190 446 minecraft:jack_o_lantern
setblock 369 190 448 minecraft:jack_o_lantern
setblock 369 190 450 minecraft:jack_o_lantern
setblock 369 190 452 minecraft:jack_o_lantern
setblock 369 190 454 minecraft:jack_o_lantern
setblock 370 190 417 minecraft:jack_o_lantern
setblock 370 190 419 minecraft:jack_o_lantern
setblock 370 190 421 minecraft:jack_o_lantern
fill 370 190 422 370 190 427 minecraft:red_concrete
fill 370 190 429 370 190 434 minecraft:red_concrete
fill 370 190 436 370 190 441 minecraft:red_concrete
setblock 370 190 443 minecraft:jack_o_lantern
setblock 370 190 445 minecraft:jack_o_lantern
setblock 370 190 447 minecraft:jack_o_lantern
setblock 370 190 449 minecraft:jack_o_lantern
setblock 370 190 451 minecraft:jack_o_lantern
setblock 370 190 453 minecraft:jack_o_lantern
setblock 370 190 455 minecraft:red_concrete
setblock 371 190 418 minecraft:jack_o_lantern
setblock 371 190 420 minecraft:jack_o_lantern
setblock 330 191 417 minecraft:red_concrete
fill 330 191 422 330 226 422 minecraft:red_concrete
setblock 330 191 424 minecraft:red_concrete
fill 330 191 429 330 226 429 minecraft:red_concrete
setblock 330 191 431 minecraft:red_concrete
setblock 330 191 438 minecraft:red_concrete
setblock 330 191 445 minecraft:red_concrete
setblock 330 191 452 minecraft:red_concrete
fill 332 191 424 334 191 426 minecraft:white_concrete
setblock 332 191 457 minecraft:red_concrete
fill 336 191 418 342 192 418 minecraft:gray_concrete
setblock 337 191 417 minecraft:red_concrete
setblock 339 191 457 minecraft:red_concrete
setblock 344 191 417 minecraft:red_concrete
setblock 346 191 457 minecraft:red_concrete
setblock 351 191 417 minecraft:red_concrete
setblock 353 191 457 minecraft:red_concrete
setblock 358 191 417 minecraft:red_concrete
fill 360 191 417 360 226 417 minecraft:red_concrete
setblock 360 191 419 minecraft:red_concrete
setblock 360 191 421 minecraft:red_concrete
fill 360 191 443 360 192 443 minecraft:red_concrete
fill 360 191 445 360 192 445 minecraft:red_concrete
fill 360 191 447 360 192 447 minecraft:red_concrete
fill 360 191 449 360 192 449 minecraft:red_concrete
fill 360 191 451 360 192 451 minecraft:red_concrete
fill 360 191 453 360 192 453 minecraft:red_concrete
setblock 360 191 457 minecraft:red_concrete
setblock 361 191 418 minecraft:red_concrete
setblock 361 191 420 minecraft:red_concrete
fill 361 191 442 361 192 442 minecraft:red_concrete
fill 361 191 444 361 192 444 minecraft:red_concrete
fill 361 191 446 361 192 446 minecraft:red_concrete
fill 361 191 448 361 192 448 minecraft:red_concrete
fill 361 191 450 361 192 450 minecraft:red_concrete
fill 361 191 452 361 192 452 minecraft:red_concrete
fill 361 191 454 361 192 454 minecraft:red_concrete
setblock 362 191 417 minecraft:red_concrete
setblock 362 191 419 minecraft:red_concrete
setblock 362 191 421 minecraft:red_concrete
fill 362 191 443 362 192 443 minecraft:red_concrete
fill 362 191 445 362 192 445 minecraft:red_concrete
fill 362 191 447 362 192 447 minecraft:red_concrete
fill 362 191 449 362 192 449 minecraft:red_concrete
fill 362 191 451 362 192 451 minecraft:red_concrete
fill 362 191 453 362 192 453 minecraft:red_concrete
setblock 363 191 418 minecraft:red_concrete
setblock 363 191 420 minecraft:red_concrete
fill 363 191 442 363 192 442 minecraft:red_concrete
fill 363 191 444 363 192 444 minecraft:red_concrete
fill 363 191 446 363 192 446 minecraft:red_concrete
fill 363 191 448 363 192 448 minecraft:red_concrete
fill 363 191 450 363 192 450 minecraft:red_concrete
fill 363 191 452 363 192 452 minecraft:red_concrete
fill 363 191 454 363 192 454 minecraft:red_concrete
fill 364 191 417 364 192 417 minecraft:red_concrete
setblock 364 191 419 minecraft:red_concrete
setblock 364 191 421 minecraft:red_concrete
fill 364 191 443 364 192 443 minecraft:red_concrete
fill 364 191 445 364 192 445 minecraft:red_concrete
fill 364 191 447 364 192 447 minecraft:red_concrete
fill 364 191 449 364 192 449 minecraft:red_concrete
fill 364 191 451 364 192 451 minecraft:red_concrete
fill 364 191 453 364 192 453 minecraft:red_concrete
setblock 365 191 418 minecraft:red_concrete
setblock 365 191 420 minecraft:red_concrete
fill 365 191 442 365 192 442 minecraft:red_concrete
fill 365 191 444 365 192 444 minecraft:red_concrete
fill 365 191 446 365 192 446 minecraft:red_concrete
fill 365 191 448 365 192 448 minecraft:red_concrete
fill 365 191 450 365 192 450 minecraft:red_concrete
fill 365 191 452 365 192 452 minecraft:red_concrete
fill 365 191 454 365 192 454 minecraft:red_concrete
setblock 366 191 417 minecraft:red_concrete
setblock 366 191 419 minecraft:red_concrete
setblock 366 191 421 minecraft:red_concrete
fill 366 191 443 366 192 443 minecraft:red_concrete
fill 366 191 445 366 192 445 minecraft:red_concrete
fill 366 191 447 366 192 447 minecraft:red_concrete
fill 366 191 449 366 192 449 minecraft:red_concrete
fill 366 191 451 366 192 451 minecraft:red_concrete
fill 366 191 453 366 192 453 minecraft:red_concrete
setblock 367 191 418 minecraft:red_concrete
setblock 367 191 420 minecraft:red_concrete
fill 367 191 442 367 192 442 minecraft:red_concrete
fill 367 191 444 367 192 444 minecraft:red_concrete
fill 367 191 446 367 192 446 minecraft:red_concrete
fill 367 191 448 367 192 448 minecraft:red_concrete
fill 367 191 450 367 192 450 minecraft:red_concrete
fill 367 191 452 367 192 452 minecraft:red_concrete
fill 367 191 454 367 192 454 minecraft:red_concrete
setblock 367 191 457 minecraft:red_concrete
setblock 368 191 417 minecraft:red_concrete
setblock 368 191 419 minecraft:red_concrete
setblock 368 191 421 minecraft:red_concrete
fill 368 191 443 368 192 443 minecraft:red_concrete
fill 368 191 445 368 192 445 minecraft:red_concrete
fill 368 191 447 368 192 447 minecraft:red_concrete
fill 368 191 449 368 192 449 minecraft:red_concrete
fill 368 191 451 368 192 451 minecraft:red_concrete
fill 368 191 453 368 192 453 minecraft:red_concrete
setblock 369 191 418 minecraft:red_concrete
setblock 369 191 420 minecraft:red_concrete
fill 369 191 442 369 192 442 minecraft:red_concrete
fill 369 191 444 369 192 444 minecraft:red_concrete
fill 369 191 446 369 192 446 minecraft:red_concrete
fill 369 191 448 369 192 448 minecraft:red_concrete
fill 369 191 450 369 192 450 minecraft:red_concrete
fill 369 191 452 369 192 452 minecraft:red_concrete
fill 369 191 454 369 192 454 minecraft:red_concrete
setblock 370 191 417 minecraft:red_concrete
setblock 370 191 419 minecraft:red_concrete
fill 370 191 421 370 226 421 minecraft:red_concrete
setblock 370 191 426 minecraft:red_concrete
setblock 370 191 433 minecraft:red_concrete
setblock 370 191 440 minecraft:red_concrete
fill 370 191 443 370 192 443 minecraft:red_concrete
fill 370 191 445 370 192 445 minecraft:red_concrete
fill 370 191 447 370 192 447 minecraft:red_concrete
fill 370 191 449 370 192 449 minecraft:red_concrete
fill 370 191 451 370 192 451 minecraft:red_concrete
fill 370 191 453 370 192 453 minecraft:red_concrete
fill 371 191 418 371 196 418 minecraft:purple_terracotta
fill 371 191 420 371 196 420 minecraft:purple_terracotta
setblock 330 192 418 minecraft:red_concrete
setblock 330 192 425 minecraft:red_concrete
setblock 330 192 432 minecraft:red_concrete
setblock 330 192 439 minecraft:red_concrete
setblock 330 192 446 minecraft:red_concrete
setblock 330 192 453 minecraft:red_concrete
setblock 332 192 419 minecraft:light[level=12]
setblock 332 192 427 minecraft:light[level=12]
setblock 332 192 435 minecraft:light[level=12]
setblock 332 192 443 minecraft:light[level=12]
setblock 332 192 451 minecraft:light[level=12]
fill 333 192 425 333 193 425 minecraft:white_concrete
setblock 333 192 457 minecraft:red_concrete
setblock 336 192 417 minecraft:red_concrete
setblock 340 192 419 minecraft:light[level=12]
setblock 340 192 427 minecraft:light[level=12]
setblock 340 192 435 minecraft:light[level=12]
setblock 340 192 443 minecraft:light[level=12]
setblock 340 192 451 minecraft:light[level=12]
setblock 340 192 457 minecraft:red_concrete
setblock 343 192 417 minecraft:red_concrete
setblock 347 192 457 minecraft:red_concrete
setblock 348 192 419 minecraft:light[level=12]
setblock 348 192 427 minecraft:light[level=12]
setblock 348 192 435 minecraft:light[level=12]
setblock 348 192 443 minecraft:light[level=12]
setblock 348 192 451 minecraft:light[level=12]
setblock 350 192 417 minecraft:red_concrete
setblock 354 192 457 minecraft:red_concrete
setblock 356 192 419 minecraft:light[level=12]
setblock 356 192 427 minecraft:light[level=12]
setblock 356 192 435 minecraft:light[level=12]
setblock 356 192 443 minecraft:light[level=12]
setblock 356 192 451 minecraft:light[level=12]
setblock 357 192 417 minecraft:red_concrete
fill 361 192 418 369 192 420 minecraft:white_concrete
setblock 361 192 457 minecraft:red_concrete
setblock 364 192 427 minecraft:light[level=12]
setblock 364 192 435 minecraft:light[level=12]
setblock 368 192 457 minecraft:red_concrete
fill 370 192 419 370 192 420 minecraft:white_concrete
setblock 370 192 425 minecraft:red_concrete
setblock 370 192 432 minecraft:red_concrete
setblock 370 192 439 minecraft:red_concrete
setblock 329 193 428 minecraft:black_concrete
fill 329 193 433 329 193 434 minecraft:purple_terracotta
setblock 329 193 435 minecraft:black_concrete
fill 329 193 445 329 194 448 minecraft:purple_terracotta
setblock 329 193 449 minecraft:black_concrete
fill 329 193 450 329 196 450 minecraft:purple_terracotta
setblock 330 193 419 minecraft:red_concrete
setblock 330 193 426 minecraft:red_concrete
setblock 330 193 433 minecraft:red_concrete
setblock 330 193 440 minecraft:red_concrete
setblock 330 193 447 minecraft:red_concrete
setblock 330 193 454 minecraft:red_concrete
setblock 331 193 458 minecraft:purple_terracotta
fill 332 193 416 335 196 416 minecraft:purple_terracotta
fill 332 193 424 332 193 426 minecraft:white_concrete
fill 332 193 455 338 194 455 minecraft:gray_concrete
setblock 332 193 458 minecraft:black_concrete
fill 333 193 424 334 193 424 minecraft:white_concrete
fill 333 193 426 334 193 426 minecraft:white_concrete
fill 333 193 458 333 196 458 minecraft:purple_terracotta
setblock 334 193 425 minecraft:white_concrete
setblock 334 193 457 minecraft:red_concrete
setblock 335 193 417 minecraft:red_concrete
setblock 336 193 416 minecraft:black_concrete
fill 336 193 458 337 196 458 minecraft:purple_terracotta
fill 337 193 416 346 193 416 minecraft:purple_terracotta
setblock 338 193 458 minecraft:black_concrete
setblock 341 193 457 minecraft:red_concrete
setblock 342 193 417 minecraft:red_concrete
setblock 347 193 416 minecraft:black_concrete
fill 348 193 416 348 196 416 minecraft:purple_terracotta
setblock 348 193 457 minecraft:red_concrete
setblock 349 193 417 minecraft:red_concrete
fill 350 193 416 351 194 416 minecraft:purple_terracotta
fill 351 193 458 351 196 458 minecraft:purple_terracotta
setblock 352 193 416 minecraft:black_concrete
setblock 352 193 458 minecraft:black_concrete
fill 354 193 416 362 193 416 minecraft:purple_terracotta
setblock 355 193 457 minecraft:red_concrete
setblock 356 193 417 minecraft:red_concrete
fill 356 193 458 356 195 458 minecraft:black_concrete
fill 357 193 458 357 196 458 minecraft:purple_terracotta
setblock 358 193 458 minecraft:black_concrete
setblock 360 193 443 minecraft:jack_o_lantern
setblock 360 193 445 minecraft:jack_o_lantern
setblock 360 193 447 minecraft:jack_o_lantern
setblock 360 193 449 minecraft:jack_o_lantern
setblock 360 193 451 minecraft:jack_o_lantern
setblock 360 193 453 minecraft:jack_o_lantern
setblock 361 193 442 minecraft:jack_o_lantern
setblock 361 193 444 minecraft:jack_o_lantern
setblock 361 193 446 minecraft:jack_o_lantern
setblock 361 193 448 minecraft:jack_o_lantern
setblock 361 193 450 minecraft:jack_o_lantern
setblock 361 193 452 minecraft:jack_o_lantern
setblock 361 193 454 minecraft:jack_o_lantern
fill 362 193 419 370 193 419 minecraft:white_concrete
setblock 362 193 443 minecraft:jack_o_lantern
setblock 362 193 445 minecraft:jack_o_lantern
setblock 362 193 447 minecraft:jack_o_lantern
setblock 362 193 449 minecraft:jack_o_lantern
setblock 362 193 451 minecraft:jack_o_lantern
setblock 362 193 453 minecraft:jack_o_lantern
setblock 362 193 457 minecraft:red_concrete
fill 363 193 416 363 194 416 minecraft:black_concrete
setblock 363 193 417 minecraft:red_concrete
setblock 363 193 442 minecraft:jack_o_lantern
setblock 363 193 444 minecraft:jack_o_lantern
setblock 363 193 446 minecraft:jack_o_lantern
setblock 363 193 448 minecraft:jack_o_lantern
setblock 363 193 450 minecraft:jack_o_lantern
setblock 363 193 452 minecraft:jack_o_lantern
setblock 363 193 454 minecraft:jack_o_lantern
fill 364 193 416 365 196 416 minecraft:purple_terracotta
setblock 364 193 443 minecraft:jack_o_lantern
setblock 364 193 445 minecraft:jack_o_lantern
setblock 364 193 447 minecraft:jack_o_lantern
setblock 364 193 449 minecraft:jack_o_lantern
setblock 364 193 451 minecraft:jack_o_lantern
setblock 364 193 453 minecraft:jack_o_lantern
setblock 365 193 442 minecraft:jack_o_lantern
setblock 365 193 444 minecraft:jack_o_lantern
setblock 365 193 446 minecraft:jack_o_lantern
setblock 365 193 448 minecraft:jack_o_lantern
setblock 365 193 450 minecraft:jack_o_lantern
setblock 365 193 452 minecraft:jack_o_lantern
setblock 365 193 454 minecraft:jack_o_lantern
setblock 366 193 416 minecraft:black_concrete
setblock 366 193 443 minecraft:jack_o_lantern
setblock 366 193 445 minecraft:jack_o_lantern
setblock 366 193 447 minecraft:jack_o_lantern
setblock 366 193 449 minecraft:jack_o_lantern
setblock 366 193 451 minecraft:jack_o_lantern
setblock 366 193 453 minecraft:jack_o_lantern
setblock 367 193 442 minecraft:jack_o_lantern
setblock 367 193 444 minecraft:jack_o_lantern
setblock 367 193 446 minecraft:jack_o_lantern
setblock 367 193 448 minecraft:jack_o_lantern
setblock 367 193 450 minecraft:jack_o_lantern
setblock 367 193 452 minecraft:jack_o_lantern
setblock 367 193 454 minecraft:jack_o_lantern
fill 368 193 416 368 194 416 minecraft:purple_terracotta
setblock 368 193 443 minecraft:jack_o_lantern
setblock 368 193 445 minecraft:jack_o_lantern
setblock 368 193 447 minecraft:jack_o_lantern
setblock 368 193 449 minecraft:jack_o_lantern
setblock 368 193 451 minecraft:jack_o_lantern
setblock 368 193 453 minecraft:jack_o_lantern
setblock 369 193 416 minecraft:black_concrete
setblock 369 193 442 minecraft:jack_o_lantern
setblock 369 193 444 minecraft:jack_o_lantern
setblock 369 193 446 minecraft:jack_o_lantern
setblock 369 193 448 minecraft:jack_o_lantern
setblock 369 193 450 minecraft:jack_o_lantern
setblock 369 193 452 minecraft:jack_o_lantern
setblock 369 193 454 minecraft:jack_o_lantern
setblock 369 193 457 minecraft:red_concrete
fill 370 193 416 370 196 416 minecraft:purple_terracotta
setblock 370 193 417 minecraft:red_concrete
setblock 370 193 424 minecraft:red_concrete
setblock 370 193 431 minecraft:red_concrete
setblock 370 193 438 minecraft:red_concrete
setblock 370 193 443 minecraft:jack_o_lantern
setblock 370 193 445 minecraft:jack_o_lantern
setblock 370 193 447 minecraft:jack_o_lantern
setblock 370 193 449 minecraft:jack_o_lantern
setblock 370 193 451 minecraft:jack_o_lantern
setblock 370 193 453 minecraft:jack_o_lantern
fill 371 193 428 371 193 432 minecraft:purple_terracotta
setblock 371 193 433 minecraft:black_concrete
fill 371 193 434 371 196 434 minecraft:purple_terracotta
setblock 371 193 457 minecraft:black_concrete
fill 329 194 428 329 197 428 minecraft:purple_terracotta
setblock 329 194 433 minecraft:black_concrete
fill 329 194 434 329 196 435 minecraft:purple_terracotta
fill 329 194 438 329 194 439 minecraft:purple_terracotta
setblock 329 194 440 minecraft:black_concrete
fill 329 194 441 329 196 442 minecraft:purple_terracotta
fill 329 194 449 329 196 449 minecraft:purple_terracotta
setblock 330 194 420 minecraft:red_concrete
setblock 330 194 427 minecraft:red_concrete
setblock 330 194 434 minecraft:red_concrete
setblock 330 194 441 minecraft:red_concrete
setblock 330 194 448 minecraft:red_concrete
setblock 330 194 455 minecraft:red_concrete
setblock 331 194 458 minecraft:black_concrete
fill 332 194 458 332 196 458 minecraft:purple_terracotta
setblock 334 194 417 minecraft:red_concrete
setblock 335 194 457 minecraft:red_concrete
fill 336 194 416 337 194 416 minecraft:purple_terracotta
setblock 338 194 416 minecraft:black_concrete
fill 338 194 458 338 196 458 minecraft:purple_terracotta
fill 339 194 416 339 196 416 minecraft:purple_terracotta
setblock 340 194 416 minecraft:black_concrete
fill 340 194 458 341 196 458 minecraft:purple_terracotta
fill 341 194 416 345 196 416 minecraft:purple_terracotta
setblock 341 194 417 minecraft:red_concrete
setblock 342 194 457 minecraft:red_concrete
setblock 342 194 458 minecraft:black_concrete
fill 343 194 458 347 196 458 minecraft:purple_terracotta
setblock 346 194 416 minecraft:black_concrete
fill 347 194 416 347 196 416 minecraft:purple_terracotta
setblock 348 194 417 minecraft:red_concrete
fill 348 194 458 348 195 458 minecraft:black_concrete
setblock 349 194 457 minecraft:red_concrete
fill 349 194 458 350 196 458 minecraft:purple_terracotta
fill 352 194 416 352 196 416 minecraft:purple_terracotta
fill 352 194 458 352 196 458 minecraft:purple_terracotta
setblock 353 194 416 minecraft:black_concrete
fill 354 194 416 359 194 416 minecraft:purple_terracotta
setblock 355 194 417 minecraft:red_concrete
setblock 356 194 457 minecraft:red_concrete
fill 358 194 458 358 197 458 minecraft:purple_terracotta
setblock 360 194 416 minecraft:black_concrete
fill 360 194 443 360 196 443 minecraft:red_concrete
fill 360 194 445 360 196 445 minecraft:red_concrete
fill 360 194 447 360 196 447 minecraft:red_concrete
fill 360 194 449 360 196 449 minecraft:red_concrete
fill 360 194 451 360 196 451 minecraft:red_concrete
fill 360 194 453 360 196 453 minecraft:red_concrete
fill 361 194 416 362 196 416 minecraft:purple_terracotta
fill 361 194 442 361 196 442 minecraft:red_concrete
fill 361 194 444 361 196 444 minecraft:red_concrete
fill 361 194 446 361 196 446 minecraft:red_concrete
fill 361 194 448 361 196 448 minecraft:red_concrete
fill 361 194 450 361 196 450 minecraft:red_concrete
fill 361 194 452 361 196 452 minecraft:red_concrete
fill 361 194 454 361 196 454 minecraft:red_concrete
setblock 362 194 417 minecraft:red_concrete
fill 362 194 443 362 196 443 minecraft:red_concrete
fill 362 194 445 362 196 445 minecraft:red_concrete
fill 362 194 447 362 196 447 minecraft:red_concrete
fill 362 194 449 362 196 449 minecraft:red_concrete
fill 362 194 451 362 196 451 minecraft:red_concrete
fill 362 194 453 362 196 453 minecraft:red_concrete
fill 363 194 418 369 194 420 minecraft:white_concrete
fill 363 194 442 363 196 442 minecraft:red_concrete
fill 363 194 444 363 196 444 minecraft:red_concrete
fill 363 194 446 363 196 446 minecraft:red_concrete
fill 363 194 448 363 196 448 minecraft:red_concrete
fill 363 194 450 363 196 450 minecraft:red_concrete
fill 363 194 452 363 196 452 minecraft:red_concrete
fill 363 194 454 363 196 454 minecraft:red_concrete
setblock 363 194 457 minecraft:red_concrete
fill 364 194 443 364 196 443 minecraft:red_concrete
fill 364 194 445 364 196 445 minecraft:red_concrete
fill 364 194 447 364 196 447 minecraft:red_concrete
fill 364 194 449 364 196 449 minecraft:red_concrete
fill 364 194 451 364 196 451 minecraft:red_concrete
fill 364 194 453 364 196 453 minecraft:red_concrete
fill 364 194 458 364 195 458 minecraft:black_concrete
fill 365 194 442 365 196 442 minecraft:red_concrete
fill 365 194 444 365 196 444 minecraft:red_concrete
fill 365 194 446 365 196 446 minecraft:red_concrete
fill 365 194 448 365 196 448 minecraft:red_concrete
fill 365 194 450 365 196 450 minecraft:red_concrete
fill 365 194 452 365 196 452 minecraft:red_concrete
fill 365 194 454 365 196 454 minecraft:red_concrete
fill 366 194 416 366 196 416 minecraft:purple_terracotta
fill 366 194 443 366 196 443 minecraft:red_concrete
fill 366 194 445 366 196 445 minecraft:red_concrete
fill 366 194 447 366 196 447 minecraft:red_concrete
fill 366 194 449 366 196 449 minecraft:red_concrete
fill 366 194 451 366 196 451 minecraft:red_concrete
fill 366 194 453 366 196 453 minecraft:red_concrete
fill 367 194 442 367 196 442 minecraft:red_concrete
fill 367 194 444 367 196 444 minecraft:red_concrete
fill 367 194 446 367 196 446 minecraft:red_concrete
fill 367 194 448 367 196 448 minecraft:red_concrete
fill 367 194 450 367 196 450 minecraft:red_concrete
fill 367 194 452 367 196 452 minecraft:red_concrete
fill 367 194 454 367 196 454 minecraft:red_concrete
fill 368 194 443 368 196 443 minecraft:red_concrete
fill 368 194 445 368 196 445 minecraft:red_concrete
fill 368 194 447 368 196 447 minecraft:red_concrete
fill 368 194 449 368 196 449 minecraft:red_concrete
fill 368 194 451 368 196 451 minecraft:red_concrete
fill 368 194 453 368 196 453 minecraft:red_concrete
setblock 368 194 458 minecraft:black_concrete
fill 369 194 416 369 196 416 minecraft:purple_terracotta
setblock 369 194 417 minecraft:red_concrete
fill 369 194 442 369 196 442 minecraft:red_concrete
fill 369 194 444 369 196 444 minecraft:red_concrete
fill 369 194 446 369 196 446 minecraft:red_concrete
fill 369 194 448 369 196 448 minecraft:red_concrete
fill 369 194 450 369 196 450 minecraft:red_concrete
fill 369 194 452 369 196 452 minecraft:red_concrete
fill 369 194 454 369 196 454 minecraft:red_concrete
setblock 370 194 423 minecraft:red_concrete
setblock 370 194 430 minecraft:red_concrete
setblock 370 194 437 minecraft:red_concrete
fill 370 194 443 370 196 443 minecraft:red_concrete
fill 370 194 445 370 196 445 minecraft:red_concrete
fill 370 194 447 370 196 447 minecraft:red_concrete
fill 370 194 449 370 226 449 minecraft:red_concrete
fill 370 194 451 370 196 451 minecraft:red_concrete
fill 370 194 453 370 196 453 minecraft:red_concrete
setblock 370 194 457 minecraft:red_concrete
fill 370 194 458 370 196 458 minecraft:purple_terracotta
fill 371 194 428 371 196 428 minecraft:purple_terracotta
setblock 371 194 429 minecraft:black_concrete
fill 371 194 430 371 194 433 minecraft:purple_terracotta
fill 371 194 441 371 196 441 minecraft:purple_terracotta
fill 371 194 442 371 194 443 minecraft:black_concrete
fill 371 194 444 371 196 444 minecraft:purple_terracotta
fill 371 194 457 371 197 457 minecraft:purple_terracotta
setblock 371 194 458 minecraft:black_concrete
setblock 329 195 416 minecraft:black_concrete
fill 329 195 418 329 196 418 minecraft:purple_terracotta
setblock 329 195 419 minecraft:black_concrete
fill 329 195 420 329 196 420 minecraft:purple_terracotta
setblock 329 195 430 minecraft:black_concrete
fill 329 195 431 329 196 433 minecraft:purple_terracotta
setblock 329 195 437 minecraft:black_concrete
fill 329 195 438 329 196 438 minecraft:purple_terracotta
setblock 329 195 439 minecraft:black_concrete
fill 329 195 440 329 196 440 minecraft:purple_terracotta
fill 329 195 445 329 196 446 minecraft:purple_terracotta
setblock 329 195 447 minecraft:black_concrete
fill 329 195 448 329 196 448 minecraft:purple_terracotta
fill 329 195 451 329 196 451 minecraft:purple_terracotta
fill 329 195 452 329 195 453 minecraft:black_concrete
fill 329 195 454 329 196 455 minecraft:purple_terracotta
fill 329 195 458 329 196 458 minecraft:purple_terracotta
setblock 330 195 421 minecraft:red_concrete
setblock 330 195 428 minecraft:red_concrete
setblock 330 195 435 minecraft:red_concrete
setblock 330 195 442 minecraft:red_concrete
setblock 330 195 449 minecraft:red_concrete
setblock 330 195 456 minecraft:red_concrete
setblock 330 195 458 minecraft:black_concrete
fill 331 195 458 331 196 458 minecraft:purple_terracotta
setblock 333 195 417 minecraft:red_concrete
fill 334 195 458 334 196 458 minecraft:purple_terracotta
setblock 335 195 458 minecraft:black_concrete
setblock 336 195 416 minecraft:black_concrete
setblock 336 195 457 minecraft:red_concrete
fill 337 195 416 338 196 416 minecraft:purple_terracotta
fill 340 195 416 340 196 416 minecraft:purple_terracotta
setblock 340 195 417 minecraft:red_concrete
fill 342 195 458 342 196 458 minecraft:purple_terracotta
setblock 343 195 457 minecraft:red_concrete
fill 346 195 416 346 196 416 minecraft:purple_terracotta
setblock 347 195 417 minecraft:red_concrete
fill 350 195 416 350 196 416 minecraft:purple_terracotta
setblock 350 195 457 minecraft:red_concrete
setblock 351 195 416 minecraft:black_concrete
fill 353 195 416 355 196 416 minecraft:purple_terracotta
setblock 354 195 417 minecraft:red_concrete
setblock 356 195 416 minecraft:black_concrete
fill 357 195 416 357 196 416 minecraft:purple_terracotta
setblock 357 195 457 minecraft:red_concrete
setblock 358 195 416 minecraft:black_concrete
fill 359 195 416 360 196 416 minecraft:purple_terracotta
setblock 361 195 417 minecraft:red_concrete
fill 362 195 458 362 196 458 minecraft:purple_terracotta
fill 363 195 416 363 196 416 minecraft:purple_terracotta
setblock 363 195 458 minecraft:black_concrete
fill 364 195 417 366 195 421 minecraft:white_concrete
setblock 364 195 457 minecraft:red_concrete
fill 367 195 418 368 195 421 minecraft:white_concrete
setblock 368 195 416 minecraft:black_concrete
setblock 368 195 417 minecraft:red_concrete
fill 368 195 458 368 196 458 minecraft:purple_terracotta
setblock 370 195 422 minecraft:red_concrete
setblock 370 195 429 minecraft:red_concrete
setblock 370 195 436 minecraft:red_concrete
fill 371 195 416 371 195 417 minecraft:black_concrete
fill 371 195 429 371 196 429 minecraft:purple_terracotta
setblock 371 195 430 minecraft:black_concrete
fill 371 195 431 371 196 433 minecraft:purple_terracotta
setblock 371 195 435 minecraft:black_concrete
fill 371 195 442 371 196 443 minecraft:purple_terracotta
fill 371 195 445 371 196 445 minecraft:purple_terracotta
setblock 371 195 446 minecraft:black_concrete
fill 371 195 447 371 196 449 minecraft:purple_terracotta
fill 371 195 458 371 196 458 minecraft:purple_terracotta
setblock 329 196 416 minecraft:purple_terracotta
setblock 329 196 419 minecraft:purple_terracotta
setblock 329 196 430 minecraft:purple_terracotta
setblock 329 196 437 minecraft:purple_terracotta
setblock 329 196 439 minecraft:purple_terracotta
setblock 329 196 447 minecraft:purple_terracotta
fill 329 196 452 329 196 453 minecraft:purple_terracotta
setblock 330 196 458 minecraft:purple_terracotta
setblock 335 196 458 minecraft:purple_terracotta
setblock 336 196 416 minecraft:purple_terracotta
setblock 348 196 458 minecraft:purple_terracotta
setblock 351 196 416 minecraft:purple_terracotta
setblock 356 196 416 minecraft:purple_terracotta
fill 356 196 458 356 197 458 minecraft:purple_terracotta
fill 358 196 416 358 198 416 minecraft:purple_terracotta
fill 363 196 458 364 196 458 minecraft:purple_terracotta
setblock 368 196 416 minecraft:purple_terracotta
fill 371 196 416 371 196 417 minecraft:purple_terracotta
setblock 371 196 430 minecraft:purple_terracotta
setblock 371 196 435 minecraft:purple_terracotta
setblock 371 196 446 minecraft:purple_terracotta
fill 329 197 416 329 197 420 minecraft:black_concrete
fill 329 197 422 329 198 427 minecraft:black_concrete
fill 329 197 429 329 307 431 minecraft:black_concrete
setblock 329 197 432 minecraft:purple_terracotta
fill 329 197 433 329 307 433 minecraft:black_concrete
setblock 329 197 434 minecraft:purple_terracotta
fill 329 197 435 329 197 454 minecraft:black_concrete
setblock 329 197 455 minecraft:purple_terracotta
fill 329 197 456 329 307 458 minecraft:black_concrete
fill 330 197 416 333 198 416 minecraft:black_concrete
setblock 330 197 423 minecraft:red_concrete
setblock 330 197 430 minecraft:red_concrete
setblock 330 197 437 minecraft:red_concrete
setblock 330 197 444 minecraft:red_concrete
setblock 330 197 451 minecraft:red_concrete
fill 330 197 458 352 197 458 minecraft:black_concrete
setblock 331 197 417 minecraft:red_concrete
setblock 331 197 457 minecraft:red_concrete
setblock 334 197 416 minecraft:purple_terracotta
fill 335 197 416 353 197 416 minecraft:black_concrete
setblock 338 197 417 minecraft:red_concrete
setblock 338 197 457 minecraft:red_concrete
setblock 345 197 417 minecraft:red_concrete
setblock 345 197 457 minecraft:red_concrete
setblock 352 197 417 minecraft:red_concrete
setblock 352 197 457 minecraft:red_concrete
setblock 354 197 416 minecraft:purple_terracotta
fill 355 197 416 357 307 416 minecraft:black_concrete
fill 355 197 458 355 307 458 minecraft:black_concrete
setblock 357 197 458 minecraft:black_concrete
fill 359 197 416 363 197 416 minecraft:black_concrete
setblock 359 197 417 minecraft:red_concrete
setblock 359 197 457 minecraft:red_concrete
fill 359 197 458 371 197 458 minecraft:black_concrete
fill 361 197 443 369 197 453 minecraft:white_concrete
setblock 364 197 416 minecraft:purple_terracotta
fill 365 197 416 371 197 416 minecraft:black_concrete
setblock 366 197 417 minecraft:red_concrete
setblock 366 197 457 minecraft:red_concrete
setblock 370 197 420 minecraft:red_concrete
setblock 370 197 427 minecraft:red_concrete
setblock 370 197 434 minecraft:red_concrete
setblock 370 197 441 minecraft:red_concrete
setblock 370 197 455 minecraft:red_concrete
fill 371 197 417 371 307 422 minecraft:black_concrete
setblock 371 197 423 minecraft:purple_terracotta
fill 371 197 424 371 197 430 minecraft:black_concrete
setblock 371 197 431 minecraft:purple_terracotta
fill 371 197 432 371 198 436 minecraft:black_concrete
setblock 371 197 437 minecraft:purple_terracotta
fill 371 197 438 371 198 442 minecraft:black_concrete
setblock 371 197 443 minecraft:purple_terracotta
fill 371 197 444 371 197 450 minecraft:black_concrete
setblock 371 197 451 minecraft:purple_terracotta
fill 371 197 452 371 197 456 minecraft:black_concrete
fill 329 198 416 329 307 416 minecraft:black_concrete
setblock 329 198 417 minecraft:purple_terracotta
fill 329 198 418 329 307 421 minecraft:black_concrete
setblock 329 198 428 minecraft:black_concrete
fill 329 198 432 329 307 432 minecraft:black_concrete
fill 329 198 434 329 198 450 minecraft:black_concrete
setblock 329 198 451 minecraft:purple_terracotta
fill 329 198 452 329 307 453 minecraft:black_concrete
setblock 329 198 454 minecraft:purple_terracotta
fill 329 198 455 329 307 455 minecraft:black_concrete
setblock 330 198 417 minecraft:red_concrete
setblock 330 198 424 minecraft:red_concrete
setblock 330 198 431 minecraft:red_concrete
setblock 330 198 438 minecraft:red_concrete
setblock 330 198 445 minecraft:red_concrete
setblock 330 198 452 minecraft:red_concrete
fill 330 198 458 334 307 458 minecraft:black_concrete
setblock 332 198 457 minecraft:red_concrete
fill 334 198 416 341 307 416 minecraft:black_concrete
setblock 335 198 458 minecraft:purple_terracotta
fill 336 198 458 339 198 458 minecraft:black_concrete
setblock 337 198 417 minecraft:red_concrete
setblock 339 198 457 minecraft:red_concrete
setblock 340 198 458 minecraft:purple_terracotta
fill 341 198 458 353 307 458 minecraft:black_concrete
setblock 342 198 416 minecraft:purple_terracotta
fill 343 198 416 343 307 416 minecraft:black_concrete
setblock 344 198 416 minecraft:purple_terracotta
setblock 344 198 417 minecraft:red_concrete
fill 345 198 416 349 198 416 minecraft:black_concrete
setblock 346 198 457 minecraft:red_concrete
setblock 350 198 416 minecraft:purple_terracotta
fill 351 198 416 354 307 416 minecraft:black_concrete
setblock 351 198 417 minecraft:red_concrete
setblock 353 198 457 minecraft:red_concrete
fill 354 198 458 354 199 458 minecraft:purple_terracotta
fill 356 198 458 356 307 458 minecraft:black_concrete
setblock 357 198 458 minecraft:purple_terracotta
setblock 358 198 417 minecraft:red_concrete
fill 358 198 458 360 307 458 minecraft:black_concrete
setblock 359 198 416 minecraft:purple_terracotta
fill 360 198 416 366 307 416 minecraft:black_concrete
setblock 360 198 457 minecraft:red_concrete
setblock 361 198 458 minecraft:purple_terracotta
fill 362 198 444 368 198 452 minecraft:white_concrete
fill 362 198 458 363 307 458 minecraft:black_concrete
setblock 364 198 458 minecraft:purple_terracotta
setblock 365 198 417 minecraft:red_concrete
fill 365 198 458 371 307 458 minecraft:black_concrete
setblock 367 198 416 minecraft:purple_terracotta
setblock 367 198 457 minecraft:red_concrete
fill 368 198 416 370 307 416 minecraft:black_concrete
setblock 370 198 419 minecraft:red_concrete
setblock 370 198 426 minecraft:red_concrete
setblock 370 198 433 minecraft:red_concrete
setblock 370 198 440 minecraft:red_concrete
setblock 370 198 447 minecraft:red_concrete
setblock 370 198 454 minecraft:red_concrete
setblock 371 198 416 minecraft:purple_terracotta
fill 371 198 423 371 307 424 minecraft:black_concrete
setblock 371 198 425 minecraft:purple_terracotta
fill 371 198 426 371 307 431 minecraft:black_concrete
fill 371 198 437 371 307 437 minecraft:black_concrete
fill 371 198 443 371 198 449 minecraft:black_concrete
setblock 371 198 450 minecraft:purple_terracotta
fill 371 198 451 371 307 455 minecraft:black_concrete
fill 371 198 456 371 199 456 minecraft:purple_terracotta
fill 371 198 457 371 307 457 minecraft:black_concrete
fill 329 199 417 329 307 417 minecraft:black_concrete
fill 329 199 422 329 307 422 minecraft:black_concrete
setblock 329 199 423 minecraft:purple_terracotta
fill 329 199 424 329 307 427 minecraft:black_concrete
setblock 329 199 428 minecraft:purple_terracotta
fill 329 199 434 329 307 439 minecraft:black_concrete
setblock 329 199 440 minecraft:purple_terracotta
fill 329 199 441 329 307 451 minecraft:black_concrete
fill 329 199 454 329 307 454 minecraft:black_concrete
fill 330 199 416 331 307 416 minecraft:black_concrete
fill 330 199 418 330 200 418 minecraft:red_concrete
fill 330 199 425 330 200 425 minecraft:red_concrete
fill 330 199 432 330 200 432 minecraft:red_concrete
fill 330 199 439 330 200 439 minecraft:red_concrete
fill 330 199 446 330 200 446 minecraft:red_concrete
fill 330 199 453 330 200 453 minecraft:red_concrete
setblock 332 199 416 minecraft:purple_terracotta
fill 333 199 416 333 307 416 minecraft:black_concrete
fill 333 199 457 333 200 457 minecraft:red_concrete
fill 335 199 458 337 307 458 minecraft:black_concrete
fill 336 199 417 336 200 417 minecraft:red_concrete
setblock 338 199 458 minecraft:purple_terracotta
fill 339 199 458 340 307 458 minecraft:black_concrete
fill 340 199 457 340 200 457 minecraft:red_concrete
fill 342 199 416 342 307 416 minecraft:black_concrete
fill 343 199 417 343 200 417 minecraft:red_concrete
fill 344 199 416 346 307 416 minecraft:black_concrete
setblock 347 199 416 minecraft:purple_terracotta
fill 347 199 457 347 200 457 minecraft:red_concrete
fill 348 199 416 350 307 416 minecraft:black_concrete
fill 350 199 417 350 200 417 minecraft:red_concrete
fill 351 199 427 351 200 427 minecraft:red_wool
fill 354 199 457 354 200 457 minecraft:red_concrete
fill 357 199 417 357 200 417 minecraft:red_concrete
fill 357 199 458 357 307 458 minecraft:black_concrete
fill 358 199 416 359 307 416 minecraft:black_concrete
fill 361 199 457 361 200 457 minecraft:red_concrete
fill 361 199 458 361 307 458 minecraft:black_concrete
fill 363 199 445 367 199 451 minecraft:white_concrete
fill 364 199 417 364 200 417 minecraft:red_concrete
fill 364 199 458 364 307 458 minecraft:black_concrete
fill 367 199 416 367 307 416 minecraft:black_concrete
fill 368 199 457 368 200 457 minecraft:red_concrete
fill 370 199 418 370 200 418 minecraft:red_concrete
fill 370 199 425 370 200 425 minecraft:red_concrete
fill 370 199 432 370 200 432 minecraft:red_concrete
fill 370 199 439 370 200 439 minecraft:red_concrete
fill 370 199 446 370 200 446 minecraft:red_concrete
fill 370 199 453 370 200 453 minecraft:red_concrete
fill 371 199 416 371 307 416 minecraft:black_concrete
fill 371 199 425 371 307 425 minecraft:black_concrete
fill 371 199 432 371 307 432 minecraft:black_concrete
setblock 371 199 433 minecraft:purple_terracotta
fill 371 199 434 371 307 436 minecraft:black_concrete
fill 371 199 438 371 307 441 minecraft:black_concrete
setblock 371 199 442 minecraft:purple_terracotta
fill 371 199 443 371 307 443 minecraft:black_concrete
setblock 371 199 444 minecraft:purple_terracotta
fill 371 199 445 371 307 450 minecraft:black_concrete
fill 329 200 423 329 307 423 minecraft:black_concrete
fill 329 200 428 329 307 428 minecraft:black_concrete
fill 329 200 440 329 307 440 minecraft:black_concrete
fill 330 200 417 331 200 417 minecraft:red_concrete
fill 330 200 419 330 200 421 minecraft:red_concrete
fill 330 200 423 330 200 424 minecraft:red_concrete
fill 330 200 426 330 200 428 minecraft:red_concrete
fill 330 200 430 330 200 431 minecraft:red_concrete
fill 330 200 433 330 200 435 minecraft:red_concrete
fill 330 200 437 330 200 438 minecraft:red_concrete
fill 330 200 440 330 200 442 minecraft:red_concrete
fill 330 200 444 330 200 445 minecraft:red_concrete
fill 330 200 447 330 200 449 minecraft:red_concrete
fill 330 200 451 330 200 452 minecraft:red_concrete
fill 330 200 454 330 200 456 minecraft:red_concrete
fill 331 200 457 332 200 457 minecraft:red_concrete
fill 332 200 416 332 307 416 minecraft:black_concrete
setblock 332 200 419 minecraft:light[level=12]
setblock 332 200 427 minecraft:light[level=12]
setblock 332 200 435 minecraft:light[level=12]
setblock 332 200 443 minecraft:light[level=12]
setblock 332 200 451 minecraft:light[level=12]
fill 333 200 417 335 200 417 minecraft:red_concrete
fill 334 200 457 336 200 457 minecraft:red_concrete
fill 337 200 417 338 200 417 minecraft:red_concrete
fill 338 200 457 339 200 457 minecraft:red_concrete
fill 338 200 458 338 307 458 minecraft:black_concrete
fill 340 200 417 342 200 417 minecraft:red_concrete
setblock 340 200 419 minecraft:light[level=12]
setblock 340 200 427 minecraft:light[level=12]
setblock 340 200 435 minecraft:light[level=12]
setblock 340 200 443 minecraft:light[level=12]
setblock 340 200 451 minecraft:light[level=12]
fill 341 200 457 343 200 457 minecraft:red_concrete
fill 344 200 417 345 200 417 minecraft:red_concrete
fill 345 200 457 346 200 457 minecraft:red_concrete
fill 347 200 416 347 307 416 minecraft:black_concrete
fill 347 200 417 349 200 417 minecraft:red_concrete
setblock 348 200 419 minecraft:light[level=12]
setblock 348 200 427 minecraft:light[level=12]
setblock 348 200 435 minecraft:light[level=12]
setblock 348 200 443 minecraft:light[level=12]
setblock 348 200 451 minecraft:light[level=12]
fill 348 200 457 350 200 457 minecraft:red_concrete
fill 351 200 417 352 200 417 minecraft:red_concrete
fill 352 200 457 353 200 457 minecraft:red_concrete
fill 354 200 417 356 200 417 minecraft:red_concrete
fill 354 200 458 354 307 458 minecraft:black_concrete
fill 355 200 457 357 200 457 minecraft:red_concrete
setblock 356 200 419 minecraft:light[level=12]
setblock 356 200 427 minecraft:light[level=12]
setblock 356 200 443 minecraft:light[level=12]
setblock 356 200 451 minecraft:light[level=12]
fill 358 200 417 359 200 417 minecraft:red_concrete
fill 359 200 457 360 200 457 minecraft:red_concrete
fill 361 200 417 363 200 417 minecraft:red_concrete
fill 362 200 457 364 200 457 minecraft:red_concrete
setblock 364 200 419 minecraft:light[level=12]
setblock 364 200 427 minecraft:light[level=12]
setblock 364 200 435 minecraft:light[level=12]
setblock 364 200 443 minecraft:light[level=12]
fill 364 200 446 366 200 450 minecraft:white_concrete
setblock 364 200 451 minecraft:light[level=12]
fill 365 200 417 366 200 417 minecraft:red_concrete
fill 366 200 457 367 200 457 minecraft:red_concrete
fill 368 200 417 370 200 417 minecraft:red_concrete
fill 369 200 457 370 200 457 minecraft:red_concrete
fill 370 200 419 370 200 420 minecraft:red_concrete
fill 370 200 422 370 200 424 minecraft:red_concrete
fill 370 200 426 370 200 427 minecraft:red_concrete
fill 370 200 429 370 200 431 minecraft:red_concrete
fill 370 200 433 370 200 434 minecraft:red_concrete
fill 370 200 436 370 200 438 minecraft:red_concrete
fill 370 200 440 370 200 441 minecraft:red_concrete
fill 370 200 443 370 200 445 minecraft:red_concrete
fill 370 200 447 370 200 448 minecraft:red_concrete
fill 370 200 450 370 200 452 minecraft:red_concrete
fill 370 200 454 370 200 455 minecraft:red_concrete
fill 371 200 433 371 307 433 minecraft:black_concrete
fill 371 200 442 371 307 442 minecraft:black_concrete
fill 371 200 444 371 307 444 minecraft:black_concrete
fill 371 200 456 371 307 456 minecraft:black_concrete
setblock 330 201 420 minecraft:red_concrete
setblock 330 201 427 minecraft:red_concrete
setblock 330 201 434 minecraft:red_concrete
setblock 330 201 441 minecraft:red_concrete
setblock 330 201 448 minecraft:red_concrete
setblock 330 201 455 minecraft:red_concrete
setblock 334 201 417 minecraft:red_concrete
setblock 335 201 457 minecraft:red_concrete
setblock 341 201 417 minecraft:red_concrete
setblock 342 201 457 minecraft:red_concrete
setblock 348 201 417 minecraft:red_concrete
setblock 349 201 457 minecraft:red_concrete
setblock 355 201 417 minecraft:red_concrete
setblock 356 201 457 minecraft:red_concrete
setblock 362 201 417 minecraft:red_concrete
setblock 363 201 457 minecraft:red_concrete
setblock 369 201 417 minecraft:red_concrete
setblock 370 201 423 minecraft:red_concrete
setblock 370 201 430 minecraft:red_concrete
setblock 370 201 437 minecraft:red_concrete
setblock 370 201 444 minecraft:red_concrete
setblock 370 201 451 minecraft:red_concrete
setblock 370 201 457 minecraft:red_concrete
setblock 330 202 421 minecraft:red_concrete
setblock 330 202 428 minecraft:red_concrete
setblock 330 202 435 minecraft:red_concrete
setblock 330 202 442 minecraft:red_concrete
setblock 330 202 449 minecraft:red_concrete
setblock 330 202 456 minecraft:red_concrete
schedule function dropper:buildpart/103_4 1t
