fill 294 166 458 297 171 458 minecraft:ochre_froglight
fill 301 166 416 304 171 416 minecraft:ochre_froglight
fill 306 166 458 309 171 458 minecraft:ochre_froglight
fill 313 166 416 316 171 416 minecraft:ochre_froglight
fill 318 166 458 321 171 458 minecraft:ochre_froglight
fill 324 166 417 324 171 420 minecraft:ochre_froglight
fill 324 166 429 324 171 432 minecraft:ochre_froglight
fill 324 166 441 324 171 444 minecraft:ochre_froglight
fill 324 166 453 324 171 456 minecraft:ochre_froglight
fill 289 167 442 289 181 442 minecraft:waxed_copper_block
setblock 312 169 419 minecraft:waxed_cut_copper
setblock 312 169 421 minecraft:waxed_cut_copper
setblock 314 169 419 minecraft:waxed_cut_copper
setblock 314 169 421 minecraft:waxed_cut_copper
fill 283 171 433 283 171 435 minecraft:waxed_cut_copper
fill 284 171 432 286 171 432 minecraft:waxed_cut_copper
fill 284 171 436 286 171 436 minecraft:waxed_cut_copper
fill 287 171 433 287 171 435 minecraft:waxed_cut_copper
fill 288 171 450 288 172 454 minecraft:waxed_copper_block
fill 289 171 449 289 172 450 minecraft:waxed_copper_block
fill 289 171 452 293 172 452 minecraft:waxed_cut_copper
fill 289 171 454 289 172 455 minecraft:waxed_copper_block
fill 290 171 449 293 172 449 minecraft:waxed_copper_block
fill 290 171 455 293 172 455 minecraft:waxed_copper_block
fill 291 171 450 291 172 451 minecraft:waxed_cut_copper
fill 291 171 453 291 172 454 minecraft:waxed_cut_copper
fill 293 171 450 294 172 450 minecraft:waxed_copper_block
fill 293 171 454 294 172 454 minecraft:waxed_copper_block
fill 294 171 451 294 172 453 minecraft:waxed_copper_block
fill 282 172 422 282 185 422 minecraft:spruce_planks
fill 282 172 423 282 172 424 minecraft:ochre_froglight
fill 282 172 425 282 185 425 minecraft:spruce_planks
fill 282 172 434 282 185 434 minecraft:spruce_planks
fill 282 172 435 282 172 436 minecraft:ochre_froglight
fill 282 172 437 282 185 437 minecraft:spruce_planks
fill 282 172 446 282 185 446 minecraft:spruce_planks
fill 282 172 447 282 172 448 minecraft:ochre_froglight
fill 282 172 449 282 185 449 minecraft:spruce_planks
fill 282 172 458 282 185 458 minecraft:spruce_planks
fill 283 172 458 284 172 458 minecraft:ochre_froglight
setblock 285 172 419 minecraft:light[level=14]
setblock 285 172 427 minecraft:light[level=14]
setblock 285 172 443 minecraft:light[level=14]
setblock 285 172 451 minecraft:light[level=14]
fill 285 172 458 285 185 458 minecraft:spruce_planks
fill 289 172 416 289 185 416 minecraft:spruce_planks
fill 290 172 416 291 172 416 minecraft:ochre_froglight
fill 292 172 416 292 185 416 minecraft:spruce_planks
setblock 293 172 419 minecraft:light[level=14]
setblock 293 172 427 minecraft:light[level=14]
setblock 293 172 435 minecraft:light[level=14]
setblock 293 172 443 minecraft:light[level=14]
setblock 293 172 451 minecraft:light[level=14]
fill 294 172 458 294 185 458 minecraft:spruce_planks
fill 295 172 458 296 172 458 minecraft:ochre_froglight
fill 297 172 458 297 185 458 minecraft:spruce_planks
fill 301 172 416 301 185 416 minecraft:spruce_planks
setblock 301 172 419 minecraft:light[level=14]
setblock 301 172 427 minecraft:light[level=14]
setblock 301 172 435 minecraft:light[level=14]
setblock 301 172 443 minecraft:light[level=14]
setblock 301 172 451 minecraft:light[level=14]
fill 302 172 416 303 172 416 minecraft:ochre_froglight
fill 304 172 416 304 185 416 minecraft:spruce_planks
fill 306 172 458 306 185 458 minecraft:spruce_planks
fill 307 172 458 308 172 458 minecraft:ochre_froglight
setblock 309 172 419 minecraft:light[level=14]
setblock 309 172 427 minecraft:light[level=14]
setblock 309 172 435 minecraft:light[level=14]
setblock 309 172 443 minecraft:light[level=14]
setblock 309 172 451 minecraft:light[level=14]
fill 309 172 458 309 185 458 minecraft:spruce_planks
fill 313 172 416 313 185 416 minecraft:spruce_planks
fill 314 172 416 315 172 416 minecraft:ochre_froglight
fill 316 172 416 316 185 416 minecraft:spruce_planks
setblock 317 172 419 minecraft:light[level=14]
setblock 317 172 427 minecraft:light[level=14]
setblock 317 172 435 minecraft:light[level=14]
setblock 317 172 443 minecraft:light[level=14]
setblock 317 172 451 minecraft:light[level=14]
fill 318 172 458 318 185 458 minecraft:spruce_planks
fill 319 172 458 320 172 458 minecraft:ochre_froglight
fill 321 172 458 321 185 458 minecraft:spruce_planks
fill 324 172 417 324 185 417 minecraft:spruce_planks
fill 324 172 418 324 172 419 minecraft:ochre_froglight
fill 324 172 420 324 185 420 minecraft:spruce_planks
fill 324 172 429 324 185 429 minecraft:spruce_planks
fill 324 172 430 324 172 431 minecraft:ochre_froglight
fill 324 172 432 324 185 432 minecraft:spruce_planks
fill 324 172 441 324 185 441 minecraft:spruce_planks
fill 324 172 442 324 172 443 minecraft:ochre_froglight
fill 324 172 444 324 185 444 minecraft:spruce_planks
fill 324 172 453 324 185 453 minecraft:spruce_planks
fill 324 172 454 324 172 455 minecraft:ochre_froglight
fill 324 172 456 324 185 456 minecraft:spruce_planks
fill 282 173 423 282 185 424 minecraft:spruce_planks
fill 282 173 435 282 185 436 minecraft:spruce_planks
fill 282 173 447 282 185 448 minecraft:spruce_planks
fill 283 173 458 284 185 458 minecraft:spruce_planks
fill 290 173 416 291 185 416 minecraft:spruce_planks
fill 295 173 458 296 185 458 minecraft:spruce_planks
fill 302 173 416 303 185 416 minecraft:spruce_planks
fill 307 173 458 308 185 458 minecraft:spruce_planks
fill 314 173 416 315 185 416 minecraft:spruce_planks
fill 319 173 458 320 185 458 minecraft:spruce_planks
fill 324 173 418 324 185 419 minecraft:spruce_planks
fill 324 173 430 324 185 431 minecraft:spruce_planks
fill 324 173 442 324 185 443 minecraft:spruce_planks
fill 324 173 454 324 185 455 minecraft:spruce_planks
setblock 312 174 419 minecraft:waxed_cut_copper
setblock 312 174 421 minecraft:waxed_cut_copper
setblock 314 174 419 minecraft:waxed_cut_copper
setblock 314 174 421 minecraft:waxed_cut_copper
fill 283 177 433 283 177 435 minecraft:waxed_cut_copper
fill 284 177 432 286 177 432 minecraft:waxed_cut_copper
fill 284 177 436 286 177 436 minecraft:waxed_cut_copper
fill 287 177 433 287 177 435 minecraft:waxed_cut_copper
setblock 312 179 419 minecraft:waxed_cut_copper
setblock 312 179 421 minecraft:waxed_cut_copper
setblock 314 179 419 minecraft:waxed_cut_copper
setblock 314 179 421 minecraft:waxed_cut_copper
fill 284 180 426 284 185 428 minecraft:waxed_cut_copper
fill 284 180 438 284 185 440 minecraft:waxed_cut_copper
fill 284 180 450 284 185 452 minecraft:waxed_cut_copper
setblock 285 180 419 minecraft:light[level=14]
setblock 285 180 427 minecraft:light[level=14]
setblock 285 180 443 minecraft:light[level=14]
setblock 285 180 451 minecraft:light[level=14]
fill 290 180 456 292 185 456 minecraft:waxed_cut_copper
setblock 293 180 419 minecraft:light[level=14]
setblock 293 180 427 minecraft:light[level=14]
setblock 293 180 435 minecraft:light[level=14]
setblock 293 180 443 minecraft:light[level=14]
setblock 293 180 451 minecraft:light[level=14]
fill 294 180 418 296 185 418 minecraft:waxed_cut_copper
setblock 301 180 419 minecraft:light[level=14]
setblock 301 180 427 minecraft:light[level=14]
setblock 301 180 435 minecraft:light[level=14]
setblock 301 180 443 minecraft:light[level=14]
setblock 301 180 451 minecraft:light[level=14]
fill 302 180 456 304 185 456 minecraft:waxed_cut_copper
fill 306 180 418 308 185 418 minecraft:waxed_cut_copper
setblock 309 180 419 minecraft:light[level=14]
setblock 309 180 427 minecraft:light[level=14]
setblock 309 180 435 minecraft:light[level=14]
setblock 309 180 443 minecraft:light[level=14]
setblock 309 180 451 minecraft:light[level=14]
fill 314 180 456 316 185 456 minecraft:waxed_cut_copper
setblock 317 180 419 minecraft:light[level=14]
setblock 317 180 427 minecraft:light[level=14]
setblock 317 180 435 minecraft:light[level=14]
setblock 317 180 443 minecraft:light[level=14]
setblock 317 180 451 minecraft:light[level=14]
fill 318 180 418 320 185 418 minecraft:waxed_cut_copper
fill 322 180 426 322 185 428 minecraft:waxed_cut_copper
fill 322 180 438 322 185 440 minecraft:waxed_cut_copper
fill 322 180 450 322 185 452 minecraft:waxed_cut_copper
fill 283 183 433 283 183 435 minecraft:waxed_cut_copper
fill 284 183 432 286 183 432 minecraft:waxed_cut_copper
fill 284 183 436 286 183 436 minecraft:waxed_cut_copper
fill 287 183 433 287 183 435 minecraft:waxed_cut_copper
setblock 312 184 419 minecraft:waxed_cut_copper
setblock 312 184 421 minecraft:waxed_cut_copper
setblock 314 184 419 minecraft:waxed_cut_copper
setblock 314 184 421 minecraft:waxed_cut_copper
fill 283 185 420 283 185 425 minecraft:dark_oak_planks
fill 283 185 432 283 185 437 minecraft:dark_oak_planks
fill 283 185 444 283 185 449 minecraft:dark_oak_planks
fill 283 185 456 283 185 457 minecraft:dark_oak_planks
fill 284 185 457 287 185 457 minecraft:dark_oak_planks
fill 287 185 417 292 185 417 minecraft:dark_oak_planks
fill 294 185 457 299 185 457 minecraft:dark_oak_planks
fill 299 185 417 304 185 417 minecraft:dark_oak_planks
fill 306 185 457 311 185 457 minecraft:dark_oak_planks
fill 311 185 417 316 185 417 minecraft:dark_oak_planks
fill 318 185 457 323 185 457 minecraft:dark_oak_planks
fill 323 185 417 323 185 422 minecraft:dark_oak_planks
fill 323 185 429 323 185 434 minecraft:dark_oak_planks
fill 323 185 441 323 185 446 minecraft:dark_oak_planks
fill 323 185 453 323 185 456 minecraft:dark_oak_planks
fill 282 186 422 282 191 425 minecraft:ochre_froglight
fill 282 186 434 282 191 437 minecraft:ochre_froglight
fill 282 186 446 282 191 449 minecraft:ochre_froglight
fill 282 186 458 285 191 458 minecraft:ochre_froglight
fill 289 186 416 292 191 416 minecraft:ochre_froglight
fill 294 186 458 297 191 458 minecraft:ochre_froglight
fill 301 186 416 304 191 416 minecraft:ochre_froglight
fill 306 186 458 309 191 458 minecraft:ochre_froglight
fill 313 186 416 316 191 416 minecraft:ochre_froglight
fill 318 186 458 321 191 458 minecraft:ochre_froglight
fill 324 186 417 324 191 420 minecraft:ochre_froglight
fill 324 186 429 324 191 432 minecraft:ochre_froglight
fill 324 186 441 324 191 444 minecraft:ochre_froglight
fill 324 186 453 324 191 456 minecraft:ochre_froglight
fill 283 188 423 285 189 423 minecraft:waxed_copper_block
setblock 285 188 419 minecraft:light[level=14]
setblock 285 188 427 minecraft:light[level=14]
setblock 285 188 443 minecraft:light[level=14]
setblock 285 188 451 minecraft:light[level=14]
setblock 293 188 419 minecraft:light[level=14]
setblock 293 188 427 minecraft:light[level=14]
setblock 293 188 435 minecraft:light[level=14]
setblock 293 188 443 minecraft:light[level=14]
setblock 293 188 451 minecraft:light[level=14]
setblock 301 188 419 minecraft:light[level=14]
setblock 301 188 427 minecraft:light[level=14]
setblock 301 188 435 minecraft:light[level=14]
setblock 301 188 443 minecraft:light[level=14]
setblock 301 188 451 minecraft:light[level=14]
setblock 309 188 419 minecraft:light[level=14]
setblock 309 188 427 minecraft:light[level=14]
setblock 309 188 435 minecraft:light[level=14]
setblock 309 188 443 minecraft:light[level=14]
setblock 309 188 451 minecraft:light[level=14]
setblock 317 188 419 minecraft:light[level=14]
setblock 317 188 427 minecraft:light[level=14]
setblock 317 188 435 minecraft:light[level=14]
setblock 317 188 443 minecraft:light[level=14]
setblock 317 188 451 minecraft:light[level=14]
fill 283 189 433 283 189 435 minecraft:waxed_cut_copper
fill 284 189 432 286 189 432 minecraft:waxed_cut_copper
fill 284 189 436 286 189 436 minecraft:waxed_cut_copper
fill 287 189 433 287 189 435 minecraft:waxed_cut_copper
setblock 312 189 419 minecraft:waxed_cut_copper
setblock 312 189 421 minecraft:waxed_cut_copper
setblock 314 189 419 minecraft:waxed_cut_copper
setblock 314 189 421 minecraft:waxed_cut_copper
fill 282 192 422 282 194 422 minecraft:spruce_planks
fill 282 192 423 282 192 424 minecraft:ochre_froglight
fill 282 192 425 282 197 425 minecraft:spruce_planks
fill 282 192 434 282 195 434 minecraft:spruce_planks
fill 282 192 435 282 192 436 minecraft:ochre_froglight
fill 282 192 437 282 197 437 minecraft:spruce_planks
fill 282 192 446 282 197 446 minecraft:spruce_planks
fill 282 192 447 282 192 448 minecraft:ochre_froglight
fill 282 192 449 282 194 449 minecraft:spruce_planks
fill 282 192 458 282 195 458 minecraft:spruce_planks
fill 283 192 458 284 192 458 minecraft:ochre_froglight
fill 285 192 458 285 197 458 minecraft:spruce_planks
fill 289 192 416 289 195 416 minecraft:spruce_planks
fill 290 192 416 291 192 416 minecraft:ochre_froglight
fill 292 192 416 292 193 416 minecraft:spruce_planks
fill 294 192 458 294 197 458 minecraft:spruce_planks
fill 295 192 458 296 192 458 minecraft:ochre_froglight
fill 297 192 458 297 197 458 minecraft:spruce_planks
fill 301 192 416 301 197 416 minecraft:spruce_planks
fill 302 192 416 303 192 416 minecraft:ochre_froglight
fill 304 192 416 304 195 416 minecraft:spruce_planks
fill 306 192 458 306 197 458 minecraft:spruce_planks
fill 307 192 458 308 192 458 minecraft:ochre_froglight
fill 309 192 458 309 195 458 minecraft:spruce_planks
fill 313 192 416 313 197 416 minecraft:spruce_planks
fill 314 192 416 315 192 416 minecraft:ochre_froglight
fill 316 192 416 316 197 416 minecraft:spruce_planks
fill 318 192 458 318 197 458 minecraft:spruce_planks
fill 319 192 458 320 192 458 minecraft:ochre_froglight
fill 321 192 458 321 197 458 minecraft:spruce_planks
fill 324 192 417 324 197 417 minecraft:spruce_planks
fill 324 192 418 324 192 419 minecraft:ochre_froglight
fill 324 192 420 324 197 420 minecraft:spruce_planks
fill 324 192 429 324 197 429 minecraft:spruce_planks
fill 324 192 430 324 192 431 minecraft:ochre_froglight
fill 324 192 432 324 197 432 minecraft:spruce_planks
fill 324 192 441 324 197 441 minecraft:spruce_planks
fill 324 192 442 324 192 443 minecraft:ochre_froglight
fill 324 192 444 324 198 444 minecraft:spruce_planks
fill 324 192 453 324 197 453 minecraft:spruce_planks
fill 324 192 454 324 192 455 minecraft:ochre_froglight
fill 324 192 456 324 197 456 minecraft:spruce_planks
fill 282 193 423 282 193 424 minecraft:spruce_planks
fill 282 193 435 282 195 436 minecraft:spruce_planks
fill 282 193 447 282 195 448 minecraft:spruce_planks
fill 283 193 458 284 197 458 minecraft:spruce_planks
fill 290 193 416 291 195 416 minecraft:spruce_planks
fill 295 193 458 296 193 458 minecraft:spruce_planks
fill 302 193 416 303 193 416 minecraft:spruce_planks
fill 307 193 458 308 197 458 minecraft:spruce_planks
fill 314 193 416 315 197 416 minecraft:spruce_planks
fill 319 193 458 320 197 458 minecraft:spruce_planks
fill 324 193 418 324 197 419 minecraft:spruce_planks
fill 324 193 430 324 197 431 minecraft:spruce_planks
fill 324 193 442 324 195 443 minecraft:spruce_planks
fill 324 193 454 324 197 455 minecraft:spruce_planks
fill 282 194 423 282 195 423 minecraft:dark_oak_planks
fill 282 194 424 282 197 424 minecraft:spruce_planks
setblock 282 194 444 minecraft:dark_oak_planks
setblock 282 194 452 minecraft:dark_oak_planks
fill 282 194 453 282 197 453 minecraft:spruce_planks
setblock 283 194 416 minecraft:spruce_planks
setblock 284 194 416 minecraft:dark_oak_planks
fill 289 194 458 291 194 458 minecraft:spruce_planks
setblock 292 194 416 minecraft:dark_oak_planks
setblock 292 194 458 minecraft:dark_oak_planks
setblock 295 194 458 minecraft:spruce_planks
setblock 296 194 458 minecraft:dark_oak_planks
setblock 299 194 458 minecraft:dark_oak_planks
fill 300 194 458 300 197 458 minecraft:spruce_planks
setblock 302 194 416 minecraft:dark_oak_planks
fill 303 194 416 303 197 416 minecraft:spruce_planks
setblock 307 194 416 minecraft:dark_oak_planks
setblock 308 194 416 minecraft:spruce_planks
setblock 312 194 419 minecraft:waxed_cut_copper
setblock 312 194 421 minecraft:waxed_cut_copper
setblock 314 194 419 minecraft:waxed_cut_copper
setblock 314 194 421 minecraft:waxed_cut_copper
setblock 321 194 416 minecraft:dark_oak_planks
fill 322 194 458 323 195 458 minecraft:spruce_planks
setblock 324 194 458 minecraft:dark_oak_planks
setblock 282 195 417 minecraft:dark_oak_planks
fill 282 195 419 282 197 419 minecraft:spruce_planks
fill 282 195 420 282 195 422 minecraft:dark_oak_planks
fill 282 195 444 282 197 444 minecraft:spruce_planks
setblock 282 195 449 minecraft:dark_oak_planks
fill 282 195 452 282 197 452 minecraft:spruce_planks
setblock 283 195 416 minecraft:dark_oak_planks
fill 283 195 433 283 195 435 minecraft:waxed_cut_copper
fill 284 195 416 284 197 416 minecraft:spruce_planks
fill 284 195 432 286 195 432 minecraft:waxed_cut_copper
fill 284 195 436 286 195 436 minecraft:waxed_cut_copper
fill 287 195 433 287 195 435 minecraft:waxed_cut_copper
fill 289 195 458 290 197 458 minecraft:spruce_planks
setblock 291 195 458 minecraft:dark_oak_planks
fill 292 195 416 294 197 416 minecraft:spruce_planks
fill 292 195 458 292 197 458 minecraft:spruce_planks
setblock 295 195 416 minecraft:dark_oak_planks
setblock 295 195 458 minecraft:dark_oak_planks
fill 296 195 458 296 197 458 minecraft:spruce_planks
fill 299 195 458 299 197 458 minecraft:spruce_planks
fill 302 195 416 302 197 416 minecraft:spruce_planks
fill 307 195 416 307 197 416 minecraft:spruce_planks
setblock 308 195 416 minecraft:dark_oak_planks
setblock 320 195 416 minecraft:dark_oak_planks
fill 321 195 416 321 197 416 minecraft:spruce_planks
setblock 324 195 439 minecraft:dark_oak_planks
setblock 324 195 452 minecraft:dark_oak_planks
setblock 324 195 458 minecraft:spruce_planks
fill 282 196 417 282 197 417 minecraft:spruce_planks
fill 282 196 420 282 197 423 minecraft:spruce_planks
fill 282 196 426 282 197 431 minecraft:spruce_planks
setblock 282 196 432 minecraft:dark_oak_planks
fill 282 196 433 282 197 433 minecraft:spruce_planks
setblock 282 196 434 minecraft:dark_oak_planks
fill 282 196 435 282 197 435 minecraft:spruce_planks
setblock 282 196 436 minecraft:dark_oak_planks
fill 282 196 438 282 197 439 minecraft:spruce_planks
setblock 282 196 440 minecraft:dark_oak_planks
setblock 282 196 445 minecraft:dark_oak_planks
fill 282 196 447 282 196 448 minecraft:dark_oak_planks
fill 282 196 449 282 197 449 minecraft:spruce_planks
setblock 282 196 458 minecraft:dark_oak_planks
fill 283 196 416 283 197 416 minecraft:spruce_planks
setblock 285 196 419 minecraft:light[level=14]
setblock 285 196 427 minecraft:light[level=14]
setblock 285 196 443 minecraft:light[level=14]
setblock 285 196 451 minecraft:light[level=14]
setblock 289 196 416 minecraft:dark_oak_planks
fill 290 196 416 290 198 416 minecraft:spruce_planks
setblock 291 196 416 minecraft:dark_oak_planks
fill 291 196 458 291 197 458 minecraft:spruce_planks
setblock 293 196 419 minecraft:light[level=14]
setblock 293 196 427 minecraft:light[level=14]
setblock 293 196 435 minecraft:light[level=14]
setblock 293 196 443 minecraft:light[level=14]
setblock 293 196 451 minecraft:light[level=14]
fill 295 196 416 295 198 416 minecraft:spruce_planks
fill 295 196 458 295 197 458 minecraft:spruce_planks
setblock 298 196 416 minecraft:dark_oak_planks
fill 299 196 416 299 197 416 minecraft:spruce_planks
setblock 301 196 419 minecraft:light[level=14]
setblock 301 196 427 minecraft:light[level=14]
setblock 301 196 435 minecraft:light[level=14]
setblock 301 196 443 minecraft:light[level=14]
setblock 301 196 451 minecraft:light[level=14]
setblock 304 196 416 minecraft:dark_oak_planks
fill 308 196 416 311 197 416 minecraft:spruce_planks
setblock 309 196 419 minecraft:light[level=14]
setblock 309 196 427 minecraft:light[level=14]
setblock 309 196 435 minecraft:light[level=14]
setblock 309 196 443 minecraft:light[level=14]
setblock 309 196 451 minecraft:light[level=14]
setblock 309 196 458 minecraft:dark_oak_planks
setblock 312 196 416 minecraft:dark_oak_planks
setblock 317 196 419 minecraft:light[level=14]
setblock 317 196 427 minecraft:light[level=14]
setblock 317 196 435 minecraft:light[level=14]
setblock 317 196 443 minecraft:light[level=14]
setblock 317 196 451 minecraft:light[level=14]
fill 320 196 416 320 197 416 minecraft:spruce_planks
setblock 322 196 458 minecraft:dark_oak_planks
fill 323 196 458 323 197 458 minecraft:spruce_planks
fill 324 196 439 324 197 439 minecraft:spruce_planks
fill 324 196 442 324 197 442 minecraft:spruce_planks
setblock 324 196 443 minecraft:dark_oak_planks
fill 324 196 445 324 197 449 minecraft:spruce_planks
setblock 324 196 450 minecraft:dark_oak_planks
fill 324 196 452 324 197 452 minecraft:spruce_planks
setblock 324 196 458 minecraft:dark_oak_planks
setblock 282 197 432 minecraft:spruce_planks
setblock 282 197 434 minecraft:spruce_planks
setblock 282 197 436 minecraft:spruce_planks
setblock 282 197 440 minecraft:spruce_planks
setblock 282 197 445 minecraft:spruce_planks
fill 282 197 447 282 197 448 minecraft:spruce_planks
setblock 282 197 458 minecraft:spruce_planks
setblock 289 197 416 minecraft:spruce_planks
fill 291 197 416 291 198 416 minecraft:spruce_planks
setblock 298 197 416 minecraft:spruce_planks
setblock 304 197 416 minecraft:spruce_planks
fill 309 197 458 309 198 458 minecraft:spruce_planks
setblock 312 197 416 minecraft:spruce_planks
setblock 322 197 458 minecraft:spruce_planks
setblock 324 197 443 minecraft:spruce_planks
setblock 324 197 450 minecraft:spruce_planks
setblock 324 197 458 minecraft:spruce_planks
fill 282 198 416 282 198 430 minecraft:dark_oak_planks
fill 282 198 431 282 199 431 minecraft:spruce_planks
fill 282 198 432 282 199 438 minecraft:dark_oak_planks
setblock 282 198 439 minecraft:spruce_planks
fill 282 198 440 282 205 450 minecraft:dark_oak_planks
setblock 282 198 451 minecraft:spruce_planks
fill 282 198 452 282 198 458 minecraft:dark_oak_planks
fill 283 198 416 289 199 416 minecraft:dark_oak_planks
setblock 283 198 458 minecraft:spruce_planks
fill 284 198 458 287 198 458 minecraft:dark_oak_planks
setblock 289 198 458 minecraft:spruce_planks
fill 290 198 458 292 198 458 minecraft:dark_oak_planks
fill 292 198 416 294 198 416 minecraft:dark_oak_planks
fill 294 198 458 300 198 458 minecraft:dark_oak_planks
fill 297 198 416 309 198 416 minecraft:dark_oak_planks
setblock 301 198 458 minecraft:spruce_planks
fill 302 198 458 306 198 458 minecraft:dark_oak_planks
setblock 307 198 458 minecraft:spruce_planks
setblock 308 198 458 minecraft:dark_oak_planks
setblock 310 198 416 minecraft:spruce_planks
fill 311 198 416 324 198 416 minecraft:dark_oak_planks
fill 311 198 458 314 198 458 minecraft:dark_oak_planks
fill 316 198 458 324 198 458 minecraft:dark_oak_planks
fill 324 198 417 324 199 426 minecraft:dark_oak_planks
setblock 324 198 427 minecraft:spruce_planks
fill 324 198 428 324 198 439 minecraft:dark_oak_planks
fill 324 198 441 324 198 443 minecraft:dark_oak_planks
fill 324 198 445 324 198 446 minecraft:dark_oak_planks
setblock 324 198 447 minecraft:spruce_planks
fill 324 198 448 324 198 457 minecraft:dark_oak_planks
fill 282 199 416 282 199 429 minecraft:dark_oak_planks
setblock 282 199 430 minecraft:spruce_planks
fill 282 199 439 282 307 439 minecraft:dark_oak_planks
fill 282 199 451 282 307 453 minecraft:dark_oak_planks
setblock 282 199 454 minecraft:spruce_planks
fill 282 199 455 282 307 455 minecraft:dark_oak_planks
setblock 282 199 456 minecraft:spruce_planks
fill 282 199 457 282 199 458 minecraft:dark_oak_planks
fill 283 199 458 283 205 458 minecraft:dark_oak_planks
setblock 284 199 458 minecraft:spruce_planks
fill 285 199 458 289 199 458 minecraft:dark_oak_planks
fill 290 199 416 292 205 416 minecraft:dark_oak_planks
setblock 290 199 458 minecraft:spruce_planks
fill 291 199 458 296 205 458 minecraft:dark_oak_planks
fill 293 199 416 294 199 416 minecraft:spruce_planks
fill 295 199 416 302 199 416 minecraft:dark_oak_planks
fill 297 199 458 298 199 458 minecraft:spruce_planks
fill 299 199 458 299 307 458 minecraft:dark_oak_planks
setblock 300 199 458 minecraft:spruce_planks
fill 301 199 458 303 199 458 minecraft:dark_oak_planks
setblock 303 199 416 minecraft:spruce_planks
fill 304 199 416 306 199 416 minecraft:dark_oak_planks
setblock 304 199 458 minecraft:spruce_planks
fill 305 199 458 307 199 458 minecraft:dark_oak_planks
fill 307 199 416 308 199 416 minecraft:spruce_planks
setblock 308 199 458 minecraft:spruce_planks
fill 309 199 416 318 199 416 minecraft:dark_oak_planks
fill 309 199 458 313 205 458 minecraft:dark_oak_planks
setblock 312 199 419 minecraft:waxed_cut_copper
setblock 312 199 421 minecraft:waxed_cut_copper
setblock 314 199 419 minecraft:waxed_cut_copper
setblock 314 199 421 minecraft:waxed_cut_copper
setblock 314 199 458 minecraft:spruce_planks
fill 315 199 458 316 307 458 minecraft:dark_oak_planks
setblock 317 199 458 minecraft:spruce_planks
fill 318 199 458 324 199 458 minecraft:dark_oak_planks
setblock 319 199 416 minecraft:spruce_planks
fill 320 199 416 324 307 416 minecraft:dark_oak_planks
fill 324 199 427 324 205 431 minecraft:dark_oak_planks
fill 324 199 432 324 200 432 minecraft:spruce_planks
fill 324 199 433 324 199 438 minecraft:dark_oak_planks
setblock 324 199 439 minecraft:spruce_planks
fill 324 199 440 324 307 440 minecraft:dark_oak_planks
setblock 324 199 441 minecraft:spruce_planks
fill 324 199 442 324 205 442 minecraft:dark_oak_planks
setblock 324 199 443 minecraft:spruce_planks
fill 324 199 444 324 205 444 minecraft:dark_oak_planks
setblock 324 199 445 minecraft:spruce_planks
fill 324 199 446 324 307 447 minecraft:dark_oak_planks
setblock 324 199 448 minecraft:spruce_planks
fill 324 199 449 324 199 457 minecraft:dark_oak_planks
fill 282 200 416 282 307 419 minecraft:dark_oak_planks
setblock 282 200 420 minecraft:spruce_planks
fill 282 200 421 282 205 423 minecraft:dark_oak_planks
setblock 282 200 424 minecraft:spruce_planks
fill 282 200 425 282 205 432 minecraft:dark_oak_planks
setblock 282 200 433 minecraft:spruce_planks
fill 282 200 434 282 205 435 minecraft:dark_oak_planks
setblock 282 200 436 minecraft:spruce_planks
fill 282 200 437 282 205 438 minecraft:dark_oak_planks
fill 282 200 454 282 307 454 minecraft:dark_oak_planks
fill 282 200 456 282 307 457 minecraft:dark_oak_planks
setblock 282 200 458 minecraft:spruce_planks
fill 283 200 416 286 307 416 minecraft:dark_oak_planks
fill 284 200 426 284 205 428 minecraft:waxed_cut_copper
fill 284 200 438 284 205 440 minecraft:waxed_cut_copper
fill 284 200 450 284 205 452 minecraft:waxed_cut_copper
fill 284 200 458 284 205 458 minecraft:dark_oak_planks
setblock 285 200 458 minecraft:spruce_planks
fill 286 200 458 290 307 458 minecraft:dark_oak_planks
setblock 287 200 416 minecraft:spruce_planks
fill 288 200 416 289 205 416 minecraft:dark_oak_planks
fill 290 200 456 292 205 456 minecraft:waxed_cut_copper
fill 293 200 416 295 307 416 minecraft:dark_oak_planks
fill 294 200 418 296 205 418 minecraft:waxed_cut_copper
setblock 296 200 416 minecraft:spruce_planks
fill 297 200 416 297 307 416 minecraft:dark_oak_planks
fill 297 200 458 298 205 458 minecraft:dark_oak_planks
fill 298 200 416 299 200 416 minecraft:spruce_planks
fill 300 200 416 303 205 416 minecraft:dark_oak_planks
fill 300 200 458 302 307 458 minecraft:dark_oak_planks
fill 302 200 456 304 205 456 minecraft:waxed_cut_copper
setblock 303 200 458 minecraft:spruce_planks
setblock 304 200 416 minecraft:spruce_planks
fill 304 200 458 304 307 458 minecraft:dark_oak_planks
fill 305 200 416 309 307 416 minecraft:dark_oak_planks
setblock 305 200 458 minecraft:spruce_planks
fill 306 200 418 308 205 418 minecraft:waxed_cut_copper
fill 306 200 458 308 205 458 minecraft:dark_oak_planks
setblock 310 200 416 minecraft:spruce_planks
fill 311 200 416 316 205 416 minecraft:dark_oak_planks
fill 314 200 456 316 205 456 minecraft:waxed_cut_copper
fill 314 200 458 314 307 458 minecraft:dark_oak_planks
setblock 317 200 416 minecraft:spruce_planks
fill 317 200 458 317 307 458 minecraft:dark_oak_planks
fill 318 200 416 319 307 416 minecraft:dark_oak_planks
fill 318 200 418 320 205 418 minecraft:waxed_cut_copper
setblock 318 200 458 minecraft:spruce_planks
fill 319 200 458 324 205 458 minecraft:dark_oak_planks
fill 322 200 426 322 205 428 minecraft:waxed_cut_copper
fill 322 200 438 322 205 440 minecraft:waxed_cut_copper
fill 322 200 450 322 205 452 minecraft:waxed_cut_copper
fill 324 200 417 324 205 422 minecraft:dark_oak_planks
setblock 324 200 423 minecraft:spruce_planks
fill 324 200 424 324 307 426 minecraft:dark_oak_planks
fill 324 200 433 324 307 433 minecraft:dark_oak_planks
setblock 324 200 434 minecraft:spruce_planks
fill 324 200 435 324 307 439 minecraft:dark_oak_planks
fill 324 200 441 324 205 441 minecraft:dark_oak_planks
fill 324 200 443 324 205 443 minecraft:dark_oak_planks
fill 324 200 445 324 307 445 minecraft:dark_oak_planks
fill 324 200 448 324 307 451 minecraft:dark_oak_planks
setblock 324 200 452 minecraft:spruce_planks
fill 324 200 453 324 205 455 minecraft:dark_oak_planks
setblock 324 200 456 minecraft:spruce_planks
fill 324 200 457 324 307 457 minecraft:dark_oak_planks
fill 282 201 420 282 307 420 minecraft:dark_oak_planks
fill 282 201 424 282 205 424 minecraft:dark_oak_planks
fill 282 201 433 282 307 433 minecraft:dark_oak_planks
fill 282 201 436 282 205 436 minecraft:dark_oak_planks
fill 282 201 458 282 205 458 minecraft:dark_oak_planks
fill 283 201 433 283 201 435 minecraft:waxed_cut_copper
fill 284 201 432 286 201 432 minecraft:waxed_cut_copper
fill 284 201 436 286 201 436 minecraft:waxed_cut_copper
fill 285 201 458 285 205 458 minecraft:dark_oak_planks
fill 287 201 416 287 307 416 minecraft:dark_oak_planks
fill 287 201 433 287 201 435 minecraft:waxed_cut_copper
fill 296 201 416 296 307 416 minecraft:dark_oak_planks
fill 298 201 416 299 307 416 minecraft:dark_oak_planks
fill 303 201 458 303 307 458 minecraft:dark_oak_planks
fill 304 201 416 304 205 416 minecraft:dark_oak_planks
fill 305 201 458 305 307 458 minecraft:dark_oak_planks
fill 310 201 416 310 307 416 minecraft:dark_oak_planks
fill 317 201 416 317 307 416 minecraft:dark_oak_planks
fill 318 201 458 318 205 458 minecraft:dark_oak_planks
fill 324 201 423 324 307 423 minecraft:dark_oak_planks
fill 324 201 432 324 205 432 minecraft:dark_oak_planks
fill 324 201 434 324 307 434 minecraft:dark_oak_planks
fill 324 201 452 324 307 452 minecraft:dark_oak_planks
fill 324 201 456 324 205 456 minecraft:dark_oak_planks
setblock 285 204 419 minecraft:light[level=14]
setblock 285 204 427 minecraft:light[level=14]
setblock 285 204 443 minecraft:light[level=14]
setblock 285 204 451 minecraft:light[level=14]
setblock 293 204 419 minecraft:light[level=14]
setblock 293 204 427 minecraft:light[level=14]
setblock 293 204 435 minecraft:light[level=14]
setblock 293 204 443 minecraft:light[level=14]
setblock 293 204 451 minecraft:light[level=14]
setblock 301 204 419 minecraft:light[level=14]
setblock 301 204 427 minecraft:light[level=14]
setblock 301 204 435 minecraft:light[level=14]
setblock 301 204 443 minecraft:light[level=14]
setblock 301 204 451 minecraft:light[level=14]
setblock 309 204 419 minecraft:light[level=14]
setblock 309 204 427 minecraft:light[level=14]
setblock 309 204 435 minecraft:light[level=14]
setblock 309 204 443 minecraft:light[level=14]
setblock 309 204 451 minecraft:light[level=14]
setblock 312 204 419 minecraft:waxed_cut_copper
setblock 312 204 421 minecraft:waxed_cut_copper
setblock 314 204 419 minecraft:waxed_cut_copper
setblock 314 204 421 minecraft:waxed_cut_copper
setblock 317 204 419 minecraft:light[level=14]
setblock 317 204 427 minecraft:light[level=14]
setblock 317 204 435 minecraft:light[level=14]
setblock 317 204 443 minecraft:light[level=14]
setblock 317 204 451 minecraft:light[level=14]
fill 283 205 420 283 205 425 minecraft:dark_oak_planks
fill 283 205 432 283 205 437 minecraft:dark_oak_planks
fill 283 205 444 283 205 449 minecraft:dark_oak_planks
fill 283 205 456 283 205 457 minecraft:dark_oak_planks
fill 284 205 457 287 205 457 minecraft:dark_oak_planks
fill 287 205 417 292 205 417 minecraft:dark_oak_planks
fill 294 205 457 299 205 457 minecraft:dark_oak_planks
fill 299 205 417 304 205 417 minecraft:dark_oak_planks
fill 306 205 457 311 205 457 minecraft:dark_oak_planks
fill 311 205 417 316 205 417 minecraft:dark_oak_planks
fill 318 205 457 323 205 457 minecraft:dark_oak_planks
fill 323 205 417 323 205 422 minecraft:dark_oak_planks
fill 323 205 429 323 205 434 minecraft:dark_oak_planks
fill 323 205 441 323 205 446 minecraft:dark_oak_planks
fill 323 205 453 323 205 456 minecraft:dark_oak_planks
fill 282 206 421 282 307 421 minecraft:dark_oak_planks
fill 282 206 422 282 211 425 minecraft:ochre_froglight
fill 282 206 426 282 307 432 minecraft:dark_oak_planks
fill 282 206 434 282 211 437 minecraft:ochre_froglight
fill 282 206 438 282 307 438 minecraft:dark_oak_planks
fill 282 206 440 282 307 445 minecraft:dark_oak_planks
fill 282 206 446 282 211 449 minecraft:ochre_froglight
fill 282 206 450 282 307 450 minecraft:dark_oak_planks
fill 282 206 458 285 211 458 minecraft:ochre_froglight
fill 288 206 416 288 307 416 minecraft:dark_oak_planks
fill 289 206 416 292 211 416 minecraft:ochre_froglight
fill 291 206 458 293 307 458 minecraft:dark_oak_planks
fill 294 206 458 297 211 458 minecraft:ochre_froglight
fill 298 206 458 298 307 458 minecraft:dark_oak_planks
fill 300 206 416 300 307 416 minecraft:dark_oak_planks
fill 301 206 416 304 211 416 minecraft:ochre_froglight
fill 306 206 458 309 211 458 minecraft:ochre_froglight
fill 310 206 458 313 307 458 minecraft:dark_oak_planks
fill 311 206 416 312 307 416 minecraft:dark_oak_planks
fill 313 206 416 316 211 416 minecraft:ochre_froglight
fill 318 206 458 321 211 458 minecraft:ochre_froglight
fill 322 206 458 324 307 458 minecraft:dark_oak_planks
fill 324 206 417 324 211 420 minecraft:ochre_froglight
fill 324 206 421 324 307 422 minecraft:dark_oak_planks
fill 324 206 427 324 307 428 minecraft:dark_oak_planks
fill 324 206 429 324 211 432 minecraft:ochre_froglight
fill 324 206 441 324 211 444 minecraft:ochre_froglight
fill 324 206 453 324 211 456 minecraft:ochre_froglight
fill 283 207 433 283 207 435 minecraft:waxed_cut_copper
fill 284 207 432 286 207 432 minecraft:waxed_cut_copper
fill 284 207 436 286 207 436 minecraft:waxed_cut_copper
fill 287 207 433 287 207 435 minecraft:waxed_cut_copper
setblock 312 209 419 minecraft:waxed_cut_copper
setblock 312 209 421 minecraft:waxed_cut_copper
setblock 314 209 419 minecraft:waxed_cut_copper
setblock 314 209 421 minecraft:waxed_cut_copper
fill 283 210 424 285 211 424 minecraft:waxed_copper_block
fill 299 210 422 299 217 422 minecraft:waxed_copper_block
fill 283 211 433 283 212 435 minecraft:waxed_copper_block
fill 282 212 422 282 228 422 minecraft:dark_oak_planks
fill 282 212 423 282 212 424 minecraft:ochre_froglight
fill 282 212 425 282 228 425 minecraft:dark_oak_planks
fill 282 212 434 282 228 434 minecraft:dark_oak_planks
fill 282 212 435 282 212 436 minecraft:ochre_froglight
fill 282 212 437 282 228 437 minecraft:dark_oak_planks
fill 282 212 446 282 228 446 minecraft:dark_oak_planks
fill 282 212 447 282 212 448 minecraft:ochre_froglight
fill 282 212 449 282 228 449 minecraft:dark_oak_planks
fill 282 212 458 282 228 458 minecraft:dark_oak_planks
fill 283 212 458 284 212 458 minecraft:ochre_froglight
setblock 285 212 419 minecraft:light[level=14]
setblock 285 212 427 minecraft:light[level=14]
setblock 285 212 443 minecraft:light[level=14]
setblock 285 212 451 minecraft:light[level=14]
fill 285 212 458 285 228 458 minecraft:dark_oak_planks
setblock 287 212 434 minecraft:ochre_froglight
fill 289 212 416 289 228 416 minecraft:dark_oak_planks
fill 290 212 416 291 212 416 minecraft:ochre_froglight
fill 292 212 416 292 228 416 minecraft:dark_oak_planks
setblock 293 212 419 minecraft:light[level=14]
setblock 293 212 427 minecraft:light[level=14]
setblock 293 212 435 minecraft:light[level=14]
setblock 293 212 443 minecraft:light[level=14]
setblock 293 212 451 minecraft:light[level=14]
fill 294 212 458 294 228 458 minecraft:dark_oak_planks
fill 295 212 458 296 212 458 minecraft:ochre_froglight
fill 297 212 458 297 228 458 minecraft:dark_oak_planks
fill 301 212 416 301 228 416 minecraft:dark_oak_planks
setblock 301 212 419 minecraft:light[level=14]
setblock 301 212 427 minecraft:light[level=14]
setblock 301 212 435 minecraft:light[level=14]
setblock 301 212 443 minecraft:light[level=14]
setblock 301 212 451 minecraft:light[level=14]
fill 302 212 416 303 212 416 minecraft:ochre_froglight
fill 304 212 416 304 228 416 minecraft:dark_oak_planks
fill 306 212 458 306 228 458 minecraft:dark_oak_planks
fill 307 212 458 308 212 458 minecraft:ochre_froglight
setblock 309 212 419 minecraft:light[level=14]
setblock 309 212 427 minecraft:light[level=14]
setblock 309 212 435 minecraft:light[level=14]
setblock 309 212 443 minecraft:light[level=14]
setblock 309 212 451 minecraft:light[level=14]
fill 309 212 458 309 228 458 minecraft:dark_oak_planks
fill 313 212 416 313 228 416 minecraft:dark_oak_planks
fill 314 212 416 315 212 416 minecraft:ochre_froglight
fill 316 212 416 316 228 416 minecraft:dark_oak_planks
setblock 317 212 419 minecraft:light[level=14]
setblock 317 212 427 minecraft:light[level=14]
setblock 317 212 435 minecraft:light[level=14]
setblock 317 212 443 minecraft:light[level=14]
setblock 317 212 451 minecraft:light[level=14]
fill 318 212 458 318 228 458 minecraft:dark_oak_planks
fill 319 212 458 320 212 458 minecraft:ochre_froglight
fill 321 212 458 321 228 458 minecraft:dark_oak_planks
fill 324 212 417 324 228 417 minecraft:dark_oak_planks
fill 324 212 418 324 212 419 minecraft:ochre_froglight
fill 324 212 420 324 228 420 minecraft:dark_oak_planks
fill 324 212 429 324 228 429 minecraft:dark_oak_planks
fill 324 212 430 324 212 431 minecraft:ochre_froglight
fill 324 212 432 324 228 432 minecraft:dark_oak_planks
fill 324 212 441 324 228 441 minecraft:dark_oak_planks
fill 324 212 442 324 212 443 minecraft:ochre_froglight
fill 324 212 444 324 228 444 minecraft:dark_oak_planks
fill 324 212 453 324 228 453 minecraft:dark_oak_planks
fill 324 212 454 324 212 455 minecraft:ochre_froglight
fill 324 212 456 324 228 456 minecraft:dark_oak_planks
fill 282 213 423 282 228 424 minecraft:dark_oak_planks
fill 282 213 435 282 228 436 minecraft:dark_oak_planks
fill 282 213 447 282 228 448 minecraft:dark_oak_planks
fill 283 213 433 283 213 435 minecraft:waxed_cut_copper
fill 283 213 458 284 228 458 minecraft:dark_oak_planks
fill 284 213 432 286 213 432 minecraft:waxed_cut_copper
fill 284 213 436 286 213 436 minecraft:waxed_cut_copper
fill 287 213 433 287 213 435 minecraft:waxed_cut_copper
fill 290 213 416 291 228 416 minecraft:dark_oak_planks
fill 295 213 458 296 228 458 minecraft:dark_oak_planks
fill 302 213 416 303 228 416 minecraft:dark_oak_planks
fill 307 213 458 308 228 458 minecraft:dark_oak_planks
fill 314 213 416 315 228 416 minecraft:dark_oak_planks
fill 319 213 458 320 228 458 minecraft:dark_oak_planks
fill 324 213 418 324 228 419 minecraft:dark_oak_planks
fill 324 213 430 324 228 431 minecraft:dark_oak_planks
fill 324 213 442 324 228 443 minecraft:dark_oak_planks
fill 324 213 454 324 228 455 minecraft:dark_oak_planks
setblock 312 214 419 minecraft:waxed_cut_copper
setblock 312 214 421 minecraft:waxed_cut_copper
setblock 314 214 419 minecraft:waxed_cut_copper
setblock 314 214 421 minecraft:waxed_cut_copper
setblock 285 220 419 minecraft:light[level=14]
setblock 285 220 427 minecraft:light[level=14]
setblock 285 220 435 minecraft:light[level=14]
setblock 285 220 443 minecraft:light[level=14]
setblock 285 220 451 minecraft:light[level=14]
setblock 293 220 419 minecraft:light[level=14]
setblock 293 220 427 minecraft:light[level=14]
setblock 293 220 435 minecraft:light[level=14]
setblock 293 220 443 minecraft:light[level=14]
setblock 293 220 451 minecraft:light[level=14]
setblock 301 220 419 minecraft:light[level=14]
setblock 301 220 427 minecraft:light[level=14]
setblock 301 220 435 minecraft:light[level=14]
setblock 301 220 443 minecraft:light[level=14]
setblock 301 220 451 minecraft:light[level=14]
setblock 309 220 419 minecraft:light[level=14]
setblock 309 220 427 minecraft:light[level=14]
setblock 309 220 435 minecraft:light[level=14]
setblock 309 220 443 minecraft:light[level=14]
setblock 309 220 451 minecraft:light[level=14]
setblock 317 220 419 minecraft:light[level=14]
setblock 317 220 427 minecraft:light[level=14]
setblock 317 220 435 minecraft:light[level=14]
setblock 317 220 443 minecraft:light[level=14]
setblock 317 220 451 minecraft:light[level=14]
fill 290 224 439 300 224 439 minecraft:waxed_copper_block
fill 291 224 434 312 224 435 minecraft:waxed_copper_block
fill 291 224 438 301 224 438 minecraft:waxed_copper_block
fill 291 224 441 302 224 442 minecraft:waxed_copper_block
fill 292 224 445 312 224 445 minecraft:waxed_copper_block
fill 293 224 431 294 225 431 minecraft:waxed_copper_block
fill 293 224 436 302 224 437 minecraft:waxed_copper_block
fill 293 224 440 301 224 440 minecraft:waxed_copper_block
fill 293 224 443 315 224 443 minecraft:waxed_copper_block
fill 293 224 446 293 225 446 minecraft:waxed_copper_block
fill 294 224 432 311 224 433 minecraft:waxed_copper_block
fill 294 224 444 315 224 444 minecraft:waxed_copper_block
fill 295 224 446 312 225 446 minecraft:waxed_copper_block
fill 295 224 448 295 225 449 minecraft:waxed_copper_block
fill 296 224 429 297 225 429 minecraft:waxed_copper_block
fill 296 224 431 310 224 431 minecraft:waxed_copper_block
fill 296 224 447 309 225 448 minecraft:waxed_copper_block
fill 297 224 428 297 225 428 minecraft:waxed_copper_block
fill 297 224 430 311 225 430 minecraft:waxed_copper_block
fill 298 224 449 299 225 451 minecraft:waxed_copper_block
fill 299 224 429 308 225 429 minecraft:waxed_copper_block
fill 300 224 427 301 225 428 minecraft:waxed_copper_block
fill 300 224 449 307 225 449 minecraft:waxed_copper_block
fill 302 224 450 303 225 451 minecraft:waxed_copper_block
fill 303 224 426 303 225 428 minecraft:waxed_copper_block
fill 303 224 436 315 224 436 minecraft:waxed_copper_block
fill 303 224 442 313 224 442 minecraft:waxed_copper_block
fill 303 224 452 303 225 452 minecraft:waxed_copper_block
fill 304 224 427 304 225 428 minecraft:waxed_copper_block
fill 304 224 437 315 224 437 minecraft:waxed_copper_block
fill 304 224 441 313 224 441 minecraft:waxed_copper_block
fill 305 224 438 313 224 438 minecraft:waxed_copper_block
fill 305 224 440 315 224 440 minecraft:waxed_copper_block
fill 305 224 450 306 225 451 minecraft:waxed_copper_block
fill 306 224 439 316 224 439 minecraft:waxed_copper_block
fill 307 224 427 308 225 428 minecraft:waxed_copper_block
fill 309 224 449 309 225 450 minecraft:waxed_copper_block
fill 310 224 447 310 225 447 minecraft:waxed_copper_block
fill 310 224 449 310 225 449 minecraft:waxed_copper_block
fill 311 224 429 311 225 429 minecraft:waxed_copper_block
fill 312 224 433 314 225 433 minecraft:waxed_copper_block
fill 312 224 447 313 225 447 minecraft:waxed_copper_block
fill 313 224 432 313 225 432 minecraft:waxed_copper_block
fill 313 224 435 313 225 435 minecraft:waxed_copper_block
fill 283 225 417 289 225 457 minecraft:spruce_planks
fill 290 225 417 290 225 438 minecraft:spruce_planks
fill 290 225 439 299 225 439 minecraft:waxed_copper_block
fill 290 225 440 290 225 457 minecraft:spruce_planks
fill 291 225 417 292 225 433 minecraft:spruce_planks
fill 291 225 434 300 225 435 minecraft:waxed_copper_block
fill 291 225 436 292 225 437 minecraft:spruce_planks
fill 291 225 438 299 225 438 minecraft:waxed_copper_block
fill 291 225 440 292 225 440 minecraft:spruce_planks
fill 291 225 441 294 225 442 minecraft:waxed_copper_block
fill 291 225 443 291 225 457 minecraft:spruce_planks
fill 292 225 443 292 225 444 minecraft:spruce_planks
fill 292 225 445 296 225 445 minecraft:waxed_copper_block
fill 292 225 446 292 225 457 minecraft:spruce_planks
fill 293 225 417 295 225 430 minecraft:spruce_planks
fill 293 225 432 293 225 433 minecraft:spruce_planks
fill 293 225 436 300 225 437 minecraft:waxed_copper_block
fill 293 225 440 294 225 440 minecraft:waxed_copper_block
fill 293 225 443 295 225 443 minecraft:waxed_copper_block
setblock 293 225 444 minecraft:spruce_planks
fill 293 225 447 294 225 457 minecraft:spruce_planks
fill 294 225 432 298 225 433 minecraft:waxed_copper_block
fill 294 225 444 296 225 444 minecraft:waxed_copper_block
setblock 294 225 446 minecraft:spruce_planks
setblock 295 225 431 minecraft:spruce_planks
fill 295 225 440 299 225 441 minecraft:gold_block
setblock 295 225 442 minecraft:waxed_copper_block
setblock 295 225 447 minecraft:spruce_planks
fill 295 225 450 297 225 457 minecraft:spruce_planks
fill 296 225 417 296 225 428 minecraft:spruce_planks
setblock 296 225 430 minecraft:spruce_planks
fill 296 225 431 300 225 431 minecraft:waxed_copper_block
fill 296 225 442 300 225 443 minecraft:gold_block
fill 296 225 449 297 225 449 minecraft:spruce_planks
fill 297 225 417 299 225 427 minecraft:spruce_planks
fill 297 225 444 299 225 445 minecraft:gold_block
fill 298 225 428 298 225 429 minecraft:spruce_planks
fill 298 225 452 302 225 457 minecraft:spruce_planks
setblock 299 225 428 minecraft:spruce_planks
fill 299 225 432 307 225 432 minecraft:gold_block
setblock 299 225 433 minecraft:waxed_copper_block
fill 300 225 417 302 225 426 minecraft:spruce_planks
fill 300 225 433 306 225 433 minecraft:gold_block
fill 300 225 438 300 225 440 minecraft:ochre_froglight
setblock 300 225 441 minecraft:gold_block
setblock 300 225 444 minecraft:gold_block
fill 300 225 445 306 225 445 minecraft:waxed_copper_block
fill 300 225 450 301 225 451 minecraft:spruce_planks
fill 301 225 431 305 225 431 minecraft:gold_block
fill 301 225 434 305 225 435 minecraft:gold_block
setblock 301 225 436 minecraft:waxed_copper_block
fill 301 225 437 301 225 438 minecraft:ochre_froglight
fill 301 225 440 301 225 441 minecraft:ochre_froglight
setblock 301 225 442 minecraft:gold_block
fill 301 225 443 305 225 444 minecraft:waxed_copper_block
fill 302 225 427 302 225 428 minecraft:spruce_planks
fill 302 225 436 302 225 437 minecraft:ochre_froglight
fill 302 225 441 302 225 442 minecraft:ochre_froglight
fill 303 225 417 323 225 425 minecraft:spruce_planks
fill 303 225 436 304 225 436 minecraft:ochre_froglight
fill 303 225 442 304 225 442 minecraft:ochre_froglight
fill 303 225 453 323 225 457 minecraft:spruce_planks
fill 304 225 426 323 225 426 minecraft:spruce_planks
fill 304 225 437 305 225 437 minecraft:ochre_froglight
fill 304 225 441 305 225 441 minecraft:ochre_froglight
fill 304 225 450 304 225 452 minecraft:spruce_planks
fill 305 225 427 306 225 428 minecraft:spruce_planks
fill 305 225 436 315 225 436 minecraft:waxed_copper_block
fill 305 225 438 306 225 438 minecraft:ochre_froglight
fill 305 225 440 306 225 440 minecraft:ochre_froglight
fill 305 225 442 310 225 442 minecraft:gold_block
fill 305 225 452 323 225 452 minecraft:spruce_planks
fill 306 225 431 310 225 431 minecraft:waxed_copper_block
fill 306 225 434 312 225 435 minecraft:waxed_copper_block
fill 306 225 437 315 225 437 minecraft:waxed_copper_block
setblock 306 225 439 minecraft:ochre_froglight
fill 306 225 441 311 225 441 minecraft:gold_block
fill 306 225 443 309 225 444 minecraft:gold_block
fill 307 225 433 311 225 433 minecraft:waxed_copper_block
fill 307 225 438 313 225 438 minecraft:waxed_copper_block
fill 307 225 439 311 225 440 minecraft:gold_block
fill 307 225 445 309 225 445 minecraft:gold_block
fill 307 225 450 308 225 451 minecraft:spruce_planks
fill 308 225 432 311 225 432 minecraft:waxed_copper_block
setblock 308 225 449 minecraft:spruce_planks
fill 309 225 427 310 225 429 minecraft:spruce_planks
fill 309 225 451 323 225 451 minecraft:spruce_planks
setblock 310 225 443 minecraft:gold_block
fill 310 225 444 312 225 445 minecraft:waxed_copper_block
fill 310 225 448 323 225 448 minecraft:spruce_planks
fill 310 225 450 323 225 450 minecraft:spruce_planks
fill 311 225 427 323 225 428 minecraft:spruce_planks
fill 311 225 431 323 225 431 minecraft:spruce_planks
fill 311 225 442 313 225 443 minecraft:waxed_copper_block
setblock 311 225 447 minecraft:spruce_planks
fill 311 225 449 323 225 449 minecraft:spruce_planks
fill 312 225 429 323 225 430 minecraft:spruce_planks
setblock 312 225 432 minecraft:spruce_planks
fill 312 225 439 313 225 441 minecraft:waxed_copper_block
fill 313 225 434 323 225 434 minecraft:spruce_planks
fill 313 225 444 315 225 444 minecraft:waxed_copper_block
fill 313 225 445 323 225 446 minecraft:spruce_planks
fill 314 225 432 323 225 432 minecraft:spruce_planks
fill 314 225 435 323 225 435 minecraft:spruce_planks
fill 314 225 438 323 225 438 minecraft:spruce_planks
fill 314 225 439 315 225 440 minecraft:waxed_copper_block
fill 314 225 441 323 225 442 minecraft:spruce_planks
fill 314 225 443 315 225 443 minecraft:waxed_copper_block
fill 314 225 447 323 225 447 minecraft:spruce_planks
fill 315 225 433 323 225 433 minecraft:spruce_planks
fill 316 225 436 323 225 437 minecraft:spruce_planks
setblock 316 225 439 minecraft:waxed_copper_block
fill 316 225 440 323 225 440 minecraft:spruce_planks
fill 316 225 443 323 225 444 minecraft:spruce_planks
fill 317 225 439 323 225 439 minecraft:spruce_planks
setblock 285 228 419 minecraft:light[level=14]
setblock 285 228 427 minecraft:light[level=14]
setblock 285 228 435 minecraft:light[level=14]
setblock 285 228 443 minecraft:light[level=14]
setblock 285 228 451 minecraft:light[level=14]
setblock 293 228 419 minecraft:light[level=14]
setblock 293 228 427 minecraft:light[level=14]
setblock 293 228 435 minecraft:light[level=14]
setblock 293 228 443 minecraft:light[level=14]
setblock 293 228 451 minecraft:light[level=14]
setblock 301 228 419 minecraft:light[level=14]
setblock 301 228 427 minecraft:light[level=14]
setblock 301 228 435 minecraft:light[level=14]
setblock 301 228 443 minecraft:light[level=14]
setblock 301 228 451 minecraft:light[level=14]
setblock 309 228 419 minecraft:light[level=14]
setblock 309 228 427 minecraft:light[level=14]
setblock 309 228 435 minecraft:light[level=14]
setblock 309 228 443 minecraft:light[level=14]
setblock 309 228 451 minecraft:light[level=14]
setblock 317 228 419 minecraft:light[level=14]
setblock 317 228 427 minecraft:light[level=14]
setblock 317 228 435 minecraft:light[level=14]
setblock 317 228 443 minecraft:light[level=14]
setblock 317 228 451 minecraft:light[level=14]
fill 282 229 422 282 231 425 minecraft:ochre_froglight
fill 282 229 434 282 231 437 minecraft:ochre_froglight
fill 282 229 446 282 231 449 minecraft:ochre_froglight
fill 282 229 458 285 231 458 minecraft:ochre_froglight
fill 283 229 417 285 273 417 minecraft:waxed_cut_copper
fill 283 229 427 283 273 429 minecraft:waxed_cut_copper
fill 283 229 439 283 273 441 minecraft:waxed_cut_copper
fill 283 229 451 283 273 453 minecraft:waxed_cut_copper
fill 289 229 416 292 231 416 minecraft:ochre_froglight
fill 289 229 457 291 273 457 minecraft:waxed_cut_copper
fill 294 229 458 297 231 458 minecraft:ochre_froglight
fill 295 229 417 297 273 417 minecraft:waxed_cut_copper
fill 301 229 416 304 231 416 minecraft:ochre_froglight
fill 301 229 457 303 273 457 minecraft:waxed_cut_copper
fill 304 229 422 304 245 422 minecraft:waxed_copper_block
fill 306 229 458 309 231 458 minecraft:ochre_froglight
fill 307 229 417 309 273 417 minecraft:waxed_cut_copper
fill 313 229 416 316 231 416 minecraft:ochre_froglight
fill 313 229 457 315 273 457 minecraft:waxed_cut_copper
fill 318 229 458 321 231 458 minecraft:ochre_froglight
fill 319 229 417 321 273 417 minecraft:waxed_cut_copper
fill 323 229 425 323 273 427 minecraft:waxed_cut_copper
fill 323 229 437 323 273 439 minecraft:waxed_cut_copper
fill 323 229 449 323 273 451 minecraft:waxed_cut_copper
fill 324 229 417 324 231 420 minecraft:ochre_froglight
fill 324 229 429 324 231 432 minecraft:ochre_froglight
fill 324 229 441 324 231 444 minecraft:ochre_froglight
fill 324 229 453 324 231 456 minecraft:ochre_froglight
fill 316 230 449 316 238 449 minecraft:waxed_copper_block
fill 282 232 422 282 245 422 minecraft:dark_oak_planks
fill 282 232 423 282 232 424 minecraft:ochre_froglight
fill 282 232 425 282 245 425 minecraft:dark_oak_planks
fill 282 232 434 282 245 434 minecraft:dark_oak_planks
fill 282 232 435 282 232 436 minecraft:ochre_froglight
fill 282 232 437 282 245 437 minecraft:dark_oak_planks
fill 282 232 446 282 245 446 minecraft:dark_oak_planks
fill 282 232 447 282 232 448 minecraft:ochre_froglight
fill 282 232 449 282 245 449 minecraft:dark_oak_planks
fill 282 232 458 282 245 458 minecraft:dark_oak_planks
fill 283 232 458 284 232 458 minecraft:ochre_froglight
fill 285 232 458 285 245 458 minecraft:dark_oak_planks
fill 289 232 416 289 245 416 minecraft:dark_oak_planks
fill 290 232 416 291 232 416 minecraft:ochre_froglight
fill 292 232 416 292 245 416 minecraft:dark_oak_planks
fill 294 232 458 294 245 458 minecraft:dark_oak_planks
fill 295 232 458 296 232 458 minecraft:ochre_froglight
fill 297 232 458 297 245 458 minecraft:dark_oak_planks
fill 301 232 416 301 245 416 minecraft:dark_oak_planks
fill 302 232 416 303 232 416 minecraft:ochre_froglight
fill 304 232 416 304 245 416 minecraft:dark_oak_planks
fill 306 232 458 306 245 458 minecraft:dark_oak_planks
fill 307 232 458 308 232 458 minecraft:ochre_froglight
fill 309 232 458 309 245 458 minecraft:dark_oak_planks
fill 313 232 416 313 245 416 minecraft:dark_oak_planks
fill 314 232 416 315 232 416 minecraft:ochre_froglight
fill 316 232 416 316 245 416 minecraft:dark_oak_planks
fill 318 232 458 318 245 458 minecraft:dark_oak_planks
fill 319 232 458 320 232 458 minecraft:ochre_froglight
fill 321 232 458 321 245 458 minecraft:dark_oak_planks
fill 324 232 417 324 245 417 minecraft:dark_oak_planks
fill 324 232 418 324 232 419 minecraft:ochre_froglight
fill 324 232 420 324 245 420 minecraft:dark_oak_planks
fill 324 232 429 324 245 429 minecraft:dark_oak_planks
fill 324 232 430 324 232 431 minecraft:ochre_froglight
fill 324 232 432 324 245 432 minecraft:dark_oak_planks
fill 324 232 441 324 245 441 minecraft:dark_oak_planks
fill 324 232 442 324 232 443 minecraft:ochre_froglight
fill 324 232 444 324 245 444 minecraft:dark_oak_planks
fill 324 232 453 324 245 453 minecraft:dark_oak_planks
fill 324 232 454 324 232 455 minecraft:ochre_froglight
fill 324 232 456 324 245 456 minecraft:dark_oak_planks
fill 282 233 423 282 245 424 minecraft:dark_oak_planks
fill 282 233 435 282 245 436 minecraft:dark_oak_planks
fill 282 233 447 282 245 448 minecraft:dark_oak_planks
fill 283 233 458 284 245 458 minecraft:dark_oak_planks
fill 290 233 416 291 245 416 minecraft:dark_oak_planks
fill 295 233 458 296 245 458 minecraft:dark_oak_planks
fill 302 233 416 303 245 416 minecraft:dark_oak_planks
fill 307 233 458 308 245 458 minecraft:dark_oak_planks
fill 314 233 416 315 245 416 minecraft:dark_oak_planks
fill 319 233 458 320 245 458 minecraft:dark_oak_planks
fill 324 233 418 324 245 419 minecraft:dark_oak_planks
fill 324 233 430 324 245 431 minecraft:dark_oak_planks
fill 324 233 442 324 245 443 minecraft:dark_oak_planks
fill 324 233 454 324 245 455 minecraft:dark_oak_planks
setblock 285 236 419 minecraft:light[level=14]
setblock 285 236 427 minecraft:light[level=14]
setblock 285 236 435 minecraft:light[level=14]
setblock 285 236 443 minecraft:light[level=14]
setblock 285 236 451 minecraft:light[level=14]
setblock 293 236 419 minecraft:light[level=14]
setblock 293 236 427 minecraft:light[level=14]
setblock 293 236 435 minecraft:light[level=14]
setblock 293 236 443 minecraft:light[level=14]
setblock 293 236 451 minecraft:light[level=14]
setblock 301 236 419 minecraft:light[level=14]
setblock 301 236 427 minecraft:light[level=14]
setblock 301 236 435 minecraft:light[level=14]
setblock 301 236 443 minecraft:light[level=14]
setblock 301 236 451 minecraft:light[level=14]
setblock 309 236 419 minecraft:light[level=14]
setblock 309 236 427 minecraft:light[level=14]
setblock 309 236 435 minecraft:light[level=14]
setblock 309 236 443 minecraft:light[level=14]
setblock 309 236 451 minecraft:light[level=14]
setblock 317 236 419 minecraft:light[level=14]
setblock 317 236 427 minecraft:light[level=14]
setblock 317 236 435 minecraft:light[level=14]
setblock 317 236 443 minecraft:light[level=14]
setblock 317 236 451 minecraft:light[level=14]
fill 284 239 428 289 239 428 minecraft:dark_oak_planks
fill 285 239 426 289 240 427 minecraft:dark_oak_planks
fill 285 239 429 289 240 430 minecraft:dark_oak_planks
fill 284 240 426 284 245 428 minecraft:waxed_cut_copper
fill 284 240 438 284 245 440 minecraft:waxed_cut_copper
fill 284 240 450 284 245 452 minecraft:waxed_cut_copper
fill 285 240 428 289 240 428 minecraft:dark_oak_planks
fill 290 240 456 292 245 456 minecraft:waxed_cut_copper
fill 294 240 418 296 245 418 minecraft:waxed_cut_copper
fill 302 240 456 304 245 456 minecraft:waxed_cut_copper
fill 306 240 418 308 245 418 minecraft:waxed_cut_copper
fill 314 240 456 316 245 456 minecraft:waxed_cut_copper
fill 318 240 418 320 245 418 minecraft:waxed_cut_copper
fill 322 240 426 322 245 428 minecraft:waxed_cut_copper
fill 322 240 438 322 245 440 minecraft:waxed_cut_copper
fill 322 240 450 322 245 452 minecraft:waxed_cut_copper
fill 284 244 429 284 245 430 minecraft:waxed_copper_block
setblock 285 244 419 minecraft:light[level=14]
fill 285 244 425 285 245 426 minecraft:waxed_copper_block
setblock 285 244 427 minecraft:light[level=14]
fill 285 244 428 289 245 428 minecraft:waxed_cut_copper
fill 285 244 430 285 245 431 minecraft:waxed_copper_block
setblock 285 244 435 minecraft:light[level=14]
setblock 285 244 443 minecraft:light[level=14]
setblock 285 244 451 minecraft:light[level=14]
fill 286 244 425 289 245 425 minecraft:waxed_copper_block
fill 286 244 431 289 245 431 minecraft:waxed_copper_block
fill 287 244 426 287 245 427 minecraft:waxed_cut_copper
fill 287 244 429 287 245 430 minecraft:waxed_cut_copper
fill 289 244 426 290 245 426 minecraft:waxed_copper_block
fill 289 244 430 290 245 430 minecraft:waxed_copper_block
fill 290 244 427 290 245 429 minecraft:waxed_copper_block
setblock 293 244 419 minecraft:light[level=14]
setblock 293 244 427 minecraft:light[level=14]
setblock 293 244 435 minecraft:light[level=14]
setblock 293 244 443 minecraft:light[level=14]
setblock 293 244 451 minecraft:light[level=14]
setblock 301 244 419 minecraft:light[level=14]
setblock 301 244 427 minecraft:light[level=14]
setblock 301 244 435 minecraft:light[level=14]
setblock 301 244 443 minecraft:light[level=14]
setblock 301 244 451 minecraft:light[level=14]
setblock 309 244 419 minecraft:light[level=14]
setblock 309 244 427 minecraft:light[level=14]
setblock 309 244 435 minecraft:light[level=14]
setblock 309 244 443 minecraft:light[level=14]
setblock 309 244 451 minecraft:light[level=14]
setblock 317 244 419 minecraft:light[level=14]
setblock 317 244 427 minecraft:light[level=14]
setblock 317 244 435 minecraft:light[level=14]
setblock 317 244 443 minecraft:light[level=14]
setblock 317 244 451 minecraft:light[level=14]
fill 319 244 429 319 259 429 minecraft:waxed_copper_block
fill 283 245 420 283 245 425 minecraft:dark_oak_planks
fill 283 245 432 283 245 437 minecraft:dark_oak_planks
fill 283 245 444 283 245 449 minecraft:dark_oak_planks
fill 283 245 456 283 245 457 minecraft:dark_oak_planks
fill 284 245 457 287 245 457 minecraft:dark_oak_planks
fill 287 245 417 292 245 417 minecraft:dark_oak_planks
fill 294 245 457 299 245 457 minecraft:dark_oak_planks
fill 299 245 417 304 245 417 minecraft:dark_oak_planks
fill 306 245 457 311 245 457 minecraft:dark_oak_planks
fill 311 245 417 316 245 417 minecraft:dark_oak_planks
fill 318 245 457 323 245 457 minecraft:dark_oak_planks
fill 323 245 417 323 245 422 minecraft:dark_oak_planks
fill 323 245 429 323 245 434 minecraft:dark_oak_planks
fill 323 245 441 323 245 446 minecraft:dark_oak_planks
fill 323 245 453 323 245 456 minecraft:dark_oak_planks
fill 282 246 422 282 251 425 minecraft:ochre_froglight
fill 282 246 434 282 251 437 minecraft:ochre_froglight
fill 282 246 446 282 251 449 minecraft:ochre_froglight
fill 282 246 458 285 251 458 minecraft:ochre_froglight
fill 289 246 416 292 251 416 minecraft:ochre_froglight
fill 294 246 458 297 251 458 minecraft:ochre_froglight
fill 301 246 416 304 251 416 minecraft:ochre_froglight
fill 306 246 458 309 251 458 minecraft:ochre_froglight
fill 313 246 416 316 251 416 minecraft:ochre_froglight
fill 318 246 458 321 251 458 minecraft:ochre_froglight
fill 324 246 417 324 251 420 minecraft:ochre_froglight
fill 324 246 429 324 251 432 minecraft:ochre_froglight
fill 324 246 441 324 251 444 minecraft:ochre_froglight
fill 324 246 453 324 251 456 minecraft:ochre_froglight
fill 282 252 422 282 265 422 minecraft:dark_oak_planks
fill 282 252 423 282 252 424 minecraft:ochre_froglight
fill 282 252 425 282 265 425 minecraft:dark_oak_planks
fill 282 252 434 282 265 434 minecraft:dark_oak_planks
fill 282 252 435 282 252 436 minecraft:ochre_froglight
fill 282 252 437 282 265 437 minecraft:dark_oak_planks
fill 282 252 446 282 265 446 minecraft:dark_oak_planks
fill 282 252 447 282 252 448 minecraft:ochre_froglight
fill 282 252 449 282 265 449 minecraft:dark_oak_planks
fill 282 252 458 282 265 458 minecraft:dark_oak_planks
fill 283 252 458 284 252 458 minecraft:ochre_froglight
setblock 285 252 419 minecraft:light[level=14]
setblock 285 252 427 minecraft:light[level=14]
setblock 285 252 435 minecraft:light[level=14]
setblock 285 252 443 minecraft:light[level=14]
setblock 285 252 451 minecraft:light[level=14]
fill 285 252 458 285 265 458 minecraft:dark_oak_planks
fill 289 252 416 289 265 416 minecraft:dark_oak_planks
fill 290 252 416 291 252 416 minecraft:ochre_froglight
fill 292 252 416 292 265 416 minecraft:dark_oak_planks
setblock 293 252 419 minecraft:light[level=14]
setblock 293 252 427 minecraft:light[level=14]
setblock 293 252 435 minecraft:light[level=14]
setblock 293 252 443 minecraft:light[level=14]
setblock 293 252 451 minecraft:light[level=14]
fill 294 252 458 294 265 458 minecraft:dark_oak_planks
fill 295 252 458 296 252 458 minecraft:ochre_froglight
fill 297 252 458 297 265 458 minecraft:dark_oak_planks
fill 301 252 416 301 265 416 minecraft:dark_oak_planks
setblock 301 252 419 minecraft:light[level=14]
setblock 301 252 427 minecraft:light[level=14]
setblock 301 252 435 minecraft:light[level=14]
setblock 301 252 443 minecraft:light[level=14]
setblock 301 252 451 minecraft:light[level=14]
fill 302 252 416 303 252 416 minecraft:ochre_froglight
fill 304 252 416 304 265 416 minecraft:dark_oak_planks
fill 306 252 458 306 265 458 minecraft:dark_oak_planks
fill 307 252 458 308 252 458 minecraft:ochre_froglight
setblock 309 252 419 minecraft:light[level=14]
setblock 309 252 427 minecraft:light[level=14]
setblock 309 252 435 minecraft:light[level=14]
setblock 309 252 443 minecraft:light[level=14]
setblock 309 252 451 minecraft:light[level=14]
fill 309 252 458 309 265 458 minecraft:dark_oak_planks
fill 313 252 416 313 265 416 minecraft:dark_oak_planks
fill 314 252 416 315 252 416 minecraft:ochre_froglight
fill 316 252 416 316 265 416 minecraft:dark_oak_planks
setblock 317 252 419 minecraft:light[level=14]
setblock 317 252 427 minecraft:light[level=14]
setblock 317 252 435 minecraft:light[level=14]
setblock 317 252 443 minecraft:light[level=14]
setblock 317 252 451 minecraft:light[level=14]
fill 318 252 458 318 265 458 minecraft:dark_oak_planks
fill 319 252 458 320 252 458 minecraft:ochre_froglight
fill 321 252 458 321 265 458 minecraft:dark_oak_planks
fill 324 252 417 324 265 417 minecraft:dark_oak_planks
fill 324 252 418 324 252 419 minecraft:ochre_froglight
fill 324 252 420 324 265 420 minecraft:dark_oak_planks
fill 324 252 429 324 265 429 minecraft:dark_oak_planks
fill 324 252 430 324 252 431 minecraft:ochre_froglight
fill 324 252 432 324 265 432 minecraft:dark_oak_planks
fill 324 252 441 324 265 441 minecraft:dark_oak_planks
fill 324 252 442 324 252 443 minecraft:ochre_froglight
fill 324 252 444 324 265 444 minecraft:dark_oak_planks
fill 324 252 453 324 265 453 minecraft:dark_oak_planks
fill 324 252 454 324 252 455 minecraft:ochre_froglight
fill 324 252 456 324 265 456 minecraft:dark_oak_planks
fill 282 253 423 282 265 424 minecraft:dark_oak_planks
fill 282 253 435 282 265 436 minecraft:dark_oak_planks
fill 282 253 447 282 265 448 minecraft:dark_oak_planks
fill 283 253 458 284 265 458 minecraft:dark_oak_planks
fill 290 253 416 291 265 416 minecraft:dark_oak_planks
fill 295 253 458 296 265 458 minecraft:dark_oak_planks
fill 302 253 416 303 265 416 minecraft:dark_oak_planks
fill 307 253 458 308 265 458 minecraft:dark_oak_planks
fill 314 253 416 315 265 416 minecraft:dark_oak_planks
fill 319 253 458 320 265 458 minecraft:dark_oak_planks
fill 324 253 418 324 265 419 minecraft:dark_oak_planks
fill 324 253 430 324 265 431 minecraft:dark_oak_planks
fill 324 253 442 324 265 443 minecraft:dark_oak_planks
fill 324 253 454 324 265 455 minecraft:dark_oak_planks
fill 284 260 426 284 265 428 minecraft:waxed_cut_copper
fill 284 260 438 284 265 440 minecraft:waxed_cut_copper
fill 284 260 450 284 265 452 minecraft:waxed_cut_copper
setblock 285 260 419 minecraft:light[level=14]
setblock 285 260 427 minecraft:light[level=14]
setblock 285 260 435 minecraft:light[level=14]
setblock 285 260 443 minecraft:light[level=14]
setblock 285 260 451 minecraft:light[level=14]
fill 290 260 456 292 265 456 minecraft:waxed_cut_copper
setblock 293 260 419 minecraft:light[level=14]
setblock 293 260 427 minecraft:light[level=14]
setblock 293 260 435 minecraft:light[level=14]
setblock 293 260 443 minecraft:light[level=14]
setblock 293 260 451 minecraft:light[level=14]
fill 294 260 418 296 265 418 minecraft:waxed_cut_copper
setblock 301 260 419 minecraft:light[level=14]
setblock 301 260 427 minecraft:light[level=14]
setblock 301 260 435 minecraft:light[level=14]
setblock 301 260 443 minecraft:light[level=14]
setblock 301 260 451 minecraft:light[level=14]
fill 302 260 456 304 265 456 minecraft:waxed_cut_copper
fill 306 260 418 308 265 418 minecraft:waxed_cut_copper
setblock 309 260 419 minecraft:light[level=14]
setblock 309 260 427 minecraft:light[level=14]
setblock 309 260 435 minecraft:light[level=14]
setblock 309 260 443 minecraft:light[level=14]
setblock 309 260 451 minecraft:light[level=14]
fill 314 260 456 316 265 456 minecraft:waxed_cut_copper
setblock 317 260 419 minecraft:light[level=14]
setblock 317 260 427 minecraft:light[level=14]
setblock 317 260 435 minecraft:light[level=14]
setblock 317 260 443 minecraft:light[level=14]
setblock 317 260 451 minecraft:light[level=14]
fill 318 260 418 320 265 418 minecraft:waxed_cut_copper
fill 322 260 426 322 265 428 minecraft:waxed_cut_copper
fill 322 260 438 322 265 440 minecraft:waxed_cut_copper
fill 322 260 450 322 265 452 minecraft:waxed_cut_copper
fill 320 262 449 322 263 449 minecraft:waxed_copper_block
fill 283 265 420 283 265 425 minecraft:dark_oak_planks
fill 283 265 432 283 265 437 minecraft:dark_oak_planks
fill 283 265 444 283 265 449 minecraft:dark_oak_planks
fill 283 265 456 283 265 457 minecraft:dark_oak_planks
fill 284 265 457 287 265 457 minecraft:dark_oak_planks
fill 287 265 417 292 265 417 minecraft:dark_oak_planks
fill 294 265 457 299 265 457 minecraft:dark_oak_planks
fill 299 265 417 304 265 417 minecraft:dark_oak_planks
fill 306 265 457 311 265 457 minecraft:dark_oak_planks
fill 311 265 417 316 265 417 minecraft:dark_oak_planks
fill 318 265 457 323 265 457 minecraft:dark_oak_planks
fill 323 265 417 323 265 422 minecraft:dark_oak_planks
fill 323 265 429 323 265 434 minecraft:dark_oak_planks
fill 323 265 441 323 265 446 minecraft:dark_oak_planks
fill 323 265 453 323 265 456 minecraft:dark_oak_planks
fill 282 266 422 282 271 425 minecraft:ochre_froglight
fill 282 266 434 282 271 437 minecraft:ochre_froglight
fill 282 266 446 282 271 449 minecraft:ochre_froglight
fill 282 266 458 285 271 458 minecraft:ochre_froglight
fill 289 266 416 292 271 416 minecraft:ochre_froglight
fill 294 266 458 297 271 458 minecraft:ochre_froglight
fill 301 266 416 304 271 416 minecraft:ochre_froglight
fill 306 266 458 309 271 458 minecraft:ochre_froglight
fill 313 266 416 316 271 416 minecraft:ochre_froglight
fill 318 266 458 321 271 458 minecraft:ochre_froglight
fill 324 266 417 324 271 420 minecraft:ochre_froglight
fill 324 266 429 324 271 432 minecraft:ochre_froglight
fill 324 266 441 324 271 444 minecraft:ochre_froglight
fill 324 266 453 324 271 456 minecraft:ochre_froglight
setblock 285 268 419 minecraft:light[level=14]
setblock 285 268 427 minecraft:light[level=14]
setblock 285 268 435 minecraft:light[level=14]
setblock 285 268 443 minecraft:light[level=14]
setblock 285 268 451 minecraft:light[level=14]
setblock 293 268 419 minecraft:light[level=14]
setblock 293 268 427 minecraft:light[level=14]
setblock 293 268 435 minecraft:light[level=14]
setblock 293 268 443 minecraft:light[level=14]
setblock 293 268 451 minecraft:light[level=14]
setblock 301 268 419 minecraft:light[level=14]
setblock 301 268 427 minecraft:light[level=14]
setblock 301 268 435 minecraft:light[level=14]
setblock 301 268 443 minecraft:light[level=14]
setblock 301 268 451 minecraft:light[level=14]
setblock 309 268 419 minecraft:light[level=14]
setblock 309 268 427 minecraft:light[level=14]
setblock 309 268 435 minecraft:light[level=14]
setblock 309 268 443 minecraft:light[level=14]
setblock 309 268 451 minecraft:light[level=14]
setblock 317 268 419 minecraft:light[level=14]
setblock 317 268 427 minecraft:light[level=14]
setblock 317 268 435 minecraft:light[level=14]
setblock 317 268 443 minecraft:light[level=14]
setblock 317 268 451 minecraft:light[level=14]
fill 309 271 450 313 272 454 minecraft:dark_oak_planks
fill 311 271 455 311 271 456 minecraft:dark_oak_planks
fill 282 272 422 282 285 422 minecraft:dark_oak_planks
fill 282 272 423 282 272 424 minecraft:ochre_froglight
fill 282 272 425 282 285 425 minecraft:dark_oak_planks
fill 282 272 434 282 285 434 minecraft:dark_oak_planks
fill 282 272 435 282 272 436 minecraft:ochre_froglight
fill 282 272 437 282 285 437 minecraft:dark_oak_planks
fill 282 272 446 282 285 446 minecraft:dark_oak_planks
fill 282 272 447 282 272 448 minecraft:ochre_froglight
fill 282 272 449 282 285 449 minecraft:dark_oak_planks
fill 282 272 458 282 285 458 minecraft:dark_oak_planks
fill 283 272 458 284 272 458 minecraft:ochre_froglight
fill 285 272 458 285 285 458 minecraft:dark_oak_planks
fill 289 272 416 289 285 416 minecraft:dark_oak_planks
fill 290 272 416 291 272 416 minecraft:ochre_froglight
fill 292 272 416 292 285 416 minecraft:dark_oak_planks
fill 294 272 458 294 285 458 minecraft:dark_oak_planks
fill 295 272 458 296 272 458 minecraft:ochre_froglight
fill 297 272 458 297 285 458 minecraft:dark_oak_planks
fill 301 272 416 301 285 416 minecraft:dark_oak_planks
fill 302 272 416 303 272 416 minecraft:ochre_froglight
fill 304 272 416 304 285 416 minecraft:dark_oak_planks
fill 306 272 458 306 285 458 minecraft:dark_oak_planks
fill 307 272 458 308 272 458 minecraft:ochre_froglight
fill 309 272 458 309 285 458 minecraft:dark_oak_planks
fill 313 272 416 313 285 416 minecraft:dark_oak_planks
fill 314 272 416 315 272 416 minecraft:ochre_froglight
fill 316 272 416 316 285 416 minecraft:dark_oak_planks
fill 318 272 458 318 285 458 minecraft:dark_oak_planks
fill 319 272 458 320 272 458 minecraft:ochre_froglight
fill 321 272 458 321 285 458 minecraft:dark_oak_planks
fill 324 272 417 324 285 417 minecraft:dark_oak_planks
fill 324 272 418 324 272 419 minecraft:ochre_froglight
fill 324 272 420 324 285 420 minecraft:dark_oak_planks
fill 324 272 429 324 285 429 minecraft:dark_oak_planks
fill 324 272 430 324 272 431 minecraft:ochre_froglight
fill 324 272 432 324 285 432 minecraft:dark_oak_planks
fill 324 272 441 324 285 441 minecraft:dark_oak_planks
fill 324 272 442 324 272 443 minecraft:ochre_froglight
fill 324 272 444 324 285 444 minecraft:dark_oak_planks
fill 324 272 453 324 285 453 minecraft:dark_oak_planks
fill 324 272 454 324 272 455 minecraft:ochre_froglight
fill 324 272 456 324 285 456 minecraft:dark_oak_planks
fill 282 273 423 282 285 424 minecraft:dark_oak_planks
fill 282 273 435 282 285 436 minecraft:dark_oak_planks
fill 282 273 447 282 285 448 minecraft:dark_oak_planks
fill 283 273 458 284 285 458 minecraft:dark_oak_planks
fill 290 273 416 291 285 416 minecraft:dark_oak_planks
fill 295 273 458 296 285 458 minecraft:dark_oak_planks
fill 302 273 416 303 285 416 minecraft:dark_oak_planks
fill 307 273 458 308 285 458 minecraft:dark_oak_planks
fill 314 273 416 315 285 416 minecraft:dark_oak_planks
fill 319 273 458 320 285 458 minecraft:dark_oak_planks
fill 324 273 418 324 285 419 minecraft:dark_oak_planks
fill 324 273 430 324 285 431 minecraft:dark_oak_planks
fill 324 273 442 324 285 443 minecraft:dark_oak_planks
fill 324 273 454 324 285 455 minecraft:dark_oak_planks
setblock 285 276 419 minecraft:light[level=14]
setblock 285 276 427 minecraft:light[level=14]
setblock 285 276 435 minecraft:light[level=14]
setblock 285 276 443 minecraft:light[level=14]
setblock 285 276 451 minecraft:light[level=14]
setblock 293 276 419 minecraft:light[level=14]
setblock 293 276 427 minecraft:light[level=14]
setblock 293 276 435 minecraft:light[level=14]
setblock 293 276 443 minecraft:light[level=14]
setblock 293 276 451 minecraft:light[level=14]
setblock 301 276 419 minecraft:light[level=14]
setblock 301 276 427 minecraft:light[level=14]
setblock 301 276 435 minecraft:light[level=14]
setblock 301 276 443 minecraft:light[level=14]
setblock 301 276 451 minecraft:light[level=14]
setblock 309 276 419 minecraft:light[level=14]
setblock 309 276 427 minecraft:light[level=14]
setblock 309 276 435 minecraft:light[level=14]
setblock 309 276 443 minecraft:light[level=14]
setblock 309 276 451 minecraft:light[level=14]
setblock 317 276 419 minecraft:light[level=14]
setblock 317 276 427 minecraft:light[level=14]
setblock 317 276 435 minecraft:light[level=14]
setblock 317 276 443 minecraft:light[level=14]
setblock 317 276 451 minecraft:light[level=14]
fill 292 279 437 293 280 437 minecraft:gold_block
fill 293 279 432 293 280 436 minecraft:gold_block
fill 293 279 438 293 280 442 minecraft:gold_block
fill 294 279 430 294 280 432 minecraft:gold_block
fill 294 279 433 303 279 441 minecraft:white_terracotta
fill 294 279 442 294 280 444 minecraft:gold_block
fill 295 279 429 295 280 430 minecraft:gold_block
fill 295 279 431 317 279 432 minecraft:white_terracotta
fill 295 279 442 317 279 443 minecraft:white_terracotta
fill 295 279 444 295 280 445 minecraft:gold_block
fill 296 279 428 296 280 429 minecraft:gold_block
fill 296 279 430 316 280 430 minecraft:white_terracotta
fill 296 279 444 316 279 444 minecraft:white_terracotta
fill 296 279 445 296 280 446 minecraft:gold_block
fill 297 279 427 297 280 428 minecraft:gold_block
fill 297 279 429 315 280 429 minecraft:white_terracotta
fill 297 279 445 315 279 445 minecraft:white_terracotta
fill 297 279 446 297 280 447 minecraft:gold_block
fill 298 279 426 298 280 427 minecraft:gold_block
fill 298 279 428 314 280 428 minecraft:white_terracotta
fill 298 279 446 314 280 446 minecraft:white_terracotta
fill 298 279 447 298 280 448 minecraft:gold_block
fill 299 279 425 299 280 426 minecraft:gold_block
fill 299 279 427 313 279 427 minecraft:white_terracotta
fill 299 279 447 313 279 447 minecraft:white_terracotta
fill 299 279 448 299 280 449 minecraft:gold_block
fill 300 279 425 301 280 425 minecraft:gold_block
fill 300 279 426 312 279 426 minecraft:white_terracotta
fill 300 279 448 312 279 448 minecraft:white_terracotta
fill 300 279 449 301 280 449 minecraft:gold_block
fill 301 279 424 311 280 424 minecraft:gold_block
fill 301 279 450 311 280 450 minecraft:gold_block
fill 302 279 425 310 279 425 minecraft:white_terracotta
fill 302 279 449 310 279 449 minecraft:white_terracotta
fill 304 279 433 304 279 435 minecraft:white_terracotta
fill 304 279 439 304 279 441 minecraft:white_terracotta
fill 305 279 433 318 279 434 minecraft:white_terracotta
fill 305 279 440 318 279 441 minecraft:white_terracotta
fill 306 279 423 306 280 423 minecraft:gold_block
fill 306 279 451 306 280 451 minecraft:gold_block
fill 308 279 435 318 279 435 minecraft:white_terracotta
fill 308 279 439 318 279 439 minecraft:white_terracotta
fill 309 279 436 318 279 438 minecraft:white_terracotta
fill 311 279 425 313 280 425 minecraft:gold_block
fill 311 279 449 313 280 449 minecraft:gold_block
fill 313 279 426 314 280 426 minecraft:gold_block
fill 313 279 448 314 280 448 minecraft:gold_block
fill 314 279 427 315 280 427 minecraft:gold_block
fill 314 279 447 315 280 447 minecraft:gold_block
fill 315 279 428 316 280 428 minecraft:gold_block
fill 315 279 446 316 280 446 minecraft:gold_block
fill 316 279 429 317 280 429 minecraft:gold_block
fill 316 279 445 317 280 445 minecraft:gold_block
fill 317 279 430 318 280 430 minecraft:gold_block
fill 317 279 444 318 280 444 minecraft:gold_block
fill 318 279 431 318 280 432 minecraft:gold_block
fill 318 279 442 318 280 443 minecraft:gold_block
fill 319 279 432 319 280 442 minecraft:gold_block
fill 320 279 437 320 280 437 minecraft:gold_block
fill 283 280 417 291 280 457 minecraft:dark_oak_planks
fill 292 280 417 292 280 436 minecraft:dark_oak_planks
fill 292 280 438 292 280 457 minecraft:dark_oak_planks
fill 293 280 417 293 280 431 minecraft:dark_oak_planks
fill 293 280 443 293 280 457 minecraft:dark_oak_planks
fill 294 280 417 294 280 429 minecraft:dark_oak_planks
fill 294 280 433 302 280 436 minecraft:white_terracotta
fill 294 280 437 295 280 437 minecraft:black_concrete
fill 294 280 438 301 280 441 minecraft:white_terracotta
fill 294 280 445 294 280 457 minecraft:dark_oak_planks
fill 295 280 417 295 280 428 minecraft:dark_oak_planks
fill 295 280 431 296 280 431 minecraft:black_concrete
fill 295 280 432 317 280 432 minecraft:white_terracotta
fill 295 280 442 300 280 442 minecraft:white_terracotta
fill 295 280 443 296 280 443 minecraft:black_concrete
fill 295 280 446 295 280 457 minecraft:dark_oak_planks
fill 296 280 417 296 280 427 minecraft:dark_oak_planks
fill 296 280 437 302 280 437 minecraft:white_terracotta
fill 296 280 444 298 280 444 minecraft:white_terracotta
fill 296 280 447 296 280 457 minecraft:dark_oak_planks
fill 297 280 417 297 280 426 minecraft:dark_oak_planks
fill 297 280 431 315 280 431 minecraft:white_terracotta
fill 297 280 443 299 280 443 minecraft:white_terracotta
fill 297 280 445 298 280 445 minecraft:white_terracotta
fill 297 280 448 297 280 457 minecraft:dark_oak_planks
fill 298 280 417 298 280 425 minecraft:dark_oak_planks
fill 298 280 449 298 280 457 minecraft:dark_oak_planks
fill 299 280 417 300 280 424 minecraft:dark_oak_planks
setblock 299 280 427 minecraft:white_terracotta
fill 299 280 444 299 280 445 minecraft:waxed_cut_copper
setblock 299 280 447 minecraft:white_terracotta
fill 299 280 450 300 280 457 minecraft:dark_oak_planks
fill 300 280 426 300 280 427 minecraft:black_concrete
fill 300 280 443 300 280 444 minecraft:waxed_cut_copper
fill 300 280 445 315 280 445 minecraft:white_terracotta
fill 300 280 447 300 280 448 minecraft:black_concrete
fill 301 280 417 305 280 423 minecraft:dark_oak_planks
fill 301 280 426 305 280 427 minecraft:white_terracotta
fill 301 280 442 301 280 443 minecraft:waxed_cut_copper
fill 301 280 444 316 280 444 minecraft:white_terracotta
fill 301 280 447 305 280 448 minecraft:white_terracotta
fill 301 280 451 305 280 457 minecraft:dark_oak_planks
fill 302 280 425 305 280 425 minecraft:white_terracotta
fill 302 280 438 302 280 440 minecraft:white_terracotta
fill 302 280 441 302 280 442 minecraft:waxed_cut_copper
fill 302 280 443 315 280 443 minecraft:white_terracotta
fill 302 280 449 305 280 449 minecraft:white_terracotta
fill 303 280 433 303 280 434 minecraft:white_terracotta
fill 303 280 435 303 280 439 minecraft:ochre_froglight
fill 303 280 440 303 280 441 minecraft:waxed_cut_copper
fill 303 280 442 311 280 442 minecraft:white_terracotta
fill 304 280 433 318 280 433 minecraft:white_terracotta
fill 304 280 434 304 280 435 minecraft:ochre_froglight
fill 304 280 439 304 280 440 minecraft:ochre_froglight
fill 304 280 441 309 280 441 minecraft:white_terracotta
fill 305 280 434 308 280 434 minecraft:ochre_froglight
fill 305 280 440 308 280 440 minecraft:ochre_froglight
fill 306 280 417 323 280 422 minecraft:dark_oak_planks
fill 306 280 425 306 280 426 minecraft:black_concrete
fill 306 280 427 311 280 427 minecraft:white_terracotta
fill 306 280 447 311 280 447 minecraft:white_terracotta
fill 306 280 448 306 280 449 minecraft:black_concrete
fill 306 280 452 323 280 457 minecraft:dark_oak_planks
fill 307 280 423 323 280 423 minecraft:dark_oak_planks
fill 307 280 425 310 280 426 minecraft:white_terracotta
fill 307 280 448 310 280 449 minecraft:white_terracotta
fill 307 280 451 323 280 451 minecraft:dark_oak_planks
fill 308 280 435 309 280 435 minecraft:ochre_froglight
fill 308 280 439 309 280 439 minecraft:ochre_froglight
fill 309 280 434 318 280 434 minecraft:white_terracotta
fill 309 280 436 309 280 438 minecraft:ochre_froglight
fill 309 280 440 310 280 440 minecraft:waxed_cut_copper
fill 310 280 435 316 280 439 minecraft:white_terracotta
fill 310 280 441 311 280 441 minecraft:waxed_cut_copper
setblock 311 280 426 minecraft:white_terracotta
fill 311 280 440 318 280 440 minecraft:white_terracotta
setblock 311 280 448 minecraft:white_terracotta
fill 312 280 424 323 280 424 minecraft:dark_oak_planks
fill 312 280 426 312 280 427 minecraft:black_concrete
fill 312 280 441 318 280 441 minecraft:white_terracotta
setblock 312 280 442 minecraft:waxed_cut_copper
fill 312 280 447 312 280 448 minecraft:black_concrete
fill 312 280 450 323 280 450 minecraft:dark_oak_planks
setblock 313 280 427 minecraft:white_terracotta
fill 313 280 442 317 280 442 minecraft:white_terracotta
setblock 313 280 447 minecraft:white_terracotta
fill 314 280 425 323 280 425 minecraft:dark_oak_planks
fill 314 280 449 323 280 449 minecraft:dark_oak_planks
fill 315 280 426 323 280 426 minecraft:dark_oak_planks
fill 315 280 448 323 280 448 minecraft:dark_oak_planks
fill 316 280 427 323 280 427 minecraft:dark_oak_planks
fill 316 280 431 317 280 431 minecraft:black_concrete
fill 316 280 443 317 280 443 minecraft:black_concrete
fill 316 280 447 323 280 447 minecraft:dark_oak_planks
fill 317 280 428 323 280 428 minecraft:dark_oak_planks
fill 317 280 435 318 280 436 minecraft:white_terracotta
fill 317 280 437 318 280 437 minecraft:black_concrete
fill 317 280 438 318 280 439 minecraft:white_terracotta
fill 317 280 446 323 280 446 minecraft:dark_oak_planks
fill 318 280 429 323 280 429 minecraft:dark_oak_planks
fill 318 280 445 323 280 445 minecraft:dark_oak_planks
fill 319 280 430 323 280 431 minecraft:dark_oak_planks
fill 319 280 443 323 280 444 minecraft:dark_oak_planks
fill 320 280 432 323 280 436 minecraft:dark_oak_planks
fill 320 280 438 323 280 442 minecraft:dark_oak_planks
fill 321 280 437 323 280 437 minecraft:dark_oak_planks
fill 283 284 417 285 300 417 minecraft:waxed_cut_copper
fill 283 284 427 283 300 429 minecraft:waxed_cut_copper
fill 283 284 439 283 300 441 minecraft:waxed_cut_copper
fill 283 284 451 283 300 453 minecraft:waxed_cut_copper
fill 284 284 426 284 285 428 minecraft:waxed_cut_copper
fill 284 284 438 284 285 440 minecraft:waxed_cut_copper
fill 284 284 450 284 285 452 minecraft:waxed_cut_copper
setblock 285 284 419 minecraft:light[level=14]
setblock 285 284 427 minecraft:light[level=14]
setblock 285 284 435 minecraft:light[level=14]
setblock 285 284 443 minecraft:light[level=14]
setblock 285 284 451 minecraft:light[level=14]
fill 288 284 417 288 284 419 minecraft:waxed_copper_block
fill 289 284 457 291 300 457 minecraft:waxed_cut_copper
fill 290 284 456 292 285 456 minecraft:waxed_cut_copper
setblock 293 284 419 minecraft:light[level=14]
setblock 293 284 427 minecraft:light[level=14]
setblock 293 284 435 minecraft:light[level=14]
setblock 293 284 443 minecraft:light[level=14]
setblock 293 284 451 minecraft:light[level=14]
fill 294 284 418 296 285 418 minecraft:waxed_cut_copper
fill 295 284 417 297 300 417 minecraft:waxed_cut_copper
setblock 301 284 419 minecraft:light[level=14]
setblock 301 284 427 minecraft:light[level=14]
setblock 301 284 435 minecraft:light[level=14]
setblock 301 284 443 minecraft:light[level=14]
setblock 301 284 451 minecraft:light[level=14]
fill 301 284 457 303 300 457 minecraft:waxed_cut_copper
fill 302 284 456 304 285 456 minecraft:waxed_cut_copper
fill 306 284 418 308 285 418 minecraft:waxed_cut_copper
fill 307 284 417 309 300 417 minecraft:waxed_cut_copper
setblock 309 284 419 minecraft:light[level=14]
setblock 309 284 427 minecraft:light[level=14]
setblock 309 284 435 minecraft:light[level=14]
setblock 309 284 443 minecraft:light[level=14]
setblock 309 284 451 minecraft:light[level=14]
fill 313 284 457 315 300 457 minecraft:waxed_cut_copper
fill 314 284 456 316 285 456 minecraft:waxed_cut_copper
setblock 317 284 419 minecraft:light[level=14]
setblock 317 284 427 minecraft:light[level=14]
setblock 317 284 435 minecraft:light[level=14]
setblock 317 284 443 minecraft:light[level=14]
setblock 317 284 451 minecraft:light[level=14]
fill 318 284 418 320 285 418 minecraft:waxed_cut_copper
fill 319 284 417 321 300 417 minecraft:waxed_cut_copper
fill 319 284 448 321 300 450 minecraft:waxed_copper_block
fill 322 284 426 322 285 428 minecraft:waxed_cut_copper
fill 322 284 438 322 285 440 minecraft:waxed_cut_copper
fill 322 284 450 322 285 452 minecraft:waxed_cut_copper
fill 323 284 425 323 300 427 minecraft:waxed_cut_copper
fill 323 284 437 323 300 439 minecraft:waxed_cut_copper
fill 323 284 449 323 300 451 minecraft:waxed_cut_copper
fill 283 285 420 283 285 425 minecraft:dark_oak_planks
fill 283 285 432 283 285 437 minecraft:dark_oak_planks
fill 283 285 444 283 285 449 minecraft:dark_oak_planks
fill 283 285 456 283 285 457 minecraft:dark_oak_planks
fill 284 285 457 287 285 457 minecraft:dark_oak_planks
fill 287 285 417 292 285 417 minecraft:dark_oak_planks
fill 294 285 457 299 285 457 minecraft:dark_oak_planks
fill 299 285 417 304 285 417 minecraft:dark_oak_planks
fill 306 285 457 311 285 457 minecraft:dark_oak_planks
fill 310 285 454 310 286 456 minecraft:waxed_copper_block
fill 311 285 417 316 285 417 minecraft:dark_oak_planks
fill 316 285 437 316 299 437 minecraft:waxed_copper_block
fill 318 285 457 323 285 457 minecraft:dark_oak_planks
fill 323 285 417 323 285 422 minecraft:dark_oak_planks
fill 323 285 429 323 285 434 minecraft:dark_oak_planks
fill 323 285 441 323 285 446 minecraft:dark_oak_planks
fill 323 285 453 323 285 456 minecraft:dark_oak_planks
fill 282 286 422 282 291 425 minecraft:ochre_froglight
fill 282 286 434 282 291 437 minecraft:ochre_froglight
fill 282 286 446 282 291 449 minecraft:ochre_froglight
fill 282 286 458 285 291 458 minecraft:ochre_froglight
fill 289 286 416 292 291 416 minecraft:ochre_froglight
fill 294 286 458 297 291 458 minecraft:ochre_froglight
fill 301 286 416 304 291 416 minecraft:ochre_froglight
fill 306 286 458 309 291 458 minecraft:ochre_froglight
fill 313 286 416 316 291 416 minecraft:ochre_froglight
fill 318 286 448 318 286 450 minecraft:waxed_cut_copper
fill 318 286 458 321 291 458 minecraft:ochre_froglight
fill 319 286 447 321 286 447 minecraft:waxed_cut_copper
fill 319 286 451 321 286 451 minecraft:waxed_cut_copper
fill 322 286 448 322 286 450 minecraft:waxed_cut_copper
fill 324 286 417 324 291 420 minecraft:ochre_froglight
fill 324 286 429 324 291 432 minecraft:ochre_froglight
fill 324 286 441 324 291 444 minecraft:ochre_froglight
fill 324 286 453 324 291 456 minecraft:ochre_froglight
fill 282 292 422 282 307 422 minecraft:dark_oak_planks
fill 282 292 423 282 292 424 minecraft:ochre_froglight
fill 282 292 425 282 307 425 minecraft:dark_oak_planks
fill 282 292 434 282 307 434 minecraft:dark_oak_planks
fill 282 292 435 282 292 436 minecraft:ochre_froglight
fill 282 292 437 282 307 437 minecraft:dark_oak_planks
fill 282 292 446 282 307 446 minecraft:dark_oak_planks
fill 282 292 447 282 292 448 minecraft:ochre_froglight
fill 282 292 449 282 307 449 minecraft:dark_oak_planks
fill 282 292 458 282 307 458 minecraft:dark_oak_planks
fill 283 292 458 284 292 458 minecraft:ochre_froglight
setblock 285 292 419 minecraft:light[level=14]
setblock 285 292 427 minecraft:light[level=14]
setblock 285 292 435 minecraft:light[level=14]
setblock 285 292 443 minecraft:light[level=14]
setblock 285 292 451 minecraft:light[level=14]
fill 285 292 458 285 307 458 minecraft:dark_oak_planks
fill 289 292 416 289 307 416 minecraft:dark_oak_planks
fill 290 292 416 291 292 416 minecraft:ochre_froglight
fill 292 292 416 292 307 416 minecraft:dark_oak_planks
setblock 293 292 419 minecraft:light[level=14]
setblock 293 292 427 minecraft:light[level=14]
setblock 293 292 435 minecraft:light[level=14]
setblock 293 292 443 minecraft:light[level=14]
setblock 293 292 451 minecraft:light[level=14]
fill 294 292 458 294 307 458 minecraft:dark_oak_planks
fill 295 292 458 296 292 458 minecraft:ochre_froglight
fill 297 292 458 297 307 458 minecraft:dark_oak_planks
fill 301 292 416 301 307 416 minecraft:dark_oak_planks
setblock 301 292 419 minecraft:light[level=14]
setblock 301 292 427 minecraft:light[level=14]
setblock 301 292 435 minecraft:light[level=14]
setblock 301 292 443 minecraft:light[level=14]
setblock 301 292 451 minecraft:light[level=14]
fill 302 292 416 303 292 416 minecraft:ochre_froglight
fill 304 292 416 304 307 416 minecraft:dark_oak_planks
fill 306 292 458 306 307 458 minecraft:dark_oak_planks
fill 307 292 458 308 292 458 minecraft:ochre_froglight
setblock 309 292 419 minecraft:light[level=14]
setblock 309 292 427 minecraft:light[level=14]
setblock 309 292 435 minecraft:light[level=14]
setblock 309 292 443 minecraft:light[level=14]
setblock 309 292 451 minecraft:light[level=14]
fill 309 292 458 309 307 458 minecraft:dark_oak_planks
fill 313 292 416 313 307 416 minecraft:dark_oak_planks
fill 314 292 416 315 292 416 minecraft:ochre_froglight
fill 316 292 416 316 307 416 minecraft:dark_oak_planks
setblock 317 292 419 minecraft:light[level=14]
setblock 317 292 427 minecraft:light[level=14]
setblock 317 292 435 minecraft:light[level=14]
setblock 317 292 443 minecraft:light[level=14]
setblock 317 292 451 minecraft:light[level=14]
fill 318 292 458 318 307 458 minecraft:dark_oak_planks
fill 319 292 458 320 292 458 minecraft:ochre_froglight
fill 321 292 458 321 307 458 minecraft:dark_oak_planks
fill 322 292 448 322 293 450 minecraft:waxed_copper_block
fill 323 292 448 323 293 448 minecraft:waxed_copper_block
fill 324 292 417 324 307 417 minecraft:dark_oak_planks
fill 324 292 418 324 292 419 minecraft:ochre_froglight
fill 324 292 420 324 307 420 minecraft:dark_oak_planks
fill 324 292 429 324 307 429 minecraft:dark_oak_planks
fill 324 292 430 324 292 431 minecraft:ochre_froglight
fill 324 292 432 324 307 432 minecraft:dark_oak_planks
fill 324 292 441 324 307 441 minecraft:dark_oak_planks
fill 324 292 442 324 292 443 minecraft:ochre_froglight
fill 324 292 444 324 307 444 minecraft:dark_oak_planks
fill 324 292 453 324 307 453 minecraft:dark_oak_planks
fill 324 292 454 324 292 455 minecraft:ochre_froglight
fill 324 292 456 324 307 456 minecraft:dark_oak_planks
fill 282 293 423 282 307 424 minecraft:dark_oak_planks
fill 282 293 435 282 307 436 minecraft:dark_oak_planks
fill 282 293 447 282 307 448 minecraft:dark_oak_planks
fill 283 293 458 284 307 458 minecraft:dark_oak_planks
fill 290 293 416 291 307 416 minecraft:dark_oak_planks
fill 295 293 458 296 307 458 minecraft:dark_oak_planks
fill 302 293 416 303 307 416 minecraft:dark_oak_planks
fill 307 293 458 308 307 458 minecraft:dark_oak_planks
fill 314 293 416 315 307 416 minecraft:dark_oak_planks
setblock 318 293 449 minecraft:ochre_froglight
fill 319 293 458 320 307 458 minecraft:dark_oak_planks
fill 324 293 418 324 307 419 minecraft:dark_oak_planks
fill 324 293 430 324 307 431 minecraft:dark_oak_planks
fill 324 293 442 324 307 443 minecraft:dark_oak_planks
fill 324 293 454 324 307 455 minecraft:dark_oak_planks
fill 318 294 448 318 294 450 minecraft:waxed_cut_copper
fill 319 294 447 321 294 447 minecraft:waxed_cut_copper
fill 319 294 451 321 294 451 minecraft:waxed_cut_copper
fill 322 294 448 322 294 450 minecraft:waxed_cut_copper
fill 284 300 426 284 300 428 minecraft:waxed_cut_copper
fill 284 300 438 284 300 440 minecraft:waxed_cut_copper
fill 284 300 450 284 300 452 minecraft:waxed_cut_copper
setblock 285 300 419 minecraft:light[level=14]
setblock 285 300 427 minecraft:light[level=14]
setblock 285 300 435 minecraft:light[level=14]
setblock 285 300 443 minecraft:light[level=14]
setblock 285 300 451 minecraft:light[level=14]
fill 290 300 456 292 300 456 minecraft:waxed_cut_copper
setblock 293 300 419 minecraft:light[level=14]
setblock 293 300 427 minecraft:light[level=14]
setblock 293 300 435 minecraft:light[level=14]
setblock 293 300 443 minecraft:light[level=14]
setblock 293 300 451 minecraft:light[level=14]
fill 294 300 418 296 300 418 minecraft:waxed_cut_copper
setblock 301 300 419 minecraft:light[level=14]
setblock 301 300 427 minecraft:light[level=14]
setblock 301 300 435 minecraft:light[level=14]
setblock 301 300 443 minecraft:light[level=14]
setblock 301 300 451 minecraft:light[level=14]
fill 302 300 456 304 300 456 minecraft:waxed_cut_copper
fill 306 300 418 308 300 418 minecraft:waxed_cut_copper
setblock 309 300 419 minecraft:light[level=14]
setblock 309 300 427 minecraft:light[level=14]
setblock 309 300 435 minecraft:light[level=14]
setblock 309 300 443 minecraft:light[level=14]
setblock 309 300 451 minecraft:light[level=14]
fill 314 300 456 316 300 456 minecraft:waxed_cut_copper
setblock 317 300 419 minecraft:light[level=14]
setblock 317 300 427 minecraft:light[level=14]
setblock 317 300 435 minecraft:light[level=14]
setblock 317 300 443 minecraft:light[level=14]
setblock 317 300 451 minecraft:light[level=14]
fill 318 300 418 320 300 418 minecraft:waxed_cut_copper
fill 322 300 426 322 300 428 minecraft:waxed_cut_copper
fill 322 300 438 322 300 440 minecraft:waxed_cut_copper
fill 322 300 450 322 300 452 minecraft:waxed_cut_copper
