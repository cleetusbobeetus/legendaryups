setblock 82 136 631 minecraft:light[level=14]
setblock 82 136 639 minecraft:light[level=14]
fill 82 136 646 82 143 646 minecraft:black_concrete
fill 86 136 604 86 143 604 minecraft:black_concrete
fill 89 136 609 89 143 609 minecraft:black_concrete
fill 89 136 617 89 143 617 minecraft:black_concrete
fill 89 136 625 89 143 625 minecraft:black_concrete
fill 89 136 633 89 143 633 minecraft:black_concrete
fill 89 136 641 89 143 641 minecraft:black_concrete
setblock 73 137 608 minecraft:magenta_concrete
setblock 73 137 610 minecraft:magenta_concrete
fill 74 137 611 76 137 611 minecraft:magenta_concrete
setblock 77 137 608 minecraft:magenta_concrete
setblock 77 137 610 minecraft:magenta_concrete
fill 86 137 614 86 140 614 minecraft:magenta_concrete
fill 72 138 605 72 138 613 minecraft:light_gray_concrete
fill 73 138 606 78 138 613 minecraft:light_gray_concrete
fill 75 138 605 78 138 605 minecraft:light_gray_concrete
fill 84 138 614 84 140 614 minecraft:magenta_concrete
fill 85 138 613 86 140 613 minecraft:magenta_concrete
fill 85 138 615 86 140 615 minecraft:magenta_concrete
setblock 72 139 605 minecraft:sea_lantern
fill 72 139 606 72 162 606 minecraft:light_gray_concrete
setblock 72 139 607 minecraft:sea_lantern
fill 72 139 608 72 162 608 minecraft:light_gray_concrete
setblock 72 139 609 minecraft:sea_lantern
fill 72 139 610 72 162 610 minecraft:light_gray_concrete
setblock 72 139 611 minecraft:sea_lantern
fill 72 139 612 72 162 612 minecraft:light_gray_concrete
setblock 72 139 613 minecraft:sea_lantern
fill 73 139 605 73 162 605 minecraft:light_gray_concrete
setblock 73 139 606 minecraft:sea_lantern
fill 73 139 607 73 162 607 minecraft:light_gray_concrete
setblock 73 139 608 minecraft:sea_lantern
fill 73 139 609 73 162 609 minecraft:light_gray_concrete
setblock 73 139 610 minecraft:sea_lantern
fill 73 139 611 73 162 611 minecraft:light_gray_concrete
setblock 73 139 612 minecraft:sea_lantern
fill 73 139 613 73 162 613 minecraft:light_gray_concrete
setblock 74 139 605 minecraft:sea_lantern
fill 74 139 606 74 162 606 minecraft:light_gray_concrete
setblock 74 139 607 minecraft:sea_lantern
fill 74 139 608 74 162 608 minecraft:light_gray_concrete
setblock 74 139 609 minecraft:sea_lantern
fill 74 139 610 74 162 610 minecraft:light_gray_concrete
setblock 74 139 611 minecraft:sea_lantern
fill 74 139 612 74 162 612 minecraft:light_gray_concrete
setblock 74 139 613 minecraft:sea_lantern
fill 75 139 605 75 162 605 minecraft:light_gray_concrete
setblock 75 139 606 minecraft:sea_lantern
fill 75 139 607 75 162 607 minecraft:light_gray_concrete
setblock 75 139 608 minecraft:sea_lantern
fill 75 139 609 75 162 609 minecraft:light_gray_concrete
setblock 75 139 610 minecraft:sea_lantern
fill 75 139 611 75 162 611 minecraft:light_gray_concrete
setblock 75 139 612 minecraft:sea_lantern
fill 75 139 613 75 162 613 minecraft:light_gray_concrete
setblock 76 139 605 minecraft:sea_lantern
fill 76 139 606 76 162 606 minecraft:light_gray_concrete
setblock 76 139 607 minecraft:sea_lantern
fill 76 139 608 76 162 608 minecraft:light_gray_concrete
setblock 76 139 609 minecraft:sea_lantern
fill 76 139 610 76 162 610 minecraft:light_gray_concrete
setblock 76 139 611 minecraft:sea_lantern
fill 76 139 612 76 162 612 minecraft:light_gray_concrete
setblock 76 139 613 minecraft:sea_lantern
fill 77 139 605 77 162 605 minecraft:light_gray_concrete
setblock 77 139 606 minecraft:sea_lantern
fill 77 139 607 77 162 607 minecraft:light_gray_concrete
setblock 77 139 608 minecraft:sea_lantern
fill 77 139 609 77 162 609 minecraft:light_gray_concrete
setblock 77 139 610 minecraft:sea_lantern
fill 77 139 611 77 162 611 minecraft:light_gray_concrete
setblock 77 139 612 minecraft:sea_lantern
fill 77 139 613 77 162 613 minecraft:light_gray_concrete
setblock 78 139 605 minecraft:sea_lantern
fill 78 139 606 78 162 606 minecraft:light_gray_concrete
setblock 78 139 607 minecraft:sea_lantern
fill 78 139 608 78 162 608 minecraft:light_gray_concrete
setblock 78 139 609 minecraft:sea_lantern
fill 78 139 610 78 162 610 minecraft:light_gray_concrete
setblock 78 139 611 minecraft:sea_lantern
fill 78 139 612 78 162 612 minecraft:light_gray_concrete
setblock 78 139 613 minecraft:sea_lantern
fill 48 140 605 48 141 610 minecraft:light_gray_concrete
fill 48 140 613 49 140 618 minecraft:light_gray_concrete
fill 48 140 621 49 140 626 minecraft:light_gray_concrete
fill 48 140 629 49 140 634 minecraft:light_gray_concrete
fill 48 140 637 49 140 642 minecraft:light_gray_concrete
fill 48 140 645 53 141 645 minecraft:light_gray_concrete
fill 49 140 606 49 140 612 minecraft:light_gray_concrete
fill 49 140 619 49 140 620 minecraft:light_gray_concrete
fill 49 140 627 49 140 628 minecraft:light_gray_concrete
fill 49 140 635 49 140 636 minecraft:light_gray_concrete
fill 49 140 643 49 140 644 minecraft:light_gray_concrete
fill 50 140 606 71 140 606 minecraft:light_gray_concrete
fill 50 140 644 88 140 644 minecraft:light_gray_concrete
fill 51 140 605 56 141 605 minecraft:light_gray_concrete
fill 56 140 645 61 141 645 minecraft:light_gray_concrete
fill 59 140 605 64 141 605 minecraft:light_gray_concrete
fill 64 140 645 69 141 645 minecraft:light_gray_concrete
fill 67 140 605 72 141 605 minecraft:light_gray_concrete
fill 72 140 607 72 141 607 minecraft:light_gray_concrete
fill 72 140 609 72 141 609 minecraft:light_gray_concrete
fill 72 140 611 72 141 611 minecraft:light_gray_concrete
fill 72 140 613 72 141 613 minecraft:light_gray_concrete
fill 72 140 645 77 141 645 minecraft:light_gray_concrete
fill 73 140 606 73 141 606 minecraft:light_gray_concrete
fill 73 140 608 73 141 608 minecraft:light_gray_concrete
fill 73 140 610 73 141 610 minecraft:light_gray_concrete
fill 73 140 612 73 141 612 minecraft:light_gray_concrete
fill 74 140 605 74 141 605 minecraft:light_gray_concrete
fill 74 140 607 74 141 607 minecraft:light_gray_concrete
fill 74 140 609 74 141 609 minecraft:light_gray_concrete
fill 74 140 611 74 141 611 minecraft:light_gray_concrete
fill 74 140 613 74 141 613 minecraft:light_gray_concrete
fill 75 140 606 75 141 606 minecraft:light_gray_concrete
fill 75 140 608 75 141 608 minecraft:light_gray_concrete
fill 75 140 610 75 141 610 minecraft:light_gray_concrete
fill 75 140 612 75 141 612 minecraft:light_gray_concrete
fill 76 140 605 76 141 605 minecraft:light_gray_concrete
fill 76 140 607 76 141 607 minecraft:light_gray_concrete
fill 76 140 609 76 141 609 minecraft:light_gray_concrete
fill 76 140 611 76 141 611 minecraft:light_gray_concrete
fill 76 140 613 76 141 613 minecraft:light_gray_concrete
fill 77 140 606 77 141 606 minecraft:light_gray_concrete
fill 77 140 608 77 141 608 minecraft:light_gray_concrete
fill 77 140 610 77 141 610 minecraft:light_gray_concrete
fill 77 140 612 77 141 612 minecraft:light_gray_concrete
fill 78 140 605 80 141 605 minecraft:light_gray_concrete
fill 78 140 607 78 141 607 minecraft:light_gray_concrete
fill 78 140 609 78 141 609 minecraft:light_gray_concrete
fill 78 140 611 78 141 611 minecraft:light_gray_concrete
fill 78 140 613 78 141 613 minecraft:light_gray_concrete
fill 79 140 606 87 140 606 minecraft:light_gray_concrete
fill 80 140 645 85 141 645 minecraft:light_gray_concrete
fill 83 140 605 88 141 605 minecraft:light_gray_concrete
setblock 84 140 613 minecraft:magenta_concrete
setblock 84 140 615 minecraft:magenta_concrete
fill 87 140 607 87 140 643 minecraft:light_gray_concrete
fill 88 140 608 88 141 613 minecraft:light_gray_concrete
fill 88 140 616 88 141 621 minecraft:light_gray_concrete
fill 88 140 624 88 141 629 minecraft:light_gray_concrete
fill 88 140 632 88 141 637 minecraft:light_gray_concrete
fill 88 140 640 88 141 643 minecraft:light_gray_concrete
fill 88 140 645 88 141 645 minecraft:light_gray_concrete
fill 48 141 613 48 141 618 minecraft:light_gray_concrete
fill 48 141 621 48 141 626 minecraft:light_gray_concrete
fill 48 141 629 48 141 634 minecraft:light_gray_concrete
fill 48 141 637 48 141 642 minecraft:light_gray_concrete
fill 83 141 608 87 141 620 minecraft:light_gray_concrete
setblock 88 141 644 minecraft:light_gray_concrete
fill 52 142 626 52 147 626 minecraft:magenta_concrete
setblock 72 142 605 minecraft:sea_lantern
setblock 72 142 607 minecraft:sea_lantern
setblock 72 142 609 minecraft:sea_lantern
setblock 72 142 611 minecraft:sea_lantern
setblock 72 142 613 minecraft:sea_lantern
setblock 73 142 606 minecraft:sea_lantern
setblock 73 142 608 minecraft:sea_lantern
setblock 73 142 610 minecraft:sea_lantern
setblock 73 142 612 minecraft:sea_lantern
setblock 74 142 605 minecraft:sea_lantern
setblock 74 142 607 minecraft:sea_lantern
setblock 74 142 609 minecraft:sea_lantern
setblock 74 142 611 minecraft:sea_lantern
setblock 74 142 613 minecraft:sea_lantern
setblock 75 142 606 minecraft:sea_lantern
setblock 75 142 608 minecraft:sea_lantern
setblock 75 142 610 minecraft:sea_lantern
setblock 75 142 612 minecraft:sea_lantern
setblock 76 142 605 minecraft:sea_lantern
setblock 76 142 607 minecraft:sea_lantern
setblock 76 142 609 minecraft:sea_lantern
setblock 76 142 611 minecraft:sea_lantern
setblock 76 142 613 minecraft:sea_lantern
setblock 77 142 606 minecraft:sea_lantern
setblock 77 142 608 minecraft:sea_lantern
setblock 77 142 610 minecraft:sea_lantern
setblock 77 142 612 minecraft:sea_lantern
setblock 78 142 605 minecraft:sea_lantern
setblock 78 142 607 minecraft:sea_lantern
setblock 78 142 609 minecraft:sea_lantern
setblock 78 142 611 minecraft:sea_lantern
setblock 78 142 613 minecraft:sea_lantern
setblock 83 142 608 minecraft:sea_lantern
fill 83 142 609 83 162 609 minecraft:light_gray_concrete
setblock 83 142 610 minecraft:sea_lantern
fill 83 142 611 83 162 611 minecraft:light_gray_concrete
setblock 83 142 612 minecraft:sea_lantern
fill 83 142 613 83 162 613 minecraft:light_gray_concrete
setblock 83 142 614 minecraft:sea_lantern
fill 83 142 615 83 162 615 minecraft:light_gray_concrete
setblock 83 142 616 minecraft:sea_lantern
fill 83 142 617 83 162 617 minecraft:light_gray_concrete
setblock 83 142 618 minecraft:sea_lantern
fill 83 142 619 83 162 619 minecraft:light_gray_concrete
setblock 83 142 620 minecraft:sea_lantern
fill 84 142 608 84 162 608 minecraft:light_gray_concrete
setblock 84 142 609 minecraft:sea_lantern
fill 84 142 610 84 162 610 minecraft:light_gray_concrete
setblock 84 142 611 minecraft:sea_lantern
fill 84 142 612 84 162 612 minecraft:light_gray_concrete
setblock 84 142 613 minecraft:sea_lantern
fill 84 142 614 84 162 614 minecraft:light_gray_concrete
setblock 84 142 615 minecraft:sea_lantern
fill 84 142 616 84 162 616 minecraft:light_gray_concrete
setblock 84 142 617 minecraft:sea_lantern
fill 84 142 618 84 162 618 minecraft:light_gray_concrete
setblock 84 142 619 minecraft:sea_lantern
fill 84 142 620 84 162 620 minecraft:light_gray_concrete
setblock 85 142 608 minecraft:sea_lantern
fill 85 142 609 85 162 609 minecraft:light_gray_concrete
setblock 85 142 610 minecraft:sea_lantern
fill 85 142 611 85 162 611 minecraft:light_gray_concrete
setblock 85 142 612 minecraft:sea_lantern
fill 85 142 613 85 162 613 minecraft:light_gray_concrete
setblock 85 142 614 minecraft:sea_lantern
fill 85 142 615 85 162 615 minecraft:light_gray_concrete
setblock 85 142 616 minecraft:sea_lantern
fill 85 142 617 85 162 617 minecraft:light_gray_concrete
setblock 85 142 618 minecraft:sea_lantern
fill 85 142 619 85 162 619 minecraft:light_gray_concrete
setblock 85 142 620 minecraft:sea_lantern
fill 86 142 608 86 162 608 minecraft:light_gray_concrete
setblock 86 142 609 minecraft:sea_lantern
fill 86 142 610 86 162 610 minecraft:light_gray_concrete
setblock 86 142 611 minecraft:sea_lantern
fill 86 142 612 86 162 612 minecraft:light_gray_concrete
setblock 86 142 613 minecraft:sea_lantern
fill 86 142 614 86 162 614 minecraft:light_gray_concrete
setblock 86 142 615 minecraft:sea_lantern
fill 86 142 616 86 162 616 minecraft:light_gray_concrete
setblock 86 142 617 minecraft:sea_lantern
fill 86 142 618 86 162 618 minecraft:light_gray_concrete
setblock 86 142 619 minecraft:sea_lantern
fill 86 142 620 86 162 620 minecraft:light_gray_concrete
setblock 87 142 608 minecraft:sea_lantern
fill 87 142 609 87 162 609 minecraft:light_gray_concrete
setblock 87 142 610 minecraft:sea_lantern
fill 87 142 611 87 162 611 minecraft:light_gray_concrete
setblock 87 142 612 minecraft:sea_lantern
fill 87 142 613 87 162 613 minecraft:light_gray_concrete
setblock 87 142 614 minecraft:sea_lantern
fill 87 142 615 87 162 615 minecraft:light_gray_concrete
setblock 87 142 616 minecraft:sea_lantern
fill 87 142 617 87 162 617 minecraft:light_gray_concrete
setblock 87 142 618 minecraft:sea_lantern
fill 87 142 619 87 162 619 minecraft:light_gray_concrete
setblock 87 142 620 minecraft:sea_lantern
fill 88 142 608 88 162 608 minecraft:light_gray_concrete
setblock 88 142 609 minecraft:sea_lantern
fill 88 142 610 88 162 610 minecraft:light_gray_concrete
setblock 88 142 611 minecraft:sea_lantern
fill 88 142 612 88 162 612 minecraft:light_gray_concrete
setblock 88 142 613 minecraft:sea_lantern
fill 88 142 614 88 162 614 minecraft:light_gray_concrete
setblock 88 142 615 minecraft:sea_lantern
fill 88 142 616 88 162 616 minecraft:light_gray_concrete
setblock 88 142 617 minecraft:sea_lantern
fill 88 142 618 88 162 618 minecraft:light_gray_concrete
setblock 88 142 619 minecraft:sea_lantern
fill 88 142 620 88 162 620 minecraft:light_gray_concrete
fill 52 143 625 52 147 625 minecraft:magenta_concrete
fill 52 143 627 52 147 627 minecraft:magenta_concrete
fill 53 143 626 53 147 626 minecraft:magenta_concrete
fill 72 143 605 72 144 605 minecraft:light_gray_concrete
fill 72 143 607 72 144 607 minecraft:light_gray_concrete
fill 72 143 609 72 144 609 minecraft:light_gray_concrete
fill 72 143 611 72 144 611 minecraft:light_gray_concrete
fill 72 143 613 72 144 613 minecraft:light_gray_concrete
fill 73 143 606 73 144 606 minecraft:light_gray_concrete
fill 73 143 608 73 144 608 minecraft:light_gray_concrete
fill 73 143 610 73 144 610 minecraft:light_gray_concrete
fill 73 143 612 73 144 612 minecraft:light_gray_concrete
fill 74 143 605 74 144 605 minecraft:light_gray_concrete
fill 74 143 607 74 144 607 minecraft:light_gray_concrete
fill 74 143 609 74 144 609 minecraft:light_gray_concrete
fill 74 143 611 74 144 611 minecraft:light_gray_concrete
fill 74 143 613 74 144 613 minecraft:light_gray_concrete
fill 75 143 606 75 144 606 minecraft:light_gray_concrete
fill 75 143 608 75 144 608 minecraft:light_gray_concrete
fill 75 143 610 75 144 610 minecraft:light_gray_concrete
fill 75 143 612 75 144 612 minecraft:light_gray_concrete
fill 76 143 605 76 144 605 minecraft:light_gray_concrete
fill 76 143 607 76 144 607 minecraft:light_gray_concrete
fill 76 143 609 76 144 609 minecraft:light_gray_concrete
fill 76 143 611 76 144 611 minecraft:light_gray_concrete
fill 76 143 613 76 144 613 minecraft:light_gray_concrete
fill 77 143 606 77 144 606 minecraft:light_gray_concrete
fill 77 143 608 77 144 608 minecraft:light_gray_concrete
fill 77 143 610 77 144 610 minecraft:light_gray_concrete
fill 77 143 612 77 144 612 minecraft:light_gray_concrete
fill 78 143 605 78 144 605 minecraft:light_gray_concrete
fill 78 143 607 78 144 607 minecraft:light_gray_concrete
fill 78 143 609 78 144 609 minecraft:light_gray_concrete
fill 78 143 611 78 144 611 minecraft:light_gray_concrete
fill 78 143 613 78 144 613 minecraft:light_gray_concrete
fill 83 143 608 83 144 608 minecraft:light_gray_concrete
fill 83 143 610 83 144 610 minecraft:light_gray_concrete
fill 83 143 612 83 144 612 minecraft:light_gray_concrete
fill 83 143 614 83 144 614 minecraft:light_gray_concrete
fill 83 143 616 83 144 616 minecraft:light_gray_concrete
fill 83 143 618 83 144 618 minecraft:light_gray_concrete
fill 83 143 620 83 144 620 minecraft:light_gray_concrete
fill 84 143 609 84 144 609 minecraft:light_gray_concrete
fill 84 143 611 84 144 611 minecraft:light_gray_concrete
fill 84 143 613 84 144 613 minecraft:light_gray_concrete
fill 84 143 615 84 144 615 minecraft:light_gray_concrete
fill 84 143 617 84 144 617 minecraft:light_gray_concrete
fill 84 143 619 84 144 619 minecraft:light_gray_concrete
fill 85 143 608 85 144 608 minecraft:light_gray_concrete
fill 85 143 610 85 144 610 minecraft:light_gray_concrete
fill 85 143 612 85 144 612 minecraft:light_gray_concrete
fill 85 143 614 85 144 614 minecraft:light_gray_concrete
fill 85 143 616 85 144 616 minecraft:light_gray_concrete
fill 85 143 618 85 144 618 minecraft:light_gray_concrete
fill 85 143 620 85 144 620 minecraft:light_gray_concrete
fill 86 143 609 86 144 609 minecraft:light_gray_concrete
fill 86 143 611 86 144 611 minecraft:light_gray_concrete
fill 86 143 613 86 144 613 minecraft:light_gray_concrete
fill 86 143 615 86 144 615 minecraft:light_gray_concrete
fill 86 143 617 86 144 617 minecraft:light_gray_concrete
fill 86 143 619 86 144 619 minecraft:light_gray_concrete
fill 87 143 608 87 144 608 minecraft:light_gray_concrete
fill 87 143 610 87 144 610 minecraft:light_gray_concrete
fill 87 143 612 87 144 612 minecraft:light_gray_concrete
fill 87 143 614 87 144 614 minecraft:light_gray_concrete
fill 87 143 616 87 144 616 minecraft:light_gray_concrete
fill 87 143 618 87 144 618 minecraft:light_gray_concrete
fill 87 143 620 87 144 620 minecraft:light_gray_concrete
fill 88 143 609 88 144 609 minecraft:light_gray_concrete
fill 88 143 611 88 144 611 minecraft:light_gray_concrete
fill 88 143 613 88 144 613 minecraft:light_gray_concrete
fill 88 143 615 88 144 615 minecraft:light_gray_concrete
fill 88 143 617 88 144 617 minecraft:light_gray_concrete
fill 88 143 619 88 144 619 minecraft:light_gray_concrete
fill 47 144 609 47 149 609 minecraft:sea_lantern
fill 47 144 617 47 149 617 minecraft:sea_lantern
fill 47 144 625 47 149 625 minecraft:sea_lantern
fill 47 144 633 47 149 633 minecraft:sea_lantern
fill 47 144 641 47 149 641 minecraft:sea_lantern
setblock 50 144 607 minecraft:light[level=14]
setblock 50 144 615 minecraft:light[level=14]
setblock 50 144 623 minecraft:light[level=14]
setblock 50 144 631 minecraft:light[level=14]
setblock 50 144 639 minecraft:light[level=14]
fill 50 144 646 50 149 646 minecraft:sea_lantern
fill 51 144 625 51 147 627 minecraft:magenta_concrete
fill 53 144 625 53 147 625 minecraft:magenta_concrete
fill 53 144 627 53 147 627 minecraft:magenta_concrete
fill 54 144 604 54 149 604 minecraft:sea_lantern
fill 54 144 626 54 147 626 minecraft:magenta_concrete
setblock 58 144 607 minecraft:light[level=14]
setblock 58 144 615 minecraft:light[level=14]
setblock 58 144 623 minecraft:light[level=14]
setblock 58 144 631 minecraft:light[level=14]
setblock 58 144 639 minecraft:light[level=14]
fill 58 144 646 58 149 646 minecraft:sea_lantern
fill 62 144 604 62 149 604 minecraft:sea_lantern
setblock 66 144 607 minecraft:light[level=14]
setblock 66 144 615 minecraft:light[level=14]
setblock 66 144 623 minecraft:light[level=14]
setblock 66 144 631 minecraft:light[level=14]
setblock 66 144 639 minecraft:light[level=14]
fill 66 144 646 66 149 646 minecraft:sea_lantern
fill 70 144 604 70 149 604 minecraft:sea_lantern
setblock 74 144 615 minecraft:light[level=14]
setblock 74 144 623 minecraft:light[level=14]
setblock 74 144 631 minecraft:light[level=14]
setblock 74 144 639 minecraft:light[level=14]
fill 74 144 646 74 149 646 minecraft:sea_lantern
fill 78 144 604 78 149 604 minecraft:sea_lantern
setblock 82 144 607 minecraft:light[level=14]
setblock 82 144 615 minecraft:light[level=14]
setblock 82 144 623 minecraft:light[level=14]
setblock 82 144 631 minecraft:light[level=14]
setblock 82 144 639 minecraft:light[level=14]
fill 82 144 646 82 149 646 minecraft:sea_lantern
fill 86 144 604 86 149 604 minecraft:sea_lantern
fill 89 144 609 89 149 609 minecraft:sea_lantern
fill 89 144 617 89 149 617 minecraft:sea_lantern
fill 89 144 625 89 149 625 minecraft:sea_lantern
fill 89 144 633 89 149 633 minecraft:sea_lantern
fill 89 144 641 89 149 641 minecraft:sea_lantern
fill 50 145 625 50 147 627 minecraft:magenta_concrete
fill 51 145 624 53 147 624 minecraft:magenta_concrete
fill 51 145 628 53 147 628 minecraft:magenta_concrete
fill 54 145 625 54 147 625 minecraft:magenta_concrete
fill 54 145 627 54 147 627 minecraft:magenta_concrete
fill 62 145 612 63 146 613 minecraft:magenta_concrete
setblock 72 145 605 minecraft:sea_lantern
setblock 72 145 607 minecraft:sea_lantern
setblock 72 145 609 minecraft:sea_lantern
setblock 72 145 611 minecraft:sea_lantern
setblock 72 145 613 minecraft:sea_lantern
setblock 73 145 606 minecraft:sea_lantern
setblock 73 145 608 minecraft:sea_lantern
setblock 73 145 610 minecraft:sea_lantern
setblock 73 145 612 minecraft:sea_lantern
setblock 74 145 605 minecraft:sea_lantern
setblock 74 145 607 minecraft:sea_lantern
setblock 74 145 609 minecraft:sea_lantern
setblock 74 145 611 minecraft:sea_lantern
setblock 74 145 613 minecraft:sea_lantern
setblock 75 145 606 minecraft:sea_lantern
setblock 75 145 608 minecraft:sea_lantern
setblock 75 145 610 minecraft:sea_lantern
setblock 75 145 612 minecraft:sea_lantern
setblock 76 145 605 minecraft:sea_lantern
setblock 76 145 607 minecraft:sea_lantern
setblock 76 145 609 minecraft:sea_lantern
setblock 76 145 611 minecraft:sea_lantern
setblock 76 145 613 minecraft:sea_lantern
setblock 77 145 606 minecraft:sea_lantern
setblock 77 145 608 minecraft:sea_lantern
setblock 77 145 610 minecraft:sea_lantern
setblock 77 145 612 minecraft:sea_lantern
setblock 78 145 605 minecraft:sea_lantern
setblock 78 145 607 minecraft:sea_lantern
setblock 78 145 609 minecraft:sea_lantern
setblock 78 145 611 minecraft:sea_lantern
setblock 78 145 613 minecraft:sea_lantern
setblock 83 145 608 minecraft:sea_lantern
setblock 83 145 610 minecraft:sea_lantern
setblock 83 145 612 minecraft:sea_lantern
setblock 83 145 614 minecraft:sea_lantern
setblock 83 145 616 minecraft:sea_lantern
setblock 83 145 618 minecraft:sea_lantern
setblock 83 145 620 minecraft:sea_lantern
setblock 84 145 609 minecraft:sea_lantern
setblock 84 145 611 minecraft:sea_lantern
setblock 84 145 613 minecraft:sea_lantern
setblock 84 145 615 minecraft:sea_lantern
setblock 84 145 617 minecraft:sea_lantern
setblock 84 145 619 minecraft:sea_lantern
setblock 85 145 608 minecraft:sea_lantern
setblock 85 145 610 minecraft:sea_lantern
setblock 85 145 612 minecraft:sea_lantern
setblock 85 145 614 minecraft:sea_lantern
setblock 85 145 616 minecraft:sea_lantern
setblock 85 145 618 minecraft:sea_lantern
setblock 85 145 620 minecraft:sea_lantern
setblock 86 145 609 minecraft:sea_lantern
setblock 86 145 611 minecraft:sea_lantern
setblock 86 145 613 minecraft:sea_lantern
setblock 86 145 615 minecraft:sea_lantern
setblock 86 145 617 minecraft:sea_lantern
setblock 86 145 619 minecraft:sea_lantern
setblock 87 145 608 minecraft:sea_lantern
setblock 87 145 610 minecraft:sea_lantern
setblock 87 145 612 minecraft:sea_lantern
setblock 87 145 614 minecraft:sea_lantern
setblock 87 145 616 minecraft:sea_lantern
setblock 87 145 618 minecraft:sea_lantern
setblock 87 145 620 minecraft:sea_lantern
setblock 88 145 609 minecraft:sea_lantern
setblock 88 145 611 minecraft:sea_lantern
setblock 88 145 613 minecraft:sea_lantern
setblock 88 145 615 minecraft:sea_lantern
setblock 88 145 617 minecraft:sea_lantern
setblock 88 145 619 minecraft:sea_lantern
fill 49 146 626 49 147 626 minecraft:magenta_concrete
fill 50 146 624 50 147 624 minecraft:magenta_concrete
fill 50 146 628 50 147 628 minecraft:magenta_concrete
fill 51 146 623 53 147 623 minecraft:magenta_concrete
fill 51 146 629 53 147 629 minecraft:magenta_concrete
fill 54 146 624 54 147 624 minecraft:magenta_concrete
fill 54 146 628 54 147 628 minecraft:magenta_concrete
fill 55 146 625 55 147 627 minecraft:magenta_concrete
fill 72 146 605 72 147 605 minecraft:light_gray_concrete
fill 72 146 607 72 147 607 minecraft:light_gray_concrete
fill 72 146 609 72 147 609 minecraft:light_gray_concrete
fill 72 146 611 72 147 611 minecraft:light_gray_concrete
fill 72 146 613 72 147 613 minecraft:light_gray_concrete
fill 73 146 606 73 147 606 minecraft:light_gray_concrete
fill 73 146 608 73 147 608 minecraft:light_gray_concrete
fill 73 146 610 73 147 610 minecraft:light_gray_concrete
fill 73 146 612 73 147 612 minecraft:light_gray_concrete
fill 74 146 605 74 147 605 minecraft:light_gray_concrete
fill 74 146 607 74 147 607 minecraft:light_gray_concrete
fill 74 146 609 74 147 609 minecraft:light_gray_concrete
fill 74 146 611 74 147 611 minecraft:light_gray_concrete
fill 74 146 613 74 147 613 minecraft:light_gray_concrete
fill 75 146 606 75 147 606 minecraft:light_gray_concrete
fill 75 146 608 75 147 608 minecraft:light_gray_concrete
fill 75 146 610 75 147 610 minecraft:light_gray_concrete
fill 75 146 612 75 147 612 minecraft:light_gray_concrete
fill 76 146 605 76 147 605 minecraft:light_gray_concrete
fill 76 146 607 76 147 607 minecraft:light_gray_concrete
fill 76 146 609 76 147 609 minecraft:light_gray_concrete
fill 76 146 611 76 147 611 minecraft:light_gray_concrete
fill 76 146 613 76 147 613 minecraft:light_gray_concrete
fill 77 146 606 77 147 606 minecraft:light_gray_concrete
fill 77 146 608 77 147 608 minecraft:light_gray_concrete
fill 77 146 610 77 147 610 minecraft:light_gray_concrete
fill 77 146 612 77 147 612 minecraft:light_gray_concrete
fill 78 146 605 78 147 605 minecraft:light_gray_concrete
fill 78 146 607 78 147 607 minecraft:light_gray_concrete
fill 78 146 609 78 147 609 minecraft:light_gray_concrete
fill 78 146 611 78 147 611 minecraft:light_gray_concrete
fill 78 146 613 78 147 613 minecraft:light_gray_concrete
fill 83 146 608 83 147 608 minecraft:light_gray_concrete
fill 83 146 610 83 147 610 minecraft:light_gray_concrete
fill 83 146 612 83 147 612 minecraft:light_gray_concrete
fill 83 146 614 83 147 614 minecraft:light_gray_concrete
fill 83 146 616 83 147 616 minecraft:light_gray_concrete
fill 83 146 618 83 147 618 minecraft:light_gray_concrete
fill 83 146 620 83 147 620 minecraft:light_gray_concrete
fill 84 146 609 84 147 609 minecraft:light_gray_concrete
fill 84 146 611 84 147 611 minecraft:light_gray_concrete
fill 84 146 613 84 147 613 minecraft:light_gray_concrete
fill 84 146 615 84 147 615 minecraft:light_gray_concrete
fill 84 146 617 84 147 617 minecraft:light_gray_concrete
fill 84 146 619 84 147 619 minecraft:light_gray_concrete
fill 85 146 608 85 147 608 minecraft:light_gray_concrete
fill 85 146 610 85 147 610 minecraft:light_gray_concrete
fill 85 146 612 85 147 612 minecraft:light_gray_concrete
fill 85 146 614 85 147 614 minecraft:light_gray_concrete
fill 85 146 616 85 147 616 minecraft:light_gray_concrete
fill 85 146 618 85 147 618 minecraft:light_gray_concrete
fill 85 146 620 85 147 620 minecraft:light_gray_concrete
fill 86 146 609 86 147 609 minecraft:light_gray_concrete
fill 86 146 611 86 147 611 minecraft:light_gray_concrete
fill 86 146 613 86 147 613 minecraft:light_gray_concrete
fill 86 146 615 86 147 615 minecraft:light_gray_concrete
fill 86 146 617 86 147 617 minecraft:light_gray_concrete
fill 86 146 619 86 147 619 minecraft:light_gray_concrete
fill 87 146 608 87 147 608 minecraft:light_gray_concrete
fill 87 146 610 87 147 610 minecraft:light_gray_concrete
fill 87 146 612 87 147 612 minecraft:light_gray_concrete
fill 87 146 614 87 147 614 minecraft:light_gray_concrete
fill 87 146 616 87 147 616 minecraft:light_gray_concrete
fill 87 146 618 87 147 618 minecraft:light_gray_concrete
fill 87 146 620 87 147 620 minecraft:light_gray_concrete
fill 88 146 609 88 147 609 minecraft:light_gray_concrete
fill 88 146 611 88 147 611 minecraft:light_gray_concrete
fill 88 146 613 88 147 613 minecraft:light_gray_concrete
fill 88 146 615 88 147 615 minecraft:light_gray_concrete
fill 88 146 617 88 147 617 minecraft:light_gray_concrete
fill 88 146 619 88 147 619 minecraft:light_gray_concrete
fill 49 147 624 49 147 625 minecraft:magenta_concrete
fill 49 147 627 49 147 628 minecraft:magenta_concrete
setblock 50 147 623 minecraft:magenta_concrete
setblock 50 147 629 minecraft:magenta_concrete
setblock 52 147 622 minecraft:magenta_concrete
setblock 52 147 630 minecraft:magenta_concrete
setblock 54 147 623 minecraft:magenta_concrete
setblock 54 147 629 minecraft:magenta_concrete
setblock 55 147 624 minecraft:magenta_concrete
setblock 55 147 628 minecraft:magenta_concrete
fill 56 147 625 56 147 627 minecraft:magenta_concrete
fill 48 148 621 57 150 626 minecraft:light_gray_concrete
fill 48 148 629 57 150 631 minecraft:light_gray_concrete
fill 49 148 627 57 150 628 minecraft:light_gray_concrete
fill 61 148 639 62 149 640 minecraft:glass
fill 64 148 633 64 149 633 minecraft:magenta_concrete
setblock 72 148 605 minecraft:sea_lantern
setblock 72 148 607 minecraft:sea_lantern
setblock 72 148 609 minecraft:sea_lantern
setblock 72 148 611 minecraft:sea_lantern
setblock 72 148 613 minecraft:sea_lantern
setblock 73 148 606 minecraft:sea_lantern
setblock 73 148 608 minecraft:sea_lantern
setblock 73 148 610 minecraft:sea_lantern
setblock 73 148 612 minecraft:sea_lantern
setblock 74 148 605 minecraft:sea_lantern
setblock 74 148 607 minecraft:sea_lantern
setblock 74 148 609 minecraft:sea_lantern
setblock 74 148 611 minecraft:sea_lantern
setblock 74 148 613 minecraft:sea_lantern
setblock 75 148 606 minecraft:sea_lantern
setblock 75 148 608 minecraft:sea_lantern
setblock 75 148 610 minecraft:sea_lantern
setblock 75 148 612 minecraft:sea_lantern
setblock 76 148 605 minecraft:sea_lantern
setblock 76 148 607 minecraft:sea_lantern
setblock 76 148 609 minecraft:sea_lantern
setblock 76 148 611 minecraft:sea_lantern
setblock 76 148 613 minecraft:sea_lantern
setblock 77 148 606 minecraft:sea_lantern
setblock 77 148 608 minecraft:sea_lantern
setblock 77 148 610 minecraft:sea_lantern
setblock 77 148 612 minecraft:sea_lantern
setblock 78 148 605 minecraft:sea_lantern
setblock 78 148 607 minecraft:sea_lantern
setblock 78 148 609 minecraft:sea_lantern
setblock 78 148 611 minecraft:sea_lantern
setblock 78 148 613 minecraft:sea_lantern
setblock 83 148 608 minecraft:sea_lantern
setblock 83 148 610 minecraft:sea_lantern
setblock 83 148 612 minecraft:sea_lantern
setblock 83 148 614 minecraft:sea_lantern
setblock 83 148 616 minecraft:sea_lantern
setblock 83 148 618 minecraft:sea_lantern
setblock 83 148 620 minecraft:sea_lantern
setblock 84 148 609 minecraft:sea_lantern
setblock 84 148 611 minecraft:sea_lantern
setblock 84 148 613 minecraft:sea_lantern
setblock 84 148 615 minecraft:sea_lantern
setblock 84 148 617 minecraft:sea_lantern
setblock 84 148 619 minecraft:sea_lantern
setblock 85 148 608 minecraft:sea_lantern
setblock 85 148 610 minecraft:sea_lantern
setblock 85 148 612 minecraft:sea_lantern
setblock 85 148 614 minecraft:sea_lantern
setblock 85 148 616 minecraft:sea_lantern
setblock 85 148 618 minecraft:sea_lantern
setblock 85 148 620 minecraft:sea_lantern
setblock 86 148 609 minecraft:sea_lantern
setblock 86 148 611 minecraft:sea_lantern
setblock 86 148 613 minecraft:sea_lantern
setblock 86 148 615 minecraft:sea_lantern
setblock 86 148 617 minecraft:sea_lantern
setblock 86 148 619 minecraft:sea_lantern
setblock 87 148 608 minecraft:sea_lantern
setblock 87 148 610 minecraft:sea_lantern
setblock 87 148 612 minecraft:sea_lantern
setblock 87 148 614 minecraft:sea_lantern
setblock 87 148 616 minecraft:sea_lantern
setblock 87 148 618 minecraft:sea_lantern
setblock 87 148 620 minecraft:sea_lantern
setblock 88 148 609 minecraft:sea_lantern
setblock 88 148 611 minecraft:sea_lantern
setblock 88 148 613 minecraft:sea_lantern
setblock 88 148 615 minecraft:sea_lantern
setblock 88 148 617 minecraft:sea_lantern
setblock 88 148 619 minecraft:sea_lantern
fill 72 149 605 72 150 605 minecraft:light_gray_concrete
fill 72 149 607 72 150 607 minecraft:light_gray_concrete
fill 72 149 609 72 150 609 minecraft:light_gray_concrete
fill 72 149 611 72 150 611 minecraft:light_gray_concrete
fill 72 149 613 72 150 613 minecraft:light_gray_concrete
fill 73 149 606 73 150 606 minecraft:light_gray_concrete
fill 73 149 608 73 150 608 minecraft:light_gray_concrete
fill 73 149 610 73 150 610 minecraft:light_gray_concrete
fill 73 149 612 73 150 612 minecraft:light_gray_concrete
fill 74 149 605 74 150 605 minecraft:light_gray_concrete
fill 74 149 607 74 150 607 minecraft:light_gray_concrete
fill 74 149 609 74 150 609 minecraft:light_gray_concrete
fill 74 149 611 74 150 611 minecraft:light_gray_concrete
fill 74 149 613 74 150 613 minecraft:light_gray_concrete
fill 75 149 606 75 150 606 minecraft:light_gray_concrete
fill 75 149 608 75 150 608 minecraft:light_gray_concrete
fill 75 149 610 75 150 610 minecraft:light_gray_concrete
fill 75 149 612 75 150 612 minecraft:light_gray_concrete
fill 76 149 605 76 150 605 minecraft:light_gray_concrete
fill 76 149 607 76 150 607 minecraft:light_gray_concrete
fill 76 149 609 76 150 609 minecraft:light_gray_concrete
fill 76 149 611 76 150 611 minecraft:light_gray_concrete
fill 76 149 613 76 150 613 minecraft:light_gray_concrete
fill 77 149 606 77 150 606 minecraft:light_gray_concrete
fill 77 149 608 77 150 608 minecraft:light_gray_concrete
fill 77 149 610 77 150 610 minecraft:light_gray_concrete
fill 77 149 612 77 150 612 minecraft:light_gray_concrete
fill 78 149 605 78 150 605 minecraft:light_gray_concrete
fill 78 149 607 78 150 607 minecraft:light_gray_concrete
fill 78 149 609 78 150 609 minecraft:light_gray_concrete
fill 78 149 611 78 150 611 minecraft:light_gray_concrete
fill 78 149 613 78 150 613 minecraft:light_gray_concrete
fill 83 149 608 83 150 608 minecraft:light_gray_concrete
fill 83 149 610 83 150 610 minecraft:light_gray_concrete
fill 83 149 612 83 150 612 minecraft:light_gray_concrete
fill 83 149 614 83 150 614 minecraft:light_gray_concrete
fill 83 149 616 83 150 616 minecraft:light_gray_concrete
fill 83 149 618 83 150 618 minecraft:light_gray_concrete
fill 83 149 620 83 150 620 minecraft:light_gray_concrete
fill 84 149 609 84 150 609 minecraft:light_gray_concrete
fill 84 149 611 84 150 611 minecraft:light_gray_concrete
fill 84 149 613 84 150 613 minecraft:light_gray_concrete
fill 84 149 615 84 150 615 minecraft:light_gray_concrete
fill 84 149 617 84 150 617 minecraft:light_gray_concrete
fill 84 149 619 84 150 619 minecraft:light_gray_concrete
fill 85 149 608 85 150 608 minecraft:light_gray_concrete
fill 85 149 610 85 150 610 minecraft:light_gray_concrete
fill 85 149 612 85 150 612 minecraft:light_gray_concrete
fill 85 149 614 85 150 614 minecraft:light_gray_concrete
fill 85 149 616 85 150 616 minecraft:light_gray_concrete
fill 85 149 618 85 150 618 minecraft:light_gray_concrete
fill 85 149 620 85 150 620 minecraft:light_gray_concrete
fill 86 149 609 86 150 609 minecraft:light_gray_concrete
fill 86 149 611 86 150 611 minecraft:light_gray_concrete
fill 86 149 613 86 150 613 minecraft:light_gray_concrete
fill 86 149 615 86 150 615 minecraft:light_gray_concrete
fill 86 149 617 86 150 617 minecraft:light_gray_concrete
fill 86 149 619 86 150 619 minecraft:light_gray_concrete
fill 87 149 608 87 150 608 minecraft:light_gray_concrete
fill 87 149 610 87 150 610 minecraft:light_gray_concrete
fill 87 149 612 87 150 612 minecraft:light_gray_concrete
fill 87 149 614 87 150 614 minecraft:light_gray_concrete
fill 87 149 616 87 150 616 minecraft:light_gray_concrete
fill 87 149 618 87 150 618 minecraft:light_gray_concrete
fill 87 149 620 87 150 620 minecraft:light_gray_concrete
fill 88 149 609 88 150 609 minecraft:light_gray_concrete
fill 88 149 611 88 150 611 minecraft:light_gray_concrete
fill 88 149 613 88 150 613 minecraft:light_gray_concrete
fill 88 149 615 88 150 615 minecraft:light_gray_concrete
fill 88 149 617 88 150 617 minecraft:light_gray_concrete
fill 88 149 619 88 150 619 minecraft:light_gray_concrete
fill 47 150 609 47 157 609 minecraft:black_concrete
fill 47 150 617 47 157 617 minecraft:black_concrete
fill 47 150 625 47 157 625 minecraft:black_concrete
fill 47 150 633 47 157 633 minecraft:black_concrete
fill 47 150 641 47 157 641 minecraft:black_concrete
fill 50 150 646 50 157 646 minecraft:black_concrete
fill 54 150 604 54 157 604 minecraft:black_concrete
fill 58 150 646 58 157 646 minecraft:black_concrete
fill 62 150 604 62 157 604 minecraft:black_concrete
fill 66 150 646 66 157 646 minecraft:black_concrete
fill 70 150 604 70 157 604 minecraft:black_concrete
fill 74 150 646 74 157 646 minecraft:black_concrete
fill 78 150 604 78 157 604 minecraft:black_concrete
fill 82 150 646 82 157 646 minecraft:black_concrete
fill 86 150 604 86 157 604 minecraft:black_concrete
fill 89 150 609 89 157 609 minecraft:black_concrete
fill 89 150 617 89 157 617 minecraft:black_concrete
fill 89 150 625 89 157 625 minecraft:black_concrete
fill 89 150 633 89 157 633 minecraft:black_concrete
fill 89 150 641 89 157 641 minecraft:black_concrete
setblock 48 151 621 minecraft:sea_lantern
fill 48 151 622 48 162 622 minecraft:light_gray_concrete
setblock 48 151 623 minecraft:sea_lantern
fill 48 151 624 48 162 624 minecraft:light_gray_concrete
setblock 48 151 625 minecraft:sea_lantern
fill 48 151 626 48 162 626 minecraft:light_gray_concrete
setblock 48 151 627 minecraft:sea_lantern
fill 48 151 628 48 162 628 minecraft:light_gray_concrete
setblock 48 151 629 minecraft:sea_lantern
fill 48 151 630 48 162 630 minecraft:light_gray_concrete
setblock 48 151 631 minecraft:sea_lantern
fill 49 151 621 49 162 621 minecraft:light_gray_concrete
setblock 49 151 622 minecraft:sea_lantern
fill 49 151 623 49 162 623 minecraft:light_gray_concrete
setblock 49 151 624 minecraft:sea_lantern
fill 49 151 625 49 162 625 minecraft:light_gray_concrete
setblock 49 151 626 minecraft:sea_lantern
fill 49 151 627 49 162 627 minecraft:light_gray_concrete
setblock 49 151 628 minecraft:sea_lantern
fill 49 151 629 49 162 629 minecraft:light_gray_concrete
setblock 49 151 630 minecraft:sea_lantern
fill 49 151 631 49 162 631 minecraft:light_gray_concrete
setblock 50 151 621 minecraft:sea_lantern
fill 50 151 622 50 162 622 minecraft:light_gray_concrete
setblock 50 151 623 minecraft:sea_lantern
fill 50 151 624 50 162 624 minecraft:light_gray_concrete
setblock 50 151 625 minecraft:sea_lantern
fill 50 151 626 50 162 626 minecraft:light_gray_concrete
setblock 50 151 627 minecraft:sea_lantern
fill 50 151 628 50 162 628 minecraft:light_gray_concrete
setblock 50 151 629 minecraft:sea_lantern
fill 50 151 630 50 162 630 minecraft:light_gray_concrete
setblock 50 151 631 minecraft:sea_lantern
fill 51 151 621 51 162 621 minecraft:light_gray_concrete
setblock 51 151 622 minecraft:sea_lantern
fill 51 151 623 51 162 623 minecraft:light_gray_concrete
setblock 51 151 624 minecraft:sea_lantern
fill 51 151 625 51 162 625 minecraft:light_gray_concrete
setblock 51 151 626 minecraft:sea_lantern
fill 51 151 627 51 162 627 minecraft:light_gray_concrete
setblock 51 151 628 minecraft:sea_lantern
fill 51 151 629 51 162 629 minecraft:light_gray_concrete
setblock 51 151 630 minecraft:sea_lantern
fill 51 151 631 51 162 631 minecraft:light_gray_concrete
setblock 52 151 621 minecraft:sea_lantern
fill 52 151 622 52 162 622 minecraft:light_gray_concrete
setblock 52 151 623 minecraft:sea_lantern
fill 52 151 624 52 162 624 minecraft:light_gray_concrete
setblock 52 151 625 minecraft:sea_lantern
fill 52 151 626 52 162 626 minecraft:light_gray_concrete
setblock 52 151 627 minecraft:sea_lantern
fill 52 151 628 52 162 628 minecraft:light_gray_concrete
setblock 52 151 629 minecraft:sea_lantern
fill 52 151 630 52 162 630 minecraft:light_gray_concrete
setblock 52 151 631 minecraft:sea_lantern
fill 53 151 621 53 162 621 minecraft:light_gray_concrete
setblock 53 151 622 minecraft:sea_lantern
fill 53 151 623 53 162 623 minecraft:light_gray_concrete
setblock 53 151 624 minecraft:sea_lantern
fill 53 151 625 53 162 625 minecraft:light_gray_concrete
setblock 53 151 626 minecraft:sea_lantern
fill 53 151 627 53 162 627 minecraft:light_gray_concrete
setblock 53 151 628 minecraft:sea_lantern
fill 53 151 629 53 162 629 minecraft:light_gray_concrete
setblock 53 151 630 minecraft:sea_lantern
fill 53 151 631 53 162 631 minecraft:light_gray_concrete
setblock 54 151 621 minecraft:sea_lantern
fill 54 151 622 54 162 622 minecraft:light_gray_concrete
setblock 54 151 623 minecraft:sea_lantern
fill 54 151 624 54 162 624 minecraft:light_gray_concrete
setblock 54 151 625 minecraft:sea_lantern
fill 54 151 626 54 162 626 minecraft:light_gray_concrete
setblock 54 151 627 minecraft:sea_lantern
fill 54 151 628 54 162 628 minecraft:light_gray_concrete
setblock 54 151 629 minecraft:sea_lantern
fill 54 151 630 54 162 630 minecraft:light_gray_concrete
setblock 54 151 631 minecraft:sea_lantern
fill 55 151 621 55 162 621 minecraft:light_gray_concrete
setblock 55 151 622 minecraft:sea_lantern
fill 55 151 623 55 162 623 minecraft:light_gray_concrete
setblock 55 151 624 minecraft:sea_lantern
fill 55 151 625 55 162 625 minecraft:light_gray_concrete
setblock 55 151 626 minecraft:sea_lantern
fill 55 151 627 55 162 627 minecraft:light_gray_concrete
setblock 55 151 628 minecraft:sea_lantern
fill 55 151 629 55 162 629 minecraft:light_gray_concrete
setblock 55 151 630 minecraft:sea_lantern
fill 55 151 631 55 162 631 minecraft:light_gray_concrete
setblock 56 151 621 minecraft:sea_lantern
fill 56 151 622 56 162 622 minecraft:light_gray_concrete
setblock 56 151 623 minecraft:sea_lantern
fill 56 151 624 56 162 624 minecraft:light_gray_concrete
setblock 56 151 625 minecraft:sea_lantern
fill 56 151 626 56 162 626 minecraft:light_gray_concrete
setblock 56 151 627 minecraft:sea_lantern
fill 56 151 628 56 162 628 minecraft:light_gray_concrete
setblock 56 151 629 minecraft:sea_lantern
fill 56 151 630 56 162 630 minecraft:light_gray_concrete
setblock 56 151 631 minecraft:sea_lantern
fill 57 151 621 57 162 621 minecraft:light_gray_concrete
setblock 57 151 622 minecraft:sea_lantern
fill 57 151 623 57 162 623 minecraft:light_gray_concrete
setblock 57 151 624 minecraft:sea_lantern
fill 57 151 625 57 162 625 minecraft:light_gray_concrete
setblock 57 151 626 minecraft:sea_lantern
fill 57 151 627 57 162 627 minecraft:light_gray_concrete
setblock 57 151 628 minecraft:sea_lantern
fill 57 151 629 57 162 629 minecraft:light_gray_concrete
setblock 57 151 630 minecraft:sea_lantern
fill 57 151 631 57 162 631 minecraft:light_gray_concrete
setblock 72 151 605 minecraft:sea_lantern
setblock 72 151 607 minecraft:sea_lantern
setblock 72 151 609 minecraft:sea_lantern
setblock 72 151 611 minecraft:sea_lantern
setblock 72 151 613 minecraft:sea_lantern
setblock 73 151 606 minecraft:sea_lantern
setblock 73 151 608 minecraft:sea_lantern
setblock 73 151 610 minecraft:sea_lantern
setblock 73 151 612 minecraft:sea_lantern
setblock 74 151 605 minecraft:sea_lantern
setblock 74 151 607 minecraft:sea_lantern
setblock 74 151 609 minecraft:sea_lantern
setblock 74 151 611 minecraft:sea_lantern
setblock 74 151 613 minecraft:sea_lantern
setblock 75 151 606 minecraft:sea_lantern
setblock 75 151 608 minecraft:sea_lantern
setblock 75 151 610 minecraft:sea_lantern
setblock 75 151 612 minecraft:sea_lantern
setblock 76 151 605 minecraft:sea_lantern
setblock 76 151 607 minecraft:sea_lantern
setblock 76 151 609 minecraft:sea_lantern
setblock 76 151 611 minecraft:sea_lantern
setblock 76 151 613 minecraft:sea_lantern
setblock 77 151 606 minecraft:sea_lantern
setblock 77 151 608 minecraft:sea_lantern
setblock 77 151 610 minecraft:sea_lantern
setblock 77 151 612 minecraft:sea_lantern
setblock 78 151 605 minecraft:sea_lantern
setblock 78 151 607 minecraft:sea_lantern
setblock 78 151 609 minecraft:sea_lantern
setblock 78 151 611 minecraft:sea_lantern
setblock 78 151 613 minecraft:sea_lantern
setblock 83 151 608 minecraft:sea_lantern
setblock 83 151 610 minecraft:sea_lantern
setblock 83 151 612 minecraft:sea_lantern
setblock 83 151 614 minecraft:sea_lantern
setblock 83 151 616 minecraft:sea_lantern
setblock 83 151 618 minecraft:sea_lantern
setblock 83 151 620 minecraft:sea_lantern
setblock 84 151 609 minecraft:sea_lantern
setblock 84 151 611 minecraft:sea_lantern
setblock 84 151 613 minecraft:sea_lantern
setblock 84 151 615 minecraft:sea_lantern
setblock 84 151 617 minecraft:sea_lantern
setblock 84 151 619 minecraft:sea_lantern
setblock 85 151 608 minecraft:sea_lantern
setblock 85 151 610 minecraft:sea_lantern
setblock 85 151 612 minecraft:sea_lantern
setblock 85 151 614 minecraft:sea_lantern
setblock 85 151 616 minecraft:sea_lantern
setblock 85 151 618 minecraft:sea_lantern
setblock 85 151 620 minecraft:sea_lantern
setblock 86 151 609 minecraft:sea_lantern
setblock 86 151 611 minecraft:sea_lantern
setblock 86 151 613 minecraft:sea_lantern
setblock 86 151 615 minecraft:sea_lantern
setblock 86 151 617 minecraft:sea_lantern
setblock 86 151 619 minecraft:sea_lantern
setblock 87 151 608 minecraft:sea_lantern
setblock 87 151 610 minecraft:sea_lantern
setblock 87 151 612 minecraft:sea_lantern
setblock 87 151 614 minecraft:sea_lantern
setblock 87 151 616 minecraft:sea_lantern
setblock 87 151 618 minecraft:sea_lantern
setblock 87 151 620 minecraft:sea_lantern
setblock 88 151 609 minecraft:sea_lantern
setblock 88 151 611 minecraft:sea_lantern
setblock 88 151 613 minecraft:sea_lantern
setblock 88 151 615 minecraft:sea_lantern
setblock 88 151 617 minecraft:sea_lantern
setblock 88 151 619 minecraft:sea_lantern
fill 48 152 621 48 153 621 minecraft:light_gray_concrete
fill 48 152 623 48 153 623 minecraft:light_gray_concrete
fill 48 152 625 48 153 625 minecraft:light_gray_concrete
fill 48 152 627 48 153 627 minecraft:light_gray_concrete
fill 48 152 629 48 153 629 minecraft:light_gray_concrete
fill 48 152 631 48 153 631 minecraft:light_gray_concrete
fill 49 152 622 49 153 622 minecraft:light_gray_concrete
fill 49 152 624 49 153 624 minecraft:light_gray_concrete
fill 49 152 626 49 153 626 minecraft:light_gray_concrete
fill 49 152 628 49 153 628 minecraft:light_gray_concrete
fill 49 152 630 49 153 630 minecraft:light_gray_concrete
setblock 50 152 607 minecraft:light[level=14]
setblock 50 152 615 minecraft:light[level=14]
fill 50 152 621 50 153 621 minecraft:light_gray_concrete
fill 50 152 623 50 153 623 minecraft:light_gray_concrete
fill 50 152 625 50 153 625 minecraft:light_gray_concrete
fill 50 152 627 50 153 627 minecraft:light_gray_concrete
fill 50 152 629 50 153 629 minecraft:light_gray_concrete
fill 50 152 631 50 153 631 minecraft:light_gray_concrete
setblock 50 152 639 minecraft:light[level=14]
fill 51 152 622 51 153 622 minecraft:light_gray_concrete
fill 51 152 624 51 153 624 minecraft:light_gray_concrete
fill 51 152 626 51 153 626 minecraft:light_gray_concrete
fill 51 152 628 51 153 628 minecraft:light_gray_concrete
fill 51 152 630 51 153 630 minecraft:light_gray_concrete
fill 52 152 621 52 153 621 minecraft:light_gray_concrete
fill 52 152 623 52 153 623 minecraft:light_gray_concrete
fill 52 152 625 52 153 625 minecraft:light_gray_concrete
fill 52 152 627 52 153 627 minecraft:light_gray_concrete
fill 52 152 629 52 153 629 minecraft:light_gray_concrete
fill 52 152 631 52 153 631 minecraft:light_gray_concrete
fill 53 152 622 53 153 622 minecraft:light_gray_concrete
fill 53 152 624 53 153 624 minecraft:light_gray_concrete
fill 53 152 626 53 153 626 minecraft:light_gray_concrete
fill 53 152 628 53 153 628 minecraft:light_gray_concrete
fill 53 152 630 53 153 630 minecraft:light_gray_concrete
fill 54 152 621 54 153 621 minecraft:light_gray_concrete
fill 54 152 623 54 153 623 minecraft:light_gray_concrete
fill 54 152 625 54 153 625 minecraft:light_gray_concrete
fill 54 152 627 54 153 627 minecraft:light_gray_concrete
fill 54 152 629 54 153 629 minecraft:light_gray_concrete
fill 54 152 631 54 153 631 minecraft:light_gray_concrete
fill 55 152 622 55 153 622 minecraft:light_gray_concrete
fill 55 152 624 55 153 624 minecraft:light_gray_concrete
fill 55 152 626 55 153 626 minecraft:light_gray_concrete
fill 55 152 628 55 153 628 minecraft:light_gray_concrete
fill 55 152 630 55 153 630 minecraft:light_gray_concrete
fill 56 152 621 56 153 621 minecraft:light_gray_concrete
fill 56 152 623 56 153 623 minecraft:light_gray_concrete
fill 56 152 625 56 153 625 minecraft:light_gray_concrete
fill 56 152 627 56 153 627 minecraft:light_gray_concrete
fill 56 152 629 56 153 629 minecraft:light_gray_concrete
fill 56 152 631 56 153 631 minecraft:light_gray_concrete
fill 57 152 622 57 153 622 minecraft:light_gray_concrete
fill 57 152 624 57 153 624 minecraft:light_gray_concrete
fill 57 152 626 57 153 626 minecraft:light_gray_concrete
fill 57 152 628 57 153 628 minecraft:light_gray_concrete
fill 57 152 630 57 153 630 minecraft:light_gray_concrete
setblock 58 152 607 minecraft:light[level=14]
setblock 58 152 615 minecraft:light[level=14]
setblock 58 152 623 minecraft:light[level=14]
setblock 58 152 631 minecraft:light[level=14]
setblock 58 152 639 minecraft:light[level=14]
setblock 66 152 607 minecraft:light[level=14]
setblock 66 152 615 minecraft:light[level=14]
setblock 66 152 623 minecraft:light[level=14]
setblock 66 152 631 minecraft:light[level=14]
setblock 66 152 639 minecraft:light[level=14]
fill 72 152 605 72 153 605 minecraft:light_gray_concrete
fill 72 152 607 72 153 607 minecraft:light_gray_concrete
fill 72 152 609 72 153 609 minecraft:light_gray_concrete
fill 72 152 611 72 153 611 minecraft:light_gray_concrete
fill 72 152 613 72 153 613 minecraft:light_gray_concrete
fill 73 152 606 73 153 606 minecraft:light_gray_concrete
fill 73 152 608 73 153 608 minecraft:light_gray_concrete
fill 73 152 610 73 153 610 minecraft:light_gray_concrete
fill 73 152 612 73 153 612 minecraft:light_gray_concrete
fill 74 152 605 74 153 605 minecraft:light_gray_concrete
fill 74 152 607 74 153 607 minecraft:light_gray_concrete
fill 74 152 609 74 153 609 minecraft:light_gray_concrete
fill 74 152 611 74 153 611 minecraft:light_gray_concrete
fill 74 152 613 74 153 613 minecraft:light_gray_concrete
setblock 74 152 615 minecraft:light[level=14]
setblock 74 152 623 minecraft:light[level=14]
setblock 74 152 631 minecraft:light[level=14]
setblock 74 152 639 minecraft:light[level=14]
fill 75 152 606 75 153 606 minecraft:light_gray_concrete
fill 75 152 608 75 153 608 minecraft:light_gray_concrete
fill 75 152 610 75 153 610 minecraft:light_gray_concrete
fill 75 152 612 75 153 612 minecraft:light_gray_concrete
fill 76 152 605 76 153 605 minecraft:light_gray_concrete
fill 76 152 607 76 153 607 minecraft:light_gray_concrete
fill 76 152 609 76 153 609 minecraft:light_gray_concrete
fill 76 152 611 76 153 611 minecraft:light_gray_concrete
fill 76 152 613 76 153 613 minecraft:light_gray_concrete
fill 77 152 606 77 153 606 minecraft:light_gray_concrete
fill 77 152 608 77 153 608 minecraft:light_gray_concrete
fill 77 152 610 77 153 610 minecraft:light_gray_concrete
fill 77 152 612 77 153 612 minecraft:light_gray_concrete
fill 78 152 605 78 153 605 minecraft:light_gray_concrete
fill 78 152 607 78 153 607 minecraft:light_gray_concrete
fill 78 152 609 78 153 609 minecraft:light_gray_concrete
fill 78 152 611 78 153 611 minecraft:light_gray_concrete
fill 78 152 613 78 153 613 minecraft:light_gray_concrete
setblock 82 152 607 minecraft:light[level=14]
setblock 82 152 615 minecraft:light[level=14]
setblock 82 152 623 minecraft:light[level=14]
setblock 82 152 631 minecraft:light[level=14]
setblock 82 152 639 minecraft:light[level=14]
fill 83 152 608 83 153 608 minecraft:light_gray_concrete
fill 83 152 610 83 153 610 minecraft:light_gray_concrete
fill 83 152 612 83 153 612 minecraft:light_gray_concrete
fill 83 152 614 83 153 614 minecraft:light_gray_concrete
fill 83 152 616 83 153 616 minecraft:light_gray_concrete
fill 83 152 618 83 153 618 minecraft:light_gray_concrete
fill 83 152 620 83 153 620 minecraft:light_gray_concrete
fill 84 152 609 84 153 609 minecraft:light_gray_concrete
fill 84 152 611 84 153 611 minecraft:light_gray_concrete
fill 84 152 613 84 153 613 minecraft:light_gray_concrete
fill 84 152 615 84 153 615 minecraft:light_gray_concrete
fill 84 152 617 84 153 617 minecraft:light_gray_concrete
fill 84 152 619 84 153 619 minecraft:light_gray_concrete
fill 85 152 608 85 153 608 minecraft:light_gray_concrete
fill 85 152 610 85 153 610 minecraft:light_gray_concrete
fill 85 152 612 85 153 612 minecraft:light_gray_concrete
fill 85 152 614 85 153 614 minecraft:light_gray_concrete
fill 85 152 616 85 153 616 minecraft:light_gray_concrete
fill 85 152 618 85 153 618 minecraft:light_gray_concrete
fill 85 152 620 85 153 620 minecraft:light_gray_concrete
fill 86 152 609 86 153 609 minecraft:light_gray_concrete
fill 86 152 611 86 153 611 minecraft:light_gray_concrete
fill 86 152 613 86 153 613 minecraft:light_gray_concrete
fill 86 152 615 86 153 615 minecraft:light_gray_concrete
fill 86 152 617 86 153 617 minecraft:light_gray_concrete
fill 86 152 619 86 153 619 minecraft:light_gray_concrete
fill 87 152 608 87 153 608 minecraft:light_gray_concrete
fill 87 152 610 87 153 610 minecraft:light_gray_concrete
fill 87 152 612 87 153 612 minecraft:light_gray_concrete
fill 87 152 614 87 153 614 minecraft:light_gray_concrete
fill 87 152 616 87 153 616 minecraft:light_gray_concrete
fill 87 152 618 87 153 618 minecraft:light_gray_concrete
fill 87 152 620 87 153 620 minecraft:light_gray_concrete
fill 88 152 609 88 153 609 minecraft:light_gray_concrete
fill 88 152 611 88 153 611 minecraft:light_gray_concrete
fill 88 152 613 88 153 613 minecraft:light_gray_concrete
fill 88 152 615 88 153 615 minecraft:light_gray_concrete
fill 88 152 617 88 153 617 minecraft:light_gray_concrete
fill 88 152 619 88 153 619 minecraft:light_gray_concrete
fill 48 154 605 48 155 610 minecraft:light_gray_concrete
fill 48 154 613 49 154 618 minecraft:light_gray_concrete
setblock 48 154 621 minecraft:sea_lantern
setblock 48 154 623 minecraft:sea_lantern
setblock 48 154 625 minecraft:sea_lantern
setblock 48 154 627 minecraft:sea_lantern
setblock 48 154 629 minecraft:sea_lantern
setblock 48 154 631 minecraft:sea_lantern
fill 48 154 632 49 154 634 minecraft:light_gray_concrete
fill 48 154 637 49 154 642 minecraft:light_gray_concrete
fill 48 154 645 53 155 645 minecraft:light_gray_concrete
fill 49 154 606 49 154 612 minecraft:light_gray_concrete
fill 49 154 619 49 154 620 minecraft:light_gray_concrete
setblock 49 154 622 minecraft:sea_lantern
setblock 49 154 624 minecraft:sea_lantern
setblock 49 154 626 minecraft:sea_lantern
setblock 49 154 628 minecraft:sea_lantern
setblock 49 154 630 minecraft:sea_lantern
fill 49 154 635 49 154 636 minecraft:light_gray_concrete
fill 49 154 643 49 154 644 minecraft:light_gray_concrete
fill 50 154 606 71 154 606 minecraft:light_gray_concrete
setblock 50 154 621 minecraft:sea_lantern
setblock 50 154 623 minecraft:sea_lantern
setblock 50 154 625 minecraft:sea_lantern
setblock 50 154 627 minecraft:sea_lantern
setblock 50 154 629 minecraft:sea_lantern
setblock 50 154 631 minecraft:sea_lantern
fill 50 154 644 88 154 644 minecraft:light_gray_concrete
fill 51 154 605 56 155 605 minecraft:light_gray_concrete
setblock 51 154 622 minecraft:sea_lantern
setblock 51 154 624 minecraft:sea_lantern
setblock 51 154 626 minecraft:sea_lantern
setblock 51 154 628 minecraft:sea_lantern
setblock 51 154 630 minecraft:sea_lantern
setblock 52 154 621 minecraft:sea_lantern
setblock 52 154 623 minecraft:sea_lantern
setblock 52 154 625 minecraft:sea_lantern
setblock 52 154 627 minecraft:sea_lantern
setblock 52 154 629 minecraft:sea_lantern
setblock 52 154 631 minecraft:sea_lantern
setblock 53 154 622 minecraft:sea_lantern
setblock 53 154 624 minecraft:sea_lantern
setblock 53 154 626 minecraft:sea_lantern
setblock 53 154 628 minecraft:sea_lantern
setblock 53 154 630 minecraft:sea_lantern
setblock 54 154 621 minecraft:sea_lantern
setblock 54 154 623 minecraft:sea_lantern
setblock 54 154 625 minecraft:sea_lantern
setblock 54 154 627 minecraft:sea_lantern
setblock 54 154 629 minecraft:sea_lantern
setblock 54 154 631 minecraft:sea_lantern
setblock 55 154 622 minecraft:sea_lantern
setblock 55 154 624 minecraft:sea_lantern
setblock 55 154 626 minecraft:sea_lantern
setblock 55 154 628 minecraft:sea_lantern
setblock 55 154 630 minecraft:sea_lantern
setblock 56 154 621 minecraft:sea_lantern
setblock 56 154 623 minecraft:sea_lantern
setblock 56 154 625 minecraft:sea_lantern
setblock 56 154 627 minecraft:sea_lantern
setblock 56 154 629 minecraft:sea_lantern
setblock 56 154 631 minecraft:sea_lantern
fill 56 154 645 61 155 645 minecraft:light_gray_concrete
setblock 57 154 622 minecraft:sea_lantern
setblock 57 154 624 minecraft:sea_lantern
setblock 57 154 626 minecraft:sea_lantern
setblock 57 154 628 minecraft:sea_lantern
setblock 57 154 630 minecraft:sea_lantern
fill 59 154 605 64 155 605 minecraft:light_gray_concrete
fill 64 154 645 69 155 645 minecraft:light_gray_concrete
fill 67 154 605 71 155 605 minecraft:light_gray_concrete
setblock 72 154 605 minecraft:sea_lantern
setblock 72 154 607 minecraft:sea_lantern
setblock 72 154 609 minecraft:sea_lantern
setblock 72 154 611 minecraft:sea_lantern
setblock 72 154 613 minecraft:sea_lantern
fill 72 154 645 77 155 645 minecraft:light_gray_concrete
setblock 73 154 606 minecraft:sea_lantern
setblock 73 154 608 minecraft:sea_lantern
setblock 73 154 610 minecraft:sea_lantern
setblock 73 154 612 minecraft:sea_lantern
setblock 74 154 605 minecraft:sea_lantern
setblock 74 154 607 minecraft:sea_lantern
setblock 74 154 609 minecraft:sea_lantern
setblock 74 154 611 minecraft:sea_lantern
setblock 74 154 613 minecraft:sea_lantern
setblock 75 154 606 minecraft:sea_lantern
setblock 75 154 608 minecraft:sea_lantern
setblock 75 154 610 minecraft:sea_lantern
setblock 75 154 612 minecraft:sea_lantern
setblock 76 154 605 minecraft:sea_lantern
setblock 76 154 607 minecraft:sea_lantern
setblock 76 154 609 minecraft:sea_lantern
setblock 76 154 611 minecraft:sea_lantern
setblock 76 154 613 minecraft:sea_lantern
setblock 77 154 606 minecraft:sea_lantern
setblock 77 154 608 minecraft:sea_lantern
setblock 77 154 610 minecraft:sea_lantern
setblock 77 154 612 minecraft:sea_lantern
setblock 78 154 605 minecraft:sea_lantern
setblock 78 154 607 minecraft:sea_lantern
setblock 78 154 609 minecraft:sea_lantern
setblock 78 154 611 minecraft:sea_lantern
setblock 78 154 613 minecraft:sea_lantern
fill 79 154 605 80 154 606 minecraft:light_gray_concrete
fill 80 154 645 85 155 645 minecraft:light_gray_concrete
fill 81 154 606 87 154 606 minecraft:light_gray_concrete
fill 83 154 605 88 155 605 minecraft:light_gray_concrete
setblock 83 154 608 minecraft:sea_lantern
setblock 83 154 610 minecraft:sea_lantern
setblock 83 154 612 minecraft:sea_lantern
setblock 83 154 614 minecraft:sea_lantern
setblock 83 154 616 minecraft:sea_lantern
setblock 83 154 618 minecraft:sea_lantern
setblock 83 154 620 minecraft:sea_lantern
setblock 84 154 609 minecraft:sea_lantern
setblock 84 154 611 minecraft:sea_lantern
setblock 84 154 613 minecraft:sea_lantern
setblock 84 154 615 minecraft:sea_lantern
setblock 84 154 617 minecraft:sea_lantern
setblock 84 154 619 minecraft:sea_lantern
setblock 85 154 608 minecraft:sea_lantern
setblock 85 154 610 minecraft:sea_lantern
setblock 85 154 612 minecraft:sea_lantern
setblock 85 154 614 minecraft:sea_lantern
setblock 85 154 616 minecraft:sea_lantern
setblock 85 154 618 minecraft:sea_lantern
setblock 85 154 620 minecraft:sea_lantern
setblock 86 154 609 minecraft:sea_lantern
setblock 86 154 611 minecraft:sea_lantern
setblock 86 154 613 minecraft:sea_lantern
setblock 86 154 615 minecraft:sea_lantern
setblock 86 154 617 minecraft:sea_lantern
setblock 86 154 619 minecraft:sea_lantern
setblock 87 154 607 minecraft:light_gray_concrete
setblock 87 154 608 minecraft:sea_lantern
setblock 87 154 610 minecraft:sea_lantern
setblock 87 154 612 minecraft:sea_lantern
setblock 87 154 614 minecraft:sea_lantern
setblock 87 154 616 minecraft:sea_lantern
setblock 87 154 618 minecraft:sea_lantern
setblock 87 154 620 minecraft:sea_lantern
fill 87 154 621 87 154 643 minecraft:light_gray_concrete
setblock 88 154 609 minecraft:sea_lantern
setblock 88 154 611 minecraft:sea_lantern
setblock 88 154 613 minecraft:sea_lantern
setblock 88 154 615 minecraft:sea_lantern
setblock 88 154 617 minecraft:sea_lantern
setblock 88 154 619 minecraft:sea_lantern
fill 88 154 621 88 155 621 minecraft:light_gray_concrete
fill 88 154 624 88 155 629 minecraft:light_gray_concrete
fill 88 154 632 88 155 637 minecraft:light_gray_concrete
fill 88 154 640 88 155 643 minecraft:light_gray_concrete
fill 88 154 645 88 155 645 minecraft:light_gray_concrete
fill 48 155 613 48 155 618 minecraft:light_gray_concrete
fill 48 155 621 48 156 621 minecraft:light_gray_concrete
fill 48 155 623 48 156 623 minecraft:light_gray_concrete
fill 48 155 625 48 156 625 minecraft:light_gray_concrete
fill 48 155 627 48 156 627 minecraft:light_gray_concrete
fill 48 155 629 48 156 629 minecraft:light_gray_concrete
fill 48 155 631 48 155 634 minecraft:light_gray_concrete
fill 48 155 637 48 155 642 minecraft:light_gray_concrete
fill 49 155 622 49 156 622 minecraft:light_gray_concrete
fill 49 155 624 49 156 624 minecraft:light_gray_concrete
fill 49 155 626 49 156 626 minecraft:light_gray_concrete
fill 49 155 628 49 156 628 minecraft:light_gray_concrete
fill 49 155 630 49 156 630 minecraft:light_gray_concrete
fill 50 155 621 50 156 621 minecraft:light_gray_concrete
fill 50 155 623 50 156 623 minecraft:light_gray_concrete
fill 50 155 625 50 156 625 minecraft:light_gray_concrete
fill 50 155 627 50 156 627 minecraft:light_gray_concrete
fill 50 155 629 50 156 629 minecraft:light_gray_concrete
fill 50 155 631 50 156 631 minecraft:light_gray_concrete
fill 51 155 622 51 156 622 minecraft:light_gray_concrete
fill 51 155 624 51 156 624 minecraft:light_gray_concrete
fill 51 155 626 51 156 626 minecraft:light_gray_concrete
fill 51 155 628 51 156 628 minecraft:light_gray_concrete
fill 51 155 630 51 156 630 minecraft:light_gray_concrete
fill 52 155 621 52 156 621 minecraft:light_gray_concrete
fill 52 155 623 52 156 623 minecraft:light_gray_concrete
fill 52 155 625 52 156 625 minecraft:light_gray_concrete
fill 52 155 627 52 156 627 minecraft:light_gray_concrete
fill 52 155 629 52 156 629 minecraft:light_gray_concrete
fill 52 155 631 52 156 631 minecraft:light_gray_concrete
fill 53 155 622 53 156 622 minecraft:light_gray_concrete
fill 53 155 624 53 156 624 minecraft:light_gray_concrete
fill 53 155 626 53 156 626 minecraft:light_gray_concrete
fill 53 155 628 53 156 628 minecraft:light_gray_concrete
fill 53 155 630 53 156 630 minecraft:light_gray_concrete
fill 54 155 621 54 156 621 minecraft:light_gray_concrete
fill 54 155 623 54 156 623 minecraft:light_gray_concrete
fill 54 155 625 54 156 625 minecraft:light_gray_concrete
fill 54 155 627 54 156 627 minecraft:light_gray_concrete
fill 54 155 629 54 156 629 minecraft:light_gray_concrete
fill 54 155 631 54 156 631 minecraft:light_gray_concrete
fill 55 155 622 55 156 622 minecraft:light_gray_concrete
fill 55 155 624 55 156 624 minecraft:light_gray_concrete
fill 55 155 626 55 156 626 minecraft:light_gray_concrete
fill 55 155 628 55 156 628 minecraft:light_gray_concrete
fill 55 155 630 55 156 630 minecraft:light_gray_concrete
fill 56 155 621 56 156 621 minecraft:light_gray_concrete
fill 56 155 623 56 156 623 minecraft:light_gray_concrete
fill 56 155 625 56 156 625 minecraft:light_gray_concrete
fill 56 155 627 56 156 627 minecraft:light_gray_concrete
fill 56 155 629 56 156 629 minecraft:light_gray_concrete
fill 56 155 631 56 156 631 minecraft:light_gray_concrete
fill 57 155 622 57 156 622 minecraft:light_gray_concrete
fill 57 155 624 57 156 624 minecraft:light_gray_concrete
fill 57 155 626 57 156 626 minecraft:light_gray_concrete
fill 57 155 628 57 156 628 minecraft:light_gray_concrete
fill 57 155 630 57 156 630 minecraft:light_gray_concrete
fill 72 155 605 72 156 605 minecraft:light_gray_concrete
fill 72 155 607 72 156 607 minecraft:light_gray_concrete
fill 72 155 609 72 156 609 minecraft:light_gray_concrete
fill 72 155 611 72 156 611 minecraft:light_gray_concrete
fill 72 155 613 72 156 613 minecraft:light_gray_concrete
fill 73 155 606 73 156 606 minecraft:light_gray_concrete
fill 73 155 608 73 156 608 minecraft:light_gray_concrete
fill 73 155 610 73 156 610 minecraft:light_gray_concrete
fill 73 155 612 73 156 612 minecraft:light_gray_concrete
fill 74 155 605 74 156 605 minecraft:light_gray_concrete
fill 74 155 607 74 156 607 minecraft:light_gray_concrete
fill 74 155 609 74 156 609 minecraft:light_gray_concrete
fill 74 155 611 74 156 611 minecraft:light_gray_concrete
fill 74 155 613 74 156 613 minecraft:light_gray_concrete
fill 75 155 606 75 156 606 minecraft:light_gray_concrete
fill 75 155 608 75 156 608 minecraft:light_gray_concrete
fill 75 155 610 75 156 610 minecraft:light_gray_concrete
fill 75 155 612 75 156 612 minecraft:light_gray_concrete
fill 76 155 605 76 156 605 minecraft:light_gray_concrete
fill 76 155 607 76 156 607 minecraft:light_gray_concrete
fill 76 155 609 76 156 609 minecraft:light_gray_concrete
fill 76 155 611 76 156 611 minecraft:light_gray_concrete
fill 76 155 613 76 156 613 minecraft:light_gray_concrete
fill 77 155 606 77 156 606 minecraft:light_gray_concrete
fill 77 155 608 77 156 608 minecraft:light_gray_concrete
fill 77 155 610 77 156 610 minecraft:light_gray_concrete
fill 77 155 612 77 156 612 minecraft:light_gray_concrete
fill 78 155 605 80 155 605 minecraft:light_gray_concrete
fill 78 155 607 78 156 607 minecraft:light_gray_concrete
fill 78 155 609 78 156 609 minecraft:light_gray_concrete
fill 78 155 611 78 156 611 minecraft:light_gray_concrete
fill 78 155 613 78 156 613 minecraft:light_gray_concrete
fill 83 155 608 83 156 608 minecraft:light_gray_concrete
fill 83 155 610 83 156 610 minecraft:light_gray_concrete
fill 83 155 612 83 156 612 minecraft:light_gray_concrete
fill 83 155 614 83 156 614 minecraft:light_gray_concrete
fill 83 155 616 83 156 616 minecraft:light_gray_concrete
fill 83 155 618 83 156 618 minecraft:light_gray_concrete
fill 83 155 620 83 156 620 minecraft:light_gray_concrete
fill 84 155 609 84 156 609 minecraft:light_gray_concrete
fill 84 155 611 84 156 611 minecraft:light_gray_concrete
fill 84 155 613 84 156 613 minecraft:light_gray_concrete
fill 84 155 615 84 156 615 minecraft:light_gray_concrete
fill 84 155 617 84 156 617 minecraft:light_gray_concrete
fill 84 155 619 84 156 619 minecraft:light_gray_concrete
fill 85 155 608 85 156 608 minecraft:light_gray_concrete
fill 85 155 610 85 156 610 minecraft:light_gray_concrete
fill 85 155 612 85 156 612 minecraft:light_gray_concrete
fill 85 155 614 85 156 614 minecraft:light_gray_concrete
fill 85 155 616 85 156 616 minecraft:light_gray_concrete
fill 85 155 618 85 156 618 minecraft:light_gray_concrete
fill 85 155 620 85 156 620 minecraft:light_gray_concrete
fill 86 155 609 86 156 609 minecraft:light_gray_concrete
fill 86 155 611 86 156 611 minecraft:light_gray_concrete
fill 86 155 613 86 156 613 minecraft:light_gray_concrete
fill 86 155 615 86 156 615 minecraft:light_gray_concrete
fill 86 155 617 86 156 617 minecraft:light_gray_concrete
fill 86 155 619 86 156 619 minecraft:light_gray_concrete
fill 87 155 608 87 156 608 minecraft:light_gray_concrete
fill 87 155 610 87 156 610 minecraft:light_gray_concrete
fill 87 155 612 87 156 612 minecraft:light_gray_concrete
fill 87 155 614 87 156 614 minecraft:light_gray_concrete
fill 87 155 616 87 156 616 minecraft:light_gray_concrete
fill 87 155 618 87 156 618 minecraft:light_gray_concrete
fill 87 155 620 87 156 620 minecraft:light_gray_concrete
fill 88 155 609 88 156 609 minecraft:light_gray_concrete
fill 88 155 611 88 156 611 minecraft:light_gray_concrete
fill 88 155 613 88 156 613 minecraft:light_gray_concrete
fill 88 155 615 88 156 615 minecraft:light_gray_concrete
fill 88 155 617 88 156 617 minecraft:light_gray_concrete
fill 88 155 619 88 156 619 minecraft:light_gray_concrete
setblock 88 155 644 minecraft:light_gray_concrete
setblock 48 156 631 minecraft:light_gray_concrete
setblock 78 156 605 minecraft:light_gray_concrete
setblock 48 157 621 minecraft:sea_lantern
setblock 48 157 623 minecraft:sea_lantern
setblock 48 157 625 minecraft:sea_lantern
setblock 48 157 627 minecraft:sea_lantern
setblock 48 157 629 minecraft:sea_lantern
setblock 48 157 631 minecraft:sea_lantern
setblock 49 157 622 minecraft:sea_lantern
setblock 49 157 624 minecraft:sea_lantern
setblock 49 157 626 minecraft:sea_lantern
setblock 49 157 628 minecraft:sea_lantern
setblock 49 157 630 minecraft:sea_lantern
setblock 50 157 621 minecraft:sea_lantern
setblock 50 157 623 minecraft:sea_lantern
setblock 50 157 625 minecraft:sea_lantern
setblock 50 157 627 minecraft:sea_lantern
setblock 50 157 629 minecraft:sea_lantern
setblock 50 157 631 minecraft:sea_lantern
setblock 51 157 622 minecraft:sea_lantern
setblock 51 157 624 minecraft:sea_lantern
setblock 51 157 626 minecraft:sea_lantern
setblock 51 157 628 minecraft:sea_lantern
setblock 51 157 630 minecraft:sea_lantern
setblock 52 157 621 minecraft:sea_lantern
setblock 52 157 623 minecraft:sea_lantern
setblock 52 157 625 minecraft:sea_lantern
setblock 52 157 627 minecraft:sea_lantern
setblock 52 157 629 minecraft:sea_lantern
setblock 52 157 631 minecraft:sea_lantern
setblock 53 157 622 minecraft:sea_lantern
setblock 53 157 624 minecraft:sea_lantern
setblock 53 157 626 minecraft:sea_lantern
setblock 53 157 628 minecraft:sea_lantern
setblock 53 157 630 minecraft:sea_lantern
setblock 54 157 621 minecraft:sea_lantern
setblock 54 157 623 minecraft:sea_lantern
setblock 54 157 625 minecraft:sea_lantern
setblock 54 157 627 minecraft:sea_lantern
setblock 54 157 629 minecraft:sea_lantern
setblock 54 157 631 minecraft:sea_lantern
setblock 55 157 622 minecraft:sea_lantern
setblock 55 157 624 minecraft:sea_lantern
setblock 55 157 626 minecraft:sea_lantern
setblock 55 157 628 minecraft:sea_lantern
setblock 55 157 630 minecraft:sea_lantern
setblock 56 157 621 minecraft:sea_lantern
setblock 56 157 623 minecraft:sea_lantern
setblock 56 157 625 minecraft:sea_lantern
setblock 56 157 627 minecraft:sea_lantern
setblock 56 157 629 minecraft:sea_lantern
setblock 56 157 631 minecraft:sea_lantern
setblock 57 157 622 minecraft:sea_lantern
setblock 57 157 624 minecraft:sea_lantern
setblock 57 157 626 minecraft:sea_lantern
setblock 57 157 628 minecraft:sea_lantern
setblock 57 157 630 minecraft:sea_lantern
setblock 72 157 605 minecraft:sea_lantern
setblock 72 157 607 minecraft:sea_lantern
setblock 72 157 609 minecraft:sea_lantern
setblock 72 157 611 minecraft:sea_lantern
setblock 72 157 613 minecraft:sea_lantern
setblock 73 157 606 minecraft:sea_lantern
setblock 73 157 608 minecraft:sea_lantern
setblock 73 157 610 minecraft:sea_lantern
setblock 73 157 612 minecraft:sea_lantern
setblock 74 157 605 minecraft:sea_lantern
setblock 74 157 607 minecraft:sea_lantern
setblock 74 157 609 minecraft:sea_lantern
setblock 74 157 611 minecraft:sea_lantern
setblock 74 157 613 minecraft:sea_lantern
setblock 75 157 606 minecraft:sea_lantern
setblock 75 157 608 minecraft:sea_lantern
setblock 75 157 610 minecraft:sea_lantern
setblock 75 157 612 minecraft:sea_lantern
setblock 76 157 605 minecraft:sea_lantern
setblock 76 157 607 minecraft:sea_lantern
setblock 76 157 609 minecraft:sea_lantern
setblock 76 157 611 minecraft:sea_lantern
setblock 76 157 613 minecraft:sea_lantern
setblock 77 157 606 minecraft:sea_lantern
setblock 77 157 608 minecraft:sea_lantern
setblock 77 157 610 minecraft:sea_lantern
setblock 77 157 612 minecraft:sea_lantern
setblock 78 157 605 minecraft:sea_lantern
setblock 78 157 607 minecraft:sea_lantern
setblock 78 157 609 minecraft:sea_lantern
setblock 78 157 611 minecraft:sea_lantern
setblock 78 157 613 minecraft:sea_lantern
setblock 83 157 608 minecraft:sea_lantern
setblock 83 157 610 minecraft:sea_lantern
setblock 83 157 612 minecraft:sea_lantern
setblock 83 157 614 minecraft:sea_lantern
setblock 83 157 616 minecraft:sea_lantern
setblock 83 157 618 minecraft:sea_lantern
setblock 83 157 620 minecraft:sea_lantern
setblock 84 157 609 minecraft:sea_lantern
setblock 84 157 611 minecraft:sea_lantern
setblock 84 157 613 minecraft:sea_lantern
setblock 84 157 615 minecraft:sea_lantern
setblock 84 157 617 minecraft:sea_lantern
setblock 84 157 619 minecraft:sea_lantern
setblock 85 157 608 minecraft:sea_lantern
setblock 85 157 610 minecraft:sea_lantern
setblock 85 157 612 minecraft:sea_lantern
setblock 85 157 614 minecraft:sea_lantern
setblock 85 157 616 minecraft:sea_lantern
setblock 85 157 618 minecraft:sea_lantern
setblock 85 157 620 minecraft:sea_lantern
setblock 86 157 609 minecraft:sea_lantern
setblock 86 157 611 minecraft:sea_lantern
setblock 86 157 613 minecraft:sea_lantern
setblock 86 157 615 minecraft:sea_lantern
setblock 86 157 617 minecraft:sea_lantern
setblock 86 157 619 minecraft:sea_lantern
setblock 87 157 608 minecraft:sea_lantern
setblock 87 157 610 minecraft:sea_lantern
setblock 87 157 612 minecraft:sea_lantern
setblock 87 157 614 minecraft:sea_lantern
setblock 87 157 616 minecraft:sea_lantern
setblock 87 157 618 minecraft:sea_lantern
setblock 87 157 620 minecraft:sea_lantern
setblock 88 157 609 minecraft:sea_lantern
setblock 88 157 611 minecraft:sea_lantern
setblock 88 157 613 minecraft:sea_lantern
setblock 88 157 615 minecraft:sea_lantern
setblock 88 157 617 minecraft:sea_lantern
setblock 88 157 619 minecraft:sea_lantern
fill 47 158 609 47 162 609 minecraft:sea_lantern
fill 47 158 617 47 162 617 minecraft:sea_lantern
fill 47 158 625 47 162 625 minecraft:sea_lantern
fill 47 158 633 47 162 633 minecraft:sea_lantern
fill 47 158 641 47 162 641 minecraft:sea_lantern
fill 48 158 621 48 159 621 minecraft:light_gray_concrete
fill 48 158 623 48 159 623 minecraft:light_gray_concrete
fill 48 158 625 48 159 625 minecraft:light_gray_concrete
fill 48 158 627 48 159 627 minecraft:light_gray_concrete
fill 48 158 629 48 159 629 minecraft:light_gray_concrete
fill 48 158 631 48 159 631 minecraft:light_gray_concrete
fill 49 158 622 49 159 622 minecraft:light_gray_concrete
fill 49 158 624 49 159 624 minecraft:light_gray_concrete
fill 49 158 626 49 159 626 minecraft:light_gray_concrete
fill 49 158 628 49 159 628 minecraft:light_gray_concrete
fill 49 158 630 49 159 630 minecraft:light_gray_concrete
fill 50 158 621 50 159 621 minecraft:light_gray_concrete
fill 50 158 623 50 159 623 minecraft:light_gray_concrete
fill 50 158 625 50 159 625 minecraft:light_gray_concrete
fill 50 158 627 50 159 627 minecraft:light_gray_concrete
fill 50 158 629 50 159 629 minecraft:light_gray_concrete
fill 50 158 631 50 159 631 minecraft:light_gray_concrete
fill 50 158 646 50 162 646 minecraft:sea_lantern
fill 51 158 622 51 159 622 minecraft:light_gray_concrete
fill 51 158 624 51 159 624 minecraft:light_gray_concrete
fill 51 158 626 51 159 626 minecraft:light_gray_concrete
fill 51 158 628 51 159 628 minecraft:light_gray_concrete
fill 51 158 630 51 159 630 minecraft:light_gray_concrete
fill 52 158 621 52 159 621 minecraft:light_gray_concrete
fill 52 158 623 52 159 623 minecraft:light_gray_concrete
fill 52 158 625 52 159 625 minecraft:light_gray_concrete
fill 52 158 627 52 159 627 minecraft:light_gray_concrete
fill 52 158 629 52 159 629 minecraft:light_gray_concrete
fill 52 158 631 52 159 631 minecraft:light_gray_concrete
fill 53 158 622 53 159 622 minecraft:light_gray_concrete
fill 53 158 624 53 159 624 minecraft:light_gray_concrete
fill 53 158 626 53 159 626 minecraft:light_gray_concrete
fill 53 158 628 53 159 628 minecraft:light_gray_concrete
fill 53 158 630 53 159 630 minecraft:light_gray_concrete
fill 54 158 604 54 162 604 minecraft:sea_lantern
fill 54 158 621 54 159 621 minecraft:light_gray_concrete
fill 54 158 623 54 159 623 minecraft:light_gray_concrete
fill 54 158 625 54 159 625 minecraft:light_gray_concrete
fill 54 158 627 54 159 627 minecraft:light_gray_concrete
fill 54 158 629 54 159 629 minecraft:light_gray_concrete
fill 54 158 631 54 159 631 minecraft:light_gray_concrete
fill 55 158 622 55 159 622 minecraft:light_gray_concrete
fill 55 158 624 55 159 624 minecraft:light_gray_concrete
fill 55 158 626 55 159 626 minecraft:light_gray_concrete
fill 55 158 628 55 159 628 minecraft:light_gray_concrete
fill 55 158 630 55 159 630 minecraft:light_gray_concrete
fill 56 158 621 56 159 621 minecraft:light_gray_concrete
fill 56 158 623 56 159 623 minecraft:light_gray_concrete
fill 56 158 625 56 159 625 minecraft:light_gray_concrete
fill 56 158 627 56 159 627 minecraft:light_gray_concrete
fill 56 158 629 56 159 629 minecraft:light_gray_concrete
fill 56 158 631 56 159 631 minecraft:light_gray_concrete
fill 57 158 622 57 159 622 minecraft:light_gray_concrete
fill 57 158 624 57 159 624 minecraft:light_gray_concrete
fill 57 158 626 57 159 626 minecraft:light_gray_concrete
fill 57 158 628 57 159 628 minecraft:light_gray_concrete
fill 57 158 630 57 159 630 minecraft:light_gray_concrete
fill 58 158 646 58 162 646 minecraft:sea_lantern
fill 62 158 604 62 162 604 minecraft:sea_lantern
fill 66 158 646 66 162 646 minecraft:sea_lantern
fill 70 158 604 70 162 604 minecraft:sea_lantern
fill 72 158 605 72 159 605 minecraft:light_gray_concrete
fill 72 158 607 72 159 607 minecraft:light_gray_concrete
fill 72 158 609 72 159 609 minecraft:light_gray_concrete
fill 72 158 611 72 159 611 minecraft:light_gray_concrete
fill 72 158 613 72 159 613 minecraft:light_gray_concrete
fill 73 158 606 73 159 606 minecraft:light_gray_concrete
fill 73 158 608 73 159 608 minecraft:light_gray_concrete
fill 73 158 610 73 159 610 minecraft:light_gray_concrete
fill 73 158 612 73 159 612 minecraft:light_gray_concrete
fill 74 158 605 74 159 605 minecraft:light_gray_concrete
fill 74 158 607 74 159 607 minecraft:light_gray_concrete
fill 74 158 609 74 159 609 minecraft:light_gray_concrete
fill 74 158 611 74 159 611 minecraft:light_gray_concrete
fill 74 158 613 74 159 613 minecraft:light_gray_concrete
fill 74 158 646 74 162 646 minecraft:sea_lantern
fill 75 158 606 75 159 606 minecraft:light_gray_concrete
fill 75 158 608 75 159 608 minecraft:light_gray_concrete
fill 75 158 610 75 159 610 minecraft:light_gray_concrete
fill 75 158 612 75 159 612 minecraft:light_gray_concrete
fill 76 158 605 76 159 605 minecraft:light_gray_concrete
fill 76 158 607 76 159 607 minecraft:light_gray_concrete
fill 76 158 609 76 159 609 minecraft:light_gray_concrete
fill 76 158 611 76 159 611 minecraft:light_gray_concrete
fill 76 158 613 76 159 613 minecraft:light_gray_concrete
fill 77 158 606 77 159 606 minecraft:light_gray_concrete
fill 77 158 608 77 159 608 minecraft:light_gray_concrete
fill 77 158 610 77 159 610 minecraft:light_gray_concrete
fill 77 158 612 77 159 612 minecraft:light_gray_concrete
fill 78 158 604 78 162 604 minecraft:sea_lantern
fill 78 158 605 78 159 605 minecraft:light_gray_concrete
fill 78 158 607 78 159 607 minecraft:light_gray_concrete
fill 78 158 609 78 159 609 minecraft:light_gray_concrete
fill 78 158 611 78 159 611 minecraft:light_gray_concrete
fill 78 158 613 78 159 613 minecraft:light_gray_concrete
fill 82 158 646 82 162 646 minecraft:sea_lantern
fill 83 158 608 83 159 608 minecraft:light_gray_concrete
fill 83 158 610 83 159 610 minecraft:light_gray_concrete
fill 83 158 612 83 159 612 minecraft:light_gray_concrete
fill 83 158 614 83 159 614 minecraft:light_gray_concrete
fill 83 158 616 83 159 616 minecraft:light_gray_concrete
fill 83 158 618 83 159 618 minecraft:light_gray_concrete
fill 83 158 620 83 159 620 minecraft:light_gray_concrete
fill 84 158 609 84 159 609 minecraft:light_gray_concrete
fill 84 158 611 84 159 611 minecraft:light_gray_concrete
fill 84 158 613 84 159 613 minecraft:light_gray_concrete
fill 84 158 615 84 159 615 minecraft:light_gray_concrete
fill 84 158 617 84 159 617 minecraft:light_gray_concrete
fill 84 158 619 84 159 619 minecraft:light_gray_concrete
fill 85 158 608 85 159 608 minecraft:light_gray_concrete
fill 85 158 610 85 159 610 minecraft:light_gray_concrete
fill 85 158 612 85 159 612 minecraft:light_gray_concrete
fill 85 158 614 85 159 614 minecraft:light_gray_concrete
fill 85 158 616 85 159 616 minecraft:light_gray_concrete
fill 85 158 618 85 159 618 minecraft:light_gray_concrete
fill 85 158 620 85 159 620 minecraft:light_gray_concrete
fill 86 158 604 86 162 604 minecraft:sea_lantern
fill 86 158 609 86 159 609 minecraft:light_gray_concrete
fill 86 158 611 86 159 611 minecraft:light_gray_concrete
fill 86 158 613 86 159 613 minecraft:light_gray_concrete
fill 86 158 615 86 159 615 minecraft:light_gray_concrete
fill 86 158 617 86 159 617 minecraft:light_gray_concrete
fill 86 158 619 86 159 619 minecraft:light_gray_concrete
fill 87 158 608 87 159 608 minecraft:light_gray_concrete
fill 87 158 610 87 159 610 minecraft:light_gray_concrete
fill 87 158 612 87 159 612 minecraft:light_gray_concrete
fill 87 158 614 87 159 614 minecraft:light_gray_concrete
fill 87 158 616 87 159 616 minecraft:light_gray_concrete
fill 87 158 618 87 159 618 minecraft:light_gray_concrete
fill 87 158 620 87 159 620 minecraft:light_gray_concrete
fill 88 158 609 88 159 609 minecraft:light_gray_concrete
fill 88 158 611 88 159 611 minecraft:light_gray_concrete
fill 88 158 613 88 159 613 minecraft:light_gray_concrete
fill 88 158 615 88 159 615 minecraft:light_gray_concrete
fill 88 158 617 88 159 617 minecraft:light_gray_concrete
fill 88 158 619 88 159 619 minecraft:light_gray_concrete
fill 89 158 609 89 162 609 minecraft:sea_lantern
fill 89 158 617 89 162 617 minecraft:sea_lantern
fill 89 158 625 89 162 625 minecraft:sea_lantern
fill 89 158 633 89 162 633 minecraft:sea_lantern
fill 89 158 641 89 162 641 minecraft:sea_lantern
fill 77 159 637 77 160 637 minecraft:magenta_concrete
setblock 48 160 621 minecraft:sea_lantern
setblock 48 160 623 minecraft:sea_lantern
setblock 48 160 625 minecraft:sea_lantern
setblock 48 160 627 minecraft:sea_lantern
setblock 48 160 629 minecraft:sea_lantern
setblock 48 160 631 minecraft:sea_lantern
setblock 49 160 622 minecraft:sea_lantern
setblock 49 160 624 minecraft:sea_lantern
setblock 49 160 626 minecraft:sea_lantern
setblock 49 160 628 minecraft:sea_lantern
setblock 49 160 630 minecraft:sea_lantern
setblock 50 160 607 minecraft:light[level=14]
setblock 50 160 615 minecraft:light[level=14]
setblock 50 160 621 minecraft:sea_lantern
setblock 50 160 623 minecraft:sea_lantern
setblock 50 160 625 minecraft:sea_lantern
setblock 50 160 627 minecraft:sea_lantern
setblock 50 160 629 minecraft:sea_lantern
setblock 50 160 631 minecraft:sea_lantern
setblock 50 160 639 minecraft:light[level=14]
setblock 51 160 622 minecraft:sea_lantern
setblock 51 160 624 minecraft:sea_lantern
setblock 51 160 626 minecraft:sea_lantern
setblock 51 160 628 minecraft:sea_lantern
setblock 51 160 630 minecraft:sea_lantern
setblock 52 160 621 minecraft:sea_lantern
setblock 52 160 623 minecraft:sea_lantern
setblock 52 160 625 minecraft:sea_lantern
setblock 52 160 627 minecraft:sea_lantern
setblock 52 160 629 minecraft:sea_lantern
setblock 52 160 631 minecraft:sea_lantern
setblock 53 160 622 minecraft:sea_lantern
setblock 53 160 624 minecraft:sea_lantern
setblock 53 160 626 minecraft:sea_lantern
setblock 53 160 628 minecraft:sea_lantern
setblock 53 160 630 minecraft:sea_lantern
setblock 54 160 621 minecraft:sea_lantern
setblock 54 160 623 minecraft:sea_lantern
setblock 54 160 625 minecraft:sea_lantern
setblock 54 160 627 minecraft:sea_lantern
setblock 54 160 629 minecraft:sea_lantern
setblock 54 160 631 minecraft:sea_lantern
setblock 55 160 622 minecraft:sea_lantern
setblock 55 160 624 minecraft:sea_lantern
setblock 55 160 626 minecraft:sea_lantern
setblock 55 160 628 minecraft:sea_lantern
setblock 55 160 630 minecraft:sea_lantern
setblock 56 160 621 minecraft:sea_lantern
setblock 56 160 623 minecraft:sea_lantern
setblock 56 160 625 minecraft:sea_lantern
setblock 56 160 627 minecraft:sea_lantern
setblock 56 160 629 minecraft:sea_lantern
setblock 56 160 631 minecraft:sea_lantern
setblock 57 160 622 minecraft:sea_lantern
setblock 57 160 624 minecraft:sea_lantern
setblock 57 160 626 minecraft:sea_lantern
setblock 57 160 628 minecraft:sea_lantern
setblock 57 160 630 minecraft:sea_lantern
setblock 58 160 607 minecraft:light[level=14]
setblock 58 160 615 minecraft:light[level=14]
setblock 58 160 623 minecraft:light[level=14]
setblock 58 160 631 minecraft:light[level=14]
setblock 58 160 639 minecraft:light[level=14]
setblock 66 160 607 minecraft:light[level=14]
setblock 66 160 615 minecraft:light[level=14]
setblock 66 160 623 minecraft:light[level=14]
setblock 66 160 631 minecraft:light[level=14]
setblock 66 160 639 minecraft:light[level=14]
setblock 72 160 605 minecraft:sea_lantern
setblock 72 160 607 minecraft:sea_lantern
setblock 72 160 609 minecraft:sea_lantern
setblock 72 160 611 minecraft:sea_lantern
setblock 72 160 613 minecraft:sea_lantern
setblock 73 160 606 minecraft:sea_lantern
setblock 73 160 608 minecraft:sea_lantern
setblock 73 160 610 minecraft:sea_lantern
setblock 73 160 612 minecraft:sea_lantern
setblock 74 160 605 minecraft:sea_lantern
setblock 74 160 607 minecraft:sea_lantern
setblock 74 160 609 minecraft:sea_lantern
setblock 74 160 611 minecraft:sea_lantern
setblock 74 160 613 minecraft:sea_lantern
setblock 74 160 615 minecraft:light[level=14]
setblock 74 160 623 minecraft:light[level=14]
setblock 74 160 631 minecraft:light[level=14]
setblock 74 160 639 minecraft:light[level=14]
setblock 75 160 606 minecraft:sea_lantern
setblock 75 160 608 minecraft:sea_lantern
setblock 75 160 610 minecraft:sea_lantern
setblock 75 160 612 minecraft:sea_lantern
setblock 76 160 605 minecraft:sea_lantern
setblock 76 160 607 minecraft:sea_lantern
setblock 76 160 609 minecraft:sea_lantern
setblock 76 160 611 minecraft:sea_lantern
setblock 76 160 613 minecraft:sea_lantern
setblock 77 160 606 minecraft:sea_lantern
setblock 77 160 608 minecraft:sea_lantern
setblock 77 160 610 minecraft:sea_lantern
setblock 77 160 612 minecraft:sea_lantern
setblock 78 160 605 minecraft:sea_lantern
setblock 78 160 607 minecraft:sea_lantern
setblock 78 160 609 minecraft:sea_lantern
setblock 78 160 611 minecraft:sea_lantern
setblock 78 160 613 minecraft:sea_lantern
setblock 82 160 607 minecraft:light[level=14]
setblock 82 160 615 minecraft:light[level=14]
setblock 82 160 623 minecraft:light[level=14]
setblock 82 160 631 minecraft:light[level=14]
setblock 82 160 639 minecraft:light[level=14]
setblock 83 160 608 minecraft:sea_lantern
setblock 83 160 610 minecraft:sea_lantern
setblock 83 160 612 minecraft:sea_lantern
setblock 83 160 614 minecraft:sea_lantern
setblock 83 160 616 minecraft:sea_lantern
setblock 83 160 618 minecraft:sea_lantern
setblock 83 160 620 minecraft:sea_lantern
setblock 84 160 609 minecraft:sea_lantern
setblock 84 160 611 minecraft:sea_lantern
setblock 84 160 613 minecraft:sea_lantern
setblock 84 160 615 minecraft:sea_lantern
setblock 84 160 617 minecraft:sea_lantern
setblock 84 160 619 minecraft:sea_lantern
setblock 85 160 608 minecraft:sea_lantern
setblock 85 160 610 minecraft:sea_lantern
setblock 85 160 612 minecraft:sea_lantern
setblock 85 160 614 minecraft:sea_lantern
setblock 85 160 616 minecraft:sea_lantern
setblock 85 160 618 minecraft:sea_lantern
setblock 85 160 620 minecraft:sea_lantern
setblock 86 160 609 minecraft:sea_lantern
setblock 86 160 611 minecraft:sea_lantern
setblock 86 160 613 minecraft:sea_lantern
setblock 86 160 615 minecraft:sea_lantern
setblock 86 160 617 minecraft:sea_lantern
setblock 86 160 619 minecraft:sea_lantern
setblock 87 160 608 minecraft:sea_lantern
setblock 87 160 610 minecraft:sea_lantern
setblock 87 160 612 minecraft:sea_lantern
setblock 87 160 614 minecraft:sea_lantern
setblock 87 160 616 minecraft:sea_lantern
setblock 87 160 618 minecraft:sea_lantern
setblock 87 160 620 minecraft:sea_lantern
setblock 88 160 609 minecraft:sea_lantern
setblock 88 160 611 minecraft:sea_lantern
setblock 88 160 613 minecraft:sea_lantern
setblock 88 160 615 minecraft:sea_lantern
setblock 88 160 617 minecraft:sea_lantern
setblock 88 160 619 minecraft:sea_lantern
fill 48 161 621 48 162 621 minecraft:light_gray_concrete
fill 48 161 623 48 162 623 minecraft:light_gray_concrete
fill 48 161 625 48 162 625 minecraft:light_gray_concrete
fill 48 161 627 48 162 627 minecraft:light_gray_concrete
fill 48 161 629 48 162 629 minecraft:light_gray_concrete
fill 48 161 631 48 162 631 minecraft:light_gray_concrete
fill 49 161 622 49 162 622 minecraft:light_gray_concrete
fill 49 161 624 49 162 624 minecraft:light_gray_concrete
fill 49 161 626 49 162 626 minecraft:light_gray_concrete
fill 49 161 628 49 162 628 minecraft:light_gray_concrete
fill 49 161 630 49 162 630 minecraft:light_gray_concrete
fill 50 161 621 50 162 621 minecraft:light_gray_concrete
fill 50 161 623 50 162 623 minecraft:light_gray_concrete
fill 50 161 625 50 162 625 minecraft:light_gray_concrete
fill 50 161 627 50 162 627 minecraft:light_gray_concrete
fill 50 161 629 50 162 629 minecraft:light_gray_concrete
fill 50 161 631 50 162 631 minecraft:light_gray_concrete
fill 51 161 622 51 162 622 minecraft:light_gray_concrete
fill 51 161 624 51 162 624 minecraft:light_gray_concrete
fill 51 161 626 51 162 626 minecraft:light_gray_concrete
fill 51 161 628 51 162 628 minecraft:light_gray_concrete
fill 51 161 630 51 162 630 minecraft:light_gray_concrete
fill 52 161 621 52 162 621 minecraft:light_gray_concrete
fill 52 161 623 52 162 623 minecraft:light_gray_concrete
fill 52 161 625 52 162 625 minecraft:light_gray_concrete
fill 52 161 627 52 162 627 minecraft:light_gray_concrete
fill 52 161 629 52 162 629 minecraft:light_gray_concrete
fill 52 161 631 52 162 631 minecraft:light_gray_concrete
fill 53 161 622 53 162 622 minecraft:light_gray_concrete
fill 53 161 624 53 162 624 minecraft:light_gray_concrete
fill 53 161 626 53 162 626 minecraft:light_gray_concrete
fill 53 161 628 53 162 628 minecraft:light_gray_concrete
fill 53 161 630 53 162 630 minecraft:light_gray_concrete
fill 54 161 621 54 162 621 minecraft:light_gray_concrete
fill 54 161 623 54 162 623 minecraft:light_gray_concrete
fill 54 161 625 54 162 625 minecraft:light_gray_concrete
fill 54 161 627 54 162 627 minecraft:light_gray_concrete
fill 54 161 629 54 162 629 minecraft:light_gray_concrete
fill 54 161 631 54 162 631 minecraft:light_gray_concrete
fill 55 161 622 55 162 622 minecraft:light_gray_concrete
fill 55 161 624 55 162 624 minecraft:light_gray_concrete
fill 55 161 626 55 162 626 minecraft:light_gray_concrete
fill 55 161 628 55 162 628 minecraft:light_gray_concrete
fill 55 161 630 55 162 630 minecraft:light_gray_concrete
fill 56 161 621 56 162 621 minecraft:light_gray_concrete
fill 56 161 623 56 162 623 minecraft:light_gray_concrete
fill 56 161 625 56 162 625 minecraft:light_gray_concrete
fill 56 161 627 56 162 627 minecraft:light_gray_concrete
fill 56 161 629 56 162 629 minecraft:light_gray_concrete
fill 56 161 631 56 162 631 minecraft:light_gray_concrete
fill 57 161 622 57 162 622 minecraft:light_gray_concrete
fill 57 161 624 57 162 624 minecraft:light_gray_concrete
fill 57 161 626 57 162 626 minecraft:light_gray_concrete
fill 57 161 628 57 162 628 minecraft:light_gray_concrete
fill 57 161 630 57 162 630 minecraft:light_gray_concrete
fill 72 161 605 72 162 605 minecraft:light_gray_concrete
fill 72 161 607 72 162 607 minecraft:light_gray_concrete
fill 72 161 609 72 162 609 minecraft:light_gray_concrete
fill 72 161 611 72 162 611 minecraft:light_gray_concrete
fill 72 161 613 72 162 613 minecraft:light_gray_concrete
fill 73 161 606 73 162 606 minecraft:light_gray_concrete
fill 73 161 608 73 162 608 minecraft:light_gray_concrete
fill 73 161 610 73 162 610 minecraft:light_gray_concrete
fill 73 161 612 73 162 612 minecraft:light_gray_concrete
fill 74 161 605 74 162 605 minecraft:light_gray_concrete
fill 74 161 607 74 162 607 minecraft:light_gray_concrete
fill 74 161 609 74 162 609 minecraft:light_gray_concrete
fill 74 161 611 74 162 611 minecraft:light_gray_concrete
fill 74 161 613 74 162 613 minecraft:light_gray_concrete
fill 75 161 606 75 162 606 minecraft:light_gray_concrete
fill 75 161 608 75 162 608 minecraft:light_gray_concrete
fill 75 161 610 75 162 610 minecraft:light_gray_concrete
fill 75 161 612 75 162 612 minecraft:light_gray_concrete
fill 76 161 605 76 162 605 minecraft:light_gray_concrete
fill 76 161 607 76 162 607 minecraft:light_gray_concrete
fill 76 161 609 76 162 609 minecraft:light_gray_concrete
fill 76 161 611 76 162 611 minecraft:light_gray_concrete
fill 76 161 613 76 162 613 minecraft:light_gray_concrete
fill 77 161 606 77 162 606 minecraft:light_gray_concrete
fill 77 161 608 77 162 608 minecraft:light_gray_concrete
fill 77 161 610 77 162 610 minecraft:light_gray_concrete
fill 77 161 612 77 162 612 minecraft:light_gray_concrete
fill 78 161 605 78 162 605 minecraft:light_gray_concrete
fill 78 161 607 78 162 607 minecraft:light_gray_concrete
fill 78 161 609 78 162 609 minecraft:light_gray_concrete
fill 78 161 611 78 162 611 minecraft:light_gray_concrete
fill 78 161 613 78 162 613 minecraft:light_gray_concrete
fill 83 161 608 83 162 608 minecraft:light_gray_concrete
fill 83 161 610 83 162 610 minecraft:light_gray_concrete
fill 83 161 612 83 162 612 minecraft:light_gray_concrete
fill 83 161 614 83 162 614 minecraft:light_gray_concrete
fill 83 161 616 83 162 616 minecraft:light_gray_concrete
fill 83 161 618 83 162 618 minecraft:light_gray_concrete
fill 83 161 620 83 162 620 minecraft:light_gray_concrete
fill 84 161 609 84 162 609 minecraft:light_gray_concrete
fill 84 161 611 84 162 611 minecraft:light_gray_concrete
fill 84 161 613 84 162 613 minecraft:light_gray_concrete
fill 84 161 615 84 162 615 minecraft:light_gray_concrete
fill 84 161 617 84 162 617 minecraft:light_gray_concrete
fill 84 161 619 84 162 619 minecraft:light_gray_concrete
fill 85 161 608 85 162 608 minecraft:light_gray_concrete
fill 85 161 610 85 162 610 minecraft:light_gray_concrete
fill 85 161 612 85 162 612 minecraft:light_gray_concrete
fill 85 161 614 85 162 614 minecraft:light_gray_concrete
fill 85 161 616 85 162 616 minecraft:light_gray_concrete
fill 85 161 618 85 162 618 minecraft:light_gray_concrete
fill 85 161 620 85 162 620 minecraft:light_gray_concrete
fill 86 161 609 86 162 609 minecraft:light_gray_concrete
fill 86 161 611 86 162 611 minecraft:light_gray_concrete
fill 86 161 613 86 162 613 minecraft:light_gray_concrete
fill 86 161 615 86 162 615 minecraft:light_gray_concrete
fill 86 161 617 86 162 617 minecraft:light_gray_concrete
fill 86 161 619 86 162 619 minecraft:light_gray_concrete
fill 87 161 608 87 162 608 minecraft:light_gray_concrete
fill 87 161 610 87 162 610 minecraft:light_gray_concrete
fill 87 161 612 87 162 612 minecraft:light_gray_concrete
fill 87 161 614 87 162 614 minecraft:light_gray_concrete
fill 87 161 616 87 162 616 minecraft:light_gray_concrete
fill 87 161 618 87 162 618 minecraft:light_gray_concrete
fill 87 161 620 87 162 620 minecraft:light_gray_concrete
fill 88 161 609 88 162 609 minecraft:light_gray_concrete
fill 88 161 611 88 162 611 minecraft:light_gray_concrete
fill 88 161 613 88 162 613 minecraft:light_gray_concrete
fill 88 161 615 88 162 615 minecraft:light_gray_concrete
fill 88 161 617 88 162 617 minecraft:light_gray_concrete
fill 88 161 619 88 162 619 minecraft:light_gray_concrete
fill 47 163 609 47 172 609 minecraft:black_concrete
fill 47 163 617 47 172 617 minecraft:black_concrete
fill 47 163 625 47 172 625 minecraft:black_concrete
fill 47 163 633 47 172 633 minecraft:black_concrete
fill 47 163 641 47 172 641 minecraft:black_concrete
fill 50 163 646 50 172 646 minecraft:black_concrete
fill 54 163 604 54 172 604 minecraft:black_concrete
fill 58 163 646 58 172 646 minecraft:black_concrete
fill 62 163 604 62 172 604 minecraft:black_concrete
fill 66 163 646 66 172 646 minecraft:black_concrete
fill 70 163 604 70 172 604 minecraft:black_concrete
fill 74 163 646 74 172 646 minecraft:black_concrete
fill 78 163 604 78 172 604 minecraft:black_concrete
fill 82 163 646 82 172 646 minecraft:black_concrete
fill 86 163 604 86 172 604 minecraft:black_concrete
fill 89 163 609 89 172 609 minecraft:black_concrete
fill 89 163 617 89 172 617 minecraft:black_concrete
fill 89 163 625 89 172 625 minecraft:black_concrete
fill 89 163 633 89 172 633 minecraft:black_concrete
fill 89 163 641 89 172 641 minecraft:black_concrete
fill 64 167 627 66 167 629 minecraft:redstone_block
fill 68 167 619 70 167 621 minecraft:redstone_block
fill 72 167 627 74 167 629 minecraft:redstone_block
fill 48 168 605 50 169 615 minecraft:black_concrete
fill 48 168 616 88 169 616 minecraft:magenta_concrete
fill 48 168 617 50 169 627 minecraft:black_concrete
fill 48 168 628 63 168 628 minecraft:magenta_concrete
fill 48 168 629 50 169 639 minecraft:black_concrete
fill 48 168 640 88 169 640 minecraft:magenta_concrete
fill 48 168 641 50 169 645 minecraft:black_concrete
fill 51 168 605 51 169 615 minecraft:light_gray_concrete
fill 51 168 617 51 169 627 minecraft:light_gray_concrete
fill 51 168 629 51 169 639 minecraft:light_gray_concrete
fill 51 168 641 51 169 645 minecraft:light_gray_concrete
fill 52 168 605 54 169 615 minecraft:black_concrete
fill 52 168 617 54 169 627 minecraft:black_concrete
fill 52 168 629 54 169 639 minecraft:black_concrete
fill 52 168 641 54 169 645 minecraft:black_concrete
fill 55 168 605 55 169 615 minecraft:light_gray_concrete
fill 55 168 617 55 169 627 minecraft:light_gray_concrete
fill 55 168 629 55 169 639 minecraft:light_gray_concrete
fill 55 168 641 55 169 645 minecraft:light_gray_concrete
fill 56 168 605 58 169 615 minecraft:black_concrete
fill 56 168 617 58 169 627 minecraft:black_concrete
fill 56 168 629 58 169 639 minecraft:black_concrete
fill 56 168 641 58 169 645 minecraft:black_concrete
fill 59 168 605 59 169 615 minecraft:light_gray_concrete
fill 59 168 617 59 169 627 minecraft:light_gray_concrete
fill 59 168 629 59 169 639 minecraft:light_gray_concrete
fill 59 168 641 59 169 645 minecraft:light_gray_concrete
fill 60 168 605 62 169 615 minecraft:black_concrete
fill 60 168 617 62 169 627 minecraft:black_concrete
fill 60 168 629 62 169 639 minecraft:black_concrete
fill 60 168 641 62 169 645 minecraft:black_concrete
fill 63 168 605 63 169 615 minecraft:light_gray_concrete
fill 63 168 617 63 168 627 minecraft:light_gray_concrete
fill 63 168 629 63 168 639 minecraft:light_gray_concrete
fill 63 168 641 63 169 645 minecraft:light_gray_concrete
fill 64 168 605 66 169 615 minecraft:black_concrete
fill 64 168 617 66 168 626 minecraft:black_concrete
fill 64 168 630 66 168 639 minecraft:black_concrete
fill 64 168 641 66 169 645 minecraft:black_concrete
fill 67 168 605 67 169 615 minecraft:light_gray_concrete
fill 67 168 617 67 168 627 minecraft:light_gray_concrete
fill 67 168 628 71 168 628 minecraft:magenta_concrete
fill 67 168 629 67 168 639 minecraft:light_gray_concrete
fill 67 168 641 67 169 645 minecraft:light_gray_concrete
fill 68 168 605 70 169 615 minecraft:black_concrete
fill 68 168 617 70 168 618 minecraft:black_concrete
fill 68 168 622 70 168 623 minecraft:black_concrete
fill 68 168 627 70 168 627 minecraft:black_concrete
fill 68 168 629 70 169 639 minecraft:black_concrete
fill 68 168 641 70 169 645 minecraft:black_concrete
fill 71 168 605 71 169 615 minecraft:light_gray_concrete
fill 71 168 617 71 168 627 minecraft:light_gray_concrete
fill 71 168 629 71 168 639 minecraft:light_gray_concrete
fill 71 168 641 71 169 645 minecraft:light_gray_concrete
fill 72 168 605 74 169 615 minecraft:black_concrete
fill 72 168 617 74 168 626 minecraft:black_concrete
fill 72 168 630 74 168 639 minecraft:black_concrete
fill 72 168 641 74 169 645 minecraft:black_concrete
fill 75 168 605 75 169 615 minecraft:light_gray_concrete
fill 75 168 617 75 168 627 minecraft:light_gray_concrete
fill 75 168 628 88 168 628 minecraft:magenta_concrete
fill 75 168 629 75 168 639 minecraft:light_gray_concrete
fill 75 168 641 75 169 645 minecraft:light_gray_concrete
fill 76 168 605 78 169 615 minecraft:black_concrete
fill 76 168 617 78 169 627 minecraft:black_concrete
fill 76 168 629 78 169 639 minecraft:black_concrete
fill 76 168 641 78 169 645 minecraft:black_concrete
fill 79 168 605 79 169 615 minecraft:light_gray_concrete
fill 79 168 617 79 169 627 minecraft:light_gray_concrete
fill 79 168 629 79 169 639 minecraft:light_gray_concrete
fill 79 168 641 79 169 645 minecraft:light_gray_concrete
fill 80 168 605 82 169 615 minecraft:black_concrete
fill 80 168 617 82 169 627 minecraft:black_concrete
fill 80 168 629 82 169 639 minecraft:black_concrete
fill 80 168 641 82 169 645 minecraft:black_concrete
fill 83 168 605 83 169 615 minecraft:light_gray_concrete
fill 83 168 617 83 169 627 minecraft:light_gray_concrete
fill 83 168 629 83 169 639 minecraft:light_gray_concrete
fill 83 168 641 83 169 645 minecraft:light_gray_concrete
fill 84 168 605 86 169 615 minecraft:black_concrete
fill 84 168 617 86 169 627 minecraft:black_concrete
fill 84 168 629 86 169 639 minecraft:black_concrete
fill 84 168 641 86 169 645 minecraft:black_concrete
fill 87 168 605 87 169 615 minecraft:light_gray_concrete
fill 87 168 617 87 169 627 minecraft:light_gray_concrete
fill 87 168 629 87 169 639 minecraft:light_gray_concrete
fill 87 168 641 87 169 645 minecraft:light_gray_concrete
fill 88 168 605 88 169 615 minecraft:black_concrete
fill 88 168 617 88 169 627 minecraft:black_concrete
fill 88 168 629 88 169 639 minecraft:black_concrete
fill 88 168 641 88 169 645 minecraft:black_concrete
fill 48 169 628 62 169 628 minecraft:magenta_concrete
fill 63 169 617 63 169 625 minecraft:light_gray_concrete
fill 63 169 626 63 169 630 minecraft:sea_lantern
fill 63 169 631 63 169 639 minecraft:light_gray_concrete
fill 64 169 617 66 169 625 minecraft:black_concrete
fill 64 169 626 67 169 626 minecraft:sea_lantern
fill 64 169 627 66 169 629 minecraft:black_concrete
fill 64 169 630 67 169 630 minecraft:sea_lantern
fill 64 169 631 66 169 639 minecraft:black_concrete
setblock 67 169 617 minecraft:light_gray_concrete
fill 67 169 618 67 169 625 minecraft:sea_lantern
fill 67 169 627 67 169 629 minecraft:sea_lantern
fill 67 169 631 67 169 639 minecraft:light_gray_concrete
fill 68 169 617 70 169 617 minecraft:black_concrete
fill 68 169 618 71 169 618 minecraft:sea_lantern
fill 68 169 619 70 169 621 minecraft:black_concrete
fill 68 169 622 71 169 623 minecraft:sea_lantern
fill 68 169 627 71 169 627 minecraft:sea_lantern
fill 68 169 628 70 169 628 minecraft:magenta_concrete
setblock 71 169 617 minecraft:light_gray_concrete
fill 71 169 619 71 169 621 minecraft:sea_lantern
fill 71 169 624 71 169 626 minecraft:sea_lantern
fill 71 169 628 71 169 630 minecraft:sea_lantern
fill 71 169 631 71 169 639 minecraft:light_gray_concrete
fill 72 169 617 74 169 625 minecraft:black_concrete
fill 72 169 626 75 169 626 minecraft:sea_lantern
fill 72 169 627 74 169 629 minecraft:black_concrete
fill 72 169 630 75 169 630 minecraft:sea_lantern
fill 72 169 631 74 169 639 minecraft:black_concrete
fill 75 169 617 75 169 625 minecraft:light_gray_concrete
fill 75 169 627 75 169 629 minecraft:sea_lantern
fill 75 169 631 75 169 639 minecraft:light_gray_concrete
fill 76 169 628 88 169 628 minecraft:magenta_concrete
fill 67 170 624 67 170 626 minecraft:lime_stained_glass
fill 68 170 623 70 170 623 minecraft:lime_stained_glass
fill 68 170 627 70 170 627 minecraft:lime_stained_glass
fill 71 170 624 71 170 626 minecraft:lime_stained_glass
fill 58 171 623 66 171 627 minecraft:light_gray_concrete
fill 59 171 620 79 171 622 minecraft:light_gray_concrete
fill 59 171 628 79 171 630 minecraft:light_gray_concrete
fill 60 171 619 78 174 619 minecraft:light_gray_concrete
fill 60 171 631 78 174 631 minecraft:light_gray_concrete
fill 61 171 618 77 174 618 minecraft:light_gray_concrete
fill 61 171 632 77 174 632 minecraft:light_gray_concrete
fill 62 171 617 76 174 617 minecraft:light_gray_concrete
fill 62 171 633 76 174 633 minecraft:light_gray_concrete
fill 63 171 616 75 174 616 minecraft:light_gray_concrete
fill 63 171 634 75 174 634 minecraft:light_gray_concrete
fill 64 171 615 74 174 615 minecraft:light_gray_concrete
fill 64 171 635 74 174 635 minecraft:light_gray_concrete
fill 67 171 614 71 174 614 minecraft:light_gray_concrete
fill 67 171 623 67 171 624 minecraft:light_gray_concrete
fill 67 171 626 67 171 627 minecraft:light_gray_concrete
fill 67 171 636 71 174 636 minecraft:light_gray_concrete
setblock 68 171 623 minecraft:light_gray_concrete
setblock 68 171 627 minecraft:light_gray_concrete
fill 70 171 623 80 171 623 minecraft:light_gray_concrete
fill 70 171 627 80 171 627 minecraft:light_gray_concrete
fill 71 171 624 80 171 624 minecraft:light_gray_concrete
fill 71 171 626 80 171 626 minecraft:light_gray_concrete
fill 72 171 625 80 171 625 minecraft:light_gray_concrete
fill 56 172 621 56 173 629 minecraft:sea_lantern
fill 57 172 619 57 173 622 minecraft:sea_lantern
fill 57 172 623 65 172 627 minecraft:light_gray_concrete
fill 57 172 628 57 173 631 minecraft:sea_lantern
fill 58 172 617 58 173 619 minecraft:sea_lantern
fill 58 172 620 68 172 622 minecraft:light_gray_concrete
fill 58 172 628 68 172 630 minecraft:light_gray_concrete
fill 58 172 631 58 173 633 minecraft:sea_lantern
fill 59 172 616 59 173 617 minecraft:sea_lantern
fill 59 172 618 59 173 619 minecraft:light_gray_concrete
fill 59 172 631 59 173 632 minecraft:light_gray_concrete
fill 59 172 633 59 173 634 minecraft:sea_lantern
fill 60 172 615 60 173 616 minecraft:sea_lantern
fill 60 172 617 60 173 618 minecraft:light_gray_concrete
fill 60 172 632 60 173 633 minecraft:light_gray_concrete
fill 60 172 634 60 173 635 minecraft:sea_lantern
fill 61 172 614 61 173 615 minecraft:sea_lantern
fill 61 172 616 61 173 617 minecraft:light_gray_concrete
fill 61 172 633 61 173 634 minecraft:light_gray_concrete
fill 61 172 635 61 173 636 minecraft:sea_lantern
fill 62 172 614 63 173 614 minecraft:sea_lantern
fill 62 172 615 62 173 616 minecraft:light_gray_concrete
fill 62 172 634 62 173 635 minecraft:light_gray_concrete
fill 62 172 636 63 173 636 minecraft:sea_lantern
fill 63 172 613 66 173 613 minecraft:sea_lantern
fill 63 172 615 63 173 615 minecraft:light_gray_concrete
fill 63 172 635 63 173 635 minecraft:light_gray_concrete
fill 63 172 637 66 173 637 minecraft:sea_lantern
fill 64 172 614 66 173 614 minecraft:light_gray_concrete
fill 64 172 636 66 173 636 minecraft:light_gray_concrete
fill 65 172 612 73 173 612 minecraft:sea_lantern
fill 65 172 638 73 173 638 minecraft:sea_lantern
fill 66 172 623 66 172 624 minecraft:light_gray_concrete
fill 66 172 625 66 175 625 minecraft:light_blue_stained_glass
fill 66 172 626 66 172 627 minecraft:light_gray_concrete
fill 67 172 613 71 173 613 minecraft:light_gray_concrete
fill 67 172 623 67 174 623 minecraft:light_blue_stained_glass
fill 67 172 627 67 174 627 minecraft:light_blue_stained_glass
fill 67 172 637 71 173 637 minecraft:light_gray_concrete
fill 69 172 620 80 172 621 minecraft:light_gray_concrete
fill 69 172 622 69 175 622 minecraft:light_blue_stained_glass
fill 69 172 628 69 175 628 minecraft:light_blue_stained_glass
fill 69 172 629 80 172 630 minecraft:light_gray_concrete
fill 70 172 622 80 172 622 minecraft:light_gray_concrete
fill 70 172 628 80 172 628 minecraft:light_gray_concrete
fill 71 172 623 71 174 623 minecraft:light_blue_stained_glass
fill 71 172 627 71 174 627 minecraft:light_blue_stained_glass
fill 72 172 613 75 173 613 minecraft:sea_lantern
fill 72 172 614 74 173 614 minecraft:light_gray_concrete
fill 72 172 623 81 172 624 minecraft:light_gray_concrete
fill 72 172 625 72 175 625 minecraft:light_blue_stained_glass
fill 72 172 626 81 172 627 minecraft:light_gray_concrete
fill 72 172 636 74 173 636 minecraft:light_gray_concrete
fill 72 172 637 75 173 637 minecraft:sea_lantern
fill 73 172 625 81 172 625 minecraft:light_gray_concrete
fill 75 172 614 77 173 614 minecraft:sea_lantern
fill 75 172 615 76 173 615 minecraft:light_gray_concrete
fill 75 172 635 76 173 635 minecraft:light_gray_concrete
fill 75 172 636 77 173 636 minecraft:sea_lantern
fill 76 172 616 77 173 616 minecraft:light_gray_concrete
fill 76 172 634 77 173 634 minecraft:light_gray_concrete
fill 77 172 615 78 173 615 minecraft:sea_lantern
fill 77 172 617 78 173 617 minecraft:light_gray_concrete
fill 77 172 633 78 173 633 minecraft:light_gray_concrete
fill 77 172 635 78 173 635 minecraft:sea_lantern
fill 78 172 616 79 173 616 minecraft:sea_lantern
fill 78 172 618 79 173 618 minecraft:light_gray_concrete
fill 78 172 632 79 173 632 minecraft:light_gray_concrete
fill 78 172 634 79 173 634 minecraft:sea_lantern
fill 79 172 617 80 173 617 minecraft:sea_lantern
fill 79 172 619 79 173 619 minecraft:light_gray_concrete
fill 79 172 631 79 173 631 minecraft:light_gray_concrete
fill 79 172 633 80 173 633 minecraft:sea_lantern
fill 80 172 618 80 173 619 minecraft:sea_lantern
fill 80 172 631 80 173 632 minecraft:sea_lantern
fill 81 172 619 81 173 622 minecraft:sea_lantern
fill 81 172 628 81 173 631 minecraft:sea_lantern
fill 82 172 621 82 173 629 minecraft:sea_lantern
fill 47 173 609 47 177 609 minecraft:sea_lantern
fill 47 173 617 47 177 617 minecraft:sea_lantern
fill 47 173 625 47 177 625 minecraft:sea_lantern
fill 47 173 633 47 177 633 minecraft:sea_lantern
fill 47 173 641 47 177 641 minecraft:sea_lantern
fill 48 173 611 48 213 612 minecraft:light_gray_concrete
fill 48 173 619 48 174 633 minecraft:light_gray_concrete
fill 48 173 635 48 225 636 minecraft:light_gray_concrete
fill 48 173 643 48 225 644 minecraft:light_gray_concrete
fill 49 173 605 50 213 605 minecraft:light_gray_concrete
fill 49 173 621 54 174 633 minecraft:light_gray_concrete
fill 50 173 646 50 177 646 minecraft:sea_lantern
fill 54 173 604 54 177 604 minecraft:sea_lantern
fill 54 173 645 55 225 645 minecraft:light_gray_concrete
fill 57 173 605 58 204 605 minecraft:light_gray_concrete
fill 57 173 623 64 173 627 minecraft:light_gray_concrete
fill 58 173 620 65 173 622 minecraft:light_gray_concrete
fill 58 173 628 65 173 630 minecraft:light_gray_concrete
fill 58 173 646 58 177 646 minecraft:sea_lantern
fill 62 173 604 62 177 604 minecraft:sea_lantern
fill 62 173 645 63 225 645 minecraft:light_gray_concrete
fill 65 173 605 66 225 605 minecraft:light_gray_concrete
fill 65 173 623 65 177 627 minecraft:light_blue_stained_glass
fill 66 173 620 66 173 621 minecraft:light_gray_concrete
fill 66 173 622 66 176 624 minecraft:light_blue_stained_glass
fill 66 173 626 66 176 628 minecraft:light_blue_stained_glass
fill 66 173 629 66 173 630 minecraft:light_gray_concrete
fill 66 173 646 66 177 646 minecraft:sea_lantern
fill 67 173 620 80 173 620 minecraft:light_gray_concrete
fill 67 173 621 68 176 622 minecraft:light_blue_stained_glass
fill 67 173 628 68 176 629 minecraft:light_blue_stained_glass
fill 67 173 630 80 173 630 minecraft:light_gray_concrete
fill 69 173 621 71 177 621 minecraft:light_blue_stained_glass
fill 69 173 629 71 177 629 minecraft:light_blue_stained_glass
fill 70 173 604 70 177 604 minecraft:sea_lantern
fill 70 173 622 72 176 622 minecraft:light_blue_stained_glass
fill 70 173 628 72 176 628 minecraft:light_blue_stained_glass
fill 70 173 645 71 225 645 minecraft:light_gray_concrete
fill 72 173 621 80 173 621 minecraft:light_gray_concrete
fill 72 173 623 73 176 624 minecraft:light_blue_stained_glass
fill 72 173 626 73 176 627 minecraft:light_blue_stained_glass
fill 72 173 629 80 173 629 minecraft:light_gray_concrete
fill 73 173 605 74 225 605 minecraft:light_gray_concrete
fill 73 173 622 80 173 622 minecraft:light_gray_concrete
fill 73 173 625 73 177 625 minecraft:light_blue_stained_glass
fill 73 173 628 80 173 628 minecraft:light_gray_concrete
fill 74 173 623 81 173 627 minecraft:light_gray_concrete
fill 74 173 646 74 177 646 minecraft:sea_lantern
fill 76 173 605 84 174 611 minecraft:light_gray_concrete
fill 78 173 604 78 177 604 minecraft:sea_lantern
fill 78 173 645 79 225 645 minecraft:light_gray_concrete
fill 82 173 646 82 177 646 minecraft:sea_lantern
fill 86 173 604 86 177 604 minecraft:sea_lantern
fill 86 173 645 87 225 645 minecraft:light_gray_concrete
fill 88 173 606 88 225 607 minecraft:light_gray_concrete
fill 88 173 614 88 225 615 minecraft:light_gray_concrete
fill 88 173 622 88 201 623 minecraft:light_gray_concrete
fill 88 173 630 88 225 631 minecraft:light_gray_concrete
fill 88 173 638 88 225 639 minecraft:light_gray_concrete
fill 89 173 609 89 177 609 minecraft:sea_lantern
fill 89 173 617 89 177 617 minecraft:sea_lantern
fill 89 173 625 89 177 625 minecraft:sea_lantern
fill 89 173 633 89 177 633 minecraft:sea_lantern
fill 89 173 641 89 177 641 minecraft:sea_lantern
fill 58 174 623 63 174 627 minecraft:light_gray_concrete
fill 59 174 620 64 174 622 minecraft:light_gray_concrete
fill 59 174 628 64 174 630 minecraft:light_gray_concrete
fill 64 174 623 64 176 627 minecraft:light_blue_stained_glass
fill 65 174 620 66 174 620 minecraft:light_gray_concrete
fill 65 174 621 65 176 622 minecraft:light_blue_stained_glass
fill 65 174 628 65 176 629 minecraft:light_blue_stained_glass
fill 65 174 630 66 174 630 minecraft:light_gray_concrete
fill 66 174 621 66 176 621 minecraft:light_blue_stained_glass
fill 66 174 629 66 176 629 minecraft:light_blue_stained_glass
fill 67 174 620 71 176 620 minecraft:light_blue_stained_glass
fill 67 174 630 71 176 630 minecraft:light_blue_stained_glass
fill 72 174 620 79 174 620 minecraft:light_gray_concrete
fill 72 174 621 73 176 621 minecraft:light_blue_stained_glass
fill 72 174 629 73 176 629 minecraft:light_blue_stained_glass
fill 72 174 630 79 174 630 minecraft:light_gray_concrete
fill 73 174 622 73 176 622 minecraft:light_blue_stained_glass
fill 73 174 628 73 176 628 minecraft:light_blue_stained_glass
fill 74 174 621 79 174 622 minecraft:light_gray_concrete
fill 74 174 623 74 176 627 minecraft:light_blue_stained_glass
fill 74 174 628 79 174 629 minecraft:light_gray_concrete
fill 75 174 623 80 174 627 minecraft:light_gray_concrete
fill 48 175 619 48 210 620 minecraft:light_gray_concrete
setblock 48 175 621 minecraft:sea_lantern
fill 48 175 622 48 189 622 minecraft:light_gray_concrete
setblock 48 175 623 minecraft:sea_lantern
fill 48 175 624 48 189 624 minecraft:light_gray_concrete
setblock 48 175 625 minecraft:sea_lantern
fill 48 175 626 48 189 626 minecraft:light_gray_concrete
setblock 48 175 627 minecraft:sea_lantern
fill 48 175 628 48 225 628 minecraft:light_gray_concrete
setblock 48 175 629 minecraft:sea_lantern
fill 48 175 630 48 189 630 minecraft:light_gray_concrete
setblock 48 175 631 minecraft:sea_lantern
fill 48 175 632 48 189 632 minecraft:light_gray_concrete
setblock 48 175 633 minecraft:sea_lantern
fill 49 175 621 49 189 621 minecraft:light_gray_concrete
setblock 49 175 622 minecraft:sea_lantern
fill 49 175 623 49 189 623 minecraft:light_gray_concrete
setblock 49 175 624 minecraft:sea_lantern
fill 49 175 625 49 189 625 minecraft:light_gray_concrete
setblock 49 175 626 minecraft:sea_lantern
fill 49 175 627 49 189 627 minecraft:light_gray_concrete
setblock 49 175 628 minecraft:sea_lantern
fill 49 175 629 49 189 629 minecraft:light_gray_concrete
setblock 49 175 630 minecraft:sea_lantern
fill 49 175 631 49 189 631 minecraft:light_gray_concrete
setblock 49 175 632 minecraft:sea_lantern
fill 49 175 633 49 189 633 minecraft:light_gray_concrete
setblock 50 175 621 minecraft:sea_lantern
fill 50 175 622 50 189 622 minecraft:light_gray_concrete
setblock 50 175 623 minecraft:sea_lantern
fill 50 175 624 50 189 624 minecraft:light_gray_concrete
setblock 50 175 625 minecraft:sea_lantern
fill 50 175 626 50 189 626 minecraft:light_gray_concrete
setblock 50 175 627 minecraft:sea_lantern
fill 50 175 628 50 189 628 minecraft:light_gray_concrete
setblock 50 175 629 minecraft:sea_lantern
fill 50 175 630 50 189 630 minecraft:light_gray_concrete
setblock 50 175 631 minecraft:sea_lantern
fill 50 175 632 50 189 632 minecraft:light_gray_concrete
setblock 50 175 633 minecraft:sea_lantern
fill 51 175 621 51 189 621 minecraft:light_gray_concrete
setblock 51 175 622 minecraft:sea_lantern
fill 51 175 623 51 189 623 minecraft:light_gray_concrete
setblock 51 175 624 minecraft:sea_lantern
fill 51 175 625 51 189 625 minecraft:light_gray_concrete
setblock 51 175 626 minecraft:sea_lantern
fill 51 175 627 51 189 627 minecraft:light_gray_concrete
setblock 51 175 628 minecraft:sea_lantern
fill 51 175 629 51 189 629 minecraft:light_gray_concrete
setblock 51 175 630 minecraft:sea_lantern
fill 51 175 631 51 189 631 minecraft:light_gray_concrete
setblock 51 175 632 minecraft:sea_lantern
fill 51 175 633 51 189 633 minecraft:light_gray_concrete
setblock 52 175 621 minecraft:sea_lantern
fill 52 175 622 52 189 622 minecraft:light_gray_concrete
setblock 52 175 623 minecraft:sea_lantern
fill 52 175 624 52 189 624 minecraft:light_gray_concrete
setblock 52 175 625 minecraft:sea_lantern
fill 52 175 626 52 189 626 minecraft:light_gray_concrete
setblock 52 175 627 minecraft:sea_lantern
fill 52 175 628 52 189 628 minecraft:light_gray_concrete
setblock 52 175 629 minecraft:sea_lantern
fill 52 175 630 52 189 630 minecraft:light_gray_concrete
setblock 52 175 631 minecraft:sea_lantern
fill 52 175 632 52 189 632 minecraft:light_gray_concrete
setblock 52 175 633 minecraft:sea_lantern
fill 53 175 621 53 189 621 minecraft:light_gray_concrete
setblock 53 175 622 minecraft:sea_lantern
fill 53 175 623 53 189 623 minecraft:light_gray_concrete
setblock 53 175 624 minecraft:sea_lantern
fill 53 175 625 53 189 625 minecraft:light_gray_concrete
setblock 53 175 626 minecraft:sea_lantern
fill 53 175 627 53 189 627 minecraft:light_gray_concrete
setblock 53 175 628 minecraft:sea_lantern
fill 53 175 629 53 189 629 minecraft:light_gray_concrete
setblock 53 175 630 minecraft:sea_lantern
fill 53 175 631 53 189 631 minecraft:light_gray_concrete
setblock 53 175 632 minecraft:sea_lantern
fill 53 175 633 53 189 633 minecraft:light_gray_concrete
setblock 54 175 621 minecraft:sea_lantern
fill 54 175 622 54 189 622 minecraft:light_gray_concrete
setblock 54 175 623 minecraft:sea_lantern
fill 54 175 624 54 189 624 minecraft:light_gray_concrete
setblock 54 175 625 minecraft:sea_lantern
fill 54 175 626 54 189 626 minecraft:light_gray_concrete
setblock 54 175 627 minecraft:sea_lantern
fill 54 175 628 54 189 628 minecraft:light_gray_concrete
setblock 54 175 629 minecraft:sea_lantern
fill 54 175 630 54 189 630 minecraft:light_gray_concrete
setblock 54 175 631 minecraft:sea_lantern
fill 54 175 632 54 189 632 minecraft:light_gray_concrete
setblock 54 175 633 minecraft:sea_lantern
setblock 63 175 625 minecraft:light_blue_stained_glass
setblock 64 175 622 minecraft:light_blue_stained_glass
setblock 64 175 628 minecraft:light_blue_stained_glass
setblock 66 175 620 minecraft:light_blue_stained_glass
setblock 66 175 630 minecraft:light_blue_stained_glass
setblock 69 175 619 minecraft:light_blue_stained_glass
setblock 69 175 631 minecraft:light_blue_stained_glass
setblock 72 175 620 minecraft:light_blue_stained_glass
setblock 72 175 630 minecraft:light_blue_stained_glass
setblock 74 175 622 minecraft:light_blue_stained_glass
setblock 74 175 628 minecraft:light_blue_stained_glass
setblock 75 175 625 minecraft:light_blue_stained_glass
setblock 76 175 605 minecraft:sea_lantern
fill 76 175 606 76 193 606 minecraft:light_gray_concrete
setblock 76 175 607 minecraft:sea_lantern
fill 76 175 608 76 193 608 minecraft:light_gray_concrete
setblock 76 175 609 minecraft:sea_lantern
fill 76 175 610 76 193 610 minecraft:light_gray_concrete
setblock 76 175 611 minecraft:sea_lantern
fill 77 175 605 77 193 605 minecraft:light_gray_concrete
setblock 77 175 606 minecraft:sea_lantern
fill 77 175 607 77 193 607 minecraft:light_gray_concrete
setblock 77 175 608 minecraft:sea_lantern
fill 77 175 609 77 193 609 minecraft:light_gray_concrete
setblock 77 175 610 minecraft:sea_lantern
fill 77 175 611 77 193 611 minecraft:light_gray_concrete
setblock 78 175 605 minecraft:sea_lantern
fill 78 175 606 78 193 606 minecraft:light_gray_concrete
setblock 78 175 607 minecraft:sea_lantern
fill 78 175 608 78 193 608 minecraft:light_gray_concrete
setblock 78 175 609 minecraft:sea_lantern
fill 78 175 610 78 193 610 minecraft:light_gray_concrete
setblock 78 175 611 minecraft:sea_lantern
fill 79 175 605 79 193 605 minecraft:light_gray_concrete
setblock 79 175 606 minecraft:sea_lantern
fill 79 175 607 79 193 607 minecraft:light_gray_concrete
setblock 79 175 608 minecraft:sea_lantern
fill 79 175 609 79 193 609 minecraft:light_gray_concrete
setblock 79 175 610 minecraft:sea_lantern
fill 79 175 611 79 193 611 minecraft:light_gray_concrete
setblock 80 175 605 minecraft:sea_lantern
fill 80 175 606 80 193 606 minecraft:light_gray_concrete
setblock 80 175 607 minecraft:sea_lantern
fill 80 175 608 80 193 608 minecraft:light_gray_concrete
setblock 80 175 609 minecraft:sea_lantern
fill 80 175 610 80 193 610 minecraft:light_gray_concrete
setblock 80 175 611 minecraft:sea_lantern
fill 81 175 605 81 225 605 minecraft:light_gray_concrete
setblock 81 175 606 minecraft:sea_lantern
fill 81 175 607 81 193 607 minecraft:light_gray_concrete
setblock 81 175 608 minecraft:sea_lantern
fill 81 175 609 81 193 609 minecraft:light_gray_concrete
setblock 81 175 610 minecraft:sea_lantern
fill 81 175 611 81 193 611 minecraft:light_gray_concrete
setblock 82 175 605 minecraft:sea_lantern
fill 82 175 606 82 193 606 minecraft:light_gray_concrete
setblock 82 175 607 minecraft:sea_lantern
fill 82 175 608 82 193 608 minecraft:light_gray_concrete
setblock 82 175 609 minecraft:sea_lantern
fill 82 175 610 82 193 610 minecraft:light_gray_concrete
setblock 82 175 611 minecraft:sea_lantern
fill 83 175 605 83 193 605 minecraft:light_gray_concrete
setblock 83 175 606 minecraft:sea_lantern
fill 83 175 607 83 193 607 minecraft:light_gray_concrete
setblock 83 175 608 minecraft:sea_lantern
fill 83 175 609 83 193 609 minecraft:light_gray_concrete
setblock 83 175 610 minecraft:sea_lantern
fill 83 175 611 83 193 611 minecraft:light_gray_concrete
setblock 84 175 605 minecraft:sea_lantern
fill 84 175 606 84 193 606 minecraft:light_gray_concrete
setblock 84 175 607 minecraft:sea_lantern
fill 84 175 608 84 193 608 minecraft:light_gray_concrete
setblock 84 175 609 minecraft:sea_lantern
fill 84 175 610 84 193 610 minecraft:light_gray_concrete
setblock 84 175 611 minecraft:sea_lantern
fill 48 176 621 48 177 621 minecraft:light_gray_concrete
fill 48 176 623 48 177 623 minecraft:light_gray_concrete
fill 48 176 625 48 177 625 minecraft:light_gray_concrete
fill 48 176 627 48 177 627 minecraft:light_gray_concrete
fill 48 176 629 48 177 629 minecraft:light_gray_concrete
fill 48 176 631 48 177 631 minecraft:light_gray_concrete
fill 48 176 633 48 177 633 minecraft:light_gray_concrete
fill 49 176 622 49 177 622 minecraft:light_gray_concrete
fill 49 176 624 49 177 624 minecraft:light_gray_concrete
fill 49 176 626 49 177 626 minecraft:light_gray_concrete
fill 49 176 628 49 177 628 minecraft:light_gray_concrete
fill 49 176 630 49 177 630 minecraft:light_gray_concrete
fill 49 176 632 49 177 632 minecraft:light_gray_concrete
setblock 50 176 607 minecraft:light[level=14]
setblock 50 176 615 minecraft:light[level=14]
fill 50 176 621 50 177 621 minecraft:light_gray_concrete
fill 50 176 623 50 177 623 minecraft:light_gray_concrete
fill 50 176 625 50 177 625 minecraft:light_gray_concrete
fill 50 176 627 50 177 627 minecraft:light_gray_concrete
fill 50 176 629 50 177 629 minecraft:light_gray_concrete
fill 50 176 631 50 177 631 minecraft:light_gray_concrete
fill 50 176 633 50 177 633 minecraft:light_gray_concrete
setblock 50 176 639 minecraft:light[level=14]
fill 51 176 622 51 177 622 minecraft:light_gray_concrete
fill 51 176 624 51 177 624 minecraft:light_gray_concrete
fill 51 176 626 51 177 626 minecraft:light_gray_concrete
fill 51 176 628 51 177 628 minecraft:light_gray_concrete
fill 51 176 630 51 177 630 minecraft:light_gray_concrete
fill 51 176 632 51 177 632 minecraft:light_gray_concrete
fill 52 176 621 52 177 621 minecraft:light_gray_concrete
fill 52 176 623 52 177 623 minecraft:light_gray_concrete
fill 52 176 625 52 177 625 minecraft:light_gray_concrete
fill 52 176 627 52 177 627 minecraft:light_gray_concrete
fill 52 176 629 52 177 629 minecraft:light_gray_concrete
fill 52 176 631 52 177 631 minecraft:light_gray_concrete
fill 52 176 633 52 177 633 minecraft:light_gray_concrete
fill 53 176 622 53 177 622 minecraft:light_gray_concrete
fill 53 176 624 53 177 624 minecraft:light_gray_concrete
fill 53 176 626 53 177 626 minecraft:light_gray_concrete
fill 53 176 628 53 177 628 minecraft:light_gray_concrete
fill 53 176 630 53 177 630 minecraft:light_gray_concrete
fill 53 176 632 53 177 632 minecraft:light_gray_concrete
fill 54 176 621 54 177 621 minecraft:light_gray_concrete
fill 54 176 623 54 177 623 minecraft:light_gray_concrete
fill 54 176 625 54 177 625 minecraft:light_gray_concrete
fill 54 176 627 54 177 627 minecraft:light_gray_concrete
fill 54 176 629 54 177 629 minecraft:light_gray_concrete
fill 54 176 631 54 177 631 minecraft:light_gray_concrete
fill 54 176 633 54 177 633 minecraft:light_gray_concrete
setblock 58 176 607 minecraft:light[level=14]
setblock 58 176 615 minecraft:light[level=14]
setblock 58 176 623 minecraft:light[level=14]
setblock 58 176 631 minecraft:light[level=14]
setblock 58 176 639 minecraft:light[level=14]
setblock 66 176 607 minecraft:light[level=14]
setblock 66 176 615 minecraft:light[level=14]
setblock 66 176 631 minecraft:light[level=14]
setblock 66 176 639 minecraft:light[level=14]
setblock 74 176 607 minecraft:light[level=14]
setblock 74 176 615 minecraft:light[level=14]
setblock 74 176 631 minecraft:light[level=14]
setblock 74 176 639 minecraft:light[level=14]
fill 76 176 605 76 177 605 minecraft:light_gray_concrete
fill 76 176 607 76 177 607 minecraft:light_gray_concrete
fill 76 176 609 76 177 609 minecraft:light_gray_concrete
fill 76 176 611 76 177 611 minecraft:light_gray_concrete
fill 77 176 606 77 177 606 minecraft:light_gray_concrete
fill 77 176 608 77 177 608 minecraft:light_gray_concrete
fill 77 176 610 77 177 610 minecraft:light_gray_concrete
fill 78 176 605 78 177 605 minecraft:light_gray_concrete
fill 78 176 607 78 177 607 minecraft:light_gray_concrete
fill 78 176 609 78 177 609 minecraft:light_gray_concrete
fill 78 176 611 78 177 611 minecraft:light_gray_concrete
fill 79 176 606 79 177 606 minecraft:light_gray_concrete
fill 79 176 608 79 177 608 minecraft:light_gray_concrete
fill 79 176 610 79 177 610 minecraft:light_gray_concrete
fill 80 176 605 80 177 605 minecraft:light_gray_concrete
fill 80 176 607 80 177 607 minecraft:light_gray_concrete
fill 80 176 609 80 177 609 minecraft:light_gray_concrete
fill 80 176 611 80 177 611 minecraft:light_gray_concrete
fill 81 176 606 81 177 606 minecraft:light_gray_concrete
fill 81 176 608 81 177 608 minecraft:light_gray_concrete
fill 81 176 610 81 177 610 minecraft:light_gray_concrete
fill 82 176 605 82 177 605 minecraft:light_gray_concrete
fill 82 176 607 82 177 607 minecraft:light_gray_concrete
fill 82 176 609 82 177 609 minecraft:light_gray_concrete
fill 82 176 611 82 177 611 minecraft:light_gray_concrete
setblock 82 176 615 minecraft:light[level=14]
setblock 82 176 623 minecraft:light[level=14]
setblock 82 176 631 minecraft:light[level=14]
setblock 82 176 639 minecraft:light[level=14]
fill 83 176 606 83 177 606 minecraft:light_gray_concrete
fill 83 176 608 83 177 608 minecraft:light_gray_concrete
fill 83 176 610 83 177 610 minecraft:light_gray_concrete
fill 84 176 605 84 177 605 minecraft:light_gray_concrete
fill 84 176 607 84 177 607 minecraft:light_gray_concrete
fill 84 176 609 84 177 609 minecraft:light_gray_concrete
fill 84 176 611 84 177 611 minecraft:light_gray_concrete
fill 66 177 622 66 177 623 minecraft:light_blue_stained_glass
fill 66 177 627 66 177 628 minecraft:light_blue_stained_glass
fill 67 177 621 67 177 622 minecraft:light_blue_stained_glass
fill 67 177 628 67 177 629 minecraft:light_blue_stained_glass
setblock 68 177 621 minecraft:light_blue_stained_glass
setblock 68 177 629 minecraft:light_blue_stained_glass
fill 71 177 622 72 177 622 minecraft:light_blue_stained_glass
fill 71 177 628 72 177 628 minecraft:light_blue_stained_glass
fill 72 177 623 73 177 623 minecraft:light_blue_stained_glass
fill 72 177 627 73 177 627 minecraft:light_blue_stained_glass
setblock 73 177 624 minecraft:light_blue_stained_glass
setblock 73 177 626 minecraft:light_blue_stained_glass
fill 47 178 609 47 185 609 minecraft:black_concrete
fill 47 178 617 47 185 617 minecraft:black_concrete
fill 47 178 625 47 185 625 minecraft:black_concrete
fill 47 178 633 47 185 633 minecraft:black_concrete
schedule function dropper:buildpart/145_2 1t
