fill 512 196 416 512 201 416 minecraft:netherrack
fill 512 196 417 512 196 418 minecraft:orange_concrete
fill 512 196 419 512 197 420 minecraft:netherrack
fill 512 196 421 512 197 421 minecraft:orange_concrete
fill 512 196 427 512 201 428 minecraft:netherrack
fill 512 196 429 512 197 430 minecraft:orange_concrete
fill 512 196 437 512 199 437 minecraft:netherrack
setblock 512 196 438 minecraft:orange_concrete
fill 512 196 439 512 201 440 minecraft:netherrack
fill 512 196 441 512 197 442 minecraft:orange_concrete
fill 512 196 447 512 201 448 minecraft:netherrack
fill 512 196 449 512 196 450 minecraft:orange_concrete
fill 512 196 451 512 201 451 minecraft:netherrack
fill 512 196 458 512 197 458 minecraft:orange_concrete
fill 470 197 424 470 197 425 minecraft:orange_concrete
setblock 470 197 428 minecraft:orange_concrete
fill 470 197 429 470 200 429 minecraft:netherrack
fill 470 197 440 470 200 440 minecraft:netherrack
setblock 470 197 445 minecraft:orange_concrete
setblock 470 197 456 minecraft:orange_concrete
fill 472 197 458 473 200 458 minecraft:netherrack
setblock 477 197 416 minecraft:orange_concrete
fill 482 197 416 482 200 416 minecraft:netherrack
fill 482 197 417 484 197 418 minecraft:magma_block
fill 489 197 421 489 203 423 minecraft:red_nether_bricks
setblock 489 197 458 minecraft:orange_concrete
fill 490 197 424 490 202 424 minecraft:red_nether_bricks
fill 491 197 420 491 200 420 minecraft:red_nether_bricks
setblock 492 197 458 minecraft:orange_concrete
fill 493 197 416 493 200 416 minecraft:netherrack
fill 493 197 458 493 200 458 minecraft:netherrack
setblock 494 197 416 minecraft:orange_concrete
setblock 495 197 423 minecraft:red_nether_bricks
fill 497 197 416 498 197 416 minecraft:orange_concrete
setblock 500 197 458 minecraft:orange_concrete
fill 504 197 458 504 200 458 minecraft:netherrack
fill 512 197 417 512 199 418 minecraft:netherrack
setblock 512 197 422 minecraft:orange_concrete
setblock 512 197 433 minecraft:orange_concrete
fill 512 197 438 512 199 438 minecraft:netherrack
fill 512 197 449 512 200 449 minecraft:netherrack
setblock 512 197 450 minecraft:orange_concrete
fill 512 197 453 512 197 454 minecraft:orange_concrete
fill 470 198 416 470 203 417 minecraft:netherrack
fill 470 198 423 470 199 423 minecraft:orange_concrete
fill 470 198 424 470 203 425 minecraft:netherrack
setblock 470 198 426 minecraft:orange_concrete
fill 470 198 428 470 203 428 minecraft:netherrack
fill 470 198 434 470 199 435 minecraft:orange_concrete
fill 470 198 436 470 203 437 minecraft:netherrack
fill 470 198 445 470 203 445 minecraft:netherrack
fill 470 198 446 470 198 447 minecraft:orange_concrete
fill 470 198 448 470 203 449 minecraft:netherrack
fill 470 198 454 470 199 455 minecraft:orange_concrete
fill 470 198 456 470 203 457 minecraft:netherrack
setblock 470 198 458 minecraft:orange_concrete
fill 471 198 417 473 198 417 minecraft:red_nether_bricks
fill 471 198 419 471 198 421 minecraft:red_nether_bricks
fill 471 198 423 471 198 425 minecraft:red_nether_bricks
fill 471 198 427 471 198 429 minecraft:red_nether_bricks
fill 471 198 431 471 198 433 minecraft:red_nether_bricks
fill 471 198 435 471 198 437 minecraft:red_nether_bricks
fill 471 198 439 471 198 441 minecraft:red_nether_bricks
fill 471 198 443 471 198 445 minecraft:red_nether_bricks
fill 471 198 447 471 198 449 minecraft:red_nether_bricks
fill 471 198 451 471 198 453 minecraft:red_nether_bricks
fill 471 198 455 471 198 457 minecraft:red_nether_bricks
fill 473 198 416 474 203 416 minecraft:netherrack
fill 473 198 457 475 198 457 minecraft:red_nether_bricks
fill 475 198 416 476 198 416 minecraft:orange_concrete
fill 475 198 417 477 198 417 minecraft:red_nether_bricks
fill 477 198 416 477 203 416 minecraft:netherrack
fill 477 198 457 479 198 457 minecraft:red_nether_bricks
fill 478 198 458 479 199 458 minecraft:orange_concrete
fill 479 198 417 481 198 417 minecraft:red_nether_bricks
fill 480 198 458 481 203 458 minecraft:netherrack
fill 481 198 418 485 199 418 minecraft:magma_block
fill 481 198 457 483 198 457 minecraft:red_nether_bricks
fill 482 198 417 482 200 417 minecraft:magma_block
fill 482 198 419 484 200 419 minecraft:magma_block
fill 483 198 417 485 198 417 minecraft:red_nether_bricks
fill 485 198 416 486 203 416 minecraft:netherrack
fill 485 198 457 487 198 457 minecraft:red_nether_bricks
fill 487 198 416 488 199 416 minecraft:orange_concrete
fill 487 198 417 489 198 417 minecraft:red_nether_bricks
fill 487 198 458 487 199 458 minecraft:orange_concrete
fill 488 198 422 488 205 423 minecraft:red_nether_bricks
fill 489 198 424 489 203 424 minecraft:red_nether_bricks
fill 489 198 457 491 198 457 minecraft:red_nether_bricks
fill 489 198 458 489 203 458 minecraft:netherrack
fill 490 198 420 490 201 420 minecraft:red_nether_bricks
fill 490 198 458 491 198 458 minecraft:orange_concrete
fill 491 198 417 493 198 417 minecraft:red_nether_bricks
fill 492 198 458 492 203 458 minecraft:netherrack
fill 493 198 457 495 198 457 minecraft:red_nether_bricks
fill 494 198 416 494 203 416 minecraft:netherrack
fill 495 198 417 497 198 417 minecraft:red_nether_bricks
setblock 496 198 416 minecraft:orange_concrete
fill 497 198 416 498 203 416 minecraft:netherrack
fill 497 198 457 499 198 457 minecraft:red_nether_bricks
fill 498 198 458 499 199 458 minecraft:orange_concrete
fill 499 198 416 499 199 416 minecraft:orange_concrete
fill 499 198 417 501 198 417 minecraft:red_nether_bricks
fill 500 198 458 501 203 458 minecraft:netherrack
fill 501 198 457 503 198 457 minecraft:red_nether_bricks
fill 503 198 417 505 198 417 minecraft:red_nether_bricks
fill 505 198 416 506 203 416 minecraft:netherrack
fill 505 198 457 507 198 457 minecraft:red_nether_bricks
fill 507 198 416 508 199 416 minecraft:orange_concrete
fill 507 198 417 509 198 417 minecraft:red_nether_bricks
fill 509 198 457 511 198 457 minecraft:red_nether_bricks
fill 510 198 458 511 198 458 minecraft:orange_concrete
fill 511 198 417 511 198 419 minecraft:red_nether_bricks
fill 511 198 421 511 198 423 minecraft:red_nether_bricks
fill 511 198 425 511 198 427 minecraft:red_nether_bricks
fill 511 198 429 511 198 431 minecraft:red_nether_bricks
fill 511 198 433 511 198 435 minecraft:red_nether_bricks
fill 511 198 437 511 198 439 minecraft:red_nether_bricks
fill 511 198 441 511 198 443 minecraft:red_nether_bricks
fill 511 198 445 511 198 447 minecraft:red_nether_bricks
fill 511 198 449 511 198 451 minecraft:red_nether_bricks
fill 511 198 453 511 198 455 minecraft:red_nether_bricks
fill 512 198 419 512 201 419 minecraft:netherrack
setblock 512 198 420 minecraft:orange_concrete
fill 512 198 421 512 203 422 minecraft:netherrack
fill 512 198 423 512 199 424 minecraft:orange_concrete
fill 512 198 429 512 200 430 minecraft:netherrack
fill 512 198 431 512 198 432 minecraft:orange_concrete
fill 512 198 433 512 203 433 minecraft:netherrack
fill 512 198 435 512 199 435 minecraft:orange_concrete
setblock 512 198 436 minecraft:netherrack
fill 512 198 441 512 203 442 minecraft:netherrack
fill 512 198 443 512 199 444 minecraft:orange_concrete
fill 512 198 450 512 203 450 minecraft:netherrack
setblock 512 198 452 minecraft:orange_concrete
fill 512 198 453 512 203 454 minecraft:netherrack
fill 512 198 455 512 199 455 minecraft:orange_concrete
fill 512 198 458 512 203 458 minecraft:netherrack
setblock 470 199 422 minecraft:orange_concrete
fill 470 199 426 470 202 426 minecraft:netherrack
fill 470 199 442 470 199 443 minecraft:orange_concrete
setblock 470 199 446 minecraft:orange_concrete
fill 470 199 447 470 202 447 minecraft:netherrack
fill 470 199 458 470 202 458 minecraft:netherrack
fill 475 199 416 475 202 416 minecraft:netherrack
fill 475 199 436 477 200 436 minecraft:magma_block
setblock 475 199 458 minecraft:orange_concrete
setblock 476 199 416 minecraft:orange_concrete
fill 476 199 435 476 200 435 minecraft:magma_block
fill 476 199 437 476 200 437 minecraft:magma_block
fill 479 199 416 480 199 416 minecraft:orange_concrete
setblock 481 199 417 minecraft:magma_block
fill 482 199 420 484 200 420 minecraft:magma_block
fill 483 199 417 485 199 417 minecraft:magma_block
fill 483 199 421 483 201 421 minecraft:magma_block
setblock 486 199 458 minecraft:orange_concrete
fill 487 199 422 487 206 423 minecraft:red_nether_bricks
fill 488 199 421 488 204 421 minecraft:red_nether_bricks
fill 488 199 424 488 205 424 minecraft:red_nether_bricks
fill 489 199 420 489 202 420 minecraft:red_nether_bricks
fill 490 199 458 491 202 458 minecraft:netherrack
fill 493 199 421 493 199 423 minecraft:red_nether_bricks
fill 494 199 422 494 201 423 minecraft:magma_block
fill 496 199 416 496 202 416 minecraft:netherrack
setblock 500 199 416 minecraft:orange_concrete
setblock 507 199 458 minecraft:orange_concrete
setblock 510 199 458 minecraft:orange_concrete
setblock 511 199 416 minecraft:orange_concrete
fill 511 199 458 511 202 458 minecraft:netherrack
fill 512 199 420 512 201 420 minecraft:netherrack
fill 512 199 431 512 202 431 minecraft:netherrack
setblock 512 199 432 minecraft:orange_concrete
setblock 512 199 436 minecraft:orange_concrete
fill 512 199 452 512 202 452 minecraft:netherrack
setblock 512 199 456 minecraft:orange_concrete
fill 470 200 420 470 201 421 minecraft:orange_concrete
fill 470 200 422 470 205 423 minecraft:netherrack
fill 470 200 432 470 200 433 minecraft:orange_concrete
fill 470 200 434 470 205 435 minecraft:netherrack
fill 470 200 441 470 201 441 minecraft:orange_concrete
fill 470 200 442 470 205 443 minecraft:netherrack
setblock 470 200 444 minecraft:orange_concrete
fill 470 200 446 470 205 446 minecraft:netherrack
fill 470 200 452 470 201 453 minecraft:orange_concrete
fill 470 200 454 470 205 455 minecraft:netherrack
setblock 473 200 419 minecraft:light[level=14]
setblock 473 200 427 minecraft:light[level=14]
setblock 473 200 435 minecraft:light[level=14]
setblock 473 200 443 minecraft:light[level=14]
setblock 473 200 451 minecraft:light[level=14]
fill 475 200 458 475 205 458 minecraft:netherrack
fill 476 200 416 476 205 416 minecraft:netherrack
fill 476 200 458 477 200 458 minecraft:orange_concrete
setblock 478 200 416 minecraft:orange_concrete
fill 478 200 458 479 205 458 minecraft:netherrack
fill 479 200 416 480 205 416 minecraft:netherrack
fill 481 200 416 481 201 416 minecraft:orange_concrete
setblock 481 200 419 minecraft:light[level=14]
setblock 481 200 427 minecraft:light[level=14]
setblock 481 200 435 minecraft:light[level=14]
setblock 481 200 443 minecraft:light[level=14]
setblock 481 200 451 minecraft:light[level=14]
fill 482 200 418 484 200 418 minecraft:magma_block
setblock 482 200 421 minecraft:magma_block
fill 483 200 417 484 200 417 minecraft:magma_block
fill 483 200 422 483 201 422 minecraft:magma_block
setblock 484 200 421 minecraft:magma_block
fill 484 200 458 485 201 458 minecraft:orange_concrete
fill 486 200 422 486 206 423 minecraft:red_nether_bricks
fill 486 200 458 487 205 458 minecraft:netherrack
fill 487 200 416 488 205 416 minecraft:netherrack
fill 487 200 421 487 204 421 minecraft:red_nether_bricks
fill 487 200 424 487 206 424 minecraft:red_nether_bricks
fill 488 200 420 488 202 420 minecraft:red_nether_bricks
setblock 488 200 458 minecraft:orange_concrete
fill 489 200 416 490 200 416 minecraft:orange_concrete
setblock 489 200 419 minecraft:light[level=14]
setblock 489 200 427 minecraft:light[level=14]
setblock 489 200 435 minecraft:light[level=14]
setblock 489 200 443 minecraft:light[level=14]
setblock 489 200 451 minecraft:light[level=14]
setblock 493 200 422 minecraft:magma_block
fill 496 200 458 497 201 458 minecraft:orange_concrete
setblock 497 200 419 minecraft:light[level=14]
setblock 497 200 427 minecraft:light[level=14]
setblock 497 200 435 minecraft:light[level=14]
setblock 497 200 443 minecraft:light[level=14]
setblock 497 200 451 minecraft:light[level=14]
fill 498 200 458 499 205 458 minecraft:netherrack
fill 499 200 416 500 205 416 minecraft:netherrack
fill 501 200 416 502 201 416 minecraft:orange_concrete
setblock 505 200 419 minecraft:light[level=14]
setblock 505 200 435 minecraft:light[level=14]
setblock 505 200 443 minecraft:light[level=14]
setblock 505 200 451 minecraft:light[level=14]
fill 505 200 458 505 201 458 minecraft:orange_concrete
fill 507 200 416 508 202 416 minecraft:netherrack
fill 507 200 458 507 205 458 minecraft:netherrack
fill 508 200 458 509 200 458 minecraft:orange_concrete
fill 509 200 416 510 200 416 minecraft:orange_concrete
fill 510 200 458 510 205 458 minecraft:netherrack
fill 511 200 416 511 205 416 minecraft:netherrack
fill 512 200 417 512 201 417 minecraft:orange_concrete
setblock 512 200 418 minecraft:netherrack
fill 512 200 423 512 205 424 minecraft:netherrack
fill 512 200 425 512 201 426 minecraft:orange_concrete
fill 512 200 432 512 202 432 minecraft:netherrack
setblock 512 200 434 minecraft:orange_concrete
fill 512 200 435 512 205 436 minecraft:netherrack
fill 512 200 437 512 201 438 minecraft:orange_concrete
fill 512 200 443 512 205 444 minecraft:netherrack
fill 512 200 445 512 200 446 minecraft:orange_concrete
fill 512 200 455 512 205 456 minecraft:netherrack
fill 512 200 457 512 201 457 minecraft:orange_concrete
setblock 470 201 429 minecraft:orange_concrete
setblock 470 201 432 minecraft:orange_concrete
fill 470 201 433 470 204 433 minecraft:netherrack
setblock 470 201 440 minecraft:orange_concrete
fill 470 201 444 470 204 444 minecraft:netherrack
fill 472 201 458 473 201 458 minecraft:orange_concrete
setblock 476 201 458 minecraft:orange_concrete
fill 477 201 458 477 204 458 minecraft:netherrack
fill 478 201 416 478 204 416 minecraft:netherrack
setblock 482 201 416 minecraft:orange_concrete
fill 483 201 418 483 201 420 minecraft:magma_block
setblock 483 201 423 minecraft:magma_block
fill 485 201 423 485 208 423 minecraft:red_nether_bricks
fill 486 201 421 486 205 421 minecraft:red_nether_bricks
fill 486 201 424 486 207 424 minecraft:red_nether_bricks
fill 488 201 458 488 204 458 minecraft:netherrack
fill 489 201 416 489 204 416 minecraft:netherrack
setblock 490 201 416 minecraft:orange_concrete
setblock 493 201 416 minecraft:orange_concrete
setblock 493 201 458 minecraft:orange_concrete
setblock 504 201 458 minecraft:orange_concrete
fill 508 201 458 509 204 458 minecraft:netherrack
fill 509 201 416 509 204 416 minecraft:netherrack
setblock 510 201 416 minecraft:orange_concrete
setblock 512 201 418 minecraft:orange_concrete
setblock 512 201 429 minecraft:orange_concrete
fill 512 201 430 512 203 430 minecraft:netherrack
fill 512 201 434 512 204 434 minecraft:netherrack
fill 512 201 445 512 204 445 minecraft:netherrack
setblock 512 201 446 minecraft:orange_concrete
setblock 512 201 449 minecraft:orange_concrete
fill 470 202 418 470 203 419 minecraft:orange_concrete
fill 470 202 420 470 207 421 minecraft:netherrack
fill 470 202 427 470 203 427 minecraft:orange_concrete
fill 470 202 429 470 207 429 minecraft:netherrack
fill 470 202 430 470 202 431 minecraft:orange_concrete
fill 470 202 432 470 207 432 minecraft:netherrack
fill 470 202 438 470 203 439 minecraft:orange_concrete
fill 470 202 440 470 207 441 minecraft:netherrack
fill 470 202 450 470 202 451 minecraft:orange_concrete
fill 470 202 452 470 207 453 minecraft:netherrack
fill 471 202 416 472 202 416 minecraft:orange_concrete
fill 471 202 458 471 203 458 minecraft:orange_concrete
fill 472 202 458 473 207 458 minecraft:netherrack
setblock 474 202 458 minecraft:orange_concrete
fill 476 202 458 476 207 458 minecraft:netherrack
fill 481 202 416 482 207 416 minecraft:netherrack
fill 482 202 458 483 203 458 minecraft:orange_concrete
fill 483 202 416 484 203 416 minecraft:orange_concrete
fill 484 202 458 485 207 458 minecraft:netherrack
fill 485 202 422 485 207 422 minecraft:red_nether_bricks
fill 485 202 424 485 209 424 minecraft:red_nether_bricks
fill 486 202 425 488 203 425 minecraft:red_nether_bricks
fill 490 202 416 490 207 416 minecraft:netherrack
fill 491 202 416 492 202 416 minecraft:orange_concrete
setblock 491 202 422 minecraft:red_nether_bricks
fill 493 202 416 493 207 416 minecraft:netherrack
fill 493 202 458 493 207 458 minecraft:netherrack
fill 494 202 458 495 202 458 minecraft:orange_concrete
fill 495 202 416 495 203 416 minecraft:orange_concrete
fill 496 202 458 497 207 458 minecraft:netherrack
fill 501 202 416 502 207 416 minecraft:netherrack
fill 502 202 458 503 203 458 minecraft:orange_concrete
fill 503 202 416 504 203 416 minecraft:orange_concrete
fill 504 202 458 505 207 458 minecraft:netherrack
setblock 506 202 458 minecraft:orange_concrete
fill 510 202 416 510 204 416 minecraft:netherrack
setblock 512 202 416 minecraft:orange_concrete
fill 512 202 417 512 207 418 minecraft:netherrack
fill 512 202 419 512 203 420 minecraft:orange_concrete
fill 512 202 425 512 207 426 minecraft:netherrack
fill 512 202 427 512 202 428 minecraft:orange_concrete
fill 512 202 429 512 203 429 minecraft:netherrack
fill 512 202 437 512 207 438 minecraft:netherrack
fill 512 202 439 512 203 440 minecraft:orange_concrete
fill 512 202 446 512 207 446 minecraft:netherrack
fill 512 202 447 512 202 448 minecraft:orange_concrete
fill 512 202 449 512 207 449 minecraft:netherrack
fill 512 202 451 512 203 451 minecraft:orange_concrete
fill 512 202 457 512 207 457 minecraft:netherrack
setblock 470 203 426 minecraft:orange_concrete
fill 470 203 430 470 206 431 minecraft:netherrack
setblock 470 203 447 minecraft:orange_concrete
setblock 470 203 450 minecraft:orange_concrete
fill 470 203 451 470 206 451 minecraft:netherrack
setblock 470 203 458 minecraft:orange_concrete
fill 471 203 416 471 206 416 minecraft:netherrack
setblock 472 203 416 minecraft:orange_concrete
fill 474 203 458 474 206 458 minecraft:netherrack
setblock 475 203 416 minecraft:orange_concrete
fill 484 203 422 484 208 424 minecraft:red_nether_bricks
fill 485 203 421 485 205 421 minecraft:red_nether_bricks
fill 485 203 425 485 209 425 minecraft:red_nether_bricks
fill 490 203 422 490 203 423 minecraft:red_nether_bricks
fill 490 203 458 491 203 458 minecraft:orange_concrete
fill 491 203 416 492 206 416 minecraft:netherrack
setblock 494 203 458 minecraft:orange_concrete
fill 495 203 458 495 206 458 minecraft:netherrack
setblock 496 203 416 minecraft:orange_concrete
fill 506 203 458 506 206 458 minecraft:netherrack
setblock 507 203 416 minecraft:orange_concrete
fill 508 203 416 508 205 416 minecraft:netherrack
setblock 511 203 458 minecraft:orange_concrete
fill 512 203 416 512 206 416 minecraft:netherrack
fill 512 203 427 512 206 427 minecraft:netherrack
setblock 512 203 428 minecraft:orange_concrete
fill 512 203 431 512 203 432 minecraft:orange_concrete
fill 512 203 447 512 205 448 minecraft:netherrack
setblock 512 203 452 minecraft:orange_concrete
fill 470 204 416 470 204 417 minecraft:orange_concrete
fill 470 204 418 470 221 419 minecraft:netherrack
fill 470 204 424 470 205 425 minecraft:orange_concrete
fill 470 204 426 470 222 427 minecraft:netherrack
setblock 470 204 428 minecraft:orange_concrete
fill 470 204 436 470 205 437 minecraft:orange_concrete
fill 470 204 438 470 221 439 minecraft:netherrack
fill 470 204 445 470 205 445 minecraft:orange_concrete
fill 470 204 447 470 225 447 minecraft:netherrack
fill 470 204 448 470 204 449 minecraft:orange_concrete
fill 470 204 450 470 221 450 minecraft:netherrack
fill 470 204 456 470 205 457 minecraft:orange_concrete
fill 470 204 458 471 222 458 minecraft:netherrack
fill 471 204 417 473 204 417 minecraft:red_nether_bricks
fill 471 204 419 471 204 421 minecraft:red_nether_bricks
fill 471 204 423 471 204 425 minecraft:red_nether_bricks
fill 471 204 427 471 204 429 minecraft:red_nether_bricks
fill 471 204 431 471 204 433 minecraft:red_nether_bricks
fill 471 204 435 471 204 437 minecraft:red_nether_bricks
fill 471 204 439 471 204 441 minecraft:red_nether_bricks
fill 471 204 443 471 204 445 minecraft:red_nether_bricks
fill 471 204 447 471 204 449 minecraft:red_nether_bricks
fill 471 204 451 471 204 453 minecraft:red_nether_bricks
fill 471 204 455 471 204 457 minecraft:red_nether_bricks
fill 472 204 416 472 221 416 minecraft:netherrack
fill 473 204 416 474 204 416 minecraft:orange_concrete
fill 473 204 457 475 204 457 minecraft:red_nether_bricks
fill 475 204 416 475 225 416 minecraft:netherrack
fill 475 204 417 477 204 417 minecraft:red_nether_bricks
fill 477 204 416 477 205 416 minecraft:orange_concrete
fill 477 204 457 479 204 457 minecraft:red_nether_bricks
fill 479 204 417 481 204 417 minecraft:red_nether_bricks
fill 480 204 458 481 204 458 minecraft:orange_concrete
fill 481 204 457 483 204 457 minecraft:red_nether_bricks
fill 482 204 458 483 221 458 minecraft:netherrack
fill 483 204 416 484 221 416 minecraft:netherrack
fill 483 204 417 485 204 417 minecraft:red_nether_bricks
fill 483 204 423 483 209 425 minecraft:red_nether_bricks
fill 484 204 425 484 209 425 minecraft:red_nether_bricks
fill 485 204 416 486 205 416 minecraft:orange_concrete
fill 485 204 457 487 204 457 minecraft:red_nether_bricks
fill 486 204 425 487 205 425 minecraft:red_nether_bricks
fill 487 204 417 489 204 417 minecraft:red_nether_bricks
fill 489 204 422 489 204 423 minecraft:red_nether_bricks
fill 489 204 457 491 204 457 minecraft:red_nether_bricks
fill 489 204 458 489 205 458 minecraft:orange_concrete
fill 490 204 458 491 225 458 minecraft:netherrack
fill 491 204 417 493 204 417 minecraft:red_nether_bricks
setblock 492 204 458 minecraft:orange_concrete
fill 493 204 457 495 204 457 minecraft:red_nether_bricks
setblock 494 204 416 minecraft:orange_concrete
fill 494 204 458 494 221 458 minecraft:netherrack
fill 495 204 416 496 222 416 minecraft:netherrack
fill 495 204 417 497 204 417 minecraft:red_nether_bricks
fill 497 204 416 498 205 416 minecraft:orange_concrete
fill 497 204 457 499 204 457 minecraft:red_nether_bricks
fill 499 204 417 501 204 417 minecraft:red_nether_bricks
fill 500 204 458 501 205 458 minecraft:orange_concrete
fill 501 204 457 503 204 457 minecraft:red_nether_bricks
fill 502 204 458 503 221 458 minecraft:netherrack
fill 503 204 416 504 221 416 minecraft:netherrack
fill 503 204 417 505 204 417 minecraft:red_nether_bricks
fill 505 204 416 506 204 416 minecraft:orange_concrete
fill 505 204 457 507 204 457 minecraft:red_nether_bricks
fill 507 204 416 507 225 416 minecraft:netherrack
fill 507 204 417 509 204 417 minecraft:red_nether_bricks
fill 509 204 457 511 204 457 minecraft:red_nether_bricks
fill 511 204 417 511 204 419 minecraft:red_nether_bricks
fill 511 204 421 511 204 423 minecraft:red_nether_bricks
fill 511 204 425 511 204 427 minecraft:red_nether_bricks
fill 511 204 429 511 204 431 minecraft:red_nether_bricks
fill 511 204 433 511 204 435 minecraft:red_nether_bricks
fill 511 204 437 511 204 439 minecraft:red_nether_bricks
fill 511 204 441 511 204 443 minecraft:red_nether_bricks
fill 511 204 445 511 204 447 minecraft:red_nether_bricks
fill 511 204 449 511 204 451 minecraft:red_nether_bricks
fill 511 204 453 511 204 455 minecraft:red_nether_bricks
fill 511 204 458 511 225 458 minecraft:netherrack
fill 512 204 419 512 222 420 minecraft:netherrack
fill 512 204 421 512 205 422 minecraft:orange_concrete
fill 512 204 428 512 221 428 minecraft:netherrack
fill 512 204 429 512 204 430 minecraft:orange_concrete
fill 512 204 431 512 205 432 minecraft:netherrack
fill 512 204 433 512 205 433 minecraft:orange_concrete
fill 512 204 439 512 221 440 minecraft:netherrack
fill 512 204 441 512 205 442 minecraft:orange_concrete
setblock 512 204 450 minecraft:orange_concrete
fill 512 204 451 512 222 452 minecraft:netherrack
fill 512 204 453 512 205 454 minecraft:orange_concrete
fill 512 204 458 512 205 458 minecraft:orange_concrete
setblock 470 205 416 minecraft:orange_concrete
fill 470 205 417 470 208 417 minecraft:netherrack
fill 470 205 428 470 208 428 minecraft:netherrack
setblock 470 205 433 minecraft:orange_concrete
setblock 470 205 444 minecraft:orange_concrete
fill 470 205 448 470 208 449 minecraft:netherrack
fill 473 205 416 474 208 416 minecraft:netherrack
setblock 477 205 458 minecraft:orange_concrete
setblock 478 205 416 minecraft:orange_concrete
setblock 480 205 458 minecraft:orange_concrete
fill 481 205 458 481 208 458 minecraft:netherrack
fill 482 205 423 482 209 425 minecraft:red_nether_bricks
fill 483 205 422 483 208 422 minecraft:red_nether_bricks
fill 483 205 441 484 206 442 minecraft:shroomlight
fill 484 205 426 485 208 426 minecraft:red_nether_bricks
setblock 488 205 458 minecraft:orange_concrete
setblock 489 205 416 minecraft:orange_concrete
fill 492 205 458 492 208 458 minecraft:netherrack
fill 494 205 416 494 208 416 minecraft:netherrack
fill 505 205 416 505 208 416 minecraft:netherrack
setblock 506 205 416 minecraft:orange_concrete
fill 508 205 458 509 205 458 minecraft:orange_concrete
fill 509 205 416 510 205 416 minecraft:orange_concrete
fill 512 205 429 512 207 430 minecraft:netherrack
setblock 512 205 434 minecraft:orange_concrete
setblock 512 205 445 minecraft:orange_concrete
fill 512 205 450 512 207 450 minecraft:netherrack
fill 470 206 416 470 223 416 minecraft:netherrack
fill 470 206 422 470 207 423 minecraft:orange_concrete
fill 470 206 424 470 219 425 minecraft:netherrack
fill 470 206 433 470 219 433 minecraft:netherrack
fill 470 206 434 470 206 435 minecraft:orange_concrete
fill 470 206 436 470 223 437 minecraft:netherrack
fill 470 206 442 470 207 443 minecraft:orange_concrete
fill 470 206 444 470 219 445 minecraft:netherrack
setblock 470 206 446 minecraft:orange_concrete
fill 470 206 454 470 207 455 minecraft:orange_concrete
fill 470 206 456 470 219 457 minecraft:netherrack
fill 475 206 458 475 207 458 minecraft:orange_concrete
setblock 476 206 416 minecraft:orange_concrete
fill 477 206 416 478 219 416 minecraft:netherrack
fill 477 206 458 477 219 458 minecraft:netherrack
fill 478 206 458 479 206 458 minecraft:orange_concrete
fill 479 206 416 480 207 416 minecraft:orange_concrete
fill 480 206 458 480 223 458 minecraft:netherrack
fill 481 206 424 481 209 425 minecraft:red_nether_bricks
fill 482 206 422 482 207 422 minecraft:red_nether_bricks
fill 482 206 426 483 209 426 minecraft:red_nether_bricks
fill 485 206 416 486 223 416 minecraft:netherrack
fill 486 206 425 486 207 425 minecraft:red_nether_bricks
fill 486 206 458 487 207 458 minecraft:orange_concrete
fill 487 206 416 488 206 416 minecraft:orange_concrete
fill 488 206 443 488 206 445 minecraft:orange_concrete
fill 488 206 458 489 219 458 minecraft:netherrack
fill 489 206 416 489 219 416 minecraft:netherrack
fill 489 206 442 489 206 443 minecraft:orange_concrete
fill 489 206 446 491 207 446 minecraft:orange_concrete
setblock 490 206 442 minecraft:orange_concrete
fill 491 206 443 491 208 443 minecraft:orange_concrete
fill 492 206 444 492 206 445 minecraft:orange_concrete
fill 497 206 416 498 219 416 minecraft:netherrack
fill 498 206 458 499 206 458 minecraft:orange_concrete
fill 499 206 416 500 207 416 minecraft:orange_concrete
fill 500 206 424 502 206 425 minecraft:orange_concrete
fill 500 206 458 501 219 458 minecraft:netherrack
fill 501 206 422 502 206 423 minecraft:orange_concrete
fill 501 206 426 502 206 427 minecraft:orange_concrete
fill 502 206 421 508 206 421 minecraft:orange_concrete
fill 502 206 428 508 206 428 minecraft:orange_concrete
fill 503 206 422 508 206 422 minecraft:orange_concrete
fill 503 206 427 503 208 427 minecraft:orange_concrete
fill 503 206 429 507 206 429 minecraft:orange_concrete
fill 504 206 420 506 206 420 minecraft:orange_concrete
fill 506 206 416 506 223 416 minecraft:netherrack
fill 506 206 427 509 206 427 minecraft:orange_concrete
fill 507 206 423 509 206 423 minecraft:orange_concrete
fill 507 206 426 509 206 426 minecraft:orange_concrete
fill 507 206 458 507 207 458 minecraft:orange_concrete
setblock 508 206 416 minecraft:orange_concrete
fill 508 206 424 509 206 425 minecraft:orange_concrete
fill 508 206 458 509 219 458 minecraft:netherrack
fill 509 206 416 510 219 416 minecraft:netherrack
setblock 510 206 458 minecraft:orange_concrete
fill 511 206 416 511 207 416 minecraft:orange_concrete
fill 512 206 421 512 219 422 minecraft:netherrack
fill 512 206 423 512 207 424 minecraft:orange_concrete
fill 512 206 431 512 225 431 minecraft:netherrack
setblock 512 206 432 minecraft:orange_concrete
fill 512 206 433 512 219 434 minecraft:netherrack
fill 512 206 435 512 207 436 minecraft:orange_concrete
fill 512 206 441 512 208 442 minecraft:netherrack
fill 512 206 443 512 206 444 minecraft:orange_concrete
fill 512 206 445 512 219 445 minecraft:netherrack
fill 512 206 447 512 207 447 minecraft:orange_concrete
setblock 512 206 448 minecraft:netherrack
fill 512 206 453 512 219 454 minecraft:netherrack
fill 512 206 455 512 207 456 minecraft:orange_concrete
fill 512 206 458 512 223 458 minecraft:netherrack
fill 470 207 430 470 207 431 minecraft:orange_concrete
setblock 470 207 434 minecraft:orange_concrete
fill 470 207 435 470 225 435 minecraft:netherrack
fill 470 207 446 470 225 446 minecraft:netherrack
setblock 470 207 451 minecraft:orange_concrete
setblock 471 207 416 minecraft:orange_concrete
setblock 474 207 458 minecraft:orange_concrete
fill 476 207 416 476 225 416 minecraft:netherrack
fill 478 207 458 479 225 458 minecraft:netherrack
fill 481 207 423 481 209 423 minecraft:red_nether_bricks
fill 481 207 426 481 209 426 minecraft:red_nether_bricks
fill 482 207 427 483 209 427 minecraft:red_nether_bricks
setblock 486 207 423 minecraft:red_nether_bricks
fill 487 207 416 487 225 416 minecraft:netherrack
setblock 488 207 416 minecraft:orange_concrete
fill 488 207 444 488 207 445 minecraft:orange_concrete
fill 489 207 443 489 208 443 minecraft:orange_concrete
fill 491 207 416 492 207 416 minecraft:orange_concrete
setblock 492 207 444 minecraft:orange_concrete
setblock 495 207 458 minecraft:orange_concrete
setblock 498 207 458 minecraft:orange_concrete
fill 499 207 458 499 225 458 minecraft:netherrack
fill 501 207 423 502 207 426 minecraft:orange_concrete
fill 502 207 422 507 207 422 minecraft:orange_concrete
setblock 502 207 427 minecraft:orange_concrete
fill 503 207 421 506 207 421 minecraft:orange_concrete
fill 503 207 428 507 207 428 minecraft:orange_concrete
fill 506 207 427 508 207 427 minecraft:orange_concrete
setblock 506 207 458 minecraft:orange_concrete
fill 507 207 423 508 207 423 minecraft:orange_concrete
fill 507 207 426 508 207 426 minecraft:orange_concrete
fill 508 207 416 508 225 416 minecraft:netherrack
fill 508 207 424 508 208 425 minecraft:orange_concrete
fill 510 207 458 510 225 458 minecraft:netherrack
setblock 512 207 416 minecraft:orange_concrete
setblock 512 207 427 minecraft:orange_concrete
fill 512 207 432 512 225 432 minecraft:netherrack
fill 512 207 443 512 225 443 minecraft:netherrack
setblock 512 207 444 minecraft:orange_concrete
setblock 512 207 448 minecraft:orange_concrete
fill 470 208 420 470 208 421 minecraft:orange_concrete
fill 470 208 422 470 221 423 minecraft:netherrack
fill 470 208 429 470 209 429 minecraft:orange_concrete
fill 470 208 430 470 221 431 minecraft:netherrack
setblock 470 208 432 minecraft:orange_concrete
fill 470 208 434 470 225 434 minecraft:netherrack
fill 470 208 440 470 209 441 minecraft:orange_concrete
fill 470 208 442 470 221 443 minecraft:netherrack
fill 470 208 451 470 221 451 minecraft:netherrack
fill 470 208 452 470 208 453 minecraft:orange_concrete
fill 470 208 454 470 225 455 minecraft:netherrack
fill 471 208 416 471 221 416 minecraft:netherrack
fill 472 208 458 473 209 458 minecraft:orange_concrete
setblock 473 208 419 minecraft:light[level=14]
setblock 473 208 427 minecraft:light[level=14]
setblock 473 208 435 minecraft:light[level=14]
setblock 473 208 443 minecraft:light[level=14]
setblock 473 208 451 minecraft:light[level=14]
fill 474 208 458 475 221 458 minecraft:netherrack
setblock 476 208 458 minecraft:orange_concrete
fill 479 208 416 480 221 416 minecraft:netherrack
fill 480 208 424 480 209 427 minecraft:red_nether_bricks
fill 481 208 416 482 209 416 minecraft:orange_concrete
setblock 481 208 419 minecraft:light[level=14]
fill 481 208 427 481 209 427 minecraft:red_nether_bricks
setblock 481 208 435 minecraft:light[level=14]
setblock 481 208 443 minecraft:light[level=14]
setblock 481 208 451 minecraft:light[level=14]
fill 484 208 458 485 209 458 minecraft:orange_concrete
fill 486 208 458 487 221 458 minecraft:netherrack
fill 488 208 416 488 225 416 minecraft:netherrack
setblock 489 208 419 minecraft:light[level=14]
setblock 489 208 427 minecraft:light[level=14]
setblock 489 208 435 minecraft:light[level=14]
setblock 489 208 451 minecraft:light[level=14]
setblock 490 208 416 minecraft:orange_concrete
setblock 490 208 446 minecraft:orange_concrete
fill 491 208 416 492 221 416 minecraft:netherrack
fill 493 208 416 493 209 416 minecraft:orange_concrete
fill 493 208 458 493 209 458 minecraft:orange_concrete
fill 495 208 458 495 221 458 minecraft:netherrack
fill 496 208 458 497 208 458 minecraft:orange_concrete
setblock 497 208 419 minecraft:light[level=14]
setblock 497 208 427 minecraft:light[level=14]
setblock 497 208 435 minecraft:light[level=14]
setblock 497 208 443 minecraft:light[level=14]
setblock 497 208 451 minecraft:light[level=14]
fill 498 208 458 498 225 458 minecraft:netherrack
fill 499 208 416 500 221 416 minecraft:netherrack
fill 501 208 416 502 208 416 minecraft:orange_concrete
fill 502 208 423 502 208 426 minecraft:orange_concrete
fill 503 208 422 506 208 422 minecraft:orange_concrete
fill 504 208 458 505 209 458 minecraft:orange_concrete
setblock 505 208 419 minecraft:light[level=14]
setblock 505 208 435 minecraft:light[level=14]
setblock 505 208 443 minecraft:light[level=14]
setblock 505 208 451 minecraft:light[level=14]
fill 506 208 427 507 208 427 minecraft:orange_concrete
fill 506 208 458 507 221 458 minecraft:netherrack
setblock 507 208 423 minecraft:orange_concrete
setblock 507 208 426 minecraft:orange_concrete
fill 511 208 416 512 221 416 minecraft:netherrack
fill 512 208 417 512 209 418 minecraft:orange_concrete
fill 512 208 423 512 225 424 minecraft:netherrack
fill 512 208 425 512 208 426 minecraft:orange_concrete
fill 512 208 427 512 221 427 minecraft:netherrack
fill 512 208 429 512 209 429 minecraft:orange_concrete
setblock 512 208 430 minecraft:netherrack
fill 512 208 435 512 221 436 minecraft:netherrack
fill 512 208 437 512 209 438 minecraft:orange_concrete
fill 512 208 444 512 225 444 minecraft:netherrack
setblock 512 208 446 minecraft:orange_concrete
fill 512 208 447 512 221 448 minecraft:netherrack
fill 512 208 449 512 209 450 minecraft:orange_concrete
fill 512 208 455 512 221 456 minecraft:netherrack
setblock 512 208 457 minecraft:orange_concrete
setblock 470 209 417 minecraft:orange_concrete
setblock 470 209 420 minecraft:orange_concrete
fill 470 209 421 470 219 421 minecraft:netherrack
setblock 470 209 428 minecraft:orange_concrete
fill 470 209 432 470 219 432 minecraft:netherrack
fill 470 209 448 470 209 449 minecraft:orange_concrete
setblock 470 209 452 minecraft:orange_concrete
fill 470 209 453 470 219 453 minecraft:netherrack
fill 473 209 416 474 209 416 minecraft:orange_concrete
fill 476 209 458 476 219 458 minecraft:netherrack
fill 479 209 425 479 209 427 minecraft:red_nether_bricks
fill 480 209 428 482 209 428 minecraft:red_nether_bricks
setblock 481 209 458 minecraft:orange_concrete
fill 484 209 423 484 209 424 minecraft:red_nether_bricks
setblock 484 209 426 minecraft:red_nether_bricks
fill 490 209 416 490 219 416 minecraft:netherrack
setblock 492 209 458 minecraft:orange_concrete
setblock 494 209 416 minecraft:orange_concrete
fill 496 209 458 497 219 458 minecraft:netherrack
fill 501 209 416 501 219 416 minecraft:netherrack
setblock 502 209 416 minecraft:orange_concrete
setblock 505 209 416 minecraft:orange_concrete
fill 512 209 425 512 219 425 minecraft:netherrack
setblock 512 209 426 minecraft:orange_concrete
setblock 512 209 430 minecraft:orange_concrete
setblock 512 209 441 minecraft:orange_concrete
fill 512 209 442 512 223 442 minecraft:netherrack
fill 512 209 446 512 219 446 minecraft:netherrack
fill 512 209 457 512 219 457 minecraft:netherrack
fill 470 210 417 470 223 417 minecraft:netherrack
fill 470 210 420 470 220 420 minecraft:netherrack
fill 470 210 428 470 223 429 minecraft:netherrack
fill 470 210 440 470 220 441 minecraft:netherrack
fill 470 210 448 470 223 449 minecraft:netherrack
fill 470 210 452 470 220 452 minecraft:netherrack
fill 472 210 458 473 223 458 minecraft:netherrack
fill 473 210 416 474 223 416 minecraft:netherrack
fill 481 210 416 482 220 416 minecraft:netherrack
fill 481 210 458 481 223 458 minecraft:netherrack
fill 484 210 458 485 220 458 minecraft:netherrack
fill 492 210 458 493 223 458 minecraft:netherrack
fill 493 210 416 494 223 416 minecraft:netherrack
fill 502 210 416 502 220 416 minecraft:netherrack
fill 504 210 458 505 220 458 minecraft:netherrack
fill 505 210 416 505 223 416 minecraft:netherrack
fill 512 210 417 512 220 418 minecraft:netherrack
fill 512 210 426 512 219 426 minecraft:netherrack
fill 512 210 429 512 223 430 minecraft:netherrack
fill 512 210 437 512 220 438 minecraft:netherrack
fill 512 210 441 512 223 441 minecraft:netherrack
fill 512 210 449 512 223 450 minecraft:netherrack
fill 471 215 417 476 216 420 minecraft:red_terracotta
fill 471 215 421 471 216 421 minecraft:nether_wart_block
fill 471 215 422 471 216 424 minecraft:red_terracotta
fill 471 215 425 471 216 426 minecraft:nether_wart_block
fill 471 215 427 476 216 435 minecraft:red_terracotta
fill 471 215 436 471 216 437 minecraft:nether_wart_block
fill 471 215 438 471 216 440 minecraft:red_terracotta
fill 471 215 441 471 216 442 minecraft:nether_wart_block
fill 471 215 443 476 216 451 minecraft:red_terracotta
fill 471 215 452 471 216 453 minecraft:nether_wart_block
fill 471 215 454 471 216 456 minecraft:red_terracotta
fill 471 215 457 472 216 457 minecraft:nether_wart_block
fill 472 215 421 474 216 421 minecraft:red_terracotta
fill 472 215 422 475 216 425 minecraft:nether_wart_block
fill 472 215 426 475 216 426 minecraft:red_terracotta
fill 472 215 436 475 216 436 minecraft:red_terracotta
fill 472 215 437 472 216 441 minecraft:nether_wart_block
fill 472 215 442 475 216 442 minecraft:red_terracotta
fill 472 215 452 475 216 452 minecraft:red_terracotta
fill 472 215 453 475 216 456 minecraft:nether_wart_block
fill 473 215 437 474 216 437 minecraft:red_terracotta
fill 473 215 438 475 216 440 minecraft:nether_wart_block
fill 473 215 441 474 216 441 minecraft:red_terracotta
fill 473 215 457 474 216 457 minecraft:red_terracotta
fill 475 215 421 476 216 421 minecraft:nether_wart_block
fill 475 215 437 476 216 437 minecraft:nether_wart_block
fill 475 215 441 476 216 441 minecraft:nether_wart_block
fill 475 215 457 476 216 457 minecraft:nether_wart_block
fill 476 215 422 486 216 425 minecraft:red_terracotta
fill 476 215 426 476 216 426 minecraft:nether_wart_block
fill 476 215 436 477 216 436 minecraft:nether_wart_block
fill 476 215 438 487 216 440 minecraft:red_terracotta
fill 476 215 442 477 216 442 minecraft:nether_wart_block
fill 476 215 452 476 216 453 minecraft:nether_wart_block
fill 476 215 454 486 216 456 minecraft:red_terracotta
fill 477 215 417 477 216 419 minecraft:red_terracotta
fill 477 215 420 477 216 420 minecraft:nether_wart_block
fill 477 215 421 486 216 421 minecraft:red_terracotta
fill 477 215 426 485 216 426 minecraft:red_terracotta
fill 477 215 427 477 216 427 minecraft:nether_wart_block
fill 477 215 428 477 216 434 minecraft:red_terracotta
fill 477 215 435 478 216 435 minecraft:nether_wart_block
fill 477 215 437 486 216 437 minecraft:red_terracotta
fill 477 215 441 486 216 441 minecraft:red_terracotta
fill 477 215 443 477 216 443 minecraft:nether_wart_block
fill 477 215 444 477 216 450 minecraft:red_terracotta
fill 477 215 451 477 216 451 minecraft:nether_wart_block
fill 477 215 452 485 216 453 minecraft:red_terracotta
fill 477 215 457 486 216 457 minecraft:red_terracotta
fill 478 215 417 478 216 418 minecraft:red_terracotta
fill 478 215 419 478 216 419 minecraft:nether_wart_block
fill 478 215 420 485 216 420 minecraft:red_terracotta
fill 478 215 427 484 216 427 minecraft:red_terracotta
fill 478 215 428 478 216 428 minecraft:nether_wart_block
fill 478 215 429 478 216 433 minecraft:red_terracotta
fill 478 215 434 479 216 434 minecraft:nether_wart_block
fill 478 215 436 485 216 436 minecraft:red_terracotta
fill 478 215 442 484 216 443 minecraft:red_terracotta
fill 478 215 444 479 216 444 minecraft:nether_wart_block
fill 478 215 445 478 216 449 minecraft:red_terracotta
fill 478 215 450 478 216 450 minecraft:nether_wart_block
fill 478 215 451 484 216 451 minecraft:red_terracotta
fill 479 215 417 479 216 418 minecraft:nether_wart_block
fill 479 215 419 484 216 419 minecraft:red_terracotta
fill 479 215 428 483 216 428 minecraft:red_terracotta
fill 479 215 429 480 216 429 minecraft:nether_wart_block
fill 479 215 430 479 216 432 minecraft:red_terracotta
fill 479 215 433 483 216 433 minecraft:nether_wart_block
fill 479 215 435 484 216 435 minecraft:red_terracotta
fill 479 215 445 480 216 445 minecraft:nether_wart_block
fill 479 215 446 479 216 448 minecraft:red_terracotta
fill 479 215 449 480 216 449 minecraft:nether_wart_block
fill 479 215 450 483 216 450 minecraft:red_terracotta
fill 480 215 417 483 216 417 minecraft:nether_wart_block
fill 480 215 418 482 216 418 minecraft:red_terracotta
fill 480 215 430 483 216 432 minecraft:nether_wart_block
fill 480 215 434 483 216 434 minecraft:red_terracotta
fill 480 215 444 483 216 444 minecraft:red_terracotta
fill 480 215 446 483 216 448 minecraft:nether_wart_block
fill 481 215 429 482 216 429 minecraft:red_terracotta
fill 481 215 445 481 216 445 minecraft:red_terracotta
fill 481 215 449 482 216 449 minecraft:red_terracotta
fill 482 215 445 483 216 445 minecraft:nether_wart_block
fill 483 215 418 484 216 418 minecraft:nether_wart_block
fill 483 215 429 484 216 429 minecraft:nether_wart_block
fill 483 215 449 484 216 449 minecraft:nether_wart_block
fill 484 215 417 494 216 417 minecraft:red_terracotta
fill 484 215 428 485 216 428 minecraft:nether_wart_block
fill 484 215 430 494 216 433 minecraft:red_terracotta
fill 484 215 434 484 216 434 minecraft:nether_wart_block
fill 484 215 444 484 216 444 minecraft:nether_wart_block
fill 484 215 445 494 216 448 minecraft:red_terracotta
fill 484 215 450 485 216 450 minecraft:nether_wart_block
fill 485 215 418 493 216 418 minecraft:red_terracotta
fill 485 215 419 485 216 419 minecraft:nether_wart_block
fill 485 215 427 486 216 427 minecraft:nether_wart_block
fill 485 215 429 494 216 429 minecraft:red_terracotta
fill 485 215 434 493 216 434 minecraft:red_terracotta
fill 485 215 435 485 216 435 minecraft:nether_wart_block
fill 485 215 442 485 216 442 minecraft:red_terracotta
fill 485 215 443 485 216 443 minecraft:nether_wart_block
fill 485 215 444 493 216 444 minecraft:red_terracotta
fill 485 215 449 494 216 449 minecraft:red_terracotta
fill 485 215 451 486 216 451 minecraft:nether_wart_block
fill 486 215 419 492 216 419 minecraft:red_terracotta
fill 486 215 420 486 216 420 minecraft:nether_wart_block
fill 486 215 426 487 216 426 minecraft:nether_wart_block
fill 486 215 428 493 216 428 minecraft:red_terracotta
fill 486 215 435 492 216 435 minecraft:red_terracotta
fill 486 215 436 486 216 436 minecraft:nether_wart_block
fill 486 215 442 486 216 442 minecraft:nether_wart_block
fill 486 215 443 492 215 443 minecraft:red_terracotta
fill 486 215 450 493 216 450 minecraft:red_terracotta
fill 486 215 452 487 216 452 minecraft:nether_wart_block
fill 486 215 453 486 216 453 minecraft:red_terracotta
fill 487 215 420 491 216 420 minecraft:red_terracotta
fill 487 215 421 487 216 422 minecraft:nether_wart_block
fill 487 215 423 487 216 424 minecraft:red_terracotta
fill 487 215 425 491 216 425 minecraft:nether_wart_block
fill 487 215 427 492 216 427 minecraft:red_terracotta
fill 487 215 436 491 216 436 minecraft:red_terracotta
fill 487 215 437 488 216 437 minecraft:nether_wart_block
fill 487 215 441 488 216 441 minecraft:nether_wart_block
fill 487 215 442 491 215 442 minecraft:red_terracotta
fill 487 215 451 492 216 451 minecraft:red_terracotta
fill 487 215 453 491 216 453 minecraft:nether_wart_block
fill 487 215 454 487 216 455 minecraft:red_terracotta
fill 487 215 456 487 216 457 minecraft:nether_wart_block
fill 488 215 421 490 216 421 minecraft:red_terracotta
fill 488 215 422 490 216 424 minecraft:nether_wart_block
fill 488 215 426 490 216 426 minecraft:red_terracotta
fill 488 215 438 490 215 440 minecraft:nether_wart_block
fill 488 215 452 491 216 452 minecraft:red_terracotta
fill 488 215 454 490 216 456 minecraft:nether_wart_block
fill 488 215 457 490 216 457 minecraft:red_terracotta
fill 489 215 437 490 216 437 minecraft:red_terracotta
fill 489 215 441 489 216 441 minecraft:red_terracotta
fill 490 215 441 491 215 441 minecraft:nether_wart_block
fill 491 215 421 491 216 422 minecraft:nether_wart_block
fill 491 215 423 502 216 423 minecraft:red_terracotta
fill 491 215 424 491 216 424 minecraft:nether_wart_block
fill 491 215 426 492 216 426 minecraft:nether_wart_block
fill 491 215 437 491 215 438 minecraft:nether_wart_block
setblock 491 215 439 minecraft:red_terracotta
fill 491 215 454 491 216 454 minecraft:nether_wart_block
fill 491 215 455 503 216 455 minecraft:red_terracotta
fill 491 215 456 491 216 457 minecraft:nether_wart_block
fill 492 215 420 492 216 421 minecraft:nether_wart_block
fill 492 215 422 502 216 422 minecraft:red_terracotta
fill 492 215 424 502 216 425 minecraft:red_terracotta
fill 492 215 436 492 216 436 minecraft:nether_wart_block
fill 492 215 437 492 215 438 minecraft:red_terracotta
setblock 492 215 442 minecraft:nether_wart_block
fill 492 215 452 492 216 452 minecraft:nether_wart_block
fill 492 215 453 502 216 454 minecraft:red_terracotta
fill 492 215 456 502 216 456 minecraft:red_terracotta
fill 492 215 457 492 216 457 minecraft:nether_wart_block
fill 493 215 419 493 216 420 minecraft:nether_wart_block
fill 493 215 421 501 216 421 minecraft:red_terracotta
fill 493 215 426 501 216 426 minecraft:red_terracotta
fill 493 215 427 493 216 427 minecraft:nether_wart_block
fill 493 215 435 493 216 435 minecraft:nether_wart_block
fill 493 215 436 501 215 437 minecraft:red_terracotta
setblock 493 215 443 minecraft:nether_wart_block
fill 493 215 451 493 216 451 minecraft:nether_wart_block
fill 493 215 452 501 216 452 minecraft:red_terracotta
fill 493 215 457 501 216 457 minecraft:red_terracotta
fill 494 215 418 494 216 419 minecraft:nether_wart_block
fill 494 215 420 500 216 420 minecraft:red_terracotta
fill 494 215 427 500 216 427 minecraft:red_terracotta
fill 494 215 428 494 216 428 minecraft:nether_wart_block
fill 494 215 434 494 216 434 minecraft:nether_wart_block
fill 494 215 435 500 216 435 minecraft:red_terracotta
fill 494 215 438 502 215 438 minecraft:red_terracotta
fill 494 215 442 500 215 443 minecraft:red_terracotta
fill 494 215 444 494 216 444 minecraft:nether_wart_block
fill 494 215 450 494 216 450 minecraft:nether_wart_block
fill 494 215 451 500 216 451 minecraft:red_terracotta
fill 495 215 417 495 216 418 minecraft:nether_wart_block
fill 495 215 419 499 216 419 minecraft:red_terracotta
fill 495 215 428 499 216 428 minecraft:red_terracotta
fill 495 215 429 495 216 430 minecraft:nether_wart_block
fill 495 215 431 495 216 432 minecraft:red_terracotta
fill 495 215 433 499 216 433 minecraft:nether_wart_block
fill 495 215 434 499 216 434 minecraft:red_terracotta
fill 495 215 439 503 215 439 minecraft:red_terracotta
fill 495 215 441 502 215 441 minecraft:red_terracotta
fill 495 215 444 499 216 444 minecraft:red_terracotta
fill 495 215 445 496 216 446 minecraft:nether_wart_block
fill 495 215 447 495 216 447 minecraft:red_terracotta
fill 495 215 448 495 216 449 minecraft:nether_wart_block
fill 495 215 450 499 216 450 minecraft:red_terracotta
fill 496 215 417 499 216 417 minecraft:nether_wart_block
fill 496 215 418 498 216 418 minecraft:red_terracotta
fill 496 215 429 498 216 429 minecraft:red_terracotta
fill 496 215 430 498 216 432 minecraft:nether_wart_block
fill 496 215 440 502 215 440 minecraft:red_terracotta
fill 496 215 447 498 216 448 minecraft:nether_wart_block
fill 496 215 449 497 216 449 minecraft:red_terracotta
fill 497 215 445 497 216 445 minecraft:red_terracotta
fill 497 215 446 499 216 446 minecraft:nether_wart_block
fill 498 215 445 499 216 445 minecraft:nether_wart_block
fill 498 215 449 499 216 449 minecraft:nether_wart_block
fill 499 215 418 500 216 418 minecraft:nether_wart_block
fill 499 215 429 499 216 430 minecraft:nether_wart_block
fill 499 215 431 510 216 432 minecraft:red_terracotta
fill 499 215 447 510 216 447 minecraft:red_terracotta
fill 499 215 448 499 216 448 minecraft:nether_wart_block
fill 500 215 417 510 216 417 minecraft:red_terracotta
fill 500 215 419 501 216 419 minecraft:nether_wart_block
fill 500 215 428 500 216 428 minecraft:nether_wart_block
fill 500 215 429 509 216 430 minecraft:red_terracotta
fill 500 215 433 510 216 433 minecraft:red_terracotta
fill 500 215 434 500 216 434 minecraft:nether_wart_block
fill 500 215 444 500 216 444 minecraft:nether_wart_block
fill 500 215 445 509 216 446 minecraft:red_terracotta
fill 500 215 448 509 216 449 minecraft:red_terracotta
fill 500 215 450 500 216 450 minecraft:nether_wart_block
fill 501 215 418 509 216 418 minecraft:red_terracotta
fill 501 215 420 502 216 420 minecraft:nether_wart_block
fill 501 215 427 501 216 427 minecraft:nether_wart_block
fill 501 215 428 508 216 428 minecraft:red_terracotta
fill 501 215 434 509 216 434 minecraft:red_terracotta
fill 501 215 435 501 216 435 minecraft:nether_wart_block
fill 501 215 442 501 216 442 minecraft:red_terracotta
fill 501 215 443 501 216 443 minecraft:nether_wart_block
fill 501 215 444 509 216 444 minecraft:red_terracotta
fill 501 215 450 508 216 450 minecraft:red_terracotta
fill 501 215 451 501 216 451 minecraft:nether_wart_block
fill 502 215 419 508 216 419 minecraft:red_terracotta
fill 502 215 421 503 216 421 minecraft:nether_wart_block
fill 502 215 426 502 216 426 minecraft:nether_wart_block
fill 502 215 427 507 216 427 minecraft:red_terracotta
fill 502 215 435 508 216 435 minecraft:red_terracotta
fill 502 215 436 502 216 436 minecraft:nether_wart_block
fill 502 215 437 502 216 437 minecraft:red_terracotta
fill 502 215 442 502 216 442 minecraft:nether_wart_block
fill 502 215 443 508 216 443 minecraft:red_terracotta
fill 502 215 451 507 216 451 minecraft:red_terracotta
fill 502 215 452 502 216 452 minecraft:nether_wart_block
fill 502 215 457 503 216 457 minecraft:nether_wart_block
fill 503 215 420 507 216 420 minecraft:red_terracotta
fill 503 215 422 506 216 425 minecraft:nether_wart_block
fill 503 215 426 506 216 426 minecraft:red_terracotta
fill 503 215 436 507 216 436 minecraft:red_terracotta
fill 503 215 437 503 216 438 minecraft:nether_wart_block
fill 503 215 440 504 216 441 minecraft:nether_wart_block
fill 503 215 442 507 216 442 minecraft:red_terracotta
fill 503 215 452 506 216 452 minecraft:red_terracotta
fill 503 215 453 506 216 454 minecraft:nether_wart_block
fill 503 215 456 507 216 456 minecraft:nether_wart_block
fill 504 215 421 506 216 421 minecraft:red_terracotta
fill 504 215 437 505 216 437 minecraft:red_terracotta
fill 504 215 438 506 216 439 minecraft:nether_wart_block
fill 504 215 455 506 216 455 minecraft:nether_wart_block
fill 504 215 457 506 216 457 minecraft:red_terracotta
fill 505 215 440 506 216 440 minecraft:nether_wart_block
fill 505 215 441 505 216 441 minecraft:red_terracotta
fill 506 215 437 507 216 437 minecraft:nether_wart_block
fill 506 215 441 507 216 441 minecraft:nether_wart_block
fill 507 215 421 507 216 422 minecraft:nether_wart_block
fill 507 215 423 511 216 424 minecraft:red_terracotta
fill 507 215 425 507 216 426 minecraft:nether_wart_block
fill 507 215 438 511 216 440 minecraft:red_terracotta
fill 507 215 452 507 216 453 minecraft:nether_wart_block
fill 507 215 454 511 216 455 minecraft:red_terracotta
fill 507 215 457 507 216 457 minecraft:nether_wart_block
fill 508 215 420 508 216 420 minecraft:nether_wart_block
fill 508 215 421 511 216 422 minecraft:red_terracotta
fill 508 215 425 511 216 425 minecraft:red_terracotta
fill 508 215 426 508 216 427 minecraft:nether_wart_block
fill 508 215 436 508 216 436 minecraft:nether_wart_block
fill 508 215 437 511 216 437 minecraft:red_terracotta
fill 508 215 441 511 216 441 minecraft:red_terracotta
fill 508 215 442 508 216 442 minecraft:nether_wart_block
fill 508 215 451 508 216 452 minecraft:nether_wart_block
fill 508 215 453 511 216 453 minecraft:red_terracotta
fill 508 215 456 511 216 457 minecraft:red_terracotta
fill 509 215 419 509 216 419 minecraft:nether_wart_block
fill 509 215 420 511 216 420 minecraft:red_terracotta
fill 509 215 426 511 216 426 minecraft:red_terracotta
fill 509 215 427 509 216 428 minecraft:nether_wart_block
fill 509 215 435 509 216 435 minecraft:nether_wart_block
fill 509 215 436 511 216 436 minecraft:red_terracotta
fill 509 215 442 511 216 442 minecraft:red_terracotta
fill 509 215 443 509 216 443 minecraft:nether_wart_block
fill 509 215 450 509 216 451 minecraft:nether_wart_block
fill 509 215 452 511 216 452 minecraft:red_terracotta
fill 510 215 418 511 216 418 minecraft:nether_wart_block
fill 510 215 419 511 216 419 minecraft:red_terracotta
fill 510 215 427 511 216 427 minecraft:red_terracotta
fill 510 215 428 510 216 429 minecraft:nether_wart_block
fill 510 215 430 510 216 430 minecraft:red_terracotta
fill 510 215 434 510 216 434 minecraft:nether_wart_block
fill 510 215 435 511 216 435 minecraft:red_terracotta
fill 510 215 443 511 216 443 minecraft:red_terracotta
fill 510 215 444 510 216 445 minecraft:nether_wart_block
fill 510 215 446 510 216 446 minecraft:red_terracotta
fill 510 215 448 510 216 448 minecraft:red_terracotta
fill 510 215 449 510 216 450 minecraft:nether_wart_block
fill 510 215 451 511 216 451 minecraft:red_terracotta
fill 511 215 417 511 216 417 minecraft:nether_wart_block
fill 511 215 428 511 216 428 minecraft:red_terracotta
fill 511 215 429 511 216 433 minecraft:nether_wart_block
fill 511 215 434 511 216 434 minecraft:red_terracotta
fill 511 215 444 511 216 444 minecraft:red_terracotta
fill 511 215 445 511 216 449 minecraft:nether_wart_block
fill 511 215 450 511 216 450 minecraft:red_terracotta
fill 486 216 443 491 216 443 minecraft:red_terracotta
fill 487 216 442 490 216 442 minecraft:red_terracotta
fill 488 216 438 489 216 440 minecraft:nether_wart_block
setblock 490 216 438 minecraft:nether_wart_block
fill 490 216 439 490 216 441 minecraft:shroomlight
setblock 491 216 437 minecraft:nether_wart_block
fill 491 216 438 491 216 439 minecraft:shroomlight
fill 491 216 441 491 216 442 minecraft:shroomlight
fill 492 216 437 492 216 438 minecraft:shroomlight
fill 492 216 442 492 216 443 minecraft:shroomlight
fill 493 216 436 501 216 436 minecraft:red_terracotta
fill 493 216 437 494 216 437 minecraft:shroomlight
fill 493 216 443 494 216 443 minecraft:shroomlight
fill 494 216 438 495 216 438 minecraft:shroomlight
fill 494 216 442 495 216 442 minecraft:shroomlight
fill 495 216 437 501 216 437 minecraft:red_terracotta
fill 495 216 439 496 216 439 minecraft:shroomlight
fill 495 216 441 496 216 441 minecraft:shroomlight
fill 495 216 443 500 216 443 minecraft:red_terracotta
fill 496 216 438 502 216 438 minecraft:red_terracotta
setblock 496 216 440 minecraft:shroomlight
fill 496 216 442 500 216 442 minecraft:red_terracotta
fill 497 216 439 502 216 441 minecraft:red_terracotta
setblock 503 216 439 minecraft:red_terracotta
fill 470 220 421 470 221 421 minecraft:orange_concrete
fill 470 220 424 470 220 425 minecraft:orange_concrete
fill 470 220 432 470 221 433 minecraft:orange_concrete
fill 470 220 444 470 220 445 minecraft:orange_concrete
fill 470 220 453 470 221 453 minecraft:orange_concrete
setblock 470 220 456 minecraft:orange_concrete
fill 470 220 457 470 223 457 minecraft:netherrack
fill 474 220 434 479 221 434 minecraft:red_nether_bricks
fill 475 220 432 479 220 433 minecraft:red_nether_bricks
fill 475 220 435 478 224 436 minecraft:red_nether_bricks
fill 476 220 431 478 220 431 minecraft:red_nether_bricks
fill 476 220 437 477 227 437 minecraft:red_nether_bricks
fill 476 220 458 477 221 458 minecraft:orange_concrete
fill 477 220 416 478 220 416 minecraft:orange_concrete
fill 488 220 458 489 220 458 minecraft:orange_concrete
fill 489 220 416 490 221 416 minecraft:orange_concrete
setblock 493 220 421 minecraft:magma_block
fill 496 220 458 497 221 458 minecraft:orange_concrete
fill 497 220 416 498 220 416 minecraft:orange_concrete
setblock 500 220 458 minecraft:orange_concrete
fill 501 220 416 501 221 416 minecraft:orange_concrete
fill 501 220 458 501 223 458 minecraft:netherrack
fill 508 220 458 509 221 458 minecraft:orange_concrete
fill 509 220 416 510 221 416 minecraft:orange_concrete
fill 512 220 421 512 223 421 minecraft:netherrack
setblock 512 220 422 minecraft:orange_concrete
fill 512 220 425 512 221 426 minecraft:orange_concrete
fill 512 220 433 512 220 434 minecraft:orange_concrete
fill 512 220 445 512 221 446 minecraft:orange_concrete
fill 512 220 453 512 220 454 minecraft:orange_concrete
fill 512 220 457 512 221 457 minecraft:orange_concrete
setblock 470 221 420 minecraft:orange_concrete
fill 470 221 424 470 224 425 minecraft:netherrack
fill 470 221 440 470 223 440 minecraft:netherrack
setblock 470 221 441 minecraft:orange_concrete
setblock 470 221 444 minecraft:orange_concrete
fill 470 221 445 470 224 445 minecraft:netherrack
setblock 470 221 452 minecraft:orange_concrete
fill 470 221 456 470 224 456 minecraft:netherrack
fill 474 221 435 474 223 436 minecraft:red_nether_bricks
fill 475 221 432 478 221 433 minecraft:red_nether_bricks
fill 475 221 437 475 226 437 minecraft:red_nether_bricks
fill 476 221 438 476 228 438 minecraft:red_nether_bricks
fill 477 221 416 477 224 416 minecraft:netherrack
fill 477 221 431 477 223 431 minecraft:magma_block
setblock 478 221 416 minecraft:orange_concrete
fill 478 221 437 478 226 437 minecraft:red_nether_bricks
setblock 481 221 416 minecraft:orange_concrete
fill 482 221 416 482 223 416 minecraft:netherrack
fill 484 221 458 485 221 458 minecraft:orange_concrete
setblock 488 221 458 minecraft:orange_concrete
fill 489 221 458 489 224 458 minecraft:netherrack
fill 497 221 416 498 224 416 minecraft:netherrack
fill 500 221 458 500 223 458 minecraft:netherrack
setblock 502 221 416 minecraft:orange_concrete
fill 504 221 458 504 223 458 minecraft:netherrack
setblock 505 221 458 minecraft:orange_concrete
setblock 512 221 417 minecraft:orange_concrete
fill 512 221 418 512 223 418 minecraft:netherrack
fill 512 221 422 512 224 422 minecraft:netherrack
fill 512 221 433 512 224 433 minecraft:netherrack
setblock 512 221 434 minecraft:orange_concrete
fill 512 221 437 512 221 438 minecraft:orange_concrete
fill 512 221 453 512 223 454 minecraft:netherrack
fill 470 222 418 470 223 419 minecraft:orange_concrete
fill 470 222 420 470 227 421 minecraft:netherrack
setblock 470 222 422 minecraft:orange_concrete
fill 470 222 423 470 225 423 minecraft:netherrack
fill 470 222 430 470 223 431 minecraft:orange_concrete
fill 470 222 432 470 227 433 minecraft:netherrack
setblock 470 222 438 minecraft:netherrack
fill 470 222 439 470 223 439 minecraft:orange_concrete
fill 470 222 441 470 227 441 minecraft:netherrack
fill 470 222 442 470 222 443 minecraft:orange_concrete
fill 470 222 444 470 227 444 minecraft:netherrack
fill 470 222 450 470 223 451 minecraft:orange_concrete
fill 470 222 452 470 227 453 minecraft:netherrack
fill 471 222 416 472 223 416 minecraft:orange_concrete
fill 471 222 417 473 222 417 minecraft:red_nether_bricks
fill 471 222 419 471 222 421 minecraft:red_nether_bricks
fill 471 222 423 471 222 425 minecraft:red_nether_bricks
fill 471 222 427 471 222 429 minecraft:red_nether_bricks
fill 471 222 431 471 222 433 minecraft:red_nether_bricks
fill 471 222 435 471 222 437 minecraft:red_nether_bricks
fill 471 222 439 471 222 441 minecraft:red_nether_bricks
fill 471 222 443 471 222 445 minecraft:red_nether_bricks
fill 471 222 447 471 222 449 minecraft:red_nether_bricks
fill 471 222 451 471 222 453 minecraft:red_nether_bricks
fill 471 222 455 471 222 457 minecraft:red_nether_bricks
fill 473 222 457 475 222 457 minecraft:red_nether_bricks
fill 474 222 437 474 225 437 minecraft:red_nether_bricks
fill 474 222 458 475 222 458 minecraft:orange_concrete
fill 475 222 417 477 222 417 minecraft:red_nether_bricks
fill 475 222 433 478 222 434 minecraft:red_nether_bricks
fill 475 222 438 475 227 438 minecraft:red_nether_bricks
fill 476 222 439 476 229 439 minecraft:red_nether_bricks
fill 476 222 458 477 227 458 minecraft:netherrack
fill 477 222 432 477 224 432 minecraft:magma_block
fill 477 222 438 477 228 438 minecraft:red_nether_bricks
fill 477 222 457 479 222 457 minecraft:red_nether_bricks
fill 478 222 416 478 227 416 minecraft:netherrack
fill 479 222 416 480 222 416 minecraft:orange_concrete
fill 479 222 417 481 222 417 minecraft:red_nether_bricks
fill 481 222 416 481 227 416 minecraft:netherrack
fill 481 222 457 483 222 457 minecraft:red_nether_bricks
setblock 482 222 458 minecraft:netherrack
fill 483 222 416 483 223 416 minecraft:orange_concrete
fill 483 222 417 485 222 417 minecraft:red_nether_bricks
fill 483 222 458 483 223 458 minecraft:orange_concrete
setblock 484 222 416 minecraft:netherrack
fill 484 222 458 485 227 458 minecraft:netherrack
fill 485 222 457 487 222 457 minecraft:red_nether_bricks
setblock 486 222 458 minecraft:orange_concrete
fill 487 222 417 489 222 417 minecraft:red_nether_bricks
fill 487 222 458 488 225 458 minecraft:netherrack
fill 489 222 416 490 227 416 minecraft:netherrack
fill 489 222 457 491 222 457 minecraft:red_nether_bricks
fill 491 222 416 492 223 416 minecraft:orange_concrete
fill 491 222 417 493 222 417 minecraft:red_nether_bricks
fill 493 222 457 495 222 457 minecraft:red_nether_bricks
fill 494 222 458 495 223 458 minecraft:orange_concrete
fill 495 222 417 497 222 417 minecraft:red_nether_bricks
fill 496 222 458 497 227 458 minecraft:netherrack
fill 497 222 444 499 223 444 minecraft:netherrack
fill 497 222 457 499 222 457 minecraft:red_nether_bricks
fill 498 222 443 499 223 443 minecraft:netherrack
fill 499 222 416 499 225 416 minecraft:netherrack
fill 499 222 417 501 222 417 minecraft:red_nether_bricks
setblock 500 222 416 minecraft:orange_concrete
fill 501 222 416 502 227 416 minecraft:netherrack
fill 501 222 457 503 222 457 minecraft:red_nether_bricks
setblock 502 222 458 minecraft:netherrack
fill 503 222 416 504 223 416 minecraft:orange_concrete
fill 503 222 417 505 222 417 minecraft:red_nether_bricks
fill 503 222 458 503 223 458 minecraft:orange_concrete
fill 505 222 457 507 222 457 minecraft:red_nether_bricks
fill 505 222 458 505 227 458 minecraft:netherrack
fill 506 222 458 507 222 458 minecraft:orange_concrete
fill 507 222 417 509 222 417 minecraft:red_nether_bricks
fill 508 222 458 509 224 458 minecraft:netherrack
fill 509 222 416 510 227 416 minecraft:netherrack
fill 509 222 457 511 222 457 minecraft:red_nether_bricks
fill 511 222 416 512 222 416 minecraft:orange_concrete
fill 511 222 417 511 222 419 minecraft:red_nether_bricks
fill 511 222 421 511 222 423 minecraft:red_nether_bricks
fill 511 222 425 511 222 427 minecraft:red_nether_bricks
fill 511 222 429 511 222 431 minecraft:red_nether_bricks
fill 511 222 433 511 222 435 minecraft:red_nether_bricks
fill 511 222 437 511 222 439 minecraft:red_nether_bricks
fill 511 222 441 511 222 443 minecraft:red_nether_bricks
fill 511 222 445 511 222 447 minecraft:red_nether_bricks
fill 511 222 449 511 222 451 minecraft:red_nether_bricks
fill 511 222 453 511 222 455 minecraft:red_nether_bricks
fill 512 222 417 512 227 417 minecraft:netherrack
fill 512 222 425 512 227 426 minecraft:netherrack
fill 512 222 427 512 223 428 minecraft:orange_concrete
fill 512 222 434 512 225 435 minecraft:netherrack
setblock 512 222 436 minecraft:orange_concrete
fill 512 222 437 512 227 438 minecraft:netherrack
fill 512 222 439 512 223 439 minecraft:orange_concrete
setblock 512 222 440 minecraft:netherrack
fill 512 222 445 512 227 446 minecraft:netherrack
fill 512 222 447 512 223 448 minecraft:orange_concrete
fill 512 222 455 512 225 455 minecraft:netherrack
setblock 512 222 456 minecraft:orange_concrete
fill 512 222 457 512 227 457 minecraft:netherrack
fill 470 223 422 470 226 422 minecraft:netherrack
fill 470 223 426 470 225 426 minecraft:netherrack
setblock 470 223 427 minecraft:orange_concrete
setblock 470 223 438 minecraft:orange_concrete
fill 470 223 442 470 226 443 minecraft:netherrack
fill 470 223 458 470 225 458 minecraft:netherrack
setblock 471 223 458 minecraft:orange_concrete
fill 474 223 438 474 226 438 minecraft:red_nether_bricks
setblock 474 223 458 minecraft:orange_concrete
fill 475 223 434 478 223 434 minecraft:red_nether_bricks
fill 475 223 439 475 228 439 minecraft:red_nether_bricks
fill 475 223 458 475 226 458 minecraft:netherrack
setblock 476 223 433 minecraft:red_nether_bricks
fill 477 223 439 477 229 439 minecraft:red_nether_bricks
fill 478 223 438 478 227 438 minecraft:red_nether_bricks
fill 479 223 416 480 226 416 minecraft:netherrack
setblock 482 223 458 minecraft:orange_concrete
setblock 484 223 416 minecraft:orange_concrete
fill 486 223 458 486 226 458 minecraft:netherrack
setblock 495 223 416 minecraft:orange_concrete
fill 496 223 416 496 225 416 minecraft:netherrack
fill 500 223 416 500 226 416 minecraft:netherrack
setblock 502 223 458 minecraft:orange_concrete
setblock 506 223 458 minecraft:orange_concrete
fill 507 223 458 507 226 458 minecraft:netherrack
fill 511 223 416 511 226 416 minecraft:netherrack
setblock 512 223 416 minecraft:orange_concrete
fill 512 223 419 512 223 420 minecraft:orange_concrete
fill 512 223 436 512 226 436 minecraft:netherrack
setblock 512 223 440 minecraft:orange_concrete
setblock 512 223 451 minecraft:orange_concrete
fill 512 223 452 512 225 452 minecraft:netherrack
fill 512 223 456 512 225 456 minecraft:netherrack
fill 470 224 416 470 225 417 minecraft:orange_concrete
fill 470 224 418 470 229 419 minecraft:netherrack
fill 470 224 427 470 229 427 minecraft:netherrack
fill 470 224 428 470 224 429 minecraft:orange_concrete
fill 470 224 430 470 229 431 minecraft:netherrack
fill 470 224 436 470 225 437 minecraft:orange_concrete
fill 470 224 438 470 229 439 minecraft:netherrack
setblock 470 224 440 minecraft:orange_concrete
fill 470 224 448 470 225 449 minecraft:orange_concrete
fill 470 224 450 470 229 451 minecraft:netherrack
fill 470 224 457 470 225 457 minecraft:orange_concrete
fill 471 224 416 472 229 416 minecraft:netherrack
fill 471 224 458 471 229 458 minecraft:netherrack
fill 472 224 458 473 224 458 minecraft:orange_concrete
fill 473 224 416 474 225 416 minecraft:orange_concrete
setblock 473 224 419 minecraft:light[level=14]
setblock 473 224 427 minecraft:light[level=14]
setblock 473 224 435 minecraft:light[level=14]
setblock 473 224 443 minecraft:light[level=14]
setblock 473 224 451 minecraft:light[level=14]
setblock 474 224 436 minecraft:red_nether_bricks
fill 474 224 439 474 227 439 minecraft:red_nether_bricks
fill 474 224 458 474 229 458 minecraft:netherrack
fill 475 224 440 477 229 440 minecraft:red_nether_bricks
fill 476 224 434 477 224 434 minecraft:red_nether_bricks
fill 478 224 439 478 229 439 minecraft:red_nether_bricks
fill 480 224 458 481 225 458 minecraft:orange_concrete
setblock 481 224 419 minecraft:light[level=14]
setblock 481 224 427 minecraft:light[level=14]
setblock 481 224 435 minecraft:light[level=14]
setblock 481 224 443 minecraft:light[level=14]
setblock 481 224 451 minecraft:light[level=14]
setblock 482 224 416 minecraft:orange_concrete
fill 482 224 458 483 229 458 minecraft:netherrack
fill 483 224 416 484 229 416 minecraft:netherrack
fill 485 224 416 486 225 416 minecraft:orange_concrete
setblock 489 224 419 minecraft:light[level=14]
setblock 489 224 427 minecraft:light[level=14]
setblock 489 224 435 minecraft:light[level=14]
setblock 489 224 443 minecraft:light[level=14]
setblock 489 224 451 minecraft:light[level=14]
fill 491 224 416 492 229 416 minecraft:netherrack
fill 492 224 458 493 224 458 minecraft:orange_concrete
fill 493 224 416 494 224 416 minecraft:orange_concrete
fill 494 224 458 495 229 458 minecraft:netherrack
fill 495 224 416 495 229 416 minecraft:netherrack
setblock 497 224 419 minecraft:light[level=14]
setblock 497 224 427 minecraft:light[level=14]
setblock 497 224 435 minecraft:light[level=14]
setblock 497 224 443 minecraft:light[level=14]
setblock 497 224 451 minecraft:light[level=14]
fill 500 224 458 501 225 458 minecraft:orange_concrete
fill 502 224 458 503 229 458 minecraft:netherrack
fill 503 224 416 504 229 416 minecraft:netherrack
setblock 504 224 458 minecraft:orange_concrete
fill 505 224 416 506 225 416 minecraft:orange_concrete
setblock 505 224 419 minecraft:light[level=14]
setblock 505 224 427 minecraft:light[level=14]
setblock 505 224 435 minecraft:light[level=14]
setblock 505 224 443 minecraft:light[level=14]
setblock 505 224 451 minecraft:light[level=14]
fill 506 224 458 506 226 458 minecraft:netherrack
fill 512 224 416 512 229 416 minecraft:netherrack
setblock 512 224 418 minecraft:orange_concrete
fill 512 224 419 512 229 420 minecraft:netherrack
fill 512 224 421 512 225 421 minecraft:orange_concrete
fill 512 224 427 512 229 428 minecraft:netherrack
fill 512 224 429 512 224 430 minecraft:orange_concrete
fill 512 224 439 512 229 440 minecraft:netherrack
fill 512 224 441 512 225 442 minecraft:orange_concrete
fill 512 224 447 512 226 448 minecraft:netherrack
fill 512 224 449 512 224 450 minecraft:orange_concrete
fill 512 224 451 512 229 451 minecraft:netherrack
fill 512 224 453 512 225 453 minecraft:orange_concrete
setblock 512 224 454 minecraft:netherrack
fill 512 224 458 512 225 458 minecraft:orange_concrete
fill 470 225 424 470 225 425 minecraft:orange_concrete
setblock 470 225 428 minecraft:orange_concrete
fill 470 225 429 470 228 429 minecraft:netherrack
fill 470 225 440 470 228 440 minecraft:netherrack
setblock 470 225 445 minecraft:orange_concrete
setblock 470 225 456 minecraft:orange_concrete
fill 472 225 458 473 228 458 minecraft:netherrack
fill 475 225 436 478 225 436 minecraft:red_nether_bricks
fill 475 225 441 478 230 441 minecraft:red_nether_bricks
fill 476 225 435 477 225 435 minecraft:red_nether_bricks
setblock 477 225 416 minecraft:orange_concrete
fill 478 225 440 478 230 440 minecraft:red_nether_bricks
fill 482 225 416 482 228 416 minecraft:netherrack
setblock 489 225 458 minecraft:orange_concrete
setblock 492 225 458 minecraft:orange_concrete
fill 493 225 416 493 228 416 minecraft:netherrack
fill 493 225 458 493 228 458 minecraft:netherrack
setblock 494 225 416 minecraft:orange_concrete
fill 497 225 416 498 225 416 minecraft:orange_concrete
fill 504 225 458 504 228 458 minecraft:netherrack
fill 508 225 458 508 227 458 minecraft:netherrack
setblock 509 225 458 minecraft:orange_concrete
fill 512 225 418 512 228 418 minecraft:netherrack
setblock 512 225 422 minecraft:orange_concrete
fill 512 225 429 512 228 429 minecraft:netherrack
setblock 512 225 430 minecraft:orange_concrete
setblock 512 225 433 minecraft:orange_concrete
fill 512 225 449 512 228 449 minecraft:netherrack
setblock 512 225 450 minecraft:orange_concrete
setblock 512 225 454 minecraft:orange_concrete
fill 470 226 416 470 231 417 minecraft:netherrack
fill 470 226 423 470 227 423 minecraft:orange_concrete
fill 470 226 424 470 231 425 minecraft:netherrack
setblock 470 226 426 minecraft:orange_concrete
fill 470 226 428 470 231 428 minecraft:netherrack
fill 470 226 434 470 227 435 minecraft:orange_concrete
fill 470 226 436 470 231 437 minecraft:netherrack
fill 470 226 445 470 231 445 minecraft:netherrack
fill 470 226 446 470 226 447 minecraft:orange_concrete
fill 470 226 448 470 231 449 minecraft:netherrack
fill 470 226 454 470 227 455 minecraft:orange_concrete
fill 470 226 456 470 231 457 minecraft:netherrack
setblock 470 226 458 minecraft:orange_concrete
fill 473 226 416 474 231 416 minecraft:netherrack
fill 474 226 440 474 227 440 minecraft:red_nether_bricks
fill 475 226 416 476 226 416 minecraft:orange_concrete
fill 475 226 436 477 226 436 minecraft:red_nether_bricks
fill 476 226 442 478 232 442 minecraft:red_nether_bricks
fill 477 226 416 477 231 416 minecraft:netherrack
fill 478 226 458 479 227 458 minecraft:orange_concrete
fill 480 226 458 481 231 458 minecraft:netherrack
fill 485 226 416 486 231 416 minecraft:netherrack
fill 487 226 416 488 227 416 minecraft:orange_concrete
fill 487 226 458 487 227 458 minecraft:orange_concrete
fill 488 226 458 489 227 458 minecraft:netherrack
fill 490 226 458 491 226 458 minecraft:orange_concrete
fill 492 226 458 492 231 458 minecraft:netherrack
fill 494 226 416 494 231 416 minecraft:netherrack
setblock 496 226 416 minecraft:orange_concrete
fill 497 226 416 498 231 416 minecraft:netherrack
fill 498 226 458 499 227 458 minecraft:orange_concrete
fill 499 226 416 499 227 416 minecraft:orange_concrete
fill 500 226 458 501 231 458 minecraft:netherrack
fill 505 226 416 506 231 416 minecraft:netherrack
fill 507 226 416 508 226 416 minecraft:orange_concrete
fill 509 226 458 509 227 458 minecraft:netherrack
fill 510 226 458 511 226 458 minecraft:orange_concrete
fill 512 226 421 512 231 422 minecraft:netherrack
fill 512 226 423 512 227 424 minecraft:orange_concrete
fill 512 226 430 512 231 430 minecraft:netherrack
fill 512 226 431 512 226 432 minecraft:orange_concrete
fill 512 226 433 512 227 434 minecraft:netherrack
fill 512 226 435 512 227 435 minecraft:orange_concrete
fill 512 226 441 512 231 442 minecraft:netherrack
fill 512 226 443 512 227 444 minecraft:orange_concrete
fill 512 226 450 512 228 450 minecraft:netherrack
setblock 512 226 452 minecraft:orange_concrete
fill 512 226 453 512 231 454 minecraft:netherrack
fill 512 226 455 512 227 456 minecraft:orange_concrete
fill 512 226 458 512 231 458 minecraft:netherrack
setblock 470 227 422 minecraft:orange_concrete
fill 470 227 426 470 230 426 minecraft:netherrack
fill 470 227 442 470 227 443 minecraft:orange_concrete
setblock 470 227 446 minecraft:orange_concrete
fill 470 227 447 470 230 447 minecraft:netherrack
fill 470 227 458 470 230 458 minecraft:netherrack
fill 475 227 416 475 230 416 minecraft:netherrack
fill 475 227 442 475 231 442 minecraft:red_nether_bricks
setblock 475 227 458 minecraft:orange_concrete
setblock 476 227 416 minecraft:orange_concrete
fill 476 227 443 478 232 443 minecraft:red_nether_bricks
fill 479 227 416 480 227 416 minecraft:orange_concrete
fill 479 227 440 479 228 441 minecraft:red_nether_bricks
setblock 486 227 458 minecraft:orange_concrete
fill 490 227 458 491 229 458 minecraft:netherrack
fill 496 227 416 496 230 416 minecraft:netherrack
setblock 500 227 416 minecraft:orange_concrete
fill 506 227 458 507 227 458 minecraft:orange_concrete
fill 507 227 416 507 230 416 minecraft:netherrack
setblock 508 227 416 minecraft:orange_concrete
setblock 510 227 458 minecraft:orange_concrete
setblock 511 227 416 minecraft:orange_concrete
fill 511 227 458 511 230 458 minecraft:netherrack
fill 512 227 431 512 230 432 minecraft:netherrack
setblock 512 227 436 minecraft:orange_concrete
setblock 512 227 447 minecraft:orange_concrete
fill 512 227 448 512 229 448 minecraft:netherrack
fill 512 227 452 512 230 452 minecraft:netherrack
fill 470 228 420 470 229 421 minecraft:orange_concrete
fill 470 228 422 470 233 423 minecraft:netherrack
fill 470 228 432 470 228 433 minecraft:orange_concrete
fill 470 228 434 470 233 435 minecraft:netherrack
fill 470 228 441 470 229 441 minecraft:orange_concrete
fill 470 228 442 470 233 443 minecraft:netherrack
setblock 470 228 444 minecraft:orange_concrete
fill 470 228 446 470 233 446 minecraft:netherrack
fill 470 228 452 470 229 453 minecraft:orange_concrete
fill 470 228 454 470 233 455 minecraft:netherrack
fill 471 228 417 473 228 417 minecraft:red_nether_bricks
fill 471 228 419 471 228 421 minecraft:red_nether_bricks
fill 471 228 423 471 228 425 minecraft:red_nether_bricks
fill 471 228 427 471 228 429 minecraft:red_nether_bricks
fill 471 228 431 471 228 433 minecraft:red_nether_bricks
fill 471 228 435 471 228 437 minecraft:red_nether_bricks
fill 471 228 439 471 228 441 minecraft:red_nether_bricks
fill 471 228 443 471 228 445 minecraft:red_nether_bricks
fill 471 228 447 471 228 449 minecraft:red_nether_bricks
fill 471 228 451 471 228 453 minecraft:red_nether_bricks
fill 471 228 455 471 228 457 minecraft:red_nether_bricks
fill 473 228 457 475 228 457 minecraft:red_nether_bricks
fill 475 228 417 477 228 417 minecraft:red_nether_bricks
fill 475 228 443 475 231 443 minecraft:red_nether_bricks
fill 475 228 458 475 233 458 minecraft:netherrack
fill 476 228 416 476 233 416 minecraft:netherrack
fill 476 228 444 478 233 444 minecraft:red_nether_bricks
fill 476 228 458 477 228 458 minecraft:orange_concrete
fill 477 228 457 479 228 457 minecraft:red_nether_bricks
setblock 478 228 416 minecraft:orange_concrete
fill 478 228 458 479 233 458 minecraft:netherrack
fill 479 228 416 480 233 416 minecraft:netherrack
fill 479 228 417 481 228 417 minecraft:red_nether_bricks
fill 479 228 442 479 232 443 minecraft:red_nether_bricks
fill 481 228 416 481 229 416 minecraft:orange_concrete
fill 481 228 457 483 228 457 minecraft:red_nether_bricks
fill 483 228 417 485 228 417 minecraft:red_nether_bricks
fill 484 228 458 485 229 458 minecraft:orange_concrete
fill 485 228 457 487 228 457 minecraft:red_nether_bricks
fill 486 228 458 487 233 458 minecraft:netherrack
fill 487 228 416 488 233 416 minecraft:netherrack
fill 487 228 417 489 228 417 minecraft:red_nether_bricks
setblock 488 228 458 minecraft:orange_concrete
fill 489 228 416 490 228 416 minecraft:orange_concrete
fill 489 228 457 491 228 457 minecraft:red_nether_bricks
fill 489 228 458 489 231 458 minecraft:netherrack
fill 491 228 417 493 228 417 minecraft:red_nether_bricks
fill 493 228 457 495 228 457 minecraft:red_nether_bricks
fill 495 228 417 497 228 417 minecraft:red_nether_bricks
fill 496 228 458 497 229 458 minecraft:orange_concrete
fill 497 228 457 499 228 457 minecraft:red_nether_bricks
fill 498 228 458 499 233 458 minecraft:netherrack
fill 499 228 416 500 233 416 minecraft:netherrack
fill 499 228 417 501 228 417 minecraft:red_nether_bricks
fill 501 228 416 502 229 416 minecraft:orange_concrete
fill 501 228 457 503 228 457 minecraft:red_nether_bricks
fill 503 228 417 505 228 417 minecraft:red_nether_bricks
fill 505 228 457 507 228 457 minecraft:red_nether_bricks
fill 505 228 458 505 229 458 minecraft:orange_concrete
fill 506 228 458 507 229 458 minecraft:netherrack
fill 507 228 417 509 228 417 minecraft:red_nether_bricks
fill 508 228 416 508 233 416 minecraft:netherrack
fill 508 228 458 509 228 458 minecraft:orange_concrete
fill 509 228 416 510 228 416 minecraft:orange_concrete
fill 509 228 457 511 228 457 minecraft:red_nether_bricks
fill 510 228 458 510 233 458 minecraft:netherrack
fill 511 228 416 511 233 416 minecraft:netherrack
fill 511 228 417 511 228 419 minecraft:red_nether_bricks
fill 511 228 421 511 228 423 minecraft:red_nether_bricks
fill 511 228 425 511 228 427 minecraft:red_nether_bricks
fill 511 228 429 511 228 431 minecraft:red_nether_bricks
fill 511 228 433 511 228 435 minecraft:red_nether_bricks
fill 511 228 437 511 228 439 minecraft:red_nether_bricks
fill 511 228 441 511 228 443 minecraft:red_nether_bricks
fill 511 228 445 511 228 447 minecraft:red_nether_bricks
fill 511 228 449 511 228 451 minecraft:red_nether_bricks
fill 511 228 453 511 228 455 minecraft:red_nether_bricks
fill 512 228 417 512 229 417 minecraft:orange_concrete
fill 512 228 423 512 233 424 minecraft:netherrack
fill 512 228 425 512 229 426 minecraft:orange_concrete
fill 512 228 433 512 231 433 minecraft:netherrack
setblock 512 228 434 minecraft:orange_concrete
fill 512 228 435 512 233 436 minecraft:netherrack
fill 512 228 437 512 229 438 minecraft:orange_concrete
fill 512 228 443 512 233 444 minecraft:netherrack
fill 512 228 445 512 228 446 minecraft:orange_concrete
fill 512 228 447 512 233 447 minecraft:netherrack
fill 512 228 455 512 233 456 minecraft:netherrack
fill 512 228 457 512 229 457 minecraft:orange_concrete
setblock 470 229 429 minecraft:orange_concrete
setblock 470 229 432 minecraft:orange_concrete
fill 470 229 433 470 232 433 minecraft:netherrack
setblock 470 229 440 minecraft:orange_concrete
fill 470 229 444 470 232 444 minecraft:netherrack
fill 472 229 458 473 229 458 minecraft:orange_concrete
setblock 476 229 458 minecraft:orange_concrete
fill 477 229 445 478 235 445 minecraft:red_nether_bricks
fill 477 229 458 477 232 458 minecraft:netherrack
fill 478 229 416 478 232 416 minecraft:netherrack
fill 479 229 441 479 230 441 minecraft:red_nether_bricks
fill 479 229 444 479 235 444 minecraft:red_nether_bricks
setblock 482 229 416 minecraft:orange_concrete
fill 488 229 458 488 231 458 minecraft:netherrack
fill 489 229 416 489 232 416 minecraft:netherrack
setblock 490 229 416 minecraft:orange_concrete
setblock 493 229 416 minecraft:orange_concrete
setblock 493 229 458 minecraft:orange_concrete
setblock 504 229 458 minecraft:orange_concrete
fill 508 229 458 509 231 458 minecraft:netherrack
fill 509 229 416 510 232 416 minecraft:netherrack
setblock 512 229 418 minecraft:orange_concrete
setblock 512 229 429 minecraft:orange_concrete
fill 512 229 434 512 232 434 minecraft:netherrack
fill 512 229 445 512 232 445 minecraft:netherrack
setblock 512 229 446 minecraft:orange_concrete
fill 512 229 449 512 229 450 minecraft:orange_concrete
fill 470 230 418 470 231 419 minecraft:orange_concrete
fill 470 230 420 470 235 421 minecraft:netherrack
fill 470 230 427 470 231 427 minecraft:orange_concrete
fill 470 230 429 470 235 429 minecraft:netherrack
fill 470 230 430 470 230 431 minecraft:orange_concrete
fill 470 230 432 470 235 432 minecraft:netherrack
fill 470 230 438 470 231 439 minecraft:orange_concrete
fill 470 230 440 470 235 441 minecraft:netherrack
fill 470 230 450 470 230 451 minecraft:orange_concrete
fill 470 230 452 470 235 453 minecraft:netherrack
fill 471 230 416 472 230 416 minecraft:orange_concrete
fill 471 230 458 471 231 458 minecraft:orange_concrete
fill 472 230 458 473 235 458 minecraft:netherrack
setblock 474 230 458 minecraft:orange_concrete
setblock 475 230 444 minecraft:red_nether_bricks
fill 476 230 440 477 230 440 minecraft:red_nether_bricks
fill 476 230 445 476 233 445 minecraft:red_nether_bricks
fill 476 230 458 476 235 458 minecraft:netherrack
fill 478 230 446 478 237 446 minecraft:red_nether_bricks
fill 479 230 445 479 236 445 minecraft:red_nether_bricks
fill 480 230 443 480 233 444 minecraft:red_nether_bricks
fill 481 230 416 482 235 416 minecraft:netherrack
fill 482 230 458 483 231 458 minecraft:orange_concrete
fill 483 230 416 484 231 416 minecraft:orange_concrete
fill 484 230 458 485 235 458 minecraft:netherrack
fill 490 230 416 490 235 416 minecraft:netherrack
setblock 490 230 458 minecraft:netherrack
fill 491 230 416 492 230 416 minecraft:orange_concrete
fill 491 230 458 491 231 458 minecraft:orange_concrete
fill 493 230 416 493 235 416 minecraft:netherrack
fill 493 230 458 493 235 458 minecraft:netherrack
fill 494 230 458 495 230 458 minecraft:orange_concrete
fill 495 230 416 495 231 416 minecraft:orange_concrete
fill 496 230 458 497 232 458 minecraft:netherrack
fill 501 230 416 502 235 416 minecraft:netherrack
fill 502 230 458 503 231 458 minecraft:orange_concrete
fill 503 230 416 504 231 416 minecraft:orange_concrete
fill 504 230 458 505 235 458 minecraft:netherrack
setblock 506 230 458 minecraft:orange_concrete
fill 507 230 458 507 233 458 minecraft:netherrack
setblock 512 230 416 minecraft:orange_concrete
fill 512 230 417 512 235 418 minecraft:netherrack
fill 512 230 419 512 231 420 minecraft:orange_concrete
fill 512 230 425 512 235 426 minecraft:netherrack
fill 512 230 427 512 230 428 minecraft:orange_concrete
fill 512 230 429 512 235 429 minecraft:netherrack
fill 512 230 437 512 235 438 minecraft:netherrack
fill 512 230 439 512 231 440 minecraft:orange_concrete
fill 512 230 446 512 235 446 minecraft:netherrack
setblock 512 230 448 minecraft:orange_concrete
fill 512 230 449 512 235 450 minecraft:netherrack
fill 512 230 451 512 231 451 minecraft:orange_concrete
fill 512 230 457 512 235 457 minecraft:netherrack
setblock 470 231 426 minecraft:orange_concrete
fill 470 231 430 470 234 431 minecraft:netherrack
setblock 470 231 447 minecraft:orange_concrete
setblock 470 231 450 minecraft:orange_concrete
fill 470 231 451 470 234 451 minecraft:netherrack
setblock 470 231 458 minecraft:orange_concrete
fill 471 231 416 471 234 416 minecraft:netherrack
setblock 472 231 416 minecraft:orange_concrete
fill 474 231 458 474 234 458 minecraft:netherrack
setblock 475 231 416 minecraft:orange_concrete
fill 476 231 441 478 231 441 minecraft:red_nether_bricks
fill 477 231 446 477 235 446 minecraft:red_nether_bricks
fill 479 231 446 480 237 446 minecraft:red_nether_bricks
fill 480 231 445 480 237 445 minecraft:red_nether_bricks
setblock 490 231 458 minecraft:orange_concrete
fill 491 231 416 492 234 416 minecraft:netherrack
setblock 494 231 458 minecraft:orange_concrete
fill 495 231 458 495 234 458 minecraft:netherrack
setblock 496 231 416 minecraft:orange_concrete
fill 506 231 458 506 233 458 minecraft:netherrack
setblock 507 231 416 minecraft:orange_concrete
setblock 511 231 458 minecraft:orange_concrete
fill 512 231 416 512 234 416 minecraft:netherrack
fill 512 231 427 512 234 427 minecraft:netherrack
setblock 512 231 428 minecraft:orange_concrete
fill 512 231 431 512 231 432 minecraft:orange_concrete
fill 512 231 448 512 234 448 minecraft:netherrack
setblock 512 231 452 minecraft:orange_concrete
fill 470 232 416 470 232 417 minecraft:orange_concrete
fill 470 232 418 470 237 419 minecraft:netherrack
fill 470 232 424 470 233 425 minecraft:orange_concrete
fill 470 232 426 470 237 427 minecraft:netherrack
setblock 470 232 428 minecraft:orange_concrete
fill 470 232 436 470 233 437 minecraft:orange_concrete
fill 470 232 438 470 237 439 minecraft:netherrack
fill 470 232 445 470 233 445 minecraft:orange_concrete
fill 470 232 447 470 237 447 minecraft:netherrack
fill 470 232 448 470 232 449 minecraft:orange_concrete
fill 470 232 450 470 237 450 minecraft:netherrack
fill 470 232 456 470 233 457 minecraft:orange_concrete
fill 470 232 458 471 237 458 minecraft:netherrack
fill 472 232 416 472 237 416 minecraft:netherrack
fill 473 232 416 474 232 416 minecraft:orange_concrete
setblock 473 232 419 minecraft:light[level=14]
setblock 473 232 427 minecraft:light[level=14]
setblock 473 232 435 minecraft:light[level=14]
setblock 473 232 443 minecraft:light[level=14]
setblock 473 232 451 minecraft:light[level=14]
fill 475 232 416 475 237 416 minecraft:netherrack
fill 477 232 416 477 233 416 minecraft:orange_concrete
fill 478 232 447 480 237 447 minecraft:red_nether_bricks
fill 480 232 458 481 232 458 minecraft:orange_concrete
setblock 481 232 419 minecraft:light[level=14]
setblock 481 232 427 minecraft:light[level=14]
setblock 481 232 435 minecraft:light[level=14]
setblock 481 232 443 minecraft:light[level=14]
fill 481 232 445 481 237 445 minecraft:red_nether_bricks
setblock 481 232 451 minecraft:light[level=14]
fill 482 232 458 483 237 458 minecraft:netherrack
fill 483 232 416 484 237 416 minecraft:netherrack
fill 485 232 416 486 233 416 minecraft:orange_concrete
fill 488 232 458 489 233 458 minecraft:orange_concrete
setblock 489 232 419 minecraft:light[level=14]
setblock 489 232 427 minecraft:light[level=14]
setblock 489 232 435 minecraft:light[level=14]
setblock 489 232 443 minecraft:light[level=14]
setblock 489 232 451 minecraft:light[level=14]
fill 490 232 458 491 237 458 minecraft:netherrack
setblock 492 232 458 minecraft:orange_concrete
setblock 494 232 416 minecraft:orange_concrete
fill 494 232 458 494 234 458 minecraft:netherrack
fill 495 232 416 496 237 416 minecraft:netherrack
fill 497 232 416 498 233 416 minecraft:orange_concrete
setblock 497 232 419 minecraft:light[level=14]
setblock 497 232 427 minecraft:light[level=14]
setblock 497 232 435 minecraft:light[level=14]
setblock 497 232 443 minecraft:light[level=14]
setblock 497 232 451 minecraft:light[level=14]
fill 500 232 458 501 233 458 minecraft:orange_concrete
fill 502 232 458 503 237 458 minecraft:netherrack
fill 503 232 416 504 237 416 minecraft:netherrack
fill 505 232 416 506 232 416 minecraft:orange_concrete
setblock 505 232 419 minecraft:light[level=14]
setblock 505 232 427 minecraft:light[level=14]
setblock 505 232 435 minecraft:light[level=14]
setblock 505 232 443 minecraft:light[level=14]
setblock 505 232 451 minecraft:light[level=14]
fill 507 232 416 507 237 416 minecraft:netherrack
setblock 508 232 458 minecraft:netherrack
fill 509 232 458 509 233 458 minecraft:orange_concrete
fill 511 232 458 511 237 458 minecraft:netherrack
fill 512 232 419 512 237 420 minecraft:netherrack
fill 512 232 421 512 233 422 minecraft:orange_concrete
fill 512 232 428 512 237 428 minecraft:netherrack
setblock 512 232 430 minecraft:orange_concrete
fill 512 232 431 512 237 432 minecraft:netherrack
fill 512 232 433 512 233 433 minecraft:orange_concrete
fill 512 232 439 512 237 440 minecraft:netherrack
fill 512 232 441 512 232 442 minecraft:orange_concrete
fill 512 232 451 512 237 452 minecraft:netherrack
fill 512 232 453 512 233 454 minecraft:orange_concrete
fill 512 232 458 512 233 458 minecraft:orange_concrete
setblock 470 233 416 minecraft:orange_concrete
fill 470 233 417 470 236 417 minecraft:netherrack
fill 470 233 428 470 236 428 minecraft:netherrack
setblock 470 233 433 minecraft:orange_concrete
setblock 470 233 444 minecraft:orange_concrete
fill 470 233 448 470 236 449 minecraft:netherrack
fill 473 233 416 474 236 416 minecraft:netherrack
fill 476 233 442 476 234 442 minecraft:magma_block
fill 477 233 442 478 233 443 minecraft:red_nether_bricks
fill 477 233 447 477 235 447 minecraft:red_nether_bricks
setblock 477 233 458 minecraft:orange_concrete
setblock 478 233 416 minecraft:orange_concrete
fill 478 233 448 480 237 448 minecraft:red_nether_bricks
fill 479 233 434 479 234 434 minecraft:netherrack
fill 479 233 443 479 234 443 minecraft:red_nether_bricks
setblock 480 233 458 minecraft:orange_concrete
fill 481 233 446 481 238 447 minecraft:red_nether_bricks
fill 481 233 458 481 236 458 minecraft:netherrack
fill 482 233 423 483 234 424 minecraft:magma_block
setblock 489 233 416 minecraft:orange_concrete
fill 492 233 458 492 236 458 minecraft:netherrack
fill 494 233 416 494 236 416 minecraft:netherrack
fill 495 233 420 496 234 421 minecraft:netherrack
fill 496 233 419 496 234 419 minecraft:netherrack
fill 496 233 458 496 235 458 minecraft:netherrack
setblock 497 233 458 minecraft:orange_concrete
fill 505 233 416 505 236 416 minecraft:netherrack
setblock 506 233 416 minecraft:orange_concrete
setblock 508 233 458 minecraft:orange_concrete
fill 509 233 416 510 233 416 minecraft:orange_concrete
fill 512 233 430 512 236 430 minecraft:netherrack
setblock 512 233 434 minecraft:orange_concrete
fill 512 233 441 512 236 441 minecraft:netherrack
setblock 512 233 442 minecraft:orange_concrete
setblock 512 233 445 minecraft:orange_concrete
fill 470 234 416 470 239 416 minecraft:netherrack
fill 470 234 422 470 235 423 minecraft:orange_concrete
fill 470 234 424 470 239 425 minecraft:netherrack
fill 470 234 433 470 239 433 minecraft:netherrack
fill 470 234 434 470 234 435 minecraft:orange_concrete
fill 470 234 436 470 239 437 minecraft:netherrack
fill 470 234 442 470 235 443 minecraft:orange_concrete
fill 470 234 444 470 239 445 minecraft:netherrack
setblock 470 234 446 minecraft:orange_concrete
fill 470 234 454 470 235 455 minecraft:orange_concrete
fill 470 234 456 470 239 457 minecraft:netherrack
fill 471 234 417 473 234 417 minecraft:red_nether_bricks
fill 471 234 419 471 234 421 minecraft:red_nether_bricks
fill 471 234 423 471 234 425 minecraft:red_nether_bricks
fill 471 234 427 471 234 429 minecraft:red_nether_bricks
fill 471 234 431 471 234 433 minecraft:red_nether_bricks
fill 471 234 435 471 234 437 minecraft:red_nether_bricks
fill 471 234 439 471 234 441 minecraft:red_nether_bricks
fill 471 234 443 471 234 445 minecraft:red_nether_bricks
fill 471 234 447 471 234 449 minecraft:red_nether_bricks
fill 471 234 451 471 234 453 minecraft:red_nether_bricks
fill 471 234 455 471 234 457 minecraft:red_nether_bricks
fill 473 234 457 475 234 457 minecraft:red_nether_bricks
fill 475 234 417 477 234 417 minecraft:red_nether_bricks
fill 475 234 458 475 235 458 minecraft:orange_concrete
setblock 476 234 416 minecraft:orange_concrete
fill 477 234 416 478 239 416 minecraft:netherrack
fill 477 234 442 477 235 442 minecraft:magma_block
fill 477 234 444 478 234 444 minecraft:red_nether_bricks
fill 477 234 457 479 234 457 minecraft:red_nether_bricks
fill 477 234 458 477 239 458 minecraft:netherrack
setblock 478 234 443 minecraft:red_nether_bricks
fill 478 234 458 479 234 458 minecraft:orange_concrete
fill 479 234 416 480 235 416 minecraft:orange_concrete
fill 479 234 417 481 234 417 minecraft:red_nether_bricks
fill 480 234 444 480 235 444 minecraft:red_nether_bricks
fill 480 234 449 480 240 449 minecraft:red_nether_bricks
fill 480 234 458 480 239 458 minecraft:netherrack
fill 481 234 448 481 240 448 minecraft:red_nether_bricks
fill 481 234 457 483 234 457 minecraft:red_nether_bricks
fill 482 234 447 482 240 447 minecraft:red_nether_bricks
fill 483 234 417 485 234 417 minecraft:red_nether_bricks
fill 485 234 416 486 239 416 minecraft:netherrack
fill 485 234 457 487 234 457 minecraft:red_nether_bricks
fill 486 234 458 487 235 458 minecraft:orange_concrete
fill 487 234 416 488 234 416 minecraft:orange_concrete
fill 487 234 417 489 234 417 minecraft:red_nether_bricks
fill 488 234 458 489 239 458 minecraft:netherrack
fill 489 234 416 489 239 416 minecraft:netherrack
fill 489 234 457 491 234 457 minecraft:red_nether_bricks
fill 491 234 417 493 234 417 minecraft:red_nether_bricks
fill 493 234 457 495 234 457 minecraft:red_nether_bricks
fill 495 234 417 497 234 417 minecraft:red_nether_bricks
fill 497 234 416 498 239 416 minecraft:netherrack
fill 497 234 457 499 234 457 minecraft:red_nether_bricks
fill 497 234 458 497 235 458 minecraft:netherrack
fill 498 234 458 499 234 458 minecraft:orange_concrete
fill 499 234 416 500 235 416 minecraft:orange_concrete
fill 499 234 417 501 234 417 minecraft:red_nether_bricks
fill 500 234 458 501 239 458 minecraft:netherrack
fill 501 234 457 503 234 457 minecraft:red_nether_bricks
fill 503 234 417 505 234 417 minecraft:red_nether_bricks
fill 505 234 457 507 234 457 minecraft:red_nether_bricks
fill 506 234 416 506 239 416 minecraft:netherrack
fill 506 234 458 507 235 458 minecraft:orange_concrete
fill 507 234 417 509 234 417 minecraft:red_nether_bricks
setblock 508 234 416 minecraft:orange_concrete
fill 508 234 458 509 239 458 minecraft:netherrack
fill 509 234 416 510 239 416 minecraft:netherrack
fill 509 234 457 511 234 457 minecraft:red_nether_bricks
setblock 510 234 458 minecraft:orange_concrete
fill 511 234 416 511 235 416 minecraft:orange_concrete
fill 511 234 417 511 234 419 minecraft:red_nether_bricks
fill 511 234 421 511 234 423 minecraft:red_nether_bricks
fill 511 234 425 511 234 427 minecraft:red_nether_bricks
fill 511 234 429 511 234 431 minecraft:red_nether_bricks
fill 511 234 433 511 234 435 minecraft:red_nether_bricks
fill 511 234 437 511 234 439 minecraft:red_nether_bricks
fill 511 234 441 511 234 443 minecraft:red_nether_bricks
fill 511 234 445 511 234 447 minecraft:red_nether_bricks
fill 511 234 449 511 234 451 minecraft:red_nether_bricks
fill 511 234 453 511 234 455 minecraft:red_nether_bricks
fill 512 234 421 512 239 422 minecraft:netherrack
fill 512 234 423 512 234 424 minecraft:orange_concrete
fill 512 234 433 512 239 434 minecraft:netherrack
fill 512 234 435 512 235 436 minecraft:orange_concrete
fill 512 234 442 512 239 442 minecraft:netherrack
fill 512 234 443 512 234 444 minecraft:orange_concrete
fill 512 234 445 512 239 445 minecraft:netherrack
fill 512 234 447 512 235 447 minecraft:orange_concrete
fill 512 234 453 512 239 454 minecraft:netherrack
fill 512 234 455 512 235 456 minecraft:orange_concrete
fill 512 234 458 512 236 458 minecraft:netherrack
fill 470 235 430 470 235 431 minecraft:orange_concrete
setblock 470 235 434 minecraft:orange_concrete
fill 470 235 435 470 238 435 minecraft:netherrack
fill 470 235 446 470 238 446 minecraft:netherrack
setblock 470 235 451 minecraft:orange_concrete
setblock 471 235 416 minecraft:orange_concrete
setblock 474 235 458 minecraft:orange_concrete
fill 476 235 416 476 238 416 minecraft:netherrack
setblock 478 235 444 minecraft:red_nether_bricks
fill 478 235 458 479 237 458 minecraft:netherrack
fill 479 235 449 479 238 449 minecraft:red_nether_bricks
fill 481 235 449 482 241 449 minecraft:red_nether_bricks
fill 482 235 446 482 238 446 minecraft:red_nether_bricks
fill 482 235 448 482 241 448 minecraft:red_nether_bricks
fill 487 235 416 487 238 416 minecraft:netherrack
setblock 488 235 416 minecraft:orange_concrete
fill 491 235 416 492 235 416 minecraft:orange_concrete
fill 494 235 458 495 235 458 minecraft:orange_concrete
setblock 498 235 458 minecraft:orange_concrete
fill 499 235 458 499 238 458 minecraft:netherrack
fill 508 235 416 508 238 416 minecraft:netherrack
fill 510 235 458 510 238 458 minecraft:netherrack
setblock 512 235 416 minecraft:orange_concrete
fill 512 235 423 512 238 423 minecraft:netherrack
setblock 512 235 424 minecraft:orange_concrete
setblock 512 235 427 minecraft:orange_concrete
fill 512 235 443 512 238 444 minecraft:netherrack
setblock 512 235 448 minecraft:orange_concrete
fill 470 236 420 470 236 421 minecraft:orange_concrete
fill 470 236 422 470 241 423 minecraft:netherrack
fill 470 236 429 470 237 429 minecraft:orange_concrete
fill 470 236 430 470 241 431 minecraft:netherrack
setblock 470 236 432 minecraft:orange_concrete
fill 470 236 434 470 241 434 minecraft:netherrack
fill 470 236 440 470 237 441 minecraft:orange_concrete
fill 470 236 442 470 241 443 minecraft:netherrack
fill 470 236 451 470 241 451 minecraft:netherrack
fill 470 236 452 470 236 453 minecraft:orange_concrete
fill 470 236 454 470 241 455 minecraft:netherrack
fill 471 236 416 471 241 416 minecraft:netherrack
fill 472 236 458 473 237 458 minecraft:orange_concrete
fill 474 236 458 475 241 458 minecraft:netherrack
setblock 476 236 458 minecraft:orange_concrete
setblock 478 236 445 minecraft:red_nether_bricks
fill 479 236 416 480 241 416 minecraft:netherrack
fill 480 236 450 482 239 450 minecraft:red_nether_bricks
fill 481 236 416 482 237 416 minecraft:orange_concrete
fill 483 236 447 483 240 449 minecraft:red_nether_bricks
fill 484 236 458 485 237 458 minecraft:orange_concrete
fill 486 236 458 487 241 458 minecraft:netherrack
fill 488 236 416 488 241 416 minecraft:netherrack
setblock 490 236 416 minecraft:orange_concrete
fill 491 236 416 492 241 416 minecraft:netherrack
fill 493 236 416 493 237 416 minecraft:orange_concrete
fill 493 236 458 493 237 458 minecraft:orange_concrete
fill 494 236 458 495 237 458 minecraft:netherrack
fill 496 236 458 497 236 458 minecraft:orange_concrete
fill 498 236 458 498 241 458 minecraft:netherrack
fill 499 236 416 500 241 416 minecraft:netherrack
fill 501 236 416 502 236 416 minecraft:orange_concrete
fill 504 236 458 505 237 458 minecraft:orange_concrete
fill 506 236 458 507 241 458 minecraft:netherrack
fill 511 236 416 512 241 416 minecraft:netherrack
fill 512 236 417 512 237 418 minecraft:orange_concrete
fill 512 236 424 512 241 424 minecraft:netherrack
fill 512 236 425 512 236 426 minecraft:orange_concrete
fill 512 236 427 512 241 427 minecraft:netherrack
fill 512 236 429 512 237 429 minecraft:orange_concrete
fill 512 236 435 512 241 436 minecraft:netherrack
fill 512 236 437 512 237 438 minecraft:orange_concrete
setblock 512 236 446 minecraft:orange_concrete
fill 512 236 447 512 241 448 minecraft:netherrack
fill 512 236 449 512 237 450 minecraft:orange_concrete
fill 512 236 455 512 241 456 minecraft:netherrack
setblock 512 236 457 minecraft:orange_concrete
setblock 470 237 417 minecraft:orange_concrete
setblock 470 237 420 minecraft:orange_concrete
fill 470 237 421 470 240 421 minecraft:netherrack
setblock 470 237 428 minecraft:orange_concrete
fill 470 237 432 470 240 432 minecraft:netherrack
fill 470 237 448 470 237 449 minecraft:orange_concrete
setblock 470 237 452 minecraft:orange_concrete
fill 470 237 453 470 240 453 minecraft:netherrack
fill 473 237 416 474 237 416 minecraft:orange_concrete
fill 476 237 458 476 239 458 minecraft:netherrack
setblock 481 237 458 minecraft:orange_concrete
fill 483 237 450 483 243 450 minecraft:red_nether_bricks
fill 484 237 448 484 242 449 minecraft:red_nether_bricks
fill 490 237 416 490 240 416 minecraft:netherrack
setblock 492 237 458 minecraft:orange_concrete
setblock 494 237 416 minecraft:orange_concrete
fill 496 237 458 497 239 458 minecraft:netherrack
fill 501 237 416 501 240 416 minecraft:netherrack
setblock 502 237 416 minecraft:orange_concrete
setblock 505 237 416 minecraft:orange_concrete
fill 512 237 425 512 240 426 minecraft:netherrack
setblock 512 237 430 minecraft:orange_concrete
setblock 512 237 441 minecraft:orange_concrete
fill 512 237 446 512 240 446 minecraft:netherrack
fill 512 237 457 512 240 457 minecraft:netherrack
setblock 512 237 458 minecraft:orange_concrete
fill 470 238 417 470 243 417 minecraft:netherrack
fill 470 238 418 470 238 419 minecraft:orange_concrete
fill 470 238 420 470 243 420 minecraft:netherrack
fill 470 238 426 470 239 427 minecraft:orange_concrete
fill 470 238 428 470 243 429 minecraft:netherrack
fill 470 238 438 470 238 439 minecraft:orange_concrete
fill 470 238 440 470 243 441 minecraft:netherrack
fill 470 238 447 470 239 447 minecraft:orange_concrete
fill 470 238 448 470 243 449 minecraft:netherrack
setblock 470 238 450 minecraft:orange_concrete
fill 470 238 452 470 243 452 minecraft:netherrack
fill 470 238 458 471 239 458 minecraft:orange_concrete
setblock 472 238 416 minecraft:orange_concrete
fill 472 238 458 473 243 458 minecraft:netherrack
fill 473 238 416 474 243 416 minecraft:netherrack
fill 475 238 416 475 239 416 minecraft:orange_concrete
setblock 478 238 458 minecraft:netherrack
fill 479 238 447 480 238 448 minecraft:red_nether_bricks
fill 479 238 458 479 239 458 minecraft:orange_concrete
setblock 480 238 446 minecraft:red_nether_bricks
fill 481 238 416 482 243 416 minecraft:netherrack
fill 481 238 451 484 240 451 minecraft:red_nether_bricks
fill 481 238 458 481 243 458 minecraft:netherrack
fill 482 238 458 483 238 458 minecraft:orange_concrete
fill 483 238 416 484 238 416 minecraft:orange_concrete
fill 484 238 450 484 244 450 minecraft:red_nether_bricks
fill 484 238 458 485 240 458 minecraft:netherrack
fill 490 238 458 491 239 458 minecraft:orange_concrete
fill 492 238 458 493 243 458 minecraft:netherrack
fill 493 238 416 494 243 416 minecraft:netherrack
setblock 494 238 458 minecraft:orange_concrete
fill 495 238 416 496 239 416 minecraft:orange_concrete
fill 495 238 458 495 241 458 minecraft:netherrack
fill 502 238 416 502 243 416 minecraft:netherrack
fill 502 238 458 503 239 458 minecraft:orange_concrete
fill 503 238 416 504 238 416 minecraft:orange_concrete
fill 504 238 458 505 243 458 minecraft:netherrack
fill 505 238 416 505 243 416 minecraft:netherrack
fill 507 238 416 507 239 416 minecraft:orange_concrete
fill 511 238 458 511 239 458 minecraft:orange_concrete
fill 512 238 417 512 243 418 minecraft:netherrack
fill 512 238 419 512 239 420 minecraft:orange_concrete
setblock 512 238 428 minecraft:orange_concrete
fill 512 238 429 512 243 430 minecraft:netherrack
fill 512 238 431 512 239 432 minecraft:orange_concrete
fill 512 238 437 512 243 438 minecraft:netherrack
fill 512 238 439 512 238 440 minecraft:orange_concrete
fill 512 238 441 512 243 441 minecraft:netherrack
fill 512 238 449 512 243 450 minecraft:netherrack
fill 512 238 451 512 239 452 minecraft:orange_concrete
fill 512 238 458 512 243 458 minecraft:netherrack
fill 470 239 418 470 242 419 minecraft:netherrack
setblock 470 239 435 minecraft:orange_concrete
setblock 470 239 438 minecraft:orange_concrete
fill 470 239 439 470 242 439 minecraft:netherrack
setblock 470 239 446 minecraft:orange_concrete
fill 470 239 450 470 242 450 minecraft:netherrack
fill 472 239 416 472 242 416 minecraft:netherrack
setblock 476 239 416 minecraft:orange_concrete
setblock 478 239 458 minecraft:orange_concrete
fill 480 239 447 480 239 448 minecraft:red_nether_bricks
fill 481 239 447 481 240 447 minecraft:red_nether_bricks
setblock 482 239 458 minecraft:orange_concrete
fill 483 239 416 483 242 416 minecraft:netherrack
fill 483 239 452 483 243 452 minecraft:red_nether_bricks
fill 483 239 458 483 242 458 minecraft:netherrack
setblock 484 239 416 minecraft:orange_concrete
fill 485 239 449 485 244 451 minecraft:red_nether_bricks
setblock 487 239 416 minecraft:orange_concrete
fill 494 239 458 494 241 458 minecraft:netherrack
setblock 499 239 458 minecraft:orange_concrete
fill 503 239 416 504 242 416 minecraft:netherrack
setblock 508 239 416 minecraft:orange_concrete
fill 510 239 453 510 244 453 minecraft:magma_block
setblock 510 239 458 minecraft:orange_concrete
setblock 512 239 423 minecraft:orange_concrete
fill 512 239 428 512 242 428 minecraft:netherrack
fill 512 239 439 512 242 439 minecraft:netherrack
setblock 512 239 440 minecraft:orange_concrete
fill 512 239 443 512 239 444 minecraft:orange_concrete
setblock 470 240 416 minecraft:orange_concrete
fill 470 240 424 470 241 425 minecraft:orange_concrete
fill 470 240 426 470 245 427 minecraft:netherrack
fill 470 240 433 470 241 433 minecraft:orange_concrete
fill 470 240 435 470 245 435 minecraft:netherrack
fill 470 240 436 470 240 437 minecraft:orange_concrete
fill 470 240 438 470 245 438 minecraft:netherrack
fill 470 240 444 470 241 445 minecraft:orange_concrete
fill 470 240 446 470 245 447 minecraft:netherrack
fill 470 240 456 470 240 457 minecraft:orange_concrete
fill 470 240 458 471 245 458 minecraft:netherrack
fill 471 240 417 473 240 417 minecraft:red_nether_bricks
fill 471 240 419 471 240 421 minecraft:red_nether_bricks
fill 471 240 423 471 240 425 minecraft:red_nether_bricks
fill 471 240 427 471 240 429 minecraft:red_nether_bricks
fill 471 240 431 471 240 433 minecraft:red_nether_bricks
fill 471 240 435 471 240 437 minecraft:red_nether_bricks
fill 471 240 439 471 240 441 minecraft:red_nether_bricks
fill 471 240 443 471 240 445 minecraft:red_nether_bricks
fill 471 240 447 471 240 449 minecraft:red_nether_bricks
fill 471 240 451 471 240 453 minecraft:red_nether_bricks
fill 471 240 455 471 240 457 minecraft:red_nether_bricks
setblock 473 240 419 minecraft:light[level=14]
setblock 473 240 427 minecraft:light[level=14]
setblock 473 240 435 minecraft:light[level=14]
setblock 473 240 443 minecraft:light[level=14]
setblock 473 240 451 minecraft:light[level=14]
fill 473 240 457 475 240 457 minecraft:red_nether_bricks
fill 475 240 416 476 245 416 minecraft:netherrack
fill 475 240 417 477 240 417 minecraft:red_nether_bricks
fill 476 240 458 477 241 458 minecraft:orange_concrete
fill 477 240 416 478 241 416 minecraft:orange_concrete
fill 477 240 457 479 240 457 minecraft:red_nether_bricks
fill 478 240 458 479 245 458 minecraft:netherrack
fill 479 240 417 481 240 417 minecraft:red_nether_bricks
setblock 480 240 458 minecraft:orange_concrete
setblock 481 240 419 minecraft:light[level=14]
setblock 481 240 427 minecraft:light[level=14]
setblock 481 240 435 minecraft:light[level=14]
setblock 481 240 443 minecraft:light[level=14]
fill 481 240 450 482 241 450 minecraft:red_nether_bricks
fill 481 240 457 483 240 457 minecraft:red_nether_bricks
fill 482 240 452 482 241 452 minecraft:red_nether_bricks
fill 482 240 458 482 242 458 minecraft:netherrack
fill 483 240 417 485 240 417 minecraft:red_nether_bricks
fill 484 240 416 484 245 416 minecraft:netherrack
fill 484 240 443 484 241 443 minecraft:shroomlight
fill 484 240 452 485 244 452 minecraft:red_nether_bricks
fill 485 240 416 486 240 416 minecraft:orange_concrete
fill 485 240 448 485 242 448 minecraft:red_nether_bricks
fill 485 240 457 487 240 457 minecraft:red_nether_bricks
fill 486 240 449 486 245 451 minecraft:red_nether_bricks
fill 487 240 416 487 245 416 minecraft:netherrack
fill 487 240 417 489 240 417 minecraft:red_nether_bricks
fill 488 240 458 489 241 458 minecraft:orange_concrete
fill 489 240 416 489 241 416 minecraft:orange_concrete
setblock 489 240 419 minecraft:light[level=14]
setblock 489 240 427 minecraft:light[level=14]
setblock 489 240 435 minecraft:light[level=14]
setblock 489 240 443 minecraft:light[level=14]
setblock 489 240 451 minecraft:light[level=14]
fill 489 240 457 491 240 457 minecraft:red_nether_bricks
fill 490 240 458 491 245 458 minecraft:netherrack
fill 491 240 417 493 240 417 minecraft:red_nether_bricks
fill 493 240 457 495 240 457 minecraft:red_nether_bricks
fill 495 240 416 496 245 416 minecraft:netherrack
fill 495 240 417 497 240 417 minecraft:red_nether_bricks
setblock 496 240 458 minecraft:netherrack
fill 497 240 416 498 241 416 minecraft:orange_concrete
setblock 497 240 419 minecraft:light[level=14]
setblock 497 240 427 minecraft:light[level=14]
setblock 497 240 435 minecraft:light[level=14]
setblock 497 240 443 minecraft:light[level=14]
setblock 497 240 451 minecraft:light[level=14]
fill 497 240 457 499 240 457 minecraft:red_nether_bricks
fill 497 240 458 497 241 458 minecraft:orange_concrete
fill 499 240 417 501 240 417 minecraft:red_nether_bricks
fill 499 240 458 499 245 458 minecraft:netherrack
fill 500 240 458 501 240 458 minecraft:orange_concrete
fill 501 240 457 503 240 457 minecraft:red_nether_bricks
fill 502 240 458 503 242 458 minecraft:netherrack
fill 503 240 417 505 240 417 minecraft:red_nether_bricks
setblock 505 240 419 minecraft:light[level=14]
setblock 505 240 427 minecraft:light[level=14]
setblock 505 240 435 minecraft:light[level=14]
setblock 505 240 443 minecraft:light[level=14]
setblock 505 240 451 minecraft:light[level=14]
fill 505 240 457 507 240 457 minecraft:red_nether_bricks
setblock 506 240 416 minecraft:orange_concrete
fill 507 240 416 508 245 416 minecraft:netherrack
fill 507 240 417 509 240 417 minecraft:red_nether_bricks
fill 508 240 453 509 244 453 minecraft:magma_block
fill 508 240 458 509 241 458 minecraft:orange_concrete
fill 509 240 416 510 241 416 minecraft:orange_concrete
fill 509 240 452 511 243 452 minecraft:magma_block
fill 509 240 454 510 243 454 minecraft:magma_block
fill 509 240 457 511 240 457 minecraft:red_nether_bricks
fill 510 240 451 510 243 451 minecraft:magma_block
fill 510 240 455 510 243 455 minecraft:magma_block
fill 510 240 458 511 245 458 minecraft:netherrack
fill 511 240 417 511 240 419 minecraft:red_nether_bricks
fill 511 240 421 511 240 423 minecraft:red_nether_bricks
fill 511 240 425 511 240 427 minecraft:red_nether_bricks
fill 511 240 429 511 240 431 minecraft:red_nether_bricks
fill 511 240 433 511 240 435 minecraft:red_nether_bricks
fill 511 240 437 511 240 439 minecraft:red_nether_bricks
fill 511 240 441 511 240 443 minecraft:red_nether_bricks
fill 511 240 445 511 240 447 minecraft:red_nether_bricks
fill 511 240 449 511 240 451 minecraft:red_nether_bricks
fill 511 240 453 511 240 455 minecraft:red_nether_bricks
fill 512 240 419 512 245 420 minecraft:netherrack
fill 512 240 421 512 240 422 minecraft:orange_concrete
fill 512 240 423 512 245 423 minecraft:netherrack
fill 512 240 431 512 245 432 minecraft:netherrack
fill 512 240 433 512 241 434 minecraft:orange_concrete
fill 512 240 440 512 245 440 minecraft:netherrack
setblock 512 240 442 minecraft:orange_concrete
fill 512 240 443 512 245 444 minecraft:netherrack
fill 512 240 445 512 241 445 minecraft:orange_concrete
fill 512 240 451 512 245 452 minecraft:netherrack
fill 512 240 453 512 240 454 minecraft:orange_concrete
fill 470 241 416 470 244 416 minecraft:netherrack
setblock 470 241 421 minecraft:orange_concrete
setblock 470 241 432 minecraft:orange_concrete
fill 470 241 436 470 244 437 minecraft:netherrack
setblock 470 241 453 minecraft:orange_concrete
setblock 470 241 456 minecraft:orange_concrete
fill 470 241 457 470 244 457 minecraft:netherrack
fill 480 241 458 480 244 458 minecraft:netherrack
fill 482 241 451 484 242 451 minecraft:red_nether_bricks
fill 483 241 448 483 242 449 minecraft:red_nether_bricks
fill 484 241 458 484 243 458 minecraft:netherrack
fill 485 241 416 486 244 416 minecraft:netherrack
setblock 485 241 458 minecraft:orange_concrete
fill 486 241 452 486 247 452 minecraft:red_nether_bricks
fill 487 241 450 487 247 451 minecraft:red_nether_bricks
setblock 490 241 416 minecraft:orange_concrete
setblock 496 241 458 minecraft:orange_concrete
setblock 500 241 458 minecraft:orange_concrete
setblock 501 241 416 minecraft:orange_concrete
fill 501 241 458 501 244 458 minecraft:netherrack
fill 506 241 416 506 244 416 minecraft:netherrack
fill 507 241 453 507 244 453 minecraft:magma_block
fill 508 241 452 508 243 452 minecraft:magma_block
fill 508 241 454 508 243 454 minecraft:magma_block
fill 509 241 451 509 242 451 minecraft:magma_block
fill 509 241 455 509 242 455 minecraft:magma_block
fill 511 241 451 511 242 451 minecraft:magma_block
fill 511 241 453 511 242 455 minecraft:magma_block
fill 512 241 421 512 244 421 minecraft:netherrack
setblock 512 241 422 minecraft:orange_concrete
fill 512 241 425 512 241 426 minecraft:orange_concrete
fill 512 241 442 512 244 442 minecraft:netherrack
setblock 512 241 446 minecraft:orange_concrete
fill 512 241 453 512 244 453 minecraft:netherrack
setblock 512 241 454 minecraft:orange_concrete
setblock 512 241 457 minecraft:orange_concrete
fill 470 242 421 470 247 421 minecraft:netherrack
fill 470 242 422 470 242 423 minecraft:orange_concrete
fill 470 242 424 470 247 425 minecraft:netherrack
fill 470 242 430 470 243 431 minecraft:orange_concrete
fill 470 242 432 470 247 433 minecraft:netherrack
setblock 470 242 434 minecraft:orange_concrete
fill 470 242 442 470 243 443 minecraft:orange_concrete
fill 470 242 444 470 247 445 minecraft:netherrack
fill 470 242 451 470 243 451 minecraft:orange_concrete
fill 470 242 453 470 247 453 minecraft:netherrack
fill 470 242 454 470 242 455 minecraft:orange_concrete
fill 470 242 456 470 247 456 minecraft:netherrack
fill 471 242 416 471 243 416 minecraft:orange_concrete
fill 474 242 458 475 243 458 minecraft:orange_concrete
fill 476 242 458 477 247 458 minecraft:netherrack
fill 477 242 416 478 247 416 minecraft:netherrack
fill 479 242 416 480 243 416 minecraft:orange_concrete
fill 482 242 449 482 242 450 minecraft:red_nether_bricks
fill 485 242 453 486 244 453 minecraft:red_nether_bricks
fill 485 242 458 485 243 458 minecraft:netherrack
fill 486 242 458 487 242 458 minecraft:orange_concrete
fill 487 242 449 487 245 449 minecraft:red_nether_bricks
fill 487 242 452 487 248 452 minecraft:red_nether_bricks
setblock 488 242 416 minecraft:orange_concrete
fill 488 242 451 488 249 451 minecraft:red_nether_bricks
fill 488 242 458 489 247 458 minecraft:netherrack
fill 489 242 416 490 247 416 minecraft:netherrack
fill 491 242 416 492 243 416 minecraft:orange_concrete
fill 494 242 458 495 243 458 minecraft:orange_concrete
fill 496 242 458 497 247 458 minecraft:netherrack
fill 497 242 416 498 247 416 minecraft:netherrack
setblock 498 242 458 minecraft:orange_concrete
fill 499 242 416 500 242 416 minecraft:orange_concrete
fill 500 242 458 500 244 458 minecraft:netherrack
fill 501 242 416 501 247 416 minecraft:netherrack
fill 506 242 452 506 243 454 minecraft:magma_block
fill 506 242 458 507 243 458 minecraft:orange_concrete
fill 507 242 452 507 243 452 minecraft:magma_block
fill 507 242 454 507 243 454 minecraft:magma_block
setblock 508 242 451 minecraft:magma_block
setblock 508 242 455 minecraft:magma_block
fill 508 242 458 509 247 458 minecraft:netherrack
fill 509 242 416 510 247 416 minecraft:netherrack
fill 511 242 416 512 243 416 minecraft:orange_concrete
fill 512 242 422 512 247 422 minecraft:netherrack
setblock 512 242 424 minecraft:orange_concrete
fill 512 242 425 512 247 426 minecraft:netherrack
fill 512 242 427 512 243 427 minecraft:orange_concrete
fill 512 242 433 512 247 434 minecraft:netherrack
fill 512 242 435 512 242 436 minecraft:orange_concrete
fill 512 242 445 512 247 446 minecraft:netherrack
fill 512 242 447 512 243 448 minecraft:orange_concrete
fill 512 242 454 512 247 454 minecraft:netherrack
fill 512 242 455 512 242 456 minecraft:orange_concrete
fill 512 242 457 512 247 457 minecraft:netherrack
fill 470 243 418 470 243 419 minecraft:orange_concrete
setblock 470 243 422 minecraft:orange_concrete
fill 470 243 423 470 246 423 minecraft:netherrack
fill 470 243 434 470 246 434 minecraft:netherrack
setblock 470 243 439 minecraft:orange_concrete
setblock 470 243 450 minecraft:orange_concrete
fill 470 243 454 470 245 455 minecraft:netherrack
setblock 472 243 416 minecraft:orange_concrete
fill 482 243 458 483 243 458 minecraft:orange_concrete
setblock 483 243 416 minecraft:orange_concrete
fill 483 243 449 484 243 449 minecraft:red_nether_bricks
fill 483 243 451 484 243 451 minecraft:red_nether_bricks
setblock 486 243 458 minecraft:orange_concrete
fill 487 243 453 488 248 453 minecraft:red_nether_bricks
fill 487 243 458 487 246 458 minecraft:netherrack
fill 488 243 416 488 246 416 minecraft:netherrack
fill 488 243 450 488 248 450 minecraft:red_nether_bricks
fill 488 243 452 488 249 452 minecraft:red_nether_bricks
fill 489 243 451 489 250 451 minecraft:red_nether_bricks
fill 498 243 458 498 246 458 minecraft:netherrack
fill 499 243 416 499 246 416 minecraft:netherrack
setblock 500 243 416 minecraft:orange_concrete
fill 502 243 458 502 245 458 minecraft:netherrack
fill 503 243 416 504 243 416 minecraft:orange_concrete
setblock 503 243 458 minecraft:orange_concrete
fill 505 243 452 505 243 454 minecraft:magma_block
fill 511 243 453 511 243 454 minecraft:magma_block
fill 512 243 424 512 246 424 minecraft:netherrack
setblock 512 243 428 minecraft:orange_concrete
fill 512 243 435 512 246 435 minecraft:netherrack
setblock 512 243 436 minecraft:orange_concrete
setblock 512 243 439 minecraft:orange_concrete
fill 512 243 455 512 246 456 minecraft:netherrack
fill 470 244 417 470 245 417 minecraft:orange_concrete
fill 470 244 418 470 249 419 minecraft:netherrack
setblock 470 244 420 minecraft:orange_concrete
fill 470 244 422 470 249 422 minecraft:netherrack
fill 470 244 428 470 245 429 minecraft:orange_concrete
fill 470 244 430 470 249 431 minecraft:netherrack
fill 470 244 439 470 249 439 minecraft:netherrack
fill 470 244 440 470 244 441 minecraft:orange_concrete
fill 470 244 442 470 249 443 minecraft:netherrack
fill 470 244 448 470 245 449 minecraft:orange_concrete
fill 470 244 450 470 249 451 minecraft:netherrack
setblock 470 244 452 minecraft:orange_concrete
fill 471 244 416 472 249 416 minecraft:netherrack
fill 472 244 458 473 245 458 minecraft:orange_concrete
fill 473 244 416 474 245 416 minecraft:orange_concrete
fill 474 244 458 475 249 458 minecraft:netherrack
fill 479 244 416 480 249 416 minecraft:netherrack
fill 481 244 416 482 244 416 minecraft:orange_concrete
fill 481 244 458 481 245 458 minecraft:orange_concrete
fill 482 244 458 483 245 458 minecraft:netherrack
fill 483 244 416 483 249 416 minecraft:netherrack
fill 483 244 450 483 246 450 minecraft:magma_block
setblock 484 244 449 minecraft:red_nether_bricks
fill 484 244 451 484 245 451 minecraft:red_nether_bricks
fill 484 244 458 485 244 458 minecraft:orange_concrete
fill 486 244 458 486 249 458 minecraft:netherrack
fill 488 244 449 488 245 449 minecraft:red_nether_bricks
fill 489 244 450 489 249 450 minecraft:red_nether_bricks
fill 489 244 452 489 250 453 minecraft:red_nether_bricks
fill 491 244 416 492 249 416 minecraft:netherrack
fill 492 244 458 493 245 458 minecraft:orange_concrete
fill 493 244 416 494 245 416 minecraft:orange_concrete
fill 494 244 458 495 249 458 minecraft:netherrack
fill 500 244 416 500 249 416 minecraft:netherrack
setblock 502 244 416 minecraft:orange_concrete
fill 503 244 416 504 249 416 minecraft:netherrack
fill 503 244 458 503 249 458 minecraft:netherrack
fill 504 244 453 506 244 453 minecraft:magma_block
fill 504 244 458 505 244 458 minecraft:orange_concrete
fill 505 244 416 505 245 416 minecraft:orange_concrete
fill 506 244 458 507 249 458 minecraft:netherrack
fill 511 244 416 512 249 416 minecraft:netherrack
fill 512 244 417 512 244 418 minecraft:orange_concrete
fill 512 244 427 512 249 428 minecraft:netherrack
fill 512 244 429 512 245 430 minecraft:orange_concrete
fill 512 244 436 512 249 436 minecraft:netherrack
fill 512 244 437 512 244 438 minecraft:orange_concrete
fill 512 244 439 512 249 439 minecraft:netherrack
fill 512 244 441 512 245 441 minecraft:orange_concrete
fill 512 244 447 512 249 448 minecraft:netherrack
fill 512 244 449 512 245 450 minecraft:orange_concrete
fill 512 244 458 512 245 458 minecraft:orange_concrete
setblock 470 245 416 minecraft:orange_concrete
fill 470 245 420 470 248 420 minecraft:netherrack
fill 470 245 436 470 245 437 minecraft:orange_concrete
setblock 470 245 440 minecraft:orange_concrete
fill 470 245 441 470 248 441 minecraft:netherrack
fill 470 245 452 470 247 452 minecraft:netherrack
setblock 470 245 457 minecraft:orange_concrete
setblock 480 245 458 minecraft:orange_concrete
fill 481 245 416 481 248 416 minecraft:netherrack
setblock 482 245 416 minecraft:orange_concrete
fill 484 245 450 484 246 450 minecraft:magma_block
fill 484 245 458 485 247 458 minecraft:netherrack
fill 485 245 416 486 245 416 minecraft:orange_concrete
fill 485 245 450 485 245 452 minecraft:red_nether_bricks
fill 486 245 453 486 246 453 minecraft:red_nether_bricks
fill 487 245 454 488 246 454 minecraft:red_nether_bricks
fill 490 245 451 490 251 453 minecraft:red_nether_bricks
fill 500 245 458 501 245 458 minecraft:orange_concrete
fill 502 245 416 502 248 416 minecraft:netherrack
setblock 504 245 458 minecraft:orange_concrete
fill 505 245 458 505 248 458 minecraft:netherrack
setblock 506 245 416 minecraft:orange_concrete
fill 512 245 417 512 248 417 minecraft:netherrack
setblock 512 245 418 minecraft:orange_concrete
setblock 512 245 421 minecraft:orange_concrete
fill 512 245 437 512 248 438 minecraft:netherrack
setblock 512 245 442 minecraft:orange_concrete
setblock 512 245 453 minecraft:orange_concrete
fill 470 246 416 470 251 417 minecraft:netherrack
fill 470 246 426 470 246 427 minecraft:orange_concrete
fill 470 246 428 470 251 429 minecraft:netherrack
fill 470 246 435 470 247 435 minecraft:orange_concrete
fill 470 246 436 470 251 437 minecraft:netherrack
setblock 470 246 438 minecraft:orange_concrete
fill 470 246 440 470 251 440 minecraft:netherrack
fill 470 246 446 470 247 447 minecraft:orange_concrete
fill 470 246 448 470 251 449 minecraft:netherrack
setblock 470 246 454 minecraft:netherrack
fill 470 246 455 470 247 455 minecraft:orange_concrete
fill 470 246 457 470 251 457 minecraft:netherrack
fill 470 246 458 471 246 458 minecraft:orange_concrete
fill 471 246 417 473 246 417 minecraft:red_nether_bricks
fill 471 246 419 471 246 421 minecraft:red_nether_bricks
fill 471 246 423 471 246 425 minecraft:red_nether_bricks
fill 471 246 427 471 246 429 minecraft:red_nether_bricks
fill 471 246 431 471 246 433 minecraft:red_nether_bricks
fill 471 246 435 471 246 437 minecraft:red_nether_bricks
fill 471 246 439 471 246 441 minecraft:red_nether_bricks
fill 471 246 443 471 246 445 minecraft:red_nether_bricks
fill 471 246 447 471 246 449 minecraft:red_nether_bricks
fill 471 246 451 471 246 453 minecraft:red_nether_bricks
fill 471 246 455 471 246 457 minecraft:red_nether_bricks
fill 472 246 458 473 248 458 minecraft:netherrack
fill 473 246 416 474 251 416 minecraft:netherrack
fill 473 246 457 475 246 457 minecraft:red_nether_bricks
fill 475 246 416 476 247 416 minecraft:orange_concrete
fill 475 246 417 477 246 417 minecraft:red_nether_bricks
fill 477 246 457 479 246 457 minecraft:red_nether_bricks
fill 478 246 458 479 247 458 minecraft:orange_concrete
fill 479 246 417 481 246 417 minecraft:red_nether_bricks
fill 480 246 458 481 251 458 minecraft:netherrack
fill 481 246 457 483 246 457 minecraft:red_nether_bricks
fill 482 246 416 482 251 416 minecraft:netherrack
setblock 482 246 458 minecraft:orange_concrete
fill 483 246 417 485 246 417 minecraft:red_nether_bricks
fill 483 246 458 483 249 458 minecraft:netherrack
setblock 484 246 416 minecraft:orange_concrete
fill 485 246 416 486 251 416 minecraft:netherrack
fill 485 246 451 485 246 452 minecraft:red_nether_bricks
fill 485 246 457 487 246 457 minecraft:red_nether_bricks
fill 486 246 450 486 246 451 minecraft:red_nether_bricks
fill 487 246 416 487 247 416 minecraft:orange_concrete
fill 487 246 417 489 246 417 minecraft:red_nether_bricks
fill 489 246 454 489 248 454 minecraft:red_nether_bricks
fill 489 246 457 491 246 457 minecraft:red_nether_bricks
fill 490 246 450 490 250 450 minecraft:red_nether_bricks
fill 490 246 458 491 247 458 minecraft:orange_concrete
fill 491 246 417 493 246 417 minecraft:red_nether_bricks
fill 491 246 451 491 252 453 minecraft:red_nether_bricks
fill 492 246 458 493 251 458 minecraft:netherrack
fill 493 246 416 494 251 416 minecraft:netherrack
fill 493 246 457 495 246 457 minecraft:red_nether_bricks
fill 495 246 416 496 246 416 minecraft:orange_concrete
fill 495 246 417 497 246 417 minecraft:red_nether_bricks
fill 497 246 457 499 246 457 minecraft:red_nether_bricks
fill 499 246 417 501 246 417 minecraft:red_nether_bricks
fill 499 246 458 499 247 458 minecraft:orange_concrete
fill 500 246 458 501 251 458 minecraft:netherrack
fill 501 246 457 503 246 457 minecraft:red_nether_bricks
setblock 502 246 458 minecraft:orange_concrete
fill 503 246 417 505 246 417 minecraft:red_nether_bricks
fill 504 246 458 504 251 458 minecraft:netherrack
fill 505 246 416 506 251 416 minecraft:netherrack
fill 505 246 457 507 246 457 minecraft:red_nether_bricks
fill 507 246 416 508 247 416 minecraft:orange_concrete
fill 507 246 417 509 246 417 minecraft:red_nether_bricks
fill 509 246 457 511 246 457 minecraft:red_nether_bricks
fill 510 246 458 511 247 458 minecraft:orange_concrete
fill 511 246 417 511 246 419 minecraft:red_nether_bricks
fill 511 246 421 511 246 423 minecraft:red_nether_bricks
fill 511 246 425 511 246 427 minecraft:red_nether_bricks
fill 511 246 429 511 246 431 minecraft:red_nether_bricks
fill 511 246 433 511 246 435 minecraft:red_nether_bricks
fill 511 246 437 511 246 439 minecraft:red_nether_bricks
fill 511 246 441 511 246 443 minecraft:red_nether_bricks
fill 511 246 445 511 246 447 minecraft:red_nether_bricks
fill 511 246 449 511 246 451 minecraft:red_nether_bricks
fill 511 246 453 511 246 455 minecraft:red_nether_bricks
fill 512 246 418 512 251 418 minecraft:netherrack
fill 512 246 419 512 246 420 minecraft:orange_concrete
fill 512 246 421 512 251 421 minecraft:netherrack
fill 512 246 423 512 247 423 minecraft:orange_concrete
fill 512 246 429 512 251 430 minecraft:netherrack
fill 512 246 431 512 247 432 minecraft:orange_concrete
setblock 512 246 440 minecraft:orange_concrete
fill 512 246 441 512 251 442 minecraft:netherrack
fill 512 246 443 512 247 444 minecraft:orange_concrete
fill 512 246 449 512 251 450 minecraft:netherrack
fill 512 246 451 512 246 452 minecraft:orange_concrete
fill 512 246 453 512 251 453 minecraft:netherrack
fill 512 246 458 512 251 458 minecraft:netherrack
setblock 470 247 423 minecraft:orange_concrete
setblock 470 247 426 minecraft:orange_concrete
fill 470 247 427 470 250 427 minecraft:netherrack
setblock 470 247 434 minecraft:orange_concrete
fill 470 247 438 470 250 438 minecraft:netherrack
setblock 470 247 454 minecraft:orange_concrete
setblock 470 247 458 minecraft:orange_concrete
fill 471 247 458 471 250 458 minecraft:netherrack
fill 482 247 458 482 249 458 minecraft:netherrack
fill 484 247 416 484 250 416 minecraft:netherrack
setblock 486 247 451 minecraft:red_nether_bricks
setblock 487 247 458 minecraft:orange_concrete
setblock 488 247 416 minecraft:orange_concrete
setblock 488 247 454 minecraft:red_nether_bricks
fill 490 247 454 490 249 454 minecraft:red_nether_bricks
fill 491 247 450 491 251 450 minecraft:red_nether_bricks
fill 492 247 451 492 253 453 minecraft:red_nether_bricks
fill 495 247 416 495 250 416 minecraft:netherrack
setblock 496 247 416 minecraft:orange_concrete
setblock 498 247 458 minecraft:orange_concrete
setblock 499 247 416 minecraft:orange_concrete
fill 502 247 458 502 250 458 minecraft:netherrack
fill 512 247 419 512 250 420 minecraft:netherrack
setblock 512 247 424 minecraft:orange_concrete
setblock 512 247 435 minecraft:orange_concrete
fill 512 247 440 512 250 440 minecraft:netherrack
fill 512 247 451 512 250 451 minecraft:netherrack
setblock 512 247 452 minecraft:orange_concrete
fill 512 247 455 512 247 456 minecraft:orange_concrete
fill 470 248 421 470 249 421 minecraft:orange_concrete
fill 470 248 423 470 253 423 minecraft:netherrack
fill 470 248 424 470 248 425 minecraft:orange_concrete
fill 470 248 426 470 253 426 minecraft:netherrack
fill 470 248 432 470 249 433 minecraft:orange_concrete
fill 470 248 434 470 253 435 minecraft:netherrack
fill 470 248 444 470 248 445 minecraft:orange_concrete
fill 470 248 446 470 253 447 minecraft:netherrack
fill 470 248 452 470 249 453 minecraft:orange_concrete
fill 470 248 454 470 253 455 minecraft:netherrack
setblock 470 248 456 minecraft:orange_concrete
fill 470 248 458 470 250 458 minecraft:netherrack
setblock 473 248 419 minecraft:light[level=14]
setblock 473 248 427 minecraft:light[level=14]
setblock 473 248 435 minecraft:light[level=14]
setblock 473 248 443 minecraft:light[level=14]
setblock 473 248 451 minecraft:light[level=14]
fill 475 248 416 476 253 416 minecraft:netherrack
fill 476 248 458 477 249 458 minecraft:orange_concrete
fill 477 248 416 478 248 416 minecraft:orange_concrete
fill 478 248 458 479 253 458 minecraft:netherrack
setblock 481 248 419 minecraft:light[level=14]
setblock 481 248 427 minecraft:light[level=14]
setblock 481 248 435 minecraft:light[level=14]
setblock 481 248 443 minecraft:light[level=14]
setblock 481 248 451 minecraft:light[level=14]
setblock 484 248 458 minecraft:netherrack
fill 485 248 458 485 249 458 minecraft:orange_concrete
fill 487 248 416 488 253 416 minecraft:netherrack
setblock 487 248 451 minecraft:red_nether_bricks
fill 487 248 458 487 253 458 minecraft:netherrack
fill 488 248 458 489 248 458 minecraft:orange_concrete
fill 489 248 416 490 249 416 minecraft:orange_concrete
setblock 489 248 419 minecraft:light[level=14]
setblock 489 248 427 minecraft:light[level=14]
setblock 489 248 435 minecraft:light[level=14]
setblock 489 248 443 minecraft:light[level=14]
fill 490 248 458 491 250 458 minecraft:netherrack
fill 491 248 454 491 251 454 minecraft:red_nether_bricks
fill 492 248 450 492 252 450 minecraft:red_nether_bricks
schedule function dropper:buildpart/106_6 1t
