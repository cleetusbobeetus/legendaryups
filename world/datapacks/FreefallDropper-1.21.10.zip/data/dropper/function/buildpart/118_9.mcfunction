fill 491 241 466 494 241 466 minecraft:red_terracotta
fill 491 241 468 491 241 469 minecraft:brown_terracotta
fill 491 241 472 492 241 472 minecraft:brown_terracotta
setblock 491 241 479 minecraft:magma_block
setblock 491 241 500 minecraft:magma_block
fill 491 241 503 492 241 503 minecraft:red_terracotta
setblock 492 241 464 minecraft:terracotta
fill 492 241 465 495 241 465 minecraft:red_terracotta
fill 492 241 470 492 241 471 minecraft:brown_terracotta
fill 492 241 479 492 245 479 minecraft:basalt
setblock 492 241 504 minecraft:terracotta
fill 493 241 464 496 241 464 minecraft:red_terracotta
setblock 493 241 503 minecraft:terracotta
fill 493 241 504 496 241 504 minecraft:red_terracotta
fill 494 241 480 494 245 480 minecraft:basalt
fill 494 241 494 495 245 494 minecraft:basalt
setblock 494 241 502 minecraft:terracotta
fill 494 241 503 497 241 503 minecraft:red_terracotta
setblock 495 241 466 minecraft:terracotta
setblock 495 241 500 minecraft:basalt
fill 495 241 502 498 241 502 minecraft:red_terracotta
setblock 496 241 465 minecraft:terracotta
fill 496 241 466 496 244 466 minecraft:red_terracotta
setblock 497 241 464 minecraft:terracotta
fill 497 241 465 497 244 465 minecraft:red_terracotta
setblock 497 241 483 minecraft:magma_block
fill 497 241 491 497 245 491 minecraft:basalt
setblock 497 241 492 minecraft:magma_block
setblock 497 241 504 minecraft:terracotta
fill 498 241 464 498 244 464 minecraft:red_terracotta
fill 498 241 484 498 245 490 minecraft:basalt
setblock 498 241 503 minecraft:terracotta
fill 498 241 504 501 241 504 minecraft:red_terracotta
setblock 499 241 502 minecraft:terracotta
fill 499 241 503 502 241 503 minecraft:red_terracotta
setblock 501 241 465 minecraft:terracotta
setblock 502 241 464 minecraft:terracotta
setblock 502 241 465 minecraft:red_terracotta
setblock 502 241 493 minecraft:basalt
setblock 502 241 504 minecraft:terracotta
fill 503 241 464 503 242 464 minecraft:red_terracotta
setblock 503 241 484 minecraft:magma_block
fill 503 241 485 503 241 486 minecraft:basalt
setblock 503 241 487 minecraft:magma_block
fill 503 241 488 503 241 489 minecraft:basalt
setblock 503 241 490 minecraft:magma_block
fill 503 241 504 503 242 504 minecraft:red_terracotta
setblock 510 241 486 minecraft:terracotta
fill 510 241 487 510 244 487 minecraft:red_terracotta
setblock 510 241 491 minecraft:terracotta
fill 510 241 492 510 244 492 minecraft:red_terracotta
setblock 511 241 464 minecraft:red_terracotta
setblock 511 241 465 minecraft:terracotta
fill 511 241 466 511 244 466 minecraft:red_terracotta
fill 511 241 468 511 242 468 minecraft:red_terracotta
setblock 511 241 480 minecraft:terracotta
fill 511 241 481 511 244 481 minecraft:red_terracotta
setblock 511 241 485 minecraft:terracotta
fill 511 241 486 511 244 486 minecraft:red_terracotta
setblock 511 241 490 minecraft:terracotta
fill 511 241 491 511 244 491 minecraft:red_terracotta
setblock 511 241 495 minecraft:terracotta
fill 511 241 496 511 244 496 minecraft:red_terracotta
setblock 471 242 464 minecraft:terracotta
fill 471 242 465 473 242 466 minecraft:red_terracotta
setblock 471 242 468 minecraft:red_terracotta
setblock 471 242 469 minecraft:terracotta
fill 471 242 470 471 245 470 minecraft:red_terracotta
setblock 471 242 473 minecraft:red_terracotta
setblock 471 242 474 minecraft:terracotta
fill 471 242 475 471 245 475 minecraft:red_terracotta
setblock 471 242 479 minecraft:terracotta
fill 471 242 480 471 242 483 minecraft:red_terracotta
setblock 471 242 484 minecraft:terracotta
fill 471 242 485 471 245 485 minecraft:red_terracotta
setblock 471 242 489 minecraft:terracotta
fill 471 242 490 471 245 490 minecraft:red_terracotta
fill 472 242 464 475 242 464 minecraft:red_terracotta
setblock 472 242 468 minecraft:terracotta
fill 472 242 469 472 245 469 minecraft:red_terracotta
setblock 472 242 473 minecraft:terracotta
fill 472 242 479 472 242 482 minecraft:red_terracotta
setblock 472 242 483 minecraft:terracotta
fill 472 242 484 472 245 484 minecraft:red_terracotta
setblock 472 242 488 minecraft:terracotta
fill 472 242 489 472 245 489 minecraft:red_terracotta
setblock 473 242 467 minecraft:terracotta
fill 473 242 468 473 245 468 minecraft:red_terracotta
fill 473 242 470 473 243 470 minecraft:red_terracotta
setblock 473 242 483 minecraft:red_terracotta
setblock 473 242 487 minecraft:terracotta
fill 473 242 488 473 244 488 minecraft:red_terracotta
setblock 474 242 465 minecraft:red_terracotta
setblock 474 242 466 minecraft:terracotta
setblock 475 242 465 minecraft:terracotta
fill 475 242 466 475 245 466 minecraft:red_terracotta
setblock 476 242 464 minecraft:terracotta
fill 476 242 465 476 245 465 minecraft:red_terracotta
setblock 476 242 504 minecraft:terracotta
fill 477 242 464 480 242 464 minecraft:red_terracotta
fill 477 242 486 478 242 486 minecraft:basalt
setblock 477 242 488 minecraft:basalt
fill 477 242 504 477 243 504 minecraft:red_terracotta
setblock 478 242 467 minecraft:terracotta
setblock 478 242 482 minecraft:magma_block
fill 478 242 483 478 242 484 minecraft:basalt
setblock 478 242 485 minecraft:magma_block
setblock 478 242 490 minecraft:basalt
setblock 478 242 491 minecraft:magma_block
setblock 478 242 492 minecraft:basalt
setblock 479 242 466 minecraft:terracotta
setblock 479 242 467 minecraft:red_terracotta
setblock 480 242 465 minecraft:terracotta
fill 480 242 466 480 244 466 minecraft:red_terracotta
setblock 481 242 464 minecraft:terracotta
fill 481 242 465 484 242 465 minecraft:red_terracotta
setblock 481 242 478 minecraft:magma_block
setblock 481 242 496 minecraft:magma_block
setblock 481 242 504 minecraft:terracotta
fill 482 242 464 485 242 464 minecraft:red_terracotta
fill 482 242 485 483 242 485 minecraft:basalt
fill 482 242 488 482 245 488 minecraft:basalt
setblock 482 242 504 minecraft:red_terracotta
fill 483 242 484 483 245 484 minecraft:basalt
fill 483 242 489 483 245 490 minecraft:basalt
fill 484 242 482 484 244 482 minecraft:basalt
setblock 484 242 483 minecraft:magma_block
fill 484 242 491 484 244 491 minecraft:basalt
setblock 484 242 492 minecraft:magma_block
setblock 484 242 498 minecraft:magma_block
setblock 485 242 465 minecraft:terracotta
setblock 485 242 475 minecraft:basalt
fill 485 242 481 486 242 481 minecraft:basalt
fill 485 242 493 486 242 493 minecraft:basalt
setblock 485 242 499 minecraft:basalt
setblock 486 242 464 minecraft:terracotta
fill 486 242 465 489 242 465 minecraft:red_terracotta
fill 487 242 464 490 242 464 minecraft:red_terracotta
setblock 487 242 475 minecraft:basalt
fill 487 242 480 488 245 480 minecraft:basalt
setblock 487 242 494 minecraft:magma_block
setblock 487 242 499 minecraft:basalt
fill 487 242 504 490 242 504 minecraft:red_terracotta
fill 488 242 494 488 245 495 minecraft:basalt
fill 489 242 500 491 242 500 minecraft:basalt
setblock 490 242 465 minecraft:terracotta
fill 490 242 474 491 242 474 minecraft:basalt
setblock 491 242 464 minecraft:terracotta
fill 491 242 465 493 242 466 minecraft:red_terracotta
fill 491 242 479 491 245 479 minecraft:basalt
setblock 491 242 503 minecraft:red_terracotta
setblock 491 242 504 minecraft:terracotta
fill 492 242 464 495 242 464 minecraft:red_terracotta
fill 492 242 480 492 245 480 minecraft:basalt
fill 492 242 494 493 242 494 minecraft:basalt
fill 492 242 499 493 242 499 minecraft:basalt
setblock 492 242 503 minecraft:terracotta
fill 492 242 504 495 242 504 minecraft:red_terracotta
setblock 493 242 480 minecraft:magma_block
fill 493 242 503 496 242 503 minecraft:red_terracotta
setblock 494 242 465 minecraft:red_terracotta
setblock 494 242 466 minecraft:terracotta
fill 494 242 481 495 245 481 minecraft:basalt
fill 494 242 493 495 245 493 minecraft:basalt
setblock 495 242 465 minecraft:terracotta
fill 495 242 466 495 244 466 minecraft:red_terracotta
setblock 496 242 464 minecraft:terracotta
fill 496 242 465 496 245 465 minecraft:red_terracotta
setblock 496 242 476 minecraft:magma_block
setblock 496 242 482 minecraft:magma_block
fill 496 242 483 497 245 483 minecraft:basalt
setblock 496 242 491 minecraft:magma_block
fill 496 242 492 497 245 492 minecraft:basalt
setblock 496 242 498 minecraft:basalt
fill 496 242 502 497 242 502 minecraft:red_terracotta
setblock 496 242 504 minecraft:terracotta
fill 497 242 464 497 245 464 minecraft:red_terracotta
fill 497 242 484 497 245 485 minecraft:basalt
fill 497 242 489 497 245 490 minecraft:basalt
setblock 497 242 503 minecraft:terracotta
fill 497 242 504 500 242 504 minecraft:red_terracotta
fill 498 242 503 501 242 503 minecraft:red_terracotta
setblock 499 242 478 minecraft:magma_block
setblock 499 242 496 minecraft:magma_block
setblock 500 242 465 minecraft:terracotta
setblock 501 242 464 minecraft:terracotta
setblock 501 242 465 minecraft:red_terracotta
setblock 501 242 504 minecraft:terracotta
fill 502 242 464 502 243 464 minecraft:red_terracotta
setblock 502 242 482 minecraft:basalt
setblock 502 242 483 minecraft:magma_block
fill 502 242 484 502 242 488 minecraft:basalt
setblock 502 242 489 minecraft:magma_block
fill 502 242 490 502 242 491 minecraft:basalt
setblock 502 242 492 minecraft:magma_block
fill 502 242 504 502 243 504 minecraft:red_terracotta
fill 503 242 486 503 242 488 minecraft:basalt
setblock 510 242 485 minecraft:terracotta
fill 510 242 486 510 245 486 minecraft:red_terracotta
setblock 510 242 490 minecraft:terracotta
fill 510 242 491 510 245 491 minecraft:red_terracotta
setblock 511 242 464 minecraft:terracotta
fill 511 242 465 511 245 465 minecraft:red_terracotta
setblock 511 242 469 minecraft:terracotta
fill 511 242 480 511 245 480 minecraft:red_terracotta
setblock 511 242 484 minecraft:terracotta
fill 511 242 485 511 245 485 minecraft:red_terracotta
setblock 511 242 489 minecraft:terracotta
fill 511 242 490 511 245 490 minecraft:red_terracotta
setblock 511 242 494 minecraft:terracotta
fill 511 242 495 511 245 495 minecraft:red_terracotta
fill 471 243 464 472 243 466 minecraft:red_terracotta
setblock 471 243 468 minecraft:terracotta
fill 471 243 469 471 246 469 minecraft:red_terracotta
setblock 471 243 473 minecraft:terracotta
fill 471 243 474 472 245 474 minecraft:red_terracotta
setblock 471 243 478 minecraft:terracotta
fill 471 243 479 471 243 482 minecraft:red_terracotta
setblock 471 243 483 minecraft:terracotta
fill 471 243 484 471 246 484 minecraft:red_terracotta
setblock 471 243 488 minecraft:terracotta
fill 471 243 489 471 246 489 minecraft:red_terracotta
setblock 471 243 493 minecraft:terracotta
setblock 472 243 467 minecraft:terracotta
fill 472 243 468 472 246 468 minecraft:red_terracotta
setblock 472 243 472 minecraft:terracotta
fill 472 243 473 472 246 473 minecraft:red_terracotta
fill 472 243 480 472 243 481 minecraft:red_terracotta
setblock 472 243 482 minecraft:terracotta
fill 472 243 483 472 246 483 minecraft:red_terracotta
setblock 472 243 487 minecraft:terracotta
fill 472 243 488 472 246 488 minecraft:red_terracotta
setblock 472 243 492 minecraft:terracotta
fill 473 243 464 473 243 465 minecraft:red_terracotta
setblock 473 243 466 minecraft:terracotta
fill 473 243 467 473 246 467 minecraft:red_terracotta
setblock 473 243 471 minecraft:terracotta
setblock 473 243 486 minecraft:terracotta
fill 473 243 487 473 244 487 minecraft:red_terracotta
setblock 474 243 464 minecraft:red_terracotta
setblock 474 243 465 minecraft:terracotta
fill 474 243 466 474 246 466 minecraft:red_terracotta
setblock 475 243 464 minecraft:terracotta
fill 475 243 465 475 246 465 minecraft:red_terracotta
setblock 475 243 504 minecraft:terracotta
fill 476 243 464 479 243 464 minecraft:red_terracotta
fill 476 243 504 476 244 504 minecraft:red_terracotta
setblock 477 243 467 minecraft:terracotta
setblock 478 243 466 minecraft:terracotta
setblock 478 243 467 minecraft:red_terracotta
fill 478 243 485 478 243 487 minecraft:basalt
setblock 479 243 465 minecraft:terracotta
fill 479 243 466 479 245 466 minecraft:red_terracotta
setblock 480 243 464 minecraft:terracotta
fill 480 243 465 483 243 465 minecraft:red_terracotta
setblock 480 243 481 minecraft:basalt
fill 481 243 464 484 243 464 minecraft:red_terracotta
setblock 481 243 495 minecraft:basalt
fill 482 243 485 482 245 485 minecraft:basalt
setblock 483 243 485 minecraft:magma_block
fill 483 243 486 483 245 487 minecraft:basalt
setblock 483 243 488 minecraft:magma_block
setblock 483 243 496 minecraft:basalt
setblock 484 243 465 minecraft:terracotta
fill 484 243 483 484 245 484 minecraft:basalt
fill 484 243 490 484 245 490 minecraft:basalt
fill 484 243 492 485 245 492 minecraft:basalt
setblock 485 243 464 minecraft:terracotta
fill 485 243 465 488 243 465 minecraft:red_terracotta
fill 485 243 481 485 245 482 minecraft:basalt
fill 485 243 493 485 245 493 minecraft:basalt
fill 486 243 464 489 243 464 minecraft:red_terracotta
setblock 486 243 481 minecraft:magma_block
setblock 486 243 493 minecraft:magma_block
setblock 486 243 498 minecraft:basalt
fill 487 243 481 487 244 481 minecraft:basalt
fill 487 243 493 487 244 494 minecraft:basalt
fill 488 243 504 489 243 504 minecraft:red_terracotta
setblock 489 243 465 minecraft:terracotta
setblock 489 243 480 minecraft:magma_block
fill 489 243 494 491 245 494 minecraft:basalt
setblock 490 243 464 minecraft:terracotta
fill 490 243 465 493 243 465 minecraft:red_terracotta
fill 490 243 480 491 244 480 minecraft:basalt
setblock 490 243 504 minecraft:terracotta
fill 491 243 464 494 243 464 minecraft:red_terracotta
fill 491 243 466 492 243 466 minecraft:red_terracotta
fill 491 243 504 494 243 504 minecraft:red_terracotta
setblock 492 243 494 minecraft:magma_block
setblock 492 243 499 minecraft:basalt
fill 492 243 503 495 243 503 minecraft:red_terracotta
setblock 493 243 466 minecraft:terracotta
fill 493 243 480 493 245 481 minecraft:basalt
fill 493 243 493 493 244 494 minecraft:basalt
setblock 494 243 465 minecraft:terracotta
fill 494 243 466 494 245 466 minecraft:red_terracotta
setblock 495 243 464 minecraft:terracotta
fill 495 243 465 495 246 465 minecraft:red_terracotta
fill 495 243 482 496 245 482 minecraft:basalt
fill 495 243 492 495 245 492 minecraft:basalt
setblock 495 243 498 minecraft:basalt
setblock 495 243 504 minecraft:terracotta
fill 496 243 464 496 246 464 minecraft:red_terracotta
fill 496 243 484 496 244 484 minecraft:basalt
fill 496 243 490 496 244 491 minecraft:basalt
setblock 496 243 503 minecraft:terracotta
fill 496 243 504 499 243 504 minecraft:red_terracotta
fill 497 243 486 497 245 488 minecraft:basalt
fill 497 243 496 498 243 496 minecraft:basalt
fill 497 243 503 499 243 503 minecraft:red_terracotta
setblock 498 243 478 minecraft:basalt
setblock 498 243 495 minecraft:magma_block
setblock 499 243 465 minecraft:terracotta
setblock 500 243 464 minecraft:terracotta
setblock 500 243 465 minecraft:red_terracotta
setblock 500 243 504 minecraft:terracotta
setblock 501 243 464 minecraft:red_terracotta
setblock 501 243 482 minecraft:magma_block
setblock 501 243 483 minecraft:basalt
setblock 501 243 491 minecraft:magma_block
setblock 501 243 492 minecraft:basalt
fill 501 243 504 501 244 504 minecraft:red_terracotta
fill 502 243 485 502 243 489 minecraft:basalt
setblock 510 243 484 minecraft:terracotta
fill 510 243 485 510 246 485 minecraft:red_terracotta
setblock 510 243 489 minecraft:terracotta
fill 510 243 490 510 246 490 minecraft:red_terracotta
setblock 510 243 493 minecraft:red_terracotta
setblock 511 243 468 minecraft:terracotta
fill 511 243 469 511 244 471 minecraft:red_terracotta
setblock 511 243 483 minecraft:terracotta
fill 511 243 484 511 246 484 minecraft:red_terracotta
setblock 511 243 488 minecraft:terracotta
fill 511 243 489 511 246 489 minecraft:red_terracotta
setblock 511 243 493 minecraft:terracotta
fill 511 243 494 511 246 494 minecraft:red_terracotta
fill 471 244 464 471 244 466 minecraft:red_terracotta
setblock 471 244 467 minecraft:terracotta
fill 471 244 468 471 247 468 minecraft:red_terracotta
setblock 471 244 472 minecraft:terracotta
fill 471 244 473 471 247 473 minecraft:red_terracotta
setblock 471 244 477 minecraft:terracotta
fill 471 244 478 471 244 481 minecraft:red_terracotta
setblock 471 244 482 minecraft:terracotta
fill 471 244 483 471 247 483 minecraft:red_terracotta
setblock 471 244 487 minecraft:terracotta
fill 471 244 488 471 247 488 minecraft:red_terracotta
setblock 471 244 492 minecraft:terracotta
fill 471 244 493 471 246 494 minecraft:red_terracotta
fill 472 244 464 472 244 465 minecraft:red_terracotta
setblock 472 244 466 minecraft:terracotta
fill 472 244 467 472 247 467 minecraft:red_terracotta
setblock 472 244 471 minecraft:terracotta
fill 472 244 472 473 246 472 minecraft:red_terracotta
setblock 472 244 475 minecraft:red_terracotta
setblock 472 244 476 minecraft:terracotta
setblock 472 244 482 minecraft:red_terracotta
setblock 472 244 486 minecraft:terracotta
fill 472 244 487 472 247 487 minecraft:red_terracotta
setblock 472 244 491 minecraft:terracotta
fill 472 244 492 472 247 492 minecraft:red_terracotta
setblock 473 244 464 minecraft:red_terracotta
setblock 473 244 465 minecraft:terracotta
fill 473 244 466 473 247 466 minecraft:red_terracotta
setblock 473 244 470 minecraft:terracotta
fill 473 244 471 473 247 471 minecraft:red_terracotta
setblock 473 244 486 minecraft:red_terracotta
setblock 474 244 464 minecraft:terracotta
fill 474 244 465 474 247 465 minecraft:red_terracotta
fill 475 244 464 478 244 464 minecraft:red_terracotta
setblock 476 244 467 minecraft:terracotta
setblock 477 244 466 minecraft:terracotta
setblock 478 244 465 minecraft:terracotta
fill 478 244 466 478 246 466 minecraft:red_terracotta
setblock 479 244 464 minecraft:terracotta
fill 479 244 465 482 244 465 minecraft:red_terracotta
setblock 479 244 485 minecraft:magma_block
fill 479 244 486 479 244 487 minecraft:basalt
setblock 479 244 488 minecraft:magma_block
setblock 479 244 489 minecraft:basalt
fill 480 244 464 483 244 464 minecraft:red_terracotta
setblock 481 244 481 minecraft:basalt
setblock 483 244 465 minecraft:terracotta
fill 483 244 485 484 244 485 minecraft:basalt
fill 483 244 488 484 244 488 minecraft:basalt
setblock 484 244 464 minecraft:terracotta
setblock 484 244 465 minecraft:red_terracotta
fill 484 244 486 484 244 487 minecraft:basalt
fill 484 244 489 484 245 489 minecraft:basalt
setblock 484 244 496 minecraft:basalt
fill 485 244 464 488 244 464 minecraft:red_terracotta
setblock 485 244 477 minecraft:magma_block
setblock 485 244 483 minecraft:magma_block
fill 485 244 491 485 245 491 minecraft:basalt
setblock 485 244 497 minecraft:basalt
fill 486 244 481 486 245 482 minecraft:basalt
fill 486 244 492 486 245 493 minecraft:basalt
setblock 487 244 465 minecraft:red_terracotta
setblock 487 244 477 minecraft:basalt
setblock 488 244 465 minecraft:terracotta
setblock 488 244 476 minecraft:magma_block
fill 488 244 481 490 244 481 minecraft:basalt
fill 488 244 493 490 244 493 minecraft:basalt
fill 488 244 498 489 244 498 minecraft:basalt
setblock 489 244 464 minecraft:terracotta
fill 489 244 465 492 244 465 minecraft:red_terracotta
fill 489 244 480 489 245 480 minecraft:basalt
setblock 489 244 504 minecraft:terracotta
fill 490 244 464 493 244 464 minecraft:red_terracotta
fill 490 244 476 492 244 476 minecraft:basalt
fill 490 244 504 493 244 504 minecraft:red_terracotta
fill 491 244 481 491 245 481 minecraft:magma_block
fill 491 244 493 491 245 493 minecraft:magma_block
fill 491 244 498 492 244 498 minecraft:basalt
setblock 492 244 466 minecraft:terracotta
fill 492 244 481 492 245 481 minecraft:basalt
fill 492 244 493 492 245 494 minecraft:basalt
fill 492 244 503 494 244 503 minecraft:red_terracotta
setblock 493 244 465 minecraft:terracotta
fill 493 244 466 493 245 466 minecraft:red_terracotta
setblock 493 244 477 minecraft:basalt
setblock 494 244 464 minecraft:terracotta
fill 494 244 465 494 247 465 minecraft:red_terracotta
setblock 494 244 477 minecraft:magma_block
fill 494 244 482 494 245 482 minecraft:basalt
setblock 494 244 492 minecraft:magma_block
setblock 494 244 504 minecraft:terracotta
fill 495 244 464 495 247 464 minecraft:red_terracotta
fill 495 244 483 495 245 483 minecraft:basalt
fill 495 244 491 495 245 491 minecraft:basalt
setblock 495 244 503 minecraft:terracotta
fill 495 244 504 498 244 504 minecraft:red_terracotta
fill 496 244 485 496 244 489 minecraft:basalt
fill 496 244 503 498 244 503 minecraft:red_terracotta
setblock 497 244 479 minecraft:magma_block
setblock 498 244 465 minecraft:terracotta
setblock 498 244 480 minecraft:basalt
setblock 499 244 464 minecraft:terracotta
setblock 499 244 504 minecraft:terracotta
setblock 500 244 464 minecraft:red_terracotta
fill 500 244 482 500 244 483 minecraft:basalt
setblock 500 244 484 minecraft:magma_block
setblock 500 244 490 minecraft:magma_block
fill 500 244 491 500 244 492 minecraft:basalt
setblock 500 244 504 minecraft:red_terracotta
fill 501 244 485 501 244 486 minecraft:basalt
fill 501 244 488 501 244 489 minecraft:basalt
fill 510 244 484 510 247 484 minecraft:red_terracotta
setblock 510 244 488 minecraft:terracotta
fill 510 244 489 510 247 489 minecraft:red_terracotta
setblock 510 244 493 minecraft:terracotta
setblock 511 244 467 minecraft:terracotta
fill 511 244 468 511 247 468 minecraft:red_terracotta
setblock 511 244 472 minecraft:terracotta
fill 511 244 473 511 247 473 minecraft:red_terracotta
setblock 511 244 482 minecraft:terracotta
fill 511 244 483 511 247 483 minecraft:red_terracotta
setblock 511 244 487 minecraft:terracotta
fill 511 244 488 511 247 488 minecraft:red_terracotta
setblock 511 244 492 minecraft:terracotta
fill 511 244 493 511 247 493 minecraft:red_terracotta
fill 471 245 464 471 245 465 minecraft:red_terracotta
setblock 471 245 466 minecraft:terracotta
fill 471 245 467 471 248 467 minecraft:red_terracotta
setblock 471 245 471 minecraft:terracotta
fill 471 245 472 471 248 472 minecraft:red_terracotta
setblock 471 245 476 minecraft:terracotta
fill 471 245 477 471 245 480 minecraft:red_terracotta
setblock 471 245 481 minecraft:terracotta
fill 471 245 482 471 248 482 minecraft:red_terracotta
setblock 471 245 486 minecraft:terracotta
fill 471 245 487 471 248 487 minecraft:red_terracotta
setblock 471 245 491 minecraft:terracotta
fill 471 245 492 471 248 492 minecraft:red_terracotta
setblock 472 245 464 minecraft:red_terracotta
setblock 472 245 465 minecraft:terracotta
fill 472 245 466 472 248 466 minecraft:red_terracotta
setblock 472 245 470 minecraft:terracotta
fill 472 245 471 472 248 471 minecraft:red_terracotta
setblock 472 245 475 minecraft:terracotta
fill 472 245 476 472 247 477 minecraft:red_terracotta
setblock 472 245 485 minecraft:terracotta
fill 472 245 486 472 248 486 minecraft:red_terracotta
setblock 472 245 490 minecraft:terracotta
fill 472 245 491 472 248 491 minecraft:red_terracotta
setblock 473 245 464 minecraft:terracotta
fill 473 245 465 473 248 465 minecraft:red_terracotta
setblock 473 245 469 minecraft:terracotta
fill 473 245 470 474 247 470 minecraft:red_terracotta
setblock 473 245 473 minecraft:red_terracotta
fill 474 245 464 477 245 464 minecraft:red_terracotta
fill 474 245 469 474 248 469 minecraft:red_terracotta
setblock 476 245 466 minecraft:terracotta
setblock 477 245 465 minecraft:terracotta
fill 477 245 466 477 248 466 minecraft:red_terracotta
setblock 478 245 464 minecraft:terracotta
fill 478 245 465 481 245 465 minecraft:red_terracotta
fill 479 245 464 482 245 464 minecraft:red_terracotta
setblock 481 245 482 minecraft:basalt
setblock 481 245 483 minecraft:magma_block
setblock 481 245 485 minecraft:basalt
setblock 481 245 486 minecraft:magma_block
fill 481 245 487 481 245 488 minecraft:basalt
setblock 481 245 489 minecraft:magma_block
setblock 481 245 490 minecraft:basalt
setblock 481 245 492 minecraft:magma_block
setblock 482 245 465 minecraft:terracotta
setblock 483 245 464 minecraft:terracotta
setblock 483 245 485 minecraft:basalt
setblock 483 245 488 minecraft:basalt
fill 484 245 464 487 245 464 minecraft:red_terracotta
setblock 484 245 479 minecraft:magma_block
setblock 484 245 482 minecraft:magma_block
fill 484 245 485 484 245 488 minecraft:magma_block
setblock 484 245 491 minecraft:magma_block
setblock 484 245 494 minecraft:magma_block
setblock 485 245 483 minecraft:basalt
fill 485 245 484 485 245 486 minecraft:magma_block
fill 485 245 488 485 245 490 minecraft:magma_block
setblock 486 245 483 minecraft:magma_block
setblock 486 245 491 minecraft:magma_block
setblock 487 245 478 minecraft:magma_block
fill 487 245 481 487 245 482 minecraft:magma_block
fill 487 245 492 487 245 493 minecraft:magma_block
setblock 487 245 494 minecraft:basalt
setblock 487 245 496 minecraft:magma_block
setblock 488 245 464 minecraft:terracotta
fill 488 245 465 491 245 465 minecraft:red_terracotta
fill 488 245 477 488 245 478 minecraft:basalt
setblock 488 245 481 minecraft:basalt
fill 488 245 482 489 245 482 minecraft:magma_block
fill 488 245 492 489 245 492 minecraft:magma_block
setblock 488 245 493 minecraft:basalt
setblock 488 245 496 minecraft:basalt
fill 489 245 464 492 245 464 minecraft:red_terracotta
setblock 489 245 477 minecraft:basalt
fill 489 245 481 490 245 481 minecraft:magma_block
fill 489 245 493 490 245 493 minecraft:magma_block
fill 489 245 504 492 245 504 minecraft:red_terracotta
setblock 490 245 477 minecraft:magma_block
setblock 490 245 480 minecraft:magma_block
setblock 490 245 495 minecraft:magma_block
setblock 491 245 480 minecraft:basalt
fill 491 245 482 493 245 482 minecraft:magma_block
fill 491 245 492 493 245 492 minecraft:magma_block
fill 491 245 495 492 245 495 minecraft:basalt
setblock 492 245 465 minecraft:terracotta
setblock 492 245 466 minecraft:red_terracotta
fill 492 245 503 493 245 503 minecraft:red_terracotta
setblock 493 245 464 minecraft:terracotta
fill 493 245 465 493 248 465 minecraft:red_terracotta
setblock 493 245 478 minecraft:basalt
setblock 493 245 479 minecraft:magma_block
setblock 493 245 493 minecraft:basalt
setblock 493 245 494 minecraft:magma_block
setblock 493 245 504 minecraft:terracotta
fill 494 245 464 494 248 464 minecraft:red_terracotta
setblock 494 245 483 minecraft:magma_block
setblock 494 245 491 minecraft:magma_block
setblock 494 245 492 minecraft:basalt
setblock 494 245 503 minecraft:terracotta
fill 494 245 504 497 245 504 minecraft:red_terracotta
fill 495 245 484 495 245 486 minecraft:magma_block
fill 495 245 488 495 245 490 minecraft:magma_block
fill 495 245 503 497 245 503 minecraft:red_terracotta
setblock 496 245 481 minecraft:magma_block
setblock 496 245 484 minecraft:magma_block
setblock 496 245 485 minecraft:basalt
fill 496 245 486 496 245 488 minecraft:magma_block
setblock 496 245 489 minecraft:basalt
setblock 496 245 490 minecraft:magma_block
setblock 496 245 491 minecraft:basalt
setblock 496 245 493 minecraft:magma_block
setblock 497 245 465 minecraft:terracotta
setblock 497 245 494 minecraft:basalt
setblock 498 245 464 minecraft:terracotta
setblock 498 245 492 minecraft:basalt
setblock 498 245 504 minecraft:terracotta
setblock 499 245 464 minecraft:red_terracotta
setblock 499 245 482 minecraft:basalt
setblock 499 245 483 minecraft:magma_block
setblock 499 245 485 minecraft:basalt
setblock 499 245 486 minecraft:magma_block
fill 499 245 487 499 245 488 minecraft:basalt
setblock 499 245 489 minecraft:magma_block
setblock 499 245 490 minecraft:basalt
setblock 499 245 492 minecraft:magma_block
fill 499 245 504 499 246 504 minecraft:red_terracotta
setblock 510 245 487 minecraft:terracotta
fill 510 245 488 510 248 488 minecraft:red_terracotta
setblock 510 245 492 minecraft:terracotta
fill 510 245 493 510 247 494 minecraft:red_terracotta
setblock 511 245 466 minecraft:terracotta
fill 511 245 467 511 248 467 minecraft:red_terracotta
fill 511 245 469 511 245 470 minecraft:red_terracotta
setblock 511 245 471 minecraft:terracotta
fill 511 245 472 511 248 472 minecraft:red_terracotta
fill 511 245 474 511 245 475 minecraft:red_terracotta
setblock 511 245 476 minecraft:terracotta
fill 511 245 479 511 246 479 minecraft:red_terracotta
setblock 511 245 481 minecraft:terracotta
fill 511 245 482 511 248 482 minecraft:red_terracotta
setblock 511 245 486 minecraft:terracotta
fill 511 245 487 511 248 487 minecraft:red_terracotta
setblock 511 245 491 minecraft:terracotta
fill 511 245 492 511 248 492 minecraft:red_terracotta
setblock 511 245 496 minecraft:terracotta
fill 511 245 497 511 248 497 minecraft:red_terracotta
setblock 471 246 464 minecraft:red_terracotta
setblock 471 246 465 minecraft:terracotta
fill 471 246 466 471 249 466 minecraft:red_terracotta
setblock 471 246 470 minecraft:terracotta
fill 471 246 471 471 249 471 minecraft:red_terracotta
setblock 471 246 474 minecraft:red_terracotta
setblock 471 246 475 minecraft:terracotta
fill 471 246 476 471 246 479 minecraft:red_terracotta
setblock 471 246 480 minecraft:terracotta
fill 471 246 481 471 249 481 minecraft:red_terracotta
setblock 471 246 485 minecraft:terracotta
fill 471 246 486 471 249 486 minecraft:red_terracotta
setblock 471 246 490 minecraft:terracotta
fill 471 246 491 471 249 491 minecraft:red_terracotta
setblock 471 246 495 minecraft:terracotta
setblock 472 246 464 minecraft:terracotta
fill 472 246 465 472 249 465 minecraft:red_terracotta
setblock 472 246 469 minecraft:terracotta
fill 472 246 470 472 249 470 minecraft:red_terracotta
setblock 472 246 474 minecraft:terracotta
fill 472 246 475 473 248 475 minecraft:red_terracotta
setblock 472 246 478 minecraft:red_terracotta
setblock 472 246 484 minecraft:terracotta
fill 472 246 485 472 249 485 minecraft:red_terracotta
setblock 472 246 489 minecraft:terracotta
fill 472 246 490 472 249 490 minecraft:red_terracotta
setblock 472 246 493 minecraft:red_terracotta
fill 473 246 464 476 246 464 minecraft:red_terracotta
setblock 473 246 468 minecraft:terracotta
fill 473 246 469 473 249 469 minecraft:red_terracotta
setblock 473 246 473 minecraft:terracotta
fill 473 246 474 473 249 474 minecraft:red_terracotta
setblock 473 246 482 minecraft:light[level=14]
setblock 473 246 490 minecraft:light[level=14]
setblock 473 246 498 minecraft:light[level=14]
fill 474 246 468 474 249 468 minecraft:red_terracotta
setblock 474 246 471 minecraft:red_terracotta
setblock 475 246 466 minecraft:terracotta
setblock 476 246 465 minecraft:terracotta
fill 476 246 466 476 249 466 minecraft:red_terracotta
setblock 477 246 464 minecraft:terracotta
fill 477 246 465 480 246 465 minecraft:red_terracotta
fill 478 246 464 481 246 464 minecraft:red_terracotta
setblock 481 246 466 minecraft:light[level=14]
setblock 481 246 474 minecraft:light[level=14]
setblock 481 246 482 minecraft:light[level=14]
setblock 481 246 490 minecraft:light[level=14]
setblock 481 246 498 minecraft:light[level=14]
setblock 482 246 464 minecraft:terracotta
fill 483 246 464 486 246 464 minecraft:red_terracotta
setblock 487 246 464 minecraft:terracotta
fill 488 246 464 490 246 465 minecraft:red_terracotta
setblock 489 246 466 minecraft:light[level=14]
setblock 489 246 474 minecraft:light[level=14]
setblock 489 246 482 minecraft:light[level=14]
setblock 489 246 490 minecraft:light[level=14]
setblock 489 246 498 minecraft:light[level=14]
fill 489 246 504 491 246 504 minecraft:red_terracotta
setblock 491 246 464 minecraft:red_terracotta
setblock 491 246 465 minecraft:terracotta
setblock 492 246 464 minecraft:terracotta
fill 492 246 465 492 249 465 minecraft:red_terracotta
setblock 492 246 503 minecraft:red_terracotta
setblock 492 246 504 minecraft:terracotta
fill 493 246 464 493 249 464 minecraft:red_terracotta
setblock 493 246 503 minecraft:terracotta
fill 493 246 504 496 246 504 minecraft:red_terracotta
fill 494 246 503 496 246 503 minecraft:red_terracotta
setblock 496 246 465 minecraft:terracotta
setblock 497 246 464 minecraft:terracotta
setblock 497 246 466 minecraft:light[level=14]
setblock 497 246 474 minecraft:light[level=14]
setblock 497 246 482 minecraft:light[level=14]
setblock 497 246 490 minecraft:light[level=14]
setblock 497 246 498 minecraft:light[level=14]
setblock 497 246 504 minecraft:terracotta
setblock 498 246 464 minecraft:red_terracotta
fill 498 246 504 498 248 504 minecraft:red_terracotta
setblock 505 246 466 minecraft:light[level=14]
setblock 505 246 474 minecraft:light[level=14]
setblock 505 246 482 minecraft:light[level=14]
setblock 505 246 490 minecraft:light[level=14]
setblock 505 246 498 minecraft:light[level=14]
fill 509 246 489 509 246 491 minecraft:red_terracotta
setblock 510 246 486 minecraft:terracotta
fill 510 246 487 510 249 487 minecraft:red_terracotta
setblock 510 246 491 minecraft:terracotta
fill 510 246 492 510 249 492 minecraft:red_terracotta
setblock 510 246 495 minecraft:red_terracotta
setblock 511 246 465 minecraft:terracotta
fill 511 246 466 511 249 466 minecraft:red_terracotta
setblock 511 246 469 minecraft:red_terracotta
setblock 511 246 470 minecraft:terracotta
fill 511 246 471 511 249 471 minecraft:red_terracotta
setblock 511 246 474 minecraft:red_terracotta
setblock 511 246 475 minecraft:terracotta
fill 511 246 476 511 247 478 minecraft:red_terracotta
setblock 511 246 480 minecraft:terracotta
fill 511 246 481 511 249 481 minecraft:red_terracotta
setblock 511 246 485 minecraft:terracotta
fill 511 246 486 511 249 486 minecraft:red_terracotta
setblock 511 246 490 minecraft:terracotta
fill 511 246 491 511 249 491 minecraft:red_terracotta
setblock 511 246 495 minecraft:terracotta
fill 511 246 496 511 249 496 minecraft:red_terracotta
setblock 471 247 464 minecraft:terracotta
fill 471 247 465 471 250 465 minecraft:red_terracotta
setblock 471 247 469 minecraft:terracotta
fill 471 247 470 471 250 470 minecraft:red_terracotta
setblock 471 247 474 minecraft:terracotta
fill 471 247 475 471 247 478 minecraft:red_terracotta
setblock 471 247 479 minecraft:terracotta
fill 471 247 480 472 249 480 minecraft:red_terracotta
setblock 471 247 484 minecraft:terracotta
fill 471 247 485 471 250 485 minecraft:red_terracotta
setblock 471 247 489 minecraft:terracotta
fill 471 247 490 471 250 490 minecraft:red_terracotta
setblock 471 247 493 minecraft:red_terracotta
setblock 471 247 494 minecraft:terracotta
fill 471 247 495 471 249 496 minecraft:red_terracotta
fill 472 247 464 475 247 464 minecraft:red_terracotta
setblock 472 247 468 minecraft:terracotta
fill 472 247 469 472 250 469 minecraft:red_terracotta
setblock 472 247 472 minecraft:red_terracotta
setblock 472 247 473 minecraft:terracotta
fill 472 247 474 472 250 474 minecraft:red_terracotta
setblock 472 247 478 minecraft:terracotta
fill 472 247 479 472 250 479 minecraft:red_terracotta
setblock 472 247 483 minecraft:terracotta
fill 472 247 484 472 250 484 minecraft:red_terracotta
setblock 472 247 488 minecraft:terracotta
fill 472 247 489 472 250 489 minecraft:red_terracotta
setblock 472 247 493 minecraft:terracotta
fill 472 247 494 472 250 494 minecraft:red_terracotta
setblock 473 247 467 minecraft:terracotta
fill 473 247 468 473 250 468 minecraft:red_terracotta
setblock 473 247 472 minecraft:terracotta
fill 473 247 473 474 249 473 minecraft:red_terracotta
setblock 473 247 476 minecraft:red_terracotta
setblock 474 247 466 minecraft:terracotta
setblock 474 247 471 minecraft:terracotta
fill 474 247 472 474 250 472 minecraft:red_terracotta
setblock 475 247 465 minecraft:terracotta
fill 475 247 466 475 250 466 minecraft:red_terracotta
setblock 476 247 464 minecraft:terracotta
fill 476 247 465 479 247 465 minecraft:red_terracotta
fill 477 247 464 480 247 464 minecraft:red_terracotta
setblock 480 247 465 minecraft:terracotta
setblock 481 247 464 minecraft:terracotta
fill 482 247 464 485 247 464 minecraft:red_terracotta
setblock 486 247 464 minecraft:terracotta
fill 487 247 464 490 247 464 minecraft:red_terracotta
fill 488 247 465 489 247 465 minecraft:red_terracotta
fill 488 247 504 490 247 504 minecraft:red_terracotta
setblock 490 247 465 minecraft:terracotta
setblock 491 247 464 minecraft:terracotta
fill 491 247 465 491 250 465 minecraft:red_terracotta
setblock 491 247 503 minecraft:red_terracotta
setblock 491 247 504 minecraft:terracotta
fill 492 247 464 492 250 464 minecraft:red_terracotta
setblock 492 247 503 minecraft:terracotta
fill 492 247 504 495 247 504 minecraft:red_terracotta
fill 493 247 503 495 248 503 minecraft:red_terracotta
setblock 495 247 465 minecraft:terracotta
setblock 496 247 464 minecraft:terracotta
setblock 496 247 465 minecraft:red_terracotta
setblock 496 247 504 minecraft:terracotta
fill 497 247 464 497 248 464 minecraft:red_terracotta
fill 497 247 504 497 250 504 minecraft:red_terracotta
fill 509 247 488 509 247 490 minecraft:red_terracotta
setblock 509 247 491 minecraft:terracotta
fill 509 247 492 509 249 493 minecraft:red_terracotta
setblock 510 247 469 minecraft:red_terracotta
setblock 510 247 470 minecraft:terracotta
fill 510 247 471 510 247 474 minecraft:red_terracotta
setblock 510 247 485 minecraft:terracotta
fill 510 247 486 510 250 486 minecraft:red_terracotta
setblock 510 247 490 minecraft:terracotta
fill 510 247 491 510 250 491 minecraft:red_terracotta
setblock 510 247 495 minecraft:terracotta
fill 510 247 496 510 250 496 minecraft:red_terracotta
fill 511 247 465 511 250 465 minecraft:red_terracotta
setblock 511 247 469 minecraft:terracotta
fill 511 247 470 511 250 470 minecraft:red_terracotta
setblock 511 247 474 minecraft:terracotta
fill 511 247 475 511 250 475 minecraft:red_terracotta
setblock 511 247 479 minecraft:terracotta
fill 511 247 480 511 250 480 minecraft:red_terracotta
setblock 511 247 484 minecraft:terracotta
fill 511 247 485 511 250 485 minecraft:red_terracotta
setblock 511 247 489 minecraft:terracotta
fill 511 247 490 511 250 490 minecraft:red_terracotta
setblock 511 247 494 minecraft:terracotta
fill 511 247 495 511 250 495 minecraft:red_terracotta
setblock 511 247 498 minecraft:red_terracotta
fill 471 248 464 474 248 464 minecraft:red_terracotta
setblock 471 248 468 minecraft:terracotta
fill 471 248 469 471 251 469 minecraft:red_terracotta
setblock 471 248 473 minecraft:terracotta
fill 471 248 474 471 248 477 minecraft:red_terracotta
setblock 471 248 478 minecraft:terracotta
fill 471 248 479 471 251 479 minecraft:red_terracotta
setblock 471 248 483 minecraft:terracotta
fill 471 248 484 471 251 484 minecraft:red_terracotta
setblock 471 248 488 minecraft:terracotta
fill 471 248 489 471 251 489 minecraft:red_terracotta
setblock 471 248 493 minecraft:terracotta
fill 471 248 494 471 251 494 minecraft:red_terracotta
setblock 471 248 497 minecraft:red_terracotta
setblock 471 248 498 minecraft:terracotta
setblock 472 248 467 minecraft:terracotta
fill 472 248 468 472 251 468 minecraft:red_terracotta
setblock 472 248 472 minecraft:terracotta
fill 472 248 473 472 251 473 minecraft:red_terracotta
setblock 472 248 476 minecraft:red_terracotta
setblock 472 248 477 minecraft:terracotta
fill 472 248 478 472 251 478 minecraft:red_terracotta
setblock 472 248 481 minecraft:red_terracotta
setblock 472 248 482 minecraft:terracotta
fill 472 248 483 472 251 483 minecraft:red_terracotta
setblock 472 248 487 minecraft:terracotta
fill 472 248 488 472 251 488 minecraft:red_terracotta
setblock 472 248 492 minecraft:terracotta
fill 472 248 493 472 251 493 minecraft:red_terracotta
fill 472 248 495 472 249 495 minecraft:red_terracotta
setblock 473 248 466 minecraft:terracotta
fill 473 248 467 473 251 467 minecraft:red_terracotta
setblock 473 248 470 minecraft:red_terracotta
setblock 473 248 471 minecraft:terracotta
fill 473 248 472 473 251 472 minecraft:red_terracotta
setblock 473 248 476 minecraft:terracotta
fill 473 248 477 473 251 477 minecraft:red_terracotta
setblock 474 248 465 minecraft:terracotta
fill 474 248 466 474 251 466 minecraft:red_terracotta
setblock 474 248 470 minecraft:terracotta
fill 474 248 471 474 251 471 minecraft:red_terracotta
setblock 474 248 474 minecraft:red_terracotta
setblock 475 248 464 minecraft:terracotta
fill 475 248 465 478 248 465 minecraft:red_terracotta
fill 476 248 464 479 248 464 minecraft:red_terracotta
setblock 479 248 465 minecraft:terracotta
setblock 480 248 464 minecraft:terracotta
fill 481 248 464 484 248 464 minecraft:red_terracotta
setblock 485 248 464 minecraft:terracotta
fill 486 248 464 489 248 464 minecraft:red_terracotta
fill 487 248 504 489 248 504 minecraft:red_terracotta
setblock 488 248 465 minecraft:red_terracotta
setblock 489 248 465 minecraft:terracotta
setblock 490 248 464 minecraft:terracotta
fill 490 248 465 490 251 465 minecraft:red_terracotta
setblock 490 248 503 minecraft:red_terracotta
setblock 490 248 504 minecraft:terracotta
fill 491 248 464 491 251 464 minecraft:red_terracotta
setblock 491 248 503 minecraft:terracotta
fill 491 248 504 494 248 504 minecraft:red_terracotta
fill 492 248 503 492 251 503 minecraft:red_terracotta
setblock 494 248 465 minecraft:terracotta
setblock 495 248 464 minecraft:terracotta
setblock 495 248 465 minecraft:red_terracotta
setblock 495 248 504 minecraft:terracotta
fill 496 248 464 496 250 464 minecraft:red_terracotta
fill 496 248 504 496 251 504 minecraft:red_terracotta
fill 509 248 488 509 248 489 minecraft:red_terracotta
setblock 509 248 490 minecraft:terracotta
fill 509 248 491 509 251 491 minecraft:red_terracotta
setblock 509 248 494 minecraft:red_terracotta
setblock 510 248 468 minecraft:red_terracotta
setblock 510 248 469 minecraft:terracotta
fill 510 248 470 510 248 473 minecraft:red_terracotta
setblock 510 248 474 minecraft:terracotta
fill 510 248 475 510 248 478 minecraft:red_terracotta
setblock 510 248 483 minecraft:red_terracotta
setblock 510 248 484 minecraft:terracotta
fill 510 248 485 510 251 485 minecraft:red_terracotta
setblock 510 248 489 minecraft:terracotta
fill 510 248 490 510 251 490 minecraft:red_terracotta
setblock 510 248 493 minecraft:red_terracotta
setblock 510 248 494 minecraft:terracotta
fill 510 248 495 510 251 495 minecraft:red_terracotta
fill 510 248 497 510 249 497 minecraft:red_terracotta
fill 511 248 464 511 251 464 minecraft:red_terracotta
setblock 511 248 468 minecraft:terracotta
fill 511 248 469 511 251 469 minecraft:red_terracotta
setblock 511 248 473 minecraft:terracotta
fill 511 248 474 511 251 474 minecraft:red_terracotta
fill 511 248 476 511 248 477 minecraft:red_terracotta
setblock 511 248 478 minecraft:terracotta
fill 511 248 479 511 251 479 minecraft:red_terracotta
setblock 511 248 483 minecraft:terracotta
fill 511 248 484 511 251 484 minecraft:red_terracotta
setblock 511 248 488 minecraft:terracotta
fill 511 248 489 511 251 489 minecraft:red_terracotta
setblock 511 248 493 minecraft:terracotta
fill 511 248 494 511 251 494 minecraft:red_terracotta
setblock 511 248 498 minecraft:terracotta
fill 511 248 499 511 251 499 minecraft:red_terracotta
fill 471 249 464 473 249 464 minecraft:red_terracotta
setblock 471 249 467 minecraft:terracotta
fill 471 249 468 471 252 468 minecraft:red_terracotta
setblock 471 249 472 minecraft:terracotta
fill 471 249 473 471 249 476 minecraft:red_terracotta
setblock 471 249 477 minecraft:terracotta
fill 471 249 478 471 252 478 minecraft:red_terracotta
setblock 471 249 482 minecraft:terracotta
fill 471 249 483 471 252 483 minecraft:red_terracotta
setblock 471 249 487 minecraft:terracotta
fill 471 249 488 471 252 488 minecraft:red_terracotta
setblock 471 249 492 minecraft:terracotta
fill 471 249 493 471 252 493 minecraft:red_terracotta
setblock 471 249 497 minecraft:terracotta
fill 471 249 498 471 250 500 minecraft:red_terracotta
setblock 472 249 466 minecraft:terracotta
fill 472 249 467 472 252 467 minecraft:red_terracotta
setblock 472 249 471 minecraft:terracotta
fill 472 249 472 472 252 472 minecraft:red_terracotta
setblock 472 249 475 minecraft:red_terracotta
setblock 472 249 476 minecraft:terracotta
fill 472 249 477 472 252 477 minecraft:red_terracotta
setblock 472 249 481 minecraft:terracotta
fill 472 249 482 472 252 482 minecraft:red_terracotta
setblock 472 249 486 minecraft:terracotta
fill 472 249 487 472 251 487 minecraft:red_terracotta
setblock 472 249 491 minecraft:terracotta
fill 472 249 492 472 252 492 minecraft:red_terracotta
setblock 472 249 496 minecraft:terracotta
fill 472 249 497 472 252 497 minecraft:red_terracotta
setblock 473 249 465 minecraft:terracotta
fill 473 249 466 473 252 466 minecraft:red_terracotta
setblock 473 249 470 minecraft:terracotta
fill 473 249 471 473 252 471 minecraft:red_terracotta
setblock 473 249 475 minecraft:terracotta
fill 473 249 476 473 252 476 minecraft:red_terracotta
fill 473 249 478 473 250 478 minecraft:red_terracotta
setblock 474 249 464 minecraft:terracotta
fill 474 249 465 477 249 465 minecraft:red_terracotta
setblock 474 249 469 minecraft:terracotta
fill 474 249 470 474 252 470 minecraft:red_terracotta
setblock 474 249 474 minecraft:terracotta
fill 474 249 475 474 252 475 minecraft:red_terracotta
fill 475 249 464 478 249 464 minecraft:red_terracotta
setblock 478 249 465 minecraft:terracotta
setblock 479 249 464 minecraft:terracotta
fill 480 249 464 483 249 464 minecraft:red_terracotta
setblock 484 249 464 minecraft:terracotta
fill 485 249 464 488 249 464 minecraft:red_terracotta
fill 486 249 504 488 249 504 minecraft:red_terracotta
setblock 487 249 465 minecraft:red_terracotta
setblock 488 249 465 minecraft:terracotta
setblock 489 249 464 minecraft:terracotta
fill 489 249 465 489 252 465 minecraft:red_terracotta
setblock 489 249 503 minecraft:red_terracotta
setblock 489 249 504 minecraft:terracotta
fill 490 249 464 490 252 464 minecraft:red_terracotta
setblock 490 249 503 minecraft:terracotta
fill 490 249 504 493 249 504 minecraft:red_terracotta
fill 491 249 503 491 252 503 minecraft:red_terracotta
setblock 493 249 465 minecraft:terracotta
fill 493 249 503 494 249 503 minecraft:red_terracotta
setblock 494 249 464 minecraft:terracotta
fill 494 249 465 494 250 465 minecraft:red_terracotta
setblock 494 249 504 minecraft:terracotta
fill 495 249 464 495 251 464 minecraft:red_terracotta
setblock 495 249 503 minecraft:terracotta
fill 495 249 504 495 252 504 minecraft:red_terracotta
fill 509 249 472 509 249 473 minecraft:red_terracotta
setblock 509 249 474 minecraft:terracotta
fill 509 249 487 509 249 488 minecraft:red_terracotta
setblock 509 249 489 minecraft:terracotta
fill 509 249 490 509 252 490 minecraft:red_terracotta
setblock 509 249 494 minecraft:terracotta
fill 509 249 495 509 252 495 minecraft:red_terracotta
setblock 510 249 467 minecraft:red_terracotta
setblock 510 249 468 minecraft:terracotta
fill 510 249 469 510 249 472 minecraft:red_terracotta
setblock 510 249 473 minecraft:terracotta
fill 510 249 474 510 249 477 minecraft:red_terracotta
setblock 510 249 478 minecraft:terracotta
fill 510 249 479 510 249 482 minecraft:red_terracotta
setblock 510 249 483 minecraft:terracotta
fill 510 249 484 510 252 484 minecraft:red_terracotta
setblock 510 249 488 minecraft:terracotta
fill 510 249 489 510 252 489 minecraft:red_terracotta
setblock 510 249 493 minecraft:terracotta
fill 510 249 494 510 252 494 minecraft:red_terracotta
setblock 510 249 498 minecraft:terracotta
setblock 511 249 467 minecraft:terracotta
fill 511 249 468 511 252 468 minecraft:red_terracotta
setblock 511 249 472 minecraft:terracotta
fill 511 249 473 511 252 473 minecraft:red_terracotta
setblock 511 249 476 minecraft:red_terracotta
setblock 511 249 477 minecraft:terracotta
fill 511 249 478 511 252 478 minecraft:red_terracotta
setblock 511 249 482 minecraft:terracotta
fill 511 249 483 511 252 483 minecraft:red_terracotta
setblock 511 249 487 minecraft:terracotta
fill 511 249 488 511 252 488 minecraft:red_terracotta
setblock 511 249 492 minecraft:terracotta
fill 511 249 493 511 252 493 minecraft:red_terracotta
setblock 511 249 497 minecraft:terracotta
fill 511 249 498 511 252 498 minecraft:red_terracotta
fill 511 249 500 511 249 501 minecraft:red_terracotta
fill 471 250 464 472 250 464 minecraft:red_terracotta
setblock 471 250 466 minecraft:terracotta
fill 471 250 467 471 253 467 minecraft:red_terracotta
setblock 471 250 471 minecraft:terracotta
fill 471 250 472 471 250 475 minecraft:red_terracotta
setblock 471 250 476 minecraft:terracotta
fill 471 250 477 471 253 477 minecraft:red_terracotta
setblock 471 250 480 minecraft:red_terracotta
setblock 471 250 481 minecraft:terracotta
fill 471 250 482 471 253 482 minecraft:red_terracotta
setblock 471 250 486 minecraft:terracotta
fill 471 250 487 471 253 487 minecraft:red_terracotta
setblock 471 250 491 minecraft:terracotta
fill 471 250 492 471 253 492 minecraft:red_terracotta
setblock 471 250 495 minecraft:red_terracotta
setblock 471 250 496 minecraft:terracotta
fill 471 250 497 471 253 497 minecraft:red_terracotta
setblock 471 250 501 minecraft:terracotta
fill 471 250 502 471 251 504 minecraft:red_terracotta
setblock 472 250 465 minecraft:terracotta
fill 472 250 466 472 253 466 minecraft:red_terracotta
setblock 472 250 470 minecraft:terracotta
fill 472 250 471 472 253 471 minecraft:red_terracotta
setblock 472 250 475 minecraft:terracotta
fill 472 250 476 472 253 476 minecraft:red_terracotta
setblock 472 250 480 minecraft:terracotta
fill 472 250 481 472 253 481 minecraft:red_terracotta
setblock 472 250 485 minecraft:terracotta
fill 472 250 486 472 251 486 minecraft:red_terracotta
setblock 472 250 490 minecraft:terracotta
fill 472 250 491 472 253 491 minecraft:red_terracotta
setblock 472 250 495 minecraft:terracotta
fill 472 250 496 472 253 496 minecraft:red_terracotta
fill 472 250 498 472 251 498 minecraft:red_terracotta
setblock 472 250 504 minecraft:red_terracotta
setblock 473 250 464 minecraft:terracotta
fill 473 250 465 476 250 465 minecraft:red_terracotta
setblock 473 250 469 minecraft:terracotta
fill 473 250 470 473 253 470 minecraft:red_terracotta
setblock 473 250 473 minecraft:red_terracotta
setblock 473 250 474 minecraft:terracotta
fill 473 250 475 473 253 475 minecraft:red_terracotta
setblock 473 250 479 minecraft:terracotta
setblock 473 250 504 minecraft:terracotta
fill 474 250 464 477 250 464 minecraft:red_terracotta
setblock 474 250 468 minecraft:terracotta
fill 474 250 469 474 252 469 minecraft:red_terracotta
setblock 474 250 473 minecraft:terracotta
fill 474 250 474 474 253 474 minecraft:red_terracotta
fill 474 250 504 475 252 504 minecraft:red_terracotta
setblock 476 250 466 minecraft:terracotta
setblock 477 250 465 minecraft:terracotta
setblock 478 250 464 minecraft:terracotta
setblock 478 250 465 minecraft:red_terracotta
fill 479 250 464 482 250 464 minecraft:red_terracotta
setblock 483 250 464 minecraft:terracotta
fill 484 250 464 487 250 464 minecraft:red_terracotta
fill 485 250 504 487 250 504 minecraft:red_terracotta
setblock 487 250 465 minecraft:terracotta
setblock 488 250 464 minecraft:terracotta
fill 488 250 465 488 253 465 minecraft:red_terracotta
setblock 488 250 503 minecraft:red_terracotta
setblock 488 250 504 minecraft:terracotta
fill 489 250 464 489 253 464 minecraft:red_terracotta
setblock 489 250 503 minecraft:terracotta
fill 489 250 504 492 250 504 minecraft:red_terracotta
setblock 490 250 502 minecraft:terracotta
fill 490 250 503 490 253 503 minecraft:red_terracotta
fill 491 250 502 493 251 502 minecraft:red_terracotta
setblock 492 250 465 minecraft:terracotta
setblock 493 250 464 minecraft:terracotta
fill 493 250 465 493 251 465 minecraft:red_terracotta
setblock 493 250 503 minecraft:red_terracotta
setblock 493 250 504 minecraft:terracotta
fill 494 250 464 494 253 464 minecraft:red_terracotta
setblock 494 250 503 minecraft:terracotta
fill 494 250 504 494 253 504 minecraft:red_terracotta
fill 495 250 503 495 253 503 minecraft:red_terracotta
fill 509 250 470 509 250 472 minecraft:red_terracotta
setblock 509 250 473 minecraft:terracotta
fill 509 250 474 509 250 477 minecraft:red_terracotta
setblock 509 250 478 minecraft:terracotta
setblock 509 250 487 minecraft:red_terracotta
setblock 509 250 488 minecraft:terracotta
fill 509 250 489 509 253 489 minecraft:red_terracotta
setblock 509 250 492 minecraft:red_terracotta
setblock 509 250 493 minecraft:terracotta
fill 509 250 494 509 253 494 minecraft:red_terracotta
fill 509 250 496 509 251 496 minecraft:red_terracotta
fill 510 250 464 510 252 464 minecraft:red_terracotta
setblock 510 250 467 minecraft:terracotta
fill 510 250 468 510 250 471 minecraft:red_terracotta
setblock 510 250 472 minecraft:terracotta
fill 510 250 473 510 250 476 minecraft:red_terracotta
setblock 510 250 477 minecraft:terracotta
fill 510 250 478 510 250 481 minecraft:red_terracotta
setblock 510 250 482 minecraft:terracotta
fill 510 250 483 510 253 483 minecraft:red_terracotta
setblock 510 250 487 minecraft:terracotta
fill 510 250 488 510 253 488 minecraft:red_terracotta
setblock 510 250 492 minecraft:terracotta
fill 510 250 493 510 253 493 minecraft:red_terracotta
setblock 510 250 497 minecraft:terracotta
fill 510 250 498 510 252 499 minecraft:red_terracotta
setblock 511 250 466 minecraft:terracotta
fill 511 250 467 511 253 467 minecraft:red_terracotta
setblock 511 250 471 minecraft:terracotta
fill 511 250 472 511 253 472 minecraft:red_terracotta
setblock 511 250 476 minecraft:terracotta
fill 511 250 477 511 253 477 minecraft:red_terracotta
setblock 511 250 481 minecraft:terracotta
fill 511 250 482 511 253 482 minecraft:red_terracotta
setblock 511 250 486 minecraft:terracotta
fill 511 250 487 511 253 487 minecraft:red_terracotta
setblock 511 250 491 minecraft:terracotta
fill 511 250 492 511 253 492 minecraft:red_terracotta
setblock 511 250 496 minecraft:terracotta
fill 511 250 497 511 253 497 minecraft:red_terracotta
setblock 511 250 500 minecraft:red_terracotta
setblock 511 250 501 minecraft:terracotta
fill 511 250 502 511 253 502 minecraft:red_terracotta
setblock 471 251 464 minecraft:red_terracotta
setblock 471 251 465 minecraft:terracotta
fill 471 251 466 471 254 466 minecraft:red_terracotta
setblock 471 251 470 minecraft:terracotta
fill 471 251 471 471 251 474 minecraft:red_terracotta
setblock 471 251 475 minecraft:terracotta
fill 471 251 476 471 254 476 minecraft:red_terracotta
setblock 471 251 480 minecraft:terracotta
fill 471 251 481 471 254 481 minecraft:red_terracotta
setblock 471 251 485 minecraft:terracotta
fill 471 251 486 471 254 486 minecraft:red_terracotta
setblock 471 251 490 minecraft:terracotta
fill 471 251 491 471 254 491 minecraft:red_terracotta
setblock 471 251 495 minecraft:terracotta
fill 471 251 496 471 254 496 minecraft:red_terracotta
fill 471 251 498 471 251 499 minecraft:red_terracotta
setblock 471 251 500 minecraft:terracotta
fill 471 251 501 471 254 501 minecraft:red_terracotta
setblock 472 251 464 minecraft:terracotta
fill 472 251 465 475 251 465 minecraft:red_terracotta
setblock 472 251 469 minecraft:terracotta
fill 472 251 470 472 254 470 minecraft:red_terracotta
setblock 472 251 474 minecraft:terracotta
fill 472 251 475 472 254 475 minecraft:red_terracotta
setblock 472 251 479 minecraft:terracotta
fill 472 251 480 472 254 480 minecraft:red_terracotta
setblock 472 251 484 minecraft:terracotta
setblock 472 251 485 minecraft:red_terracotta
setblock 472 251 489 minecraft:terracotta
fill 472 251 490 472 253 490 minecraft:red_terracotta
setblock 472 251 494 minecraft:terracotta
fill 472 251 495 472 254 495 minecraft:red_terracotta
setblock 472 251 499 minecraft:terracotta
setblock 472 251 504 minecraft:terracotta
fill 473 251 464 476 251 464 minecraft:red_terracotta
setblock 473 251 468 minecraft:terracotta
fill 473 251 469 473 254 469 minecraft:red_terracotta
setblock 473 251 473 minecraft:terracotta
fill 473 251 474 473 254 474 minecraft:red_terracotta
setblock 473 251 478 minecraft:terracotta
fill 473 251 479 473 254 479 minecraft:red_terracotta
fill 473 251 504 473 254 504 minecraft:red_terracotta
setblock 474 251 468 minecraft:red_terracotta
setblock 474 251 472 minecraft:terracotta
fill 474 251 473 474 254 473 minecraft:red_terracotta
setblock 474 251 476 minecraft:red_terracotta
setblock 475 251 466 minecraft:terracotta
setblock 476 251 465 minecraft:terracotta
setblock 477 251 464 minecraft:terracotta
setblock 477 251 465 minecraft:red_terracotta
fill 478 251 464 481 251 464 minecraft:red_terracotta
fill 478 251 475 479 252 475 minecraft:magma_block
setblock 482 251 464 minecraft:terracotta
fill 483 251 464 486 251 464 minecraft:red_terracotta
fill 484 251 504 486 251 504 minecraft:red_terracotta
setblock 486 251 465 minecraft:terracotta
fill 486 251 503 487 251 503 minecraft:red_terracotta
setblock 487 251 464 minecraft:terracotta
fill 487 251 465 487 254 465 minecraft:red_terracotta
setblock 487 251 504 minecraft:terracotta
fill 488 251 464 488 254 464 minecraft:red_terracotta
setblock 488 251 503 minecraft:terracotta
fill 488 251 504 491 251 504 minecraft:red_terracotta
setblock 489 251 502 minecraft:terracotta
fill 489 251 503 489 254 503 minecraft:red_terracotta
fill 490 251 502 490 254 502 minecraft:red_terracotta
setblock 491 251 465 minecraft:terracotta
setblock 492 251 464 minecraft:terracotta
fill 492 251 465 492 252 465 minecraft:red_terracotta
setblock 492 251 504 minecraft:terracotta
fill 493 251 464 493 254 464 minecraft:red_terracotta
setblock 493 251 503 minecraft:terracotta
fill 493 251 504 493 254 504 minecraft:red_terracotta
setblock 494 251 502 minecraft:terracotta
fill 494 251 503 494 254 503 minecraft:red_terracotta
setblock 496 251 503 minecraft:red_terracotta
setblock 497 251 504 minecraft:terracotta
setblock 508 251 492 minecraft:red_terracotta
setblock 508 251 493 minecraft:terracotta
fill 508 251 494 508 253 494 minecraft:red_terracotta
fill 509 251 464 509 253 464 minecraft:red_terracotta
fill 509 251 469 509 251 471 minecraft:red_terracotta
setblock 509 251 472 minecraft:terracotta
fill 509 251 473 509 251 476 minecraft:red_terracotta
setblock 509 251 477 minecraft:terracotta
fill 509 251 478 509 251 481 minecraft:red_terracotta
setblock 509 251 486 minecraft:red_terracotta
setblock 509 251 487 minecraft:terracotta
fill 509 251 488 509 253 488 minecraft:red_terracotta
setblock 509 251 492 minecraft:terracotta
fill 509 251 493 509 254 493 minecraft:red_terracotta
setblock 509 251 497 minecraft:terracotta
setblock 510 251 466 minecraft:terracotta
fill 510 251 467 510 251 470 minecraft:red_terracotta
setblock 510 251 471 minecraft:terracotta
fill 510 251 472 510 251 475 minecraft:red_terracotta
setblock 510 251 476 minecraft:terracotta
fill 510 251 477 510 251 480 minecraft:red_terracotta
setblock 510 251 481 minecraft:terracotta
fill 510 251 482 510 254 482 minecraft:red_terracotta
setblock 510 251 486 minecraft:terracotta
fill 510 251 487 510 254 487 minecraft:red_terracotta
setblock 510 251 491 minecraft:terracotta
fill 510 251 492 510 254 492 minecraft:red_terracotta
setblock 510 251 496 minecraft:terracotta
fill 510 251 497 510 254 497 minecraft:red_terracotta
setblock 510 251 500 minecraft:red_terracotta
setblock 511 251 465 minecraft:terracotta
fill 511 251 466 511 254 466 minecraft:red_terracotta
setblock 511 251 470 minecraft:terracotta
fill 511 251 471 511 254 471 minecraft:red_terracotta
setblock 511 251 475 minecraft:terracotta
fill 511 251 476 511 254 476 minecraft:red_terracotta
setblock 511 251 480 minecraft:terracotta
fill 511 251 481 511 254 481 minecraft:red_terracotta
setblock 511 251 485 minecraft:terracotta
fill 511 251 486 511 254 486 minecraft:red_terracotta
setblock 511 251 490 minecraft:terracotta
fill 511 251 491 511 254 491 minecraft:red_terracotta
setblock 511 251 495 minecraft:terracotta
fill 511 251 496 511 254 496 minecraft:red_terracotta
setblock 511 251 500 minecraft:terracotta
fill 511 251 501 511 254 501 minecraft:red_terracotta
fill 511 251 503 511 251 504 minecraft:red_terracotta
setblock 471 252 464 minecraft:terracotta
fill 471 252 465 474 252 465 minecraft:red_terracotta
setblock 471 252 469 minecraft:terracotta
fill 471 252 470 471 252 473 minecraft:red_terracotta
setblock 471 252 474 minecraft:terracotta
fill 471 252 475 471 255 475 minecraft:red_terracotta
setblock 471 252 479 minecraft:terracotta
fill 471 252 480 471 255 480 minecraft:red_terracotta
setblock 471 252 484 minecraft:terracotta
fill 471 252 485 471 255 485 minecraft:red_terracotta
setblock 471 252 489 minecraft:terracotta
fill 471 252 490 471 255 490 minecraft:red_terracotta
setblock 471 252 494 minecraft:terracotta
fill 471 252 495 471 255 495 minecraft:red_terracotta
setblock 471 252 498 minecraft:red_terracotta
setblock 471 252 499 minecraft:terracotta
fill 471 252 500 472 254 500 minecraft:red_terracotta
fill 471 252 502 471 252 503 minecraft:red_terracotta
setblock 471 252 504 minecraft:terracotta
fill 472 252 464 475 252 464 minecraft:red_terracotta
setblock 472 252 468 minecraft:terracotta
fill 472 252 469 472 255 469 minecraft:red_terracotta
setblock 472 252 473 minecraft:terracotta
fill 472 252 474 472 255 474 minecraft:red_terracotta
setblock 472 252 478 minecraft:terracotta
fill 472 252 479 472 255 479 minecraft:red_terracotta
setblock 472 252 483 minecraft:terracotta
setblock 472 252 488 minecraft:terracotta
setblock 472 252 489 minecraft:red_terracotta
setblock 472 252 493 minecraft:terracotta
fill 472 252 494 472 255 494 minecraft:red_terracotta
setblock 472 252 498 minecraft:terracotta
fill 472 252 499 472 255 499 minecraft:red_terracotta
fill 472 252 501 472 253 501 minecraft:red_terracotta
fill 472 252 504 472 255 504 minecraft:red_terracotta
setblock 473 252 467 minecraft:terracotta
fill 473 252 468 473 254 468 minecraft:red_terracotta
setblock 473 252 472 minecraft:terracotta
fill 473 252 473 473 255 473 minecraft:red_terracotta
setblock 473 252 477 minecraft:terracotta
fill 473 252 478 473 255 478 minecraft:red_terracotta
setblock 474 252 466 minecraft:terracotta
setblock 474 252 471 minecraft:terracotta
fill 474 252 472 474 253 472 minecraft:red_terracotta
setblock 474 252 476 minecraft:terracotta
setblock 475 252 465 minecraft:terracotta
setblock 476 252 464 minecraft:terracotta
setblock 476 252 465 minecraft:red_terracotta
setblock 476 252 504 minecraft:terracotta
fill 477 252 464 480 252 464 minecraft:red_terracotta
setblock 481 252 464 minecraft:terracotta
fill 482 252 464 485 252 464 minecraft:red_terracotta
fill 483 252 504 485 252 504 minecraft:red_terracotta
fill 485 252 503 486 252 503 minecraft:red_terracotta
setblock 486 252 464 minecraft:terracotta
fill 486 252 465 486 253 465 minecraft:red_terracotta
setblock 486 252 504 minecraft:terracotta
fill 487 252 464 487 255 464 minecraft:red_terracotta
setblock 487 252 502 minecraft:red_terracotta
setblock 487 252 503 minecraft:terracotta
fill 487 252 504 490 252 504 minecraft:red_terracotta
setblock 488 252 502 minecraft:terracotta
fill 488 252 503 488 255 503 minecraft:red_terracotta
fill 489 252 502 489 255 502 minecraft:red_terracotta
setblock 490 252 465 minecraft:terracotta
fill 490 252 501 492 253 501 minecraft:red_terracotta
setblock 491 252 464 minecraft:terracotta
fill 491 252 465 491 253 465 minecraft:red_terracotta
fill 491 252 502 492 252 502 minecraft:red_terracotta
setblock 491 252 504 minecraft:terracotta
fill 492 252 464 492 255 464 minecraft:red_terracotta
setblock 492 252 503 minecraft:terracotta
fill 492 252 504 492 255 504 minecraft:red_terracotta
setblock 493 252 502 minecraft:terracotta
fill 493 252 503 493 255 503 minecraft:red_terracotta
fill 494 252 502 494 254 502 minecraft:red_terracotta
setblock 496 252 504 minecraft:terracotta
fill 497 252 504 497 253 504 minecraft:red_terracotta
fill 508 252 473 508 252 476 minecraft:red_terracotta
setblock 508 252 492 minecraft:terracotta
fill 508 252 493 508 253 493 minecraft:red_terracotta
fill 508 252 495 508 253 495 minecraft:red_terracotta
fill 509 252 469 509 252 470 minecraft:red_terracotta
setblock 509 252 471 minecraft:terracotta
fill 509 252 472 509 252 475 minecraft:red_terracotta
setblock 509 252 476 minecraft:terracotta
fill 509 252 477 509 252 480 minecraft:red_terracotta
setblock 509 252 481 minecraft:terracotta
fill 509 252 482 509 252 485 minecraft:red_terracotta
setblock 509 252 486 minecraft:terracotta
fill 509 252 487 509 253 487 minecraft:red_terracotta
setblock 509 252 491 minecraft:terracotta
fill 509 252 492 509 255 492 minecraft:red_terracotta
setblock 509 252 496 minecraft:terracotta
fill 509 252 497 509 254 498 minecraft:red_terracotta
fill 509 252 504 510 252 504 minecraft:red_terracotta
fill 510 252 466 510 252 469 minecraft:red_terracotta
setblock 510 252 470 minecraft:terracotta
fill 510 252 471 510 252 474 minecraft:red_terracotta
setblock 510 252 475 minecraft:terracotta
fill 510 252 476 510 252 479 minecraft:red_terracotta
setblock 510 252 480 minecraft:terracotta
fill 510 252 481 510 255 481 minecraft:red_terracotta
setblock 510 252 485 minecraft:terracotta
fill 510 252 486 510 255 486 minecraft:red_terracotta
setblock 510 252 490 minecraft:terracotta
fill 510 252 491 510 255 491 minecraft:red_terracotta
setblock 510 252 495 minecraft:terracotta
fill 510 252 496 510 255 496 minecraft:red_terracotta
setblock 510 252 500 minecraft:terracotta
fill 510 252 501 510 255 501 minecraft:red_terracotta
setblock 511 252 464 minecraft:terracotta
fill 511 252 465 511 255 465 minecraft:red_terracotta
setblock 511 252 469 minecraft:terracotta
fill 511 252 470 511 255 470 minecraft:red_terracotta
setblock 511 252 474 minecraft:terracotta
fill 511 252 475 511 255 475 minecraft:red_terracotta
setblock 511 252 479 minecraft:terracotta
fill 511 252 480 511 255 480 minecraft:red_terracotta
setblock 511 252 484 minecraft:terracotta
fill 511 252 485 511 255 485 minecraft:red_terracotta
setblock 511 252 489 minecraft:terracotta
fill 511 252 490 511 255 490 minecraft:red_terracotta
setblock 511 252 494 minecraft:terracotta
fill 511 252 495 511 255 495 minecraft:red_terracotta
setblock 511 252 499 minecraft:terracotta
fill 511 252 500 511 255 500 minecraft:red_terracotta
setblock 511 252 503 minecraft:red_terracotta
setblock 511 252 504 minecraft:terracotta
fill 471 253 464 473 253 465 minecraft:red_terracotta
setblock 471 253 468 minecraft:terracotta
fill 471 253 469 471 253 472 minecraft:red_terracotta
setblock 471 253 473 minecraft:terracotta
fill 471 253 474 471 256 474 minecraft:red_terracotta
setblock 471 253 478 minecraft:terracotta
fill 471 253 479 471 256 479 minecraft:red_terracotta
setblock 471 253 483 minecraft:terracotta
fill 471 253 484 471 256 484 minecraft:red_terracotta
setblock 471 253 488 minecraft:terracotta
fill 471 253 489 471 255 489 minecraft:red_terracotta
setblock 471 253 493 minecraft:terracotta
fill 471 253 494 471 256 494 minecraft:red_terracotta
setblock 471 253 498 minecraft:terracotta
fill 471 253 499 471 256 499 minecraft:red_terracotta
setblock 471 253 502 minecraft:red_terracotta
setblock 471 253 503 minecraft:terracotta
fill 471 253 504 471 256 504 minecraft:red_terracotta
setblock 472 253 467 minecraft:terracotta
fill 472 253 468 472 256 468 minecraft:red_terracotta
setblock 472 253 472 minecraft:terracotta
fill 472 253 473 472 256 473 minecraft:red_terracotta
setblock 472 253 477 minecraft:terracotta
fill 472 253 478 472 256 478 minecraft:red_terracotta
setblock 472 253 482 minecraft:terracotta
setblock 472 253 483 minecraft:red_terracotta
setblock 472 253 492 minecraft:terracotta
fill 472 253 493 472 254 493 minecraft:red_terracotta
setblock 472 253 497 minecraft:terracotta
fill 472 253 498 472 256 498 minecraft:red_terracotta
setblock 472 253 502 minecraft:terracotta
setblock 473 253 466 minecraft:terracotta
setblock 473 253 467 minecraft:red_terracotta
setblock 473 253 471 minecraft:terracotta
fill 473 253 472 473 256 472 minecraft:red_terracotta
setblock 473 253 476 minecraft:terracotta
fill 473 253 477 473 256 477 minecraft:red_terracotta
setblock 474 253 464 minecraft:red_terracotta
setblock 474 253 465 minecraft:terracotta
setblock 474 253 470 minecraft:terracotta
setblock 474 253 471 minecraft:red_terracotta
setblock 474 253 475 minecraft:terracotta
setblock 474 253 476 minecraft:red_terracotta
setblock 474 253 504 minecraft:red_terracotta
setblock 475 253 464 minecraft:terracotta
setblock 475 253 465 minecraft:red_terracotta
setblock 475 253 504 minecraft:terracotta
fill 476 253 464 479 253 464 minecraft:red_terracotta
fill 476 253 504 476 255 504 minecraft:red_terracotta
setblock 480 253 464 minecraft:terracotta
fill 481 253 464 484 253 464 minecraft:red_terracotta
fill 482 253 504 484 253 504 minecraft:red_terracotta
fill 484 253 503 485 253 503 minecraft:red_terracotta
setblock 485 253 464 minecraft:terracotta
setblock 485 253 504 minecraft:terracotta
fill 486 253 464 486 256 464 minecraft:red_terracotta
setblock 486 253 502 minecraft:red_terracotta
setblock 486 253 503 minecraft:terracotta
fill 486 253 504 489 253 504 minecraft:red_terracotta
setblock 487 253 502 minecraft:terracotta
fill 487 253 503 487 256 503 minecraft:red_terracotta
setblock 488 253 501 minecraft:terracotta
fill 488 253 502 488 256 502 minecraft:red_terracotta
setblock 489 253 465 minecraft:terracotta
fill 489 253 501 489 256 501 minecraft:red_terracotta
setblock 490 253 464 minecraft:terracotta
setblock 490 253 465 minecraft:red_terracotta
setblock 490 253 504 minecraft:terracotta
fill 491 253 464 491 256 464 minecraft:red_terracotta
setblock 491 253 502 minecraft:red_terracotta
setblock 491 253 503 minecraft:terracotta
fill 491 253 504 491 256 504 minecraft:red_terracotta
setblock 492 253 502 minecraft:terracotta
fill 492 253 503 492 256 503 minecraft:red_terracotta
fill 493 253 502 493 255 502 minecraft:red_terracotta
setblock 495 253 504 minecraft:terracotta
fill 496 253 504 496 255 504 minecraft:red_terracotta
fill 508 253 473 508 253 475 minecraft:red_terracotta
setblock 508 253 476 minecraft:terracotta
fill 508 253 477 510 253 478 minecraft:red_terracotta
fill 508 253 504 509 253 504 minecraft:red_terracotta
setblock 509 253 469 minecraft:red_terracotta
setblock 509 253 470 minecraft:terracotta
fill 509 253 471 509 253 474 minecraft:red_terracotta
setblock 509 253 475 minecraft:terracotta
fill 509 253 476 510 255 476 minecraft:red_terracotta
setblock 509 253 479 minecraft:red_terracotta
setblock 509 253 480 minecraft:terracotta
fill 509 253 481 509 253 484 minecraft:red_terracotta
setblock 509 253 485 minecraft:terracotta
setblock 509 253 486 minecraft:red_terracotta
setblock 509 253 490 minecraft:terracotta
fill 509 253 491 509 254 491 minecraft:red_terracotta
setblock 509 253 495 minecraft:terracotta
fill 509 253 496 509 256 496 minecraft:red_terracotta
setblock 509 253 499 minecraft:red_terracotta
setblock 510 253 464 minecraft:terracotta
fill 510 253 466 510 253 468 minecraft:red_terracotta
setblock 510 253 469 minecraft:terracotta
fill 510 253 470 510 253 473 minecraft:red_terracotta
setblock 510 253 474 minecraft:terracotta
fill 510 253 475 510 256 475 minecraft:red_terracotta
setblock 510 253 479 minecraft:terracotta
fill 510 253 480 510 256 480 minecraft:red_terracotta
setblock 510 253 484 minecraft:terracotta
fill 510 253 485 510 256 485 minecraft:red_terracotta
setblock 510 253 489 minecraft:terracotta
fill 510 253 490 510 256 490 minecraft:red_terracotta
setblock 510 253 494 minecraft:terracotta
fill 510 253 495 510 256 495 minecraft:red_terracotta
setblock 510 253 498 minecraft:red_terracotta
setblock 510 253 499 minecraft:terracotta
fill 510 253 500 510 256 500 minecraft:red_terracotta
setblock 510 253 504 minecraft:terracotta
fill 511 253 464 511 256 464 minecraft:red_terracotta
setblock 511 253 468 minecraft:terracotta
fill 511 253 469 511 256 469 minecraft:red_terracotta
setblock 511 253 473 minecraft:terracotta
fill 511 253 474 511 256 474 minecraft:red_terracotta
setblock 511 253 478 minecraft:terracotta
fill 511 253 479 511 256 479 minecraft:red_terracotta
setblock 511 253 483 minecraft:terracotta
fill 511 253 484 511 256 484 minecraft:red_terracotta
setblock 511 253 488 minecraft:terracotta
fill 511 253 489 511 256 489 minecraft:red_terracotta
setblock 511 253 493 minecraft:terracotta
fill 511 253 494 511 256 494 minecraft:red_terracotta
setblock 511 253 498 minecraft:terracotta
fill 511 253 499 511 256 499 minecraft:red_terracotta
setblock 511 253 503 minecraft:terracotta
fill 511 253 504 511 256 504 minecraft:red_terracotta
fill 471 254 464 472 254 465 minecraft:red_terracotta
setblock 471 254 467 minecraft:terracotta
fill 471 254 468 471 254 471 minecraft:red_terracotta
setblock 471 254 472 minecraft:terracotta
fill 471 254 473 471 257 473 minecraft:red_terracotta
setblock 471 254 477 minecraft:terracotta
fill 471 254 478 471 257 478 minecraft:red_terracotta
setblock 471 254 482 minecraft:terracotta
fill 471 254 483 471 257 483 minecraft:red_terracotta
setblock 471 254 487 minecraft:terracotta
fill 471 254 488 471 255 488 minecraft:red_terracotta
setblock 471 254 492 minecraft:terracotta
fill 471 254 493 471 256 493 minecraft:red_terracotta
setblock 471 254 497 minecraft:terracotta
fill 471 254 498 471 257 498 minecraft:red_terracotta
setblock 471 254 502 minecraft:terracotta
fill 471 254 503 471 257 503 minecraft:red_terracotta
setblock 472 254 466 minecraft:terracotta
fill 472 254 467 472 256 467 minecraft:red_terracotta
setblock 472 254 471 minecraft:terracotta
fill 472 254 472 472 257 472 minecraft:red_terracotta
setblock 472 254 476 minecraft:terracotta
fill 472 254 477 472 257 477 minecraft:red_terracotta
setblock 472 254 481 minecraft:terracotta
fill 472 254 482 472 255 482 minecraft:red_terracotta
setblock 472 254 492 minecraft:red_terracotta
setblock 472 254 496 minecraft:terracotta
fill 472 254 497 472 256 497 minecraft:red_terracotta
setblock 472 254 501 minecraft:terracotta
fill 472 254 502 472 256 502 minecraft:red_terracotta
setblock 473 254 464 minecraft:red_terracotta
setblock 473 254 465 minecraft:terracotta
setblock 473 254 466 minecraft:light[level=14]
setblock 473 254 470 minecraft:terracotta
fill 473 254 471 473 255 471 minecraft:red_terracotta
setblock 473 254 475 minecraft:terracotta
fill 473 254 476 473 256 476 minecraft:red_terracotta
setblock 473 254 482 minecraft:light[level=14]
setblock 473 254 490 minecraft:light[level=14]
setblock 473 254 498 minecraft:light[level=14]
setblock 474 254 464 minecraft:terracotta
setblock 474 254 465 minecraft:red_terracotta
setblock 474 254 474 minecraft:terracotta
setblock 474 254 504 minecraft:terracotta
fill 475 254 464 478 254 464 minecraft:red_terracotta
fill 475 254 504 475 257 504 minecraft:red_terracotta
setblock 481 254 466 minecraft:light[level=14]
setblock 481 254 474 minecraft:light[level=14]
setblock 481 254 482 minecraft:light[level=14]
setblock 481 254 490 minecraft:light[level=14]
setblock 481 254 498 minecraft:light[level=14]
fill 481 254 504 483 254 504 minecraft:red_terracotta
fill 482 254 464 483 254 464 minecraft:red_terracotta
fill 483 254 503 484 254 503 minecraft:red_terracotta
setblock 484 254 464 minecraft:terracotta
setblock 484 254 504 minecraft:terracotta
fill 485 254 464 485 257 464 minecraft:red_terracotta
setblock 485 254 502 minecraft:red_terracotta
setblock 485 254 503 minecraft:terracotta
fill 485 254 504 488 254 504 minecraft:red_terracotta
setblock 486 254 502 minecraft:terracotta
fill 486 254 503 486 257 503 minecraft:red_terracotta
setblock 487 254 501 minecraft:terracotta
fill 487 254 502 487 257 502 minecraft:red_terracotta
setblock 488 254 465 minecraft:terracotta
fill 488 254 501 488 257 501 minecraft:red_terracotta
setblock 489 254 464 minecraft:terracotta
setblock 489 254 465 minecraft:red_terracotta
setblock 489 254 466 minecraft:light[level=14]
setblock 489 254 474 minecraft:light[level=14]
setblock 489 254 482 minecraft:light[level=14]
setblock 489 254 490 minecraft:light[level=14]
setblock 489 254 498 minecraft:light[level=14]
setblock 489 254 504 minecraft:terracotta
fill 490 254 464 490 257 464 minecraft:red_terracotta
fill 490 254 501 491 254 501 minecraft:red_terracotta
setblock 490 254 503 minecraft:terracotta
fill 490 254 504 490 257 504 minecraft:red_terracotta
setblock 491 254 502 minecraft:terracotta
fill 491 254 503 491 257 503 minecraft:red_terracotta
setblock 492 254 501 minecraft:terracotta
fill 492 254 502 492 257 502 minecraft:red_terracotta
setblock 494 254 504 minecraft:terracotta
setblock 495 254 503 minecraft:terracotta
fill 495 254 504 495 256 504 minecraft:red_terracotta
setblock 497 254 466 minecraft:light[level=14]
setblock 497 254 474 minecraft:light[level=14]
setblock 497 254 482 minecraft:light[level=14]
setblock 497 254 490 minecraft:light[level=14]
setblock 497 254 498 minecraft:light[level=14]
setblock 505 254 466 minecraft:light[level=14]
setblock 505 254 474 minecraft:light[level=14]
setblock 505 254 482 minecraft:light[level=14]
setblock 505 254 490 minecraft:light[level=14]
setblock 505 254 498 minecraft:light[level=14]
fill 507 254 504 508 254 504 minecraft:red_terracotta
setblock 508 254 464 minecraft:red_terracotta
fill 508 254 473 508 254 474 minecraft:red_terracotta
setblock 508 254 475 minecraft:terracotta
fill 508 254 476 508 254 479 minecraft:red_terracotta
setblock 509 254 464 minecraft:terracotta
fill 509 254 470 509 254 473 minecraft:red_terracotta
setblock 509 254 474 minecraft:terracotta
fill 509 254 475 509 257 475 minecraft:red_terracotta
fill 509 254 477 509 254 478 minecraft:red_terracotta
setblock 509 254 479 minecraft:terracotta
fill 509 254 480 509 254 483 minecraft:red_terracotta
setblock 509 254 484 minecraft:terracotta
setblock 509 254 489 minecraft:terracotta
setblock 509 254 490 minecraft:red_terracotta
setblock 509 254 494 minecraft:terracotta
fill 509 254 495 509 256 495 minecraft:red_terracotta
setblock 509 254 499 minecraft:terracotta
setblock 509 254 504 minecraft:terracotta
fill 510 254 464 510 257 464 minecraft:red_terracotta
setblock 510 254 467 minecraft:red_terracotta
setblock 510 254 468 minecraft:terracotta
fill 510 254 469 510 254 472 minecraft:red_terracotta
setblock 510 254 473 minecraft:terracotta
fill 510 254 474 510 257 474 minecraft:red_terracotta
setblock 510 254 477 minecraft:red_terracotta
setblock 510 254 478 minecraft:terracotta
fill 510 254 479 510 257 479 minecraft:red_terracotta
setblock 510 254 483 minecraft:terracotta
fill 510 254 484 510 257 484 minecraft:red_terracotta
setblock 510 254 488 minecraft:terracotta
fill 510 254 489 510 256 489 minecraft:red_terracotta
setblock 510 254 493 minecraft:terracotta
fill 510 254 494 510 257 494 minecraft:red_terracotta
setblock 510 254 498 minecraft:terracotta
fill 510 254 499 510 257 499 minecraft:red_terracotta
setblock 510 254 502 minecraft:red_terracotta
fill 510 254 504 510 257 504 minecraft:red_terracotta
setblock 511 254 467 minecraft:terracotta
fill 511 254 468 511 257 468 minecraft:red_terracotta
setblock 511 254 472 minecraft:terracotta
fill 511 254 473 511 257 473 minecraft:red_terracotta
setblock 511 254 477 minecraft:terracotta
fill 511 254 478 511 257 478 minecraft:red_terracotta
setblock 511 254 482 minecraft:terracotta
fill 511 254 483 511 257 483 minecraft:red_terracotta
setblock 511 254 487 minecraft:terracotta
fill 511 254 488 511 257 488 minecraft:red_terracotta
setblock 511 254 492 minecraft:terracotta
fill 511 254 493 511 257 493 minecraft:red_terracotta
setblock 511 254 497 minecraft:terracotta
fill 511 254 498 511 257 498 minecraft:red_terracotta
setblock 511 254 502 minecraft:terracotta
fill 511 254 503 511 257 503 minecraft:red_terracotta
fill 471 255 464 471 255 465 minecraft:red_terracotta
setblock 471 255 466 minecraft:terracotta
fill 471 255 467 471 255 470 minecraft:red_terracotta
setblock 471 255 471 minecraft:terracotta
fill 471 255 472 471 258 472 minecraft:red_terracotta
setblock 471 255 476 minecraft:terracotta
fill 471 255 477 471 258 477 minecraft:red_terracotta
setblock 471 255 481 minecraft:terracotta
fill 471 255 482 471 258 482 minecraft:red_terracotta
setblock 471 255 486 minecraft:terracotta
setblock 471 255 487 minecraft:red_terracotta
setblock 471 255 491 minecraft:terracotta
fill 471 255 492 471 256 492 minecraft:red_terracotta
setblock 471 255 496 minecraft:terracotta
fill 471 255 497 471 258 497 minecraft:red_terracotta
setblock 471 255 500 minecraft:red_terracotta
setblock 471 255 501 minecraft:terracotta
fill 471 255 502 471 258 502 minecraft:red_terracotta
setblock 472 255 464 minecraft:red_terracotta
setblock 472 255 465 minecraft:terracotta
fill 472 255 466 472 256 466 minecraft:red_terracotta
setblock 472 255 470 minecraft:terracotta
fill 472 255 471 472 257 471 minecraft:red_terracotta
setblock 472 255 475 minecraft:terracotta
fill 472 255 476 472 258 476 minecraft:red_terracotta
setblock 472 255 480 minecraft:terracotta
fill 472 255 481 472 256 481 minecraft:red_terracotta
setblock 472 255 495 minecraft:terracotta
fill 472 255 496 472 256 496 minecraft:red_terracotta
setblock 472 255 500 minecraft:terracotta
fill 472 255 501 472 257 501 minecraft:red_terracotta
setblock 473 255 464 minecraft:terracotta
setblock 473 255 465 minecraft:red_terracotta
setblock 473 255 470 minecraft:red_terracotta
setblock 473 255 474 minecraft:terracotta
fill 473 255 475 473 256 475 minecraft:red_terracotta
setblock 473 255 504 minecraft:terracotta
fill 474 255 464 476 255 464 minecraft:red_terracotta
fill 474 255 504 474 258 504 minecraft:red_terracotta
fill 480 255 504 482 255 504 minecraft:red_terracotta
setblock 482 255 464 minecraft:red_terracotta
setblock 483 255 464 minecraft:terracotta
setblock 483 255 503 minecraft:red_terracotta
setblock 483 255 504 minecraft:terracotta
fill 484 255 464 484 258 464 minecraft:red_terracotta
setblock 484 255 503 minecraft:terracotta
fill 484 255 504 487 255 504 minecraft:red_terracotta
setblock 485 255 502 minecraft:terracotta
fill 485 255 503 485 258 503 minecraft:red_terracotta
fill 486 255 502 486 258 502 minecraft:red_terracotta
fill 487 255 501 487 258 501 minecraft:red_terracotta
setblock 488 255 464 minecraft:terracotta
setblock 488 255 504 minecraft:terracotta
fill 489 255 464 489 258 464 minecraft:red_terracotta
setblock 489 255 503 minecraft:terracotta
fill 489 255 504 489 258 504 minecraft:red_terracotta
setblock 490 255 501 minecraft:red_terracotta
setblock 490 255 502 minecraft:terracotta
fill 490 255 503 490 258 503 minecraft:red_terracotta
setblock 491 255 501 minecraft:terracotta
fill 491 255 502 491 258 502 minecraft:red_terracotta
setblock 493 255 504 minecraft:terracotta
setblock 494 255 503 minecraft:terracotta
fill 494 255 504 494 258 504 minecraft:red_terracotta
setblock 507 255 504 minecraft:red_terracotta
setblock 508 255 473 minecraft:red_terracotta
setblock 508 255 474 minecraft:terracotta
fill 508 255 475 508 255 478 minecraft:red_terracotta
setblock 508 255 479 minecraft:terracotta
fill 508 255 480 509 257 480 minecraft:red_terracotta
setblock 508 255 504 minecraft:terracotta
fill 509 255 464 509 258 464 minecraft:red_terracotta
fill 509 255 470 509 255 472 minecraft:red_terracotta
setblock 509 255 473 minecraft:terracotta
fill 509 255 474 509 258 474 minecraft:red_terracotta
setblock 509 255 477 minecraft:red_terracotta
setblock 509 255 478 minecraft:terracotta
fill 509 255 479 509 258 479 minecraft:red_terracotta
fill 509 255 481 509 255 482 minecraft:red_terracotta
setblock 509 255 483 minecraft:terracotta
setblock 509 255 484 minecraft:red_terracotta
setblock 509 255 493 minecraft:terracotta
setblock 509 255 494 minecraft:red_terracotta
setblock 509 255 497 minecraft:red_terracotta
setblock 509 255 498 minecraft:terracotta
setblock 509 255 499 minecraft:red_terracotta
fill 509 255 504 509 258 504 minecraft:red_terracotta
fill 510 255 468 510 255 471 minecraft:red_terracotta
setblock 510 255 472 minecraft:terracotta
fill 510 255 473 510 258 473 minecraft:red_terracotta
setblock 510 255 477 minecraft:terracotta
fill 510 255 478 510 258 478 minecraft:red_terracotta
setblock 510 255 482 minecraft:terracotta
fill 510 255 483 510 258 483 minecraft:red_terracotta
setblock 510 255 487 minecraft:terracotta
fill 510 255 488 510 256 488 minecraft:red_terracotta
setblock 510 255 492 minecraft:terracotta
fill 510 255 493 510 256 493 minecraft:red_terracotta
setblock 510 255 497 minecraft:terracotta
fill 510 255 498 510 258 498 minecraft:red_terracotta
setblock 510 255 502 minecraft:terracotta
setblock 511 255 466 minecraft:terracotta
fill 511 255 467 511 258 467 minecraft:red_terracotta
setblock 511 255 471 minecraft:terracotta
fill 511 255 472 511 258 472 minecraft:red_terracotta
setblock 511 255 476 minecraft:terracotta
fill 511 255 477 511 258 477 minecraft:red_terracotta
setblock 511 255 481 minecraft:terracotta
fill 511 255 482 511 258 482 minecraft:red_terracotta
setblock 511 255 486 minecraft:terracotta
fill 511 255 487 511 258 487 minecraft:red_terracotta
setblock 511 255 491 minecraft:terracotta
fill 511 255 492 511 257 492 minecraft:red_terracotta
setblock 511 255 496 minecraft:terracotta
fill 511 255 497 511 258 497 minecraft:red_terracotta
setblock 511 255 501 minecraft:terracotta
fill 511 255 502 511 258 502 minecraft:red_terracotta
setblock 471 256 464 minecraft:red_terracotta
setblock 471 256 465 minecraft:terracotta
fill 471 256 466 471 256 469 minecraft:red_terracotta
setblock 471 256 470 minecraft:terracotta
fill 471 256 471 471 259 471 minecraft:red_terracotta
setblock 471 256 475 minecraft:terracotta
fill 471 256 476 471 259 476 minecraft:red_terracotta
setblock 471 256 480 minecraft:terracotta
fill 471 256 481 471 259 481 minecraft:red_terracotta
setblock 471 256 495 minecraft:terracotta
fill 471 256 496 471 258 496 minecraft:red_terracotta
setblock 471 256 500 minecraft:terracotta
fill 471 256 501 471 259 501 minecraft:red_terracotta
setblock 472 256 464 minecraft:terracotta
setblock 472 256 469 minecraft:terracotta
fill 472 256 470 472 257 470 minecraft:red_terracotta
setblock 472 256 474 minecraft:terracotta
fill 472 256 475 472 259 475 minecraft:red_terracotta
setblock 472 256 479 minecraft:terracotta
fill 472 256 480 472 258 480 minecraft:red_terracotta
setblock 472 256 499 minecraft:terracotta
fill 472 256 500 472 257 500 minecraft:red_terracotta
setblock 472 256 504 minecraft:terracotta
fill 473 256 464 475 256 464 minecraft:red_terracotta
setblock 473 256 473 minecraft:terracotta
setblock 473 256 474 minecraft:red_terracotta
fill 473 256 504 473 259 504 minecraft:red_terracotta
fill 479 256 504 481 256 504 minecraft:red_terracotta
setblock 482 256 503 minecraft:red_terracotta
setblock 482 256 504 minecraft:terracotta
fill 483 256 464 483 259 464 minecraft:red_terracotta
setblock 483 256 503 minecraft:terracotta
fill 483 256 504 486 256 504 minecraft:red_terracotta
setblock 484 256 502 minecraft:terracotta
fill 484 256 503 484 259 503 minecraft:red_terracotta
fill 485 256 502 485 259 502 minecraft:red_terracotta
fill 486 256 501 486 259 501 minecraft:red_terracotta
setblock 487 256 464 minecraft:terracotta
setblock 487 256 504 minecraft:terracotta
fill 488 256 464 488 259 464 minecraft:red_terracotta
setblock 488 256 503 minecraft:terracotta
fill 488 256 504 488 259 504 minecraft:red_terracotta
setblock 489 256 502 minecraft:terracotta
fill 489 256 503 489 259 503 minecraft:red_terracotta
setblock 490 256 501 minecraft:terracotta
fill 490 256 502 490 259 502 minecraft:red_terracotta
setblock 491 256 501 minecraft:red_terracotta
setblock 492 256 504 minecraft:terracotta
setblock 493 256 503 minecraft:terracotta
fill 493 256 504 493 259 504 minecraft:red_terracotta
setblock 494 256 503 minecraft:red_terracotta
setblock 506 256 504 minecraft:red_terracotta
setblock 507 256 504 minecraft:terracotta
fill 508 256 474 508 256 477 minecraft:red_terracotta
setblock 508 256 478 minecraft:terracotta
fill 508 256 479 508 259 479 minecraft:red_terracotta
fill 508 256 504 508 259 504 minecraft:red_terracotta
setblock 509 256 471 minecraft:red_terracotta
setblock 509 256 472 minecraft:terracotta
fill 509 256 473 509 258 473 minecraft:red_terracotta
setblock 509 256 476 minecraft:red_terracotta
setblock 509 256 477 minecraft:terracotta
fill 509 256 478 509 259 478 minecraft:red_terracotta
setblock 509 256 481 minecraft:red_terracotta
setblock 509 256 482 minecraft:terracotta
fill 509 256 483 509 259 483 minecraft:red_terracotta
setblock 509 256 497 minecraft:terracotta
setblock 509 256 498 minecraft:red_terracotta
fill 510 256 469 510 256 470 minecraft:red_terracotta
setblock 510 256 471 minecraft:terracotta
fill 510 256 472 510 259 472 minecraft:red_terracotta
setblock 510 256 476 minecraft:terracotta
fill 510 256 477 510 259 477 minecraft:red_terracotta
setblock 510 256 481 minecraft:terracotta
fill 510 256 482 510 259 482 minecraft:red_terracotta
setblock 510 256 486 minecraft:terracotta
setblock 510 256 487 minecraft:red_terracotta
setblock 510 256 491 minecraft:terracotta
setblock 510 256 492 minecraft:red_terracotta
setblock 510 256 496 minecraft:terracotta
fill 510 256 497 510 258 497 minecraft:red_terracotta
setblock 510 256 501 minecraft:terracotta
setblock 511 256 465 minecraft:terracotta
fill 511 256 466 511 257 466 minecraft:red_terracotta
setblock 511 256 470 minecraft:terracotta
fill 511 256 471 511 259 471 minecraft:red_terracotta
setblock 511 256 475 minecraft:terracotta
fill 511 256 476 511 259 476 minecraft:red_terracotta
setblock 511 256 480 minecraft:terracotta
fill 511 256 481 511 259 481 minecraft:red_terracotta
setblock 511 256 485 minecraft:terracotta
fill 511 256 486 511 259 486 minecraft:red_terracotta
setblock 511 256 490 minecraft:terracotta
fill 511 256 491 511 257 491 minecraft:red_terracotta
setblock 511 256 495 minecraft:terracotta
fill 511 256 496 511 259 496 minecraft:red_terracotta
setblock 511 256 500 minecraft:terracotta
fill 511 256 501 511 259 501 minecraft:red_terracotta
setblock 471 257 464 minecraft:terracotta
fill 471 257 465 471 257 468 minecraft:red_terracotta
setblock 471 257 469 minecraft:terracotta
fill 471 257 470 471 260 470 minecraft:red_terracotta
setblock 471 257 474 minecraft:terracotta
fill 471 257 475 471 260 475 minecraft:red_terracotta
setblock 471 257 479 minecraft:terracotta
fill 471 257 480 471 260 480 minecraft:red_terracotta
setblock 471 257 484 minecraft:terracotta
setblock 471 257 494 minecraft:terracotta
setblock 471 257 495 minecraft:red_terracotta
setblock 471 257 499 minecraft:terracotta
fill 471 257 500 471 260 500 minecraft:red_terracotta
setblock 471 257 504 minecraft:terracotta
fill 472 257 464 474 257 464 minecraft:red_terracotta
setblock 472 257 469 minecraft:red_terracotta
setblock 472 257 473 minecraft:terracotta
fill 472 257 474 472 258 474 minecraft:red_terracotta
setblock 472 257 478 minecraft:terracotta
fill 472 257 479 472 259 479 minecraft:red_terracotta
setblock 472 257 499 minecraft:red_terracotta
fill 472 257 504 472 260 504 minecraft:red_terracotta
fill 479 257 504 480 257 504 minecraft:red_terracotta
setblock 481 257 504 minecraft:terracotta
setblock 482 257 503 minecraft:terracotta
fill 482 257 504 485 257 504 minecraft:red_terracotta
fill 483 257 503 483 260 503 minecraft:red_terracotta
fill 484 257 502 484 260 502 minecraft:red_terracotta
setblock 486 257 464 minecraft:terracotta
setblock 486 257 504 minecraft:terracotta
fill 487 257 464 487 260 464 minecraft:red_terracotta
setblock 487 257 503 minecraft:terracotta
fill 487 257 504 487 260 504 minecraft:red_terracotta
setblock 488 257 502 minecraft:terracotta
fill 488 257 503 488 260 503 minecraft:red_terracotta
setblock 489 257 501 minecraft:terracotta
fill 489 257 502 489 260 502 minecraft:red_terracotta
setblock 490 257 501 minecraft:red_terracotta
setblock 491 257 504 minecraft:terracotta
setblock 492 257 503 minecraft:terracotta
fill 492 257 504 492 260 504 minecraft:red_terracotta
fill 493 257 503 493 258 503 minecraft:red_terracotta
setblock 506 257 504 minecraft:terracotta
fill 507 257 504 507 260 504 minecraft:red_terracotta
fill 508 257 475 508 257 476 minecraft:red_terracotta
setblock 508 257 477 minecraft:terracotta
fill 508 257 478 508 260 478 minecraft:red_terracotta
setblock 509 257 472 minecraft:red_terracotta
setblock 509 257 476 minecraft:terracotta
fill 509 257 477 509 260 477 minecraft:red_terracotta
setblock 509 257 481 minecraft:terracotta
fill 509 257 482 509 260 482 minecraft:red_terracotta
setblock 510 257 470 minecraft:terracotta
fill 510 257 471 510 258 471 minecraft:red_terracotta
setblock 510 257 475 minecraft:terracotta
fill 510 257 476 510 260 476 minecraft:red_terracotta
setblock 510 257 480 minecraft:terracotta
fill 510 257 481 510 260 481 minecraft:red_terracotta
setblock 510 257 485 minecraft:terracotta
setblock 510 257 495 minecraft:terracotta
setblock 510 257 496 minecraft:red_terracotta
setblock 510 257 500 minecraft:terracotta
setblock 510 257 501 minecraft:red_terracotta
setblock 511 257 465 minecraft:red_terracotta
setblock 511 257 469 minecraft:terracotta
fill 511 257 470 511 260 470 minecraft:red_terracotta
setblock 511 257 474 minecraft:terracotta
fill 511 257 475 511 260 475 minecraft:red_terracotta
setblock 511 257 479 minecraft:terracotta
fill 511 257 480 511 260 480 minecraft:red_terracotta
setblock 511 257 484 minecraft:terracotta
fill 511 257 485 511 260 485 minecraft:red_terracotta
setblock 511 257 489 minecraft:terracotta
setblock 511 257 490 minecraft:red_terracotta
setblock 511 257 494 minecraft:terracotta
fill 511 257 495 511 258 495 minecraft:red_terracotta
setblock 511 257 499 minecraft:terracotta
fill 511 257 500 511 260 500 minecraft:red_terracotta
setblock 511 257 504 minecraft:terracotta
fill 471 258 464 471 258 467 minecraft:red_terracotta
setblock 471 258 468 minecraft:terracotta
fill 471 258 469 471 260 469 minecraft:red_terracotta
setblock 471 258 473 minecraft:terracotta
fill 471 258 474 471 261 474 minecraft:red_terracotta
setblock 471 258 478 minecraft:terracotta
fill 471 258 479 471 261 479 minecraft:red_terracotta
setblock 471 258 483 minecraft:terracotta
setblock 471 258 498 minecraft:terracotta
fill 471 258 499 471 261 499 minecraft:red_terracotta
setblock 471 258 503 minecraft:terracotta
fill 471 258 504 471 261 504 minecraft:red_terracotta
fill 472 258 464 473 259 464 minecraft:red_terracotta
setblock 472 258 472 minecraft:terracotta
setblock 472 258 473 minecraft:red_terracotta
setblock 472 258 477 minecraft:terracotta
fill 472 258 478 472 259 478 minecraft:red_terracotta
setblock 475 258 504 minecraft:terracotta
fill 477 258 504 479 258 504 minecraft:red_terracotta
setblock 480 258 504 minecraft:terracotta
setblock 481 258 503 minecraft:terracotta
fill 481 258 504 484 258 504 minecraft:red_terracotta
fill 482 258 503 482 261 503 minecraft:red_terracotta
fill 483 258 502 483 261 502 minecraft:red_terracotta
setblock 485 258 464 minecraft:terracotta
fill 485 258 501 485 260 501 minecraft:red_terracotta
setblock 485 258 504 minecraft:terracotta
fill 486 258 464 486 261 464 minecraft:red_terracotta
setblock 486 258 503 minecraft:terracotta
fill 486 258 504 486 261 504 minecraft:red_terracotta
setblock 487 258 502 minecraft:terracotta
fill 487 258 503 487 261 503 minecraft:red_terracotta
setblock 488 258 501 minecraft:terracotta
fill 488 258 502 488 261 502 minecraft:red_terracotta
fill 489 258 501 489 259 501 minecraft:red_terracotta
setblock 490 258 504 minecraft:terracotta
setblock 491 258 503 minecraft:terracotta
fill 491 258 504 491 261 504 minecraft:red_terracotta
fill 492 258 503 492 261 503 minecraft:red_terracotta
setblock 505 258 504 minecraft:terracotta
fill 506 258 504 506 261 504 minecraft:red_terracotta
fill 508 258 464 508 259 464 minecraft:red_terracotta
setblock 508 258 476 minecraft:terracotta
fill 508 258 477 508 260 477 minecraft:red_terracotta
setblock 508 258 480 minecraft:red_terracotta
setblock 509 258 475 minecraft:terracotta
fill 509 258 476 509 261 476 minecraft:red_terracotta
setblock 509 258 480 minecraft:terracotta
fill 509 258 481 509 261 481 minecraft:red_terracotta
setblock 510 258 464 minecraft:terracotta
setblock 510 258 474 minecraft:terracotta
fill 510 258 475 510 261 475 minecraft:red_terracotta
setblock 510 258 479 minecraft:terracotta
fill 510 258 480 510 261 480 minecraft:red_terracotta
setblock 510 258 484 minecraft:terracotta
setblock 510 258 485 minecraft:red_terracotta
setblock 510 258 499 minecraft:terracotta
setblock 510 258 500 minecraft:red_terracotta
setblock 510 258 504 minecraft:terracotta
setblock 511 258 468 minecraft:terracotta
fill 511 258 469 511 259 469 minecraft:red_terracotta
setblock 511 258 473 minecraft:terracotta
fill 511 258 474 511 261 474 minecraft:red_terracotta
setblock 511 258 478 minecraft:terracotta
fill 511 258 479 511 261 479 minecraft:red_terracotta
setblock 511 258 483 minecraft:terracotta
fill 511 258 484 511 261 484 minecraft:red_terracotta
setblock 511 258 494 minecraft:red_terracotta
setblock 511 258 498 minecraft:terracotta
fill 511 258 499 511 260 499 minecraft:red_terracotta
setblock 511 258 503 minecraft:terracotta
fill 471 259 464 471 259 466 minecraft:red_terracotta
setblock 471 259 467 minecraft:terracotta
fill 471 259 468 471 262 468 minecraft:red_terracotta
setblock 471 259 472 minecraft:terracotta
fill 471 259 473 471 262 473 minecraft:red_terracotta
setblock 471 259 477 minecraft:terracotta
fill 471 259 478 471 262 478 minecraft:red_terracotta
setblock 471 259 482 minecraft:terracotta
fill 471 259 483 471 262 483 minecraft:red_terracotta
setblock 471 259 497 minecraft:terracotta
fill 471 259 498 471 261 498 minecraft:red_terracotta
setblock 471 259 502 minecraft:terracotta
fill 471 259 503 471 262 503 minecraft:red_terracotta
setblock 472 259 476 minecraft:terracotta
setblock 472 259 477 minecraft:red_terracotta
setblock 474 259 504 minecraft:terracotta
fill 475 259 504 478 259 504 minecraft:red_terracotta
setblock 479 259 504 minecraft:terracotta
setblock 480 259 503 minecraft:terracotta
fill 480 259 504 483 259 504 minecraft:red_terracotta
fill 481 259 503 481 262 503 minecraft:red_terracotta
fill 482 259 464 482 260 464 minecraft:red_terracotta
fill 482 259 502 482 262 502 minecraft:red_terracotta
setblock 484 259 464 minecraft:terracotta
setblock 484 259 504 minecraft:terracotta
fill 485 259 464 485 262 464 minecraft:red_terracotta
setblock 485 259 503 minecraft:terracotta
fill 485 259 504 485 262 504 minecraft:red_terracotta
setblock 486 259 502 minecraft:terracotta
fill 486 259 503 486 262 503 minecraft:red_terracotta
setblock 487 259 501 minecraft:terracotta
fill 487 259 502 487 262 502 minecraft:red_terracotta
fill 488 259 501 488 262 501 minecraft:red_terracotta
setblock 489 259 464 minecraft:terracotta
setblock 489 259 504 minecraft:terracotta
setblock 490 259 503 minecraft:terracotta
fill 490 259 504 490 262 504 minecraft:red_terracotta
setblock 491 259 502 minecraft:terracotta
fill 491 259 503 491 262 503 minecraft:red_terracotta
setblock 494 259 504 minecraft:terracotta
setblock 504 259 504 minecraft:terracotta
fill 505 259 504 505 262 504 minecraft:red_terracotta
fill 507 259 464 507 260 464 minecraft:red_terracotta
setblock 508 259 476 minecraft:red_terracotta
setblock 508 259 480 minecraft:terracotta
setblock 509 259 464 minecraft:terracotta
setblock 509 259 474 minecraft:terracotta
fill 509 259 475 509 261 475 minecraft:red_terracotta
setblock 509 259 479 minecraft:terracotta
fill 509 259 480 509 262 480 minecraft:red_terracotta
setblock 509 259 504 minecraft:terracotta
fill 510 259 464 510 262 464 minecraft:red_terracotta
setblock 510 259 473 minecraft:terracotta
fill 510 259 474 510 262 474 minecraft:red_terracotta
setblock 510 259 478 minecraft:terracotta
fill 510 259 479 510 262 479 minecraft:red_terracotta
setblock 510 259 483 minecraft:terracotta
fill 510 259 484 510 262 484 minecraft:red_terracotta
fill 510 259 504 510 262 504 minecraft:red_terracotta
setblock 511 259 472 minecraft:terracotta
fill 511 259 473 511 262 473 minecraft:red_terracotta
setblock 511 259 477 minecraft:terracotta
fill 511 259 478 511 262 478 minecraft:red_terracotta
setblock 511 259 482 minecraft:terracotta
fill 511 259 483 511 262 483 minecraft:red_terracotta
setblock 511 259 497 minecraft:terracotta
fill 511 259 498 511 260 498 minecraft:red_terracotta
setblock 511 259 502 minecraft:terracotta
fill 511 259 503 511 262 503 minecraft:red_terracotta
fill 471 260 464 471 260 465 minecraft:red_terracotta
setblock 471 260 466 minecraft:terracotta
fill 471 260 467 471 263 467 minecraft:red_terracotta
setblock 471 260 471 minecraft:terracotta
fill 471 260 472 471 261 472 minecraft:red_terracotta
setblock 471 260 476 minecraft:terracotta
fill 471 260 477 471 263 477 minecraft:red_terracotta
setblock 471 260 481 minecraft:terracotta
fill 471 260 482 471 263 482 minecraft:red_terracotta
setblock 471 260 501 minecraft:terracotta
fill 471 260 502 471 263 502 minecraft:red_terracotta
setblock 472 260 464 minecraft:red_terracotta
setblock 473 260 464 minecraft:terracotta
setblock 473 260 504 minecraft:terracotta
fill 474 260 504 477 260 504 minecraft:red_terracotta
setblock 478 260 504 minecraft:terracotta
setblock 479 260 503 minecraft:terracotta
fill 479 260 504 482 260 504 minecraft:red_terracotta
fill 480 260 464 481 261 464 minecraft:red_terracotta
fill 480 260 503 480 263 503 minecraft:red_terracotta
setblock 483 260 464 minecraft:terracotta
setblock 483 260 504 minecraft:terracotta
fill 484 260 464 484 263 464 minecraft:red_terracotta
fill 484 260 501 484 261 501 minecraft:red_terracotta
setblock 484 260 503 minecraft:terracotta
fill 484 260 504 484 263 504 minecraft:red_terracotta
setblock 485 260 502 minecraft:terracotta
fill 485 260 503 485 263 503 minecraft:red_terracotta
setblock 486 260 501 minecraft:terracotta
fill 486 260 502 486 263 502 minecraft:red_terracotta
fill 487 260 501 487 263 501 minecraft:red_terracotta
setblock 488 260 464 minecraft:terracotta
setblock 488 260 504 minecraft:terracotta
fill 489 260 464 489 263 464 minecraft:red_terracotta
setblock 489 260 503 minecraft:terracotta
fill 489 260 504 489 263 504 minecraft:red_terracotta
setblock 490 260 502 minecraft:terracotta
fill 490 260 503 490 263 503 minecraft:red_terracotta
setblock 493 260 504 minecraft:terracotta
setblock 503 260 504 minecraft:terracotta
fill 504 260 504 504 263 504 minecraft:red_terracotta
fill 506 260 464 506 261 464 minecraft:red_terracotta
setblock 508 260 464 minecraft:terracotta
setblock 508 260 479 minecraft:terracotta
fill 508 260 480 508 262 481 minecraft:red_terracotta
setblock 508 260 504 minecraft:terracotta
fill 509 260 464 509 263 464 minecraft:red_terracotta
setblock 509 260 474 minecraft:red_terracotta
setblock 509 260 478 minecraft:terracotta
fill 509 260 479 509 263 479 minecraft:red_terracotta
setblock 509 260 483 minecraft:terracotta
fill 509 260 504 509 263 504 minecraft:red_terracotta
setblock 510 260 472 minecraft:terracotta
fill 510 260 473 510 261 473 minecraft:red_terracotta
setblock 510 260 477 minecraft:terracotta
fill 510 260 478 510 263 478 minecraft:red_terracotta
setblock 510 260 482 minecraft:terracotta
fill 510 260 483 510 263 483 minecraft:red_terracotta
fill 511 260 464 511 261 464 minecraft:red_terracotta
setblock 511 260 471 minecraft:terracotta
fill 511 260 472 511 263 472 minecraft:red_terracotta
setblock 511 260 476 minecraft:terracotta
fill 511 260 477 511 263 477 minecraft:red_terracotta
setblock 511 260 481 minecraft:terracotta
fill 511 260 482 511 263 482 minecraft:red_terracotta
setblock 511 260 486 minecraft:terracotta
setblock 511 260 501 minecraft:terracotta
fill 511 260 502 511 263 502 minecraft:red_terracotta
fill 511 260 504 511 261 504 minecraft:red_terracotta
setblock 471 261 464 minecraft:red_terracotta
setblock 471 261 465 minecraft:terracotta
fill 471 261 466 471 264 466 minecraft:red_terracotta
setblock 471 261 471 minecraft:red_terracotta
setblock 471 261 475 minecraft:terracotta
fill 471 261 476 471 264 476 minecraft:red_terracotta
setblock 471 261 480 minecraft:terracotta
fill 471 261 481 471 264 481 minecraft:red_terracotta
setblock 471 261 500 minecraft:terracotta
fill 471 261 501 471 264 501 minecraft:red_terracotta
setblock 472 261 464 minecraft:terracotta
setblock 472 261 504 minecraft:terracotta
fill 473 261 464 474 263 464 minecraft:red_terracotta
fill 473 261 504 476 261 504 minecraft:red_terracotta
setblock 477 261 504 minecraft:terracotta
fill 478 261 464 479 263 464 minecraft:red_terracotta
setblock 478 261 503 minecraft:terracotta
fill 478 261 504 481 261 504 minecraft:red_terracotta
fill 479 261 503 479 264 503 minecraft:red_terracotta
fill 481 261 502 481 263 502 minecraft:red_terracotta
setblock 482 261 464 minecraft:terracotta
setblock 482 261 504 minecraft:terracotta
fill 483 261 464 483 264 464 minecraft:red_terracotta
fill 483 261 501 483 262 501 minecraft:red_terracotta
setblock 483 261 503 minecraft:terracotta
fill 483 261 504 483 264 504 minecraft:red_terracotta
setblock 484 261 502 minecraft:terracotta
fill 484 261 503 484 264 503 minecraft:red_terracotta
setblock 485 261 501 minecraft:terracotta
fill 485 261 502 485 264 502 minecraft:red_terracotta
fill 486 261 501 486 264 501 minecraft:red_terracotta
setblock 487 261 464 minecraft:terracotta
setblock 487 261 504 minecraft:terracotta
fill 488 261 464 488 264 464 minecraft:red_terracotta
setblock 488 261 503 minecraft:terracotta
fill 488 261 504 488 264 504 minecraft:red_terracotta
setblock 489 261 502 minecraft:terracotta
fill 489 261 503 489 264 503 minecraft:red_terracotta
fill 490 261 502 490 264 502 minecraft:red_terracotta
setblock 492 261 504 minecraft:terracotta
fill 493 261 504 494 263 504 minecraft:red_terracotta
setblock 501 261 504 minecraft:red_terracotta
setblock 502 261 504 minecraft:terracotta
fill 503 261 504 503 264 504 minecraft:red_terracotta
fill 504 261 464 505 262 464 minecraft:red_terracotta
fill 505 261 503 507 261 503 minecraft:red_terracotta
setblock 507 261 464 minecraft:terracotta
setblock 507 261 504 minecraft:terracotta
fill 508 261 464 508 264 464 minecraft:red_terracotta
setblock 508 261 478 minecraft:terracotta
fill 508 261 479 508 263 479 minecraft:red_terracotta
fill 508 261 504 508 264 504 minecraft:red_terracotta
setblock 509 261 477 minecraft:terracotta
fill 509 261 478 509 264 478 minecraft:red_terracotta
setblock 509 261 482 minecraft:terracotta
fill 509 261 483 509 264 483 minecraft:red_terracotta
setblock 510 261 476 minecraft:terracotta
fill 510 261 477 510 264 477 minecraft:red_terracotta
setblock 510 261 481 minecraft:terracotta
fill 510 261 482 510 264 482 minecraft:red_terracotta
setblock 511 261 465 minecraft:terracotta
setblock 511 261 470 minecraft:terracotta
fill 511 261 471 511 264 471 minecraft:red_terracotta
setblock 511 261 475 minecraft:terracotta
fill 511 261 476 511 264 476 minecraft:red_terracotta
setblock 511 261 480 minecraft:terracotta
fill 511 261 481 511 264 481 minecraft:red_terracotta
setblock 511 261 485 minecraft:terracotta
fill 511 261 486 511 264 486 minecraft:red_terracotta
setblock 511 261 500 minecraft:terracotta
fill 511 261 501 511 264 501 minecraft:red_terracotta
setblock 471 262 464 minecraft:terracotta
fill 471 262 465 471 265 465 minecraft:red_terracotta
setblock 471 262 474 minecraft:terracotta
fill 471 262 475 471 263 475 minecraft:red_terracotta
setblock 471 262 479 minecraft:terracotta
fill 471 262 480 471 265 480 minecraft:red_terracotta
setblock 471 262 499 minecraft:terracotta
fill 471 262 500 471 265 500 minecraft:red_terracotta
setblock 471 262 504 minecraft:terracotta
fill 472 262 464 472 265 464 minecraft:red_terracotta
setblock 472 262 503 minecraft:terracotta
fill 472 262 504 475 262 504 minecraft:red_terracotta
setblock 473 262 466 minecraft:light[level=14]
setblock 473 262 474 minecraft:light[level=14]
setblock 473 262 482 minecraft:light[level=14]
setblock 473 262 490 minecraft:light[level=14]
setblock 473 262 498 minecraft:light[level=14]
setblock 475 262 464 minecraft:red_terracotta
setblock 476 262 464 minecraft:terracotta
setblock 476 262 503 minecraft:red_terracotta
setblock 476 262 504 minecraft:terracotta
fill 477 262 464 477 265 464 minecraft:red_terracotta
setblock 477 262 503 minecraft:terracotta
fill 477 262 504 480 262 504 minecraft:red_terracotta
fill 478 262 503 478 265 503 minecraft:red_terracotta
setblock 480 262 464 minecraft:red_terracotta
fill 480 262 502 480 264 502 minecraft:red_terracotta
setblock 481 262 464 minecraft:terracotta
setblock 481 262 466 minecraft:light[level=14]
setblock 481 262 474 minecraft:light[level=14]
setblock 481 262 482 minecraft:light[level=14]
setblock 481 262 490 minecraft:light[level=14]
setblock 481 262 498 minecraft:light[level=14]
setblock 481 262 504 minecraft:terracotta
fill 482 262 464 482 265 464 minecraft:red_terracotta
setblock 482 262 503 minecraft:terracotta
fill 482 262 504 482 265 504 minecraft:red_terracotta
setblock 483 262 502 minecraft:terracotta
fill 483 262 503 483 265 503 minecraft:red_terracotta
setblock 484 262 465 minecraft:red_terracotta
setblock 484 262 501 minecraft:terracotta
fill 484 262 502 484 265 502 minecraft:red_terracotta
fill 485 262 501 485 265 501 minecraft:red_terracotta
setblock 486 262 464 minecraft:terracotta
setblock 486 262 504 minecraft:terracotta
fill 487 262 464 487 265 464 minecraft:red_terracotta
setblock 487 262 503 minecraft:terracotta
fill 487 262 504 487 265 504 minecraft:red_terracotta
setblock 488 262 502 minecraft:terracotta
fill 488 262 503 488 265 503 minecraft:red_terracotta
setblock 489 262 466 minecraft:light[level=14]
setblock 489 262 474 minecraft:light[level=14]
setblock 489 262 482 minecraft:light[level=14]
setblock 489 262 490 minecraft:light[level=14]
setblock 489 262 498 minecraft:light[level=14]
fill 489 262 502 489 265 502 minecraft:red_terracotta
setblock 491 262 504 minecraft:terracotta
setblock 492 262 503 minecraft:terracotta
fill 492 262 504 492 265 504 minecraft:red_terracotta
setblock 497 262 466 minecraft:light[level=14]
setblock 497 262 474 minecraft:light[level=14]
setblock 497 262 482 minecraft:light[level=14]
setblock 497 262 490 minecraft:light[level=14]
setblock 497 262 498 minecraft:light[level=14]
setblock 500 262 504 minecraft:red_terracotta
setblock 501 262 504 minecraft:terracotta
fill 502 262 464 503 264 464 minecraft:red_terracotta
fill 502 262 504 502 265 504 minecraft:red_terracotta
fill 503 262 503 506 262 503 minecraft:red_terracotta
setblock 505 262 466 minecraft:light[level=14]
setblock 505 262 474 minecraft:light[level=14]
setblock 505 262 482 minecraft:light[level=14]
setblock 505 262 490 minecraft:light[level=14]
setblock 505 262 498 minecraft:light[level=14]
setblock 506 262 464 minecraft:terracotta
setblock 506 262 504 minecraft:terracotta
fill 507 262 464 507 265 464 minecraft:red_terracotta
setblock 507 262 503 minecraft:terracotta
fill 507 262 504 507 265 504 minecraft:red_terracotta
setblock 508 262 478 minecraft:red_terracotta
fill 508 262 503 508 265 503 minecraft:red_terracotta
setblock 509 262 476 minecraft:terracotta
fill 509 262 477 509 264 477 minecraft:red_terracotta
setblock 509 262 481 minecraft:terracotta
fill 509 262 482 509 265 482 minecraft:red_terracotta
fill 510 262 473 510 273 473 minecraft:magma_block
setblock 510 262 475 minecraft:terracotta
fill 510 262 476 510 265 476 minecraft:red_terracotta
setblock 510 262 480 minecraft:terracotta
fill 510 262 481 510 265 481 minecraft:red_terracotta
setblock 510 262 485 minecraft:terracotta
setblock 511 262 464 minecraft:terracotta
fill 511 262 465 511 263 467 minecraft:red_terracotta
fill 511 262 470 511 265 470 minecraft:red_terracotta
setblock 511 262 474 minecraft:terracotta
fill 511 262 475 511 265 475 minecraft:red_terracotta
setblock 511 262 479 minecraft:terracotta
fill 511 262 480 511 265 480 minecraft:red_terracotta
setblock 511 262 484 minecraft:terracotta
fill 511 262 485 511 265 485 minecraft:red_terracotta
setblock 511 262 500 minecraft:red_terracotta
setblock 511 262 504 minecraft:terracotta
fill 471 263 464 471 266 464 minecraft:red_terracotta
setblock 471 263 468 minecraft:terracotta
setblock 471 263 478 minecraft:terracotta
fill 471 263 479 471 265 479 minecraft:red_terracotta
setblock 471 263 483 minecraft:terracotta
fill 471 263 499 471 265 499 minecraft:red_terracotta
setblock 471 263 503 minecraft:terracotta
fill 471 263 504 474 263 504 minecraft:red_terracotta
setblock 472 263 502 minecraft:terracotta
fill 472 263 503 475 263 503 minecraft:red_terracotta
setblock 475 263 464 minecraft:terracotta
setblock 475 263 504 minecraft:terracotta
fill 476 263 464 476 266 464 minecraft:red_terracotta
setblock 476 263 503 minecraft:terracotta
fill 476 263 504 479 263 504 minecraft:red_terracotta
fill 477 263 503 477 266 503 minecraft:red_terracotta
fill 479 263 502 479 265 502 minecraft:red_terracotta
setblock 480 263 464 minecraft:terracotta
fill 480 263 465 483 263 465 minecraft:red_terracotta
setblock 480 263 504 minecraft:terracotta
fill 481 263 464 481 266 464 minecraft:red_terracotta
setblock 481 263 503 minecraft:terracotta
fill 481 263 504 481 266 504 minecraft:red_terracotta
setblock 482 263 501 minecraft:red_terracotta
setblock 482 263 502 minecraft:terracotta
fill 482 263 503 482 266 503 minecraft:red_terracotta
setblock 483 263 501 minecraft:terracotta
fill 483 263 502 483 266 502 minecraft:red_terracotta
setblock 484 263 465 minecraft:terracotta
fill 484 263 501 484 266 501 minecraft:red_terracotta
setblock 485 263 464 minecraft:terracotta
fill 485 263 465 486 265 465 minecraft:red_terracotta
setblock 485 263 504 minecraft:terracotta
fill 486 263 464 486 266 464 minecraft:red_terracotta
setblock 486 263 503 minecraft:terracotta
fill 486 263 504 486 266 504 minecraft:red_terracotta
setblock 487 263 502 minecraft:terracotta
fill 487 263 503 487 266 503 minecraft:red_terracotta
fill 488 263 502 488 266 502 minecraft:red_terracotta
setblock 490 263 504 minecraft:terracotta
setblock 491 263 503 minecraft:terracotta
fill 491 263 504 491 266 504 minecraft:red_terracotta
fill 492 263 503 492 265 503 minecraft:red_terracotta
setblock 495 263 504 minecraft:terracotta
fill 496 263 504 499 263 504 minecraft:red_terracotta
setblock 500 263 504 minecraft:terracotta
fill 501 263 464 501 266 464 minecraft:red_terracotta
setblock 501 263 503 minecraft:terracotta
fill 501 263 504 501 266 504 minecraft:red_terracotta
fill 502 263 503 505 263 503 minecraft:red_terracotta
setblock 504 263 464 minecraft:red_terracotta
setblock 504 263 465 minecraft:terracotta
setblock 505 263 464 minecraft:terracotta
fill 505 263 465 508 263 465 minecraft:red_terracotta
setblock 505 263 504 minecraft:terracotta
fill 506 263 464 506 266 464 minecraft:red_terracotta
setblock 506 263 503 minecraft:terracotta
fill 506 263 504 506 266 504 minecraft:red_terracotta
fill 507 263 503 507 266 503 minecraft:red_terracotta
setblock 508 263 480 minecraft:red_terracotta
setblock 508 263 481 minecraft:terracotta
fill 508 263 482 508 265 482 minecraft:red_terracotta
setblock 509 263 465 minecraft:terracotta
setblock 509 263 476 minecraft:red_terracotta
setblock 509 263 480 minecraft:terracotta
fill 509 263 481 509 266 481 minecraft:red_terracotta
setblock 509 263 484 minecraft:red_terracotta
setblock 510 263 464 minecraft:terracotta
setblock 510 263 474 minecraft:terracotta
fill 510 263 475 510 265 475 minecraft:red_terracotta
setblock 510 263 479 minecraft:terracotta
fill 510 263 480 510 266 480 minecraft:red_terracotta
setblock 510 263 484 minecraft:terracotta
fill 510 263 485 510 266 485 minecraft:red_terracotta
setblock 510 263 504 minecraft:terracotta
fill 511 263 464 511 266 464 minecraft:red_terracotta
setblock 511 263 468 minecraft:terracotta
fill 511 263 469 511 266 469 minecraft:red_terracotta
setblock 511 263 473 minecraft:terracotta
fill 511 263 474 511 266 474 minecraft:red_terracotta
setblock 511 263 478 minecraft:terracotta
fill 511 263 479 511 266 479 minecraft:red_terracotta
setblock 511 263 483 minecraft:terracotta
fill 511 263 484 511 266 484 minecraft:red_terracotta
setblock 511 263 503 minecraft:terracotta
fill 511 263 504 511 266 504 minecraft:red_terracotta
setblock 471 264 467 minecraft:terracotta
fill 471 264 468 471 266 469 minecraft:red_terracotta
setblock 471 264 477 minecraft:terracotta
fill 471 264 478 471 265 478 minecraft:red_terracotta
setblock 471 264 482 minecraft:terracotta
fill 471 264 483 471 266 484 minecraft:red_terracotta
setblock 471 264 502 minecraft:terracotta
fill 471 264 503 473 264 504 minecraft:red_terracotta
setblock 472 264 465 minecraft:red_terracotta
fill 472 264 502 472 267 502 minecraft:red_terracotta
setblock 473 264 464 minecraft:red_terracotta
setblock 474 264 464 minecraft:terracotta
setblock 474 264 503 minecraft:red_terracotta
setblock 474 264 504 minecraft:terracotta
fill 475 264 464 475 267 464 minecraft:red_terracotta
setblock 475 264 503 minecraft:terracotta
fill 475 264 504 478 264 504 minecraft:red_terracotta
fill 476 264 503 476 267 503 minecraft:red_terracotta
setblock 478 264 464 minecraft:red_terracotta
setblock 478 264 465 minecraft:terracotta
fill 478 264 502 478 266 502 minecraft:red_terracotta
setblock 479 264 464 minecraft:terracotta
fill 479 264 465 482 264 465 minecraft:red_terracotta
setblock 479 264 504 minecraft:terracotta
fill 480 264 464 480 267 464 minecraft:red_terracotta
setblock 480 264 503 minecraft:terracotta
fill 480 264 504 480 267 504 minecraft:red_terracotta
setblock 481 264 501 minecraft:red_terracotta
setblock 481 264 502 minecraft:terracotta
fill 481 264 503 481 267 503 minecraft:red_terracotta
setblock 482 264 501 minecraft:terracotta
fill 482 264 502 482 267 502 minecraft:red_terracotta
setblock 483 264 465 minecraft:terracotta
fill 483 264 501 483 267 501 minecraft:red_terracotta
setblock 484 264 464 minecraft:terracotta
fill 484 264 465 484 267 465 minecraft:red_terracotta
setblock 484 264 504 minecraft:terracotta
fill 485 264 464 485 267 464 minecraft:red_terracotta
setblock 485 264 503 minecraft:terracotta
fill 485 264 504 485 267 504 minecraft:red_terracotta
setblock 486 264 502 minecraft:terracotta
fill 486 264 503 486 267 503 minecraft:red_terracotta
setblock 487 264 465 minecraft:red_terracotta
setblock 487 264 501 minecraft:terracotta
fill 487 264 502 487 267 502 minecraft:red_terracotta
setblock 489 264 464 minecraft:terracotta
setblock 489 264 504 minecraft:terracotta
fill 490 264 464 490 267 464 minecraft:red_terracotta
setblock 490 264 503 minecraft:terracotta
fill 490 264 504 490 267 504 minecraft:red_terracotta
fill 491 264 503 491 266 503 minecraft:red_terracotta
setblock 493 264 504 minecraft:red_terracotta
setblock 494 264 504 minecraft:terracotta
fill 495 264 504 498 264 504 minecraft:red_terracotta
setblock 499 264 464 minecraft:terracotta
setblock 499 264 504 minecraft:terracotta
fill 500 264 464 500 267 464 minecraft:red_terracotta
setblock 500 264 503 minecraft:terracotta
fill 500 264 504 500 267 504 minecraft:red_terracotta
fill 501 264 503 504 264 503 minecraft:red_terracotta
setblock 502 264 465 minecraft:red_terracotta
setblock 503 264 465 minecraft:terracotta
setblock 504 264 464 minecraft:terracotta
fill 504 264 465 507 264 465 minecraft:red_terracotta
setblock 504 264 504 minecraft:terracotta
fill 505 264 464 505 267 464 minecraft:red_terracotta
setblock 505 264 503 minecraft:terracotta
fill 505 264 504 505 267 504 minecraft:red_terracotta
fill 506 264 503 506 267 503 minecraft:red_terracotta
setblock 508 264 465 minecraft:terracotta
setblock 508 264 480 minecraft:terracotta
fill 508 264 481 508 265 481 minecraft:red_terracotta
setblock 509 264 464 minecraft:terracotta
fill 509 264 465 511 265 465 minecraft:red_terracotta
setblock 509 264 479 minecraft:terracotta
schedule function dropper:buildpart/118_10 1t
