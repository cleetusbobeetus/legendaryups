setblock 10 99 332 minecraft:light[level=12]
setblock 10 99 339 minecraft:light[level=12]
setblock 10 99 346 minecraft:light[level=12]
setblock 10 99 353 minecraft:light[level=12]
setblock 10 99 360 minecraft:light[level=12]
fill 10 99 363 13 99 363 minecraft:honeycomb_block
fill 11 99 364 11 175 364 minecraft:honeycomb_block
setblock 12 99 324 minecraft:honeycomb_block
fill 12 99 362 12 101 362 minecraft:honeycomb_block
setblock 13 99 324 minecraft:yellow_terracotta
setblock 14 99 323 minecraft:yellow_terracotta
fill 14 99 324 14 102 324 minecraft:honeycomb_block
setblock 14 99 363 minecraft:yellow_terracotta
fill 15 99 323 15 102 323 minecraft:honeycomb_block
setblock 15 99 362 minecraft:yellow_terracotta
fill 15 99 363 15 102 363 minecraft:honeycomb_block
fill 16 99 362 16 102 362 minecraft:honeycomb_block
setblock 17 99 325 minecraft:light[level=12]
setblock 17 99 332 minecraft:light[level=12]
setblock 17 99 339 minecraft:light[level=12]
setblock 17 99 353 minecraft:light[level=12]
setblock 17 99 360 minecraft:light[level=12]
setblock 18 99 324 minecraft:yellow_terracotta
setblock 19 99 323 minecraft:yellow_terracotta
fill 19 99 324 20 101 324 minecraft:honeycomb_block
setblock 19 99 363 minecraft:yellow_terracotta
fill 20 99 323 20 102 323 minecraft:honeycomb_block
setblock 20 99 362 minecraft:yellow_terracotta
fill 20 99 363 20 102 363 minecraft:honeycomb_block
setblock 24 99 323 minecraft:yellow_terracotta
setblock 24 99 325 minecraft:light[level=12]
setblock 24 99 332 minecraft:light[level=12]
setblock 24 99 339 minecraft:light[level=12]
setblock 24 99 346 minecraft:light[level=12]
setblock 24 99 353 minecraft:light[level=12]
setblock 24 99 360 minecraft:light[level=12]
setblock 24 99 363 minecraft:yellow_terracotta
fill 25 99 323 25 102 323 minecraft:honeycomb_block
setblock 25 99 327 minecraft:flowering_azalea_leaves[persistent=true]
setblock 25 99 329 minecraft:flowering_azalea_leaves[persistent=true]
fill 25 99 363 25 102 363 minecraft:honeycomb_block
fill 26 99 326 28 99 326 minecraft:flowering_azalea_leaves[persistent=true]
setblock 26 99 330 minecraft:flowering_azalea_leaves[persistent=true]
fill 26 99 362 26 102 362 minecraft:honeycomb_block
fill 27 99 328 27 100 328 minecraft:flowering_azalea_leaves[persistent=true]
setblock 28 99 330 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 99 323 minecraft:yellow_terracotta
setblock 29 99 327 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 99 329 minecraft:flowering_azalea_leaves[persistent=true]
setblock 29 99 363 minecraft:yellow_terracotta
fill 30 99 323 30 102 323 minecraft:honeycomb_block
setblock 30 99 362 minecraft:yellow_terracotta
fill 30 99 363 30 102 363 minecraft:honeycomb_block
setblock 31 99 325 minecraft:light[level=12]
setblock 31 99 332 minecraft:light[level=12]
setblock 31 99 339 minecraft:light[level=12]
setblock 31 99 346 minecraft:light[level=12]
setblock 31 99 353 minecraft:light[level=12]
setblock 31 99 360 minecraft:light[level=12]
setblock 31 99 361 minecraft:yellow_terracotta
fill 31 99 362 31 102 362 minecraft:honeycomb_block
setblock 32 99 324 minecraft:honeycomb_block
fill 32 99 361 32 102 361 minecraft:honeycomb_block
setblock 33 99 324 minecraft:yellow_terracotta
fill 33 99 360 33 102 360 minecraft:honeycomb_block
setblock 34 99 323 minecraft:yellow_terracotta
fill 34 99 324 34 102 324 minecraft:honeycomb_block
setblock 34 99 363 minecraft:yellow_terracotta
fill 35 99 323 35 102 323 minecraft:honeycomb_block
fill 35 99 346 35 101 346 minecraft:yellow_terracotta
setblock 35 99 362 minecraft:yellow_terracotta
fill 35 99 363 35 102 363 minecraft:honeycomb_block
setblock 36 99 361 minecraft:yellow_terracotta
fill 36 99 362 36 102 362 minecraft:honeycomb_block
fill 37 99 361 37 102 361 minecraft:honeycomb_block
setblock 38 99 325 minecraft:light[level=12]
setblock 38 99 332 minecraft:light[level=12]
setblock 38 99 339 minecraft:light[level=12]
setblock 38 99 346 minecraft:light[level=12]
setblock 38 99 353 minecraft:light[level=12]
setblock 38 99 360 minecraft:light[level=12]
setblock 39 99 323 minecraft:yellow_terracotta
setblock 39 99 363 minecraft:yellow_terracotta
setblock 40 99 342 minecraft:yellow_terracotta
fill 40 99 343 40 102 343 minecraft:honeycomb_block
setblock 40 99 357 minecraft:yellow_terracotta
setblock 40 99 358 minecraft:honeycomb_block
setblock 40 99 362 minecraft:yellow_terracotta
fill 40 99 363 40 102 363 minecraft:honeycomb_block
setblock 41 99 332 minecraft:honey_block
setblock 41 99 341 minecraft:yellow_terracotta
fill 41 99 342 41 102 342 minecraft:honeycomb_block
setblock 41 99 346 minecraft:yellow_terracotta
fill 41 99 347 41 102 347 minecraft:honeycomb_block
setblock 41 99 351 minecraft:honey_block
setblock 41 99 356 minecraft:yellow_terracotta
fill 41 99 357 41 101 357 minecraft:honeycomb_block
setblock 41 99 361 minecraft:yellow_terracotta
fill 41 99 362 41 102 362 minecraft:honeycomb_block
fill 42 99 341 42 197 341 minecraft:honeycomb_block
fill 1 100 322 1 251 322 minecraft:honeycomb_block
fill 1 100 336 1 103 336 minecraft:honeycomb_block
setblock 1 100 340 minecraft:yellow_terracotta
fill 1 100 341 1 103 341 minecraft:honeycomb_block
setblock 1 100 345 minecraft:yellow_terracotta
fill 1 100 346 1 103 346 minecraft:honeycomb_block
setblock 1 100 360 minecraft:honey_block
setblock 2 100 339 minecraft:yellow_terracotta
fill 2 100 340 2 103 340 minecraft:honeycomb_block
setblock 2 100 344 minecraft:yellow_terracotta
fill 5 100 364 5 214 364 minecraft:honeycomb_block
setblock 8 100 323 minecraft:yellow_terracotta
fill 9 100 323 9 103 323 minecraft:honeycomb_block
fill 9 100 363 12 100 363 minecraft:honeycomb_block
fill 10 100 324 11 100 324 minecraft:honeycomb_block
fill 11 100 362 11 102 362 minecraft:honeycomb_block
setblock 12 100 324 minecraft:yellow_terracotta
setblock 13 100 323 minecraft:yellow_terracotta
fill 13 100 324 13 103 324 minecraft:honeycomb_block
setblock 13 100 363 minecraft:yellow_terracotta
fill 14 100 323 14 103 323 minecraft:honeycomb_block
fill 14 100 325 15 100 325 minecraft:honeycomb_block
setblock 14 100 362 minecraft:yellow_terracotta
fill 14 100 363 14 103 363 minecraft:honeycomb_block
fill 15 100 362 15 103 362 minecraft:honeycomb_block
setblock 16 100 325 minecraft:yellow_terracotta
setblock 17 100 324 minecraft:yellow_terracotta
setblock 18 100 323 minecraft:yellow_terracotta
fill 18 100 324 18 103 324 minecraft:honeycomb_block
setblock 18 100 363 minecraft:yellow_terracotta
fill 19 100 323 19 103 323 minecraft:honeycomb_block
setblock 19 100 362 minecraft:yellow_terracotta
fill 19 100 363 19 103 363 minecraft:honeycomb_block
fill 20 100 362 20 103 362 minecraft:honeycomb_block
setblock 23 100 323 minecraft:yellow_terracotta
setblock 23 100 363 minecraft:yellow_terracotta
fill 24 100 323 24 103 323 minecraft:honeycomb_block
fill 24 100 363 24 103 363 minecraft:honeycomb_block
fill 25 100 362 25 103 362 minecraft:honeycomb_block
setblock 28 100 323 minecraft:yellow_terracotta
setblock 28 100 363 minecraft:yellow_terracotta
fill 29 100 323 29 103 323 minecraft:honeycomb_block
setblock 29 100 361 minecraft:honeycomb_block
setblock 29 100 362 minecraft:yellow_terracotta
fill 29 100 363 29 103 363 minecraft:honeycomb_block
fill 30 100 324 31 100 324 minecraft:honeycomb_block
setblock 30 100 361 minecraft:yellow_terracotta
fill 30 100 362 30 103 362 minecraft:honeycomb_block
fill 31 100 361 31 103 361 minecraft:honeycomb_block
setblock 32 100 324 minecraft:yellow_terracotta
setblock 33 100 323 minecraft:yellow_terracotta
fill 33 100 324 33 103 324 minecraft:honeycomb_block
setblock 33 100 363 minecraft:yellow_terracotta
fill 34 100 323 34 103 323 minecraft:honeycomb_block
setblock 34 100 362 minecraft:yellow_terracotta
fill 34 100 363 34 103 363 minecraft:honeycomb_block
fill 35 100 324 35 101 324 minecraft:honeycomb_block
setblock 35 100 361 minecraft:yellow_terracotta
fill 35 100 362 35 103 362 minecraft:honeycomb_block
fill 36 100 361 36 103 361 minecraft:honeycomb_block
setblock 38 100 323 minecraft:yellow_terracotta
setblock 38 100 363 minecraft:yellow_terracotta
fill 39 100 323 39 103 323 minecraft:honeycomb_block
setblock 39 100 362 minecraft:yellow_terracotta
fill 39 100 363 39 103 363 minecraft:honeycomb_block
setblock 40 100 341 minecraft:yellow_terracotta
fill 40 100 342 40 103 342 minecraft:honeycomb_block
fill 40 100 344 40 101 344 minecraft:honeycomb_block
setblock 40 100 361 minecraft:yellow_terracotta
fill 40 100 362 40 102 362 minecraft:honeycomb_block
setblock 41 100 326 minecraft:honey_block
setblock 41 100 340 minecraft:yellow_terracotta
fill 41 100 341 41 103 341 minecraft:honeycomb_block
setblock 41 100 345 minecraft:yellow_terracotta
fill 41 100 346 41 103 346 minecraft:honeycomb_block
fill 41 100 348 41 101 348 minecraft:honeycomb_block
setblock 41 100 356 minecraft:honeycomb_block
setblock 41 100 360 minecraft:yellow_terracotta
fill 41 100 361 42 103 361 minecraft:honeycomb_block
setblock 42 100 332 minecraft:yellow_terracotta
setblock 42 100 351 minecraft:yellow_terracotta
setblock 42 100 354 minecraft:orange_terracotta
setblock 42 100 360 minecraft:orange_terracotta
setblock 1 101 339 minecraft:yellow_terracotta
fill 1 101 340 1 104 340 minecraft:honeycomb_block
setblock 1 101 344 minecraft:yellow_terracotta
fill 1 101 345 2 103 345 minecraft:honeycomb_block
setblock 1 101 348 minecraft:honeycomb_block
fill 2 101 339 2 104 339 minecraft:honeycomb_block
setblock 2 101 343 minecraft:yellow_terracotta
fill 2 101 344 2 104 344 minecraft:honeycomb_block
setblock 4 101 363 minecraft:honey_block
setblock 6 101 323 minecraft:honeycomb_block
setblock 7 101 323 minecraft:yellow_terracotta
setblock 7 101 363 minecraft:yellow_terracotta
fill 8 101 323 8 104 323 minecraft:honeycomb_block
fill 8 101 363 11 101 363 minecraft:honeycomb_block
fill 9 101 324 10 101 324 minecraft:honeycomb_block
fill 10 101 362 10 103 362 minecraft:honeycomb_block
setblock 11 101 324 minecraft:yellow_terracotta
fill 11 101 325 14 101 325 minecraft:honeycomb_block
setblock 12 101 323 minecraft:yellow_terracotta
fill 12 101 324 12 104 324 minecraft:honeycomb_block
setblock 12 101 363 minecraft:yellow_terracotta
fill 13 101 323 13 104 323 minecraft:honeycomb_block
setblock 13 101 362 minecraft:yellow_terracotta
fill 13 101 363 13 104 363 minecraft:honeycomb_block
fill 14 101 362 14 104 362 minecraft:honeycomb_block
setblock 15 101 325 minecraft:yellow_terracotta
setblock 16 101 324 minecraft:yellow_terracotta
fill 16 101 325 17 103 325 minecraft:honeycomb_block
setblock 17 101 323 minecraft:yellow_terracotta
fill 17 101 324 17 104 324 minecraft:honeycomb_block
setblock 17 101 363 minecraft:yellow_terracotta
fill 18 101 323 18 104 323 minecraft:honeycomb_block
setblock 18 101 362 minecraft:yellow_terracotta
fill 18 101 363 18 104 363 minecraft:honeycomb_block
fill 19 101 362 19 104 362 minecraft:honeycomb_block
setblock 21 101 324 minecraft:yellow_terracotta
setblock 22 101 323 minecraft:yellow_terracotta
setblock 22 101 363 minecraft:yellow_terracotta
fill 23 101 323 23 104 323 minecraft:honeycomb_block
fill 23 101 363 23 104 363 minecraft:honeycomb_block
setblock 23 101 364 minecraft:yellow_concrete
fill 24 101 362 24 104 362 minecraft:honeycomb_block
fill 25 101 328 25 106 328 minecraft:flowering_azalea_leaves[persistent=true]
setblock 27 101 323 minecraft:yellow_terracotta
fill 27 101 324 30 101 324 minecraft:honeycomb_block
setblock 27 101 363 minecraft:yellow_terracotta
fill 28 101 323 28 104 323 minecraft:honeycomb_block
setblock 28 101 361 minecraft:honeycomb_block
setblock 28 101 362 minecraft:yellow_terracotta
fill 28 101 363 28 104 363 minecraft:honeycomb_block
setblock 29 101 361 minecraft:yellow_terracotta
fill 29 101 362 29 104 362 minecraft:honeycomb_block
fill 30 101 361 30 104 361 minecraft:honeycomb_block
setblock 31 101 324 minecraft:yellow_terracotta
setblock 32 101 323 minecraft:yellow_terracotta
fill 32 101 324 32 104 324 minecraft:honeycomb_block
fill 32 101 360 32 103 360 minecraft:honeycomb_block
setblock 32 101 363 minecraft:yellow_terracotta
fill 33 101 323 33 104 323 minecraft:honeycomb_block
setblock 33 101 362 minecraft:yellow_terracotta
fill 33 101 363 33 104 363 minecraft:honeycomb_block
setblock 34 101 361 minecraft:yellow_terracotta
fill 34 101 362 34 104 362 minecraft:honeycomb_block
fill 35 101 361 35 104 361 minecraft:honeycomb_block
setblock 36 101 324 minecraft:yellow_terracotta
setblock 37 101 323 minecraft:yellow_terracotta
setblock 37 101 363 minecraft:yellow_terracotta
fill 38 101 323 38 104 323 minecraft:honeycomb_block
setblock 38 101 362 minecraft:yellow_terracotta
fill 38 101 363 38 104 363 minecraft:honeycomb_block
fill 39 101 362 39 104 362 minecraft:honeycomb_block
fill 40 101 341 40 104 341 minecraft:honeycomb_block
setblock 40 101 345 minecraft:yellow_terracotta
fill 40 101 346 40 104 346 minecraft:honeycomb_block
setblock 40 101 360 minecraft:yellow_terracotta
setblock 40 101 361 minecraft:honeycomb_block
setblock 41 101 339 minecraft:yellow_terracotta
fill 41 101 340 41 104 340 minecraft:honeycomb_block
setblock 41 101 344 minecraft:yellow_terracotta
fill 41 101 345 41 104 345 minecraft:honeycomb_block
setblock 41 101 349 minecraft:yellow_terracotta
setblock 41 101 359 minecraft:yellow_terracotta
fill 41 101 360 42 104 360 minecraft:honeycomb_block
fill 42 101 332 42 122 332 minecraft:honeycomb_block
fill 42 101 351 42 116 351 minecraft:honeycomb_block
fill 42 101 354 42 143 354 minecraft:honeycomb_block
setblock 0 102 356 minecraft:orange_terracotta
setblock 1 102 328 minecraft:honey_block
setblock 1 102 338 minecraft:yellow_terracotta
fill 1 102 339 1 105 339 minecraft:honeycomb_block
setblock 1 102 343 minecraft:yellow_terracotta
fill 1 102 344 1 105 344 minecraft:honeycomb_block
setblock 1 102 348 minecraft:yellow_terracotta
fill 1 102 349 1 105 349 minecraft:honeycomb_block
setblock 1 102 353 minecraft:honey_block
setblock 2 102 342 minecraft:yellow_terracotta
fill 2 102 343 2 105 343 minecraft:honeycomb_block
setblock 2 102 346 minecraft:honeycomb_block
fill 4 102 325 4 103 325 minecraft:brown_terracotta
fill 4 102 359 4 103 359 minecraft:brown_terracotta
setblock 5 102 323 minecraft:honeycomb_block
setblock 6 102 323 minecraft:yellow_terracotta
setblock 6 102 363 minecraft:yellow_terracotta
fill 7 102 323 7 104 324 minecraft:honeycomb_block
fill 7 102 359 7 103 359 minecraft:brown_terracotta
fill 7 102 363 10 102 363 minecraft:honeycomb_block
fill 8 102 324 9 102 324 minecraft:honeycomb_block
setblock 10 102 324 minecraft:yellow_terracotta
fill 10 102 325 13 102 325 minecraft:honeycomb_block
setblock 11 102 323 minecraft:yellow_terracotta
fill 11 102 324 11 105 324 minecraft:honeycomb_block
setblock 11 102 363 minecraft:yellow_terracotta
fill 12 102 323 12 105 323 minecraft:honeycomb_block
setblock 12 102 362 minecraft:yellow_terracotta
fill 12 102 363 12 105 363 minecraft:honeycomb_block
fill 13 102 362 13 105 362 minecraft:honeycomb_block
setblock 14 102 325 minecraft:yellow_terracotta
setblock 15 102 324 minecraft:yellow_terracotta
fill 15 102 325 15 105 325 minecraft:honeycomb_block
setblock 16 102 323 minecraft:yellow_terracotta
fill 16 102 324 16 105 324 minecraft:honeycomb_block
setblock 16 102 363 minecraft:yellow_terracotta
fill 17 102 323 17 105 323 minecraft:honeycomb_block
fill 17 102 359 17 103 359 minecraft:brown_terracotta
setblock 17 102 362 minecraft:yellow_terracotta
fill 17 102 363 17 105 363 minecraft:honeycomb_block
setblock 18 102 325 minecraft:honeycomb_block
fill 18 102 362 18 105 362 minecraft:honeycomb_block
setblock 19 102 324 minecraft:honeycomb_block
setblock 20 102 324 minecraft:yellow_terracotta
fill 20 102 326 20 103 326 minecraft:brown_terracotta
setblock 21 102 323 minecraft:yellow_terracotta
fill 21 102 324 24 102 324 minecraft:honeycomb_block
fill 21 102 359 21 103 359 minecraft:brown_terracotta
setblock 21 102 362 minecraft:honeycomb_block
setblock 21 102 363 minecraft:yellow_terracotta
fill 22 102 323 22 105 323 minecraft:honeycomb_block
setblock 22 102 362 minecraft:yellow_terracotta
fill 22 102 363 22 105 363 minecraft:honeycomb_block
fill 23 102 362 23 105 362 minecraft:honeycomb_block
fill 23 102 364 23 147 364 minecraft:honeycomb_block
setblock 25 102 324 minecraft:yellow_terracotta
setblock 26 102 323 minecraft:yellow_terracotta
fill 26 102 324 29 102 324 minecraft:honeycomb_block
setblock 26 102 363 minecraft:yellow_terracotta
fill 27 102 323 27 105 323 minecraft:honeycomb_block
setblock 27 102 362 minecraft:yellow_terracotta
fill 27 102 363 27 105 363 minecraft:honeycomb_block
setblock 28 102 361 minecraft:yellow_terracotta
fill 28 102 362 28 105 362 minecraft:honeycomb_block
fill 29 102 361 29 105 361 minecraft:honeycomb_block
setblock 30 102 324 minecraft:yellow_terracotta
setblock 31 102 323 minecraft:yellow_terracotta
fill 31 102 324 31 105 324 minecraft:honeycomb_block
setblock 31 102 363 minecraft:yellow_terracotta
fill 32 102 323 32 105 323 minecraft:honeycomb_block
setblock 32 102 362 minecraft:yellow_terracotta
fill 32 102 363 32 105 363 minecraft:honeycomb_block
setblock 33 102 361 minecraft:yellow_terracotta
fill 33 102 362 33 105 362 minecraft:honeycomb_block
fill 34 102 345 36 104 347 minecraft:flowering_azalea_leaves[persistent=true]
setblock 34 102 360 minecraft:yellow_terracotta
fill 34 102 361 34 105 361 minecraft:honeycomb_block
setblock 35 102 324 minecraft:yellow_terracotta
fill 35 102 344 36 104 344 minecraft:flowering_azalea_leaves[persistent=true]
setblock 36 102 323 minecraft:yellow_terracotta
fill 36 102 324 36 105 324 minecraft:honeycomb_block
setblock 36 102 363 minecraft:yellow_terracotta
fill 37 102 323 37 105 323 minecraft:honeycomb_block
fill 37 102 345 37 104 346 minecraft:flowering_azalea_leaves[persistent=true]
setblock 37 102 362 minecraft:yellow_terracotta
fill 37 102 363 37 105 363 minecraft:honeycomb_block
fill 38 102 362 38 105 362 minecraft:honeycomb_block
setblock 40 102 344 minecraft:yellow_terracotta
fill 40 102 345 40 105 345 minecraft:honeycomb_block
fill 40 102 347 40 103 347 minecraft:honeycomb_block
setblock 41 102 333 minecraft:honey_block
fill 41 102 339 41 105 339 minecraft:honeycomb_block
setblock 41 102 343 minecraft:yellow_terracotta
fill 41 102 344 41 105 344 minecraft:honeycomb_block
setblock 41 102 348 minecraft:yellow_terracotta
fill 41 102 349 41 104 350 minecraft:honeycomb_block
setblock 41 102 358 minecraft:yellow_terracotta
fill 41 102 359 41 103 359 minecraft:honeycomb_block
setblock 41 102 363 minecraft:yellow_terracotta
fill 0 103 356 0 129 356 minecraft:honeycomb_block
fill 1 103 323 4 103 323 minecraft:honeycomb_block
setblock 1 103 334 minecraft:honey_block
setblock 1 103 337 minecraft:yellow_terracotta
fill 1 103 338 1 106 338 minecraft:honeycomb_block
setblock 1 103 342 minecraft:yellow_terracotta
fill 1 103 343 1 106 343 minecraft:honeycomb_block
setblock 1 103 347 minecraft:yellow_terracotta
fill 1 103 348 1 106 348 minecraft:honeycomb_block
setblock 1 103 359 minecraft:honey_block
setblock 2 103 341 minecraft:yellow_terracotta
fill 2 103 342 2 106 342 minecraft:honeycomb_block
setblock 2 103 346 minecraft:yellow_terracotta
fill 3 103 325 3 104 325 minecraft:brown_terracotta
setblock 3 103 333 minecraft:light[level=15]
setblock 3 103 341 minecraft:light[level=15]
setblock 3 103 349 minecraft:light[level=15]
setblock 3 103 357 minecraft:light[level=15]
fill 4 103 360 4 104 360 minecraft:brown_terracotta
setblock 5 103 323 minecraft:yellow_terracotta
setblock 5 103 363 minecraft:yellow_terracotta
fill 6 103 323 6 105 324 minecraft:honeycomb_block
fill 6 103 363 9 103 363 minecraft:honeycomb_block
fill 7 103 360 7 104 360 minecraft:brown_terracotta
setblock 8 103 324 minecraft:honeycomb_block
setblock 8 103 325 minecraft:yellow_terracotta
setblock 9 103 324 minecraft:yellow_terracotta
fill 9 103 325 12 103 325 minecraft:honeycomb_block
fill 9 103 362 9 104 362 minecraft:honeycomb_block
setblock 10 103 323 minecraft:yellow_terracotta
fill 10 103 324 10 106 324 minecraft:honeycomb_block
setblock 10 103 363 minecraft:yellow_terracotta
fill 11 103 323 11 106 323 minecraft:honeycomb_block
setblock 11 103 326 minecraft:honeycomb_block
setblock 11 103 333 minecraft:light[level=15]
setblock 11 103 341 minecraft:light[level=15]
setblock 11 103 349 minecraft:light[level=15]
setblock 11 103 357 minecraft:light[level=15]
setblock 11 103 362 minecraft:yellow_terracotta
fill 11 103 363 11 106 363 minecraft:honeycomb_block
setblock 12 103 326 minecraft:yellow_terracotta
fill 12 103 362 12 106 362 minecraft:honeycomb_block
setblock 13 103 325 minecraft:yellow_terracotta
fill 13 103 326 14 105 326 minecraft:honeycomb_block
setblock 14 103 324 minecraft:yellow_terracotta
fill 14 103 325 14 106 325 minecraft:honeycomb_block
setblock 15 103 323 minecraft:yellow_terracotta
fill 15 103 324 15 106 324 minecraft:honeycomb_block
setblock 15 103 363 minecraft:yellow_terracotta
fill 16 103 323 16 106 323 minecraft:honeycomb_block
setblock 16 103 362 minecraft:yellow_terracotta
fill 16 103 363 16 106 363 minecraft:honeycomb_block
fill 17 103 360 17 104 360 minecraft:brown_terracotta
fill 17 103 362 17 106 362 minecraft:honeycomb_block
setblock 18 103 325 minecraft:yellow_terracotta
setblock 19 103 324 minecraft:yellow_terracotta
setblock 19 103 325 minecraft:light[level=15]
setblock 19 103 333 minecraft:light[level=15]
setblock 19 103 341 minecraft:light[level=15]
setblock 19 103 349 minecraft:light[level=15]
setblock 19 103 357 minecraft:light[level=15]
setblock 20 103 323 minecraft:yellow_terracotta
fill 20 103 324 23 103 324 minecraft:honeycomb_block
fill 20 103 325 20 104 325 minecraft:brown_terracotta
setblock 20 103 363 minecraft:yellow_terracotta
fill 21 103 323 21 106 323 minecraft:honeycomb_block
fill 21 103 360 21 104 360 minecraft:brown_terracotta
setblock 21 103 362 minecraft:yellow_terracotta
fill 21 103 363 21 106 363 minecraft:honeycomb_block
fill 22 103 362 22 106 362 minecraft:honeycomb_block
setblock 24 103 324 minecraft:yellow_terracotta
setblock 25 103 323 minecraft:yellow_terracotta
fill 25 103 324 28 103 324 minecraft:honeycomb_block
setblock 25 103 363 minecraft:yellow_terracotta
fill 25 103 364 25 112 364 minecraft:honeycomb_block
fill 26 103 323 26 106 323 minecraft:honeycomb_block
setblock 26 103 362 minecraft:yellow_terracotta
fill 26 103 363 26 106 363 minecraft:honeycomb_block
setblock 26 103 364 minecraft:yellow_concrete
setblock 27 103 325 minecraft:light[level=15]
setblock 27 103 333 minecraft:light[level=15]
setblock 27 103 341 minecraft:light[level=15]
setblock 27 103 349 minecraft:light[level=15]
setblock 27 103 357 minecraft:light[level=15]
setblock 27 103 361 minecraft:yellow_terracotta
fill 27 103 362 27 106 362 minecraft:honeycomb_block
fill 28 103 361 28 106 361 minecraft:honeycomb_block
setblock 29 103 324 minecraft:yellow_terracotta
fill 29 103 325 32 103 325 minecraft:honeycomb_block
setblock 30 103 323 minecraft:yellow_terracotta
fill 30 103 324 30 106 324 minecraft:honeycomb_block
setblock 30 103 363 minecraft:yellow_terracotta
fill 31 103 323 31 106 323 minecraft:honeycomb_block
fill 31 103 360 31 104 360 minecraft:honeycomb_block
setblock 31 103 362 minecraft:yellow_terracotta
fill 31 103 363 31 106 363 minecraft:honeycomb_block
setblock 32 103 361 minecraft:yellow_terracotta
fill 32 103 362 32 106 362 minecraft:honeycomb_block
setblock 33 103 325 minecraft:yellow_terracotta
fill 33 103 345 33 103 346 minecraft:flowering_azalea_leaves[persistent=true]
setblock 33 103 360 minecraft:yellow_terracotta
fill 33 103 361 33 106 361 minecraft:honeycomb_block
setblock 34 103 324 minecraft:yellow_terracotta
setblock 34 103 344 minecraft:flowering_azalea_leaves[persistent=true]
setblock 35 103 323 minecraft:yellow_terracotta
fill 35 103 324 35 106 324 minecraft:honeycomb_block
setblock 35 103 325 minecraft:light[level=15]
setblock 35 103 333 minecraft:light[level=15]
setblock 35 103 341 minecraft:light[level=15]
setblock 35 103 349 minecraft:light[level=15]
setblock 35 103 357 minecraft:light[level=15]
setblock 35 103 363 minecraft:yellow_terracotta
fill 36 103 323 36 106 323 minecraft:honeycomb_block
setblock 36 103 362 minecraft:yellow_terracotta
fill 36 103 363 36 106 363 minecraft:honeycomb_block
fill 37 103 324 37 104 324 minecraft:honeycomb_block
setblock 37 103 344 minecraft:flowering_azalea_leaves[persistent=true]
setblock 37 103 347 minecraft:flowering_azalea_leaves[persistent=true]
setblock 37 103 361 minecraft:yellow_terracotta
fill 37 103 362 37 106 362 minecraft:honeycomb_block
setblock 39 103 344 minecraft:yellow_terracotta
fill 39 103 345 39 106 345 minecraft:honeycomb_block
setblock 40 103 323 minecraft:yellow_terracotta
setblock 40 103 343 minecraft:yellow_terracotta
fill 40 103 344 40 106 344 minecraft:honeycomb_block
setblock 40 103 348 minecraft:yellow_terracotta
fill 40 103 349 40 106 349 minecraft:honeycomb_block
setblock 40 103 363 minecraft:yellow_terracotta
setblock 41 103 322 minecraft:orange_terracotta
setblock 41 103 327 minecraft:honey_block
setblock 41 103 342 minecraft:yellow_terracotta
fill 41 103 343 41 106 343 minecraft:honeycomb_block
setblock 41 103 347 minecraft:yellow_terracotta
fill 41 103 348 41 106 348 minecraft:honeycomb_block
setblock 41 103 351 minecraft:honeycomb_block
setblock 41 103 352 minecraft:yellow_terracotta
setblock 41 103 362 minecraft:yellow_terracotta
fill 41 103 363 41 105 363 minecraft:honeycomb_block
setblock 42 103 330 minecraft:orange_terracotta
setblock 0 104 345 minecraft:yellow_terracotta
fill 0 104 346 0 158 347 minecraft:honeycomb_block
fill 1 104 323 1 104 325 minecraft:honeycomb_block
setblock 1 104 326 minecraft:yellow_terracotta
setblock 1 104 336 minecraft:yellow_terracotta
fill 1 104 337 1 107 337 minecraft:honeycomb_block
setblock 1 104 341 minecraft:yellow_terracotta
fill 1 104 342 1 107 342 minecraft:honeycomb_block
setblock 1 104 345 minecraft:honeycomb_block
setblock 1 104 346 minecraft:yellow_terracotta
fill 1 104 347 2 106 347 minecraft:honeycomb_block
setblock 1 104 350 minecraft:honeycomb_block
fill 2 104 323 3 104 323 minecraft:honeycomb_block
fill 2 104 325 2 105 325 minecraft:brown_terracotta
setblock 2 104 340 minecraft:yellow_terracotta
fill 2 104 341 2 107 341 minecraft:honeycomb_block
setblock 2 104 345 minecraft:yellow_terracotta
fill 2 104 346 2 107 346 minecraft:honeycomb_block
setblock 3 104 343 minecraft:honeycomb_block
setblock 3 104 363 minecraft:honey_block
setblock 4 104 323 minecraft:yellow_terracotta
fill 4 104 324 5 106 324 minecraft:honeycomb_block
fill 4 104 361 4 105 361 minecraft:brown_terracotta
fill 5 104 323 5 107 323 minecraft:honeycomb_block
fill 5 104 363 8 104 363 minecraft:honeycomb_block
setblock 7 104 325 minecraft:yellow_terracotta
fill 7 104 361 7 105 361 minecraft:brown_terracotta
setblock 8 104 324 minecraft:yellow_terracotta
fill 8 104 325 11 104 325 minecraft:honeycomb_block
fill 8 104 362 8 105 362 minecraft:honeycomb_block
setblock 9 104 323 minecraft:yellow_terracotta
fill 9 104 324 9 107 324 minecraft:honeycomb_block
fill 9 104 326 10 104 326 minecraft:honeycomb_block
setblock 9 104 363 minecraft:yellow_terracotta
fill 10 104 323 10 107 323 minecraft:honeycomb_block
setblock 10 104 362 minecraft:yellow_terracotta
fill 10 104 363 10 107 363 minecraft:honeycomb_block
setblock 11 104 326 minecraft:yellow_terracotta
fill 11 104 362 11 107 362 minecraft:honeycomb_block
setblock 12 104 325 minecraft:yellow_terracotta
fill 12 104 326 12 107 326 minecraft:honeycomb_block
setblock 13 104 324 minecraft:yellow_terracotta
fill 13 104 325 13 107 325 minecraft:honeycomb_block
setblock 14 104 323 minecraft:yellow_terracotta
fill 14 104 324 14 107 324 minecraft:honeycomb_block
setblock 14 104 363 minecraft:yellow_terracotta
fill 15 104 323 15 107 323 minecraft:honeycomb_block
setblock 15 104 326 minecraft:honeycomb_block
setblock 15 104 362 minecraft:yellow_terracotta
fill 15 104 363 15 107 363 minecraft:honeycomb_block
setblock 16 104 325 minecraft:honeycomb_block
fill 16 104 349 16 105 349 minecraft:honey_block
fill 16 104 362 16 106 362 minecraft:honeycomb_block
setblock 17 104 325 minecraft:yellow_terracotta
fill 17 104 361 17 105 361 minecraft:brown_terracotta
setblock 18 104 324 minecraft:yellow_terracotta
fill 18 104 325 19 106 325 minecraft:honeycomb_block
setblock 19 104 323 minecraft:yellow_terracotta
fill 19 104 324 22 104 324 minecraft:honeycomb_block
setblock 19 104 363 minecraft:yellow_terracotta
fill 20 104 323 20 107 323 minecraft:honeycomb_block
setblock 20 104 362 minecraft:yellow_terracotta
fill 20 104 363 20 107 363 minecraft:honeycomb_block
fill 21 104 361 21 105 361 minecraft:brown_terracotta
fill 21 104 362 21 105 362 minecraft:honeycomb_block
setblock 23 104 324 minecraft:yellow_terracotta
setblock 24 104 323 minecraft:yellow_terracotta
fill 24 104 324 27 104 324 minecraft:honeycomb_block
setblock 24 104 363 minecraft:yellow_terracotta
fill 25 104 323 25 107 323 minecraft:honeycomb_block
setblock 25 104 362 minecraft:yellow_terracotta
fill 25 104 363 25 107 363 minecraft:honeycomb_block
fill 26 104 362 26 107 362 minecraft:honeycomb_block
fill 26 104 364 26 149 364 minecraft:honeycomb_block
setblock 27 104 325 minecraft:yellow_terracotta
fill 27 104 361 27 107 361 minecraft:honeycomb_block
setblock 28 104 324 minecraft:yellow_terracotta
fill 28 104 325 31 104 325 minecraft:honeycomb_block
setblock 29 104 323 minecraft:yellow_terracotta
fill 29 104 324 29 107 324 minecraft:honeycomb_block
setblock 29 104 363 minecraft:yellow_terracotta
fill 30 104 323 30 107 323 minecraft:honeycomb_block
setblock 30 104 362 minecraft:yellow_terracotta
fill 30 104 363 30 107 363 minecraft:honeycomb_block
setblock 31 104 361 minecraft:yellow_terracotta
fill 31 104 362 31 107 362 minecraft:honeycomb_block
setblock 32 104 325 minecraft:yellow_terracotta
setblock 32 104 360 minecraft:yellow_terracotta
fill 32 104 361 32 107 361 minecraft:honeycomb_block
setblock 33 104 324 minecraft:yellow_terracotta
fill 33 104 325 33 107 325 minecraft:honeycomb_block
setblock 34 104 323 minecraft:yellow_terracotta
fill 34 104 324 34 107 324 minecraft:honeycomb_block
setblock 34 104 363 minecraft:yellow_terracotta
fill 35 104 323 35 107 323 minecraft:honeycomb_block
setblock 35 104 362 minecraft:yellow_terracotta
fill 35 104 363 35 107 363 minecraft:honeycomb_block
setblock 36 104 361 minecraft:yellow_terracotta
fill 36 104 362 36 106 362 minecraft:honeycomb_block
setblock 39 104 323 minecraft:yellow_terracotta
fill 39 104 344 39 106 344 minecraft:honeycomb_block
fill 39 104 346 39 104 347 minecraft:honeycomb_block
setblock 39 104 363 minecraft:yellow_terracotta
fill 40 104 323 40 106 323 minecraft:honeycomb_block
setblock 40 104 342 minecraft:yellow_terracotta
fill 40 104 343 40 107 343 minecraft:honeycomb_block
setblock 40 104 347 minecraft:yellow_terracotta
fill 40 104 348 40 107 348 minecraft:honeycomb_block
fill 40 104 350 40 105 350 minecraft:honeycomb_block
fill 40 104 363 40 106 363 minecraft:honeycomb_block
fill 41 104 322 41 130 322 minecraft:honeycomb_block
setblock 41 104 341 minecraft:yellow_terracotta
fill 41 104 342 41 107 342 minecraft:honeycomb_block
setblock 41 104 346 minecraft:yellow_terracotta
fill 41 104 347 41 107 347 minecraft:honeycomb_block
setblock 41 104 351 minecraft:yellow_terracotta
fill 41 104 352 41 107 352 minecraft:honeycomb_block
setblock 41 104 361 minecraft:yellow_terracotta
fill 41 104 362 41 105 362 minecraft:honeycomb_block
fill 42 104 330 42 202 330 minecraft:honeycomb_block
fill 42 104 361 42 170 361 minecraft:honeycomb_block
fill 0 105 345 0 160 345 minecraft:honeycomb_block
setblock 0 105 350 minecraft:orange_terracotta
fill 1 105 323 1 105 324 minecraft:honeycomb_block
setblock 1 105 325 minecraft:yellow_terracotta
fill 1 105 326 1 105 329 minecraft:honeycomb_block
fill 1 105 336 1 106 336 minecraft:honeycomb_block
setblock 1 105 340 minecraft:yellow_terracotta
fill 1 105 341 1 108 341 minecraft:honeycomb_block
setblock 1 105 345 minecraft:yellow_terracotta
fill 1 105 346 1 108 346 minecraft:honeycomb_block
setblock 1 105 350 minecraft:yellow_terracotta
setblock 2 105 323 minecraft:honeycomb_block
setblock 2 105 339 minecraft:yellow_terracotta
fill 2 105 340 2 106 340 minecraft:honeycomb_block
setblock 2 105 344 minecraft:yellow_terracotta
fill 2 105 345 3 106 345 minecraft:honeycomb_block
setblock 2 105 348 minecraft:honeycomb_block
setblock 3 105 323 minecraft:yellow_terracotta
fill 3 105 324 3 108 324 minecraft:honeycomb_block
setblock 3 105 325 minecraft:light[level=12]
setblock 3 105 332 minecraft:light[level=12]
setblock 3 105 339 minecraft:light[level=12]
setblock 3 105 343 minecraft:yellow_terracotta
fill 3 105 344 3 106 344 minecraft:honeycomb_block
setblock 3 105 346 minecraft:light[level=12]
setblock 3 105 353 minecraft:light[level=12]
setblock 3 105 360 minecraft:light[level=12]
fill 4 105 323 4 108 323 minecraft:honeycomb_block
fill 4 105 362 4 106 362 minecraft:brown_terracotta
fill 4 105 363 7 105 363 minecraft:honeycomb_block
setblock 6 105 325 minecraft:yellow_terracotta
setblock 7 105 323 minecraft:honeycomb_block
setblock 7 105 324 minecraft:yellow_terracotta
fill 7 105 325 10 105 325 minecraft:honeycomb_block
fill 7 105 362 7 106 362 minecraft:brown_terracotta
setblock 8 105 323 minecraft:yellow_terracotta
fill 8 105 324 8 108 324 minecraft:honeycomb_block
fill 8 105 326 9 105 326 minecraft:honeycomb_block
setblock 8 105 363 minecraft:yellow_terracotta
fill 9 105 323 9 108 323 minecraft:honeycomb_block
setblock 9 105 362 minecraft:yellow_terracotta
fill 9 105 363 9 108 363 minecraft:honeycomb_block
setblock 10 105 326 minecraft:yellow_terracotta
setblock 10 105 332 minecraft:light[level=12]
setblock 10 105 339 minecraft:light[level=12]
setblock 10 105 346 minecraft:light[level=12]
setblock 10 105 353 minecraft:light[level=12]
setblock 10 105 360 minecraft:light[level=12]
fill 10 105 362 10 108 362 minecraft:honeycomb_block
setblock 11 105 325 minecraft:yellow_terracotta
fill 11 105 326 11 108 326 minecraft:honeycomb_block
setblock 12 105 324 minecraft:yellow_terracotta
fill 12 105 325 12 108 325 minecraft:honeycomb_block
setblock 13 105 323 minecraft:yellow_terracotta
fill 13 105 324 13 108 324 minecraft:honeycomb_block
setblock 13 105 363 minecraft:yellow_terracotta
fill 14 105 323 14 108 323 minecraft:honeycomb_block
setblock 14 105 362 minecraft:yellow_terracotta
fill 14 105 363 14 108 363 minecraft:honeycomb_block
setblock 15 105 326 minecraft:yellow_terracotta
fill 15 105 362 15 107 362 minecraft:honeycomb_block
setblock 16 105 325 minecraft:yellow_terracotta
setblock 16 105 326 minecraft:honeycomb_block
setblock 17 105 324 minecraft:yellow_terracotta
fill 17 105 325 17 108 325 minecraft:honeycomb_block
setblock 17 105 332 minecraft:light[level=12]
setblock 17 105 339 minecraft:light[level=12]
fill 17 105 343 17 119 343 minecraft:yellow_terracotta
setblock 17 105 353 minecraft:light[level=12]
setblock 17 105 360 minecraft:light[level=12]
setblock 18 105 323 minecraft:yellow_terracotta
fill 18 105 324 21 105 324 minecraft:honeycomb_block
setblock 18 105 363 minecraft:yellow_terracotta
fill 19 105 323 19 108 323 minecraft:honeycomb_block
setblock 19 105 362 minecraft:yellow_terracotta
fill 19 105 363 19 108 363 minecraft:honeycomb_block
setblock 20 105 362 minecraft:honeycomb_block
setblock 22 105 324 minecraft:yellow_terracotta
setblock 23 105 323 minecraft:yellow_terracotta
fill 23 105 324 26 105 324 minecraft:honeycomb_block
setblock 23 105 363 minecraft:yellow_terracotta
fill 24 105 323 24 108 323 minecraft:honeycomb_block
setblock 24 105 325 minecraft:light[level=12]
setblock 24 105 332 minecraft:light[level=12]
setblock 24 105 339 minecraft:light[level=12]
setblock 24 105 346 minecraft:light[level=12]
setblock 24 105 353 minecraft:light[level=12]
setblock 24 105 360 minecraft:light[level=12]
setblock 24 105 362 minecraft:yellow_terracotta
fill 24 105 363 24 108 363 minecraft:honeycomb_block
setblock 25 105 325 minecraft:honeycomb_block
fill 25 105 362 25 108 362 minecraft:honeycomb_block
setblock 26 105 325 minecraft:yellow_terracotta
fill 26 105 361 26 106 361 minecraft:honeycomb_block
setblock 27 105 324 minecraft:yellow_terracotta
fill 27 105 325 30 105 325 minecraft:honeycomb_block
setblock 28 105 323 minecraft:yellow_terracotta
fill 28 105 324 28 108 324 minecraft:honeycomb_block
setblock 28 105 363 minecraft:yellow_terracotta
fill 29 105 323 29 108 323 minecraft:honeycomb_block
setblock 29 105 362 minecraft:yellow_terracotta
fill 29 105 363 29 108 363 minecraft:honeycomb_block
setblock 30 105 361 minecraft:yellow_terracotta
fill 30 105 362 30 108 362 minecraft:honeycomb_block
setblock 31 105 325 minecraft:yellow_terracotta
setblock 31 105 332 minecraft:light[level=12]
setblock 31 105 339 minecraft:light[level=12]
setblock 31 105 346 minecraft:light[level=12]
setblock 31 105 353 minecraft:light[level=12]
setblock 31 105 360 minecraft:light[level=12]
fill 31 105 361 31 108 361 minecraft:honeycomb_block
setblock 31 105 364 minecraft:yellow_concrete
setblock 32 105 324 minecraft:yellow_terracotta
fill 32 105 325 32 108 325 minecraft:honeycomb_block
setblock 33 105 323 minecraft:yellow_terracotta
fill 33 105 324 33 108 324 minecraft:honeycomb_block
setblock 33 105 363 minecraft:yellow_terracotta
fill 34 105 323 34 108 323 minecraft:honeycomb_block
setblock 34 105 325 minecraft:honeycomb_block
setblock 34 105 362 minecraft:yellow_terracotta
fill 34 105 363 34 108 363 minecraft:honeycomb_block
setblock 35 105 361 minecraft:yellow_terracotta
fill 35 105 362 35 107 362 minecraft:honeycomb_block
setblock 37 105 324 minecraft:yellow_terracotta
fill 37 105 336 37 112 336 minecraft:brown_terracotta
setblock 38 105 323 minecraft:yellow_terracotta
setblock 38 105 325 minecraft:light[level=12]
setblock 38 105 332 minecraft:light[level=12]
setblock 38 105 339 minecraft:light[level=12]
setblock 38 105 346 minecraft:light[level=12]
setblock 38 105 353 minecraft:light[level=12]
setblock 38 105 360 minecraft:light[level=12]
setblock 38 105 363 minecraft:yellow_terracotta
fill 39 105 323 39 106 323 minecraft:honeycomb_block
setblock 39 105 346 minecraft:honeycomb_block
setblock 39 105 347 minecraft:yellow_terracotta
fill 39 105 348 39 107 348 minecraft:honeycomb_block
fill 39 105 363 39 106 363 minecraft:honeycomb_block
setblock 40 105 341 minecraft:yellow_terracotta
fill 40 105 342 40 107 342 minecraft:honeycomb_block
setblock 40 105 346 minecraft:yellow_terracotta
fill 40 105 347 40 108 347 minecraft:honeycomb_block
fill 41 105 323 41 105 324 minecraft:honeycomb_block
fill 41 105 334 41 106 334 minecraft:honey_block
setblock 41 105 340 minecraft:yellow_terracotta
fill 41 105 341 41 108 341 minecraft:honeycomb_block
setblock 41 105 345 minecraft:yellow_terracotta
fill 41 105 346 41 108 346 minecraft:honeycomb_block
setblock 41 105 349 minecraft:honeycomb_block
setblock 41 105 350 minecraft:yellow_terracotta
fill 41 105 351 41 108 351 minecraft:honeycomb_block
fill 41 105 353 41 106 353 minecraft:honeycomb_block
setblock 41 105 359 minecraft:honey_block
setblock 42 105 353 minecraft:orange_terracotta
fill 42 105 360 42 138 360 minecraft:honeycomb_block
fill 0 106 350 1 109 350 minecraft:honeycomb_block
setblock 1 106 323 minecraft:honeycomb_block
setblock 1 106 324 minecraft:yellow_terracotta
fill 1 106 325 1 106 328 minecraft:honeycomb_block
setblock 1 106 329 minecraft:yellow_terracotta
fill 1 106 330 1 108 331 minecraft:honeycomb_block
setblock 1 106 333 minecraft:honey_block
setblock 1 106 339 minecraft:yellow_terracotta
fill 1 106 340 1 109 340 minecraft:honeycomb_block
setblock 1 106 344 minecraft:yellow_terracotta
fill 1 106 345 1 109 345 minecraft:honeycomb_block
setblock 1 106 349 minecraft:yellow_terracotta
fill 1 106 351 1 108 351 minecraft:honeycomb_block
setblock 1 106 352 minecraft:honey_block
setblock 2 106 323 minecraft:yellow_terracotta
fill 2 106 325 2 107 326 minecraft:honeycomb_block
setblock 2 106 343 minecraft:yellow_terracotta
fill 2 106 344 2 109 344 minecraft:honeycomb_block
setblock 2 106 348 minecraft:yellow_terracotta
fill 3 106 323 3 109 323 minecraft:honeycomb_block
setblock 3 106 343 minecraft:honeycomb_block
setblock 4 106 330 minecraft:ochre_froglight
setblock 4 106 336 minecraft:ochre_froglight
setblock 4 106 342 minecraft:ochre_froglight
setblock 4 106 348 minecraft:ochre_froglight
setblock 4 106 354 minecraft:ochre_froglight
setblock 4 106 360 minecraft:ochre_froglight
fill 4 106 363 6 106 363 minecraft:honeycomb_block
setblock 5 106 325 minecraft:yellow_terracotta
setblock 6 106 323 minecraft:honeycomb_block
setblock 6 106 324 minecraft:yellow_terracotta
fill 6 106 325 9 106 325 minecraft:honeycomb_block
setblock 7 106 323 minecraft:yellow_terracotta
fill 7 106 324 7 109 324 minecraft:honeycomb_block
fill 7 106 326 8 106 326 minecraft:honeycomb_block
setblock 7 106 363 minecraft:yellow_terracotta
fill 8 106 323 8 109 323 minecraft:honeycomb_block
setblock 8 106 362 minecraft:yellow_terracotta
fill 8 106 363 8 109 363 minecraft:honeycomb_block
setblock 9 106 326 minecraft:yellow_terracotta
fill 9 106 362 9 108 362 minecraft:honeycomb_block
setblock 10 106 325 minecraft:yellow_terracotta
fill 10 106 326 10 109 326 minecraft:honeycomb_block
setblock 10 106 360 minecraft:ochre_froglight
setblock 11 106 324 minecraft:yellow_terracotta
fill 11 106 325 11 109 325 minecraft:honeycomb_block
setblock 12 106 323 minecraft:yellow_terracotta
fill 12 106 324 12 109 324 minecraft:honeycomb_block
setblock 12 106 363 minecraft:yellow_terracotta
fill 13 106 323 13 109 323 minecraft:honeycomb_block
setblock 13 106 326 minecraft:honeycomb_block
setblock 13 106 362 minecraft:yellow_terracotta
fill 13 106 363 13 109 363 minecraft:honeycomb_block
setblock 14 106 326 minecraft:yellow_terracotta
fill 14 106 362 14 107 362 minecraft:honeycomb_block
fill 15 106 322 15 225 322 minecraft:honeycomb_block
setblock 15 106 325 minecraft:yellow_terracotta
fill 15 106 326 15 107 326 minecraft:honeycomb_block
setblock 16 106 322 minecraft:yellow_concrete
setblock 16 106 324 minecraft:yellow_terracotta
fill 16 106 325 16 109 325 minecraft:honeycomb_block
setblock 16 106 360 minecraft:ochre_froglight
fill 17 106 322 17 134 322 minecraft:honeycomb_block
setblock 17 106 323 minecraft:yellow_terracotta
fill 17 106 324 20 106 324 minecraft:honeycomb_block
setblock 17 106 363 minecraft:yellow_terracotta
fill 18 106 323 18 109 323 minecraft:honeycomb_block
fill 18 106 363 18 109 363 minecraft:honeycomb_block
fill 20 106 325 20 107 325 minecraft:yellow_terracotta
setblock 20 106 326 minecraft:ochre_froglight
setblock 21 106 324 minecraft:yellow_terracotta
setblock 21 106 362 minecraft:brown_terracotta
setblock 22 106 323 minecraft:yellow_terracotta
fill 22 106 324 25 106 324 minecraft:honeycomb_block
setblock 22 106 360 minecraft:ochre_froglight
setblock 22 106 363 minecraft:yellow_terracotta
fill 23 106 323 23 109 323 minecraft:honeycomb_block
setblock 23 106 362 minecraft:yellow_terracotta
fill 23 106 363 23 109 363 minecraft:honeycomb_block
setblock 24 106 325 minecraft:honeycomb_block
fill 24 106 362 24 109 362 minecraft:honeycomb_block
setblock 25 106 325 minecraft:yellow_terracotta
setblock 26 106 324 minecraft:yellow_terracotta
fill 26 106 325 29 106 325 minecraft:honeycomb_block
setblock 26 106 326 minecraft:ochre_froglight
setblock 27 106 323 minecraft:yellow_terracotta
fill 27 106 324 27 109 324 minecraft:honeycomb_block
setblock 27 106 363 minecraft:yellow_terracotta
fill 28 106 323 28 109 323 minecraft:honeycomb_block
setblock 28 106 360 minecraft:ochre_froglight
setblock 28 106 362 minecraft:yellow_terracotta
fill 28 106 363 28 109 363 minecraft:honeycomb_block
setblock 29 106 361 minecraft:yellow_terracotta
fill 29 106 362 29 109 362 minecraft:honeycomb_block
setblock 30 106 325 minecraft:yellow_terracotta
fill 30 106 361 30 108 361 minecraft:honeycomb_block
setblock 31 106 324 minecraft:yellow_terracotta
fill 31 106 325 31 108 325 minecraft:honeycomb_block
fill 31 106 364 31 176 364 minecraft:honeycomb_block
setblock 32 106 323 minecraft:yellow_terracotta
fill 32 106 324 32 109 324 minecraft:honeycomb_block
setblock 32 106 326 minecraft:ochre_froglight
setblock 32 106 363 minecraft:yellow_terracotta
fill 33 106 323 33 109 323 minecraft:honeycomb_block
setblock 33 106 362 minecraft:yellow_terracotta
fill 33 106 363 33 109 363 minecraft:honeycomb_block
setblock 34 106 360 minecraft:ochre_froglight
fill 34 106 361 34 107 361 minecraft:yellow_terracotta
fill 34 106 362 34 108 362 minecraft:honeycomb_block
fill 36 106 324 36 107 324 minecraft:yellow_terracotta
setblock 37 106 323 minecraft:yellow_terracotta
setblock 37 106 363 minecraft:yellow_terracotta
fill 38 106 323 38 107 323 minecraft:honeycomb_block
setblock 38 106 326 minecraft:ochre_froglight
setblock 38 106 332 minecraft:ochre_froglight
setblock 38 106 338 minecraft:ochre_froglight
setblock 38 106 344 minecraft:ochre_froglight
setblock 38 106 350 minecraft:ochre_froglight
setblock 38 106 356 minecraft:ochre_froglight
fill 38 106 363 38 107 363 minecraft:honeycomb_block
setblock 39 106 346 minecraft:yellow_terracotta
fill 39 106 347 39 108 347 minecraft:honeycomb_block
setblock 40 106 345 minecraft:yellow_terracotta
fill 40 106 346 40 109 346 minecraft:honeycomb_block
setblock 40 106 350 minecraft:yellow_terracotta
fill 40 106 351 40 109 351 minecraft:honeycomb_block
setblock 41 106 323 minecraft:honeycomb_block
fill 41 106 324 41 107 324 minecraft:yellow_terracotta
fill 41 106 325 41 107 325 minecraft:honeycomb_block
setblock 41 106 328 minecraft:honey_block
fill 41 106 339 41 107 339 minecraft:yellow_terracotta
fill 41 106 340 41 108 340 minecraft:honeycomb_block
setblock 41 106 344 minecraft:yellow_terracotta
fill 41 106 345 41 109 345 minecraft:honeycomb_block
setblock 41 106 349 minecraft:yellow_terracotta
fill 41 106 350 41 109 350 minecraft:honeycomb_block
fill 42 106 353 42 153 353 minecraft:honeycomb_block
setblock 0 107 334 minecraft:yellow_concrete
setblock 1 107 323 minecraft:yellow_terracotta
fill 1 107 324 1 107 327 minecraft:honeycomb_block
setblock 1 107 328 minecraft:yellow_terracotta
fill 1 107 329 2 109 329 minecraft:honeycomb_block
setblock 1 107 332 minecraft:honeycomb_block
fill 1 107 333 4 107 336 minecraft:yellow_terracotta
fill 1 107 338 4 107 338 minecraft:yellow_terracotta
fill 1 107 339 1 109 339 minecraft:honeycomb_block
setblock 1 107 343 minecraft:yellow_terracotta
fill 1 107 344 1 110 344 minecraft:honeycomb_block
setblock 1 107 347 minecraft:honeycomb_block
setblock 1 107 348 minecraft:yellow_terracotta
fill 1 107 349 2 109 349 minecraft:honeycomb_block
fill 1 107 352 4 107 357 minecraft:yellow_terracotta
setblock 1 107 358 minecraft:honey_block
fill 1 107 359 1 107 363 minecraft:yellow_terracotta
fill 2 107 323 2 108 324 minecraft:honeycomb_block
fill 2 107 327 4 107 327 minecraft:yellow_terracotta
fill 2 107 328 2 110 328 minecraft:honeycomb_block
fill 2 107 330 4 107 332 minecraft:yellow_terracotta
fill 2 107 337 4 107 337 minecraft:yellow_terracotta
fill 2 107 339 4 107 340 minecraft:yellow_terracotta
fill 2 107 342 4 107 342 minecraft:yellow_terracotta
fill 2 107 343 2 109 343 minecraft:honeycomb_block
fill 2 107 345 2 108 345 minecraft:honeycomb_block
fill 2 107 347 4 107 347 minecraft:yellow_terracotta
fill 2 107 348 2 110 348 minecraft:honeycomb_block
fill 2 107 350 4 107 351 minecraft:yellow_terracotta
fill 2 107 358 4 107 362 minecraft:yellow_terracotta
fill 2 107 363 2 108 363 minecraft:honey_block
fill 3 107 325 4 107 326 minecraft:yellow_terracotta
fill 3 107 328 4 107 329 minecraft:yellow_terracotta
fill 3 107 341 4 107 341 minecraft:yellow_terracotta
fill 3 107 343 4 107 346 minecraft:yellow_terracotta
fill 3 107 348 4 107 349 minecraft:yellow_terracotta
fill 3 107 363 4 107 363 minecraft:yellow_terracotta
setblock 4 107 324 minecraft:honeycomb_block
setblock 5 107 324 minecraft:yellow_terracotta
fill 5 107 325 8 107 325 minecraft:honeycomb_block
setblock 5 107 326 minecraft:yellow_terracotta
fill 5 107 360 7 107 362 minecraft:yellow_terracotta
setblock 5 107 363 minecraft:honeycomb_block
setblock 6 107 323 minecraft:yellow_terracotta
fill 6 107 324 6 110 324 minecraft:honeycomb_block
fill 6 107 326 7 107 326 minecraft:honeycomb_block
setblock 6 107 363 minecraft:yellow_terracotta
fill 7 107 323 7 110 323 minecraft:honeycomb_block
fill 7 107 363 7 110 363 minecraft:honeycomb_block
setblock 8 107 326 minecraft:yellow_terracotta
fill 8 107 360 26 107 361 minecraft:yellow_terracotta
setblock 8 107 362 minecraft:honeycomb_block
setblock 9 107 322 minecraft:orange_terracotta
setblock 9 107 325 minecraft:yellow_terracotta
fill 9 107 326 9 110 326 minecraft:honeycomb_block
setblock 10 107 324 minecraft:yellow_terracotta
fill 10 107 325 10 110 325 minecraft:honeycomb_block
fill 10 107 327 11 107 327 minecraft:honeycomb_block
setblock 11 107 323 minecraft:yellow_terracotta
fill 11 107 324 11 110 324 minecraft:honeycomb_block
setblock 11 107 363 minecraft:yellow_terracotta
fill 12 107 323 12 110 323 minecraft:honeycomb_block
fill 12 107 350 13 108 350 minecraft:yellow_concrete
setblock 12 107 362 minecraft:yellow_terracotta
fill 12 107 363 12 110 363 minecraft:honeycomb_block
setblock 13 107 326 minecraft:yellow_terracotta
setblock 13 107 362 minecraft:honeycomb_block
setblock 14 107 325 minecraft:yellow_terracotta
fill 14 107 326 14 108 326 minecraft:honeycomb_block
setblock 15 107 324 minecraft:yellow_terracotta
fill 15 107 325 15 109 325 minecraft:honeycomb_block
fill 16 107 322 16 291 322 minecraft:honeycomb_block
setblock 16 107 323 minecraft:yellow_terracotta
fill 16 107 324 19 107 324 minecraft:honeycomb_block
fill 16 107 326 41 107 326 minecraft:yellow_terracotta
fill 16 107 362 16 107 363 minecraft:yellow_terracotta
fill 17 107 323 17 110 323 minecraft:honeycomb_block
fill 17 107 362 22 107 362 minecraft:yellow_terracotta
fill 17 107 363 17 109 363 minecraft:honeycomb_block
setblock 18 107 325 minecraft:honeycomb_block
setblock 19 107 325 minecraft:yellow_terracotta
setblock 20 107 324 minecraft:yellow_terracotta
setblock 21 107 323 minecraft:yellow_terracotta
fill 21 107 324 24 107 324 minecraft:honeycomb_block
fill 21 107 325 24 107 325 minecraft:yellow_terracotta
setblock 21 107 363 minecraft:yellow_terracotta
setblock 22 107 322 minecraft:orange_terracotta
fill 22 107 323 22 110 323 minecraft:honeycomb_block
fill 22 107 363 22 110 363 minecraft:honeycomb_block
fill 23 107 362 23 108 362 minecraft:honeycomb_block
setblock 25 107 324 minecraft:yellow_terracotta
fill 25 107 325 28 107 325 minecraft:honeycomb_block
setblock 26 107 323 minecraft:yellow_terracotta
fill 26 107 324 26 110 324 minecraft:honeycomb_block
setblock 26 107 363 minecraft:yellow_terracotta
fill 27 107 323 27 110 323 minecraft:honeycomb_block
fill 27 107 360 41 107 360 minecraft:yellow_terracotta
setblock 27 107 362 minecraft:yellow_terracotta
fill 27 107 363 27 110 363 minecraft:honeycomb_block
setblock 28 107 361 minecraft:yellow_terracotta
fill 28 107 362 28 110 362 minecraft:honeycomb_block
setblock 29 107 325 minecraft:yellow_terracotta
fill 29 107 361 29 108 361 minecraft:honeycomb_block
setblock 30 107 324 minecraft:yellow_terracotta
fill 30 107 325 30 109 325 minecraft:honeycomb_block
setblock 31 107 323 minecraft:yellow_terracotta
fill 31 107 324 31 110 324 minecraft:honeycomb_block
setblock 31 107 363 minecraft:yellow_terracotta
fill 32 107 323 32 110 323 minecraft:honeycomb_block
setblock 32 107 362 minecraft:yellow_terracotta
fill 32 107 363 32 110 363 minecraft:honeycomb_block
setblock 33 107 361 minecraft:yellow_terracotta
fill 33 107 362 33 108 362 minecraft:honeycomb_block
fill 34 107 325 40 107 325 minecraft:yellow_terracotta
setblock 34 107 364 minecraft:orange_terracotta
setblock 35 107 324 minecraft:yellow_terracotta
fill 35 107 361 41 107 361 minecraft:yellow_terracotta
setblock 36 107 323 minecraft:yellow_terracotta
fill 36 107 362 36 107 363 minecraft:yellow_terracotta
fill 37 107 323 37 108 323 minecraft:honeycomb_block
fill 37 107 324 40 107 324 minecraft:yellow_terracotta
fill 37 107 362 41 107 362 minecraft:yellow_terracotta
fill 37 107 363 37 108 363 minecraft:honeycomb_block
fill 38 107 327 38 107 359 minecraft:yellow_terracotta
fill 39 107 322 39 107 323 minecraft:yellow_terracotta
fill 39 107 327 39 107 345 minecraft:yellow_terracotta
setblock 39 107 346 minecraft:honeycomb_block
fill 39 107 349 39 107 359 minecraft:yellow_terracotta
setblock 39 107 363 minecraft:yellow_terracotta
setblock 40 107 323 minecraft:honey_block
fill 40 107 327 40 107 341 minecraft:yellow_terracotta
setblock 40 107 344 minecraft:yellow_terracotta
fill 40 107 345 40 110 345 minecraft:honeycomb_block
setblock 40 107 349 minecraft:yellow_terracotta
fill 40 107 350 40 110 350 minecraft:honeycomb_block
fill 40 107 352 40 107 359 minecraft:yellow_terracotta
setblock 40 107 363 minecraft:honey_block
setblock 41 107 323 minecraft:yellow_terracotta
fill 41 107 327 41 107 338 minecraft:yellow_terracotta
setblock 41 107 343 minecraft:yellow_terracotta
fill 41 107 344 41 110 344 minecraft:honeycomb_block
setblock 41 107 348 minecraft:yellow_terracotta
fill 41 107 349 41 110 349 minecraft:honeycomb_block
fill 41 107 353 41 107 359 minecraft:yellow_terracotta
setblock 41 107 363 minecraft:yellow_terracotta
setblock 42 107 359 minecraft:orange_terracotta
fill 0 108 334 1 110 334 minecraft:honeycomb_block
fill 1 108 323 1 108 326 minecraft:honeycomb_block
setblock 1 108 327 minecraft:yellow_terracotta
fill 1 108 328 1 111 328 minecraft:honeycomb_block
setblock 1 108 332 minecraft:yellow_terracotta
fill 1 108 333 1 111 333 minecraft:honeycomb_block
setblock 1 108 338 minecraft:honeycomb_block
setblock 1 108 342 minecraft:yellow_terracotta
fill 1 108 343 1 111 343 minecraft:honeycomb_block
setblock 1 108 347 minecraft:yellow_terracotta
fill 1 108 348 1 111 348 minecraft:honeycomb_block
setblock 2 108 325 minecraft:honeycomb_block
setblock 2 108 326 minecraft:yellow_terracotta
fill 2 108 327 2 111 327 minecraft:honeycomb_block
setblock 2 108 330 minecraft:honeycomb_block
setblock 2 108 342 minecraft:honeycomb_block
setblock 2 108 346 minecraft:yellow_terracotta
fill 2 108 347 2 110 347 minecraft:honeycomb_block
setblock 4 108 324 minecraft:yellow_terracotta
fill 4 108 325 7 108 325 minecraft:honeycomb_block
fill 4 108 326 4 108 360 minecraft:honey_block
setblock 5 108 323 minecraft:yellow_terracotta
fill 5 108 324 5 111 324 minecraft:honeycomb_block
setblock 5 108 326 minecraft:honey_block
fill 5 108 360 38 108 360 minecraft:honey_block
setblock 5 108 363 minecraft:yellow_terracotta
fill 6 108 323 6 111 323 minecraft:honeycomb_block
setblock 6 108 326 minecraft:honeycomb_block
fill 6 108 363 6 110 363 minecraft:honeycomb_block
setblock 7 108 326 minecraft:yellow_terracotta
setblock 8 108 325 minecraft:yellow_terracotta
fill 8 108 326 8 111 326 minecraft:honeycomb_block
fill 9 108 322 9 176 322 minecraft:honeycomb_block
setblock 9 108 324 minecraft:yellow_terracotta
fill 9 108 325 9 111 325 minecraft:honeycomb_block
setblock 10 108 323 minecraft:yellow_terracotta
fill 10 108 324 10 111 324 minecraft:honeycomb_block
setblock 10 108 327 minecraft:honeycomb_block
setblock 10 108 363 minecraft:yellow_terracotta
fill 11 108 323 11 111 323 minecraft:honeycomb_block
setblock 11 108 362 minecraft:yellow_terracotta
fill 11 108 363 11 111 363 minecraft:honeycomb_block
setblock 12 108 326 minecraft:yellow_terracotta
setblock 12 108 362 minecraft:honeycomb_block
setblock 13 108 325 minecraft:yellow_terracotta
fill 13 108 326 13 109 326 minecraft:honeycomb_block
setblock 14 108 324 minecraft:yellow_terracotta
fill 14 108 325 14 110 325 minecraft:honeycomb_block
setblock 15 108 323 minecraft:yellow_terracotta
fill 15 108 324 18 108 324 minecraft:honeycomb_block
fill 15 108 326 38 108 326 minecraft:honey_block
setblock 15 108 363 minecraft:yellow_terracotta
fill 16 108 323 16 111 323 minecraft:honeycomb_block
fill 16 108 363 16 109 363 minecraft:honeycomb_block
setblock 19 108 324 minecraft:yellow_terracotta
setblock 20 108 323 minecraft:yellow_terracotta
fill 20 108 324 23 108 324 minecraft:honeycomb_block
setblock 20 108 363 minecraft:yellow_terracotta
fill 21 108 323 21 111 323 minecraft:honeycomb_block
fill 21 108 363 21 110 363 minecraft:honeycomb_block
fill 22 108 322 22 114 322 minecraft:honeycomb_block
setblock 24 108 324 minecraft:yellow_terracotta
fill 24 108 325 27 108 325 minecraft:honeycomb_block
setblock 25 108 323 minecraft:yellow_terracotta
fill 25 108 324 25 111 324 minecraft:honeycomb_block
setblock 25 108 363 minecraft:yellow_terracotta
fill 26 108 323 26 111 323 minecraft:honeycomb_block
setblock 26 108 362 minecraft:yellow_terracotta
fill 26 108 363 26 111 363 minecraft:honeycomb_block
setblock 27 108 361 minecraft:yellow_terracotta
fill 27 108 362 27 111 362 minecraft:honeycomb_block
setblock 28 108 325 minecraft:yellow_terracotta
setblock 28 108 361 minecraft:honeycomb_block
setblock 29 108 324 minecraft:yellow_terracotta
fill 29 108 325 29 109 325 minecraft:honeycomb_block
setblock 30 108 323 minecraft:yellow_terracotta
fill 30 108 324 30 111 324 minecraft:honeycomb_block
setblock 30 108 363 minecraft:yellow_terracotta
fill 31 108 323 31 111 323 minecraft:honeycomb_block
setblock 31 108 362 minecraft:yellow_terracotta
fill 31 108 363 31 111 363 minecraft:honeycomb_block
fill 32 108 362 32 109 362 minecraft:honeycomb_block
setblock 34 108 324 minecraft:yellow_terracotta
fill 34 108 364 34 135 364 minecraft:honeycomb_block
setblock 35 108 323 minecraft:yellow_terracotta
setblock 35 108 363 minecraft:yellow_terracotta
setblock 36 108 323 minecraft:honeycomb_block
setblock 36 108 363 minecraft:honeycomb_block
fill 38 108 327 38 108 359 minecraft:honey_block
fill 39 108 322 39 119 322 minecraft:honeycomb_block
setblock 40 108 343 minecraft:yellow_terracotta
fill 40 108 344 40 109 344 minecraft:honeycomb_block
setblock 40 108 348 minecraft:yellow_terracotta
fill 40 108 349 40 111 349 minecraft:honeycomb_block
setblock 41 108 342 minecraft:yellow_terracotta
fill 41 108 343 41 111 343 minecraft:honeycomb_block
setblock 41 108 347 minecraft:yellow_terracotta
fill 41 108 348 41 111 348 minecraft:honeycomb_block
setblock 41 108 352 minecraft:yellow_terracotta
fill 41 108 353 41 111 353 minecraft:honeycomb_block
setblock 41 108 360 minecraft:honey_block
fill 42 108 359 42 112 359 minecraft:honeycomb_block
setblock 0 109 332 minecraft:yellow_terracotta
fill 1 109 323 1 109 325 minecraft:honeycomb_block
setblock 1 109 326 minecraft:yellow_terracotta
fill 1 109 327 1 112 327 minecraft:honeycomb_block
setblock 1 109 330 minecraft:honeycomb_block
setblock 1 109 331 minecraft:yellow_terracotta
fill 1 109 332 1 112 332 minecraft:honeycomb_block
setblock 1 109 341 minecraft:yellow_terracotta
fill 1 109 342 1 110 342 minecraft:honeycomb_block
setblock 1 109 346 minecraft:yellow_terracotta
fill 1 109 347 1 112 347 minecraft:honeycomb_block
setblock 1 109 351 minecraft:yellow_terracotta
fill 2 109 323 2 110 323 minecraft:honeycomb_block
setblock 2 109 325 minecraft:yellow_terracotta
fill 2 109 326 2 112 326 minecraft:honeycomb_block
setblock 2 109 330 minecraft:yellow_terracotta
fill 2 109 331 2 112 331 minecraft:honeycomb_block
setblock 2 109 345 minecraft:yellow_terracotta
fill 2 109 346 2 110 346 minecraft:honeycomb_block
setblock 3 109 324 minecraft:yellow_terracotta
setblock 4 109 323 minecraft:yellow_terracotta
fill 4 109 324 4 111 325 minecraft:honeycomb_block
fill 5 109 323 5 112 323 minecraft:honeycomb_block
fill 5 109 325 6 109 325 minecraft:honeycomb_block
setblock 6 109 326 minecraft:yellow_terracotta
setblock 7 109 325 minecraft:yellow_terracotta
fill 7 109 326 7 112 326 minecraft:honeycomb_block
setblock 8 109 324 minecraft:yellow_terracotta
fill 8 109 325 8 112 325 minecraft:honeycomb_block
setblock 9 109 323 minecraft:yellow_terracotta
fill 9 109 324 9 112 324 minecraft:honeycomb_block
setblock 9 109 363 minecraft:yellow_terracotta
fill 10 109 323 10 112 323 minecraft:honeycomb_block
fill 10 109 363 10 112 363 minecraft:honeycomb_block
setblock 11 109 326 minecraft:yellow_terracotta
setblock 12 109 325 minecraft:yellow_terracotta
fill 12 109 326 12 110 326 minecraft:honeycomb_block
setblock 13 109 324 minecraft:yellow_terracotta
fill 13 109 325 13 111 325 minecraft:honeycomb_block
setblock 14 109 323 minecraft:yellow_terracotta
fill 14 109 324 17 109 324 minecraft:honeycomb_block
setblock 14 109 363 minecraft:yellow_terracotta
fill 15 109 323 15 112 323 minecraft:honeycomb_block
setblock 15 109 363 minecraft:honeycomb_block
setblock 18 109 322 minecraft:orange_terracotta
setblock 18 109 324 minecraft:yellow_terracotta
setblock 19 109 323 minecraft:yellow_terracotta
fill 19 109 324 22 109 324 minecraft:honeycomb_block
setblock 19 109 363 minecraft:yellow_terracotta
fill 20 109 323 20 112 323 minecraft:honeycomb_block
setblock 20 109 363 minecraft:honeycomb_block
setblock 23 109 324 minecraft:yellow_terracotta
setblock 24 109 323 minecraft:yellow_terracotta
fill 24 109 324 24 112 324 minecraft:honeycomb_block
setblock 24 109 363 minecraft:yellow_terracotta
fill 25 109 323 25 112 323 minecraft:honeycomb_block
fill 25 109 325 26 109 325 minecraft:honeycomb_block
setblock 25 109 362 minecraft:yellow_terracotta
fill 25 109 363 25 112 363 minecraft:honeycomb_block
fill 26 109 362 26 112 362 minecraft:honeycomb_block
setblock 27 109 325 minecraft:yellow_terracotta
setblock 28 109 324 minecraft:yellow_terracotta
setblock 28 109 325 minecraft:honeycomb_block
setblock 29 109 323 minecraft:yellow_terracotta
fill 29 109 324 29 111 324 minecraft:honeycomb_block
setblock 29 109 363 minecraft:yellow_terracotta
fill 30 109 323 30 112 323 minecraft:honeycomb_block
setblock 30 109 362 minecraft:yellow_terracotta
fill 30 109 363 30 112 363 minecraft:honeycomb_block
fill 31 109 362 31 110 362 minecraft:honeycomb_block
setblock 33 109 324 minecraft:yellow_terracotta
setblock 34 109 323 minecraft:yellow_terracotta
setblock 34 109 363 minecraft:yellow_terracotta
setblock 35 109 323 minecraft:honeycomb_block
setblock 35 109 363 minecraft:honeycomb_block
fill 36 109 336 36 112 336 minecraft:brown_terracotta
fill 37 109 335 37 112 335 minecraft:brown_terracotta
fill 37 109 337 37 112 337 minecraft:brown_terracotta
fill 38 109 336 38 112 336 minecraft:brown_terracotta
setblock 40 109 347 minecraft:yellow_terracotta
fill 40 109 348 40 112 348 minecraft:honeycomb_block
setblock 41 109 335 minecraft:honey_block
setblock 41 109 341 minecraft:yellow_terracotta
fill 41 109 342 41 111 342 minecraft:honeycomb_block
setblock 41 109 346 minecraft:yellow_terracotta
fill 41 109 347 41 112 347 minecraft:honeycomb_block
setblock 41 109 351 minecraft:yellow_terracotta
fill 41 109 352 41 112 352 minecraft:honeycomb_block
setblock 41 109 354 minecraft:honey_block
fill 0 110 332 0 134 332 minecraft:honeycomb_block
fill 0 110 350 0 121 350 minecraft:honeycomb_block
setblock 0 110 360 minecraft:orange_terracotta
fill 1 110 323 1 110 324 minecraft:honeycomb_block
setblock 1 110 325 minecraft:yellow_terracotta
fill 1 110 326 1 113 326 minecraft:honeycomb_block
setblock 1 110 329 minecraft:honeycomb_block
setblock 1 110 330 minecraft:yellow_terracotta
fill 1 110 331 1 113 331 minecraft:honeycomb_block
setblock 1 110 335 minecraft:yellow_terracotta
setblock 1 110 338 minecraft:honey_block
setblock 1 110 341 minecraft:honeycomb_block
setblock 1 110 345 minecraft:yellow_terracotta
fill 1 110 346 1 113 346 minecraft:honeycomb_block
setblock 1 110 349 minecraft:honeycomb_block
setblock 1 110 350 minecraft:yellow_terracotta
fill 1 110 351 1 113 351 minecraft:honeycomb_block
setblock 1 110 357 minecraft:honey_block
fill 2 110 325 2 113 325 minecraft:honeycomb_block
setblock 2 110 329 minecraft:yellow_terracotta
fill 2 110 330 2 113 330 minecraft:honeycomb_block
fill 2 110 332 2 111 332 minecraft:honeycomb_block
setblock 3 110 323 minecraft:yellow_terracotta
fill 3 110 324 3 113 324 minecraft:honeycomb_block
setblock 3 110 327 minecraft:honeycomb_block
setblock 3 110 328 minecraft:yellow_terracotta
fill 3 110 329 3 113 329 minecraft:honeycomb_block
fill 4 110 323 4 113 323 minecraft:honeycomb_block
setblock 5 110 325 minecraft:honeycomb_block
setblock 6 110 325 minecraft:yellow_terracotta
fill 6 110 326 6 111 326 minecraft:honeycomb_block
setblock 7 110 324 minecraft:yellow_terracotta
fill 7 110 325 7 113 325 minecraft:honeycomb_block
setblock 8 110 323 minecraft:yellow_terracotta
fill 8 110 324 8 113 324 minecraft:honeycomb_block
setblock 8 110 363 minecraft:yellow_terracotta
fill 9 110 323 9 113 323 minecraft:honeycomb_block
fill 9 110 363 9 112 363 minecraft:honeycomb_block
setblock 10 110 326 minecraft:yellow_terracotta
setblock 11 110 325 minecraft:yellow_terracotta
setblock 11 110 326 minecraft:honeycomb_block
setblock 12 110 324 minecraft:yellow_terracotta
fill 12 110 325 12 111 325 minecraft:honeycomb_block
setblock 13 110 323 minecraft:yellow_terracotta
fill 13 110 324 16 110 324 minecraft:honeycomb_block
setblock 13 110 363 minecraft:yellow_terracotta
fill 14 110 323 14 113 323 minecraft:honeycomb_block
setblock 14 110 363 minecraft:honeycomb_block
setblock 17 110 324 minecraft:yellow_terracotta
setblock 17 110 364 minecraft:yellow_concrete
fill 18 110 322 18 308 322 minecraft:honeycomb_block
setblock 18 110 323 minecraft:yellow_terracotta
setblock 18 110 324 minecraft:honeycomb_block
fill 19 110 323 19 111 323 minecraft:honeycomb_block
setblock 20 110 363 minecraft:honey_block
setblock 21 110 324 minecraft:honeycomb_block
setblock 22 110 324 minecraft:yellow_terracotta
setblock 23 110 323 minecraft:yellow_terracotta
fill 23 110 324 23 111 324 minecraft:honeycomb_block
setblock 23 110 363 minecraft:yellow_terracotta
fill 24 110 323 24 113 323 minecraft:honeycomb_block
fill 24 110 363 24 113 363 minecraft:honeycomb_block
fill 25 110 362 25 111 362 minecraft:honeycomb_block
fill 26 110 352 27 111 352 minecraft:honey_block
setblock 27 110 324 minecraft:yellow_terracotta
setblock 27 110 325 minecraft:honeycomb_block
setblock 28 110 323 minecraft:yellow_terracotta
fill 28 110 324 28 112 324 minecraft:honeycomb_block
setblock 28 110 363 minecraft:yellow_terracotta
fill 29 110 323 29 113 323 minecraft:honeycomb_block
setblock 29 110 362 minecraft:yellow_terracotta
fill 29 110 363 29 113 363 minecraft:honeycomb_block
setblock 30 110 362 minecraft:honeycomb_block
setblock 33 110 323 minecraft:yellow_terracotta
setblock 33 110 363 minecraft:yellow_terracotta
setblock 39 110 363 minecraft:honey_block
setblock 40 110 346 minecraft:yellow_terracotta
fill 40 110 347 40 112 347 minecraft:honeycomb_block
setblock 40 110 351 minecraft:yellow_terracotta
setblock 41 110 329 minecraft:honey_block
setblock 41 110 345 minecraft:yellow_terracotta
fill 41 110 346 41 113 346 minecraft:honeycomb_block
setblock 41 110 350 minecraft:yellow_terracotta
fill 41 110 351 41 113 351 minecraft:honeycomb_block
setblock 42 110 358 minecraft:orange_terracotta
fill 0 111 334 0 113 334 minecraft:honeycomb_block
fill 0 111 360 0 222 360 minecraft:honeycomb_block
setblock 1 111 324 minecraft:yellow_terracotta
fill 1 111 325 1 114 325 minecraft:honeycomb_block
setblock 1 111 329 minecraft:yellow_terracotta
fill 1 111 330 1 114 330 minecraft:honeycomb_block
setblock 1 111 334 minecraft:yellow_terracotta
fill 1 111 335 1 114 335 minecraft:honeycomb_block
setblock 1 111 344 minecraft:yellow_terracotta
fill 1 111 345 1 113 345 minecraft:honeycomb_block
setblock 1 111 349 minecraft:yellow_terracotta
fill 1 111 350 1 114 350 minecraft:honeycomb_block
setblock 1 111 363 minecraft:honey_block
setblock 2 111 323 minecraft:yellow_terracotta
setblock 2 111 328 minecraft:yellow_terracotta
fill 2 111 329 2 114 329 minecraft:honeycomb_block
setblock 2 111 333 minecraft:yellow_terracotta
fill 3 111 323 3 114 323 minecraft:honeycomb_block
setblock 3 111 325 minecraft:light[level=15]
setblock 3 111 327 minecraft:yellow_terracotta
fill 3 111 328 3 114 328 minecraft:honeycomb_block
fill 3 111 330 3 112 330 minecraft:honeycomb_block
setblock 3 111 332 minecraft:light[level=12]
setblock 3 111 333 minecraft:light[level=15]
setblock 3 111 339 minecraft:light[level=12]
setblock 3 111 341 minecraft:light[level=15]
setblock 3 111 346 minecraft:light[level=12]
setblock 3 111 349 minecraft:light[level=15]
setblock 3 111 353 minecraft:light[level=12]
setblock 3 111 357 minecraft:light[level=15]
setblock 3 111 360 minecraft:light[level=12]
setblock 5 111 325 minecraft:yellow_terracotta
setblock 6 111 324 minecraft:yellow_terracotta
fill 6 111 325 6 114 325 minecraft:honeycomb_block
setblock 7 111 323 minecraft:yellow_terracotta
fill 7 111 324 7 114 324 minecraft:honeycomb_block
setblock 7 111 363 minecraft:yellow_terracotta
fill 8 111 323 8 114 323 minecraft:honeycomb_block
fill 8 111 363 8 112 363 minecraft:honeycomb_block
setblock 9 111 326 minecraft:yellow_terracotta
setblock 10 111 325 minecraft:yellow_terracotta
setblock 10 111 326 minecraft:honeycomb_block
setblock 10 111 332 minecraft:light[level=12]
setblock 10 111 339 minecraft:light[level=12]
setblock 10 111 346 minecraft:light[level=12]
setblock 10 111 353 minecraft:light[level=12]
setblock 10 111 360 minecraft:light[level=12]
setblock 11 111 324 minecraft:yellow_terracotta
fill 11 111 325 11 112 325 minecraft:honeycomb_block
setblock 11 111 333 minecraft:light[level=15]
setblock 11 111 341 minecraft:light[level=15]
setblock 11 111 349 minecraft:light[level=15]
setblock 11 111 357 minecraft:light[level=15]
setblock 12 111 323 minecraft:yellow_terracotta
fill 12 111 324 15 111 324 minecraft:honeycomb_block
setblock 12 111 363 minecraft:yellow_terracotta
fill 13 111 323 13 114 323 minecraft:honeycomb_block
setblock 17 111 323 minecraft:yellow_terracotta
setblock 17 111 325 minecraft:light[level=12]
setblock 17 111 332 minecraft:light[level=12]
setblock 17 111 339 minecraft:light[level=12]
setblock 17 111 353 minecraft:light[level=12]
setblock 17 111 360 minecraft:light[level=12]
fill 17 111 364 17 122 364 minecraft:honeycomb_block
setblock 18 111 323 minecraft:honeycomb_block
setblock 19 111 325 minecraft:light[level=15]
setblock 19 111 333 minecraft:light[level=15]
setblock 19 111 341 minecraft:light[level=15]
setblock 19 111 349 minecraft:light[level=15]
setblock 19 111 357 minecraft:light[level=15]
setblock 22 111 323 minecraft:yellow_terracotta
setblock 22 111 363 minecraft:yellow_terracotta
fill 23 111 323 23 114 323 minecraft:honeycomb_block
fill 23 111 363 23 114 363 minecraft:honeycomb_block
setblock 24 111 325 minecraft:light[level=12]
setblock 24 111 332 minecraft:light[level=12]
setblock 24 111 339 minecraft:light[level=12]
setblock 24 111 346 minecraft:light[level=12]
setblock 24 111 353 minecraft:light[level=12]
setblock 24 111 360 minecraft:light[level=12]
setblock 26 111 324 minecraft:yellow_terracotta
setblock 27 111 323 minecraft:yellow_terracotta
fill 27 111 324 27 112 324 minecraft:honeycomb_block
setblock 27 111 325 minecraft:light[level=15]
setblock 27 111 333 minecraft:light[level=15]
setblock 27 111 341 minecraft:light[level=15]
setblock 27 111 349 minecraft:light[level=15]
setblock 27 111 357 minecraft:light[level=15]
setblock 27 111 363 minecraft:yellow_terracotta
fill 28 111 323 28 114 323 minecraft:honeycomb_block
setblock 28 111 362 minecraft:yellow_terracotta
fill 28 111 363 28 114 363 minecraft:honeycomb_block
setblock 29 111 362 minecraft:honeycomb_block
setblock 31 111 325 minecraft:light[level=12]
setblock 31 111 332 minecraft:light[level=12]
setblock 31 111 339 minecraft:light[level=12]
setblock 31 111 346 minecraft:light[level=12]
setblock 31 111 353 minecraft:light[level=12]
setblock 31 111 360 minecraft:light[level=12]
setblock 32 111 323 minecraft:yellow_terracotta
setblock 32 111 363 minecraft:yellow_terracotta
setblock 35 111 325 minecraft:light[level=15]
setblock 35 111 333 minecraft:light[level=15]
setblock 35 111 341 minecraft:light[level=15]
setblock 35 111 349 minecraft:light[level=15]
setblock 35 111 357 minecraft:light[level=15]
fill 36 111 335 36 112 335 minecraft:brown_terracotta
fill 36 111 337 36 112 337 minecraft:brown_terracotta
fill 37 111 352 37 112 352 minecraft:yellow_concrete
setblock 38 111 325 minecraft:light[level=12]
setblock 38 111 332 minecraft:light[level=12]
fill 38 111 335 38 112 335 minecraft:brown_terracotta
fill 38 111 337 38 112 337 minecraft:brown_terracotta
setblock 38 111 339 minecraft:light[level=12]
setblock 38 111 346 minecraft:light[level=12]
setblock 38 111 353 minecraft:light[level=12]
setblock 38 111 360 minecraft:light[level=12]
setblock 40 111 346 minecraft:honeycomb_block
setblock 40 111 350 minecraft:yellow_terracotta
fill 40 111 351 40 114 351 minecraft:honeycomb_block
setblock 41 111 323 minecraft:honey_block
setblock 41 111 328 minecraft:honeycomb_block
setblock 41 111 329 minecraft:yellow_terracotta
fill 41 111 330 41 114 330 minecraft:honeycomb_block
setblock 41 111 344 minecraft:yellow_terracotta
fill 41 111 345 41 114 345 minecraft:honeycomb_block
setblock 41 111 349 minecraft:yellow_terracotta
fill 41 111 350 41 114 350 minecraft:honeycomb_block
setblock 41 111 354 minecraft:yellow_terracotta
fill 42 111 358 42 112 358 minecraft:honeycomb_block
fill 1 112 324 1 115 324 minecraft:honeycomb_block
setblock 1 112 328 minecraft:yellow_terracotta
fill 1 112 329 1 115 329 minecraft:honeycomb_block
setblock 1 112 333 minecraft:yellow_terracotta
fill 1 112 334 2 114 334 minecraft:honeycomb_block
fill 1 112 336 1 113 336 minecraft:honeycomb_block
setblock 1 112 344 minecraft:honeycomb_block
setblock 1 112 348 minecraft:yellow_terracotta
fill 1 112 349 1 115 349 minecraft:honeycomb_block
fill 2 112 323 2 115 323 minecraft:honeycomb_block
setblock 2 112 327 minecraft:yellow_terracotta
fill 2 112 328 2 115 328 minecraft:honeycomb_block
setblock 2 112 332 minecraft:yellow_terracotta
fill 2 112 333 2 115 333 minecraft:honeycomb_block
fill 3 112 327 3 115 327 minecraft:honeycomb_block
setblock 3 112 331 minecraft:yellow_terracotta
setblock 4 112 324 minecraft:honeycomb_block
setblock 4 112 325 minecraft:yellow_terracotta
setblock 5 112 324 minecraft:yellow_terracotta
fill 5 112 325 5 115 325 minecraft:honeycomb_block
setblock 6 112 323 minecraft:yellow_terracotta
fill 6 112 324 6 115 324 minecraft:honeycomb_block
fill 7 112 323 7 115 323 minecraft:honeycomb_block
setblock 7 112 363 minecraft:honey_block
setblock 8 112 326 minecraft:yellow_terracotta
setblock 9 112 325 minecraft:yellow_terracotta
setblock 9 112 326 minecraft:honeycomb_block
setblock 10 112 324 minecraft:yellow_terracotta
fill 10 112 325 10 113 325 minecraft:honeycomb_block
setblock 11 112 323 minecraft:yellow_terracotta
fill 11 112 324 13 112 324 minecraft:honeycomb_block
fill 12 112 323 12 115 323 minecraft:honeycomb_block
setblock 16 112 323 minecraft:yellow_terracotta
setblock 17 112 323 minecraft:honeycomb_block
setblock 21 112 323 minecraft:yellow_terracotta
fill 22 112 323 22 115 323 minecraft:honeycomb_block
fill 22 112 363 22 115 363 minecraft:honeycomb_block
setblock 25 112 324 minecraft:yellow_terracotta
setblock 26 112 323 minecraft:yellow_terracotta
setblock 26 112 324 minecraft:honeycomb_block
setblock 26 112 363 minecraft:yellow_terracotta
fill 27 112 323 27 115 323 minecraft:honeycomb_block
setblock 27 112 362 minecraft:yellow_terracotta
fill 27 112 363 27 115 363 minecraft:honeycomb_block
setblock 31 112 363 minecraft:yellow_terracotta
setblock 32 112 363 minecraft:honey_block
setblock 35 112 323 minecraft:honey_block
setblock 40 112 349 minecraft:yellow_terracotta
fill 40 112 350 40 115 350 minecraft:honeycomb_block
setblock 41 112 328 minecraft:yellow_terracotta
fill 41 112 329 41 115 329 minecraft:honeycomb_block
fill 41 112 331 41 112 332 minecraft:honeycomb_block
setblock 41 112 336 minecraft:honey_block
setblock 41 112 343 minecraft:yellow_terracotta
fill 41 112 344 41 115 344 minecraft:honeycomb_block
setblock 41 112 348 minecraft:yellow_terracotta
fill 41 112 349 41 115 349 minecraft:honeycomb_block
setblock 41 112 353 minecraft:yellow_terracotta
fill 41 112 354 41 115 354 minecraft:honeycomb_block
setblock 41 112 361 minecraft:honey_block
setblock 1 113 327 minecraft:yellow_terracotta
fill 1 113 328 1 116 328 minecraft:honeycomb_block
setblock 1 113 332 minecraft:yellow_terracotta
fill 1 113 333 1 116 333 minecraft:honeycomb_block
setblock 1 113 337 minecraft:yellow_terracotta
setblock 1 113 347 minecraft:yellow_terracotta
fill 1 113 348 1 116 348 minecraft:honeycomb_block
setblock 1 113 352 minecraft:yellow_terracotta
setblock 1 113 356 minecraft:honey_block
setblock 2 113 326 minecraft:yellow_terracotta
fill 2 113 327 2 116 327 minecraft:honeycomb_block
setblock 2 113 331 minecraft:yellow_terracotta
fill 2 113 332 3 115 332 minecraft:honeycomb_block
setblock 2 113 335 minecraft:honeycomb_block
setblock 3 113 330 minecraft:yellow_terracotta
fill 3 113 331 3 116 331 minecraft:honeycomb_block
fill 3 113 333 3 114 333 minecraft:honeycomb_block
setblock 4 113 324 minecraft:yellow_terracotta
setblock 5 113 323 minecraft:yellow_terracotta
fill 5 113 324 5 116 324 minecraft:honeycomb_block
fill 6 113 323 6 116 323 minecraft:honeycomb_block
setblock 8 113 325 minecraft:yellow_terracotta
setblock 9 113 324 minecraft:yellow_terracotta
fill 9 113 325 9 114 325 minecraft:honeycomb_block
setblock 10 113 323 minecraft:yellow_terracotta
fill 10 113 324 12 113 324 minecraft:honeycomb_block
fill 11 113 323 11 116 323 minecraft:honeycomb_block
setblock 13 113 363 minecraft:honey_block
fill 21 113 323 21 116 323 minecraft:honeycomb_block
setblock 25 113 323 minecraft:yellow_terracotta
fill 25 113 363 25 113 364 minecraft:yellow_terracotta
fill 26 113 323 26 116 323 minecraft:honeycomb_block
fill 26 113 363 26 116 363 minecraft:honeycomb_block
setblock 30 113 363 minecraft:yellow_terracotta
setblock 38 113 363 minecraft:honey_block
setblock 40 113 348 minecraft:yellow_terracotta
fill 40 113 349 40 116 349 minecraft:honeycomb_block
setblock 41 113 327 minecraft:yellow_terracotta
fill 41 113 328 41 116 328 minecraft:honeycomb_block
setblock 41 113 331 minecraft:honeycomb_block
setblock 41 113 332 minecraft:yellow_terracotta
fill 41 113 333 41 114 335 minecraft:honeycomb_block
fill 41 113 343 41 116 343 minecraft:honeycomb_block
setblock 41 113 347 minecraft:yellow_terracotta
fill 41 113 348 41 116 348 minecraft:honeycomb_block
setblock 41 113 352 minecraft:yellow_terracotta
fill 41 113 353 41 116 353 minecraft:honeycomb_block
setblock 41 113 355 minecraft:honey_block
setblock 42 113 358 minecraft:orange_terracotta
setblock 42 113 359 minecraft:yellow_terracotta
setblock 0 114 334 minecraft:yellow_concrete
setblock 1 114 326 minecraft:yellow_terracotta
fill 1 114 327 1 117 327 minecraft:honeycomb_block
setblock 1 114 331 minecraft:yellow_terracotta
fill 1 114 332 1 117 332 minecraft:honeycomb_block
setblock 1 114 336 minecraft:yellow_terracotta
fill 1 114 337 1 116 338 minecraft:honeycomb_block
setblock 1 114 346 minecraft:yellow_terracotta
fill 1 114 347 1 117 347 minecraft:honeycomb_block
setblock 1 114 351 minecraft:yellow_terracotta
fill 1 114 352 1 116 353 minecraft:honeycomb_block
setblock 1 114 362 minecraft:honey_block
setblock 2 114 325 minecraft:yellow_terracotta
fill 2 114 326 3 116 326 minecraft:honeycomb_block
setblock 2 114 330 minecraft:yellow_terracotta
fill 2 114 331 2 117 331 minecraft:honeycomb_block
setblock 2 114 335 minecraft:yellow_terracotta
fill 2 114 336 2 117 336 minecraft:honeycomb_block
setblock 3 114 324 minecraft:yellow_terracotta
setblock 3 114 329 minecraft:yellow_terracotta
fill 3 114 330 4 116 330 minecraft:honeycomb_block
setblock 3 114 334 minecraft:yellow_terracotta
setblock 4 114 323 minecraft:yellow_terracotta
fill 4 114 324 4 116 325 minecraft:honeycomb_block
fill 4 114 329 4 117 329 minecraft:honeycomb_block
fill 4 114 331 4 115 331 minecraft:honeycomb_block
fill 5 114 323 5 117 323 minecraft:honeycomb_block
setblock 7 114 325 minecraft:yellow_terracotta
setblock 8 114 324 minecraft:yellow_terracotta
fill 8 114 325 8 116 325 minecraft:honeycomb_block
setblock 9 114 323 minecraft:yellow_terracotta
fill 9 114 324 11 114 324 minecraft:honeycomb_block
fill 10 114 323 10 117 323 minecraft:honeycomb_block
fill 17 114 323 17 115 323 minecraft:honey_block
setblock 19 114 363 minecraft:honey_block
fill 21 114 363 21 116 363 minecraft:honeycomb_block
setblock 24 114 322 minecraft:orange_terracotta
setblock 24 114 323 minecraft:yellow_terracotta
setblock 24 114 363 minecraft:yellow_terracotta
fill 25 114 323 25 117 323 minecraft:honeycomb_block
fill 25 114 363 25 117 364 minecraft:honeycomb_block
setblock 29 114 363 minecraft:yellow_terracotta
fill 40 114 348 40 117 348 minecraft:honeycomb_block
setblock 40 114 352 minecraft:yellow_terracotta
setblock 41 114 324 minecraft:honey_block
fill 41 114 327 41 117 327 minecraft:honeycomb_block
setblock 41 114 331 minecraft:yellow_terracotta
fill 41 114 332 41 117 332 minecraft:honeycomb_block
setblock 41 114 336 minecraft:yellow_terracotta
fill 41 114 337 41 116 338 minecraft:honeycomb_block
fill 41 114 342 41 117 342 minecraft:honeycomb_block
setblock 41 114 346 minecraft:yellow_terracotta
fill 41 114 347 41 117 347 minecraft:honeycomb_block
setblock 41 114 351 minecraft:yellow_terracotta
fill 41 114 352 41 117 352 minecraft:honeycomb_block
setblock 41 114 355 minecraft:honeycomb_block
fill 42 114 358 42 150 359 minecraft:honeycomb_block
setblock 42 114 363 minecraft:yellow_terracotta
fill 0 115 325 0 166 326 minecraft:honeycomb_block
setblock 0 115 327 minecraft:orange_terracotta
fill 0 115 328 0 220 328 minecraft:honeycomb_block
fill 0 115 334 1 115 334 minecraft:honeycomb_block
fill 1 115 323 1 116 323 minecraft:honeycomb_block
setblock 1 115 325 minecraft:yellow_terracotta
fill 1 115 326 1 118 326 minecraft:honeycomb_block
setblock 1 115 330 minecraft:yellow_terracotta
fill 1 115 331 1 118 331 minecraft:honeycomb_block
setblock 1 115 335 minecraft:yellow_terracotta
fill 1 115 336 1 118 336 minecraft:honeycomb_block
setblock 1 115 339 minecraft:honeycomb_block
setblock 1 115 340 minecraft:yellow_terracotta
setblock 1 115 343 minecraft:honey_block
fill 1 115 346 1 118 346 minecraft:honeycomb_block
setblock 1 115 350 minecraft:yellow_terracotta
fill 1 115 351 1 118 351 minecraft:honeycomb_block
setblock 1 115 354 minecraft:honeycomb_block
setblock 1 115 355 minecraft:yellow_terracotta
setblock 2 115 324 minecraft:yellow_terracotta
fill 2 115 325 2 118 325 minecraft:honeycomb_block
setblock 2 115 329 minecraft:yellow_terracotta
fill 2 115 330 2 118 330 minecraft:honeycomb_block
setblock 2 115 334 minecraft:yellow_terracotta
fill 2 115 335 3 117 335 minecraft:honeycomb_block
fill 2 115 337 2 116 337 minecraft:honeycomb_block
setblock 3 115 323 minecraft:yellow_terracotta
fill 3 115 324 3 118 324 minecraft:honeycomb_block
setblock 3 115 328 minecraft:yellow_terracotta
fill 3 115 329 3 118 329 minecraft:honeycomb_block
setblock 3 115 333 minecraft:yellow_terracotta
fill 3 115 334 3 118 334 minecraft:honeycomb_block
fill 4 115 323 4 118 323 minecraft:honeycomb_block
fill 4 115 328 4 118 328 minecraft:honeycomb_block
setblock 4 115 332 minecraft:yellow_terracotta
fill 4 115 333 4 118 333 minecraft:honeycomb_block
setblock 6 115 325 minecraft:yellow_terracotta
fill 6 115 363 7 115 363 minecraft:honeycomb_block
setblock 7 115 324 minecraft:yellow_terracotta
fill 7 115 325 7 118 325 minecraft:honeycomb_block
setblock 8 115 323 minecraft:yellow_terracotta
fill 8 115 324 10 116 324 minecraft:honeycomb_block
setblock 8 115 363 minecraft:yellow_terracotta
fill 9 115 323 9 118 323 minecraft:honeycomb_block
setblock 22 115 322 minecraft:yellow_concrete
setblock 23 115 323 minecraft:yellow_terracotta
setblock 23 115 363 minecraft:yellow_terracotta
fill 24 115 322 24 118 323 minecraft:honeycomb_block
setblock 24 115 362 minecraft:yellow_terracotta
fill 24 115 363 24 118 363 minecraft:honeycomb_block
fill 25 115 362 26 117 362 minecraft:honeycomb_block
fill 27 115 350 27 116 350 minecraft:yellow_concrete
setblock 28 115 363 minecraft:yellow_terracotta
fill 29 115 363 29 118 363 minecraft:honeycomb_block
setblock 36 115 323 minecraft:honey_block
setblock 40 115 331 minecraft:yellow_terracotta
fill 40 115 332 40 117 333 minecraft:honeycomb_block
setblock 40 115 351 minecraft:yellow_terracotta
fill 40 115 352 40 117 353 minecraft:honeycomb_block
fill 41 115 326 41 118 326 minecraft:honeycomb_block
setblock 41 115 330 minecraft:yellow_terracotta
fill 41 115 331 41 118 331 minecraft:honeycomb_block
fill 41 115 333 41 115 334 minecraft:honeycomb_block
setblock 41 115 335 minecraft:yellow_terracotta
fill 41 115 336 41 118 336 minecraft:honeycomb_block
setblock 41 115 339 minecraft:honeycomb_block
setblock 41 115 340 minecraft:yellow_terracotta
fill 41 115 341 41 118 341 minecraft:honeycomb_block
setblock 41 115 345 minecraft:yellow_terracotta
fill 41 115 346 41 118 346 minecraft:honeycomb_block
setblock 41 115 350 minecraft:yellow_terracotta
fill 41 115 351 41 118 351 minecraft:honeycomb_block
setblock 41 115 355 minecraft:yellow_terracotta
fill 41 115 356 41 118 356 minecraft:honeycomb_block
setblock 41 115 362 minecraft:honey_block
fill 42 115 363 42 129 363 minecraft:honeycomb_block
fill 0 116 327 0 132 327 minecraft:honeycomb_block
setblock 0 116 334 minecraft:honeycomb_block
setblock 0 116 341 minecraft:orange_terracotta
setblock 1 116 324 minecraft:yellow_terracotta
fill 1 116 325 1 119 325 minecraft:honeycomb_block
setblock 1 116 329 minecraft:yellow_terracotta
fill 1 116 330 1 119 330 minecraft:honeycomb_block
setblock 1 116 334 minecraft:yellow_terracotta
fill 1 116 335 1 119 335 minecraft:honeycomb_block
setblock 1 116 339 minecraft:yellow_terracotta
fill 1 116 340 1 117 342 minecraft:honeycomb_block
fill 1 116 345 1 119 345 minecraft:honeycomb_block
setblock 1 116 349 minecraft:yellow_terracotta
fill 1 116 350 2 118 350 minecraft:honeycomb_block
setblock 1 116 354 minecraft:yellow_terracotta
fill 1 116 355 1 117 357 minecraft:honeycomb_block
setblock 2 116 323 minecraft:yellow_terracotta
fill 2 116 324 2 119 324 minecraft:honeycomb_block
setblock 2 116 328 minecraft:yellow_terracotta
fill 2 116 329 2 119 329 minecraft:honeycomb_block
setblock 2 116 332 minecraft:honeycomb_block
setblock 2 116 333 minecraft:yellow_terracotta
fill 2 116 334 2 119 334 minecraft:honeycomb_block
setblock 2 116 338 minecraft:yellow_terracotta
fill 2 116 351 2 116 352 minecraft:honeycomb_block
setblock 2 116 353 minecraft:yellow_terracotta
fill 2 116 354 2 119 354 minecraft:honeycomb_block
fill 3 116 323 3 119 323 minecraft:honeycomb_block
setblock 3 116 327 minecraft:yellow_terracotta
fill 3 116 328 3 119 328 minecraft:honeycomb_block
setblock 3 116 332 minecraft:yellow_terracotta
fill 3 116 333 3 119 333 minecraft:honeycomb_block
setblock 3 116 336 minecraft:honeycomb_block
setblock 4 116 331 minecraft:yellow_terracotta
fill 4 116 332 4 119 332 minecraft:honeycomb_block
fill 4 116 334 4 117 334 minecraft:honeycomb_block
fill 4 116 363 6 116 363 minecraft:honeycomb_block
setblock 5 116 325 minecraft:yellow_terracotta
fill 5 116 327 6 116 328 minecraft:honey_block
fill 5 116 331 5 116 332 minecraft:honey_block
setblock 6 116 324 minecraft:yellow_terracotta
fill 6 116 325 6 119 325 minecraft:honeycomb_block
fill 6 116 332 7 116 332 minecraft:honey_block
setblock 7 116 323 minecraft:yellow_terracotta
fill 7 116 324 7 119 324 minecraft:honeycomb_block
fill 7 116 328 7 117 329 minecraft:honey_block
fill 7 116 331 8 116 331 minecraft:honey_block
setblock 7 116 363 minecraft:yellow_terracotta
fill 8 116 323 8 119 323 minecraft:honeycomb_block
fill 8 116 329 8 116 330 minecraft:honey_block
fill 8 116 363 9 118 363 minecraft:honeycomb_block
setblock 12 116 323 minecraft:yellow_terracotta
setblock 12 116 363 minecraft:honey_block
fill 13 116 345 15 116 345 minecraft:honey_block
fill 14 116 342 15 116 344 minecraft:honey_block
fill 14 116 346 15 116 347 minecraft:honey_block
fill 15 116 341 17 116 341 minecraft:honey_block
fill 15 116 348 21 116 348 minecraft:honey_block
fill 16 116 342 17 117 342 minecraft:honey_block
fill 16 116 347 16 118 347 minecraft:honey_block
fill 16 116 349 19 116 349 minecraft:honey_block
fill 19 116 347 21 116 347 minecraft:honey_block
fill 19 116 363 20 117 363 minecraft:honeycomb_block
fill 20 116 346 22 116 346 minecraft:honey_block
fill 22 116 322 22 126 322 minecraft:honeycomb_block
setblock 22 116 323 minecraft:yellow_terracotta
setblock 22 116 345 minecraft:honey_block
setblock 22 116 362 minecraft:honeycomb_block
setblock 22 116 363 minecraft:yellow_terracotta
setblock 22 116 364 minecraft:yellow_concrete
fill 23 116 323 23 119 323 minecraft:honeycomb_block
setblock 23 116 362 minecraft:yellow_terracotta
fill 23 116 363 23 119 363 minecraft:honeycomb_block
fill 24 116 362 24 119 362 minecraft:honeycomb_block
setblock 27 116 323 minecraft:yellow_terracotta
setblock 27 116 362 minecraft:honeycomb_block
setblock 27 116 363 minecraft:yellow_terracotta
fill 28 116 363 28 119 363 minecraft:honeycomb_block
setblock 30 116 323 minecraft:honey_block
setblock 31 116 363 minecraft:honey_block
fill 37 116 363 37 117 363 minecraft:honey_block
setblock 40 116 329 minecraft:honeycomb_block
setblock 40 116 330 minecraft:yellow_terracotta
fill 40 116 331 40 119 331 minecraft:honeycomb_block
setblock 40 116 334 minecraft:honeycomb_block
setblock 40 116 335 minecraft:yellow_terracotta
fill 40 116 336 40 118 337 minecraft:honeycomb_block
fill 40 116 347 40 118 347 minecraft:honeycomb_block
setblock 40 116 350 minecraft:yellow_terracotta
fill 40 116 351 40 119 351 minecraft:honeycomb_block
setblock 40 116 354 minecraft:honeycomb_block
setblock 41 116 329 minecraft:yellow_terracotta
fill 41 116 330 41 119 330 minecraft:honeycomb_block
setblock 41 116 333 minecraft:honeycomb_block
setblock 41 116 334 minecraft:yellow_terracotta
fill 41 116 335 41 119 335 minecraft:honeycomb_block
setblock 41 116 339 minecraft:yellow_terracotta
fill 41 116 340 41 119 340 minecraft:honeycomb_block
setblock 41 116 344 minecraft:yellow_terracotta
fill 41 116 345 41 119 345 minecraft:honeycomb_block
setblock 41 116 349 minecraft:yellow_terracotta
fill 41 116 350 41 119 350 minecraft:honeycomb_block
setblock 41 116 354 minecraft:yellow_terracotta
fill 41 116 355 41 119 355 minecraft:honeycomb_block
fill 41 116 357 41 117 357 minecraft:honeycomb_block
setblock 42 116 328 minecraft:orange_terracotta
setblock 0 117 329 minecraft:orange_terracotta
setblock 0 117 334 minecraft:yellow_terracotta
fill 0 117 341 0 308 341 minecraft:honeycomb_block
setblock 1 117 323 minecraft:yellow_terracotta
fill 1 117 324 1 119 324 minecraft:honeycomb_block
setblock 1 117 328 minecraft:yellow_terracotta
fill 1 117 329 1 119 329 minecraft:honeycomb_block
setblock 1 117 333 minecraft:yellow_terracotta
fill 1 117 334 1 119 334 minecraft:honeycomb_block
setblock 1 117 337 minecraft:honeycomb_block
setblock 1 117 338 minecraft:yellow_terracotta
fill 1 117 339 2 119 339 minecraft:honeycomb_block
setblock 1 117 343 minecraft:yellow_terracotta
fill 1 117 344 1 119 344 minecraft:honeycomb_block
setblock 1 117 348 minecraft:yellow_terracotta
fill 1 117 349 1 119 349 minecraft:honeycomb_block
setblock 1 117 352 minecraft:honeycomb_block
setblock 1 117 353 minecraft:yellow_terracotta
fill 1 117 354 1 119 354 minecraft:honeycomb_block
setblock 1 117 358 minecraft:yellow_terracotta
fill 1 117 359 1 119 359 minecraft:honeycomb_block
setblock 1 117 361 minecraft:honey_block
fill 2 117 323 2 119 323 minecraft:honeycomb_block
setblock 2 117 326 minecraft:honeycomb_block
setblock 2 117 327 minecraft:yellow_terracotta
fill 2 117 328 2 119 328 minecraft:honeycomb_block
setblock 2 117 332 minecraft:yellow_terracotta
fill 2 117 333 2 119 333 minecraft:honeycomb_block
setblock 2 117 337 minecraft:yellow_terracotta
fill 2 117 338 2 119 338 minecraft:honeycomb_block
fill 2 117 340 2 118 340 minecraft:honeycomb_block
setblock 2 117 351 minecraft:honeycomb_block
setblock 2 117 352 minecraft:yellow_terracotta
fill 2 117 353 2 119 353 minecraft:honeycomb_block
fill 2 117 355 2 117 356 minecraft:honeycomb_block
setblock 2 117 357 minecraft:yellow_terracotta
setblock 3 117 325 minecraft:honeycomb_block
setblock 3 117 326 minecraft:yellow_terracotta
fill 3 117 327 4 118 327 minecraft:honeycomb_block
setblock 3 117 330 minecraft:honeycomb_block
setblock 3 117 331 minecraft:yellow_terracotta
fill 3 117 332 3 119 332 minecraft:honeycomb_block
setblock 3 117 336 minecraft:yellow_terracotta
fill 3 117 337 3 119 337 minecraft:honeycomb_block
setblock 3 117 339 minecraft:light[level=12]
setblock 3 117 346 minecraft:light[level=12]
setblock 3 117 353 minecraft:light[level=12]
setblock 3 117 360 minecraft:light[level=12]
fill 3 117 363 5 117 363 minecraft:honeycomb_block
setblock 4 117 324 minecraft:honeycomb_block
setblock 4 117 325 minecraft:yellow_terracotta
setblock 4 117 330 minecraft:yellow_terracotta
fill 4 117 331 4 119 331 minecraft:honeycomb_block
setblock 4 117 335 minecraft:yellow_terracotta
setblock 5 117 324 minecraft:yellow_terracotta
fill 5 117 325 5 119 325 minecraft:honeycomb_block
fill 5 117 328 6 118 328 minecraft:honey_block
fill 5 117 331 5 118 331 minecraft:honey_block
setblock 6 117 323 minecraft:yellow_terracotta
fill 6 117 324 6 119 324 minecraft:honeycomb_block
setblock 6 117 363 minecraft:yellow_terracotta
fill 7 117 323 7 119 323 minecraft:honeycomb_block
setblock 7 117 331 minecraft:honey_block
fill 7 117 363 7 119 363 minecraft:honeycomb_block
fill 8 117 324 9 117 324 minecraft:honeycomb_block
setblock 10 117 325 minecraft:light[level=12]
setblock 10 117 332 minecraft:light[level=12]
fill 10 117 338 10 118 338 minecraft:orange_stained_glass
fill 10 117 339 10 119 339 minecraft:honeycomb_block
fill 10 117 340 10 120 344 minecraft:orange_stained_glass
fill 10 117 345 10 119 345 minecraft:honeycomb_block
fill 10 117 346 10 118 346 minecraft:orange_stained_glass
setblock 10 117 353 minecraft:light[level=12]
setblock 10 117 360 minecraft:light[level=12]
setblock 10 117 363 minecraft:honeycomb_block
setblock 11 117 323 minecraft:yellow_terracotta
fill 11 117 336 11 118 337 minecraft:orange_stained_glass
fill 11 117 347 11 118 348 minecraft:orange_stained_glass
fill 12 117 323 12 118 323 minecraft:honeycomb_block
fill 12 117 335 12 119 336 minecraft:orange_stained_glass
fill 12 117 348 12 119 349 minecraft:orange_stained_glass
fill 13 117 334 14 119 334 minecraft:orange_stained_glass
fill 13 117 335 13 121 335 minecraft:honeycomb_block
fill 13 117 349 13 121 349 minecraft:honeycomb_block
fill 13 117 350 14 119 350 minecraft:orange_stained_glass
fill 14 117 333 15 118 333 minecraft:orange_stained_glass
fill 14 117 344 15 117 346 minecraft:honey_block
fill 14 117 351 15 118 351 minecraft:orange_stained_glass
fill 15 117 342 15 117 343 minecraft:honey_block
setblock 15 117 347 minecraft:honey_block
fill 16 117 332 16 118 332 minecraft:orange_stained_glass
fill 16 117 348 20 117 348 minecraft:honey_block
fill 16 117 352 16 118 352 minecraft:orange_stained_glass
setblock 17 117 325 minecraft:light[level=12]
fill 17 117 332 17 119 332 minecraft:honeycomb_block
setblock 17 117 339 minecraft:light[level=12]
setblock 17 117 341 minecraft:honey_block
fill 17 117 352 17 119 352 minecraft:honeycomb_block
setblock 17 117 353 minecraft:light[level=12]
setblock 17 117 360 minecraft:light[level=12]
fill 18 117 332 22 120 332 minecraft:orange_stained_glass
fill 18 117 352 22 120 352 minecraft:orange_stained_glass
fill 18 117 363 18 119 363 minecraft:honeycomb_block
fill 19 117 347 20 118 347 minecraft:honey_block
setblock 20 117 323 minecraft:honeycomb_block
fill 20 117 346 21 117 346 minecraft:honey_block
fill 20 117 362 21 117 362 minecraft:honeycomb_block
setblock 21 117 323 minecraft:yellow_terracotta
setblock 21 117 363 minecraft:yellow_terracotta
fill 22 117 323 22 119 323 minecraft:honeycomb_block
setblock 22 117 362 minecraft:yellow_terracotta
fill 22 117 363 22 119 364 minecraft:honeycomb_block
fill 23 117 332 23 119 332 minecraft:honeycomb_block
fill 23 117 352 23 119 352 minecraft:honeycomb_block
setblock 23 117 361 minecraft:yellow_terracotta
fill 23 117 362 23 119 362 minecraft:honeycomb_block
setblock 24 117 325 minecraft:light[level=12]
fill 24 117 332 24 118 332 minecraft:orange_stained_glass
setblock 24 117 339 minecraft:light[level=12]
setblock 24 117 346 minecraft:light[level=12]
fill 24 117 352 24 118 352 minecraft:orange_stained_glass
setblock 24 117 353 minecraft:light[level=12]
setblock 24 117 360 minecraft:light[level=12]
fill 24 117 361 25 119 361 minecraft:honeycomb_block
fill 25 117 333 26 118 333 minecraft:orange_stained_glass
fill 25 117 351 26 118 351 minecraft:orange_stained_glass
setblock 26 117 323 minecraft:yellow_terracotta
fill 26 117 334 27 119 334 minecraft:orange_stained_glass
fill 26 117 350 27 119 350 minecraft:orange_stained_glass
setblock 26 117 363 minecraft:yellow_terracotta
fill 27 117 322 27 195 322 minecraft:honeycomb_block
fill 27 117 335 27 121 335 minecraft:honeycomb_block
fill 27 117 349 27 121 349 minecraft:honeycomb_block
setblock 27 117 362 minecraft:yellow_terracotta
fill 27 117 363 27 119 363 minecraft:honeycomb_block
setblock 28 117 322 minecraft:yellow_concrete
fill 28 117 335 28 119 336 minecraft:orange_stained_glass
fill 28 117 348 28 119 349 minecraft:orange_stained_glass
fill 29 117 336 29 118 337 minecraft:orange_stained_glass
fill 29 117 347 29 118 348 minecraft:orange_stained_glass
fill 30 117 338 30 118 338 minecraft:orange_stained_glass
fill 30 117 339 30 119 339 minecraft:honeycomb_block
fill 30 117 340 30 120 344 minecraft:orange_stained_glass
fill 30 117 345 30 119 345 minecraft:honeycomb_block
fill 30 117 346 30 118 346 minecraft:orange_stained_glass
setblock 31 117 325 minecraft:light[level=12]
setblock 31 117 332 minecraft:light[level=12]
setblock 31 117 339 minecraft:light[level=12]
fill 31 117 345 32 118 345 minecraft:honey_block
setblock 31 117 346 minecraft:light[level=12]
setblock 31 117 353 minecraft:light[level=12]
setblock 31 117 360 minecraft:light[level=12]
setblock 38 117 325 minecraft:light[level=12]
setblock 38 117 332 minecraft:light[level=12]
setblock 38 117 339 minecraft:light[level=12]
setblock 38 117 346 minecraft:light[level=12]
setblock 38 117 353 minecraft:light[level=12]
setblock 38 117 360 minecraft:light[level=12]
setblock 40 117 328 minecraft:honeycomb_block
setblock 40 117 329 minecraft:yellow_terracotta
fill 40 117 330 40 119 330 minecraft:honeycomb_block
setblock 40 117 334 minecraft:yellow_terracotta
fill 40 117 335 40 119 335 minecraft:honeycomb_block
setblock 40 117 338 minecraft:honeycomb_block
setblock 40 117 339 minecraft:yellow_terracotta
fill 40 117 340 40 119 340 minecraft:honeycomb_block
setblock 40 117 349 minecraft:yellow_terracotta
fill 40 117 350 40 119 350 minecraft:honeycomb_block
setblock 40 117 354 minecraft:yellow_terracotta
fill 40 117 355 40 119 356 minecraft:honeycomb_block
fill 41 117 325 41 119 325 minecraft:honeycomb_block
setblock 41 117 328 minecraft:yellow_terracotta
fill 41 117 329 41 119 329 minecraft:honeycomb_block
setblock 41 117 333 minecraft:yellow_terracotta
fill 41 117 334 41 119 334 minecraft:honeycomb_block
setblock 41 117 337 minecraft:honeycomb_block
setblock 41 117 338 minecraft:yellow_terracotta
fill 41 117 339 41 119 339 minecraft:honeycomb_block
setblock 41 117 343 minecraft:yellow_terracotta
fill 41 117 344 41 119 344 minecraft:honeycomb_block
setblock 41 117 348 minecraft:yellow_terracotta
fill 41 117 349 41 119 349 minecraft:honeycomb_block
setblock 41 117 353 minecraft:yellow_terracotta
fill 41 117 354 41 119 354 minecraft:honeycomb_block
setblock 41 117 358 minecraft:yellow_terracotta
fill 41 117 359 41 119 359 minecraft:honeycomb_block
fill 42 117 328 42 308 328 minecraft:honeycomb_block
setblock 42 117 351 minecraft:yellow_terracotta
fill 0 118 329 0 257 329 minecraft:honeycomb_block
fill 0 118 334 0 138 334 minecraft:honeycomb_block
fill 1 118 323 1 119 323 minecraft:honeycomb_block
setblock 1 118 327 minecraft:yellow_terracotta
fill 1 118 328 1 119 328 minecraft:honeycomb_block
setblock 1 118 332 minecraft:yellow_terracotta
fill 1 118 333 1 119 333 minecraft:honeycomb_block
setblock 1 118 337 minecraft:yellow_terracotta
fill 1 118 338 1 119 338 minecraft:honeycomb_block
fill 1 118 340 1 118 341 minecraft:honeycomb_block
setblock 1 118 342 minecraft:yellow_terracotta
fill 1 118 343 1 119 343 minecraft:honeycomb_block
setblock 1 118 347 minecraft:yellow_terracotta
fill 1 118 348 1 119 348 minecraft:honeycomb_block
setblock 1 118 352 minecraft:yellow_terracotta
fill 1 118 353 1 119 353 minecraft:honeycomb_block
fill 1 118 355 1 118 356 minecraft:honeycomb_block
setblock 1 118 357 minecraft:yellow_terracotta
fill 1 118 358 2 119 358 minecraft:honeycomb_block
fill 1 118 360 1 118 361 minecraft:honeycomb_block
setblock 1 118 362 minecraft:yellow_terracotta
fill 1 118 363 4 118 363 minecraft:honeycomb_block
setblock 2 118 326 minecraft:yellow_terracotta
fill 2 118 327 2 119 327 minecraft:honeycomb_block
setblock 2 118 331 minecraft:yellow_terracotta
fill 2 118 332 2 119 332 minecraft:honeycomb_block
setblock 2 118 335 minecraft:honeycomb_block
setblock 2 118 336 minecraft:yellow_terracotta
fill 2 118 337 2 119 337 minecraft:honeycomb_block
setblock 2 118 341 minecraft:yellow_terracotta
setblock 2 118 349 minecraft:honeycomb_block
setblock 2 118 351 minecraft:yellow_terracotta
fill 2 118 352 2 119 352 minecraft:honeycomb_block
setblock 2 118 355 minecraft:honeycomb_block
setblock 2 118 356 minecraft:yellow_terracotta
fill 2 118 357 2 119 357 minecraft:honeycomb_block
fill 2 118 359 2 119 359 minecraft:honeycomb_block
setblock 3 118 325 minecraft:yellow_terracotta
fill 3 118 326 3 119 326 minecraft:honeycomb_block
setblock 3 118 330 minecraft:yellow_terracotta
fill 3 118 331 3 119 331 minecraft:honeycomb_block
setblock 3 118 335 minecraft:yellow_terracotta
fill 3 118 336 4 119 336 minecraft:honeycomb_block
fill 3 118 338 3 119 338 minecraft:honeycomb_block
setblock 4 118 324 minecraft:yellow_terracotta
fill 4 118 325 4 119 325 minecraft:honeycomb_block
setblock 4 118 329 minecraft:yellow_terracotta
fill 4 118 330 4 119 330 minecraft:honeycomb_block
setblock 4 118 334 minecraft:yellow_terracotta
fill 4 118 335 4 119 335 minecraft:honeycomb_block
fill 4 118 362 5 118 362 minecraft:honeycomb_block
setblock 5 118 323 minecraft:yellow_terracotta
fill 5 118 324 5 119 324 minecraft:honeycomb_block
setblock 5 118 363 minecraft:yellow_terracotta
fill 6 118 323 6 119 323 minecraft:honeycomb_block
setblock 6 118 362 minecraft:yellow_terracotta
fill 6 118 363 6 119 363 minecraft:honeycomb_block
setblock 7 118 329 minecraft:honey_block
setblock 7 118 364 minecraft:orange_terracotta
setblock 8 118 324 minecraft:honeycomb_block
setblock 9 118 324 minecraft:yellow_terracotta
setblock 10 118 323 minecraft:yellow_terracotta
setblock 10 118 363 minecraft:yellow_terracotta
fill 11 118 323 11 119 323 minecraft:honeycomb_block
fill 11 118 338 11 121 338 minecraft:orange_stained_glass
fill 11 118 346 11 121 346 minecraft:orange_stained_glass
fill 11 118 363 11 119 363 minecraft:honeycomb_block
fill 15 118 344 15 118 346 minecraft:honey_block
setblock 15 118 363 minecraft:yellow_terracotta
fill 16 118 333 16 121 333 minecraft:orange_stained_glass
fill 16 118 351 16 121 351 minecraft:orange_stained_glass
fill 16 118 363 17 119 363 minecraft:honeycomb_block
setblock 17 118 342 minecraft:honey_block
fill 17 118 348 18 118 348 minecraft:honey_block
setblock 18 118 323 minecraft:honey_block
fill 18 118 344 18 119 344 minecraft:yellow_terracotta
setblock 19 118 323 minecraft:honeycomb_block
fill 19 118 362 19 118 363 minecraft:honeycomb_block
setblock 20 118 323 minecraft:yellow_terracotta
setblock 20 118 346 minecraft:honey_block
setblock 20 118 362 minecraft:honeycomb_block
setblock 20 118 363 minecraft:yellow_terracotta
fill 21 118 323 21 119 323 minecraft:honeycomb_block
setblock 21 118 361 minecraft:honeycomb_block
setblock 21 118 362 minecraft:yellow_terracotta
fill 21 118 363 21 119 363 minecraft:honeycomb_block
setblock 22 118 361 minecraft:yellow_terracotta
fill 22 118 362 22 119 362 minecraft:honeycomb_block
fill 23 118 361 23 119 361 minecraft:honeycomb_block
fill 24 118 333 24 121 333 minecraft:orange_stained_glass
fill 24 118 351 24 121 351 minecraft:orange_stained_glass
setblock 25 118 323 minecraft:yellow_terracotta
setblock 25 118 362 minecraft:honeycomb_block
setblock 25 118 363 minecraft:yellow_terracotta
fill 25 118 364 25 138 364 minecraft:honeycomb_block
fill 26 118 323 26 119 323 minecraft:honeycomb_block
setblock 26 118 361 minecraft:honeycomb_block
setblock 26 118 362 minecraft:yellow_terracotta
fill 26 118 363 26 119 363 minecraft:honeycomb_block
fill 27 118 362 27 119 362 minecraft:honeycomb_block
fill 28 118 322 28 119 322 minecraft:honeycomb_block
fill 29 118 338 29 121 338 minecraft:orange_stained_glass
fill 29 118 346 29 121 346 minecraft:orange_stained_glass
setblock 37 118 323 minecraft:honey_block
fill 39 118 331 39 118 333 minecraft:honeycomb_block
setblock 39 118 334 minecraft:yellow_terracotta
fill 39 118 335 39 119 337 minecraft:honeycomb_block
setblock 40 118 328 minecraft:yellow_terracotta
fill 40 118 329 40 119 329 minecraft:honeycomb_block
setblock 40 118 332 minecraft:honeycomb_block
setblock 40 118 333 minecraft:yellow_terracotta
fill 40 118 334 40 119 334 minecraft:honeycomb_block
setblock 40 118 338 minecraft:yellow_terracotta
fill 40 118 339 40 119 339 minecraft:honeycomb_block
fill 40 118 341 40 118 342 minecraft:honeycomb_block
setblock 40 118 343 minecraft:yellow_terracotta
fill 40 118 344 40 119 346 minecraft:honeycomb_block
setblock 40 118 348 minecraft:yellow_terracotta
fill 40 118 349 40 119 349 minecraft:honeycomb_block
setblock 40 118 352 minecraft:honeycomb_block
setblock 40 118 353 minecraft:yellow_terracotta
fill 40 118 354 40 119 354 minecraft:honeycomb_block
setblock 40 118 357 minecraft:honeycomb_block
fill 41 118 324 41 119 324 minecraft:honeycomb_block
setblock 41 118 327 minecraft:yellow_terracotta
fill 41 118 328 41 119 328 minecraft:honeycomb_block
setblock 41 118 332 minecraft:yellow_terracotta
fill 41 118 333 41 119 333 minecraft:honeycomb_block
setblock 41 118 337 minecraft:yellow_terracotta
fill 41 118 338 41 119 338 minecraft:honeycomb_block
setblock 41 118 342 minecraft:yellow_terracotta
fill 41 118 343 41 119 343 minecraft:honeycomb_block
setblock 41 118 347 minecraft:yellow_terracotta
fill 41 118 348 41 119 348 minecraft:honeycomb_block
setblock 41 118 352 minecraft:yellow_terracotta
fill 41 118 353 41 119 353 minecraft:honeycomb_block
setblock 41 118 357 minecraft:yellow_terracotta
fill 41 118 358 41 119 358 minecraft:honeycomb_block
fill 41 118 360 41 119 360 minecraft:honeycomb_block
fill 42 118 351 42 252 351 minecraft:honeycomb_block
setblock 0 119 330 minecraft:orange_terracotta
setblock 1 119 326 minecraft:yellow_terracotta
setblock 1 119 327 minecraft:honeycomb_block
setblock 1 119 331 minecraft:yellow_terracotta
setblock 1 119 332 minecraft:honeycomb_block
setblock 1 119 336 minecraft:yellow_terracotta
setblock 1 119 337 minecraft:honeycomb_block
setblock 1 119 340 minecraft:honeycomb_block
setblock 1 119 341 minecraft:yellow_terracotta
fill 1 119 342 2 119 342 minecraft:honeycomb_block
setblock 1 119 346 minecraft:yellow_terracotta
setblock 1 119 347 minecraft:honeycomb_block
setblock 1 119 350 minecraft:honeycomb_block
setblock 1 119 351 minecraft:yellow_terracotta
setblock 1 119 352 minecraft:honeycomb_block
setblock 1 119 355 minecraft:honeycomb_block
setblock 1 119 356 minecraft:yellow_terracotta
setblock 1 119 357 minecraft:honeycomb_block
setblock 1 119 360 minecraft:honeycomb_block
setblock 1 119 361 minecraft:yellow_terracotta
fill 1 119 362 3 119 363 minecraft:honeycomb_block
setblock 2 119 325 minecraft:yellow_terracotta
setblock 2 119 326 minecraft:honeycomb_block
setblock 2 119 330 minecraft:yellow_terracotta
setblock 2 119 331 minecraft:honeycomb_block
setblock 2 119 335 minecraft:yellow_terracotta
setblock 2 119 336 minecraft:honeycomb_block
setblock 2 119 340 minecraft:yellow_terracotta
setblock 2 119 341 minecraft:honeycomb_block
setblock 2 119 350 minecraft:yellow_terracotta
setblock 2 119 351 minecraft:honeycomb_block
setblock 2 119 355 minecraft:yellow_terracotta
fill 2 119 356 3 119 356 minecraft:honeycomb_block
setblock 2 119 360 minecraft:yellow_terracotta
setblock 2 119 361 minecraft:honeycomb_block
setblock 3 119 324 minecraft:yellow_terracotta
setblock 3 119 325 minecraft:honeycomb_block
setblock 3 119 327 minecraft:honeycomb_block
setblock 3 119 329 minecraft:yellow_terracotta
setblock 3 119 330 minecraft:honeycomb_block
setblock 3 119 334 minecraft:yellow_terracotta
setblock 3 119 335 minecraft:honeycomb_block
setblock 3 119 339 minecraft:yellow_terracotta
setblock 3 119 341 minecraft:light[level=15]
setblock 3 119 349 minecraft:light[level=15]
setblock 3 119 354 minecraft:yellow_terracotta
setblock 3 119 355 minecraft:honeycomb_block
fill 3 119 357 3 119 358 minecraft:honeycomb_block
setblock 4 119 323 minecraft:yellow_terracotta
setblock 4 119 324 minecraft:honeycomb_block
setblock 4 119 328 minecraft:yellow_terracotta
setblock 4 119 329 minecraft:honeycomb_block
setblock 4 119 333 minecraft:yellow_terracotta
setblock 4 119 334 minecraft:honeycomb_block
setblock 4 119 362 minecraft:honeycomb_block
setblock 4 119 363 minecraft:yellow_terracotta
setblock 5 119 323 minecraft:honeycomb_block
setblock 5 119 362 minecraft:yellow_terracotta
setblock 5 119 363 minecraft:honeycomb_block
fill 6 119 362 8 119 362 minecraft:honeycomb_block
fill 7 119 364 7 160 364 minecraft:honeycomb_block
setblock 8 119 324 minecraft:yellow_terracotta
setblock 8 119 363 minecraft:honeycomb_block
setblock 9 119 323 minecraft:yellow_terracotta
setblock 9 119 363 minecraft:yellow_terracotta
setblock 10 119 323 minecraft:honeycomb_block
setblock 10 119 363 minecraft:honeycomb_block
setblock 11 119 325 minecraft:light[level=15]
setblock 11 119 333 minecraft:light[level=15]
fill 11 119 337 11 120 337 minecraft:orange_stained_glass
setblock 11 119 341 minecraft:light[level=15]
fill 11 119 347 11 120 347 minecraft:orange_stained_glass
setblock 11 119 349 minecraft:light[level=15]
setblock 11 119 357 minecraft:light[level=15]
setblock 12 119 323 minecraft:honey_block
fill 12 119 363 13 119 363 minecraft:honeycomb_block
setblock 14 119 363 minecraft:yellow_terracotta
fill 15 119 333 15 120 333 minecraft:orange_stained_glass
fill 15 119 351 15 120 351 minecraft:orange_stained_glass
setblock 15 119 363 minecraft:honeycomb_block
fill 17 119 362 19 119 362 minecraft:honeycomb_block
setblock 18 119 323 minecraft:honeycomb_block
setblock 19 119 322 minecraft:orange_terracotta
setblock 19 119 323 minecraft:yellow_terracotta
setblock 19 119 325 minecraft:light[level=15]
setblock 19 119 333 minecraft:light[level=15]
setblock 19 119 341 minecraft:light[level=15]
setblock 19 119 349 minecraft:light[level=15]
setblock 19 119 357 minecraft:light[level=15]
fill 19 119 361 20 119 361 minecraft:honeycomb_block
setblock 19 119 363 minecraft:yellow_terracotta
setblock 20 119 323 minecraft:honeycomb_block
setblock 20 119 362 minecraft:yellow_terracotta
setblock 20 119 363 minecraft:honeycomb_block
setblock 21 119 360 minecraft:honeycomb_block
setblock 21 119 361 minecraft:yellow_terracotta
setblock 21 119 362 minecraft:honeycomb_block
setblock 22 119 360 minecraft:yellow_terracotta
setblock 22 119 361 minecraft:honeycomb_block
fill 23 119 360 25 119 360 minecraft:honeycomb_block
fill 24 119 322 24 308 322 minecraft:honeycomb_block
setblock 24 119 323 minecraft:yellow_terracotta
setblock 24 119 363 minecraft:yellow_terracotta
setblock 25 119 323 minecraft:honeycomb_block
fill 25 119 333 25 120 333 minecraft:orange_stained_glass
fill 25 119 351 25 120 351 minecraft:orange_stained_glass
setblock 25 119 362 minecraft:yellow_terracotta
setblock 25 119 363 minecraft:honeycomb_block
setblock 26 119 361 minecraft:yellow_terracotta
setblock 26 119 362 minecraft:honeycomb_block
setblock 27 119 325 minecraft:light[level=15]
setblock 27 119 333 minecraft:light[level=15]
setblock 27 119 341 minecraft:light[level=15]
setblock 27 119 357 minecraft:light[level=15]
setblock 28 119 362 minecraft:honeycomb_block
fill 29 119 337 29 120 337 minecraft:orange_stained_glass
fill 29 119 347 29 120 347 minecraft:orange_stained_glass
setblock 29 119 363 minecraft:yellow_terracotta
setblock 30 119 363 minecraft:honey_block
setblock 31 119 323 minecraft:honey_block
setblock 35 119 325 minecraft:light[level=15]
setblock 35 119 333 minecraft:light[level=15]
setblock 35 119 341 minecraft:light[level=15]
setblock 35 119 349 minecraft:light[level=15]
setblock 35 119 357 minecraft:light[level=15]
fill 39 119 331 39 119 332 minecraft:honeycomb_block
setblock 39 119 333 minecraft:yellow_terracotta
setblock 39 119 334 minecraft:honeycomb_block
setblock 39 119 338 minecraft:yellow_terracotta
setblock 39 119 339 minecraft:honeycomb_block
setblock 39 119 353 minecraft:yellow_terracotta
setblock 40 119 327 minecraft:yellow_terracotta
setblock 40 119 328 minecraft:honeycomb_block
setblock 40 119 332 minecraft:yellow_terracotta
setblock 40 119 333 minecraft:honeycomb_block
setblock 40 119 336 minecraft:honeycomb_block
setblock 40 119 337 minecraft:yellow_terracotta
setblock 40 119 338 minecraft:honeycomb_block
setblock 40 119 341 minecraft:honeycomb_block
setblock 40 119 342 minecraft:yellow_terracotta
setblock 40 119 343 minecraft:honeycomb_block
setblock 40 119 347 minecraft:yellow_terracotta
setblock 40 119 348 minecraft:honeycomb_block
setblock 40 119 352 minecraft:yellow_terracotta
setblock 40 119 353 minecraft:honeycomb_block
setblock 40 119 357 minecraft:yellow_terracotta
setblock 40 119 358 minecraft:honeycomb_block
setblock 41 119 323 minecraft:honeycomb_block
setblock 41 119 326 minecraft:yellow_terracotta
setblock 41 119 327 minecraft:honeycomb_block
setblock 41 119 331 minecraft:yellow_terracotta
setblock 41 119 332 minecraft:honeycomb_block
setblock 41 119 336 minecraft:yellow_terracotta
setblock 41 119 337 minecraft:honeycomb_block
setblock 41 119 341 minecraft:yellow_terracotta
setblock 41 119 342 minecraft:honeycomb_block
setblock 41 119 346 minecraft:yellow_terracotta
setblock 41 119 347 minecraft:honeycomb_block
setblock 41 119 351 minecraft:yellow_terracotta
setblock 41 119 352 minecraft:honeycomb_block
setblock 41 119 356 minecraft:yellow_terracotta
setblock 41 119 357 minecraft:honeycomb_block
setblock 41 119 361 minecraft:yellow_terracotta
setblock 41 119 362 minecraft:honeycomb_block
fill 0 120 330 0 166 330 minecraft:honeycomb_block
setblock 0 120 363 minecraft:yellow_terracotta
fill 11 120 339 11 122 339 minecraft:orange_stained_glass
fill 11 120 345 11 122 345 minecraft:orange_stained_glass
fill 12 120 336 12 121 337 minecraft:orange_stained_glass
fill 12 120 347 12 121 348 minecraft:orange_stained_glass
fill 14 120 334 15 121 334 minecraft:orange_stained_glass
fill 14 120 350 15 121 350 minecraft:orange_stained_glass
fill 17 120 333 17 122 333 minecraft:orange_stained_glass
fill 17 120 351 17 122 351 minecraft:orange_stained_glass
fill 19 120 322 19 270 322 minecraft:honeycomb_block
fill 22 120 364 22 199 364 minecraft:honeycomb_block
fill 23 120 333 23 122 333 minecraft:orange_stained_glass
fill 23 120 351 23 122 351 minecraft:orange_stained_glass
fill 25 120 334 26 121 334 minecraft:orange_stained_glass
fill 25 120 350 26 121 350 minecraft:orange_stained_glass
setblock 26 120 322 minecraft:yellow_concrete
setblock 28 120 322 minecraft:yellow_terracotta
fill 28 120 336 28 121 337 minecraft:orange_stained_glass
fill 28 120 347 28 121 348 minecraft:orange_stained_glass
fill 29 120 339 29 122 339 minecraft:orange_stained_glass
fill 29 120 345 29 122 345 minecraft:orange_stained_glass
setblock 39 120 322 minecraft:orange_terracotta
fill 0 121 363 0 248 363 minecraft:honeycomb_block
fill 10 121 342 11 121 342 minecraft:orange_stained_glass
fill 11 121 340 11 122 341 minecraft:orange_stained_glass
fill 11 121 343 11 122 344 minecraft:orange_stained_glass
fill 12 121 338 12 122 338 minecraft:orange_stained_glass
fill 12 121 346 12 122 346 minecraft:orange_stained_glass
setblock 13 121 322 minecraft:yellow_concrete
fill 13 121 336 13 122 336 minecraft:orange_stained_glass
fill 13 121 348 13 122 348 minecraft:orange_stained_glass
fill 14 121 335 14 122 335 minecraft:orange_stained_glass
fill 14 121 349 14 122 349 minecraft:orange_stained_glass
setblock 15 121 364 minecraft:orange_terracotta
fill 16 121 334 16 122 334 minecraft:orange_stained_glass
fill 16 121 350 16 122 350 minecraft:orange_stained_glass
fill 18 121 333 22 122 333 minecraft:orange_stained_glass
fill 18 121 351 22 122 351 minecraft:orange_stained_glass
setblock 20 121 332 minecraft:orange_stained_glass
setblock 20 121 352 minecraft:orange_stained_glass
fill 24 121 334 24 122 334 minecraft:orange_stained_glass
fill 24 121 350 24 122 350 minecraft:orange_stained_glass
fill 26 121 322 26 143 322 minecraft:honeycomb_block
fill 26 121 335 26 122 335 minecraft:orange_stained_glass
fill 26 121 349 26 122 349 minecraft:orange_stained_glass
fill 27 121 336 27 122 336 minecraft:orange_stained_glass
fill 27 121 348 27 122 348 minecraft:orange_stained_glass
fill 28 121 322 28 126 322 minecraft:honeycomb_block
fill 28 121 338 28 122 338 minecraft:orange_stained_glass
fill 28 121 346 28 122 346 minecraft:orange_stained_glass
fill 29 121 340 29 122 344 minecraft:orange_stained_glass
setblock 30 121 342 minecraft:orange_stained_glass
fill 39 121 322 39 186 322 minecraft:honeycomb_block
setblock 0 122 350 minecraft:yellow_concrete
setblock 11 122 342 minecraft:orange_stained_glass
fill 12 122 337 13 122 337 minecraft:orange_stained_glass
fill 12 122 339 12 123 339 minecraft:orange_stained_glass
fill 12 122 340 12 123 340 minecraft:honeycomb_block
fill 12 122 344 12 123 344 minecraft:honeycomb_block
fill 12 122 345 12 123 345 minecraft:orange_stained_glass
fill 12 122 347 13 122 347 minecraft:orange_stained_glass
fill 13 122 322 13 130 322 minecraft:honeycomb_block
fill 14 122 336 14 123 336 minecraft:honeycomb_block
fill 14 122 348 14 123 348 minecraft:honeycomb_block
fill 15 122 334 15 122 335 minecraft:orange_stained_glass
fill 15 122 349 15 122 350 minecraft:orange_stained_glass
setblock 15 122 364 minecraft:yellow_concrete
fill 17 122 334 17 123 334 minecraft:orange_stained_glass
fill 17 122 350 17 123 350 minecraft:orange_stained_glass
fill 18 122 334 18 123 334 minecraft:honeycomb_block
fill 18 122 350 18 123 350 minecraft:honeycomb_block
fill 22 122 334 22 123 334 minecraft:honeycomb_block
fill 22 122 350 22 123 350 minecraft:honeycomb_block
fill 23 122 334 23 123 334 minecraft:orange_stained_glass
fill 23 122 350 23 123 350 minecraft:orange_stained_glass
fill 25 122 334 25 122 335 minecraft:orange_stained_glass
fill 25 122 349 25 122 350 minecraft:orange_stained_glass
fill 26 122 336 26 123 336 minecraft:honeycomb_block
fill 26 122 348 26 123 348 minecraft:honeycomb_block
fill 27 122 337 28 122 337 minecraft:orange_stained_glass
fill 27 122 347 28 122 347 minecraft:orange_stained_glass
fill 28 122 339 28 123 339 minecraft:orange_stained_glass
fill 28 122 340 28 123 340 minecraft:honeycomb_block
fill 28 122 344 28 123 344 minecraft:honeycomb_block
fill 28 122 345 28 123 345 minecraft:orange_stained_glass
fill 0 123 350 0 219 350 minecraft:honeycomb_block
setblock 3 123 325 minecraft:light[level=12]
setblock 3 123 332 minecraft:light[level=12]
setblock 3 123 339 minecraft:light[level=12]
setblock 3 123 346 minecraft:light[level=12]
setblock 3 123 353 minecraft:light[level=12]
setblock 3 123 360 minecraft:light[level=12]
setblock 10 123 325 minecraft:light[level=12]
setblock 10 123 332 minecraft:light[level=12]
setblock 10 123 339 minecraft:light[level=12]
setblock 10 123 346 minecraft:light[level=12]
setblock 10 123 353 minecraft:light[level=12]
setblock 10 123 360 minecraft:light[level=12]
fill 12 123 341 12 123 343 minecraft:orange_stained_glass
fill 13 123 337 13 123 339 minecraft:orange_stained_glass
fill 13 123 345 13 123 347 minecraft:orange_stained_glass
fill 14 123 337 14 124 337 minecraft:orange_stained_glass
fill 14 123 347 14 124 347 minecraft:orange_stained_glass
fill 15 123 335 15 123 336 minecraft:orange_stained_glass
fill 15 123 348 15 123 349 minecraft:orange_stained_glass
fill 15 123 364 15 131 364 minecraft:honeycomb_block
fill 16 123 335 17 123 335 minecraft:orange_stained_glass
fill 16 123 349 17 123 349 minecraft:orange_stained_glass
setblock 17 123 325 minecraft:light[level=12]
setblock 17 123 332 minecraft:light[level=12]
setblock 17 123 339 minecraft:light[level=12]
setblock 17 123 346 minecraft:light[level=12]
setblock 17 123 353 minecraft:light[level=12]
setblock 17 123 360 minecraft:light[level=12]
setblock 17 123 364 minecraft:yellow_terracotta
fill 19 123 334 21 123 334 minecraft:orange_stained_glass
fill 19 123 350 21 123 350 minecraft:orange_stained_glass
fill 23 123 335 25 123 335 minecraft:orange_stained_glass
fill 23 123 349 25 123 349 minecraft:orange_stained_glass
setblock 24 123 325 minecraft:light[level=12]
setblock 24 123 332 minecraft:light[level=12]
setblock 24 123 339 minecraft:light[level=12]
setblock 24 123 346 minecraft:light[level=12]
setblock 24 123 353 minecraft:light[level=12]
setblock 24 123 360 minecraft:light[level=12]
fill 25 123 336 25 124 336 minecraft:orange_stained_glass
fill 25 123 348 25 124 348 minecraft:orange_stained_glass
fill 26 123 337 27 123 337 minecraft:orange_stained_glass
fill 26 123 347 27 123 347 minecraft:orange_stained_glass
fill 27 123 338 27 123 339 minecraft:orange_stained_glass
fill 27 123 345 27 123 346 minecraft:orange_stained_glass
fill 28 123 341 28 123 343 minecraft:orange_stained_glass
setblock 31 123 325 minecraft:light[level=12]
setblock 31 123 332 minecraft:light[level=12]
setblock 31 123 339 minecraft:light[level=12]
setblock 31 123 346 minecraft:light[level=12]
setblock 31 123 353 minecraft:light[level=12]
setblock 31 123 360 minecraft:light[level=12]
setblock 34 123 322 minecraft:orange_terracotta
setblock 38 123 325 minecraft:light[level=12]
setblock 38 123 332 minecraft:light[level=12]
setblock 38 123 339 minecraft:light[level=12]
setblock 38 123 346 minecraft:light[level=12]
setblock 38 123 353 minecraft:light[level=12]
setblock 38 123 360 minecraft:light[level=12]
setblock 42 123 332 minecraft:yellow_concrete
fill 12 124 342 13 124 342 minecraft:orange_stained_glass
fill 13 124 339 14 124 339 minecraft:orange_stained_glass
setblock 13 124 340 minecraft:honeycomb_block
setblock 13 124 341 minecraft:orange_stained_glass
setblock 13 124 343 minecraft:orange_stained_glass
setblock 13 124 344 minecraft:honeycomb_block
fill 13 124 345 14 124 345 minecraft:orange_stained_glass
setblock 14 124 338 minecraft:orange_stained_glass
setblock 14 124 346 minecraft:orange_stained_glass
fill 15 124 336 17 124 336 minecraft:orange_stained_glass
setblock 15 124 337 minecraft:honeycomb_block
setblock 15 124 347 minecraft:honeycomb_block
fill 15 124 348 17 124 348 minecraft:orange_stained_glass
setblock 17 124 335 minecraft:orange_stained_glass
setblock 17 124 349 minecraft:orange_stained_glass
fill 17 124 364 17 168 364 minecraft:honeycomb_block
setblock 18 124 335 minecraft:honeycomb_block
setblock 18 124 349 minecraft:honeycomb_block
fill 19 124 335 21 124 335 minecraft:orange_stained_glass
fill 19 124 349 21 124 349 minecraft:orange_stained_glass
setblock 20 124 334 minecraft:orange_stained_glass
setblock 20 124 350 minecraft:orange_stained_glass
setblock 22 124 335 minecraft:honeycomb_block
setblock 22 124 349 minecraft:honeycomb_block
fill 23 124 335 23 124 336 minecraft:orange_stained_glass
fill 23 124 348 23 124 349 minecraft:orange_stained_glass
setblock 24 124 336 minecraft:orange_stained_glass
setblock 24 124 348 minecraft:orange_stained_glass
setblock 25 124 337 minecraft:honeycomb_block
setblock 25 124 347 minecraft:honeycomb_block
fill 26 124 337 26 124 339 minecraft:orange_stained_glass
fill 26 124 345 26 124 347 minecraft:orange_stained_glass
setblock 27 124 339 minecraft:orange_stained_glass
setblock 27 124 340 minecraft:honeycomb_block
fill 27 124 341 27 124 343 minecraft:orange_stained_glass
setblock 27 124 344 minecraft:honeycomb_block
setblock 27 124 345 minecraft:orange_stained_glass
setblock 28 124 342 minecraft:orange_stained_glass
fill 34 124 322 34 308 322 minecraft:honeycomb_block
schedule function dropper:buildpart/72_4 1t
