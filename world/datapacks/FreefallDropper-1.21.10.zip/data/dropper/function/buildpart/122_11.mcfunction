fill 131 279 537 132 280 537 minecraft:blue_concrete
fill 132 279 523 132 280 530 minecraft:light_blue_concrete
fill 132 279 536 132 280 536 minecraft:blue_concrete
fill 133 279 525 133 280 530 minecraft:light_blue_concrete
fill 133 279 535 133 280 535 minecraft:blue_concrete
fill 134 279 530 134 280 530 minecraft:light_blue_concrete
fill 95 280 511 101 280 551 minecraft:basalt
fill 102 280 511 102 280 529 minecraft:basalt
fill 102 280 531 102 280 551 minecraft:basalt
fill 103 280 511 103 280 524 minecraft:basalt
fill 103 280 536 103 280 551 minecraft:basalt
fill 104 280 511 104 280 522 minecraft:basalt
fill 104 280 538 104 280 551 minecraft:basalt
fill 105 280 511 105 280 520 minecraft:basalt
fill 105 280 540 105 280 551 minecraft:basalt
fill 106 280 511 106 280 519 minecraft:basalt
fill 106 280 541 106 280 551 minecraft:basalt
fill 107 280 511 107 280 518 minecraft:basalt
fill 107 280 542 107 280 551 minecraft:basalt
fill 108 280 511 108 280 517 minecraft:basalt
fill 108 280 543 108 280 551 minecraft:basalt
fill 109 280 511 110 280 516 minecraft:basalt
fill 109 280 544 110 280 551 minecraft:basalt
fill 111 280 511 112 280 515 minecraft:basalt
fill 111 280 545 112 280 551 minecraft:basalt
fill 113 280 511 117 280 514 minecraft:basalt
fill 113 280 546 117 280 551 minecraft:basalt
fill 115 280 529 115 280 531 minecraft:shroomlight
fill 116 280 528 116 280 529 minecraft:shroomlight
fill 116 280 531 116 280 532 minecraft:shroomlight
fill 117 280 527 117 280 528 minecraft:shroomlight
fill 117 280 532 117 280 533 minecraft:shroomlight
fill 118 280 511 135 280 513 minecraft:basalt
fill 118 280 527 119 280 527 minecraft:shroomlight
fill 118 280 533 119 280 533 minecraft:shroomlight
fill 118 280 547 135 280 551 minecraft:basalt
fill 119 280 514 135 280 514 minecraft:basalt
fill 119 280 528 120 280 528 minecraft:shroomlight
fill 119 280 532 120 280 532 minecraft:shroomlight
fill 119 280 546 135 280 546 minecraft:basalt
fill 120 280 529 121 280 529 minecraft:shroomlight
fill 120 280 531 121 280 531 minecraft:shroomlight
setblock 121 280 530 minecraft:shroomlight
fill 124 280 515 135 280 515 minecraft:basalt
fill 124 280 545 135 280 545 minecraft:basalt
fill 126 280 516 135 280 516 minecraft:basalt
fill 126 280 544 135 280 544 minecraft:basalt
fill 128 280 517 135 280 517 minecraft:basalt
fill 128 280 543 135 280 543 minecraft:basalt
fill 129 280 518 135 280 518 minecraft:basalt
fill 129 280 542 135 280 542 minecraft:basalt
fill 130 280 519 135 280 519 minecraft:basalt
fill 130 280 541 135 280 541 minecraft:basalt
fill 131 280 520 135 280 520 minecraft:basalt
fill 131 280 540 135 280 540 minecraft:basalt
fill 132 280 521 135 280 522 minecraft:basalt
fill 132 280 538 135 280 539 minecraft:basalt
fill 133 280 523 135 280 524 minecraft:basalt
fill 133 280 536 135 280 537 minecraft:basalt
fill 134 280 525 135 280 529 minecraft:basalt
fill 134 280 531 135 280 535 minecraft:basalt
setblock 135 280 530 minecraft:basalt
fill 95 284 511 95 284 513 minecraft:blackstone
setblock 95 284 514 minecraft:smooth_basalt
fill 95 284 515 95 284 518 minecraft:blackstone
setblock 95 284 524 minecraft:smooth_basalt
fill 95 284 525 95 284 528 minecraft:blackstone
setblock 95 284 529 minecraft:smooth_basalt
fill 95 284 530 95 284 533 minecraft:blackstone
setblock 95 284 534 minecraft:smooth_basalt
fill 95 284 535 95 286 536 minecraft:blackstone
fill 96 284 511 97 284 511 minecraft:blackstone
fill 96 284 530 96 284 531 minecraft:blackstone
setblock 98 284 511 minecraft:smooth_basalt
fill 98 284 512 101 284 512 minecraft:blackstone
fill 99 284 511 102 284 511 minecraft:blackstone
fill 100 284 551 102 284 551 minecraft:blackstone
setblock 102 284 512 minecraft:smooth_basalt
fill 102 284 513 105 284 513 minecraft:blackstone
setblock 103 284 511 minecraft:smooth_basalt
fill 103 284 512 106 284 512 minecraft:blackstone
setblock 103 284 550 minecraft:blackstone
setblock 103 284 551 minecraft:smooth_basalt
fill 104 284 511 107 284 511 minecraft:blackstone
setblock 104 284 550 minecraft:smooth_basalt
fill 104 284 551 107 284 551 minecraft:blackstone
fill 105 284 550 108 284 550 minecraft:blackstone
setblock 106 284 513 minecraft:smooth_basalt
fill 106 284 514 108 285 514 minecraft:blackstone
setblock 107 284 512 minecraft:smooth_basalt
fill 107 284 513 110 284 513 minecraft:blackstone
fill 107 284 549 109 284 549 minecraft:blackstone
setblock 108 284 511 minecraft:smooth_basalt
fill 108 284 512 111 284 512 minecraft:blackstone
setblock 108 284 551 minecraft:smooth_basalt
fill 109 284 511 112 284 511 minecraft:blackstone
setblock 109 284 550 minecraft:smooth_basalt
fill 109 284 551 112 284 551 minecraft:blackstone
setblock 110 284 549 minecraft:smooth_basalt
fill 110 284 550 113 284 550 minecraft:blackstone
setblock 111 284 513 minecraft:smooth_basalt
fill 111 284 549 112 284 549 minecraft:blackstone
setblock 112 284 512 minecraft:smooth_basalt
fill 112 284 513 112 287 513 minecraft:blackstone
setblock 113 284 511 minecraft:smooth_basalt
fill 113 284 512 115 285 512 minecraft:blackstone
setblock 113 284 551 minecraft:smooth_basalt
fill 114 284 511 117 284 511 minecraft:blackstone
setblock 114 284 550 minecraft:smooth_basalt
fill 114 284 551 117 284 551 minecraft:blackstone
fill 115 284 550 118 284 550 minecraft:blackstone
setblock 118 284 511 minecraft:smooth_basalt
setblock 118 284 551 minecraft:smooth_basalt
fill 119 284 511 122 284 511 minecraft:blackstone
setblock 119 284 522 minecraft:gilded_blackstone
setblock 119 284 550 minecraft:smooth_basalt
fill 119 284 551 122 284 551 minecraft:blackstone
fill 120 284 550 123 284 550 minecraft:blackstone
setblock 123 284 511 minecraft:smooth_basalt
setblock 123 284 551 minecraft:smooth_basalt
fill 124 284 511 126 284 512 minecraft:blackstone
setblock 124 284 550 minecraft:smooth_basalt
fill 124 284 551 127 284 551 minecraft:blackstone
setblock 125 284 549 minecraft:smooth_basalt
fill 125 284 550 128 284 550 minecraft:blackstone
fill 126 284 549 128 284 549 minecraft:blackstone
setblock 127 284 511 minecraft:blackstone
setblock 127 284 512 minecraft:smooth_basalt
setblock 128 284 511 minecraft:smooth_basalt
fill 128 284 512 131 284 512 minecraft:blackstone
setblock 128 284 551 minecraft:smooth_basalt
fill 129 284 511 132 284 511 minecraft:blackstone
setblock 129 284 550 minecraft:smooth_basalt
fill 129 284 551 132 284 551 minecraft:blackstone
fill 130 284 550 131 285 550 minecraft:blackstone
setblock 132 284 531 minecraft:blackstone
setblock 132 284 532 minecraft:smooth_basalt
fill 132 284 533 135 284 533 minecraft:blackstone
setblock 133 284 511 minecraft:smooth_basalt
fill 133 284 529 133 284 530 minecraft:blackstone
setblock 133 284 531 minecraft:smooth_basalt
fill 133 284 532 135 285 532 minecraft:blackstone
fill 133 284 534 133 284 535 minecraft:blackstone
setblock 133 284 536 minecraft:smooth_basalt
setblock 133 284 551 minecraft:smooth_basalt
fill 134 284 511 135 286 511 minecraft:blackstone
fill 134 284 527 134 284 529 minecraft:blackstone
setblock 134 284 530 minecraft:smooth_basalt
fill 134 284 531 135 286 531 minecraft:blackstone
setblock 134 284 534 minecraft:blackstone
setblock 134 284 535 minecraft:smooth_basalt
fill 134 284 536 135 285 537 minecraft:blackstone
fill 134 284 551 134 285 551 minecraft:blackstone
fill 135 284 512 135 285 512 minecraft:blackstone
fill 135 284 525 135 284 528 minecraft:blackstone
setblock 135 284 529 minecraft:smooth_basalt
fill 135 284 530 135 287 530 minecraft:blackstone
setblock 135 284 534 minecraft:smooth_basalt
fill 135 284 535 135 287 535 minecraft:blackstone
setblock 135 284 538 minecraft:blackstone
fill 95 285 511 95 285 512 minecraft:blackstone
setblock 95 285 513 minecraft:smooth_basalt
fill 95 285 514 95 285 517 minecraft:blackstone
setblock 95 285 518 minecraft:smooth_basalt
fill 95 285 519 95 287 520 minecraft:blackstone
fill 95 285 524 95 285 527 minecraft:blackstone
setblock 95 285 528 minecraft:smooth_basalt
fill 95 285 529 95 285 532 minecraft:blackstone
setblock 95 285 533 minecraft:smooth_basalt
fill 95 285 534 95 288 534 minecraft:blackstone
setblock 96 285 511 minecraft:blackstone
setblock 96 285 512 minecraft:smooth_basalt
fill 96 285 513 96 287 514 minecraft:blackstone
setblock 96 285 531 minecraft:blackstone
setblock 97 285 511 minecraft:smooth_basalt
fill 97 285 512 100 285 512 minecraft:blackstone
setblock 97 285 513 minecraft:light[level=12]
setblock 97 285 521 minecraft:light[level=12]
setblock 97 285 529 minecraft:light[level=12]
setblock 97 285 537 minecraft:light[level=12]
setblock 97 285 545 minecraft:light[level=12]
fill 98 285 511 101 285 511 minecraft:blackstone
fill 99 285 551 101 285 551 minecraft:blackstone
setblock 101 285 512 minecraft:smooth_basalt
fill 101 285 513 104 285 513 minecraft:blackstone
setblock 102 285 511 minecraft:smooth_basalt
fill 102 285 512 105 285 512 minecraft:blackstone
setblock 102 285 551 minecraft:smooth_basalt
fill 103 285 511 106 285 511 minecraft:blackstone
setblock 103 285 550 minecraft:smooth_basalt
fill 103 285 551 106 285 551 minecraft:blackstone
setblock 104 285 514 minecraft:smooth_basalt
fill 104 285 550 107 285 550 minecraft:blackstone
setblock 105 285 513 minecraft:smooth_basalt
fill 105 285 514 105 288 514 minecraft:blackstone
setblock 105 285 521 minecraft:light[level=12]
setblock 105 285 529 minecraft:light[level=12]
setblock 105 285 537 minecraft:light[level=12]
setblock 105 285 545 minecraft:light[level=12]
setblock 106 285 512 minecraft:smooth_basalt
fill 106 285 513 109 285 513 minecraft:blackstone
fill 106 285 549 108 285 549 minecraft:blackstone
setblock 107 285 511 minecraft:smooth_basalt
fill 107 285 512 110 285 512 minecraft:blackstone
setblock 107 285 551 minecraft:smooth_basalt
fill 108 285 511 111 285 511 minecraft:blackstone
setblock 108 285 550 minecraft:smooth_basalt
fill 108 285 551 111 285 551 minecraft:blackstone
setblock 109 285 514 minecraft:smooth_basalt
setblock 109 285 549 minecraft:smooth_basalt
fill 109 285 550 112 285 550 minecraft:blackstone
setblock 110 285 513 minecraft:smooth_basalt
fill 110 285 549 111 285 549 minecraft:blackstone
setblock 111 285 512 minecraft:smooth_basalt
fill 111 285 513 111 288 513 minecraft:blackstone
setblock 112 285 511 minecraft:smooth_basalt
fill 112 285 512 112 288 512 minecraft:blackstone
setblock 112 285 551 minecraft:smooth_basalt
fill 113 285 511 116 285 511 minecraft:blackstone
setblock 113 285 513 minecraft:light[level=12]
setblock 113 285 521 minecraft:light[level=12]
setblock 113 285 529 minecraft:light[level=12]
setblock 113 285 537 minecraft:light[level=12]
setblock 113 285 545 minecraft:light[level=12]
setblock 113 285 550 minecraft:smooth_basalt
fill 113 285 551 116 285 551 minecraft:blackstone
fill 114 285 550 117 285 550 minecraft:blackstone
setblock 117 285 511 minecraft:smooth_basalt
setblock 117 285 551 minecraft:smooth_basalt
fill 118 285 511 121 285 511 minecraft:blackstone
setblock 118 285 550 minecraft:smooth_basalt
fill 118 285 551 121 285 551 minecraft:blackstone
fill 119 285 550 122 285 550 minecraft:blackstone
setblock 121 285 513 minecraft:light[level=12]
setblock 121 285 521 minecraft:light[level=12]
setblock 121 285 529 minecraft:light[level=12]
setblock 121 285 537 minecraft:light[level=12]
setblock 121 285 545 minecraft:light[level=12]
setblock 122 285 511 minecraft:smooth_basalt
fill 122 285 512 125 285 512 minecraft:blackstone
setblock 122 285 551 minecraft:smooth_basalt
fill 123 285 511 126 285 511 minecraft:blackstone
setblock 123 285 550 minecraft:smooth_basalt
fill 123 285 551 126 285 551 minecraft:blackstone
fill 124 285 550 127 285 550 minecraft:blackstone
fill 125 285 549 127 286 549 minecraft:blackstone
setblock 126 285 512 minecraft:smooth_basalt
setblock 127 285 511 minecraft:smooth_basalt
fill 127 285 512 130 285 512 minecraft:blackstone
setblock 127 285 551 minecraft:smooth_basalt
fill 128 285 511 131 285 511 minecraft:blackstone
setblock 128 285 550 minecraft:smooth_basalt
fill 128 285 551 131 285 551 minecraft:blackstone
setblock 129 285 513 minecraft:light[level=12]
setblock 129 285 521 minecraft:light[level=12]
setblock 129 285 529 minecraft:light[level=12]
setblock 129 285 537 minecraft:light[level=12]
setblock 129 285 545 minecraft:light[level=12]
fill 129 285 550 129 287 550 minecraft:blackstone
setblock 131 285 512 minecraft:smooth_basalt
setblock 132 285 511 minecraft:smooth_basalt
fill 132 285 512 132 287 512 minecraft:blackstone
setblock 132 285 531 minecraft:smooth_basalt
fill 132 285 532 132 286 534 minecraft:blackstone
setblock 132 285 551 minecraft:smooth_basalt
fill 133 285 511 133 288 511 minecraft:blackstone
setblock 133 285 529 minecraft:blackstone
setblock 133 285 530 minecraft:smooth_basalt
fill 133 285 531 133 288 531 minecraft:blackstone
fill 133 285 533 133 285 534 minecraft:blackstone
setblock 133 285 535 minecraft:smooth_basalt
fill 133 285 536 133 288 536 minecraft:blackstone
fill 133 285 551 133 286 551 minecraft:blackstone
fill 134 285 527 134 285 528 minecraft:blackstone
setblock 134 285 529 minecraft:smooth_basalt
fill 134 285 530 134 288 530 minecraft:blackstone
setblock 134 285 533 minecraft:blackstone
setblock 134 285 534 minecraft:smooth_basalt
fill 134 285 535 134 288 535 minecraft:blackstone
setblock 134 285 538 minecraft:blackstone
setblock 135 285 513 minecraft:smooth_basalt
fill 135 285 514 135 287 515 minecraft:blackstone
fill 135 285 525 135 285 527 minecraft:blackstone
setblock 135 285 528 minecraft:smooth_basalt
fill 135 285 529 135 288 529 minecraft:blackstone
setblock 135 285 533 minecraft:smooth_basalt
fill 135 285 534 135 288 534 minecraft:blackstone
setblock 135 285 538 minecraft:smooth_basalt
fill 135 285 539 135 288 539 minecraft:blackstone
setblock 95 286 511 minecraft:blackstone
setblock 95 286 512 minecraft:smooth_basalt
fill 95 286 513 95 286 516 minecraft:blackstone
setblock 95 286 517 minecraft:smooth_basalt
fill 95 286 518 95 289 518 minecraft:blackstone
setblock 95 286 521 minecraft:blackstone
setblock 95 286 522 minecraft:smooth_basalt
fill 95 286 523 95 286 526 minecraft:blackstone
setblock 95 286 527 minecraft:smooth_basalt
fill 95 286 528 95 286 531 minecraft:blackstone
setblock 95 286 532 minecraft:smooth_basalt
fill 95 286 533 95 289 533 minecraft:blackstone
setblock 95 286 537 minecraft:smooth_basalt
setblock 96 286 511 minecraft:smooth_basalt
fill 96 286 512 99 286 512 minecraft:blackstone
setblock 96 286 515 minecraft:blackstone
setblock 96 286 516 minecraft:smooth_basalt
fill 97 286 511 100 286 511 minecraft:blackstone
setblock 99 286 513 minecraft:smooth_basalt
fill 99 286 551 100 286 551 minecraft:blackstone
setblock 100 286 512 minecraft:smooth_basalt
fill 100 286 513 103 286 513 minecraft:blackstone
setblock 101 286 511 minecraft:smooth_basalt
fill 101 286 512 104 286 512 minecraft:blackstone
setblock 101 286 551 minecraft:smooth_basalt
fill 102 286 511 105 286 511 minecraft:blackstone
setblock 102 286 514 minecraft:blackstone
setblock 102 286 550 minecraft:smooth_basalt
fill 102 286 551 105 286 551 minecraft:blackstone
setblock 103 286 514 minecraft:smooth_basalt
fill 103 286 550 106 286 550 minecraft:blackstone
setblock 104 286 513 minecraft:smooth_basalt
fill 104 286 514 104 289 514 minecraft:blackstone
setblock 105 286 512 minecraft:smooth_basalt
fill 105 286 513 108 286 513 minecraft:blackstone
setblock 106 286 511 minecraft:smooth_basalt
fill 106 286 512 109 286 512 minecraft:blackstone
fill 106 286 514 107 286 514 minecraft:blackstone
fill 106 286 549 107 286 549 minecraft:blackstone
setblock 106 286 551 minecraft:smooth_basalt
fill 107 286 511 110 286 511 minecraft:blackstone
setblock 107 286 550 minecraft:smooth_basalt
fill 107 286 551 110 286 551 minecraft:blackstone
setblock 108 286 514 minecraft:smooth_basalt
setblock 108 286 549 minecraft:smooth_basalt
fill 108 286 550 111 286 550 minecraft:blackstone
setblock 109 286 513 minecraft:smooth_basalt
fill 109 286 514 110 287 514 minecraft:blackstone
fill 109 286 549 110 287 549 minecraft:blackstone
setblock 110 286 512 minecraft:smooth_basalt
fill 110 286 513 110 289 513 minecraft:blackstone
setblock 111 286 511 minecraft:smooth_basalt
fill 111 286 512 111 289 512 minecraft:blackstone
setblock 111 286 551 minecraft:smooth_basalt
fill 112 286 511 115 286 511 minecraft:blackstone
setblock 112 286 550 minecraft:smooth_basalt
fill 112 286 551 115 286 551 minecraft:blackstone
fill 113 286 512 114 286 512 minecraft:blackstone
fill 113 286 550 116 286 550 minecraft:blackstone
setblock 115 286 512 minecraft:smooth_basalt
setblock 116 286 511 minecraft:smooth_basalt
fill 116 286 512 116 287 512 minecraft:blackstone
setblock 116 286 551 minecraft:smooth_basalt
fill 117 286 511 120 286 511 minecraft:blackstone
setblock 117 286 550 minecraft:smooth_basalt
fill 117 286 551 120 286 551 minecraft:blackstone
fill 118 286 550 121 286 550 minecraft:blackstone
setblock 121 286 511 minecraft:smooth_basalt
fill 121 286 512 124 286 512 minecraft:blackstone
setblock 121 286 551 minecraft:smooth_basalt
fill 122 286 511 125 286 511 minecraft:blackstone
setblock 122 286 550 minecraft:smooth_basalt
fill 122 286 551 125 286 551 minecraft:blackstone
fill 123 286 550 126 286 550 minecraft:blackstone
setblock 125 286 512 minecraft:smooth_basalt
setblock 126 286 511 minecraft:smooth_basalt
fill 126 286 512 129 286 512 minecraft:blackstone
setblock 126 286 551 minecraft:smooth_basalt
fill 127 286 511 130 286 511 minecraft:blackstone
fill 127 286 513 127 287 513 minecraft:blackstone
setblock 127 286 550 minecraft:smooth_basalt
fill 127 286 551 130 286 551 minecraft:blackstone
fill 128 286 550 128 288 550 minecraft:blackstone
setblock 130 286 512 minecraft:smooth_basalt
setblock 130 286 550 minecraft:blackstone
setblock 131 286 511 minecraft:smooth_basalt
fill 131 286 512 131 288 512 minecraft:blackstone
setblock 131 286 551 minecraft:smooth_basalt
fill 132 286 511 132 289 511 minecraft:blackstone
setblock 132 286 535 minecraft:smooth_basalt
fill 132 286 551 132 287 551 minecraft:blackstone
setblock 133 286 529 minecraft:smooth_basalt
fill 133 286 530 133 287 530 minecraft:blackstone
fill 133 286 532 133 286 533 minecraft:blackstone
setblock 133 286 534 minecraft:smooth_basalt
fill 133 286 535 133 289 535 minecraft:blackstone
fill 133 286 537 134 286 537 minecraft:blackstone
setblock 134 286 527 minecraft:blackstone
setblock 134 286 528 minecraft:smooth_basalt
fill 134 286 529 134 288 529 minecraft:blackstone
setblock 134 286 532 minecraft:blackstone
setblock 134 286 533 minecraft:smooth_basalt
fill 134 286 534 134 289 534 minecraft:blackstone
fill 134 286 536 135 286 536 minecraft:blackstone
setblock 134 286 538 minecraft:smooth_basalt
setblock 135 286 512 minecraft:smooth_basalt
fill 135 286 513 135 289 513 minecraft:blackstone
setblock 135 286 516 minecraft:blackstone
setblock 135 286 517 minecraft:smooth_basalt
fill 135 286 525 135 286 526 minecraft:blackstone
setblock 135 286 527 minecraft:smooth_basalt
fill 135 286 528 135 289 528 minecraft:blackstone
setblock 135 286 532 minecraft:smooth_basalt
fill 135 286 533 135 289 533 minecraft:blackstone
setblock 135 286 537 minecraft:smooth_basalt
fill 135 286 538 135 289 538 minecraft:blackstone
setblock 95 287 511 minecraft:smooth_basalt
fill 95 287 512 95 287 515 minecraft:blackstone
setblock 95 287 516 minecraft:smooth_basalt
fill 95 287 517 96 289 517 minecraft:blackstone
setblock 95 287 521 minecraft:smooth_basalt
fill 95 287 522 95 288 523 minecraft:blackstone
setblock 95 287 525 minecraft:blackstone
setblock 95 287 526 minecraft:smooth_basalt
fill 95 287 527 95 287 530 minecraft:blackstone
setblock 95 287 531 minecraft:smooth_basalt
fill 95 287 532 95 290 532 minecraft:blackstone
setblock 95 287 535 minecraft:blackstone
setblock 95 287 536 minecraft:smooth_basalt
fill 95 287 537 95 290 537 minecraft:blackstone
fill 96 287 511 98 287 512 minecraft:blackstone
setblock 96 287 515 minecraft:smooth_basalt
fill 96 287 516 96 290 516 minecraft:blackstone
fill 96 287 518 96 288 518 minecraft:blackstone
setblock 98 287 513 minecraft:smooth_basalt
fill 98 287 551 99 287 551 minecraft:blackstone
setblock 99 287 511 minecraft:blackstone
setblock 99 287 512 minecraft:smooth_basalt
fill 99 287 513 102 287 513 minecraft:blackstone
setblock 100 287 511 minecraft:smooth_basalt
fill 100 287 512 103 287 512 minecraft:blackstone
setblock 100 287 551 minecraft:smooth_basalt
fill 101 287 511 104 287 511 minecraft:blackstone
setblock 101 287 514 minecraft:blackstone
fill 101 287 551 104 287 551 minecraft:blackstone
setblock 102 287 514 minecraft:smooth_basalt
fill 102 287 550 105 287 550 minecraft:blackstone
setblock 103 287 513 minecraft:smooth_basalt
fill 103 287 514 103 290 514 minecraft:blackstone
setblock 104 287 512 minecraft:smooth_basalt
fill 104 287 513 107 287 513 minecraft:blackstone
setblock 105 287 511 minecraft:smooth_basalt
fill 105 287 512 108 287 512 minecraft:blackstone
fill 105 287 549 106 287 549 minecraft:blackstone
setblock 105 287 551 minecraft:smooth_basalt
fill 106 287 511 109 287 511 minecraft:blackstone
setblock 106 287 514 minecraft:blackstone
setblock 106 287 550 minecraft:smooth_basalt
fill 106 287 551 109 287 551 minecraft:blackstone
setblock 107 287 514 minecraft:smooth_basalt
setblock 107 287 549 minecraft:smooth_basalt
fill 107 287 550 110 287 550 minecraft:blackstone
setblock 108 287 513 minecraft:smooth_basalt
fill 108 287 514 108 290 514 minecraft:blackstone
fill 108 287 549 108 288 549 minecraft:blackstone
setblock 109 287 512 minecraft:smooth_basalt
fill 109 287 513 109 290 513 minecraft:blackstone
setblock 110 287 511 minecraft:smooth_basalt
fill 110 287 512 110 290 512 minecraft:blackstone
setblock 110 287 551 minecraft:smooth_basalt
fill 111 287 511 114 287 511 minecraft:blackstone
setblock 111 287 550 minecraft:smooth_basalt
fill 111 287 551 114 287 551 minecraft:blackstone
fill 112 287 550 115 287 550 minecraft:blackstone
setblock 113 287 512 minecraft:blackstone
setblock 114 287 512 minecraft:smooth_basalt
setblock 115 287 511 minecraft:smooth_basalt
fill 115 287 512 115 288 512 minecraft:blackstone
setblock 115 287 551 minecraft:smooth_basalt
fill 116 287 511 119 287 511 minecraft:blackstone
fill 116 287 551 119 287 551 minecraft:blackstone
fill 118 287 550 120 287 550 minecraft:blackstone
setblock 120 287 511 minecraft:smooth_basalt
fill 120 287 512 123 287 512 minecraft:blackstone
setblock 120 287 551 minecraft:smooth_basalt
fill 121 287 511 124 287 511 minecraft:blackstone
setblock 121 287 550 minecraft:smooth_basalt
fill 121 287 551 124 287 551 minecraft:blackstone
fill 122 287 550 125 287 550 minecraft:blackstone
setblock 124 287 512 minecraft:smooth_basalt
setblock 125 287 511 minecraft:smooth_basalt
fill 125 287 512 126 288 513 minecraft:blackstone
setblock 125 287 551 minecraft:smooth_basalt
fill 126 287 511 129 287 511 minecraft:blackstone
setblock 126 287 550 minecraft:smooth_basalt
fill 126 287 551 129 287 551 minecraft:blackstone
fill 127 287 512 128 287 512 minecraft:blackstone
fill 127 287 550 127 289 550 minecraft:blackstone
setblock 128 287 513 minecraft:smooth_basalt
setblock 129 287 512 minecraft:smooth_basalt
setblock 130 287 511 minecraft:smooth_basalt
fill 130 287 512 130 289 512 minecraft:blackstone
setblock 130 287 551 minecraft:smooth_basalt
fill 131 287 511 131 290 511 minecraft:blackstone
fill 131 287 551 131 288 551 minecraft:blackstone
setblock 132 287 533 minecraft:blackstone
setblock 132 287 534 minecraft:smooth_basalt
setblock 132 287 535 minecraft:blackstone
setblock 133 287 532 minecraft:blackstone
setblock 133 287 533 minecraft:smooth_basalt
fill 133 287 534 133 289 534 minecraft:blackstone
setblock 133 287 537 minecraft:blackstone
setblock 134 287 511 minecraft:blackstone
setblock 134 287 528 minecraft:blackstone
setblock 134 287 531 minecraft:blackstone
setblock 134 287 532 minecraft:smooth_basalt
fill 134 287 533 134 290 533 minecraft:blackstone
setblock 134 287 536 minecraft:blackstone
setblock 134 287 537 minecraft:smooth_basalt
fill 134 287 538 134 290 538 minecraft:blackstone
setblock 135 287 511 minecraft:smooth_basalt
fill 135 287 512 135 290 512 minecraft:blackstone
setblock 135 287 516 minecraft:smooth_basalt
fill 135 287 517 135 288 519 minecraft:blackstone
setblock 135 287 525 minecraft:blackstone
setblock 135 287 526 minecraft:smooth_basalt
fill 135 287 527 135 289 527 minecraft:blackstone
setblock 135 287 531 minecraft:smooth_basalt
fill 135 287 532 135 290 532 minecraft:blackstone
setblock 135 287 536 minecraft:smooth_basalt
fill 135 287 537 135 290 537 minecraft:blackstone
setblock 135 287 540 minecraft:blackstone
fill 95 288 511 95 288 514 minecraft:blackstone
setblock 95 288 515 minecraft:smooth_basalt
fill 95 288 516 95 291 516 minecraft:blackstone
setblock 95 288 519 minecraft:blackstone
setblock 95 288 520 minecraft:smooth_basalt
fill 95 288 521 95 291 521 minecraft:blackstone
fill 95 288 527 95 288 529 minecraft:blackstone
setblock 95 288 530 minecraft:smooth_basalt
fill 95 288 531 95 289 531 minecraft:blackstone
setblock 95 288 535 minecraft:smooth_basalt
fill 95 288 536 95 290 536 minecraft:blackstone
fill 96 288 511 96 288 513 minecraft:blackstone
setblock 96 288 514 minecraft:smooth_basalt
fill 96 288 515 97 290 515 minecraft:blackstone
setblock 96 288 519 minecraft:smooth_basalt
fill 97 288 511 97 288 512 minecraft:blackstone
setblock 97 288 513 minecraft:smooth_basalt
fill 97 288 514 97 291 514 minecraft:blackstone
setblock 98 288 511 minecraft:blackstone
setblock 98 288 512 minecraft:smooth_basalt
fill 98 288 513 101 288 513 minecraft:blackstone
setblock 98 288 551 minecraft:blackstone
setblock 99 288 511 minecraft:smooth_basalt
fill 99 288 512 102 288 512 minecraft:blackstone
setblock 99 288 551 minecraft:smooth_basalt
fill 100 288 511 103 288 511 minecraft:blackstone
setblock 100 288 514 minecraft:blackstone
fill 100 288 551 103 288 551 minecraft:blackstone
setblock 101 288 514 minecraft:smooth_basalt
setblock 102 288 513 minecraft:smooth_basalt
fill 102 288 514 102 291 514 minecraft:blackstone
fill 102 288 550 104 288 550 minecraft:blackstone
setblock 103 288 512 minecraft:smooth_basalt
fill 103 288 513 106 288 513 minecraft:blackstone
setblock 104 288 511 minecraft:smooth_basalt
fill 104 288 512 107 288 512 minecraft:blackstone
setblock 104 288 551 minecraft:smooth_basalt
fill 105 288 511 108 288 511 minecraft:blackstone
setblock 105 288 515 minecraft:smooth_basalt
setblock 105 288 549 minecraft:blackstone
setblock 105 288 550 minecraft:smooth_basalt
fill 105 288 551 108 288 551 minecraft:blackstone
setblock 106 288 514 minecraft:smooth_basalt
setblock 106 288 549 minecraft:smooth_basalt
fill 106 288 550 109 288 550 minecraft:blackstone
setblock 107 288 513 minecraft:smooth_basalt
fill 107 288 514 107 290 514 minecraft:blackstone
setblock 107 288 549 minecraft:blackstone
setblock 108 288 512 minecraft:smooth_basalt
fill 108 288 513 108 291 513 minecraft:blackstone
setblock 109 288 511 minecraft:smooth_basalt
fill 109 288 512 109 291 512 minecraft:blackstone
fill 109 288 514 109 289 514 minecraft:blackstone
setblock 109 288 551 minecraft:smooth_basalt
fill 110 288 511 113 288 511 minecraft:blackstone
setblock 110 288 550 minecraft:smooth_basalt
fill 110 288 551 113 288 551 minecraft:blackstone
fill 111 288 550 113 288 550 minecraft:blackstone
setblock 112 288 513 minecraft:smooth_basalt
setblock 113 288 512 minecraft:smooth_basalt
setblock 114 288 511 minecraft:smooth_basalt
fill 114 288 512 114 289 512 minecraft:blackstone
setblock 114 288 551 minecraft:smooth_basalt
fill 115 288 511 118 288 511 minecraft:blackstone
fill 115 288 551 118 288 551 minecraft:blackstone
setblock 119 288 511 minecraft:smooth_basalt
fill 119 288 512 122 288 512 minecraft:blackstone
setblock 119 288 550 minecraft:blackstone
setblock 119 288 551 minecraft:smooth_basalt
fill 120 288 511 123 288 511 minecraft:blackstone
setblock 120 288 550 minecraft:smooth_basalt
fill 120 288 551 123 288 551 minecraft:blackstone
fill 121 288 550 124 288 550 minecraft:blackstone
setblock 123 288 512 minecraft:smooth_basalt
setblock 124 288 511 minecraft:smooth_basalt
fill 124 288 512 124 289 513 minecraft:blackstone
setblock 124 288 551 minecraft:smooth_basalt
fill 125 288 511 128 288 511 minecraft:blackstone
setblock 125 288 550 minecraft:smooth_basalt
fill 125 288 551 128 288 551 minecraft:blackstone
fill 126 288 550 126 289 550 minecraft:blackstone
setblock 127 288 512 minecraft:blackstone
setblock 127 288 513 minecraft:smooth_basalt
setblock 128 288 512 minecraft:smooth_basalt
setblock 128 288 513 minecraft:blackstone
setblock 129 288 511 minecraft:smooth_basalt
fill 129 288 512 129 290 512 minecraft:blackstone
setblock 129 288 551 minecraft:smooth_basalt
fill 130 288 511 130 290 511 minecraft:blackstone
fill 130 288 551 130 289 551 minecraft:blackstone
setblock 133 288 532 minecraft:smooth_basalt
fill 133 288 533 133 289 533 minecraft:blackstone
setblock 133 288 537 minecraft:smooth_basalt
setblock 134 288 511 minecraft:smooth_basalt
setblock 134 288 531 minecraft:smooth_basalt
fill 134 288 532 134 290 532 minecraft:blackstone
setblock 134 288 536 minecraft:smooth_basalt
fill 134 288 537 134 291 537 minecraft:blackstone
fill 135 288 511 135 289 511 minecraft:blackstone
setblock 135 288 514 minecraft:blackstone
setblock 135 288 515 minecraft:smooth_basalt
fill 135 288 516 135 291 516 minecraft:blackstone
setblock 135 288 520 minecraft:smooth_basalt
fill 135 288 521 135 291 521 minecraft:blackstone
setblock 135 288 525 minecraft:smooth_basalt
fill 135 288 526 135 289 526 minecraft:blackstone
setblock 135 288 530 minecraft:smooth_basalt
fill 135 288 531 135 291 531 minecraft:blackstone
setblock 135 288 535 minecraft:smooth_basalt
fill 135 288 536 135 291 536 minecraft:blackstone
setblock 135 288 540 minecraft:smooth_basalt
fill 95 289 511 95 289 513 minecraft:blackstone
setblock 95 289 514 minecraft:smooth_basalt
fill 95 289 515 95 292 515 minecraft:blackstone
setblock 95 289 519 minecraft:smooth_basalt
fill 95 289 520 95 292 520 minecraft:blackstone
fill 95 289 522 95 290 522 minecraft:blackstone
setblock 95 289 530 minecraft:blackstone
setblock 95 289 534 minecraft:smooth_basalt
fill 95 289 535 95 290 535 minecraft:blackstone
fill 96 289 511 96 289 512 minecraft:blackstone
setblock 96 289 513 minecraft:smooth_basalt
fill 96 289 514 96 292 514 minecraft:blackstone
setblock 96 289 518 minecraft:smooth_basalt
fill 96 289 519 96 292 519 minecraft:blackstone
setblock 97 289 511 minecraft:blackstone
setblock 97 289 512 minecraft:smooth_basalt
fill 97 289 513 100 289 513 minecraft:blackstone
setblock 97 289 516 minecraft:blackstone
setblock 98 289 511 minecraft:smooth_basalt
fill 98 289 512 101 289 512 minecraft:blackstone
setblock 98 289 551 minecraft:smooth_basalt
fill 99 289 511 102 289 511 minecraft:blackstone
fill 99 289 551 102 289 551 minecraft:blackstone
setblock 100 289 514 minecraft:smooth_basalt
setblock 101 289 513 minecraft:smooth_basalt
fill 101 289 514 101 292 514 minecraft:blackstone
setblock 102 289 512 minecraft:smooth_basalt
fill 102 289 513 105 289 513 minecraft:blackstone
fill 102 289 550 103 289 550 minecraft:blackstone
setblock 103 289 511 minecraft:smooth_basalt
fill 103 289 512 106 289 512 minecraft:blackstone
setblock 103 289 551 minecraft:smooth_basalt
fill 104 289 511 107 289 511 minecraft:blackstone
setblock 104 289 515 minecraft:smooth_basalt
setblock 104 289 550 minecraft:smooth_basalt
fill 104 289 551 107 289 551 minecraft:blackstone
setblock 105 289 514 minecraft:smooth_basalt
setblock 105 289 515 minecraft:blackstone
fill 105 289 550 108 289 550 minecraft:blackstone
setblock 106 289 513 minecraft:smooth_basalt
fill 106 289 514 106 291 514 minecraft:blackstone
setblock 107 289 512 minecraft:smooth_basalt
fill 107 289 513 107 292 513 minecraft:blackstone
setblock 108 289 511 minecraft:smooth_basalt
fill 108 289 512 108 292 512 minecraft:blackstone
setblock 108 289 551 minecraft:smooth_basalt
fill 109 289 511 112 289 511 minecraft:blackstone
fill 109 289 539 109 290 539 minecraft:gold_block
setblock 109 289 550 minecraft:smooth_basalt
fill 109 289 551 112 289 551 minecraft:blackstone
fill 110 289 550 112 289 550 minecraft:blackstone
setblock 111 289 513 minecraft:smooth_basalt
setblock 112 289 512 minecraft:smooth_basalt
setblock 113 289 511 minecraft:smooth_basalt
setblock 113 289 512 minecraft:blackstone
setblock 113 289 551 minecraft:smooth_basalt
fill 114 289 511 117 289 511 minecraft:blackstone
fill 114 289 551 117 289 551 minecraft:blackstone
setblock 118 289 511 minecraft:smooth_basalt
setblock 118 289 551 minecraft:smooth_basalt
fill 119 289 511 122 289 511 minecraft:blackstone
fill 119 289 551 122 289 551 minecraft:blackstone
fill 120 289 512 121 289 512 minecraft:blackstone
fill 120 289 550 123 289 550 minecraft:blackstone
setblock 122 289 512 minecraft:smooth_basalt
setblock 123 289 511 minecraft:smooth_basalt
fill 123 289 512 123 291 512 minecraft:blackstone
setblock 123 289 551 minecraft:smooth_basalt
fill 124 289 511 127 289 511 minecraft:blackstone
setblock 124 289 550 minecraft:smooth_basalt
fill 124 289 551 127 289 551 minecraft:blackstone
fill 125 289 512 125 289 513 minecraft:blackstone
fill 125 289 550 125 290 550 minecraft:blackstone
setblock 126 289 512 minecraft:blackstone
setblock 126 289 513 minecraft:smooth_basalt
setblock 127 289 512 minecraft:smooth_basalt
setblock 127 289 513 minecraft:blackstone
setblock 128 289 511 minecraft:smooth_basalt
fill 128 289 512 128 290 512 minecraft:blackstone
setblock 128 289 551 minecraft:smooth_basalt
fill 129 289 511 129 291 511 minecraft:blackstone
setblock 129 289 551 minecraft:blackstone
setblock 133 289 511 minecraft:smooth_basalt
setblock 133 289 536 minecraft:smooth_basalt
setblock 134 289 511 minecraft:blackstone
setblock 134 289 530 minecraft:smooth_basalt
setblock 134 289 531 minecraft:blackstone
setblock 134 289 535 minecraft:smooth_basalt
fill 134 289 536 134 291 536 minecraft:blackstone
setblock 135 289 514 minecraft:smooth_basalt
fill 135 289 515 135 292 515 minecraft:blackstone
fill 135 289 517 135 289 518 minecraft:blackstone
setblock 135 289 519 minecraft:smooth_basalt
fill 135 289 520 135 292 520 minecraft:blackstone
fill 135 289 522 135 290 522 minecraft:blackstone
setblock 135 289 529 minecraft:smooth_basalt
fill 135 289 530 135 291 530 minecraft:blackstone
setblock 135 289 534 minecraft:smooth_basalt
fill 135 289 535 135 292 535 minecraft:blackstone
setblock 135 289 539 minecraft:smooth_basalt
fill 135 289 540 135 291 540 minecraft:blackstone
fill 95 290 511 95 290 512 minecraft:blackstone
setblock 95 290 513 minecraft:smooth_basalt
fill 95 290 514 95 293 514 minecraft:blackstone
setblock 95 290 517 minecraft:blackstone
setblock 95 290 518 minecraft:smooth_basalt
fill 95 290 519 95 293 519 minecraft:blackstone
setblock 95 290 533 minecraft:smooth_basalt
setblock 95 290 534 minecraft:blackstone
setblock 96 290 511 minecraft:blackstone
setblock 96 290 512 minecraft:smooth_basalt
fill 96 290 513 99 290 513 minecraft:blackstone
setblock 96 290 517 minecraft:smooth_basalt
fill 96 290 518 96 293 518 minecraft:blackstone
setblock 97 290 511 minecraft:smooth_basalt
fill 97 290 512 100 290 512 minecraft:blackstone
setblock 97 290 516 minecraft:smooth_basalt
fill 97 290 517 97 293 517 minecraft:blackstone
fill 98 290 511 101 290 511 minecraft:blackstone
fill 99 290 551 101 290 551 minecraft:blackstone
setblock 100 290 513 minecraft:smooth_basalt
fill 100 290 514 100 291 514 minecraft:blackstone
setblock 101 290 512 minecraft:smooth_basalt
fill 101 290 513 104 290 513 minecraft:blackstone
setblock 102 290 511 minecraft:smooth_basalt
fill 102 290 512 105 290 512 minecraft:blackstone
setblock 102 290 550 minecraft:blackstone
setblock 102 290 551 minecraft:smooth_basalt
fill 103 290 511 106 290 511 minecraft:blackstone
setblock 103 290 550 minecraft:smooth_basalt
fill 103 290 551 106 290 551 minecraft:blackstone
setblock 104 290 514 minecraft:smooth_basalt
fill 104 290 550 107 290 550 minecraft:blackstone
setblock 105 290 513 minecraft:smooth_basalt
fill 105 290 514 105 292 514 minecraft:blackstone
setblock 106 290 512 minecraft:smooth_basalt
fill 106 290 513 106 293 513 minecraft:blackstone
setblock 107 290 511 minecraft:smooth_basalt
fill 107 290 512 107 293 512 minecraft:blackstone
setblock 107 290 551 minecraft:smooth_basalt
fill 108 290 511 111 290 511 minecraft:blackstone
setblock 108 290 550 minecraft:smooth_basalt
fill 108 290 551 111 290 551 minecraft:blackstone
fill 109 290 550 110 290 550 minecraft:blackstone
setblock 110 290 513 minecraft:smooth_basalt
setblock 111 290 512 minecraft:smooth_basalt
setblock 112 290 511 minecraft:smooth_basalt
setblock 112 290 512 minecraft:blackstone
setblock 112 290 551 minecraft:smooth_basalt
fill 113 290 511 116 290 511 minecraft:blackstone
fill 113 290 551 116 290 551 minecraft:blackstone
setblock 117 290 511 minecraft:smooth_basalt
setblock 117 290 551 minecraft:smooth_basalt
fill 118 290 511 121 290 511 minecraft:blackstone
fill 118 290 551 121 290 551 minecraft:blackstone
setblock 120 290 512 minecraft:blackstone
setblock 121 290 512 minecraft:smooth_basalt
fill 121 290 550 122 290 550 minecraft:blackstone
setblock 122 290 511 minecraft:smooth_basalt
fill 122 290 512 122 291 512 minecraft:blackstone
setblock 122 290 551 minecraft:smooth_basalt
fill 123 290 511 126 290 511 minecraft:blackstone
setblock 123 290 550 minecraft:smooth_basalt
fill 123 290 551 126 290 551 minecraft:blackstone
fill 124 290 512 125 290 512 minecraft:blackstone
setblock 124 290 550 minecraft:blackstone
setblock 126 290 512 minecraft:smooth_basalt
setblock 127 290 511 minecraft:smooth_basalt
fill 127 290 512 127 291 512 minecraft:blackstone
setblock 127 290 551 minecraft:smooth_basalt
fill 128 290 511 128 291 511 minecraft:blackstone
setblock 128 290 551 minecraft:blackstone
setblock 134 290 534 minecraft:smooth_basalt
fill 134 290 535 134 291 535 minecraft:blackstone
setblock 135 290 513 minecraft:smooth_basalt
fill 135 290 514 135 293 514 minecraft:blackstone
setblock 135 290 517 minecraft:blackstone
setblock 135 290 518 minecraft:smooth_basalt
fill 135 290 519 135 293 519 minecraft:blackstone
setblock 135 290 528 minecraft:smooth_basalt
setblock 135 290 529 minecraft:blackstone
setblock 135 290 533 minecraft:smooth_basalt
fill 135 290 534 135 293 534 minecraft:blackstone
setblock 135 290 538 minecraft:smooth_basalt
fill 135 290 539 135 293 539 minecraft:blackstone
setblock 95 291 511 minecraft:blackstone
setblock 95 291 512 minecraft:smooth_basalt
fill 95 291 513 96 293 513 minecraft:blackstone
setblock 95 291 517 minecraft:smooth_basalt
fill 95 291 518 95 294 518 minecraft:blackstone
setblock 95 291 522 minecraft:smooth_basalt
setblock 96 291 511 minecraft:smooth_basalt
fill 96 291 512 99 291 512 minecraft:blackstone
setblock 96 291 515 minecraft:blackstone
setblock 96 291 516 minecraft:smooth_basalt
fill 96 291 517 96 294 517 minecraft:blackstone
setblock 96 291 520 minecraft:blackstone
fill 97 291 511 100 291 511 minecraft:blackstone
setblock 97 291 515 minecraft:smooth_basalt
fill 97 291 516 97 294 516 minecraft:blackstone
setblock 98 291 513 minecraft:blackstone
setblock 99 291 513 minecraft:smooth_basalt
fill 99 291 551 100 291 551 minecraft:blackstone
setblock 100 291 512 minecraft:smooth_basalt
fill 100 291 513 103 291 513 minecraft:blackstone
setblock 101 291 511 minecraft:smooth_basalt
fill 101 291 512 104 291 512 minecraft:blackstone
setblock 101 291 551 minecraft:smooth_basalt
fill 102 291 511 105 291 511 minecraft:blackstone
setblock 102 291 550 minecraft:smooth_basalt
fill 102 291 551 105 291 551 minecraft:blackstone
setblock 103 291 514 minecraft:smooth_basalt
fill 103 291 550 106 291 550 minecraft:blackstone
setblock 104 291 513 minecraft:smooth_basalt
fill 104 291 514 104 292 514 minecraft:blackstone
setblock 105 291 512 minecraft:smooth_basalt
fill 105 291 513 105 293 513 minecraft:blackstone
setblock 106 291 511 minecraft:smooth_basalt
fill 106 291 512 106 294 512 minecraft:blackstone
setblock 106 291 551 minecraft:smooth_basalt
fill 107 291 511 110 291 511 minecraft:blackstone
setblock 107 291 550 minecraft:smooth_basalt
fill 107 291 551 110 291 551 minecraft:blackstone
setblock 108 291 550 minecraft:blackstone
setblock 109 291 513 minecraft:smooth_basalt
setblock 110 291 512 minecraft:smooth_basalt
setblock 111 291 511 minecraft:smooth_basalt
setblock 111 291 512 minecraft:blackstone
setblock 111 291 551 minecraft:smooth_basalt
fill 112 291 511 113 291 511 minecraft:blackstone
fill 112 291 551 113 291 551 minecraft:blackstone
fill 117 291 551 120 291 551 minecraft:blackstone
fill 118 291 511 120 291 511 minecraft:blackstone
setblock 121 291 511 minecraft:smooth_basalt
setblock 121 291 551 minecraft:smooth_basalt
fill 122 291 511 125 291 511 minecraft:blackstone
fill 122 291 551 125 291 551 minecraft:blackstone
setblock 124 291 512 minecraft:blackstone
setblock 125 291 512 minecraft:smooth_basalt
setblock 126 291 511 minecraft:smooth_basalt
setblock 126 291 512 minecraft:blackstone
setblock 126 291 551 minecraft:smooth_basalt
fill 127 291 511 127 292 511 minecraft:blackstone
setblock 127 291 551 minecraft:blackstone
setblock 134 291 534 minecraft:blackstone
fill 135 291 513 135 292 513 minecraft:blackstone
setblock 135 291 517 minecraft:smooth_basalt
fill 135 291 518 135 294 518 minecraft:blackstone
setblock 135 291 522 minecraft:smooth_basalt
setblock 135 291 532 minecraft:smooth_basalt
fill 135 291 533 135 292 533 minecraft:blackstone
setblock 135 291 537 minecraft:smooth_basalt
fill 135 291 538 135 294 538 minecraft:blackstone
setblock 95 292 511 minecraft:smooth_basalt
fill 95 292 512 98 292 512 minecraft:blackstone
setblock 95 292 516 minecraft:smooth_basalt
fill 95 292 517 95 295 517 minecraft:blackstone
setblock 95 292 521 minecraft:smooth_basalt
fill 95 292 522 95 295 522 minecraft:blackstone
fill 96 292 511 99 292 511 minecraft:blackstone
setblock 96 292 515 minecraft:smooth_basalt
fill 96 292 516 96 295 516 minecraft:blackstone
setblock 96 292 520 minecraft:smooth_basalt
setblock 97 292 514 minecraft:smooth_basalt
fill 97 292 515 97 293 515 minecraft:blackstone
setblock 98 292 513 minecraft:smooth_basalt
setblock 99 292 512 minecraft:smooth_basalt
fill 99 292 513 102 292 513 minecraft:blackstone
setblock 99 292 551 minecraft:blackstone
setblock 100 292 511 minecraft:smooth_basalt
fill 100 292 512 103 292 512 minecraft:blackstone
setblock 100 292 551 minecraft:smooth_basalt
fill 101 292 511 104 292 511 minecraft:blackstone
fill 101 292 551 104 292 551 minecraft:blackstone
setblock 102 292 514 minecraft:smooth_basalt
setblock 103 292 513 minecraft:smooth_basalt
setblock 103 292 514 minecraft:blackstone
fill 103 292 550 105 292 550 minecraft:blackstone
setblock 104 292 512 minecraft:smooth_basalt
fill 104 292 513 104 294 513 minecraft:blackstone
setblock 105 292 511 minecraft:smooth_basalt
fill 105 292 512 105 295 512 minecraft:blackstone
setblock 105 292 551 minecraft:smooth_basalt
fill 106 292 511 109 292 511 minecraft:blackstone
setblock 106 292 550 minecraft:smooth_basalt
fill 106 292 551 109 292 551 minecraft:blackstone
setblock 109 292 512 minecraft:smooth_basalt
setblock 110 292 511 minecraft:smooth_basalt
setblock 110 292 551 minecraft:smooth_basalt
setblock 111 292 511 minecraft:blackstone
setblock 119 292 551 minecraft:blackstone
setblock 120 292 511 minecraft:smooth_basalt
setblock 120 292 551 minecraft:smooth_basalt
fill 121 292 511 124 292 511 minecraft:blackstone
fill 121 292 551 124 292 551 minecraft:blackstone
setblock 125 292 511 minecraft:smooth_basalt
setblock 125 292 551 minecraft:smooth_basalt
setblock 126 292 511 minecraft:blackstone
setblock 135 292 516 minecraft:smooth_basalt
fill 135 292 517 135 295 517 minecraft:blackstone
setblock 135 292 521 minecraft:smooth_basalt
fill 135 292 522 135 294 523 minecraft:blackstone
setblock 135 292 532 minecraft:blackstone
setblock 135 292 536 minecraft:smooth_basalt
fill 135 292 537 135 294 537 minecraft:blackstone
fill 95 293 511 95 293 512 minecraft:blackstone
setblock 95 293 515 minecraft:smooth_basalt
fill 95 293 516 95 296 516 minecraft:blackstone
setblock 95 293 520 minecraft:smooth_basalt
fill 95 293 521 95 296 521 minecraft:blackstone
fill 96 293 511 98 293 511 minecraft:blackstone
setblock 96 293 514 minecraft:smooth_basalt
fill 96 293 515 96 296 515 minecraft:blackstone
setblock 96 293 519 minecraft:smooth_basalt
fill 96 293 520 96 296 520 minecraft:blackstone
setblock 97 293 512 minecraft:blackstone
setblock 97 293 513 minecraft:light[level=12]
setblock 97 293 521 minecraft:light[level=12]
setblock 97 293 529 minecraft:light[level=12]
setblock 97 293 537 minecraft:light[level=12]
setblock 97 293 545 minecraft:light[level=12]
setblock 98 293 512 minecraft:smooth_basalt
setblock 99 293 511 minecraft:smooth_basalt
fill 99 293 512 101 293 513 minecraft:blackstone
setblock 99 293 551 minecraft:smooth_basalt
fill 100 293 511 103 293 511 minecraft:blackstone
fill 100 293 551 103 293 551 minecraft:blackstone
setblock 102 293 512 minecraft:blackstone
setblock 102 293 513 minecraft:smooth_basalt
setblock 102 293 514 minecraft:blackstone
setblock 103 293 512 minecraft:smooth_basalt
fill 103 293 513 103 294 513 minecraft:blackstone
fill 103 293 550 104 293 550 minecraft:blackstone
setblock 104 293 511 minecraft:smooth_basalt
fill 104 293 512 104 296 512 minecraft:blackstone
setblock 104 293 551 minecraft:smooth_basalt
fill 105 293 511 108 293 511 minecraft:blackstone
setblock 105 293 521 minecraft:light[level=12]
setblock 105 293 529 minecraft:light[level=12]
setblock 105 293 537 minecraft:light[level=12]
setblock 105 293 545 minecraft:light[level=12]
fill 105 293 551 108 293 551 minecraft:blackstone
setblock 109 293 511 minecraft:smooth_basalt
setblock 109 293 551 minecraft:smooth_basalt
setblock 113 293 513 minecraft:light[level=12]
setblock 113 293 521 minecraft:light[level=12]
setblock 113 293 529 minecraft:light[level=12]
setblock 113 293 537 minecraft:light[level=12]
setblock 113 293 545 minecraft:light[level=12]
fill 120 293 551 123 293 551 minecraft:blackstone
fill 121 293 511 123 293 511 minecraft:blackstone
setblock 121 293 513 minecraft:light[level=12]
setblock 121 293 521 minecraft:light[level=12]
setblock 121 293 529 minecraft:light[level=12]
setblock 121 293 537 minecraft:light[level=12]
setblock 121 293 545 minecraft:light[level=12]
setblock 124 293 511 minecraft:smooth_basalt
setblock 125 293 511 minecraft:blackstone
setblock 129 293 513 minecraft:light[level=12]
setblock 129 293 521 minecraft:light[level=12]
setblock 129 293 529 minecraft:light[level=12]
setblock 129 293 537 minecraft:light[level=12]
setblock 129 293 545 minecraft:light[level=12]
setblock 135 293 515 minecraft:smooth_basalt
fill 135 293 516 135 296 516 minecraft:blackstone
setblock 135 293 520 minecraft:smooth_basalt
fill 135 293 521 135 296 521 minecraft:blackstone
setblock 135 293 535 minecraft:smooth_basalt
setblock 135 293 536 minecraft:blackstone
fill 95 294 512 95 294 513 minecraft:blackstone
setblock 95 294 514 minecraft:smooth_basalt
fill 95 294 515 95 297 515 minecraft:blackstone
setblock 95 294 519 minecraft:smooth_basalt
fill 95 294 520 95 297 520 minecraft:blackstone
fill 96 294 511 97 294 511 minecraft:blackstone
setblock 96 294 513 minecraft:smooth_basalt
fill 96 294 514 96 297 514 minecraft:blackstone
setblock 96 294 518 minecraft:smooth_basalt
fill 96 294 519 96 297 519 minecraft:blackstone
fill 96 294 521 96 295 521 minecraft:blackstone
setblock 97 294 512 minecraft:smooth_basalt
setblock 97 294 517 minecraft:smooth_basalt
fill 97 294 518 97 297 518 minecraft:blackstone
setblock 98 294 511 minecraft:smooth_basalt
fill 98 294 512 101 294 512 minecraft:blackstone
fill 99 294 511 102 294 511 minecraft:blackstone
fill 99 294 513 100 294 513 minecraft:blackstone
fill 99 294 551 102 294 551 minecraft:blackstone
setblock 101 294 513 minecraft:smooth_basalt
setblock 102 294 512 minecraft:smooth_basalt
fill 102 294 513 102 295 513 minecraft:blackstone
setblock 103 294 511 minecraft:smooth_basalt
fill 103 294 512 103 297 512 minecraft:blackstone
setblock 103 294 551 minecraft:smooth_basalt
fill 104 294 511 107 294 511 minecraft:blackstone
fill 104 294 551 107 294 551 minecraft:blackstone
setblock 108 294 511 minecraft:smooth_basalt
setblock 135 294 514 minecraft:smooth_basalt
fill 135 294 515 135 297 515 minecraft:blackstone
setblock 135 294 519 minecraft:smooth_basalt
fill 135 294 520 135 297 520 minecraft:blackstone
setblock 135 294 524 minecraft:smooth_basalt
setblock 95 295 512 minecraft:blackstone
setblock 95 295 513 minecraft:smooth_basalt
fill 95 295 514 95 298 514 minecraft:blackstone
setblock 95 295 518 minecraft:smooth_basalt
fill 95 295 519 95 298 519 minecraft:blackstone
setblock 95 295 523 minecraft:smooth_basalt
setblock 96 295 511 minecraft:blackstone
setblock 96 295 517 minecraft:smooth_basalt
fill 96 295 518 96 298 518 minecraft:blackstone
setblock 97 295 511 minecraft:smooth_basalt
setblock 97 295 516 minecraft:smooth_basalt
fill 97 295 517 97 298 517 minecraft:blackstone
fill 98 295 511 100 295 512 minecraft:blackstone
fill 99 295 551 101 295 551 minecraft:blackstone
setblock 100 295 513 minecraft:smooth_basalt
setblock 101 295 511 minecraft:blackstone
setblock 101 295 512 minecraft:smooth_basalt
setblock 101 295 513 minecraft:blackstone
setblock 102 295 511 minecraft:smooth_basalt
fill 102 295 512 102 298 512 minecraft:blackstone
setblock 102 295 551 minecraft:smooth_basalt
fill 103 295 511 106 295 511 minecraft:blackstone
fill 103 295 551 106 295 551 minecraft:blackstone
setblock 107 295 511 minecraft:smooth_basalt
setblock 107 295 551 minecraft:smooth_basalt
setblock 134 295 519 minecraft:smooth_basalt
fill 135 295 514 135 298 514 minecraft:blackstone
setblock 135 295 518 minecraft:smooth_basalt
fill 135 295 519 135 298 519 minecraft:blackstone
setblock 135 295 522 minecraft:blackstone
setblock 135 295 523 minecraft:smooth_basalt
fill 135 295 524 135 298 524 minecraft:blackstone
setblock 95 296 512 minecraft:smooth_basalt
fill 95 296 513 95 299 513 minecraft:blackstone
setblock 95 296 517 minecraft:smooth_basalt
fill 95 296 518 95 299 518 minecraft:blackstone
setblock 95 296 522 minecraft:smooth_basalt
fill 95 296 523 95 298 524 minecraft:blackstone
setblock 96 296 511 minecraft:smooth_basalt
setblock 96 296 516 minecraft:smooth_basalt
fill 96 296 517 96 299 517 minecraft:blackstone
setblock 96 296 521 minecraft:smooth_basalt
fill 96 296 522 96 299 522 minecraft:blackstone
fill 97 296 511 99 296 512 minecraft:blackstone
fill 97 296 516 97 299 516 minecraft:blackstone
setblock 97 296 519 minecraft:blackstone
fill 98 296 551 100 296 551 minecraft:blackstone
setblock 100 296 511 minecraft:blackstone
setblock 100 296 512 minecraft:smooth_basalt
setblock 101 296 511 minecraft:smooth_basalt
fill 101 296 512 101 299 512 minecraft:blackstone
setblock 101 296 551 minecraft:smooth_basalt
fill 102 296 511 105 296 511 minecraft:blackstone
fill 102 296 551 105 296 551 minecraft:blackstone
setblock 106 296 511 minecraft:smooth_basalt
setblock 106 296 551 minecraft:smooth_basalt
setblock 134 296 518 minecraft:smooth_basalt
fill 134 296 519 134 296 522 minecraft:blackstone
setblock 135 296 517 minecraft:smooth_basalt
fill 135 296 518 135 299 518 minecraft:blackstone
setblock 135 296 522 minecraft:smooth_basalt
fill 135 296 523 135 299 523 minecraft:blackstone
fill 135 296 525 135 297 525 minecraft:blackstone
setblock 95 297 511 minecraft:smooth_basalt
fill 95 297 512 95 300 512 minecraft:blackstone
setblock 95 297 516 minecraft:smooth_basalt
fill 95 297 517 95 300 517 minecraft:blackstone
setblock 95 297 521 minecraft:smooth_basalt
fill 95 297 522 95 300 522 minecraft:blackstone
setblock 95 297 525 minecraft:blackstone
setblock 95 297 541 minecraft:smooth_basalt
fill 95 297 542 95 298 544 minecraft:blackstone
fill 96 297 511 99 297 511 minecraft:blackstone
fill 96 297 513 96 298 513 minecraft:blackstone
setblock 96 297 515 minecraft:smooth_basalt
fill 96 297 516 96 300 516 minecraft:blackstone
setblock 96 297 520 minecraft:smooth_basalt
fill 96 297 521 97 299 521 minecraft:blackstone
fill 96 297 523 96 298 523 minecraft:blackstone
fill 97 297 512 98 297 512 minecraft:blackstone
setblock 97 297 519 minecraft:smooth_basalt
fill 97 297 520 97 300 520 minecraft:blackstone
fill 97 297 551 99 297 551 minecraft:blackstone
setblock 99 297 512 minecraft:smooth_basalt
setblock 100 297 511 minecraft:smooth_basalt
fill 100 297 512 100 300 512 minecraft:blackstone
setblock 100 297 550 minecraft:blackstone
setblock 100 297 551 minecraft:smooth_basalt
fill 101 297 511 104 297 511 minecraft:blackstone
setblock 101 297 550 minecraft:smooth_basalt
fill 101 297 551 104 297 551 minecraft:blackstone
fill 102 297 550 103 299 550 minecraft:blackstone
setblock 105 297 511 minecraft:smooth_basalt
setblock 105 297 551 minecraft:smooth_basalt
fill 106 297 551 106 300 551 minecraft:blackstone
setblock 134 297 517 minecraft:smooth_basalt
fill 134 297 518 134 297 521 minecraft:blackstone
setblock 134 297 522 minecraft:smooth_basalt
fill 134 297 523 134 300 523 minecraft:blackstone
setblock 135 297 516 minecraft:smooth_basalt
fill 135 297 517 135 300 517 minecraft:blackstone
setblock 135 297 521 minecraft:smooth_basalt
fill 135 297 522 135 300 522 minecraft:blackstone
setblock 135 297 526 minecraft:smooth_basalt
fill 135 297 527 135 300 527 minecraft:blackstone
fill 135 297 539 135 297 540 minecraft:blackstone
setblock 135 297 541 minecraft:smooth_basalt
fill 95 298 511 98 298 511 minecraft:blackstone
setblock 95 298 515 minecraft:smooth_basalt
fill 95 298 516 95 300 516 minecraft:blackstone
setblock 95 298 520 minecraft:smooth_basalt
fill 95 298 521 95 300 521 minecraft:blackstone
setblock 95 298 525 minecraft:smooth_basalt
fill 95 298 526 95 300 526 minecraft:blackstone
setblock 95 298 539 minecraft:blackstone
setblock 95 298 540 minecraft:smooth_basalt
fill 95 298 541 95 300 541 minecraft:blackstone
setblock 95 298 545 minecraft:smooth_basalt
fill 95 298 546 95 299 548 minecraft:blackstone
setblock 96 298 514 minecraft:smooth_basalt
fill 96 298 515 97 300 515 minecraft:blackstone
setblock 96 298 519 minecraft:smooth_basalt
fill 96 298 520 96 300 520 minecraft:blackstone
setblock 96 298 524 minecraft:smooth_basalt
fill 96 298 542 96 298 543 minecraft:blackstone
setblock 96 298 544 minecraft:smooth_basalt
fill 96 298 551 98 298 551 minecraft:blackstone
setblock 97 298 512 minecraft:blackstone
setblock 97 298 518 minecraft:smooth_basalt
fill 97 298 519 97 300 519 minecraft:blackstone
setblock 97 298 522 minecraft:blackstone
setblock 98 298 512 minecraft:smooth_basalt
fill 98 298 550 99 298 550 minecraft:blackstone
setblock 99 298 511 minecraft:smooth_basalt
fill 99 298 512 99 300 512 minecraft:blackstone
setblock 99 298 551 minecraft:smooth_basalt
fill 100 298 511 103 298 511 minecraft:blackstone
setblock 100 298 550 minecraft:smooth_basalt
fill 100 298 551 103 298 551 minecraft:blackstone
fill 101 298 550 101 300 550 minecraft:blackstone
setblock 104 298 511 minecraft:smooth_basalt
setblock 104 298 550 minecraft:blackstone
setblock 104 298 551 minecraft:smooth_basalt
setblock 105 298 511 minecraft:blackstone
fill 105 298 551 105 300 551 minecraft:blackstone
fill 117 298 551 118 298 551 minecraft:blackstone
setblock 119 298 551 minecraft:smooth_basalt
fill 120 298 551 121 300 551 minecraft:blackstone
fill 134 298 517 134 298 520 minecraft:blackstone
setblock 134 298 521 minecraft:smooth_basalt
fill 134 298 522 134 300 522 minecraft:blackstone
fill 134 298 524 134 298 525 minecraft:blackstone
fill 135 298 513 135 299 513 minecraft:blackstone
setblock 135 298 515 minecraft:smooth_basalt
fill 135 298 516 135 300 516 minecraft:blackstone
setblock 135 298 520 minecraft:smooth_basalt
fill 135 298 521 135 300 521 minecraft:blackstone
setblock 135 298 525 minecraft:smooth_basalt
fill 135 298 526 135 300 526 minecraft:blackstone
fill 135 298 528 135 299 528 minecraft:blackstone
fill 135 298 538 135 298 539 minecraft:blackstone
setblock 135 298 540 minecraft:smooth_basalt
fill 135 298 541 135 298 544 minecraft:blackstone
fill 95 299 511 97 299 511 minecraft:blackstone
setblock 95 299 514 minecraft:smooth_basalt
fill 95 299 515 95 300 515 minecraft:blackstone
setblock 95 299 519 minecraft:smooth_basalt
fill 95 299 520 95 300 520 minecraft:blackstone
setblock 95 299 523 minecraft:blackstone
setblock 95 299 524 minecraft:smooth_basalt
fill 95 299 525 96 300 525 minecraft:blackstone
fill 95 299 527 95 300 527 minecraft:blackstone
setblock 95 299 539 minecraft:smooth_basalt
fill 95 299 540 95 300 540 minecraft:blackstone
fill 95 299 542 95 299 543 minecraft:blackstone
setblock 95 299 544 minecraft:smooth_basalt
fill 95 299 545 97 300 545 minecraft:blackstone
setblock 95 299 549 minecraft:smooth_basalt
fill 95 299 550 95 300 551 minecraft:blackstone
setblock 96 299 512 minecraft:blackstone
setblock 96 299 513 minecraft:smooth_basalt
fill 96 299 514 96 300 514 minecraft:blackstone
setblock 96 299 518 minecraft:smooth_basalt
fill 96 299 519 96 300 519 minecraft:blackstone
setblock 96 299 523 minecraft:smooth_basalt
fill 96 299 524 96 300 524 minecraft:blackstone
fill 96 299 541 96 299 542 minecraft:blackstone
setblock 96 299 543 minecraft:smooth_basalt
fill 96 299 544 97 300 544 minecraft:blackstone
fill 96 299 546 96 299 547 minecraft:blackstone
setblock 96 299 548 minecraft:smooth_basalt
fill 96 299 549 96 300 549 minecraft:blackstone
fill 96 299 551 97 299 551 minecraft:blackstone
setblock 97 299 512 minecraft:smooth_basalt
setblock 97 299 517 minecraft:smooth_basalt
fill 97 299 518 97 300 518 minecraft:blackstone
setblock 97 299 522 minecraft:smooth_basalt
fill 97 299 523 97 300 523 minecraft:blackstone
fill 97 299 543 97 300 543 minecraft:blackstone
fill 97 299 550 98 299 550 minecraft:blackstone
setblock 98 299 511 minecraft:smooth_basalt
fill 98 299 512 98 300 512 minecraft:blackstone
setblock 98 299 551 minecraft:smooth_basalt
fill 99 299 511 102 299 511 minecraft:blackstone
setblock 99 299 549 minecraft:blackstone
setblock 99 299 550 minecraft:smooth_basalt
fill 99 299 551 102 299 551 minecraft:blackstone
setblock 100 299 549 minecraft:smooth_basalt
fill 100 299 550 100 300 550 minecraft:blackstone
fill 101 299 549 102 300 549 minecraft:blackstone
setblock 102 299 512 minecraft:smooth_basalt
setblock 103 299 511 minecraft:smooth_basalt
setblock 103 299 551 minecraft:smooth_basalt
fill 104 299 511 104 300 511 minecraft:blackstone
setblock 104 299 550 minecraft:smooth_basalt
fill 104 299 551 104 300 551 minecraft:blackstone
fill 105 299 550 105 300 550 minecraft:blackstone
setblock 107 299 551 minecraft:blackstone
fill 115 299 551 117 299 551 minecraft:blackstone
setblock 118 299 551 minecraft:smooth_basalt
fill 119 299 551 119 300 551 minecraft:blackstone
setblock 122 299 551 minecraft:blackstone
setblock 133 299 520 minecraft:blackstone
setblock 133 299 521 minecraft:smooth_basalt
fill 133 299 522 133 300 523 minecraft:blackstone
fill 134 299 516 134 299 519 minecraft:blackstone
setblock 134 299 520 minecraft:smooth_basalt
fill 134 299 521 134 300 521 minecraft:blackstone
setblock 134 299 524 minecraft:blackstone
setblock 134 299 525 minecraft:smooth_basalt
fill 134 299 526 134 300 526 minecraft:blackstone
fill 135 299 512 135 300 512 minecraft:blackstone
setblock 135 299 514 minecraft:smooth_basalt
fill 135 299 515 135 300 515 minecraft:blackstone
setblock 135 299 519 minecraft:smooth_basalt
fill 135 299 520 135 300 520 minecraft:blackstone
setblock 135 299 524 minecraft:smooth_basalt
fill 135 299 525 135 300 525 minecraft:blackstone
setblock 135 299 529 minecraft:smooth_basalt
fill 135 299 530 135 300 530 minecraft:blackstone
setblock 135 299 538 minecraft:blackstone
setblock 135 299 539 minecraft:smooth_basalt
fill 135 299 540 135 299 543 minecraft:blackstone
setblock 135 299 544 minecraft:smooth_basalt
fill 135 299 545 135 300 546 minecraft:blackstone
fill 95 300 511 96 300 511 minecraft:blackstone
setblock 95 300 513 minecraft:smooth_basalt
setblock 95 300 514 minecraft:blackstone
setblock 95 300 518 minecraft:smooth_basalt
setblock 95 300 519 minecraft:blackstone
setblock 95 300 523 minecraft:smooth_basalt
setblock 95 300 524 minecraft:blackstone
setblock 95 300 528 minecraft:smooth_basalt
setblock 95 300 538 minecraft:smooth_basalt
setblock 95 300 539 minecraft:blackstone
setblock 95 300 542 minecraft:blackstone
setblock 95 300 543 minecraft:smooth_basalt
setblock 95 300 544 minecraft:blackstone
fill 95 300 546 95 300 547 minecraft:blackstone
setblock 95 300 548 minecraft:smooth_basalt
setblock 95 300 549 minecraft:blackstone
setblock 96 300 512 minecraft:smooth_basalt
setblock 96 300 513 minecraft:blackstone
setblock 96 300 517 minecraft:smooth_basalt
setblock 96 300 518 minecraft:blackstone
setblock 96 300 521 minecraft:blackstone
setblock 96 300 522 minecraft:smooth_basalt
setblock 96 300 523 minecraft:blackstone
setblock 96 300 526 minecraft:blackstone
fill 96 300 540 96 300 541 minecraft:blackstone
setblock 96 300 542 minecraft:smooth_basalt
setblock 96 300 543 minecraft:blackstone
setblock 96 300 546 minecraft:blackstone
setblock 96 300 547 minecraft:smooth_basalt
fill 96 300 548 97 300 548 minecraft:blackstone
fill 96 300 550 96 300 551 minecraft:blackstone
setblock 97 300 511 minecraft:smooth_basalt
setblock 97 300 512 minecraft:blackstone
setblock 97 300 516 minecraft:smooth_basalt
setblock 97 300 517 minecraft:blackstone
setblock 97 300 521 minecraft:smooth_basalt
setblock 97 300 522 minecraft:blackstone
setblock 97 300 524 minecraft:blackstone
setblock 97 300 542 minecraft:blackstone
setblock 97 300 546 minecraft:smooth_basalt
setblock 97 300 547 minecraft:blackstone
fill 97 300 549 97 300 550 minecraft:blackstone
setblock 97 300 551 minecraft:smooth_basalt
fill 98 300 511 101 300 511 minecraft:blackstone
setblock 98 300 549 minecraft:blackstone
setblock 98 300 550 minecraft:smooth_basalt
fill 98 300 551 101 300 551 minecraft:blackstone
setblock 99 300 549 minecraft:smooth_basalt
setblock 99 300 550 minecraft:blackstone
setblock 100 300 549 minecraft:blackstone
setblock 101 300 512 minecraft:smooth_basalt
setblock 102 300 511 minecraft:smooth_basalt
setblock 102 300 512 minecraft:blackstone
setblock 102 300 550 minecraft:blackstone
setblock 102 300 551 minecraft:smooth_basalt
setblock 103 300 511 minecraft:blackstone
setblock 103 300 549 minecraft:blackstone
setblock 103 300 550 minecraft:smooth_basalt
setblock 103 300 551 minecraft:blackstone
setblock 104 300 550 minecraft:blackstone
setblock 106 300 550 minecraft:blackstone
setblock 107 300 551 minecraft:smooth_basalt
setblock 108 300 551 minecraft:blackstone
setblock 112 300 551 minecraft:smooth_basalt
fill 113 300 551 116 300 551 minecraft:blackstone
fill 115 300 550 117 300 550 minecraft:blackstone
setblock 117 300 551 minecraft:smooth_basalt
setblock 118 300 550 minecraft:smooth_basalt
setblock 118 300 551 minecraft:blackstone
fill 119 300 550 120 300 550 minecraft:blackstone
setblock 122 300 551 minecraft:smooth_basalt
setblock 133 300 519 minecraft:blackstone
setblock 133 300 520 minecraft:smooth_basalt
setblock 133 300 521 minecraft:blackstone
setblock 133 300 524 minecraft:blackstone
setblock 133 300 525 minecraft:smooth_basalt
fill 134 300 515 134 300 518 minecraft:blackstone
setblock 134 300 519 minecraft:smooth_basalt
setblock 134 300 520 minecraft:blackstone
setblock 134 300 524 minecraft:smooth_basalt
setblock 134 300 525 minecraft:blackstone
fill 134 300 527 134 300 528 minecraft:blackstone
setblock 135 300 511 minecraft:blackstone
setblock 135 300 513 minecraft:smooth_basalt
setblock 135 300 514 minecraft:blackstone
setblock 135 300 518 minecraft:smooth_basalt
setblock 135 300 519 minecraft:blackstone
setblock 135 300 523 minecraft:smooth_basalt
setblock 135 300 524 minecraft:blackstone
setblock 135 300 528 minecraft:smooth_basalt
setblock 135 300 529 minecraft:blackstone
setblock 135 300 531 minecraft:blackstone
setblock 135 300 537 minecraft:blackstone
setblock 135 300 538 minecraft:smooth_basalt
fill 135 300 539 135 300 542 minecraft:blackstone
setblock 135 300 543 minecraft:smooth_basalt
setblock 135 300 544 minecraft:blackstone
setblock 135 300 547 minecraft:blackstone
setblock 135 300 548 minecraft:smooth_basalt
setblock 135 300 549 minecraft:blackstone
setblock 97 301 513 minecraft:light[level=12]
setblock 97 301 521 minecraft:light[level=12]
setblock 97 301 529 minecraft:light[level=12]
setblock 97 301 537 minecraft:light[level=12]
setblock 97 301 545 minecraft:light[level=12]
setblock 105 301 513 minecraft:light[level=12]
setblock 105 301 521 minecraft:light[level=12]
setblock 105 301 529 minecraft:light[level=12]
setblock 105 301 537 minecraft:light[level=12]
setblock 105 301 545 minecraft:light[level=12]
setblock 113 301 513 minecraft:light[level=12]
setblock 113 301 521 minecraft:light[level=12]
setblock 113 301 529 minecraft:light[level=12]
setblock 113 301 537 minecraft:light[level=12]
setblock 113 301 545 minecraft:light[level=12]
setblock 121 301 513 minecraft:light[level=12]
setblock 121 301 521 minecraft:light[level=12]
setblock 121 301 529 minecraft:light[level=12]
setblock 121 301 537 minecraft:light[level=12]
setblock 121 301 545 minecraft:light[level=12]
setblock 129 301 513 minecraft:light[level=12]
setblock 129 301 521 minecraft:light[level=12]
setblock 129 301 529 minecraft:light[level=12]
setblock 129 301 537 minecraft:light[level=12]
setblock 129 301 545 minecraft:light[level=12]
