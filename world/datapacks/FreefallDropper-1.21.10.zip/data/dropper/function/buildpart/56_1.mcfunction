fill 418 118 255 418 129 255 minecraft:brown_terracotta
setblock 376 119 255 minecraft:brown_terracotta
fill 379 119 270 379 131 270 minecraft:brown_terracotta
setblock 417 119 270 minecraft:mossy_cobblestone
setblock 418 119 250 minecraft:jungle_leaves[persistent=true]
setblock 376 120 255 minecraft:moss_block
setblock 376 120 268 minecraft:moss_block
setblock 379 120 238 minecraft:light[level=12]
setblock 379 120 245 minecraft:light[level=12]
setblock 379 120 252 minecraft:light[level=12]
setblock 379 120 259 minecraft:light[level=12]
setblock 386 120 231 minecraft:light[level=12]
setblock 386 120 238 minecraft:light[level=12]
setblock 386 120 245 minecraft:light[level=12]
setblock 386 120 252 minecraft:light[level=12]
setblock 386 120 259 minecraft:light[level=12]
setblock 386 120 266 minecraft:light[level=12]
setblock 393 120 231 minecraft:light[level=12]
setblock 393 120 238 minecraft:light[level=12]
setblock 393 120 245 minecraft:light[level=12]
setblock 393 120 252 minecraft:light[level=12]
setblock 393 120 259 minecraft:light[level=12]
setblock 393 120 266 minecraft:light[level=12]
setblock 400 120 231 minecraft:light[level=12]
setblock 400 120 238 minecraft:light[level=12]
setblock 400 120 245 minecraft:light[level=12]
setblock 400 120 252 minecraft:light[level=12]
setblock 400 120 259 minecraft:light[level=12]
setblock 400 120 266 minecraft:light[level=12]
setblock 407 120 231 minecraft:light[level=12]
setblock 407 120 238 minecraft:light[level=12]
setblock 407 120 245 minecraft:light[level=12]
setblock 407 120 252 minecraft:light[level=12]
setblock 407 120 259 minecraft:light[level=12]
setblock 407 120 266 minecraft:light[level=12]
setblock 410 120 270 minecraft:mossy_cobblestone
setblock 414 120 238 minecraft:light[level=12]
setblock 414 120 245 minecraft:light[level=12]
setblock 414 120 252 minecraft:light[level=12]
setblock 414 120 259 minecraft:light[level=12]
fill 417 120 270 417 122 270 minecraft:brown_terracotta
fill 418 120 250 418 149 250 minecraft:brown_terracotta
setblock 418 120 267 minecraft:green_concrete
fill 376 121 255 376 149 255 minecraft:brown_terracotta
fill 376 121 268 376 149 268 minecraft:brown_terracotta
setblock 379 121 239 minecraft:light[level=15]
setblock 379 121 247 minecraft:light[level=15]
setblock 379 121 255 minecraft:light[level=15]
fill 380 121 259 380 128 259 minecraft:green_wool
setblock 387 121 231 minecraft:light[level=15]
setblock 387 121 239 minecraft:light[level=15]
setblock 387 121 247 minecraft:light[level=15]
setblock 387 121 255 minecraft:light[level=15]
setblock 387 121 263 minecraft:light[level=15]
fill 392 121 269 392 127 269 minecraft:moss_block
setblock 395 121 231 minecraft:light[level=15]
setblock 395 121 239 minecraft:light[level=15]
setblock 395 121 247 minecraft:light[level=15]
setblock 395 121 255 minecraft:light[level=15]
setblock 395 121 263 minecraft:light[level=15]
setblock 403 121 231 minecraft:light[level=15]
setblock 403 121 239 minecraft:light[level=15]
setblock 403 121 247 minecraft:light[level=15]
setblock 403 121 255 minecraft:light[level=15]
setblock 403 121 263 minecraft:light[level=15]
fill 410 121 270 410 143 270 minecraft:brown_terracotta
setblock 411 121 239 minecraft:light[level=15]
setblock 411 121 247 minecraft:light[level=15]
setblock 411 121 255 minecraft:light[level=15]
setblock 411 121 263 minecraft:light[level=15]
setblock 418 121 237 minecraft:moss_block
setblock 418 121 261 minecraft:mossy_cobblestone
fill 418 121 262 418 147 263 minecraft:brown_terracotta
fill 418 121 267 418 139 267 minecraft:brown_terracotta
fill 376 122 261 376 139 261 minecraft:brown_terracotta
setblock 376 122 262 minecraft:moss_block
fill 376 122 263 376 139 263 minecraft:brown_terracotta
fill 403 122 231 407 123 235 minecraft:dirt
fill 405 122 229 405 122 230 minecraft:dirt
setblock 410 122 228 minecraft:jungle_leaves[persistent=true]
fill 418 122 237 418 125 237 minecraft:brown_terracotta
setblock 418 122 242 minecraft:moss_block
fill 418 122 243 418 149 243 minecraft:brown_terracotta
fill 418 122 261 418 139 261 minecraft:brown_terracotta
fill 376 123 262 376 138 262 minecraft:brown_terracotta
fill 401 123 270 401 146 270 minecraft:brown_terracotta
setblock 402 123 270 minecraft:moss_block
fill 403 123 270 403 149 270 minecraft:brown_terracotta
fill 410 123 228 410 149 228 minecraft:brown_terracotta
setblock 417 123 270 minecraft:moss_block
fill 418 123 242 418 149 242 minecraft:brown_terracotta
setblock 393 124 228 minecraft:jungle_leaves[persistent=true]
fill 401 124 232 403 125 232 minecraft:bone_block
fill 401 124 234 403 125 234 minecraft:bone_block
fill 402 124 233 402 125 233 minecraft:bone_block
fill 402 124 270 402 149 270 minecraft:brown_terracotta
fill 408 124 270 408 146 270 minecraft:brown_terracotta
setblock 409 124 270 minecraft:green_concrete
fill 417 124 270 417 146 270 minecraft:brown_terracotta
setblock 418 124 233 minecraft:green_concrete
fill 418 124 234 418 148 235 minecraft:brown_terracotta
fill 379 125 247 379 141 247 minecraft:iron_block
setblock 386 125 228 minecraft:moss_block
fill 387 125 228 388 126 228 minecraft:brown_terracotta
fill 393 125 228 393 147 228 minecraft:brown_terracotta
fill 403 125 233 404 126 233 minecraft:bone_block
fill 409 125 270 409 149 270 minecraft:brown_terracotta
fill 418 125 233 418 139 233 minecraft:brown_terracotta
setblock 418 125 265 minecraft:green_concrete
fill 418 125 266 418 145 266 minecraft:brown_terracotta
fill 378 126 259 378 130 260 minecraft:azalea_leaves[persistent=true]
setblock 379 126 238 minecraft:light[level=12]
setblock 379 126 245 minecraft:light[level=12]
setblock 379 126 252 minecraft:light[level=12]
fill 379 126 259 379 131 259 minecraft:azalea_leaves[persistent=true]
fill 383 126 260 384 131 260 minecraft:azalea_leaves[persistent=true]
fill 385 126 269 385 131 269 minecraft:jungle_leaves[persistent=true]
setblock 385 126 270 minecraft:brown_terracotta
setblock 386 126 228 minecraft:brown_terracotta
setblock 386 126 231 minecraft:light[level=12]
setblock 386 126 238 minecraft:light[level=12]
setblock 386 126 245 minecraft:light[level=12]
setblock 386 126 252 minecraft:light[level=12]
setblock 386 126 259 minecraft:light[level=12]
setblock 386 126 266 minecraft:light[level=12]
fill 386 126 270 386 131 270 minecraft:jungle_leaves[persistent=true]
fill 387 126 269 387 131 269 minecraft:jungle_leaves[persistent=true]
setblock 387 126 270 minecraft:brown_terracotta
setblock 393 126 231 minecraft:light[level=12]
setblock 393 126 238 minecraft:light[level=12]
setblock 393 126 245 minecraft:light[level=12]
setblock 393 126 252 minecraft:light[level=12]
setblock 393 126 259 minecraft:light[level=12]
setblock 393 126 266 minecraft:light[level=12]
setblock 400 126 231 minecraft:light[level=12]
setblock 400 126 238 minecraft:light[level=12]
setblock 400 126 245 minecraft:light[level=12]
setblock 400 126 252 minecraft:light[level=12]
setblock 400 126 259 minecraft:light[level=12]
setblock 400 126 266 minecraft:light[level=12]
fill 405 126 233 405 127 233 minecraft:bone_block
setblock 406 126 228 minecraft:moss_block
setblock 407 126 231 minecraft:light[level=12]
setblock 407 126 238 minecraft:light[level=12]
setblock 407 126 245 minecraft:light[level=12]
setblock 407 126 252 minecraft:light[level=12]
setblock 407 126 259 minecraft:light[level=12]
fill 407 126 263 407 130 266 minecraft:oak_leaves[persistent=true]
fill 408 126 263 409 130 263 minecraft:oak_leaves[persistent=true]
fill 408 126 266 408 130 266 minecraft:oak_leaves[persistent=true]
fill 409 126 260 410 130 260 minecraft:oak_leaves[persistent=true]
fill 409 126 262 410 130 262 minecraft:oak_leaves[persistent=true]
setblock 414 126 238 minecraft:light[level=12]
setblock 414 126 245 minecraft:light[level=12]
setblock 414 126 252 minecraft:light[level=12]
setblock 414 126 259 minecraft:light[level=12]
fill 416 126 238 416 143 238 minecraft:jungle_leaves[persistent=true]
setblock 418 126 237 minecraft:green_concrete
fill 418 126 265 418 149 265 minecraft:brown_terracotta
setblock 376 127 231 minecraft:brown_terracotta
fill 376 127 232 376 128 233 minecraft:jungle_log
setblock 376 127 267 minecraft:mossy_cobblestone
fill 377 127 258 377 130 260 minecraft:azalea_leaves[persistent=true]
fill 378 127 258 380 130 258 minecraft:azalea_leaves[persistent=true]
fill 378 127 261 379 129 261 minecraft:azalea_leaves[persistent=true]
fill 379 127 260 380 130 260 minecraft:azalea_leaves[persistent=true]
fill 379 127 262 380 128 262 minecraft:jungle_log
fill 382 127 259 382 130 261 minecraft:azalea_leaves[persistent=true]
fill 382 127 262 382 127 263 minecraft:jungle_log
fill 383 127 229 383 128 230 minecraft:jungle_log
fill 383 127 258 384 129 259 minecraft:azalea_leaves[persistent=true]
fill 383 127 261 384 129 262 minecraft:azalea_leaves[persistent=true]
fill 383 127 268 384 128 268 minecraft:jungle_log
fill 384 127 228 387 130 228 minecraft:azalea_leaves[persistent=true]
fill 384 127 270 385 129 270 minecraft:jungle_leaves[persistent=true]
fill 385 127 229 387 129 229 minecraft:azalea_leaves[persistent=true]
fill 385 127 259 385 129 261 minecraft:azalea_leaves[persistent=true]
fill 385 127 268 388 128 268 minecraft:jungle_leaves[persistent=true]
fill 386 127 269 386 130 269 minecraft:jungle_leaves[persistent=true]
fill 387 127 267 387 128 267 minecraft:jungle_leaves[persistent=true]
fill 387 127 270 387 130 270 minecraft:jungle_leaves[persistent=true]
setblock 388 127 228 minecraft:brown_terracotta
fill 388 127 269 388 130 269 minecraft:jungle_leaves[persistent=true]
fill 393 127 270 393 136 270 minecraft:brown_terracotta
setblock 394 127 270 minecraft:jungle_leaves[persistent=true]
fill 395 127 270 397 140 270 minecraft:brown_terracotta
fill 405 127 266 406 129 266 minecraft:oak_leaves[persistent=true]
fill 406 127 228 406 146 228 minecraft:brown_terracotta
fill 406 127 233 407 128 233 minecraft:bone_block
fill 406 127 261 406 128 265 minecraft:oak_leaves[persistent=true]
fill 407 127 261 408 130 262 minecraft:oak_leaves[persistent=true]
fill 407 127 267 408 129 267 minecraft:oak_leaves[persistent=true]
fill 408 127 260 408 130 260 minecraft:oak_leaves[persistent=true]
fill 408 127 264 408 130 265 minecraft:oak_leaves[persistent=true]
fill 409 127 259 410 129 259 minecraft:oak_leaves[persistent=true]
fill 409 127 261 411 130 261 minecraft:oak_leaves[persistent=true]
fill 409 127 264 409 130 264 minecraft:oak_leaves[persistent=true]
fill 409 127 266 409 130 266 minecraft:oak_leaves[persistent=true]
fill 410 127 263 410 128 263 minecraft:oak_leaves[persistent=true]
fill 410 127 264 410 127 266 minecraft:jungle_log
fill 411 127 260 411 130 260 minecraft:oak_leaves[persistent=true]
fill 411 127 263 411 128 264 minecraft:jungle_log
fill 412 127 228 412 127 229 minecraft:jungle_log
fill 412 127 263 412 128 263 minecraft:jungle_log
fill 413 127 228 413 128 228 minecraft:jungle_log
fill 416 127 228 417 149 228 minecraft:brown_terracotta
fill 417 127 229 417 128 230 minecraft:jungle_log
fill 418 127 228 418 130 228 minecraft:oak_leaves[persistent=true]
setblock 418 127 229 minecraft:azalea_leaves[persistent=true]
fill 418 127 230 418 128 230 minecraft:jungle_log
fill 418 127 237 418 149 237 minecraft:brown_terracotta
setblock 418 127 256 minecraft:green_concrete
fill 418 127 257 418 140 259 minecraft:brown_terracotta
setblock 376 128 231 minecraft:jungle_log
setblock 376 128 234 minecraft:jungle_log
fill 376 128 260 376 129 260 minecraft:azalea_leaves[persistent=true]
fill 376 128 267 376 130 267 minecraft:brown_terracotta
fill 378 128 257 380 128 257 minecraft:azalea_leaves[persistent=true]
setblock 379 128 239 minecraft:light[level=15]
setblock 379 128 255 minecraft:light[level=15]
fill 380 128 261 381 129 261 minecraft:azalea_leaves[persistent=true]
fill 381 128 259 381 130 260 minecraft:azalea_leaves[persistent=true]
setblock 382 128 258 minecraft:azalea_leaves[persistent=true]
fill 382 128 262 382 130 262 minecraft:azalea_leaves[persistent=true]
setblock 382 128 263 minecraft:jungle_log
fill 383 128 228 383 129 228 minecraft:azalea_leaves[persistent=true]
fill 384 128 229 384 130 229 minecraft:azalea_leaves[persistent=true]
fill 384 128 269 384 130 269 minecraft:jungle_leaves[persistent=true]
fill 385 128 258 385 129 258 minecraft:azalea_leaves[persistent=true]
fill 385 128 267 386 129 267 minecraft:jungle_leaves[persistent=true]
setblock 387 128 231 minecraft:light[level=15]
setblock 387 128 239 minecraft:light[level=15]
setblock 387 128 247 minecraft:light[level=15]
setblock 387 128 255 minecraft:light[level=15]
setblock 387 128 263 minecraft:light[level=15]
fill 388 128 228 388 129 228 minecraft:azalea_leaves[persistent=true]
fill 388 128 270 388 130 270 minecraft:jungle_leaves[persistent=true]
fill 394 128 270 394 146 270 minecraft:brown_terracotta
setblock 395 128 228 minecraft:moss_block
setblock 395 128 231 minecraft:light[level=15]
setblock 395 128 239 minecraft:light[level=15]
setblock 395 128 247 minecraft:light[level=15]
setblock 395 128 255 minecraft:light[level=15]
setblock 395 128 263 minecraft:light[level=15]
fill 402 128 228 404 137 228 minecraft:brown_terracotta
setblock 403 128 231 minecraft:light[level=15]
setblock 403 128 239 minecraft:light[level=15]
setblock 403 128 247 minecraft:light[level=15]
setblock 403 128 255 minecraft:light[level=15]
setblock 403 128 263 minecraft:light[level=15]
setblock 405 128 228 minecraft:mossy_cobblestone
fill 405 128 264 405 129 265 minecraft:oak_leaves[persistent=true]
fill 405 128 267 406 129 267 minecraft:oak_leaves[persistent=true]
fill 407 128 232 409 129 232 minecraft:bone_block
fill 407 128 234 409 129 234 minecraft:bone_block
fill 407 128 260 407 129 260 minecraft:oak_leaves[persistent=true]
fill 408 128 233 408 129 233 minecraft:bone_block
fill 408 128 259 408 130 259 minecraft:oak_leaves[persistent=true]
fill 409 128 265 409 130 265 minecraft:oak_leaves[persistent=true]
setblock 409 128 267 minecraft:oak_leaves[persistent=true]
setblock 410 128 264 minecraft:oak_leaves[persistent=true]
fill 410 128 265 410 128 266 minecraft:jungle_log
setblock 411 128 228 minecraft:jungle_leaves[persistent=true]
setblock 411 128 239 minecraft:light[level=15]
setblock 411 128 247 minecraft:light[level=15]
setblock 411 128 255 minecraft:light[level=15]
setblock 411 128 259 minecraft:oak_leaves[persistent=true]
fill 411 128 262 411 130 262 minecraft:oak_leaves[persistent=true]
setblock 412 128 228 minecraft:jungle_log
fill 418 128 229 418 130 229 minecraft:oak_leaves[persistent=true]
setblock 418 128 247 minecraft:jungle_leaves[persistent=true]
fill 418 128 256 418 149 256 minecraft:brown_terracotta
fill 376 129 231 376 139 233 minecraft:brown_terracotta
setblock 376 129 234 minecraft:jungle_leaves[persistent=true]
fill 378 129 257 379 129 257 minecraft:azalea_leaves[persistent=true]
fill 380 129 259 380 131 259 minecraft:azalea_leaves[persistent=true]
fill 385 129 268 387 129 268 minecraft:jungle_leaves[persistent=true]
fill 395 129 228 395 146 228 minecraft:brown_terracotta
fill 402 129 266 402 141 266 minecraft:iron_block
fill 405 129 228 405 149 228 minecraft:brown_terracotta
fill 406 129 262 406 129 265 minecraft:oak_leaves[persistent=true]
fill 411 129 228 413 139 228 minecraft:brown_terracotta
setblock 412 129 261 minecraft:oak_leaves[persistent=true]
setblock 418 129 230 minecraft:oak_leaves[persistent=true]
fill 418 129 245 418 135 245 minecraft:brown_terracotta
setblock 418 129 246 minecraft:jungle_leaves[persistent=true]
fill 418 129 247 418 136 247 minecraft:brown_terracotta
fill 376 130 234 376 149 234 minecraft:brown_terracotta
fill 376 130 260 376 141 260 minecraft:brown_terracotta
setblock 378 130 257 minecraft:azalea_leaves[persistent=true]
fill 383 130 228 383 146 228 minecraft:brown_terracotta
fill 383 130 259 385 130 259 minecraft:azalea_leaves[persistent=true]
fill 383 130 261 383 130 262 minecraft:azalea_leaves[persistent=true]
setblock 384 130 258 minecraft:azalea_leaves[persistent=true]
setblock 384 130 261 minecraft:azalea_leaves[persistent=true]
fill 384 130 270 384 149 270 minecraft:brown_terracotta
fill 385 130 229 386 130 229 minecraft:azalea_leaves[persistent=true]
setblock 385 130 260 minecraft:azalea_leaves[persistent=true]
fill 385 130 268 386 130 268 minecraft:jungle_leaves[persistent=true]
setblock 385 130 270 minecraft:jungle_leaves[persistent=true]
fill 388 130 228 388 149 228 minecraft:brown_terracotta
fill 405 130 265 406 130 265 minecraft:oak_leaves[persistent=true]
fill 406 130 263 406 130 264 minecraft:oak_leaves[persistent=true]
fill 406 130 266 406 130 267 minecraft:oak_leaves[persistent=true]
setblock 407 130 267 minecraft:oak_leaves[persistent=true]
setblock 409 130 259 minecraft:oak_leaves[persistent=true]
fill 418 130 230 418 139 230 minecraft:brown_terracotta
fill 418 130 246 418 140 246 minecraft:brown_terracotta
setblock 418 130 255 minecraft:moss_block
setblock 418 130 269 minecraft:green_concrete
setblock 376 131 236 minecraft:jungle_leaves[persistent=true]
fill 376 131 237 376 139 238 minecraft:brown_terracotta
setblock 376 131 239 minecraft:green_concrete
fill 376 131 240 376 149 240 minecraft:brown_terracotta
setblock 376 131 267 minecraft:jungle_leaves[persistent=true]
setblock 377 131 270 minecraft:jungle_leaves[persistent=true]
setblock 378 131 258 minecraft:azalea_leaves[persistent=true]
setblock 378 131 260 minecraft:azalea_leaves[persistent=true]
fill 384 131 228 384 149 228 minecraft:brown_terracotta
setblock 384 131 259 minecraft:azalea_leaves[persistent=true]
setblock 385 131 228 minecraft:azalea_leaves[persistent=true]
fill 385 131 270 385 146 270 minecraft:brown_terracotta
fill 386 131 228 387 145 228 minecraft:brown_terracotta
fill 387 131 270 388 146 270 minecraft:brown_terracotta
setblock 406 131 265 minecraft:oak_leaves[persistent=true]
setblock 407 131 266 minecraft:oak_leaves[persistent=true]
fill 408 131 261 408 131 264 minecraft:oak_leaves[persistent=true]
fill 409 131 261 410 131 261 minecraft:oak_leaves[persistent=true]
fill 418 131 228 418 145 229 minecraft:brown_terracotta
fill 418 131 255 418 149 255 minecraft:brown_terracotta
fill 418 131 269 418 149 269 minecraft:brown_terracotta
fill 376 132 236 376 139 236 minecraft:brown_terracotta
fill 376 132 239 376 139 239 minecraft:brown_terracotta
setblock 376 132 257 minecraft:moss_block
fill 376 132 267 376 150 267 minecraft:brown_terracotta
fill 377 132 270 377 150 270 minecraft:brown_terracotta
setblock 379 132 238 minecraft:light[level=12]
setblock 379 132 245 minecraft:light[level=12]
setblock 379 132 252 minecraft:light[level=12]
setblock 379 132 259 minecraft:light[level=12]
setblock 379 132 270 minecraft:moss_block
fill 385 132 228 385 147 228 minecraft:brown_terracotta
setblock 386 132 231 minecraft:light[level=12]
setblock 386 132 238 minecraft:light[level=12]
setblock 386 132 245 minecraft:light[level=12]
setblock 386 132 252 minecraft:light[level=12]
setblock 386 132 259 minecraft:light[level=12]
setblock 386 132 266 minecraft:light[level=12]
fill 386 132 270 386 149 270 minecraft:brown_terracotta
setblock 393 132 231 minecraft:light[level=12]
setblock 393 132 238 minecraft:light[level=12]
setblock 393 132 245 minecraft:light[level=12]
setblock 393 132 252 minecraft:light[level=12]
setblock 393 132 259 minecraft:light[level=12]
setblock 393 132 266 minecraft:light[level=12]
setblock 400 132 231 minecraft:light[level=12]
setblock 400 132 238 minecraft:light[level=12]
setblock 400 132 245 minecraft:light[level=12]
setblock 400 132 252 minecraft:light[level=12]
setblock 400 132 259 minecraft:light[level=12]
setblock 400 132 266 minecraft:light[level=12]
setblock 407 132 231 minecraft:light[level=12]
setblock 407 132 238 minecraft:light[level=12]
setblock 407 132 245 minecraft:light[level=12]
setblock 407 132 252 minecraft:light[level=12]
setblock 407 132 259 minecraft:light[level=12]
setblock 407 132 266 minecraft:light[level=12]
setblock 414 132 238 minecraft:light[level=12]
setblock 414 132 245 minecraft:light[level=12]
setblock 414 132 252 minecraft:light[level=12]
setblock 414 132 259 minecraft:light[level=12]
fill 376 133 257 376 145 257 minecraft:brown_terracotta
fill 379 133 270 379 139 270 minecraft:brown_terracotta
fill 382 133 270 382 147 270 minecraft:brown_terracotta
setblock 383 133 270 minecraft:jungle_leaves[persistent=true]
fill 383 134 270 383 149 270 minecraft:brown_terracotta
setblock 376 135 245 minecraft:moss_block
setblock 379 135 239 minecraft:light[level=15]
setblock 379 135 255 minecraft:light[level=15]
setblock 387 135 231 minecraft:light[level=15]
setblock 387 135 239 minecraft:light[level=15]
setblock 387 135 247 minecraft:light[level=15]
setblock 387 135 255 minecraft:light[level=15]
setblock 387 135 263 minecraft:light[level=15]
setblock 395 135 231 minecraft:light[level=15]
setblock 395 135 239 minecraft:light[level=15]
setblock 395 135 247 minecraft:light[level=15]
setblock 395 135 255 minecraft:light[level=15]
setblock 395 135 263 minecraft:light[level=15]
setblock 403 135 231 minecraft:light[level=15]
setblock 403 135 239 minecraft:light[level=15]
setblock 403 135 247 minecraft:light[level=15]
setblock 403 135 255 minecraft:light[level=15]
setblock 403 135 263 minecraft:light[level=15]
setblock 411 135 239 minecraft:light[level=15]
setblock 411 135 247 minecraft:light[level=15]
setblock 411 135 255 minecraft:light[level=15]
setblock 411 135 263 minecraft:light[level=15]
fill 376 136 245 376 145 245 minecraft:brown_terracotta
setblock 418 136 244 minecraft:moss_block
setblock 418 136 245 minecraft:green_concrete
setblock 376 137 247 minecraft:green_concrete
fill 389 137 231 393 138 235 minecraft:dirt
fill 391 137 229 391 137 230 minecraft:dirt
setblock 393 137 270 minecraft:moss_block
fill 418 137 244 418 145 245 minecraft:brown_terracotta
setblock 418 137 247 minecraft:green_concrete
fill 376 138 241 376 141 242 minecraft:brown_terracotta
setblock 376 138 243 minecraft:mossy_cobblestone
fill 376 138 244 376 149 244 minecraft:brown_terracotta
fill 376 138 247 376 145 247 minecraft:brown_terracotta
setblock 379 138 238 minecraft:light[level=12]
setblock 379 138 245 minecraft:light[level=12]
setblock 379 138 252 minecraft:light[level=12]
setblock 379 138 259 minecraft:light[level=12]
setblock 386 138 231 minecraft:light[level=12]
setblock 386 138 238 minecraft:light[level=12]
setblock 386 138 245 minecraft:light[level=12]
setblock 386 138 252 minecraft:light[level=12]
setblock 386 138 259 minecraft:light[level=12]
setblock 386 138 266 minecraft:light[level=12]
setblock 393 138 238 minecraft:light[level=12]
setblock 393 138 245 minecraft:light[level=12]
setblock 393 138 252 minecraft:light[level=12]
setblock 393 138 259 minecraft:light[level=12]
setblock 393 138 266 minecraft:light[level=12]
fill 393 138 270 393 146 270 minecraft:brown_terracotta
setblock 400 138 231 minecraft:light[level=12]
setblock 400 138 238 minecraft:light[level=12]
setblock 400 138 245 minecraft:light[level=12]
setblock 400 138 252 minecraft:light[level=12]
setblock 400 138 259 minecraft:light[level=12]
setblock 400 138 266 minecraft:light[level=12]
fill 402 138 228 403 147 228 minecraft:brown_terracotta
setblock 404 138 228 minecraft:mossy_cobblestone
setblock 407 138 231 minecraft:light[level=12]
setblock 407 138 238 minecraft:light[level=12]
setblock 407 138 245 minecraft:light[level=12]
setblock 407 138 252 minecraft:light[level=12]
setblock 407 138 259 minecraft:light[level=12]
setblock 407 138 266 minecraft:light[level=12]
setblock 414 138 238 minecraft:light[level=12]
setblock 414 138 245 minecraft:light[level=12]
setblock 414 138 252 minecraft:light[level=12]
setblock 414 138 259 minecraft:light[level=12]
fill 418 138 231 418 149 231 minecraft:brown_terracotta
setblock 418 138 232 minecraft:mossy_cobblestone
setblock 418 138 236 minecraft:moss_block
fill 418 138 247 418 149 247 minecraft:brown_terracotta
setblock 418 138 248 minecraft:jungle_leaves[persistent=true]
fill 376 139 243 376 149 243 minecraft:brown_terracotta
fill 376 139 262 376 143 262 minecraft:oak_leaves[persistent=true]
fill 382 139 259 382 144 259 minecraft:oak_leaves[persistent=true]
fill 383 139 260 383 143 260 minecraft:oak_leaves[persistent=true]
fill 387 139 232 389 140 232 minecraft:bone_block
fill 387 139 234 389 140 234 minecraft:bone_block
fill 388 139 233 388 140 233 minecraft:bone_block
fill 404 139 228 404 149 228 minecraft:brown_terracotta
fill 414 139 239 415 143 239 minecraft:jungle_leaves[persistent=true]
fill 416 139 259 416 144 260 minecraft:oak_leaves[persistent=true]
fill 417 139 260 417 143 260 minecraft:oak_leaves[persistent=true]
setblock 418 139 232 minecraft:brown_terracotta
fill 418 139 236 418 149 236 minecraft:brown_terracotta
fill 418 139 248 418 149 248 minecraft:brown_terracotta
fill 376 140 231 376 141 232 minecraft:jungle_log
fill 376 140 233 376 146 233 minecraft:brown_terracotta
fill 376 140 236 376 142 239 minecraft:oak_leaves[persistent=true]
fill 376 140 261 376 143 261 minecraft:oak_leaves[persistent=true]
fill 376 140 263 376 142 263 minecraft:oak_leaves[persistent=true]
setblock 376 140 269 minecraft:mossy_cobblestone
fill 377 140 234 377 140 235 minecraft:jungle_log
fill 377 140 262 377 141 262 minecraft:oak_leaves[persistent=true]
fill 377 140 263 377 141 264 minecraft:jungle_log
setblock 378 140 235 minecraft:jungle_log
fill 379 140 270 380 141 270 minecraft:jungle_log
fill 380 140 260 382 142 260 minecraft:oak_leaves[persistent=true]
fill 381 140 258 381 143 259 minecraft:oak_leaves[persistent=true]
fill 381 140 262 382 141 262 minecraft:jungle_log
fill 382 140 257 383 141 258 minecraft:oak_leaves[persistent=true]
fill 382 140 261 383 143 261 minecraft:oak_leaves[persistent=true]
fill 383 140 259 384 143 259 minecraft:oak_leaves[persistent=true]
fill 384 140 260 384 143 260 minecraft:oak_leaves[persistent=true]
fill 389 140 233 390 141 233 minecraft:bone_block
fill 411 140 228 411 149 228 minecraft:brown_terracotta
fill 412 140 228 412 140 229 minecraft:jungle_log
fill 413 140 228 413 141 228 minecraft:jungle_log
fill 413 140 238 413 141 241 minecraft:jungle_leaves[persistent=true]
fill 413 140 258 415 141 259 minecraft:oak_leaves[persistent=true]
fill 414 140 236 414 141 236 minecraft:jungle_log
fill 414 140 238 415 143 238 minecraft:jungle_leaves[persistent=true]
fill 414 140 240 415 142 241 minecraft:jungle_leaves[persistent=true]
fill 414 140 260 415 142 261 minecraft:oak_leaves[persistent=true]
fill 414 140 262 416 140 262 minecraft:jungle_log
fill 416 140 239 416 143 240 minecraft:jungle_leaves[persistent=true]
fill 416 140 257 417 142 258 minecraft:oak_leaves[persistent=true]
fill 416 140 261 418 142 261 minecraft:oak_leaves[persistent=true]
fill 417 140 259 417 144 259 minecraft:oak_leaves[persistent=true]
fill 417 140 262 417 141 262 minecraft:oak_leaves[persistent=true]
setblock 418 140 230 minecraft:mossy_cobblestone
fill 418 140 232 418 141 233 minecraft:jungle_log
fill 418 140 267 418 141 267 minecraft:jungle_log
fill 376 141 235 376 143 235 minecraft:oak_leaves[persistent=true]
setblock 376 141 264 minecraft:jungle_log
fill 376 141 269 376 149 269 minecraft:brown_terracotta
setblock 377 141 235 minecraft:jungle_log
fill 377 141 236 377 142 238 minecraft:oak_leaves[persistent=true]
setblock 379 141 228 minecraft:moss_block
fill 380 141 259 380 143 259 minecraft:oak_leaves[persistent=true]
fill 381 141 261 381 143 261 minecraft:oak_leaves[persistent=true]
fill 384 141 258 384 142 258 minecraft:oak_leaves[persistent=true]
fill 384 141 261 384 142 261 minecraft:oak_leaves[persistent=true]
fill 391 141 233 391 142 233 minecraft:bone_block
setblock 395 141 270 minecraft:jungle_leaves[persistent=true]
fill 396 141 270 397 149 270 minecraft:brown_terracotta
setblock 412 141 228 minecraft:jungle_log
fill 412 141 238 412 141 240 minecraft:jungle_leaves[persistent=true]
fill 413 141 237 415 142 237 minecraft:jungle_leaves[persistent=true]
fill 414 141 257 415 142 257 minecraft:oak_leaves[persistent=true]
fill 414 141 262 415 141 262 minecraft:jungle_log
setblock 416 141 241 minecraft:jungle_leaves[persistent=true]
setblock 416 141 262 minecraft:oak_leaves[persistent=true]
fill 418 141 230 418 146 230 minecraft:brown_terracotta
setblock 418 141 246 minecraft:jungle_leaves[persistent=true]
fill 418 141 257 418 145 257 minecraft:brown_terracotta
fill 418 141 258 418 142 260 minecraft:oak_leaves[persistent=true]
setblock 418 141 268 minecraft:jungle_leaves[persistent=true]
fill 376 142 231 376 149 232 minecraft:brown_terracotta
setblock 376 142 241 minecraft:mossy_cobblestone
setblock 376 142 242 minecraft:moss_block
setblock 376 142 250 minecraft:green_concrete
fill 376 142 251 376 149 251 minecraft:brown_terracotta
setblock 376 142 260 minecraft:oak_leaves[persistent=true]
fill 376 142 264 376 149 264 minecraft:brown_terracotta
setblock 377 142 235 minecraft:oak_leaves[persistent=true]
fill 379 142 228 379 150 228 minecraft:brown_terracotta
setblock 379 142 239 minecraft:light[level=15]
setblock 379 142 247 minecraft:light[level=15]
setblock 379 142 255 minecraft:light[level=15]
fill 379 142 270 380 143 270 minecraft:brown_terracotta
fill 382 142 258 383 143 258 minecraft:oak_leaves[persistent=true]
setblock 382 142 262 minecraft:oak_leaves[persistent=true]
setblock 387 142 231 minecraft:light[level=15]
setblock 387 142 239 minecraft:light[level=15]
setblock 387 142 247 minecraft:light[level=15]
setblock 387 142 255 minecraft:light[level=15]
setblock 387 142 263 minecraft:light[level=15]
fill 392 142 233 393 143 233 minecraft:bone_block
setblock 395 142 231 minecraft:light[level=15]
setblock 395 142 239 minecraft:light[level=15]
setblock 395 142 247 minecraft:light[level=15]
setblock 395 142 255 minecraft:light[level=15]
setblock 395 142 263 minecraft:light[level=15]
fill 395 142 270 395 143 270 minecraft:brown_terracotta
setblock 403 142 231 minecraft:light[level=15]
setblock 403 142 239 minecraft:light[level=15]
setblock 403 142 247 minecraft:light[level=15]
setblock 403 142 255 minecraft:light[level=15]
setblock 403 142 263 minecraft:light[level=15]
setblock 411 142 239 minecraft:light[level=15]
setblock 411 142 247 minecraft:light[level=15]
setblock 411 142 255 minecraft:light[level=15]
setblock 411 142 263 minecraft:light[level=15]
setblock 412 142 228 minecraft:azalea_leaves[persistent=true]
fill 412 142 239 413 142 240 minecraft:jungle_leaves[persistent=true]
fill 413 142 228 413 149 228 minecraft:brown_terracotta
fill 413 142 238 413 143 238 minecraft:jungle_leaves[persistent=true]
fill 413 142 259 413 142 260 minecraft:oak_leaves[persistent=true]
fill 414 142 258 415 143 259 minecraft:oak_leaves[persistent=true]
fill 418 142 232 418 142 233 minecraft:brown_terracotta
fill 418 142 246 418 149 246 minecraft:brown_terracotta
setblock 418 142 253 minecraft:jungle_leaves[persistent=true]
fill 418 142 267 418 145 268 minecraft:brown_terracotta
fill 376 143 236 376 143 238 minecraft:oak_leaves[persistent=true]
fill 376 143 239 376 145 239 minecraft:brown_terracotta
fill 376 143 241 376 149 242 minecraft:brown_terracotta
fill 376 143 250 376 149 250 minecraft:brown_terracotta
fill 376 143 260 376 149 260 minecraft:brown_terracotta
fill 376 143 263 376 149 263 minecraft:brown_terracotta
fill 377 143 236 377 143 237 minecraft:oak_leaves[persistent=true]
fill 379 143 254 379 149 254 minecraft:moss_block
fill 380 143 228 380 149 228 minecraft:brown_terracotta
setblock 381 143 228 minecraft:jungle_leaves[persistent=true]
fill 381 143 260 382 143 260 minecraft:oak_leaves[persistent=true]
fill 393 143 232 395 144 232 minecraft:bone_block
fill 393 143 234 395 144 234 minecraft:bone_block
fill 394 143 233 394 144 233 minecraft:bone_block
fill 412 143 228 412 147 228 minecraft:brown_terracotta
fill 412 143 239 413 143 239 minecraft:jungle_leaves[persistent=true]
fill 413 143 240 415 143 240 minecraft:jungle_leaves[persistent=true]
fill 413 143 260 415 143 260 minecraft:oak_leaves[persistent=true]
fill 414 143 237 415 143 237 minecraft:jungle_leaves[persistent=true]
fill 415 143 257 416 143 257 minecraft:oak_leaves[persistent=true]
fill 415 143 261 416 143 261 minecraft:oak_leaves[persistent=true]
fill 416 143 258 417 143 258 minecraft:oak_leaves[persistent=true]
fill 418 143 232 418 146 232 minecraft:brown_terracotta
setblock 418 143 233 minecraft:moss_block
fill 418 143 253 418 149 253 minecraft:brown_terracotta
fill 418 143 258 418 149 258 minecraft:brown_terracotta
fill 418 143 259 418 143 260 minecraft:oak_leaves[persistent=true]
fill 418 143 261 418 145 261 minecraft:brown_terracotta
fill 376 144 235 376 149 235 minecraft:brown_terracotta
fill 376 144 236 376 144 237 minecraft:oak_leaves[persistent=true]
fill 376 144 238 376 149 238 minecraft:brown_terracotta
fill 376 144 261 376 149 262 minecraft:brown_terracotta
setblock 379 144 238 minecraft:light[level=12]
setblock 379 144 245 minecraft:light[level=12]
setblock 379 144 252 minecraft:light[level=12]
setblock 379 144 259 minecraft:light[level=12]
fill 379 144 270 379 145 270 minecraft:brown_terracotta
setblock 380 144 270 minecraft:moss_block
fill 381 144 228 381 149 228 minecraft:brown_terracotta
setblock 382 144 260 minecraft:oak_leaves[persistent=true]
setblock 383 144 259 minecraft:oak_leaves[persistent=true]
setblock 386 144 231 minecraft:light[level=12]
setblock 386 144 238 minecraft:light[level=12]
setblock 386 144 245 minecraft:light[level=12]
setblock 386 144 252 minecraft:light[level=12]
setblock 386 144 259 minecraft:light[level=12]
setblock 386 144 266 minecraft:light[level=12]
setblock 389 144 270 minecraft:moss_block
setblock 393 144 231 minecraft:light[level=12]
setblock 393 144 238 minecraft:light[level=12]
setblock 393 144 245 minecraft:light[level=12]
setblock 393 144 252 minecraft:light[level=12]
setblock 393 144 259 minecraft:light[level=12]
setblock 393 144 266 minecraft:light[level=12]
setblock 395 144 270 minecraft:moss_block
setblock 400 144 231 minecraft:light[level=12]
setblock 400 144 238 minecraft:light[level=12]
setblock 400 144 245 minecraft:light[level=12]
setblock 400 144 252 minecraft:light[level=12]
setblock 400 144 259 minecraft:light[level=12]
setblock 400 144 266 minecraft:light[level=12]
setblock 407 144 231 minecraft:light[level=12]
setblock 407 144 238 minecraft:light[level=12]
setblock 407 144 245 minecraft:light[level=12]
setblock 407 144 252 minecraft:light[level=12]
setblock 407 144 259 minecraft:light[level=12]
setblock 407 144 266 minecraft:light[level=12]
setblock 410 144 270 minecraft:moss_block
setblock 414 144 238 minecraft:light[level=12]
setblock 414 144 240 minecraft:jungle_leaves[persistent=true]
setblock 414 144 245 minecraft:light[level=12]
setblock 414 144 252 minecraft:light[level=12]
setblock 414 144 259 minecraft:light[level=12]
setblock 415 144 238 minecraft:jungle_leaves[persistent=true]
fill 415 144 258 415 144 260 minecraft:oak_leaves[persistent=true]
fill 418 144 233 418 145 233 minecraft:brown_terracotta
fill 418 144 259 418 145 260 minecraft:brown_terracotta
fill 376 145 236 376 145 237 minecraft:brown_terracotta
setblock 377 145 228 minecraft:green_concrete
fill 380 145 270 380 150 270 minecraft:brown_terracotta
fill 389 145 270 389 149 270 minecraft:brown_terracotta
fill 395 145 270 395 149 270 minecraft:brown_terracotta
setblock 397 145 228 minecraft:jungle_leaves[persistent=true]
fill 398 145 228 398 147 228 minecraft:brown_terracotta
setblock 405 145 270 minecraft:mossy_cobblestone
fill 410 145 270 410 147 270 minecraft:brown_terracotta
setblock 418 145 251 minecraft:moss_block
fill 376 146 228 376 149 229 minecraft:brown_terracotta
setblock 376 146 230 minecraft:green_terracotta
fill 376 146 236 376 149 236 minecraft:brown_terracotta
setblock 376 146 237 minecraft:green_terracotta
setblock 376 146 239 minecraft:green_terracotta
setblock 376 146 245 minecraft:green_terracotta
setblock 376 146 247 minecraft:green_terracotta
setblock 376 146 257 minecraft:green_terracotta
setblock 376 146 266 minecraft:green_terracotta
setblock 376 146 270 minecraft:green_terracotta
fill 377 146 228 377 149 228 minecraft:brown_terracotta
setblock 379 146 270 minecraft:green_terracotta
fill 386 146 228 386 149 228 minecraft:brown_terracotta
setblock 387 146 228 minecraft:green_terracotta
setblock 390 146 228 minecraft:green_terracotta
fill 397 146 228 397 149 228 minecraft:brown_terracotta
fill 405 146 270 405 149 270 minecraft:brown_terracotta
setblock 409 146 228 minecraft:green_terracotta
setblock 418 146 228 minecraft:brown_terracotta
setblock 418 146 229 minecraft:green_terracotta
setblock 418 146 233 minecraft:green_terracotta
fill 418 146 244 418 151 244 minecraft:brown_terracotta
fill 418 146 245 418 148 245 minecraft:green_terracotta
fill 418 146 251 418 147 251 minecraft:brown_terracotta
setblock 418 146 257 minecraft:green_concrete
fill 418 146 259 418 149 259 minecraft:brown_terracotta
fill 418 146 260 418 146 261 minecraft:green_terracotta
setblock 418 146 266 minecraft:green_terracotta
fill 418 146 267 418 149 267 minecraft:brown_terracotta
setblock 418 146 268 minecraft:green_terracotta
fill 376 147 230 376 149 230 minecraft:brown_terracotta
setblock 376 147 233 minecraft:green_terracotta
fill 376 147 237 376 149 237 minecraft:brown_terracotta
fill 376 147 239 376 150 239 minecraft:brown_terracotta
setblock 376 147 245 minecraft:green_concrete
fill 376 147 247 376 149 247 minecraft:brown_terracotta
fill 376 147 257 376 149 257 minecraft:brown_terracotta
fill 376 147 266 376 149 266 minecraft:brown_terracotta
fill 376 147 270 376 149 270 minecraft:brown_terracotta
setblock 378 147 228 minecraft:jungle_leaves[persistent=true]
fill 379 147 270 379 149 270 minecraft:brown_terracotta
fill 383 147 228 383 148 228 minecraft:green_terracotta
setblock 385 147 270 minecraft:green_terracotta
fill 387 147 228 387 150 228 minecraft:brown_terracotta
fill 387 147 270 387 149 270 minecraft:brown_terracotta
setblock 388 147 270 minecraft:green_terracotta
fill 390 147 228 390 149 228 minecraft:brown_terracotta
fill 393 147 270 394 147 270 minecraft:green_terracotta
setblock 395 147 228 minecraft:green_terracotta
fill 400 147 270 401 147 270 minecraft:green_terracotta
setblock 406 147 228 minecraft:green_terracotta
fill 406 147 270 406 149 270 minecraft:brown_terracotta
setblock 407 147 270 minecraft:green_terracotta
setblock 408 147 270 minecraft:moss_block
fill 409 147 228 409 149 228 minecraft:brown_terracotta
setblock 417 147 270 minecraft:green_terracotta
fill 418 147 228 418 148 228 minecraft:green_terracotta
fill 418 147 229 418 149 229 minecraft:brown_terracotta
setblock 418 147 230 minecraft:green_terracotta
setblock 418 147 232 minecraft:jungle_leaves[persistent=true]
fill 418 147 233 418 149 233 minecraft:brown_terracotta
setblock 418 147 238 minecraft:green_terracotta
fill 418 147 239 418 149 239 minecraft:brown_terracotta
setblock 418 147 240 minecraft:green_terracotta
setblock 418 147 257 minecraft:brown_terracotta
fill 418 147 260 418 149 261 minecraft:brown_terracotta
fill 418 147 266 418 148 266 minecraft:brown_terracotta
setblock 418 147 268 minecraft:brown_terracotta
fill 376 148 233 376 149 233 minecraft:brown_terracotta
setblock 376 148 245 minecraft:brown_terracotta
setblock 376 148 246 minecraft:green_terracotta
setblock 376 148 252 minecraft:green_terracotta
fill 378 148 228 378 149 228 minecraft:brown_terracotta
fill 381 148 270 382 148 270 minecraft:green_terracotta
setblock 382 148 228 minecraft:green_terracotta
setblock 385 148 228 minecraft:green_terracotta
fill 385 148 270 385 150 270 minecraft:brown_terracotta
fill 388 148 270 388 149 270 minecraft:brown_terracotta
setblock 392 148 270 minecraft:green_terracotta
setblock 393 148 228 minecraft:green_terracotta
fill 393 148 270 394 149 270 minecraft:brown_terracotta
fill 395 148 228 395 149 228 minecraft:brown_terracotta
setblock 396 148 228 minecraft:green_terracotta
setblock 398 148 228 minecraft:green_terracotta
fill 400 148 270 401 149 270 minecraft:brown_terracotta
setblock 402 148 228 minecraft:green_terracotta
setblock 403 148 228 minecraft:brown_terracotta
fill 406 148 228 407 149 228 minecraft:brown_terracotta
fill 407 148 270 408 149 270 minecraft:brown_terracotta
setblock 408 148 228 minecraft:green_terracotta
setblock 410 148 270 minecraft:green_terracotta
setblock 412 148 228 minecraft:green_concrete
setblock 412 148 270 minecraft:green_terracotta
setblock 414 148 270 minecraft:green_terracotta
fill 417 148 270 417 149 270 minecraft:brown_terracotta
fill 418 148 230 418 149 230 minecraft:brown_terracotta
fill 418 148 232 418 149 232 minecraft:brown_terracotta
fill 418 148 238 418 149 238 minecraft:brown_terracotta
fill 418 148 240 418 149 240 minecraft:brown_terracotta
setblock 418 148 251 minecraft:green_terracotta
setblock 418 148 257 minecraft:green_terracotta
setblock 418 148 262 minecraft:mossy_cobblestone
fill 418 148 263 418 149 263 minecraft:brown_terracotta
setblock 418 148 268 minecraft:green_terracotta
setblock 376 149 245 minecraft:jungle_leaves[persistent=true]
setblock 376 149 246 minecraft:brown_terracotta
setblock 376 149 252 minecraft:brown_terracotta
setblock 379 149 239 minecraft:light[level=15]
setblock 379 149 247 minecraft:light[level=15]
setblock 379 149 255 minecraft:light[level=15]
fill 381 149 270 382 149 270 minecraft:brown_terracotta
fill 382 149 228 383 149 228 minecraft:brown_terracotta
setblock 385 149 228 minecraft:brown_terracotta
setblock 387 149 231 minecraft:light[level=15]
setblock 387 149 239 minecraft:light[level=15]
setblock 387 149 247 minecraft:light[level=15]
setblock 387 149 255 minecraft:light[level=15]
setblock 387 149 263 minecraft:light[level=15]
setblock 392 149 270 minecraft:brown_terracotta
setblock 393 149 228 minecraft:brown_terracotta
setblock 395 149 231 minecraft:light[level=15]
setblock 395 149 239 minecraft:light[level=15]
setblock 395 149 247 minecraft:light[level=15]
setblock 395 149 255 minecraft:light[level=15]
setblock 395 149 263 minecraft:light[level=15]
setblock 396 149 228 minecraft:brown_terracotta
setblock 398 149 228 minecraft:brown_terracotta
setblock 402 149 228 minecraft:brown_terracotta
setblock 403 149 228 minecraft:jungle_leaves[persistent=true]
setblock 403 149 231 minecraft:light[level=15]
setblock 403 149 239 minecraft:light[level=15]
setblock 403 149 247 minecraft:light[level=15]
setblock 403 149 255 minecraft:light[level=15]
setblock 403 149 263 minecraft:light[level=15]
setblock 408 149 228 minecraft:brown_terracotta
setblock 410 149 270 minecraft:brown_terracotta
setblock 411 149 239 minecraft:light[level=15]
setblock 411 149 247 minecraft:light[level=15]
setblock 411 149 255 minecraft:light[level=15]
setblock 411 149 263 minecraft:light[level=15]
setblock 412 149 228 minecraft:brown_terracotta
setblock 412 149 270 minecraft:brown_terracotta
setblock 414 149 270 minecraft:brown_terracotta
setblock 418 149 228 minecraft:brown_terracotta
setblock 418 149 234 minecraft:moss_block
setblock 418 149 235 minecraft:brown_terracotta
setblock 418 149 245 minecraft:brown_terracotta
setblock 418 149 251 minecraft:brown_terracotta
setblock 418 149 257 minecraft:brown_terracotta
setblock 418 149 262 minecraft:brown_terracotta
setblock 418 149 266 minecraft:moss_block
setblock 418 149 268 minecraft:brown_terracotta
fill 376 150 228 378 150 228 minecraft:green_terracotta
fill 376 150 229 417 150 229 minecraft:brown_terracotta
fill 376 150 230 376 151 238 minecraft:green_terracotta
fill 376 150 240 376 150 258 minecraft:green_terracotta
fill 376 150 259 389 151 259 minecraft:brown_terracotta
fill 376 150 260 376 150 266 minecraft:green_terracotta
fill 376 150 268 376 151 270 minecraft:green_terracotta
fill 377 150 230 387 151 258 minecraft:brown_terracotta
fill 377 150 260 417 151 269 minecraft:brown_terracotta
fill 378 150 270 379 150 270 minecraft:green_terracotta
fill 380 150 228 386 150 228 minecraft:green_terracotta
fill 381 150 270 384 150 270 minecraft:green_terracotta
fill 386 150 270 400 150 270 minecraft:green_terracotta
fill 388 150 228 403 150 228 minecraft:green_terracotta
fill 388 150 230 388 151 254 minecraft:brown_terracotta
fill 388 150 258 388 151 258 minecraft:brown_terracotta
fill 389 150 230 389 151 253 minecraft:brown_terracotta
fill 390 150 230 417 151 252 minecraft:brown_terracotta
fill 393 150 253 417 151 253 minecraft:brown_terracotta
fill 393 150 259 417 151 259 minecraft:brown_terracotta
fill 394 150 254 417 151 254 minecraft:brown_terracotta
fill 394 150 258 417 151 258 minecraft:brown_terracotta
fill 395 150 255 417 151 257 minecraft:brown_terracotta
setblock 401 150 270 minecraft:brown_terracotta
fill 402 150 270 417 150 270 minecraft:green_terracotta
setblock 404 150 228 minecraft:green_concrete
fill 405 150 228 405 203 228 minecraft:green_terracotta
setblock 406 150 228 minecraft:brown_terracotta
fill 407 150 228 418 150 228 minecraft:green_terracotta
fill 418 150 229 418 154 233 minecraft:green_terracotta
setblock 418 150 234 minecraft:brown_terracotta
fill 418 150 235 418 150 243 minecraft:green_terracotta
fill 418 150 245 418 150 251 minecraft:green_terracotta
fill 418 150 253 418 150 265 minecraft:green_terracotta
setblock 418 150 266 minecraft:brown_terracotta
fill 418 150 267 418 151 269 minecraft:green_terracotta
setblock 376 151 228 minecraft:brown_terracotta
fill 376 151 229 376 178 229 minecraft:green_terracotta
fill 376 151 239 376 152 244 minecraft:green_terracotta
setblock 376 151 245 minecraft:jungle_leaves[persistent=true]
fill 376 151 246 376 182 247 minecraft:green_terracotta
setblock 376 151 248 minecraft:moss_block
fill 376 151 249 376 151 250 minecraft:green_terracotta
setblock 376 151 251 minecraft:brown_terracotta
fill 376 151 252 376 191 252 minecraft:green_terracotta
setblock 376 151 253 minecraft:brown_terracotta
fill 376 151 254 376 178 258 minecraft:green_terracotta
fill 376 151 260 376 151 264 minecraft:green_terracotta
fill 376 151 265 376 152 265 minecraft:brown_terracotta
fill 376 151 266 376 165 267 minecraft:green_terracotta
fill 377 151 228 379 159 228 minecraft:green_terracotta
fill 377 151 229 417 152 229 minecraft:brown_terracotta
fill 377 151 270 378 191 270 minecraft:green_terracotta
setblock 379 151 270 minecraft:brown_terracotta
setblock 380 151 228 minecraft:brown_terracotta
fill 380 151 270 380 204 270 minecraft:green_terracotta
fill 381 151 228 391 151 228 minecraft:green_terracotta
setblock 381 151 270 minecraft:brown_terracotta
fill 382 151 270 387 151 270 minecraft:green_terracotta
setblock 388 151 270 minecraft:moss_block
fill 389 151 270 390 153 270 minecraft:green_terracotta
setblock 391 151 270 minecraft:brown_terracotta
setblock 392 151 228 minecraft:brown_terracotta
fill 392 151 270 394 164 270 minecraft:green_terracotta
fill 393 151 228 397 151 228 minecraft:green_terracotta
setblock 395 151 270 minecraft:brown_terracotta
fill 396 151 270 405 151 270 minecraft:green_terracotta
setblock 398 151 228 minecraft:moss_block
fill 399 151 228 403 159 228 minecraft:green_terracotta
setblock 404 151 228 minecraft:brown_terracotta
fill 406 151 228 407 153 228 minecraft:green_terracotta
setblock 406 151 270 minecraft:jungle_leaves[persistent=true]
fill 407 151 270 418 151 270 minecraft:green_terracotta
setblock 408 151 228 minecraft:brown_terracotta
fill 409 151 228 409 153 228 minecraft:green_terracotta
setblock 410 151 228 minecraft:brown_terracotta
fill 411 151 228 412 152 228 minecraft:green_terracotta
fill 413 151 228 414 151 228 minecraft:brown_terracotta
fill 415 151 228 418 153 228 minecraft:green_terracotta
fill 418 151 234 418 170 236 minecraft:green_terracotta
setblock 418 151 237 minecraft:moss_block
fill 418 151 238 418 151 243 minecraft:green_terracotta
setblock 418 151 245 minecraft:brown_terracotta
fill 418 151 246 418 151 254 minecraft:green_terracotta
setblock 418 151 255 minecraft:brown_terracotta
fill 418 151 256 418 151 260 minecraft:green_terracotta
setblock 418 151 261 minecraft:brown_terracotta
fill 418 151 262 418 151 266 minecraft:green_terracotta
fill 376 152 228 376 178 228 minecraft:green_terracotta
fill 376 152 230 376 152 233 minecraft:green_terracotta
setblock 376 152 234 minecraft:mossy_cobblestone
fill 376 152 235 376 159 238 minecraft:green_terracotta
fill 376 152 245 417 152 245 minecraft:brown_terracotta
fill 376 152 248 376 215 248 minecraft:green_terracotta
fill 376 152 249 417 152 249 minecraft:brown_terracotta
fill 376 152 250 376 189 250 minecraft:green_terracotta
setblock 376 152 251 minecraft:moss_block
fill 376 152 253 376 153 253 minecraft:green_terracotta
fill 376 152 259 376 171 263 minecraft:green_terracotta
setblock 376 152 264 minecraft:mossy_cobblestone
fill 376 152 268 376 152 269 minecraft:green_terracotta
setblock 376 152 270 minecraft:brown_terracotta
fill 377 152 230 417 152 244 minecraft:brown_terracotta
fill 377 152 246 417 152 248 minecraft:brown_terracotta
fill 377 152 250 385 152 269 minecraft:brown_terracotta
fill 379 152 270 379 229 270 minecraft:green_terracotta
fill 380 152 228 390 155 228 minecraft:green_terracotta
fill 381 152 270 382 165 270 minecraft:green_terracotta
setblock 383 152 270 minecraft:brown_terracotta
setblock 384 152 270 minecraft:green_terracotta
fill 385 152 270 385 157 270 minecraft:oak_leaves[persistent=true]
fill 386 152 250 386 163 252 minecraft:brown_terracotta
fill 386 152 253 386 152 259 minecraft:bone_block
fill 386 152 260 386 152 269 minecraft:brown_terracotta
fill 386 152 270 388 152 270 minecraft:green_terracotta
fill 387 152 250 387 163 251 minecraft:brown_terracotta
fill 387 152 252 387 152 253 minecraft:bone_block
fill 387 152 254 387 152 258 minecraft:shroomlight
fill 387 152 259 387 152 260 minecraft:bone_block
fill 387 152 261 387 152 269 minecraft:brown_terracotta
fill 388 152 250 417 152 250 minecraft:brown_terracotta
fill 388 152 251 388 152 252 minecraft:bone_block
fill 388 152 253 388 152 254 minecraft:shroomlight
fill 388 152 258 388 152 259 minecraft:shroomlight
fill 388 152 260 388 152 261 minecraft:bone_block
fill 388 152 262 417 152 269 minecraft:brown_terracotta
fill 389 152 251 394 152 251 minecraft:bone_block
fill 389 152 252 389 152 253 minecraft:shroomlight
fill 389 152 259 389 152 260 minecraft:shroomlight
fill 389 152 261 394 152 261 minecraft:bone_block
fill 390 152 252 393 152 252 minecraft:shroomlight
fill 390 152 260 393 152 260 minecraft:shroomlight
setblock 391 152 228 minecraft:brown_terracotta
fill 391 152 270 391 215 270 minecraft:green_terracotta
fill 392 152 228 392 177 228 minecraft:green_terracotta
setblock 393 152 228 minecraft:brown_terracotta
fill 393 152 253 394 152 253 minecraft:shroomlight
fill 393 152 259 394 152 259 minecraft:shroomlight
fill 394 152 228 395 190 228 minecraft:green_terracotta
fill 394 152 252 395 152 252 minecraft:bone_block
fill 394 152 254 395 152 254 minecraft:shroomlight
fill 394 152 258 395 152 258 minecraft:shroomlight
fill 394 152 260 395 152 260 minecraft:bone_block
fill 395 152 251 417 152 251 minecraft:brown_terracotta
fill 395 152 253 396 152 253 minecraft:bone_block
fill 395 152 255 395 152 257 minecraft:shroomlight
fill 395 152 259 396 152 259 minecraft:bone_block
fill 395 152 261 417 152 261 minecraft:brown_terracotta
fill 395 152 270 395 183 270 minecraft:green_terracotta
setblock 396 152 228 minecraft:brown_terracotta
fill 396 152 252 417 152 252 minecraft:brown_terracotta
fill 396 152 254 396 152 258 minecraft:bone_block
fill 396 152 260 417 152 260 minecraft:brown_terracotta
setblock 396 152 270 minecraft:brown_terracotta
fill 397 152 228 398 163 228 minecraft:green_terracotta
fill 397 152 253 417 152 259 minecraft:brown_terracotta
fill 397 152 270 399 175 270 minecraft:green_terracotta
setblock 400 152 270 minecraft:brown_terracotta
fill 401 152 270 408 152 270 minecraft:green_terracotta
fill 404 152 228 404 153 228 minecraft:green_terracotta
fill 408 152 228 408 177 228 minecraft:green_terracotta
fill 409 152 270 409 156 270 minecraft:oak_leaves[persistent=true]
setblock 410 152 228 minecraft:green_terracotta
setblock 410 152 270 minecraft:green_terracotta
setblock 411 152 270 minecraft:moss_block
fill 412 152 270 418 152 270 minecraft:green_terracotta
fill 413 152 228 414 153 228 minecraft:green_terracotta
fill 418 152 237 418 153 241 minecraft:green_terracotta
setblock 418 152 242 minecraft:brown_terracotta
fill 418 152 243 418 187 244 minecraft:green_terracotta
setblock 418 152 245 minecraft:green_concrete
fill 418 152 246 418 175 252 minecraft:green_terracotta
setblock 418 152 253 minecraft:brown_terracotta
fill 418 152 254 418 159 256 minecraft:green_terracotta
setblock 418 152 257 minecraft:brown_terracotta
fill 418 152 258 418 154 265 minecraft:green_terracotta
setblock 418 152 266 minecraft:brown_terracotta
fill 418 152 267 418 157 268 minecraft:green_terracotta
setblock 418 152 269 minecraft:brown_terracotta
fill 376 153 230 376 163 231 minecraft:green_terracotta
fill 376 153 232 376 154 233 minecraft:jungle_log
fill 376 153 234 376 158 234 minecraft:green_terracotta
setblock 376 153 239 minecraft:jungle_leaves[persistent=true]
fill 376 153 240 376 163 245 minecraft:green_terracotta
fill 376 153 249 376 155 249 minecraft:green_terracotta
fill 376 153 251 376 226 251 minecraft:green_terracotta
fill 376 153 264 376 205 265 minecraft:green_terracotta
fill 376 153 268 376 154 268 minecraft:jungle_log
fill 376 153 269 376 156 270 minecraft:jungle_leaves[persistent=true]
fill 377 153 229 377 210 269 minecraft:brown_concrete
fill 378 153 229 417 223 229 minecraft:brown_concrete
fill 378 153 230 385 159 268 minecraft:brown_terracotta
fill 378 153 269 417 206 269 minecraft:brown_concrete
setblock 383 153 270 minecraft:green_terracotta
fill 384 153 270 384 156 270 minecraft:oak_leaves[persistent=true]
fill 386 153 230 416 166 249 minecraft:brown_terracotta
fill 386 153 253 386 153 268 minecraft:brown_terracotta
fill 386 153 270 388 156 270 minecraft:oak_leaves[persistent=true]
fill 387 153 252 387 154 253 minecraft:brown_terracotta
fill 387 153 254 387 153 258 minecraft:brown_concrete
fill 387 153 259 387 154 268 minecraft:brown_terracotta
fill 388 153 250 388 154 252 minecraft:brown_terracotta
fill 388 153 253 388 154 253 minecraft:brown_concrete
fill 388 153 259 388 154 259 minecraft:brown_concrete
fill 388 153 260 388 154 268 minecraft:brown_terracotta
fill 389 153 250 416 153 251 minecraft:brown_terracotta
fill 389 153 252 393 153 252 minecraft:brown_concrete
fill 389 153 260 393 153 260 minecraft:brown_concrete
fill 389 153 261 416 153 268 minecraft:brown_terracotta
fill 391 153 228 391 163 228 minecraft:green_terracotta
fill 393 153 228 393 182 228 minecraft:green_terracotta
fill 394 153 252 416 154 252 minecraft:brown_terracotta
fill 394 153 253 394 154 253 minecraft:brown_concrete
fill 394 153 259 394 154 259 minecraft:brown_concrete
fill 394 153 260 416 154 260 minecraft:brown_terracotta
fill 395 153 253 416 154 253 minecraft:brown_terracotta
fill 395 153 254 395 153 258 minecraft:brown_concrete
fill 395 153 259 416 154 259 minecraft:brown_terracotta
fill 396 153 228 396 207 228 minecraft:green_terracotta
fill 396 153 254 416 153 258 minecraft:brown_terracotta
fill 396 153 270 396 162 270 minecraft:green_terracotta
fill 400 153 270 406 153 270 minecraft:green_terracotta
fill 407 153 270 408 156 270 minecraft:oak_leaves[persistent=true]
fill 410 153 228 411 155 228 minecraft:jungle_leaves[persistent=true]
fill 410 153 270 411 156 270 minecraft:jungle_leaves[persistent=true]
fill 412 153 228 412 154 228 minecraft:jungle_log
setblock 412 153 270 minecraft:green_terracotta
fill 413 153 270 413 154 270 minecraft:jungle_log
fill 414 153 270 418 165 270 minecraft:green_terracotta
fill 417 153 230 417 223 268 minecraft:brown_concrete
fill 418 153 242 418 218 242 minecraft:green_terracotta
fill 418 153 245 418 202 245 minecraft:green_terracotta
fill 418 153 253 418 158 253 minecraft:green_terracotta
fill 418 153 257 418 157 257 minecraft:green_terracotta
fill 418 153 266 418 194 266 minecraft:green_terracotta
fill 418 153 269 418 205 269 minecraft:green_terracotta
fill 376 154 239 376 180 239 minecraft:green_terracotta
setblock 376 154 253 minecraft:moss_block
fill 383 154 270 383 155 270 minecraft:oak_leaves[persistent=true]
fill 386 154 253 386 154 255 minecraft:brown_terracotta
setblock 386 154 256 minecraft:brown_concrete
fill 386 154 257 386 154 268 minecraft:brown_terracotta
fill 387 154 254 387 154 255 minecraft:brown_concrete
fill 387 154 257 387 154 258 minecraft:brown_concrete
fill 389 154 250 390 154 251 minecraft:brown_terracotta
fill 389 154 252 390 154 252 minecraft:brown_concrete
fill 389 154 260 390 154 260 minecraft:brown_concrete
fill 389 154 261 390 154 268 minecraft:brown_terracotta
setblock 389 154 270 minecraft:oak_leaves[persistent=true]
fill 390 154 270 390 155 270 minecraft:green_terracotta
fill 391 154 250 416 159 250 minecraft:brown_terracotta
setblock 391 154 251 minecraft:brown_concrete
setblock 391 154 261 minecraft:brown_concrete
fill 391 154 262 416 159 268 minecraft:brown_terracotta
fill 392 154 251 416 154 251 minecraft:brown_terracotta
fill 392 154 252 393 154 252 minecraft:brown_concrete
fill 392 154 260 393 154 260 minecraft:brown_concrete
fill 392 154 261 416 154 261 minecraft:brown_terracotta
fill 395 154 254 395 154 255 minecraft:brown_concrete
fill 395 154 257 395 154 258 minecraft:brown_concrete
fill 396 154 254 416 154 255 minecraft:brown_terracotta
setblock 396 154 256 minecraft:brown_concrete
fill 396 154 257 416 154 258 minecraft:brown_terracotta
fill 397 154 256 416 159 256 minecraft:brown_terracotta
fill 400 154 270 405 176 270 minecraft:green_terracotta
setblock 404 154 228 minecraft:green_concrete
setblock 406 154 228 minecraft:moss_block
fill 406 154 270 406 156 270 minecraft:oak_leaves[persistent=true]
fill 407 154 228 407 178 228 minecraft:green_terracotta
fill 409 154 228 409 155 228 minecraft:jungle_leaves[persistent=true]
setblock 412 154 270 minecraft:jungle_log
fill 413 154 228 413 229 228 minecraft:green_terracotta
setblock 414 154 228 minecraft:jungle_leaves[persistent=true]
fill 415 154 228 416 165 228 minecraft:green_terracotta
setblock 417 154 228 minecraft:jungle_leaves[persistent=true]
fill 418 154 228 418 165 228 minecraft:green_terracotta
fill 418 154 237 418 210 238 minecraft:green_terracotta
setblock 418 154 239 minecraft:azalea_leaves[persistent=true]
fill 418 154 240 418 174 241 minecraft:green_terracotta
fill 376 155 232 376 185 233 minecraft:green_terracotta
fill 376 155 253 376 179 253 minecraft:green_terracotta
fill 376 155 268 376 178 268 minecraft:green_terracotta
fill 386 155 253 386 156 254 minecraft:brown_terracotta
fill 386 155 255 386 155 257 minecraft:bone_block
fill 386 155 258 386 156 268 minecraft:brown_terracotta
fill 387 155 252 387 159 252 minecraft:brown_terracotta
fill 387 155 253 387 155 254 minecraft:bone_block
fill 387 155 258 387 155 259 minecraft:bone_block
fill 387 155 260 387 159 268 minecraft:brown_terracotta
fill 388 155 250 389 156 251 minecraft:brown_terracotta
fill 388 155 252 389 155 252 minecraft:bone_block
fill 388 155 260 389 155 260 minecraft:bone_block
fill 388 155 261 389 156 268 minecraft:brown_terracotta
fill 389 155 270 389 229 270 minecraft:green_terracotta
fill 390 155 250 390 160 250 minecraft:brown_terracotta
fill 390 155 251 392 155 251 minecraft:bone_block
fill 390 155 261 392 155 261 minecraft:bone_block
fill 390 155 262 390 160 268 minecraft:brown_terracotta
fill 393 155 251 416 156 251 minecraft:brown_terracotta
fill 393 155 252 394 155 252 minecraft:bone_block
fill 393 155 260 394 155 260 minecraft:bone_block
fill 393 155 261 416 156 261 minecraft:brown_terracotta
fill 395 155 252 416 159 252 minecraft:brown_terracotta
fill 395 155 253 395 155 254 minecraft:bone_block
fill 395 155 258 395 155 259 minecraft:bone_block
fill 395 155 260 416 159 260 minecraft:brown_terracotta
fill 396 155 253 416 156 254 minecraft:brown_terracotta
fill 396 155 255 396 155 257 minecraft:bone_block
fill 396 155 258 416 156 259 minecraft:brown_terracotta
fill 397 155 255 416 160 255 minecraft:brown_terracotta
fill 397 155 257 416 160 257 minecraft:brown_terracotta
fill 404 155 228 404 199 228 minecraft:green_terracotta
fill 406 155 228 406 170 228 minecraft:green_terracotta
fill 412 155 228 412 158 228 minecraft:green_terracotta
setblock 412 155 270 minecraft:jungle_leaves[persistent=true]
fill 413 155 270 413 229 270 minecraft:green_terracotta
fill 414 155 228 414 165 228 minecraft:green_terracotta
fill 417 155 228 417 157 228 minecraft:green_terracotta
fill 418 155 229 418 165 232 minecraft:green_terracotta
setblock 418 155 233 minecraft:moss_block
fill 418 155 239 418 156 239 minecraft:green_terracotta
fill 418 155 258 418 174 260 minecraft:green_terracotta
setblock 418 155 261 minecraft:moss_block
fill 418 155 262 418 164 265 minecraft:green_terracotta
setblock 376 156 249 minecraft:green_concrete
fill 380 156 228 383 157 228 minecraft:green_terracotta
fill 383 156 270 383 166 270 minecraft:green_terracotta
setblock 384 156 228 minecraft:jungle_leaves[persistent=true]
fill 385 156 228 390 177 228 minecraft:green_terracotta
fill 386 156 255 386 158 257 minecraft:brown_concrete
fill 387 156 253 387 156 254 minecraft:brown_concrete
setblock 387 156 255 minecraft:light[level=15]
fill 387 156 258 387 156 259 minecraft:brown_concrete
fill 388 156 252 389 156 252 minecraft:brown_concrete
fill 388 156 260 389 156 260 minecraft:brown_concrete
fill 390 156 251 392 158 251 minecraft:brown_concrete
fill 390 156 261 392 158 261 minecraft:brown_concrete
setblock 390 156 270 minecraft:moss_block
fill 393 156 252 394 156 252 minecraft:brown_concrete
setblock 393 156 259 minecraft:light[level=12]
fill 393 156 260 394 156 260 minecraft:brown_concrete
fill 395 156 253 395 156 254 minecraft:brown_concrete
setblock 395 156 255 minecraft:light[level=15]
fill 395 156 258 395 156 259 minecraft:brown_concrete
fill 396 156 255 396 158 257 minecraft:brown_concrete
fill 409 156 228 409 158 228 minecraft:green_terracotta
setblock 410 156 228 minecraft:jungle_leaves[persistent=true]
fill 411 156 228 411 229 228 minecraft:green_terracotta
fill 412 156 270 412 229 270 minecraft:green_terracotta
fill 418 156 233 418 179 233 minecraft:green_terracotta
fill 418 156 261 418 177 261 minecraft:green_terracotta
fill 376 157 249 376 190 249 minecraft:green_terracotta
fill 376 157 269 376 178 270 minecraft:green_terracotta
fill 384 157 228 384 227 228 minecraft:green_terracotta
fill 384 157 270 384 165 270 minecraft:green_terracotta
fill 386 157 253 386 159 253 minecraft:brown_terracotta
fill 386 157 254 386 158 254 minecraft:brown_concrete
fill 386 157 258 386 158 258 minecraft:brown_concrete
fill 386 157 259 386 159 268 minecraft:brown_terracotta
fill 386 157 270 386 179 270 minecraft:green_terracotta
fill 387 157 253 387 158 253 minecraft:brown_concrete
fill 387 157 259 387 158 259 minecraft:brown_concrete
setblock 387 157 270 minecraft:oak_leaves[persistent=true]
fill 388 157 250 388 159 251 minecraft:brown_terracotta
fill 388 157 252 388 158 252 minecraft:brown_concrete
fill 388 157 260 388 158 260 minecraft:brown_concrete
fill 388 157 261 388 159 268 minecraft:brown_terracotta
fill 388 157 270 388 217 270 minecraft:green_terracotta
fill 389 157 250 389 162 250 minecraft:brown_terracotta
fill 389 157 251 389 158 251 minecraft:brown_concrete
fill 389 157 261 389 158 261 minecraft:brown_concrete
fill 389 157 262 389 162 268 minecraft:brown_terracotta
setblock 390 157 270 minecraft:green_concrete
fill 393 157 251 393 158 251 minecraft:brown_concrete
fill 393 157 261 393 158 261 minecraft:brown_concrete
fill 394 157 251 416 159 251 minecraft:brown_terracotta
fill 394 157 252 394 158 252 minecraft:brown_concrete
fill 394 157 260 394 158 260 minecraft:brown_concrete
fill 394 157 261 416 159 261 minecraft:brown_terracotta
fill 395 157 253 395 158 253 minecraft:brown_concrete
fill 395 157 259 395 158 259 minecraft:brown_concrete
fill 396 157 253 416 159 253 minecraft:brown_terracotta
fill 396 157 254 396 158 254 minecraft:brown_concrete
fill 396 157 258 396 158 258 minecraft:brown_concrete
fill 396 157 259 416 159 259 minecraft:brown_terracotta
fill 397 157 254 416 162 254 minecraft:brown_terracotta
fill 397 157 258 416 162 258 minecraft:brown_terracotta
fill 406 157 270 411 162 270 minecraft:green_terracotta
fill 410 157 228 410 162 228 minecraft:green_terracotta
setblock 418 157 239 minecraft:mossy_cobblestone
fill 380 158 228 382 165 228 minecraft:green_terracotta
setblock 383 158 228 minecraft:moss_block
fill 385 158 270 385 174 270 minecraft:green_terracotta
fill 387 158 270 387 229 270 minecraft:green_terracotta
fill 390 158 270 390 223 270 minecraft:green_terracotta
setblock 417 158 228 minecraft:green_concrete
fill 418 158 239 418 212 239 minecraft:green_terracotta
setblock 418 158 257 minecraft:jungle_leaves[persistent=true]
fill 418 158 267 418 186 267 minecraft:green_terracotta
setblock 418 158 268 minecraft:mossy_cobblestone
setblock 376 159 234 minecraft:mossy_cobblestone
fill 383 159 228 383 161 228 minecraft:green_terracotta
fill 386 159 254 386 159 258 minecraft:bone_block
setblock 387 159 253 minecraft:bone_block
setblock 387 159 259 minecraft:bone_block
setblock 388 159 252 minecraft:bone_block
setblock 388 159 260 minecraft:bone_block
fill 389 159 251 393 159 251 minecraft:bone_block
fill 389 159 261 393 159 261 minecraft:bone_block
setblock 394 159 252 minecraft:bone_block
setblock 394 159 260 minecraft:bone_block
setblock 395 159 253 minecraft:bone_block
setblock 395 159 259 minecraft:bone_block
fill 396 159 254 396 159 258 minecraft:bone_block
setblock 409 159 228 minecraft:moss_block
setblock 412 159 228 minecraft:jungle_leaves[persistent=true]
fill 417 159 228 417 165 228 minecraft:green_terracotta
setblock 418 159 253 minecraft:mossy_cobblestone
fill 418 159 257 418 229 257 minecraft:green_terracotta
fill 418 159 268 418 204 268 minecraft:green_terracotta
fill 376 160 234 376 229 234 minecraft:green_terracotta
setblock 376 160 235 minecraft:mossy_cobblestone
fill 376 160 236 376 160 238 minecraft:green_terracotta
setblock 377 160 228 minecraft:green_concrete
fill 378 160 228 379 204 228 minecraft:green_terracotta
fill 378 160 230 384 166 268 minecraft:brown_terracotta
fill 385 160 230 385 160 255 minecraft:brown_terracotta
fill 385 160 256 385 162 256 minecraft:brown_concrete
fill 385 160 257 385 160 268 minecraft:brown_terracotta
fill 386 160 253 386 160 255 minecraft:brown_concrete
fill 386 160 257 386 160 259 minecraft:brown_concrete
fill 386 160 260 386 163 268 minecraft:brown_terracotta
fill 387 160 252 387 162 252 minecraft:brown_concrete
fill 387 160 260 387 162 260 minecraft:brown_concrete
fill 387 160 261 387 163 268 minecraft:brown_terracotta
fill 388 160 250 388 165 250 minecraft:brown_terracotta
fill 388 160 251 390 160 251 minecraft:brown_concrete
fill 388 160 261 390 160 261 minecraft:brown_concrete
fill 388 160 262 388 165 268 minecraft:brown_terracotta
fill 391 160 250 391 162 250 minecraft:brown_concrete
fill 391 160 262 391 162 262 minecraft:brown_concrete
fill 391 160 263 416 166 268 minecraft:brown_terracotta
fill 392 160 250 416 160 250 minecraft:brown_terracotta
fill 392 160 251 394 160 251 minecraft:brown_concrete
fill 392 160 261 394 160 261 minecraft:brown_concrete
fill 392 160 262 416 160 262 minecraft:brown_terracotta
fill 395 160 251 416 163 251 minecraft:brown_terracotta
fill 395 160 252 395 162 252 minecraft:brown_concrete
fill 395 160 260 395 162 260 minecraft:brown_concrete
fill 395 160 261 416 163 261 minecraft:brown_terracotta
fill 396 160 252 416 163 252 minecraft:brown_terracotta
fill 396 160 253 396 160 255 minecraft:brown_concrete
fill 396 160 257 396 160 259 minecraft:brown_concrete
fill 396 160 260 416 163 260 minecraft:brown_terracotta
fill 397 160 253 416 165 253 minecraft:brown_terracotta
fill 397 160 256 397 162 256 minecraft:brown_concrete
fill 397 160 259 416 165 259 minecraft:brown_terracotta
fill 398 160 256 416 166 256 minecraft:brown_terracotta
fill 399 160 228 400 174 228 minecraft:green_terracotta
setblock 401 160 228 minecraft:jungle_leaves[persistent=true]
fill 402 160 228 403 184 228 minecraft:green_terracotta
fill 409 160 228 409 177 228 minecraft:green_terracotta
fill 412 160 228 412 192 228 minecraft:green_terracotta
fill 418 160 253 418 163 255 minecraft:green_terracotta
setblock 418 160 256 minecraft:moss_block
fill 376 161 235 376 161 237 minecraft:green_terracotta
setblock 376 161 238 minecraft:mossy_cobblestone
fill 377 161 228 377 229 228 minecraft:green_terracotta
fill 385 161 230 385 162 254 minecraft:brown_terracotta
fill 385 161 255 385 162 255 minecraft:brown_concrete
fill 385 161 257 385 162 257 minecraft:brown_concrete
fill 385 161 258 385 162 268 minecraft:brown_terracotta
fill 386 161 253 386 162 254 minecraft:brown_concrete
fill 386 161 258 386 162 259 minecraft:brown_concrete
fill 388 161 251 389 162 251 minecraft:brown_concrete
fill 388 161 261 389 162 261 minecraft:brown_concrete
fill 390 161 250 390 162 250 minecraft:brown_concrete
fill 390 161 262 390 162 262 minecraft:brown_concrete
fill 390 161 263 390 166 268 minecraft:brown_terracotta
fill 392 161 250 392 162 250 minecraft:brown_concrete
fill 392 161 262 392 162 262 minecraft:brown_concrete
fill 393 161 250 416 162 250 minecraft:brown_terracotta
fill 393 161 251 394 162 251 minecraft:brown_concrete
fill 393 161 261 394 162 261 minecraft:brown_concrete
fill 393 161 262 416 162 262 minecraft:brown_terracotta
fill 396 161 253 396 162 254 minecraft:brown_concrete
fill 396 161 258 396 162 259 minecraft:brown_concrete
fill 397 161 255 397 162 255 minecraft:brown_concrete
fill 397 161 257 397 162 257 minecraft:brown_concrete
fill 398 161 255 416 166 255 minecraft:brown_terracotta
fill 398 161 257 416 166 257 minecraft:brown_terracotta
fill 401 161 228 401 174 228 minecraft:green_terracotta
fill 418 161 256 418 215 256 minecraft:green_terracotta
setblock 376 162 235 minecraft:mossy_cobblestone
fill 376 162 236 376 176 238 minecraft:green_terracotta
setblock 383 162 228 minecraft:jungle_leaves[persistent=true]
setblock 393 162 252 minecraft:light[level=12]
setblock 393 162 259 minecraft:light[level=12]
fill 376 163 235 376 205 235 minecraft:green_terracotta
fill 383 163 228 383 172 228 minecraft:green_terracotta
fill 385 163 230 385 165 253 minecraft:brown_terracotta
fill 385 163 254 385 163 258 minecraft:bone_block
fill 385 163 259 385 165 268 minecraft:brown_terracotta
setblock 386 163 253 minecraft:bone_block
setblock 386 163 259 minecraft:bone_block
setblock 387 163 252 minecraft:bone_block
setblock 387 163 255 minecraft:light[level=15]
setblock 387 163 260 minecraft:bone_block
setblock 388 163 251 minecraft:bone_block
setblock 388 163 261 minecraft:bone_block
fill 389 163 250 393 163 250 minecraft:bone_block
fill 389 163 262 393 163 262 minecraft:bone_block
fill 389 163 263 389 168 268 minecraft:brown_terracotta
fill 394 163 250 416 165 250 minecraft:brown_terracotta
setblock 394 163 251 minecraft:bone_block
setblock 394 163 261 minecraft:bone_block
fill 394 163 262 416 165 262 minecraft:brown_terracotta
setblock 395 163 252 minecraft:bone_block
setblock 395 163 255 minecraft:light[level=15]
setblock 395 163 260 minecraft:bone_block
setblock 396 163 253 minecraft:bone_block
setblock 396 163 259 minecraft:bone_block
setblock 396 163 270 minecraft:mossy_cobblestone
fill 397 163 254 397 163 258 minecraft:bone_block
fill 398 163 254 416 168 254 minecraft:brown_terracotta
fill 398 163 258 416 168 258 minecraft:brown_terracotta
setblock 406 163 270 minecraft:moss_block
fill 407 163 270 411 166 270 minecraft:green_terracotta
setblock 410 163 228 minecraft:green_concrete
fill 376 164 230 376 179 230 minecraft:green_terracotta
setblock 376 164 231 minecraft:moss_block
fill 376 164 240 376 178 241 minecraft:green_terracotta
setblock 376 164 242 minecraft:moss_block
fill 376 164 243 376 164 245 minecraft:green_terracotta
fill 385 164 254 385 166 258 minecraft:brown_concrete
fill 386 164 250 386 168 251 minecraft:brown_terracotta
fill 386 164 252 386 165 253 minecraft:brown_concrete
fill 386 164 259 386 165 260 minecraft:brown_concrete
fill 386 164 261 386 168 268 minecraft:brown_terracotta
fill 387 164 250 387 168 250 minecraft:brown_terracotta
fill 387 164 251 388 165 251 minecraft:brown_concrete
fill 387 164 261 388 165 261 minecraft:brown_concrete
fill 387 164 262 387 168 268 minecraft:brown_terracotta
fill 389 164 250 393 166 250 minecraft:brown_concrete
fill 389 164 262 393 166 262 minecraft:brown_concrete
setblock 391 164 228 minecraft:mossy_cobblestone
fill 394 164 251 395 165 251 minecraft:brown_concrete
fill 394 164 261 395 165 261 minecraft:brown_concrete
fill 396 164 251 416 168 251 minecraft:brown_terracotta
fill 396 164 252 396 165 253 minecraft:brown_concrete
fill 396 164 259 396 165 260 minecraft:brown_concrete
fill 396 164 261 416 168 261 minecraft:brown_terracotta
fill 396 164 270 396 209 270 minecraft:green_terracotta
setblock 397 164 228 minecraft:green_concrete
fill 397 164 252 416 168 252 minecraft:brown_terracotta
fill 397 164 254 397 166 258 minecraft:brown_concrete
fill 397 164 260 416 168 260 minecraft:brown_terracotta
fill 398 164 228 398 200 228 minecraft:green_terracotta
fill 406 164 270 406 166 270 minecraft:green_terracotta
fill 410 164 228 410 178 228 minecraft:green_terracotta
setblock 418 164 253 minecraft:green_concrete
fill 418 164 254 418 209 255 minecraft:green_terracotta
fill 376 165 231 376 196 231 minecraft:green_terracotta
fill 376 165 242 376 183 243 minecraft:green_terracotta
setblock 376 165 244 minecraft:moss_block
fill 376 165 245 376 227 245 minecraft:green_terracotta
fill 391 165 228 391 213 228 minecraft:green_terracotta
fill 392 165 270 393 171 270 minecraft:green_terracotta
setblock 394 165 270 minecraft:moss_block
fill 397 165 228 397 229 228 minecraft:green_terracotta
fill 418 165 253 418 178 253 minecraft:green_terracotta
setblock 418 165 262 minecraft:green_concrete
fill 418 165 263 418 165 265 minecraft:green_terracotta
setblock 376 166 244 minecraft:green_concrete
fill 376 166 266 376 167 267 minecraft:jungle_log
fill 380 166 228 380 167 228 minecraft:jungle_log
fill 381 166 228 382 229 228 minecraft:green_terracotta
fill 381 166 270 381 194 270 minecraft:green_terracotta
fill 382 166 270 382 167 270 minecraft:jungle_log
setblock 384 166 270 minecraft:mossy_cobblestone
fill 385 166 230 385 168 252 minecraft:brown_terracotta
setblock 385 166 253 minecraft:brown_concrete
setblock 385 166 259 minecraft:brown_concrete
fill 385 166 260 385 168 268 minecraft:brown_terracotta
setblock 386 166 252 minecraft:brown_concrete
setblock 386 166 260 minecraft:brown_concrete
setblock 387 166 251 minecraft:brown_concrete
setblock 387 166 261 minecraft:brown_concrete
setblock 388 166 250 minecraft:brown_concrete
setblock 388 166 262 minecraft:brown_concrete
fill 388 166 263 388 170 268 minecraft:brown_terracotta
setblock 394 166 250 minecraft:brown_concrete
setblock 394 166 262 minecraft:brown_concrete
fill 394 166 270 394 189 270 minecraft:green_terracotta
fill 395 166 250 416 168 250 minecraft:brown_terracotta
setblock 395 166 251 minecraft:brown_concrete
setblock 395 166 261 minecraft:brown_concrete
fill 395 166 262 416 168 262 minecraft:brown_terracotta
setblock 396 166 252 minecraft:brown_concrete
setblock 396 166 260 minecraft:brown_concrete
setblock 397 166 253 minecraft:brown_concrete
setblock 397 166 259 minecraft:brown_concrete
fill 398 166 253 416 170 253 minecraft:brown_terracotta
fill 398 166 259 416 170 259 minecraft:brown_terracotta
fill 414 166 228 415 167 228 minecraft:jungle_log
fill 414 166 270 414 179 270 minecraft:green_terracotta
fill 415 166 270 416 167 270 minecraft:jungle_log
fill 416 166 228 416 189 228 minecraft:green_terracotta
fill 417 166 228 418 168 228 minecraft:azalea_leaves[persistent=true]
fill 417 166 270 418 168 270 minecraft:jungle_leaves[persistent=true]
fill 418 166 229 418 168 229 minecraft:azalea_leaves[persistent=true]
fill 418 166 230 418 169 232 minecraft:green_terracotta
fill 418 166 262 418 178 264 minecraft:green_terracotta
setblock 418 166 265 minecraft:mossy_cobblestone
fill 376 167 244 376 209 244 minecraft:green_terracotta
fill 378 167 230 383 172 268 minecraft:brown_terracotta
fill 383 167 270 384 167 270 minecraft:azalea_leaves[persistent=true]
fill 384 167 230 384 168 254 minecraft:brown_terracotta
fill 384 167 255 384 167 257 minecraft:bone_block
fill 384 167 258 384 168 268 minecraft:brown_terracotta
fill 385 167 253 385 167 254 minecraft:bone_block
fill 385 167 258 385 167 259 minecraft:bone_block
fill 386 167 230 389 168 249 minecraft:brown_terracotta
setblock 386 167 252 minecraft:bone_block
setblock 386 167 260 minecraft:bone_block
setblock 387 167 251 minecraft:bone_block
setblock 387 167 261 minecraft:bone_block
fill 388 167 250 389 167 250 minecraft:bone_block
fill 388 167 262 389 167 262 minecraft:bone_block
fill 390 167 230 416 172 248 minecraft:brown_terracotta
fill 390 167 249 392 167 249 minecraft:bone_block
fill 390 167 263 392 167 263 minecraft:bone_block
fill 390 167 264 416 172 268 minecraft:brown_terracotta
fill 393 167 249 416 168 249 minecraft:brown_terracotta
fill 393 167 250 394 167 250 minecraft:bone_block
fill 393 167 262 394 167 262 minecraft:bone_block
fill 393 167 263 416 168 263 minecraft:brown_terracotta
setblock 395 167 251 minecraft:bone_block
setblock 395 167 261 minecraft:bone_block
setblock 396 167 252 minecraft:bone_block
setblock 396 167 260 minecraft:bone_block
fill 397 167 253 397 167 254 minecraft:bone_block
fill 397 167 258 397 167 259 minecraft:bone_block
fill 398 167 255 398 167 257 minecraft:bone_block
fill 399 167 255 416 172 257 minecraft:brown_terracotta
fill 406 167 270 408 168 270 minecraft:jungle_leaves[persistent=true]
fill 409 167 270 411 176 270 minecraft:green_terracotta
setblock 418 167 265 minecraft:green_terracotta
fill 376 168 266 376 175 267 minecraft:green_terracotta
fill 380 168 228 380 199 228 minecraft:green_terracotta
fill 382 168 270 383 169 270 minecraft:azalea_leaves[persistent=true]
fill 384 168 255 384 170 257 minecraft:brown_concrete
fill 384 168 270 384 178 270 minecraft:green_terracotta
fill 385 168 253 385 168 254 minecraft:brown_concrete
fill 385 168 258 385 168 259 minecraft:brown_concrete
setblock 386 168 252 minecraft:brown_concrete
setblock 386 168 259 minecraft:light[level=12]
setblock 386 168 260 minecraft:brown_concrete
setblock 387 168 251 minecraft:brown_concrete
setblock 387 168 261 minecraft:brown_concrete
fill 388 168 250 389 168 250 minecraft:brown_concrete
fill 388 168 262 389 168 262 minecraft:brown_concrete
fill 390 168 249 392 170 249 minecraft:brown_concrete
fill 390 168 263 392 170 263 minecraft:brown_concrete
fill 393 168 250 394 168 250 minecraft:brown_concrete
setblock 393 168 252 minecraft:light[level=12]
setblock 393 168 259 minecraft:light[level=12]
fill 393 168 262 394 168 262 minecraft:brown_concrete
setblock 395 168 251 minecraft:brown_concrete
setblock 395 168 261 minecraft:brown_concrete
setblock 396 168 252 minecraft:brown_concrete
setblock 396 168 260 minecraft:brown_concrete
fill 397 168 253 397 168 254 minecraft:brown_concrete
fill 397 168 258 397 168 259 minecraft:brown_concrete
fill 398 168 255 398 170 257 minecraft:brown_concrete
fill 414 168 228 415 204 228 minecraft:green_terracotta
fill 415 168 270 416 229 270 minecraft:green_terracotta
setblock 418 168 265 minecraft:green_concrete
fill 384 169 230 384 170 253 minecraft:brown_terracotta
fill 384 169 254 384 170 254 minecraft:brown_concrete
fill 384 169 258 384 170 258 minecraft:brown_concrete
fill 384 169 259 384 170 268 minecraft:brown_terracotta
fill 385 169 230 385 172 251 minecraft:brown_terracotta
fill 385 169 252 385 170 253 minecraft:brown_concrete
fill 385 169 259 385 170 260 minecraft:brown_concrete
fill 385 169 261 385 172 268 minecraft:brown_terracotta
fill 386 169 230 386 172 250 minecraft:brown_terracotta
fill 386 169 251 386 170 251 minecraft:brown_concrete
fill 386 169 261 386 170 261 minecraft:brown_concrete
fill 386 169 262 386 172 268 minecraft:brown_terracotta
fill 387 169 230 388 170 249 minecraft:brown_terracotta
fill 387 169 250 388 170 250 minecraft:brown_concrete
fill 387 169 262 388 170 262 minecraft:brown_concrete
fill 387 169 263 387 173 268 minecraft:brown_terracotta
fill 389 169 230 389 174 248 minecraft:brown_terracotta
fill 389 169 249 389 170 249 minecraft:brown_concrete
fill 389 169 263 389 170 263 minecraft:brown_concrete
fill 389 169 264 389 174 268 minecraft:brown_terracotta
fill 393 169 249 393 170 249 minecraft:brown_concrete
fill 393 169 263 393 170 263 minecraft:brown_concrete
fill 394 169 249 416 170 249 minecraft:brown_terracotta
fill 394 169 250 395 170 250 minecraft:brown_concrete
fill 394 169 262 395 170 262 minecraft:brown_concrete
fill 394 169 263 416 170 263 minecraft:brown_terracotta
fill 396 169 250 416 172 250 minecraft:brown_terracotta
fill 396 169 251 396 170 251 minecraft:brown_concrete
fill 396 169 261 396 170 261 minecraft:brown_concrete
fill 396 169 262 416 172 262 minecraft:brown_terracotta
fill 397 169 251 416 172 251 minecraft:brown_terracotta
fill 397 169 252 397 170 253 minecraft:brown_concrete
fill 397 169 259 397 170 260 minecraft:brown_concrete
fill 397 169 261 416 172 261 minecraft:brown_terracotta
fill 398 169 252 416 173 252 minecraft:brown_terracotta
fill 398 169 254 398 170 254 minecraft:brown_concrete
fill 398 169 258 398 170 258 minecraft:brown_concrete
fill 398 169 260 416 173 260 minecraft:brown_terracotta
fill 399 169 254 416 174 254 minecraft:brown_terracotta
fill 399 169 258 416 174 258 minecraft:brown_terracotta
fill 406 169 270 408 178 270 minecraft:green_terracotta
fill 417 169 228 417 199 228 minecraft:green_terracotta
fill 417 169 270 417 229 270 minecraft:green_terracotta
setblock 418 169 228 minecraft:azalea_leaves[persistent=true]
fill 418 169 229 418 211 229 minecraft:green_terracotta
fill 418 169 265 418 176 265 minecraft:green_terracotta
setblock 418 169 270 minecraft:jungle_leaves[persistent=true]
fill 382 170 270 383 172 270 minecraft:green_terracotta
setblock 387 170 255 minecraft:light[level=15]
setblock 395 170 255 minecraft:light[level=15]
fill 418 170 228 418 204 228 minecraft:green_terracotta
fill 418 170 230 418 180 231 minecraft:green_terracotta
setblock 418 170 232 minecraft:jungle_leaves[persistent=true]
fill 418 170 270 418 205 270 minecraft:green_terracotta
fill 384 171 230 384 173 252 minecraft:brown_terracotta
fill 384 171 253 384 171 259 minecraft:bone_block
fill 384 171 260 384 173 268 minecraft:brown_terracotta
setblock 385 171 252 minecraft:bone_block
setblock 385 171 260 minecraft:bone_block
setblock 386 171 251 minecraft:bone_block
setblock 386 171 261 minecraft:bone_block
fill 387 171 230 387 173 249 minecraft:brown_terracotta
setblock 387 171 250 minecraft:bone_block
setblock 387 171 262 minecraft:bone_block
fill 388 171 230 388 176 248 minecraft:brown_terracotta
fill 388 171 249 394 171 249 minecraft:bone_block
fill 388 171 263 394 171 263 minecraft:bone_block
fill 388 171 264 388 176 268 minecraft:brown_terracotta
fill 395 171 249 416 173 249 minecraft:brown_terracotta
setblock 395 171 250 minecraft:bone_block
setblock 395 171 262 minecraft:bone_block
fill 395 171 263 416 173 263 minecraft:brown_terracotta
setblock 396 171 251 minecraft:bone_block
setblock 396 171 261 minecraft:bone_block
setblock 397 171 252 minecraft:bone_block
setblock 397 171 260 minecraft:bone_block
fill 398 171 253 398 171 259 minecraft:bone_block
fill 399 171 253 416 176 253 minecraft:brown_terracotta
fill 399 171 259 416 176 259 minecraft:brown_terracotta
setblock 406 171 228 minecraft:moss_block
fill 418 171 232 418 191 232 minecraft:green_terracotta
fill 418 171 234 418 202 235 minecraft:green_terracotta
setblock 418 171 236 minecraft:mossy_cobblestone
fill 376 172 259 376 191 260 minecraft:green_terracotta
setblock 376 172 261 minecraft:green_concrete
fill 376 172 262 376 174 263 minecraft:green_terracotta
fill 384 172 253 384 172 259 minecraft:brown_concrete
fill 385 172 252 385 173 252 minecraft:brown_concrete
fill 385 172 260 385 173 260 minecraft:brown_concrete
setblock 386 172 251 minecraft:brown_concrete
setblock 386 172 261 minecraft:brown_concrete
fill 387 172 250 387 173 250 minecraft:brown_concrete
fill 387 172 262 387 173 262 minecraft:brown_concrete
fill 388 172 249 394 172 249 minecraft:brown_concrete
fill 388 172 263 394 172 263 minecraft:brown_concrete
fill 392 172 270 392 208 270 minecraft:green_terracotta
setblock 393 172 270 minecraft:green_concrete
fill 395 172 250 395 173 250 minecraft:brown_concrete
fill 395 172 262 395 173 262 minecraft:brown_concrete
setblock 396 172 251 minecraft:brown_concrete
setblock 396 172 261 minecraft:brown_concrete
fill 397 172 252 397 173 252 minecraft:brown_concrete
fill 397 172 260 397 173 260 minecraft:brown_concrete
fill 398 172 253 398 172 259 minecraft:brown_concrete
fill 406 172 228 406 180 228 minecraft:green_terracotta
fill 418 172 236 418 217 236 minecraft:green_terracotta
fill 376 173 261 376 176 261 minecraft:green_terracotta
fill 378 173 230 382 178 268 minecraft:brown_terracotta
fill 382 173 270 382 179 270 minecraft:green_terracotta
setblock 383 173 228 minecraft:moss_block
fill 383 173 230 383 174 254 minecraft:brown_terracotta
fill 383 173 255 383 174 257 minecraft:brown_concrete
fill 383 173 258 383 174 268 minecraft:brown_terracotta
setblock 383 173 270 minecraft:green_concrete
fill 384 173 253 384 174 254 minecraft:brown_concrete
fill 384 173 258 384 174 259 minecraft:brown_concrete
fill 385 173 230 385 177 250 minecraft:brown_terracotta
fill 385 173 251 385 174 251 minecraft:brown_concrete
fill 385 173 261 385 174 261 minecraft:brown_concrete
fill 385 173 262 385 177 268 minecraft:brown_terracotta
fill 386 173 230 386 177 249 minecraft:brown_terracotta
fill 386 173 250 386 174 250 minecraft:brown_concrete
fill 386 173 262 386 174 262 minecraft:brown_concrete
fill 386 173 263 386 177 268 minecraft:brown_terracotta
fill 388 173 249 389 174 249 minecraft:brown_concrete
fill 388 173 263 389 174 263 minecraft:brown_concrete
fill 390 173 230 416 178 247 minecraft:brown_terracotta
fill 390 173 248 392 174 248 minecraft:brown_concrete
fill 390 173 264 392 174 264 minecraft:brown_concrete
fill 390 173 265 416 178 268 minecraft:brown_terracotta
fill 393 173 248 416 174 248 minecraft:brown_terracotta
fill 393 173 249 394 174 249 minecraft:brown_concrete
fill 393 173 263 394 174 263 minecraft:brown_concrete
fill 393 173 264 416 174 264 minecraft:brown_terracotta
fill 393 173 270 393 179 270 minecraft:green_terracotta
fill 396 173 250 396 174 250 minecraft:brown_concrete
fill 396 173 262 396 174 262 minecraft:brown_concrete
fill 397 173 250 416 177 250 minecraft:brown_terracotta
fill 397 173 251 397 174 251 minecraft:brown_concrete
fill 397 173 261 397 174 261 minecraft:brown_concrete
fill 397 173 262 416 177 262 minecraft:brown_terracotta
fill 398 173 251 416 177 251 minecraft:brown_terracotta
fill 398 173 253 398 174 254 minecraft:brown_concrete
fill 398 173 258 398 174 259 minecraft:brown_concrete
fill 398 173 261 416 177 261 minecraft:brown_terracotta
fill 399 173 255 399 174 257 minecraft:brown_concrete
fill 400 173 255 416 178 257 minecraft:brown_terracotta
fill 383 174 228 383 229 228 minecraft:green_terracotta
fill 383 174 270 383 178 270 minecraft:green_terracotta
fill 384 174 230 384 177 251 minecraft:brown_terracotta
setblock 384 174 252 minecraft:brown_concrete
setblock 384 174 260 minecraft:brown_concrete
fill 384 174 261 384 177 268 minecraft:brown_terracotta
setblock 386 174 252 minecraft:light[level=12]
setblock 386 174 259 minecraft:light[level=12]
fill 387 174 230 387 179 248 minecraft:brown_terracotta
setblock 387 174 249 minecraft:brown_concrete
setblock 387 174 263 minecraft:brown_concrete
fill 387 174 264 387 179 268 minecraft:brown_terracotta
setblock 393 174 252 minecraft:light[level=12]
setblock 393 174 259 minecraft:light[level=12]
setblock 395 174 249 minecraft:brown_concrete
setblock 395 174 263 minecraft:brown_concrete
fill 396 174 249 416 177 249 minecraft:brown_terracotta
fill 396 174 263 416 177 263 minecraft:brown_terracotta
setblock 398 174 252 minecraft:brown_concrete
setblock 398 174 260 minecraft:brown_concrete
fill 399 174 252 416 179 252 minecraft:brown_terracotta
fill 399 174 260 416 179 260 minecraft:brown_terracotta
setblock 376 175 262 minecraft:moss_block
fill 376 175 263 376 185 263 minecraft:green_terracotta
fill 383 175 230 383 176 253 minecraft:brown_terracotta
fill 383 175 254 383 175 258 minecraft:bone_block
fill 383 175 259 383 176 268 minecraft:brown_terracotta
fill 384 175 252 384 175 253 minecraft:bone_block
fill 384 175 259 384 175 260 minecraft:bone_block
setblock 385 175 251 minecraft:bone_block
setblock 385 175 261 minecraft:bone_block
setblock 385 175 270 minecraft:moss_block
setblock 386 175 250 minecraft:bone_block
setblock 386 175 262 minecraft:bone_block
fill 387 175 249 388 175 249 minecraft:bone_block
fill 387 175 263 388 175 263 minecraft:bone_block
fill 389 175 230 389 180 247 minecraft:brown_terracotta
fill 389 175 248 393 175 248 minecraft:bone_block
fill 389 175 264 393 175 264 minecraft:bone_block
fill 389 175 265 389 180 268 minecraft:brown_terracotta
fill 394 175 248 416 176 248 minecraft:brown_terracotta
fill 394 175 249 395 175 249 minecraft:bone_block
fill 394 175 263 395 175 263 minecraft:bone_block
fill 394 175 264 416 176 264 minecraft:brown_terracotta
setblock 396 175 250 minecraft:bone_block
setblock 396 175 262 minecraft:bone_block
setblock 397 175 251 minecraft:bone_block
setblock 397 175 261 minecraft:bone_block
fill 398 175 252 398 175 253 minecraft:bone_block
fill 398 175 259 398 175 260 minecraft:bone_block
fill 399 175 228 399 229 228 minecraft:green_terracotta
fill 399 175 254 399 175 258 minecraft:bone_block
setblock 400 175 228 minecraft:jungle_leaves[persistent=true]
fill 400 175 254 416 180 254 minecraft:brown_terracotta
fill 400 175 258 416 180 258 minecraft:brown_terracotta
setblock 401 175 228 minecraft:moss_block
setblock 418 175 240 minecraft:jungle_leaves[persistent=true]
fill 418 175 241 418 223 241 minecraft:green_terracotta
fill 418 175 258 418 179 259 minecraft:green_terracotta
setblock 418 175 260 minecraft:moss_block
fill 376 176 262 376 191 262 minecraft:green_terracotta
fill 376 176 266 376 204 266 minecraft:green_terracotta
setblock 376 176 267 minecraft:green_concrete
fill 383 176 254 383 178 258 minecraft:brown_concrete
fill 384 176 252 384 176 253 minecraft:brown_concrete
fill 384 176 259 384 176 260 minecraft:brown_concrete
fill 385 176 251 385 177 251 minecraft:brown_concrete
fill 385 176 261 385 177 261 minecraft:brown_concrete
fill 385 176 270 385 179 270 minecraft:green_terracotta
fill 386 176 250 386 177 250 minecraft:brown_concrete
fill 386 176 262 386 177 262 minecraft:brown_concrete
fill 387 176 249 388 176 249 minecraft:brown_concrete
fill 387 176 263 388 176 263 minecraft:brown_concrete
fill 389 176 248 393 178 248 minecraft:brown_concrete
fill 389 176 264 393 178 264 minecraft:brown_concrete
fill 394 176 249 395 176 249 minecraft:brown_concrete
fill 394 176 263 395 176 263 minecraft:brown_concrete
fill 396 176 250 396 177 250 minecraft:brown_concrete
fill 396 176 262 396 177 262 minecraft:brown_concrete
fill 397 176 251 397 177 251 minecraft:brown_concrete
fill 397 176 261 397 177 261 minecraft:brown_concrete
fill 397 176 270 398 188 270 minecraft:green_terracotta
fill 398 176 252 398 176 253 minecraft:brown_concrete
fill 398 176 259 398 176 260 minecraft:brown_concrete
fill 399 176 254 399 178 258 minecraft:brown_concrete
setblock 399 176 270 minecraft:mossy_cobblestone
fill 400 176 228 401 229 228 minecraft:green_terracotta
fill 418 176 240 418 225 240 minecraft:green_terracotta
setblock 418 176 246 minecraft:jungle_leaves[persistent=true]
fill 418 176 247 418 179 252 minecraft:green_terracotta
fill 418 176 260 418 178 260 minecraft:green_terracotta
setblock 376 177 236 minecraft:jungle_leaves[persistent=true]
fill 376 177 237 376 178 238 minecraft:green_terracotta
setblock 376 177 261 minecraft:jungle_leaves[persistent=true]
fill 376 177 267 376 189 267 minecraft:green_terracotta
fill 383 177 230 383 179 252 minecraft:brown_terracotta
fill 383 177 253 383 178 253 minecraft:brown_concrete
fill 383 177 259 383 178 259 minecraft:brown_concrete
fill 383 177 260 383 179 268 minecraft:brown_terracotta
fill 384 177 252 384 178 252 minecraft:brown_concrete
fill 384 177 260 384 178 260 minecraft:brown_concrete
fill 387 177 249 387 178 249 minecraft:brown_concrete
setblock 387 177 255 minecraft:light[level=15]
fill 387 177 263 387 178 263 minecraft:brown_concrete
fill 388 177 230 388 182 247 minecraft:brown_terracotta
fill 388 177 248 388 178 248 minecraft:brown_concrete
fill 388 177 264 388 178 264 minecraft:brown_concrete
fill 388 177 265 388 182 268 minecraft:brown_terracotta
fill 394 177 248 394 178 248 minecraft:brown_concrete
fill 394 177 264 394 178 264 minecraft:brown_concrete
fill 395 177 248 416 179 248 minecraft:brown_terracotta
fill 395 177 249 395 178 249 minecraft:brown_concrete
setblock 395 177 255 minecraft:light[level=15]
fill 395 177 263 395 178 263 minecraft:brown_concrete
fill 395 177 264 416 179 264 minecraft:brown_terracotta
fill 398 177 252 398 178 252 minecraft:brown_concrete
fill 398 177 260 398 178 260 minecraft:brown_concrete
fill 399 177 253 399 178 253 minecraft:brown_concrete
fill 399 177 259 399 178 259 minecraft:brown_concrete
fill 399 177 270 404 195 270 minecraft:green_terracotta
fill 400 177 253 416 182 253 minecraft:brown_terracotta
fill 400 177 259 416 182 259 minecraft:brown_terracotta
setblock 405 177 270 minecraft:moss_block
fill 409 177 270 409 200 270 minecraft:green_terracotta
setblock 410 177 270 minecraft:jungle_leaves[persistent=true]
setblock 411 177 270 minecraft:green_concrete
fill 418 177 246 418 221 246 minecraft:green_terracotta
setblock 418 177 265 minecraft:moss_block
fill 376 178 236 376 225 236 minecraft:green_terracotta
fill 376 178 261 376 190 261 minecraft:green_terracotta
fill 384 178 230 384 181 250 minecraft:brown_terracotta
setblock 384 178 251 minecraft:brown_concrete
setblock 384 178 261 minecraft:brown_concrete
fill 384 178 262 384 181 268 minecraft:brown_terracotta
fill 385 178 228 389 180 228 minecraft:green_terracotta
fill 385 178 230 385 181 249 minecraft:brown_terracotta
setblock 385 178 250 minecraft:brown_concrete
setblock 385 178 262 minecraft:brown_concrete
fill 385 178 263 385 181 268 minecraft:brown_terracotta
fill 386 178 230 386 182 248 minecraft:brown_terracotta
setblock 386 178 249 minecraft:brown_concrete
fill 386 178 262 386 182 262 minecraft:oak_leaves[persistent=true]
setblock 386 178 263 minecraft:brown_concrete
fill 386 178 264 386 182 268 minecraft:brown_terracotta
setblock 390 178 228 minecraft:green_concrete
setblock 392 178 228 minecraft:mossy_cobblestone
setblock 396 178 249 minecraft:brown_concrete
setblock 396 178 263 minecraft:brown_concrete
fill 397 178 249 416 181 249 minecraft:brown_terracotta
setblock 397 178 250 minecraft:brown_concrete
setblock 397 178 262 minecraft:brown_concrete
fill 397 178 263 416 181 263 minecraft:brown_terracotta
fill 398 178 250 416 181 250 minecraft:brown_terracotta
setblock 398 178 251 minecraft:brown_concrete
setblock 398 178 261 minecraft:brown_concrete
fill 398 178 262 416 181 262 minecraft:brown_terracotta
fill 399 178 251 416 182 251 minecraft:brown_terracotta
fill 399 178 261 416 182 261 minecraft:brown_terracotta
fill 405 178 270 405 211 270 minecraft:green_terracotta
fill 408 178 228 409 183 228 minecraft:oak_leaves[persistent=true]
fill 410 178 270 411 205 270 minecraft:green_terracotta
fill 418 178 261 418 183 261 minecraft:azalea_leaves[persistent=true]
fill 418 178 265 418 210 265 minecraft:green_terracotta
fill 376 179 228 376 182 229 minecraft:oak_leaves[persistent=true]
fill 376 179 237 376 226 237 minecraft:green_terracotta
setblock 376 179 238 minecraft:mossy_cobblestone
setblock 376 179 240 minecraft:moss_block
fill 376 179 241 376 217 241 minecraft:green_terracotta
fill 376 179 254 376 184 255 minecraft:green_terracotta
setblock 376 179 256 minecraft:moss_block
fill 376 179 257 376 192 258 minecraft:green_terracotta
fill 376 179 268 376 180 268 minecraft:jungle_log
setblock 376 179 269 minecraft:green_terracotta
fill 376 179 270 376 182 270 minecraft:azalea_leaves[persistent=true]
fill 378 179 230 381 185 268 minecraft:brown_terracotta
fill 382 179 230 382 179 255 minecraft:brown_terracotta
setblock 382 179 256 minecraft:bone_block
fill 382 179 257 382 179 268 minecraft:brown_terracotta
fill 383 179 253 383 179 255 minecraft:bone_block
fill 383 179 256 383 180 256 minecraft:dirt
fill 383 179 257 383 179 259 minecraft:bone_block
fill 383 179 270 384 181 270 minecraft:oak_leaves[persistent=true]
fill 384 179 251 384 179 252 minecraft:bone_block
fill 384 179 260 384 179 261 minecraft:bone_block
setblock 385 179 250 minecraft:bone_block
fill 385 179 260 385 181 261 minecraft:oak_leaves[persistent=true]
setblock 385 179 262 minecraft:bone_block
fill 386 179 249 387 179 249 minecraft:bone_block
fill 386 179 261 387 182 261 minecraft:oak_leaves[persistent=true]
fill 386 179 263 387 179 263 minecraft:bone_block
fill 387 179 262 388 181 262 minecraft:oak_leaves[persistent=true]
fill 388 179 248 390 179 248 minecraft:bone_block
fill 388 179 264 390 179 264 minecraft:bone_block
fill 390 179 228 390 187 228 minecraft:green_terracotta
fill 390 179 230 390 179 247 minecraft:brown_terracotta
fill 390 179 265 390 179 268 minecraft:brown_terracotta
fill 391 179 230 416 185 246 minecraft:brown_terracotta
setblock 391 179 247 minecraft:bone_block
setblock 391 179 265 minecraft:bone_block
fill 391 179 266 416 185 268 minecraft:brown_terracotta
fill 392 179 228 392 196 228 minecraft:green_terracotta
fill 392 179 247 416 179 247 minecraft:brown_terracotta
fill 392 179 248 394 179 248 minecraft:bone_block
fill 392 179 264 394 179 264 minecraft:bone_block
fill 392 179 265 416 179 265 minecraft:brown_terracotta
fill 395 179 249 396 179 249 minecraft:bone_block
fill 395 179 263 396 179 263 minecraft:bone_block
setblock 397 179 250 minecraft:bone_block
setblock 397 179 262 minecraft:bone_block
fill 398 179 251 398 179 252 minecraft:bone_block
fill 398 179 260 398 179 261 minecraft:bone_block
fill 399 179 253 399 179 255 minecraft:bone_block
fill 399 179 257 399 179 259 minecraft:bone_block
fill 400 179 255 416 179 255 minecraft:brown_terracotta
setblock 400 179 256 minecraft:bone_block
fill 400 179 257 416 179 257 minecraft:brown_terracotta
fill 401 179 256 416 185 256 minecraft:brown_terracotta
setblock 406 179 270 minecraft:green_terracotta
fill 407 179 228 407 182 228 minecraft:oak_leaves[persistent=true]
fill 407 179 270 407 181 270 minecraft:oak_leaves[persistent=true]
setblock 408 179 270 minecraft:green_terracotta
fill 410 179 228 410 182 228 minecraft:oak_leaves[persistent=true]
setblock 418 179 253 minecraft:mossy_cobblestone
fill 418 179 260 418 182 260 minecraft:azalea_leaves[persistent=true]
fill 418 179 262 418 182 262 minecraft:azalea_leaves[persistent=true]
setblock 418 179 263 minecraft:jungle_leaves[persistent=true]
fill 418 179 264 418 191 264 minecraft:green_terracotta
fill 376 180 230 376 181 230 minecraft:oak_leaves[persistent=true]
fill 376 180 238 376 183 238 minecraft:green_terracotta
fill 376 180 240 376 229 240 minecraft:green_terracotta
setblock 376 180 253 minecraft:moss_block
fill 376 180 256 376 190 256 minecraft:green_terracotta
fill 376 180 269 376 182 269 minecraft:azalea_leaves[persistent=true]
fill 382 180 230 382 180 254 minecraft:brown_terracotta
fill 382 180 255 382 182 257 minecraft:brown_concrete
fill 382 180 258 382 180 268 minecraft:brown_terracotta
setblock 382 180 270 minecraft:jungle_log
fill 383 180 230 383 182 251 minecraft:brown_terracotta
fill 383 180 252 383 180 254 minecraft:brown_concrete
setblock 383 180 255 minecraft:dirt
setblock 383 180 257 minecraft:dirt
fill 383 180 258 383 180 260 minecraft:brown_concrete
fill 383 180 261 383 182 268 minecraft:brown_terracotta
fill 384 180 251 384 182 251 minecraft:brown_concrete
fill 384 180 261 384 182 261 minecraft:brown_concrete
fill 385 180 250 385 181 250 minecraft:brown_concrete
fill 385 180 262 385 181 262 minecraft:brown_concrete
fill 385 180 270 386 181 270 minecraft:oak_leaves[persistent=true]
fill 386 180 249 386 182 249 minecraft:brown_concrete
setblock 386 180 252 minecraft:light[level=12]
setblock 386 180 259 minecraft:light[level=12]
fill 386 180 260 387 181 260 minecraft:oak_leaves[persistent=true]
fill 386 180 263 386 182 263 minecraft:brown_concrete
fill 387 180 230 387 184 247 minecraft:brown_terracotta
fill 387 180 248 389 180 248 minecraft:brown_concrete
fill 387 180 263 387 183 263 minecraft:oak_leaves[persistent=true]
fill 387 180 264 389 180 264 minecraft:brown_concrete
fill 387 180 265 387 184 268 minecraft:brown_terracotta
fill 388 180 261 388 181 261 minecraft:oak_leaves[persistent=true]
fill 390 180 230 390 185 246 minecraft:brown_terracotta
fill 390 180 247 392 182 247 minecraft:brown_concrete
fill 390 180 265 392 182 265 minecraft:brown_concrete
fill 390 180 266 390 185 268 minecraft:brown_terracotta
fill 393 180 247 416 180 247 minecraft:brown_terracotta
fill 393 180 248 395 180 248 minecraft:brown_concrete
setblock 393 180 252 minecraft:light[level=12]
setblock 393 180 259 minecraft:light[level=12]
fill 393 180 264 395 180 264 minecraft:brown_concrete
fill 393 180 265 416 180 265 minecraft:brown_terracotta
setblock 393 180 270 minecraft:green_concrete
fill 396 180 248 416 182 248 minecraft:brown_terracotta
fill 396 180 249 396 182 249 minecraft:brown_concrete
fill 396 180 263 396 182 263 minecraft:brown_concrete
fill 396 180 264 416 182 264 minecraft:brown_terracotta
fill 397 180 250 397 181 250 minecraft:brown_concrete
fill 397 180 262 397 181 262 minecraft:brown_concrete
fill 398 180 251 398 182 251 minecraft:brown_concrete
fill 398 180 261 398 182 261 minecraft:brown_concrete
fill 399 180 252 399 180 254 minecraft:brown_concrete
fill 399 180 258 399 180 260 minecraft:brown_concrete
fill 400 180 252 416 184 252 minecraft:brown_terracotta
fill 400 180 255 400 182 257 minecraft:brown_concrete
fill 400 180 260 416 184 260 minecraft:brown_terracotta
fill 401 180 255 416 185 255 minecraft:brown_terracotta
fill 401 180 257 416 185 257 minecraft:brown_terracotta
setblock 406 180 270 minecraft:oak_leaves[persistent=true]
fill 408 180 270 408 181 270 minecraft:oak_leaves[persistent=true]
setblock 414 180 270 minecraft:mossy_cobblestone
setblock 418 180 233 minecraft:green_concrete
fill 418 180 247 418 204 249 minecraft:green_terracotta
setblock 418 180 250 minecraft:green_concrete
fill 418 180 251 418 200 253 minecraft:green_terracotta
fill 418 180 258 418 196 258 minecraft:green_terracotta
fill 418 180 259 418 182 259 minecraft:azalea_leaves[persistent=true]
fill 418 180 263 418 182 263 minecraft:azalea_leaves[persistent=true]
setblock 376 181 239 minecraft:mossy_cobblestone
fill 376 181 253 376 204 253 minecraft:green_terracotta
fill 376 181 268 376 184 268 minecraft:green_terracotta
fill 382 181 230 382 182 253 minecraft:brown_terracotta
fill 382 181 254 382 182 254 minecraft:brown_concrete
fill 382 181 258 382 182 258 minecraft:brown_concrete
fill 382 181 259 382 182 268 minecraft:brown_terracotta
fill 382 181 270 382 205 270 minecraft:green_terracotta
fill 383 181 252 383 182 253 minecraft:brown_concrete
fill 383 181 259 383 182 260 minecraft:brown_concrete
fill 385 181 228 385 192 228 minecraft:green_terracotta
setblock 386 181 228 minecraft:jungle_leaves[persistent=true]
fill 387 181 228 389 184 228 minecraft:green_terracotta
fill 387 181 248 388 182 248 minecraft:brown_concrete
fill 387 181 264 388 182 264 minecraft:brown_concrete
fill 389 181 230 389 186 246 minecraft:brown_terracotta
fill 389 181 247 389 182 247 minecraft:brown_concrete
fill 389 181 265 389 182 265 minecraft:brown_concrete
fill 389 181 266 389 186 268 minecraft:brown_terracotta
fill 393 181 247 393 182 247 minecraft:brown_concrete
fill 393 181 265 393 182 265 minecraft:brown_concrete
fill 393 181 270 393 213 270 minecraft:green_terracotta
fill 394 181 247 416 182 247 minecraft:brown_terracotta
fill 394 181 248 395 182 248 minecraft:brown_concrete
fill 394 181 264 395 182 264 minecraft:brown_concrete
fill 394 181 265 416 182 265 minecraft:brown_terracotta
fill 399 181 252 399 182 253 minecraft:brown_concrete
fill 399 181 259 399 182 260 minecraft:brown_concrete
fill 400 181 254 400 182 254 minecraft:brown_concrete
fill 400 181 258 400 182 258 minecraft:brown_concrete
fill 401 181 254 416 186 254 minecraft:brown_terracotta
fill 401 181 258 416 186 258 minecraft:brown_terracotta
setblock 406 181 228 minecraft:oak_leaves[persistent=true]
fill 406 181 270 406 205 270 minecraft:green_terracotta
fill 414 181 270 414 227 270 minecraft:green_terracotta
setblock 418 181 230 minecraft:moss_block
fill 418 181 231 418 198 231 minecraft:green_terracotta
fill 418 181 233 418 188 233 minecraft:green_terracotta
fill 418 181 250 418 207 250 minecraft:green_terracotta
fill 376 182 230 376 220 230 minecraft:green_terracotta
fill 376 182 239 376 189 239 minecraft:green_terracotta
fill 383 182 270 383 217 270 minecraft:green_terracotta
fill 384 182 230 384 186 249 minecraft:brown_terracotta
setblock 384 182 250 minecraft:brown_concrete
setblock 384 182 262 minecraft:brown_concrete
fill 384 182 263 384 186 268 minecraft:brown_terracotta
fill 384 182 270 385 182 270 minecraft:oak_leaves[persistent=true]
fill 385 182 230 385 186 248 minecraft:brown_terracotta
setblock 385 182 249 minecraft:brown_concrete
fill 385 182 261 385 182 262 minecraft:oak_leaves[persistent=true]
setblock 385 182 263 minecraft:brown_concrete
fill 385 182 264 385 186 268 minecraft:brown_terracotta
fill 386 182 228 386 192 228 minecraft:green_terracotta
setblock 386 182 260 minecraft:oak_leaves[persistent=true]
setblock 386 182 270 minecraft:green_terracotta
setblock 387 182 262 minecraft:oak_leaves[persistent=true]
setblock 397 182 249 minecraft:brown_concrete
setblock 397 182 263 minecraft:brown_concrete
fill 398 182 249 416 186 249 minecraft:brown_terracotta
setblock 398 182 250 minecraft:brown_concrete
setblock 398 182 262 minecraft:brown_concrete
fill 398 182 263 416 186 263 minecraft:brown_terracotta
fill 399 182 250 416 186 250 minecraft:brown_terracotta
fill 399 182 262 416 186 262 minecraft:brown_terracotta
fill 406 182 228 406 218 228 minecraft:green_terracotta
fill 407 182 270 408 196 270 minecraft:green_terracotta
fill 418 182 230 418 225 230 minecraft:green_terracotta
fill 376 183 228 376 226 229 minecraft:green_terracotta
setblock 376 183 246 minecraft:mossy_cobblestone
fill 376 183 247 376 199 247 minecraft:green_terracotta
fill 376 183 269 376 192 270 minecraft:green_terracotta
fill 382 183 230 382 184 252 minecraft:brown_terracotta
fill 382 183 253 382 183 259 minecraft:bone_block
fill 382 183 260 382 184 268 minecraft:brown_terracotta
fill 383 183 230 383 186 250 minecraft:brown_terracotta
fill 383 183 251 383 183 252 minecraft:bone_block
fill 383 183 260 383 183 261 minecraft:bone_block
fill 383 183 262 383 186 268 minecraft:brown_terracotta
setblock 384 183 250 minecraft:bone_block
setblock 384 183 262 minecraft:bone_block
fill 384 183 270 385 217 270 minecraft:green_terracotta
setblock 385 183 249 minecraft:bone_block
setblock 385 183 263 minecraft:bone_block
fill 386 183 230 386 188 247 minecraft:brown_terracotta
fill 386 183 248 387 183 248 minecraft:bone_block
fill 386 183 264 387 183 264 minecraft:bone_block
fill 386 183 265 386 188 268 minecraft:brown_terracotta
setblock 386 183 270 minecraft:jungle_leaves[persistent=true]
fill 388 183 230 388 188 246 minecraft:brown_terracotta
fill 388 183 247 394 183 247 minecraft:bone_block
fill 388 183 265 394 183 265 minecraft:bone_block
fill 388 183 266 388 188 268 minecraft:brown_terracotta
setblock 393 183 228 minecraft:moss_block
fill 395 183 247 416 184 247 minecraft:brown_terracotta
fill 395 183 248 396 183 248 minecraft:bone_block
fill 395 183 264 396 183 264 minecraft:bone_block
fill 395 183 265 416 184 265 minecraft:brown_terracotta
fill 397 183 248 416 186 248 minecraft:brown_terracotta
setblock 397 183 249 minecraft:bone_block
setblock 397 183 263 minecraft:bone_block
fill 397 183 264 416 186 264 minecraft:brown_terracotta
setblock 398 183 250 minecraft:bone_block
setblock 398 183 262 minecraft:bone_block
fill 399 183 251 399 183 252 minecraft:bone_block
fill 399 183 260 399 183 261 minecraft:bone_block
fill 400 183 251 416 188 251 minecraft:brown_terracotta
fill 400 183 253 400 183 259 minecraft:bone_block
fill 400 183 261 416 188 261 minecraft:brown_terracotta
fill 401 183 253 416 188 253 minecraft:brown_terracotta
fill 401 183 259 416 188 259 minecraft:brown_terracotta
fill 407 183 228 407 229 228 minecraft:green_terracotta
fill 410 183 228 410 204 228 minecraft:green_terracotta
fill 418 183 259 418 192 260 minecraft:green_terracotta
fill 418 183 262 418 191 263 minecraft:green_terracotta
setblock 376 184 238 minecraft:jungle_leaves[persistent=true]
setblock 376 184 242 minecraft:green_concrete
fill 376 184 243 376 229 243 minecraft:green_terracotta
fill 376 184 246 376 229 246 minecraft:green_terracotta
fill 382 184 253 382 185 259 minecraft:brown_concrete
fill 383 184 251 383 184 252 minecraft:brown_concrete
fill 383 184 260 383 184 261 minecraft:brown_concrete
fill 384 184 250 384 186 250 minecraft:brown_concrete
fill 384 184 262 384 186 262 minecraft:brown_concrete
fill 385 184 249 385 186 249 minecraft:brown_concrete
fill 385 184 263 385 186 263 minecraft:brown_concrete
fill 386 184 248 387 184 248 minecraft:brown_concrete
fill 386 184 264 387 184 264 minecraft:brown_concrete
fill 386 184 270 386 217 270 minecraft:green_terracotta
setblock 387 184 255 minecraft:light[level=15]
setblock 387 184 263 minecraft:light[level=15]
fill 388 184 247 394 185 247 minecraft:brown_concrete
fill 388 184 265 394 185 265 minecraft:brown_concrete
fill 393 184 228 393 210 228 minecraft:green_terracotta
fill 395 184 248 396 184 248 minecraft:brown_concrete
setblock 395 184 255 minecraft:light[level=15]
setblock 395 184 263 minecraft:light[level=15]
fill 395 184 264 396 184 264 minecraft:brown_concrete
setblock 395 184 270 minecraft:moss_block
fill 397 184 249 397 186 249 minecraft:brown_concrete
fill 397 184 263 397 186 263 minecraft:brown_concrete
fill 398 184 250 398 186 250 minecraft:brown_concrete
fill 398 184 262 398 186 262 minecraft:brown_concrete
fill 399 184 251 399 184 252 minecraft:brown_concrete
fill 399 184 260 399 184 261 minecraft:brown_concrete
fill 400 184 253 400 185 259 minecraft:brown_concrete
fill 408 184 228 409 229 228 minecraft:green_terracotta
fill 418 184 261 418 191 261 minecraft:green_terracotta
fill 376 185 238 376 220 238 minecraft:green_terracotta
fill 376 185 242 376 229 242 minecraft:green_terracotta
setblock 376 185 254 minecraft:green_concrete
fill 376 185 255 376 225 255 minecraft:green_terracotta
setblock 376 185 268 minecraft:moss_block
fill 382 185 230 382 188 251 minecraft:brown_terracotta
fill 382 185 252 382 186 252 minecraft:brown_concrete
fill 382 185 260 382 186 260 minecraft:brown_concrete
fill 382 185 261 382 188 268 minecraft:brown_terracotta
fill 383 185 251 383 186 251 minecraft:brown_concrete
fill 383 185 261 383 186 261 minecraft:brown_concrete
fill 386 185 248 386 186 248 minecraft:brown_concrete
fill 386 185 264 386 186 264 minecraft:brown_concrete
setblock 387 185 228 minecraft:moss_block
fill 387 185 230 387 190 246 minecraft:brown_terracotta
fill 387 185 247 387 186 247 minecraft:brown_concrete
fill 387 185 265 387 186 265 minecraft:brown_concrete
fill 387 185 266 387 190 268 minecraft:brown_terracotta
fill 388 185 228 389 191 228 minecraft:green_terracotta
fill 395 185 247 395 186 247 minecraft:brown_concrete
fill 395 185 265 395 186 265 minecraft:brown_concrete
fill 395 185 270 395 229 270 minecraft:green_terracotta
fill 396 185 247 416 188 247 minecraft:brown_terracotta
fill 396 185 248 396 186 248 minecraft:brown_concrete
fill 396 185 264 396 186 264 minecraft:brown_concrete
fill 396 185 265 416 188 265 minecraft:brown_terracotta
fill 399 185 251 399 186 251 minecraft:brown_concrete
fill 399 185 261 399 186 261 minecraft:brown_concrete
fill 400 185 252 400 186 252 minecraft:brown_concrete
fill 400 185 260 400 186 260 minecraft:brown_concrete
fill 401 185 252 416 190 252 minecraft:brown_terracotta
fill 401 185 260 416 190 260 minecraft:brown_terracotta
fill 402 185 228 402 226 228 minecraft:green_terracotta
setblock 403 185 228 minecraft:green_concrete
setblock 376 186 232 minecraft:jungle_leaves[persistent=true]
fill 376 186 233 376 229 233 minecraft:green_terracotta
fill 376 186 254 376 209 254 minecraft:green_terracotta
setblock 376 186 263 minecraft:moss_block
fill 376 186 268 376 191 268 minecraft:green_terracotta
fill 378 186 230 380 191 268 minecraft:brown_terracotta
fill 381 186 230 381 186 254 minecraft:brown_terracotta
fill 381 186 255 381 186 257 minecraft:brown_concrete
fill 381 186 258 381 186 268 minecraft:brown_terracotta
fill 382 186 253 382 186 254 minecraft:brown_concrete
fill 382 186 256 382 187 256 minecraft:jungle_log
fill 382 186 258 382 186 259 minecraft:brown_concrete
setblock 386 186 252 minecraft:light[level=12]
setblock 386 186 259 minecraft:light[level=12]
fill 387 186 228 387 191 228 minecraft:green_terracotta
fill 388 186 247 389 186 247 minecraft:brown_concrete
fill 388 186 265 389 186 265 minecraft:brown_concrete
fill 390 186 230 416 191 245 minecraft:brown_terracotta
fill 390 186 246 392 186 246 minecraft:brown_concrete
fill 390 186 266 392 186 266 minecraft:brown_concrete
fill 390 186 267 416 191 268 minecraft:brown_terracotta
fill 393 186 246 416 186 246 minecraft:brown_terracotta
fill 393 186 247 394 186 247 minecraft:brown_concrete
setblock 393 186 252 minecraft:light[level=12]
setblock 393 186 259 minecraft:light[level=12]
fill 393 186 265 394 186 265 minecraft:brown_concrete
fill 393 186 266 416 186 266 minecraft:brown_terracotta
fill 400 186 253 400 186 254 minecraft:brown_concrete
fill 400 186 258 400 186 259 minecraft:brown_concrete
fill 401 186 255 401 186 257 minecraft:brown_concrete
fill 402 186 255 416 191 257 minecraft:brown_terracotta
fill 403 186 228 403 227 228 minecraft:green_terracotta
fill 376 187 232 376 227 232 minecraft:green_terracotta
fill 376 187 263 376 229 263 minecraft:green_terracotta
fill 381 187 230 381 188 253 minecraft:brown_terracotta
fill 381 187 254 381 187 258 minecraft:bone_block
fill 381 187 259 381 188 268 minecraft:brown_terracotta
fill 382 187 252 382 187 253 minecraft:bone_block
fill 382 187 259 382 187 260 minecraft:bone_block
fill 383 187 230 383 191 249 minecraft:brown_terracotta
fill 383 187 250 383 187 251 minecraft:bone_block
fill 383 187 261 383 187 262 minecraft:bone_block
fill 383 187 263 383 191 268 minecraft:brown_terracotta
fill 384 187 230 384 191 248 minecraft:brown_terracotta
setblock 384 187 249 minecraft:bone_block
setblock 384 187 263 minecraft:bone_block
fill 384 187 264 384 191 268 minecraft:brown_terracotta
fill 385 187 230 385 191 247 minecraft:brown_terracotta
fill 385 187 248 386 187 248 minecraft:bone_block
fill 385 187 264 386 187 264 minecraft:bone_block
fill 385 187 265 385 191 268 minecraft:brown_terracotta
fill 387 187 247 388 187 247 minecraft:bone_block
fill 387 187 265 388 187 265 minecraft:bone_block
fill 389 187 230 389 192 245 minecraft:brown_terracotta
fill 389 187 246 393 187 246 minecraft:bone_block
fill 389 187 266 393 187 266 minecraft:bone_block
fill 389 187 267 389 192 268 minecraft:brown_terracotta
fill 394 187 246 416 188 246 minecraft:brown_terracotta
fill 394 187 247 395 187 247 minecraft:bone_block
fill 394 187 265 395 187 265 minecraft:bone_block
fill 394 187 266 416 188 266 minecraft:brown_terracotta
fill 396 187 248 397 187 248 minecraft:bone_block
fill 396 187 264 397 187 264 minecraft:bone_block
fill 398 187 248 416 191 248 minecraft:brown_terracotta
setblock 398 187 249 minecraft:bone_block
setblock 398 187 263 minecraft:bone_block
fill 398 187 264 416 191 264 minecraft:brown_terracotta
fill 399 187 249 416 191 249 minecraft:brown_terracotta
fill 399 187 250 399 187 251 minecraft:bone_block
fill 399 187 261 399 187 262 minecraft:bone_block
fill 399 187 263 416 191 263 minecraft:brown_terracotta
fill 400 187 250 416 191 250 minecraft:brown_terracotta
fill 400 187 252 400 187 253 minecraft:bone_block
fill 400 187 259 400 187 260 minecraft:bone_block
fill 400 187 262 416 191 262 minecraft:brown_terracotta
fill 401 187 254 401 187 258 minecraft:bone_block
fill 402 187 254 416 192 254 minecraft:brown_terracotta
fill 402 187 258 416 192 258 minecraft:brown_terracotta
setblock 418 187 267 minecraft:moss_block
fill 381 188 254 381 190 258 minecraft:brown_concrete
fill 382 188 252 382 188 253 minecraft:brown_concrete
fill 382 188 254 383 191 258 minecraft:jungle_leaves[persistent=true]
fill 382 188 259 382 188 260 minecraft:brown_concrete
fill 383 188 250 383 188 251 minecraft:brown_concrete
fill 383 188 261 383 188 262 minecraft:brown_concrete
fill 384 188 249 384 190 249 minecraft:brown_concrete
fill 384 188 263 384 190 263 minecraft:brown_concrete
fill 385 188 248 386 188 248 minecraft:brown_concrete
fill 385 188 264 386 188 264 minecraft:brown_concrete
fill 387 188 247 388 188 247 minecraft:brown_concrete
fill 387 188 265 388 188 265 minecraft:brown_concrete
fill 389 188 246 393 190 246 minecraft:brown_concrete
fill 389 188 266 393 190 266 minecraft:brown_concrete
setblock 390 188 228 minecraft:moss_block
fill 394 188 247 395 188 247 minecraft:brown_concrete
fill 394 188 265 395 188 265 minecraft:brown_concrete
fill 396 188 248 397 188 248 minecraft:brown_concrete
fill 396 188 264 397 188 264 minecraft:brown_concrete
fill 398 188 249 398 190 249 minecraft:brown_concrete
fill 398 188 263 398 190 263 minecraft:brown_concrete
fill 399 188 250 399 188 251 minecraft:brown_concrete
fill 399 188 261 399 188 262 minecraft:brown_concrete
fill 400 188 252 400 188 253 minecraft:brown_concrete
fill 400 188 259 400 188 260 minecraft:brown_concrete
fill 401 188 254 401 190 258 minecraft:brown_concrete
setblock 418 188 243 minecraft:jungle_leaves[persistent=true]
fill 418 188 244 418 230 244 minecraft:green_terracotta
fill 418 188 267 418 217 267 minecraft:green_terracotta
fill 381 189 230 381 190 252 minecraft:brown_terracotta
fill 381 189 253 381 190 253 minecraft:brown_concrete
fill 381 189 259 381 190 259 minecraft:brown_concrete
fill 381 189 260 381 190 268 minecraft:brown_terracotta
fill 382 189 230 382 191 250 minecraft:brown_terracotta
fill 382 189 251 382 190 252 minecraft:brown_concrete
fill 382 189 253 382 190 253 minecraft:jungle_leaves[persistent=true]
fill 382 189 259 382 190 259 minecraft:jungle_leaves[persistent=true]
fill 382 189 260 382 190 261 minecraft:brown_concrete
fill 382 189 262 382 191 268 minecraft:brown_terracotta
fill 383 189 250 383 190 250 minecraft:brown_concrete
fill 383 189 262 383 190 262 minecraft:brown_concrete
fill 384 189 255 384 190 257 minecraft:jungle_leaves[persistent=true]
fill 385 189 248 385 190 248 minecraft:brown_concrete
fill 385 189 264 385 190 264 minecraft:brown_concrete
fill 386 189 230 386 193 246 minecraft:brown_terracotta
fill 386 189 247 387 190 247 minecraft:brown_concrete
fill 386 189 265 387 190 265 minecraft:brown_concrete
fill 386 189 266 386 193 268 minecraft:brown_terracotta
fill 388 189 230 388 194 245 minecraft:brown_terracotta
fill 388 189 246 388 190 246 minecraft:brown_concrete
fill 388 189 266 388 190 266 minecraft:brown_concrete
fill 388 189 267 388 194 268 minecraft:brown_terracotta
fill 390 189 228 390 229 228 minecraft:green_terracotta
fill 394 189 246 394 190 246 minecraft:brown_concrete
fill 394 189 266 394 190 266 minecraft:brown_concrete
fill 395 189 246 416 190 246 minecraft:brown_terracotta
fill 395 189 247 396 190 247 minecraft:brown_concrete
fill 395 189 265 396 190 265 minecraft:brown_concrete
fill 395 189 266 416 190 266 minecraft:brown_terracotta
fill 397 189 247 416 191 247 minecraft:brown_terracotta
fill 397 189 248 397 190 248 minecraft:brown_concrete
fill 397 189 264 397 190 264 minecraft:brown_concrete
fill 397 189 265 416 191 265 minecraft:brown_terracotta
setblock 397 189 270 minecraft:green_concrete
fill 398 189 270 398 215 270 minecraft:green_terracotta
fill 399 189 250 399 190 250 minecraft:brown_concrete
fill 399 189 262 399 190 262 minecraft:brown_concrete
fill 400 189 251 400 190 252 minecraft:brown_concrete
fill 400 189 260 400 190 261 minecraft:brown_concrete
fill 401 189 251 416 193 251 minecraft:brown_terracotta
fill 401 189 253 401 190 253 minecraft:brown_concrete
fill 401 189 259 401 190 259 minecraft:brown_concrete
fill 401 189 261 416 193 261 minecraft:brown_terracotta
fill 402 189 253 416 194 253 minecraft:brown_terracotta
fill 402 189 259 416 194 259 minecraft:brown_terracotta
setblock 418 189 233 minecraft:jungle_leaves[persistent=true]
fill 418 189 243 418 229 243 minecraft:green_terracotta
setblock 376 190 239 minecraft:green_concrete
setblock 376 190 250 minecraft:jungle_leaves[persistent=true]
setblock 376 190 267 minecraft:jungle_leaves[persistent=true]
fill 389 190 263 389 191 263 minecraft:verdant_froglight
setblock 394 190 270 minecraft:mossy_cobblestone
fill 397 190 270 397 229 270 minecraft:green_terracotta
setblock 416 190 228 minecraft:green_concrete
fill 418 190 233 418 191 233 minecraft:green_terracotta
fill 376 191 239 376 192 239 minecraft:green_terracotta
setblock 376 191 249 minecraft:mossy_cobblestone
fill 376 191 250 376 226 250 minecraft:green_terracotta
setblock 376 191 256 minecraft:moss_block
fill 376 191 261 376 195 261 minecraft:jungle_leaves[persistent=true]
setblock 376 191 267 minecraft:green_terracotta
fill 381 191 230 381 193 251 minecraft:brown_terracotta
fill 381 191 252 381 191 260 minecraft:bone_block
fill 381 191 261 381 193 268 minecraft:brown_terracotta
setblock 382 191 251 minecraft:bone_block
setblock 382 191 261 minecraft:bone_block
setblock 383 191 250 minecraft:bone_block
setblock 383 191 262 minecraft:bone_block
setblock 384 191 249 minecraft:bone_block
setblock 384 191 263 minecraft:bone_block
setblock 385 191 248 minecraft:bone_block
setblock 385 191 264 minecraft:bone_block
setblock 386 191 247 minecraft:bone_block
setblock 386 191 265 minecraft:bone_block
fill 387 191 230 387 196 245 minecraft:brown_terracotta
fill 387 191 246 395 191 246 minecraft:bone_block
setblock 387 191 247 minecraft:light[level=15]
setblock 387 191 255 minecraft:light[level=15]
setblock 387 191 263 minecraft:light[level=15]
fill 387 191 266 395 191 266 minecraft:bone_block
fill 387 191 267 387 196 268 minecraft:brown_terracotta
setblock 394 191 228 minecraft:moss_block
fill 394 191 270 394 225 270 minecraft:green_terracotta
setblock 395 191 228 minecraft:green_concrete
setblock 395 191 247 minecraft:light[level=15]
setblock 395 191 263 minecraft:light[level=15]
fill 396 191 246 416 193 246 minecraft:brown_terracotta
setblock 396 191 247 minecraft:bone_block
setblock 396 191 265 minecraft:bone_block
fill 396 191 266 416 193 266 minecraft:brown_terracotta
setblock 397 191 248 minecraft:bone_block
setblock 397 191 264 minecraft:bone_block
setblock 398 191 249 minecraft:bone_block
setblock 398 191 263 minecraft:bone_block
setblock 399 191 250 minecraft:bone_block
setblock 399 191 262 minecraft:bone_block
setblock 400 191 251 minecraft:bone_block
setblock 400 191 261 minecraft:bone_block
fill 401 191 252 401 191 260 minecraft:bone_block
fill 402 191 252 416 196 252 minecraft:brown_terracotta
fill 402 191 260 416 196 260 minecraft:brown_terracotta
fill 416 191 228 416 204 228 minecraft:green_terracotta
fill 376 192 249 376 229 249 minecraft:green_terracotta
setblock 376 192 252 minecraft:mossy_cobblestone
fill 376 192 256 376 229 256 minecraft:green_terracotta
fill 376 192 259 376 195 260 minecraft:jungle_leaves[persistent=true]
fill 376 192 262 376 194 262 minecraft:jungle_leaves[persistent=true]
fill 376 192 267 376 192 268 minecraft:jungle_log
fill 377 192 270 377 194 270 minecraft:oak_leaves[persistent=true]
fill 378 192 230 379 198 268 minecraft:brown_terracotta
setblock 378 192 270 minecraft:jungle_log
fill 380 192 230 380 192 254 minecraft:brown_terracotta
fill 380 192 255 380 194 257 minecraft:brown_concrete
fill 380 192 258 380 192 268 minecraft:brown_terracotta
fill 381 192 252 381 192 254 minecraft:brown_concrete
setblock 381 192 256 minecraft:jungle_leaves[persistent=true]
fill 381 192 258 381 192 260 minecraft:brown_concrete
fill 382 192 230 382 195 249 minecraft:brown_terracotta
fill 382 192 250 382 193 251 minecraft:brown_concrete
fill 382 192 261 382 193 262 minecraft:brown_concrete
fill 382 192 263 382 195 268 minecraft:brown_terracotta
fill 383 192 230 383 195 248 minecraft:brown_terracotta
fill 383 192 249 383 194 249 minecraft:brown_concrete
fill 383 192 263 383 194 263 minecraft:brown_concrete
fill 383 192 264 383 195 268 minecraft:brown_terracotta
fill 384 192 230 384 195 247 minecraft:brown_terracotta
fill 384 192 248 384 194 248 minecraft:brown_concrete
fill 384 192 264 384 194 264 minecraft:brown_concrete
fill 384 192 265 384 195 268 minecraft:brown_terracotta
fill 385 192 230 385 196 246 minecraft:brown_terracotta
fill 385 192 247 386 193 247 minecraft:brown_concrete
fill 385 192 265 386 193 265 minecraft:brown_concrete
fill 385 192 266 385 196 268 minecraft:brown_terracotta
setblock 386 192 252 minecraft:light[level=12]
setblock 386 192 259 minecraft:light[level=12]
fill 387 192 228 388 193 228 minecraft:oak_leaves[persistent=true]
fill 387 192 246 389 192 246 minecraft:brown_concrete
fill 387 192 266 389 192 266 minecraft:brown_concrete
fill 389 192 228 389 222 228 minecraft:green_terracotta
fill 389 192 263 389 198 263 minecraft:dirt
fill 390 192 230 416 198 244 minecraft:brown_terracotta
fill 390 192 245 392 194 245 minecraft:brown_concrete
fill 390 192 267 392 194 267 minecraft:brown_concrete
fill 390 192 268 416 198 268 minecraft:brown_terracotta
fill 393 192 245 416 192 245 minecraft:brown_terracotta
fill 393 192 246 395 192 246 minecraft:brown_concrete
setblock 393 192 252 minecraft:light[level=12]
setblock 393 192 259 minecraft:light[level=12]
fill 393 192 266 395 192 266 minecraft:brown_concrete
fill 393 192 267 416 192 267 minecraft:brown_terracotta
fill 394 192 228 395 225 228 minecraft:green_terracotta
fill 396 192 247 397 193 247 minecraft:brown_concrete
fill 396 192 265 397 193 265 minecraft:brown_concrete
fill 398 192 247 416 195 247 minecraft:brown_terracotta
fill 398 192 248 398 194 248 minecraft:brown_concrete
fill 398 192 264 398 194 264 minecraft:brown_concrete
fill 398 192 265 416 195 265 minecraft:brown_terracotta
fill 399 192 248 416 195 248 minecraft:brown_terracotta
fill 399 192 249 399 194 249 minecraft:brown_concrete
fill 399 192 263 399 194 263 minecraft:brown_concrete
fill 399 192 264 416 195 264 minecraft:brown_terracotta
fill 400 192 249 416 195 249 minecraft:brown_terracotta
fill 400 192 250 400 193 251 minecraft:brown_concrete
setblock 400 192 252 minecraft:light[level=12]
setblock 400 192 259 minecraft:light[level=12]
fill 400 192 261 400 193 262 minecraft:brown_concrete
fill 400 192 263 416 195 263 minecraft:brown_terracotta
fill 401 192 250 416 196 250 minecraft:brown_terracotta
fill 401 192 252 401 192 254 minecraft:brown_concrete
fill 401 192 258 401 192 260 minecraft:brown_concrete
fill 401 192 262 416 196 262 minecraft:brown_terracotta
fill 402 192 255 402 194 257 minecraft:brown_concrete
fill 403 192 255 416 198 257 minecraft:brown_terracotta
fill 418 192 232 418 193 233 minecraft:jungle_log
fill 418 192 261 418 194 263 minecraft:oak_leaves[persistent=true]
setblock 418 192 264 minecraft:jungle_log
setblock 376 193 239 minecraft:green_concrete
fill 376 193 252 376 226 252 minecraft:green_terracotta
fill 376 193 257 376 226 257 minecraft:green_terracotta
fill 376 193 258 376 195 258 minecraft:jungle_leaves[persistent=true]
setblock 376 193 267 minecraft:jungle_log
setblock 376 193 268 minecraft:jungle_leaves[persistent=true]
fill 376 193 269 376 229 269 minecraft:green_terracotta
fill 376 193 270 376 194 270 minecraft:oak_leaves[persistent=true]
fill 378 193 270 378 194 270 minecraft:oak_leaves[persistent=true]
fill 380 193 230 380 194 253 minecraft:brown_terracotta
fill 380 193 254 380 194 254 minecraft:brown_concrete
fill 380 193 258 380 194 258 minecraft:brown_concrete
fill 380 193 259 380 194 268 minecraft:brown_terracotta
fill 381 193 252 381 194 253 minecraft:brown_concrete
fill 381 193 259 381 194 260 minecraft:brown_concrete
fill 385 193 228 386 195 228 minecraft:oak_leaves[persistent=true]
fill 387 193 246 388 194 246 minecraft:brown_concrete
fill 387 193 266 388 194 266 minecraft:brown_concrete
fill 389 193 230 389 199 244 minecraft:brown_terracotta
fill 389 193 245 389 194 245 minecraft:brown_concrete
fill 389 193 267 389 194 267 minecraft:brown_concrete
fill 389 193 268 389 199 268 minecraft:brown_terracotta
fill 390 193 263 390 198 263 minecraft:dirt
fill 393 193 245 393 194 245 minecraft:brown_concrete
fill 393 193 267 393 194 267 minecraft:brown_concrete
fill 394 193 245 416 194 245 minecraft:brown_terracotta
fill 394 193 246 395 194 246 minecraft:brown_concrete
fill 394 193 266 395 194 266 minecraft:brown_concrete
fill 394 193 267 416 194 267 minecraft:brown_terracotta
fill 401 193 252 401 194 253 minecraft:brown_concrete
fill 401 193 259 401 194 260 minecraft:brown_concrete
fill 402 193 254 402 194 254 minecraft:brown_concrete
fill 402 193 258 402 194 258 minecraft:brown_concrete
fill 403 193 254 416 199 254 minecraft:brown_terracotta
fill 403 193 258 416 199 258 minecraft:brown_terracotta
setblock 412 193 228 minecraft:jungle_leaves[persistent=true]
fill 418 193 259 418 198 259 minecraft:green_terracotta
fill 418 193 260 418 194 260 minecraft:oak_leaves[persistent=true]
fill 418 193 264 418 194 264 minecraft:oak_leaves[persistent=true]
fill 376 194 239 376 229 239 minecraft:green_terracotta
fill 376 194 267 376 205 268 minecraft:green_terracotta
fill 381 194 230 381 196 250 minecraft:brown_terracotta
setblock 381 194 251 minecraft:brown_concrete
setblock 381 194 261 minecraft:brown_concrete
fill 381 194 262 381 196 268 minecraft:brown_terracotta
setblock 382 194 250 minecraft:brown_concrete
setblock 382 194 262 minecraft:brown_concrete
setblock 385 194 247 minecraft:brown_concrete
setblock 385 194 265 minecraft:brown_concrete
fill 386 194 230 386 199 245 minecraft:brown_terracotta
setblock 386 194 246 minecraft:brown_concrete
setblock 386 194 266 minecraft:brown_concrete
fill 386 194 267 386 199 268 minecraft:brown_terracotta
setblock 387 194 228 minecraft:oak_leaves[persistent=true]
fill 388 194 228 388 218 228 minecraft:green_terracotta
fill 389 194 262 390 198 262 minecraft:dirt
setblock 396 194 246 minecraft:brown_concrete
setblock 396 194 266 minecraft:brown_concrete
fill 397 194 246 416 196 246 minecraft:brown_terracotta
setblock 397 194 247 minecraft:brown_concrete
setblock 397 194 265 minecraft:brown_concrete
fill 397 194 266 416 196 266 minecraft:brown_terracotta
setblock 400 194 250 minecraft:brown_concrete
setblock 400 194 262 minecraft:brown_concrete
setblock 401 194 251 minecraft:brown_concrete
setblock 401 194 261 minecraft:brown_concrete
fill 402 194 251 416 199 251 minecraft:brown_terracotta
fill 402 194 261 416 199 261 minecraft:brown_terracotta
fill 412 194 228 412 230 228 minecraft:green_terracotta
fill 418 194 232 418 229 233 minecraft:green_terracotta
fill 376 195 262 376 217 262 minecraft:green_terracotta
fill 376 195 270 378 205 270 minecraft:green_terracotta
fill 380 195 230 380 196 252 minecraft:brown_terracotta
fill 380 195 253 380 195 259 minecraft:bone_block
fill 380 195 260 380 196 268 minecraft:brown_terracotta
fill 381 195 251 381 195 252 minecraft:bone_block
fill 381 195 260 381 195 261 minecraft:bone_block
setblock 381 195 270 minecraft:jungle_leaves[persistent=true]
setblock 382 195 250 minecraft:bone_block
setblock 382 195 262 minecraft:bone_block
setblock 383 195 249 minecraft:bone_block
setblock 383 195 263 minecraft:bone_block
setblock 384 195 248 minecraft:bone_block
setblock 384 195 264 minecraft:bone_block
setblock 385 195 247 minecraft:bone_block
setblock 385 195 265 minecraft:bone_block
fill 386 195 246 387 195 246 minecraft:bone_block
fill 386 195 266 387 195 266 minecraft:bone_block
fill 387 195 228 387 210 228 minecraft:green_terracotta
fill 388 195 230 388 200 244 minecraft:brown_terracotta
fill 388 195 245 394 195 245 minecraft:bone_block
fill 388 195 262 388 198 263 minecraft:dirt
fill 388 195 267 394 195 267 minecraft:bone_block
fill 388 195 268 388 200 268 minecraft:brown_terracotta
fill 389 195 264 390 198 264 minecraft:dirt
fill 391 195 262 391 198 263 minecraft:dirt
fill 395 195 245 416 196 245 minecraft:brown_terracotta
fill 395 195 246 396 195 246 minecraft:bone_block
fill 395 195 266 396 195 266 minecraft:bone_block
fill 395 195 267 416 196 267 minecraft:brown_terracotta
setblock 397 195 247 minecraft:bone_block
setblock 397 195 265 minecraft:bone_block
setblock 398 195 248 minecraft:bone_block
schedule function dropper:buildpart/56_2 1t
