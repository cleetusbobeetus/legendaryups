setblock 49 149 323 minecraft:moss_block
setblock 49 149 324 minecraft:mossy_cobblestone
fill 49 149 325 49 149 327 minecraft:moss_block
setblock 49 149 328 minecraft:mossy_cobblestone
fill 49 149 329 49 149 331 minecraft:moss_block
setblock 49 149 332 minecraft:mossy_cobblestone
fill 49 149 333 49 149 335 minecraft:moss_block
setblock 49 149 336 minecraft:mossy_cobblestone
fill 49 149 337 49 149 339 minecraft:moss_block
setblock 49 149 340 minecraft:mossy_cobblestone
fill 49 149 341 49 149 343 minecraft:moss_block
setblock 49 149 344 minecraft:mossy_cobblestone
fill 49 149 345 49 149 347 minecraft:moss_block
setblock 49 149 348 minecraft:mossy_cobblestone
fill 49 149 349 49 149 351 minecraft:moss_block
setblock 49 149 352 minecraft:mossy_cobblestone
fill 49 149 353 49 149 355 minecraft:moss_block
setblock 49 149 356 minecraft:mossy_cobblestone
fill 49 149 357 49 149 359 minecraft:moss_block
setblock 49 149 360 minecraft:mossy_cobblestone
fill 49 149 361 51 149 361 minecraft:moss_block
setblock 50 149 323 minecraft:mossy_cobblestone
fill 50 149 324 50 149 326 minecraft:moss_block
setblock 50 149 327 minecraft:mossy_cobblestone
fill 50 149 328 50 149 330 minecraft:moss_block
setblock 50 149 331 minecraft:mossy_cobblestone
fill 50 149 332 50 149 334 minecraft:moss_block
setblock 50 149 335 minecraft:mossy_cobblestone
fill 50 149 336 50 149 338 minecraft:moss_block
setblock 50 149 339 minecraft:mossy_cobblestone
fill 50 149 340 50 149 342 minecraft:moss_block
setblock 50 149 343 minecraft:mossy_cobblestone
fill 50 149 344 50 149 346 minecraft:moss_block
setblock 50 149 347 minecraft:mossy_cobblestone
fill 50 149 348 50 149 350 minecraft:moss_block
setblock 50 149 351 minecraft:mossy_cobblestone
fill 50 149 352 50 149 354 minecraft:moss_block
setblock 50 149 355 minecraft:mossy_cobblestone
fill 50 149 356 50 149 358 minecraft:moss_block
setblock 50 149 359 minecraft:mossy_cobblestone
fill 50 149 360 52 149 360 minecraft:moss_block
setblock 50 149 362 minecraft:moss_block
setblock 50 149 363 minecraft:mossy_cobblestone
fill 51 149 323 51 149 325 minecraft:moss_block
setblock 51 149 326 minecraft:mossy_cobblestone
fill 51 149 327 51 149 329 minecraft:moss_block
setblock 51 149 330 minecraft:mossy_cobblestone
fill 51 149 331 51 149 333 minecraft:moss_block
setblock 51 149 334 minecraft:mossy_cobblestone
fill 51 149 335 51 149 337 minecraft:moss_block
setblock 51 149 338 minecraft:mossy_cobblestone
fill 51 149 339 51 149 341 minecraft:moss_block
setblock 51 149 342 minecraft:mossy_cobblestone
fill 51 149 343 51 149 345 minecraft:moss_block
setblock 51 149 346 minecraft:mossy_cobblestone
fill 51 149 347 51 149 349 minecraft:moss_block
setblock 51 149 350 minecraft:mossy_cobblestone
fill 51 149 351 51 149 353 minecraft:moss_block
setblock 51 149 354 minecraft:mossy_cobblestone
fill 51 149 355 51 149 357 minecraft:moss_block
setblock 51 149 358 minecraft:mossy_cobblestone
fill 51 149 359 53 149 359 minecraft:moss_block
setblock 51 149 362 minecraft:mossy_cobblestone
fill 51 149 363 53 149 363 minecraft:moss_block
fill 52 149 322 59 154 322 minecraft:spruce_planks
fill 52 149 323 52 149 324 minecraft:moss_block
setblock 52 149 325 minecraft:mossy_cobblestone
fill 52 149 326 52 149 328 minecraft:moss_block
setblock 52 149 329 minecraft:mossy_cobblestone
fill 52 149 330 52 149 332 minecraft:moss_block
setblock 52 149 333 minecraft:mossy_cobblestone
fill 52 149 334 52 149 336 minecraft:moss_block
setblock 52 149 337 minecraft:mossy_cobblestone
fill 52 149 338 52 149 340 minecraft:moss_block
setblock 52 149 341 minecraft:mossy_cobblestone
fill 52 149 342 52 149 344 minecraft:moss_block
setblock 52 149 345 minecraft:mossy_cobblestone
fill 52 149 346 52 149 348 minecraft:moss_block
setblock 52 149 349 minecraft:mossy_cobblestone
fill 52 149 350 52 149 352 minecraft:moss_block
setblock 52 149 353 minecraft:mossy_cobblestone
fill 52 149 354 52 149 356 minecraft:moss_block
setblock 52 149 357 minecraft:mossy_cobblestone
fill 52 149 358 54 149 358 minecraft:moss_block
setblock 52 149 361 minecraft:mossy_cobblestone
fill 52 149 362 54 149 362 minecraft:moss_block
setblock 53 149 323 minecraft:moss_block
setblock 53 149 324 minecraft:mossy_cobblestone
fill 53 149 325 53 149 327 minecraft:moss_block
setblock 53 149 328 minecraft:mossy_cobblestone
fill 53 149 329 53 149 331 minecraft:moss_block
setblock 53 149 332 minecraft:mossy_cobblestone
fill 53 149 333 53 149 335 minecraft:moss_block
setblock 53 149 336 minecraft:mossy_cobblestone
fill 53 149 337 53 149 339 minecraft:moss_block
setblock 53 149 340 minecraft:mossy_cobblestone
fill 53 149 341 53 149 343 minecraft:moss_block
setblock 53 149 344 minecraft:mossy_cobblestone
fill 53 149 345 53 149 347 minecraft:moss_block
setblock 53 149 348 minecraft:mossy_cobblestone
fill 53 149 349 53 149 351 minecraft:moss_block
setblock 53 149 352 minecraft:mossy_cobblestone
fill 53 149 353 53 149 355 minecraft:moss_block
setblock 53 149 356 minecraft:mossy_cobblestone
fill 53 149 357 55 149 357 minecraft:moss_block
setblock 53 149 360 minecraft:mossy_cobblestone
fill 53 149 361 55 149 361 minecraft:moss_block
setblock 54 149 323 minecraft:mossy_cobblestone
fill 54 149 324 54 149 326 minecraft:moss_block
setblock 54 149 327 minecraft:mossy_cobblestone
fill 54 149 328 54 149 330 minecraft:moss_block
setblock 54 149 331 minecraft:mossy_cobblestone
fill 54 149 332 54 149 334 minecraft:moss_block
setblock 54 149 335 minecraft:mossy_cobblestone
fill 54 149 336 54 149 338 minecraft:moss_block
setblock 54 149 339 minecraft:mossy_cobblestone
fill 54 149 340 54 149 342 minecraft:moss_block
setblock 54 149 343 minecraft:mossy_cobblestone
fill 54 149 344 54 149 346 minecraft:moss_block
setblock 54 149 347 minecraft:mossy_cobblestone
fill 54 149 348 54 149 350 minecraft:moss_block
setblock 54 149 351 minecraft:mossy_cobblestone
fill 54 149 352 54 149 354 minecraft:moss_block
setblock 54 149 355 minecraft:mossy_cobblestone
fill 54 149 356 56 149 356 minecraft:moss_block
setblock 54 149 359 minecraft:mossy_cobblestone
fill 54 149 360 56 149 360 minecraft:moss_block
setblock 54 149 363 minecraft:mossy_cobblestone
fill 55 149 323 55 149 325 minecraft:moss_block
setblock 55 149 326 minecraft:mossy_cobblestone
fill 55 149 327 55 149 329 minecraft:moss_block
setblock 55 149 330 minecraft:mossy_cobblestone
fill 55 149 331 55 149 333 minecraft:moss_block
setblock 55 149 334 minecraft:mossy_cobblestone
fill 55 149 335 55 149 337 minecraft:moss_block
setblock 55 149 338 minecraft:mossy_cobblestone
fill 55 149 339 55 149 341 minecraft:moss_block
setblock 55 149 342 minecraft:mossy_cobblestone
fill 55 149 343 55 149 345 minecraft:moss_block
setblock 55 149 346 minecraft:mossy_cobblestone
fill 55 149 347 55 149 349 minecraft:moss_block
setblock 55 149 350 minecraft:mossy_cobblestone
fill 55 149 351 55 149 353 minecraft:moss_block
setblock 55 149 354 minecraft:mossy_cobblestone
fill 55 149 355 57 149 355 minecraft:moss_block
setblock 55 149 358 minecraft:mossy_cobblestone
fill 55 149 359 57 149 359 minecraft:moss_block
setblock 55 149 362 minecraft:mossy_cobblestone
fill 55 149 363 57 149 363 minecraft:moss_block
fill 56 149 323 56 149 324 minecraft:moss_block
setblock 56 149 325 minecraft:mossy_cobblestone
fill 56 149 326 56 149 328 minecraft:moss_block
setblock 56 149 329 minecraft:mossy_cobblestone
fill 56 149 330 56 149 332 minecraft:moss_block
setblock 56 149 333 minecraft:mossy_cobblestone
fill 56 149 334 56 149 336 minecraft:moss_block
setblock 56 149 337 minecraft:mossy_cobblestone
fill 56 149 338 56 149 340 minecraft:moss_block
setblock 56 149 341 minecraft:mossy_cobblestone
fill 56 149 342 56 149 344 minecraft:moss_block
setblock 56 149 345 minecraft:mossy_cobblestone
fill 56 149 346 56 149 348 minecraft:moss_block
setblock 56 149 349 minecraft:mossy_cobblestone
fill 56 149 350 56 149 352 minecraft:moss_block
setblock 56 149 353 minecraft:mossy_cobblestone
fill 56 149 354 58 149 354 minecraft:moss_block
setblock 56 149 357 minecraft:mossy_cobblestone
fill 56 149 358 58 149 358 minecraft:moss_block
setblock 56 149 361 minecraft:mossy_cobblestone
fill 56 149 362 58 149 362 minecraft:moss_block
setblock 57 149 323 minecraft:moss_block
setblock 57 149 324 minecraft:mossy_cobblestone
fill 57 149 325 57 149 327 minecraft:moss_block
setblock 57 149 328 minecraft:mossy_cobblestone
fill 57 149 329 57 149 331 minecraft:moss_block
setblock 57 149 332 minecraft:mossy_cobblestone
fill 57 149 333 57 149 335 minecraft:moss_block
setblock 57 149 336 minecraft:mossy_cobblestone
fill 57 149 337 57 149 339 minecraft:moss_block
setblock 57 149 340 minecraft:mossy_cobblestone
setblock 57 149 341 minecraft:moss_block
setblock 57 149 342 minecraft:smooth_sandstone
setblock 57 149 343 minecraft:moss_block
setblock 57 149 344 minecraft:mossy_cobblestone
fill 57 149 345 57 149 347 minecraft:moss_block
setblock 57 149 348 minecraft:mossy_cobblestone
fill 57 149 349 57 149 351 minecraft:moss_block
setblock 57 149 352 minecraft:mossy_cobblestone
fill 57 149 353 59 149 353 minecraft:moss_block
setblock 57 149 356 minecraft:mossy_cobblestone
fill 57 149 357 59 149 357 minecraft:moss_block
setblock 57 149 360 minecraft:mossy_cobblestone
fill 57 149 361 59 149 361 minecraft:moss_block
setblock 58 149 323 minecraft:mossy_cobblestone
fill 58 149 324 58 149 326 minecraft:moss_block
setblock 58 149 327 minecraft:mossy_cobblestone
fill 58 149 328 58 149 330 minecraft:moss_block
setblock 58 149 331 minecraft:mossy_cobblestone
fill 58 149 332 58 149 334 minecraft:moss_block
setblock 58 149 335 minecraft:mossy_cobblestone
fill 58 149 336 58 149 337 minecraft:moss_block
fill 58 149 338 58 149 339 minecraft:smooth_sandstone
fill 58 149 340 58 149 344 minecraft:white_concrete
fill 58 149 345 58 149 346 minecraft:smooth_sandstone
setblock 58 149 347 minecraft:mossy_cobblestone
fill 58 149 348 58 149 350 minecraft:moss_block
setblock 58 149 351 minecraft:mossy_cobblestone
fill 58 149 352 60 149 352 minecraft:moss_block
setblock 58 149 355 minecraft:mossy_cobblestone
fill 58 149 356 60 149 356 minecraft:moss_block
setblock 58 149 359 minecraft:mossy_cobblestone
fill 58 149 360 60 149 360 minecraft:moss_block
setblock 58 149 363 minecraft:mossy_cobblestone
fill 59 149 323 59 149 325 minecraft:moss_block
setblock 59 149 326 minecraft:mossy_cobblestone
fill 59 149 327 59 149 329 minecraft:moss_block
setblock 59 149 330 minecraft:mossy_cobblestone
fill 59 149 331 59 149 333 minecraft:moss_block
setblock 59 149 334 minecraft:mossy_cobblestone
setblock 59 149 335 minecraft:moss_block
fill 59 149 336 59 149 337 minecraft:smooth_sandstone
setblock 59 149 338 minecraft:white_concrete
fill 59 149 339 59 149 345 minecraft:smooth_sandstone
setblock 59 149 346 minecraft:white_concrete
fill 59 149 347 59 149 348 minecraft:smooth_sandstone
setblock 59 149 349 minecraft:moss_block
setblock 59 149 350 minecraft:mossy_cobblestone
fill 59 149 351 61 149 351 minecraft:moss_block
setblock 59 149 354 minecraft:mossy_cobblestone
fill 59 149 355 61 149 355 minecraft:moss_block
setblock 59 149 358 minecraft:mossy_cobblestone
fill 59 149 359 61 149 359 minecraft:moss_block
setblock 59 149 362 minecraft:mossy_cobblestone
fill 59 149 363 61 149 363 minecraft:moss_block
setblock 60 149 322 minecraft:red_concrete
fill 60 149 323 60 149 324 minecraft:moss_block
setblock 60 149 325 minecraft:mossy_cobblestone
fill 60 149 326 60 149 328 minecraft:moss_block
setblock 60 149 329 minecraft:mossy_cobblestone
fill 60 149 330 60 149 332 minecraft:moss_block
setblock 60 149 333 minecraft:mossy_cobblestone
setblock 60 149 334 minecraft:moss_block
setblock 60 149 335 minecraft:smooth_sandstone
setblock 60 149 336 minecraft:white_concrete
fill 60 149 337 60 149 340 minecraft:smooth_sandstone
fill 60 149 341 60 149 343 minecraft:white_concrete
fill 60 149 344 60 149 347 minecraft:smooth_sandstone
setblock 60 149 348 minecraft:white_concrete
setblock 60 149 349 minecraft:smooth_sandstone
setblock 60 149 350 minecraft:moss_block
setblock 60 149 353 minecraft:mossy_cobblestone
fill 60 149 354 62 149 354 minecraft:moss_block
setblock 60 149 357 minecraft:mossy_cobblestone
fill 60 149 358 62 149 358 minecraft:moss_block
setblock 60 149 361 minecraft:mossy_cobblestone
fill 60 149 362 62 149 362 minecraft:moss_block
fill 61 149 322 68 204 322 minecraft:spruce_planks
setblock 61 149 323 minecraft:moss_block
setblock 61 149 324 minecraft:mossy_cobblestone
fill 61 149 325 61 149 327 minecraft:moss_block
setblock 61 149 328 minecraft:mossy_cobblestone
fill 61 149 329 61 149 331 minecraft:moss_block
setblock 61 149 332 minecraft:mossy_cobblestone
setblock 61 149 333 minecraft:moss_block
setblock 61 149 334 minecraft:smooth_sandstone
setblock 61 149 335 minecraft:white_concrete
fill 61 149 336 61 149 337 minecraft:smooth_sandstone
setblock 61 149 338 minecraft:white_concrete
fill 61 149 339 61 149 343 minecraft:smooth_sandstone
fill 61 149 344 62 150 345 minecraft:stone
setblock 61 149 346 minecraft:white_concrete
fill 61 149 347 61 149 348 minecraft:smooth_sandstone
setblock 61 149 349 minecraft:white_concrete
setblock 61 149 350 minecraft:smooth_sandstone
setblock 61 149 352 minecraft:mossy_cobblestone
fill 61 149 353 63 149 353 minecraft:moss_block
setblock 61 149 356 minecraft:mossy_cobblestone
fill 61 149 357 63 149 357 minecraft:moss_block
setblock 61 149 360 minecraft:mossy_cobblestone
fill 61 149 361 63 149 361 minecraft:moss_block
setblock 62 149 323 minecraft:mossy_cobblestone
fill 62 149 324 62 149 326 minecraft:moss_block
setblock 62 149 327 minecraft:mossy_cobblestone
fill 62 149 328 62 149 330 minecraft:moss_block
setblock 62 149 331 minecraft:mossy_cobblestone
fill 62 149 332 63 149 332 minecraft:moss_block
fill 62 149 333 63 149 333 minecraft:smooth_sandstone
setblock 62 149 334 minecraft:white_concrete
fill 62 149 335 62 149 336 minecraft:smooth_sandstone
setblock 62 149 337 minecraft:white_concrete
fill 62 149 338 62 149 340 minecraft:smooth_sandstone
fill 62 149 341 62 149 343 minecraft:white_concrete
fill 62 149 346 66 149 346 minecraft:smooth_sandstone
setblock 62 149 347 minecraft:white_concrete
fill 62 149 348 62 149 349 minecraft:smooth_sandstone
setblock 62 149 350 minecraft:white_concrete
fill 62 149 351 63 149 351 minecraft:smooth_sandstone
fill 62 149 352 63 149 352 minecraft:moss_block
setblock 62 149 355 minecraft:mossy_cobblestone
fill 62 149 356 64 149 356 minecraft:moss_block
setblock 62 149 359 minecraft:mossy_cobblestone
fill 62 149 360 64 149 360 minecraft:moss_block
setblock 62 149 363 minecraft:mossy_cobblestone
fill 63 149 323 63 149 325 minecraft:moss_block
setblock 63 149 326 minecraft:mossy_cobblestone
fill 63 149 327 63 149 329 minecraft:moss_block
setblock 63 149 330 minecraft:mossy_cobblestone
fill 63 149 331 65 149 331 minecraft:moss_block
fill 63 149 334 63 149 335 minecraft:smooth_sandstone
setblock 63 149 336 minecraft:white_concrete
fill 63 149 337 64 149 338 minecraft:smooth_sandstone
setblock 63 149 339 minecraft:white_concrete
fill 63 149 340 63 149 344 minecraft:smooth_sandstone
setblock 63 149 345 minecraft:white_concrete
fill 63 149 347 64 149 347 minecraft:smooth_sandstone
setblock 63 149 348 minecraft:white_concrete
fill 63 149 349 63 149 350 minecraft:smooth_sandstone
setblock 63 149 354 minecraft:mossy_cobblestone
fill 63 149 355 65 149 355 minecraft:moss_block
setblock 63 149 358 minecraft:mossy_cobblestone
fill 63 149 359 65 149 359 minecraft:moss_block
setblock 63 149 362 minecraft:mossy_cobblestone
fill 63 149 363 65 149 363 minecraft:moss_block
fill 64 149 323 64 149 324 minecraft:moss_block
setblock 64 149 325 minecraft:mossy_cobblestone
fill 64 149 326 64 149 328 minecraft:moss_block
setblock 64 149 329 minecraft:mossy_cobblestone
fill 64 149 330 66 149 330 minecraft:moss_block
fill 64 149 332 65 149 332 minecraft:smooth_sandstone
setblock 64 149 333 minecraft:white_concrete
fill 64 149 334 66 149 334 minecraft:smooth_sandstone
setblock 64 149 335 minecraft:white_concrete
fill 64 149 336 66 149 336 minecraft:smooth_sandstone
fill 64 149 339 64 149 340 minecraft:smooth_sandstone
fill 64 149 341 64 149 343 minecraft:white_concrete
fill 64 149 344 64 149 345 minecraft:smooth_sandstone
fill 64 149 348 66 149 348 minecraft:smooth_sandstone
setblock 64 149 349 minecraft:white_concrete
fill 64 149 350 66 149 350 minecraft:smooth_sandstone
setblock 64 149 351 minecraft:white_concrete
fill 64 149 352 65 149 352 minecraft:smooth_sandstone
setblock 64 149 353 minecraft:mossy_cobblestone
fill 64 149 354 66 149 354 minecraft:moss_block
setblock 64 149 357 minecraft:mossy_cobblestone
fill 64 149 358 66 149 358 minecraft:moss_block
setblock 64 149 361 minecraft:mossy_cobblestone
fill 64 149 362 66 149 362 minecraft:moss_block
setblock 65 149 323 minecraft:moss_block
setblock 65 149 324 minecraft:mossy_cobblestone
fill 65 149 325 65 149 327 minecraft:moss_block
setblock 65 149 328 minecraft:mossy_cobblestone
fill 65 149 329 67 149 329 minecraft:moss_block
fill 65 149 333 71 149 333 minecraft:smooth_sandstone
fill 65 149 335 67 149 335 minecraft:smooth_sandstone
setblock 65 149 337 minecraft:white_concrete
fill 65 149 338 65 149 339 minecraft:smooth_sandstone
fill 65 149 340 65 149 344 minecraft:red_concrete
setblock 65 149 345 minecraft:smooth_sandstone
setblock 65 149 347 minecraft:white_concrete
fill 65 149 349 71 149 349 minecraft:smooth_sandstone
fill 65 149 351 71 149 351 minecraft:smooth_sandstone
fill 65 149 353 67 149 353 minecraft:moss_block
setblock 65 149 356 minecraft:mossy_cobblestone
fill 65 149 357 67 149 357 minecraft:moss_block
setblock 65 149 360 minecraft:mossy_cobblestone
fill 65 149 361 67 149 361 minecraft:moss_block
setblock 66 149 323 minecraft:mossy_cobblestone
fill 66 149 324 66 149 326 minecraft:moss_block
setblock 66 149 327 minecraft:mossy_cobblestone
fill 66 149 328 68 149 328 minecraft:moss_block
setblock 66 149 331 minecraft:mossy_cobblestone
fill 66 149 332 70 149 332 minecraft:white_concrete
fill 66 149 337 66 149 338 minecraft:smooth_sandstone
fill 66 149 339 66 149 340 minecraft:red_concrete
fill 66 149 344 66 149 345 minecraft:red_concrete
fill 66 149 347 70 149 347 minecraft:smooth_sandstone
fill 66 149 352 70 149 352 minecraft:white_concrete
setblock 66 149 355 minecraft:mossy_cobblestone
fill 66 149 356 68 149 356 minecraft:moss_block
setblock 66 149 359 minecraft:mossy_cobblestone
fill 66 149 360 68 149 360 minecraft:moss_block
setblock 66 149 363 minecraft:mossy_cobblestone
fill 67 149 323 67 149 325 minecraft:moss_block
setblock 67 149 326 minecraft:mossy_cobblestone
fill 67 149 327 69 149 327 minecraft:moss_block
setblock 67 149 330 minecraft:mossy_cobblestone
setblock 67 149 331 minecraft:moss_block
fill 67 149 334 68 149 334 minecraft:white_concrete
fill 67 149 336 68 149 336 minecraft:white_concrete
fill 67 149 337 70 149 337 minecraft:smooth_sandstone
fill 67 149 338 69 149 338 minecraft:white_concrete
fill 67 149 339 70 149 339 minecraft:red_concrete
fill 67 149 345 70 149 345 minecraft:red_concrete
fill 67 149 346 69 149 346 minecraft:white_concrete
fill 67 149 348 69 149 348 minecraft:white_concrete
fill 67 149 350 69 149 350 minecraft:white_concrete
setblock 67 149 354 minecraft:mossy_cobblestone
fill 67 149 355 69 149 355 minecraft:moss_block
setblock 67 149 358 minecraft:mossy_cobblestone
fill 67 149 359 69 149 359 minecraft:moss_block
setblock 67 149 362 minecraft:mossy_cobblestone
fill 67 149 363 69 149 363 minecraft:moss_block
fill 68 149 323 68 149 324 minecraft:moss_block
setblock 68 149 325 minecraft:mossy_cobblestone
fill 68 149 326 70 149 326 minecraft:moss_block
setblock 68 149 329 minecraft:mossy_cobblestone
fill 68 149 330 70 149 330 minecraft:moss_block
fill 68 149 335 70 149 335 minecraft:stone
fill 68 149 354 70 149 354 minecraft:moss_block
setblock 68 149 357 minecraft:mossy_cobblestone
fill 68 149 358 70 149 358 minecraft:moss_block
setblock 68 149 361 minecraft:mossy_cobblestone
fill 68 149 362 70 149 362 minecraft:moss_block
setblock 69 149 323 minecraft:moss_block
setblock 69 149 324 minecraft:mossy_cobblestone
fill 69 149 325 71 149 325 minecraft:moss_block
setblock 69 149 328 minecraft:mossy_cobblestone
fill 69 149 329 71 149 329 minecraft:moss_block
setblock 69 149 331 minecraft:moss_block
setblock 69 149 334 minecraft:stone
fill 69 149 336 70 150 336 minecraft:stone
fill 69 149 353 71 149 353 minecraft:moss_block
setblock 69 149 356 minecraft:mossy_cobblestone
fill 69 149 357 71 149 357 minecraft:moss_block
setblock 69 149 360 minecraft:mossy_cobblestone
fill 69 149 361 71 149 361 minecraft:moss_block
setblock 70 149 323 minecraft:mossy_cobblestone
fill 70 149 324 72 149 324 minecraft:moss_block
setblock 70 149 327 minecraft:mossy_cobblestone
fill 70 149 328 72 149 328 minecraft:moss_block
setblock 70 149 331 minecraft:mossy_cobblestone
fill 70 149 334 73 149 334 minecraft:smooth_sandstone
fill 70 149 338 74 149 338 minecraft:smooth_sandstone
fill 70 149 340 71 149 340 minecraft:red_concrete
fill 70 149 344 71 149 344 minecraft:red_concrete
fill 70 149 346 72 149 346 minecraft:smooth_sandstone
fill 70 149 348 72 149 348 minecraft:smooth_sandstone
fill 70 149 350 73 149 350 minecraft:smooth_sandstone
setblock 70 149 355 minecraft:mossy_cobblestone
fill 70 149 356 72 149 356 minecraft:moss_block
setblock 70 149 359 minecraft:mossy_cobblestone
fill 70 149 360 72 149 360 minecraft:moss_block
setblock 70 149 363 minecraft:mossy_cobblestone
fill 71 149 323 73 149 323 minecraft:moss_block
setblock 71 149 326 minecraft:mossy_cobblestone
fill 71 149 327 73 149 327 minecraft:moss_block
setblock 71 149 330 minecraft:mossy_cobblestone
fill 71 149 331 73 149 331 minecraft:moss_block
fill 71 149 332 72 149 332 minecraft:smooth_sandstone
fill 71 149 335 71 149 336 minecraft:smooth_sandstone
setblock 71 149 337 minecraft:white_concrete
fill 71 149 339 72 149 339 minecraft:smooth_sandstone
fill 71 149 341 71 149 343 minecraft:red_concrete
fill 71 149 345 72 149 345 minecraft:smooth_sandstone
setblock 71 149 347 minecraft:white_concrete
fill 71 149 352 72 149 352 minecraft:smooth_sandstone
setblock 71 149 354 minecraft:mossy_cobblestone
fill 71 149 355 73 149 355 minecraft:moss_block
setblock 71 149 358 minecraft:mossy_cobblestone
fill 71 149 359 73 149 359 minecraft:moss_block
setblock 71 149 362 minecraft:mossy_cobblestone
fill 71 149 363 73 149 363 minecraft:moss_block
setblock 72 149 325 minecraft:mossy_cobblestone
fill 72 149 326 74 149 326 minecraft:moss_block
setblock 72 149 329 minecraft:mossy_cobblestone
fill 72 149 330 74 149 330 minecraft:moss_block
setblock 72 149 333 minecraft:white_concrete
setblock 72 149 335 minecraft:white_concrete
fill 72 149 336 72 149 337 minecraft:smooth_sandstone
fill 72 149 340 77 149 340 minecraft:smooth_sandstone
fill 72 149 341 72 149 343 minecraft:white_concrete
fill 72 149 344 77 149 344 minecraft:smooth_sandstone
setblock 72 149 347 minecraft:smooth_sandstone
setblock 72 149 349 minecraft:white_concrete
setblock 72 149 351 minecraft:white_concrete
setblock 72 149 353 minecraft:mossy_cobblestone
fill 72 149 354 74 149 354 minecraft:moss_block
setblock 72 149 357 minecraft:mossy_cobblestone
fill 72 149 358 74 149 358 minecraft:moss_block
setblock 72 149 361 minecraft:mossy_cobblestone
fill 72 149 362 74 149 362 minecraft:moss_block
setblock 73 149 324 minecraft:mossy_cobblestone
fill 73 149 325 75 149 325 minecraft:moss_block
setblock 73 149 328 minecraft:mossy_cobblestone
fill 73 149 329 75 149 329 minecraft:moss_block
setblock 73 149 332 minecraft:mossy_cobblestone
fill 73 149 333 74 149 333 minecraft:smooth_sandstone
fill 73 149 335 74 149 335 minecraft:smooth_sandstone
setblock 73 149 336 minecraft:white_concrete
setblock 73 149 337 minecraft:smooth_sandstone
setblock 73 149 339 minecraft:white_concrete
fill 73 149 341 73 149 343 minecraft:smooth_sandstone
setblock 73 149 345 minecraft:white_concrete
fill 73 149 346 74 150 347 minecraft:stone
setblock 73 149 348 minecraft:white_concrete
fill 73 149 349 74 149 349 minecraft:smooth_sandstone
fill 73 149 351 74 149 351 minecraft:smooth_sandstone
setblock 73 149 352 minecraft:mossy_cobblestone
fill 73 149 353 75 149 353 minecraft:moss_block
setblock 73 149 356 minecraft:mossy_cobblestone
fill 73 149 357 75 149 357 minecraft:moss_block
setblock 73 149 360 minecraft:mossy_cobblestone
fill 73 149 361 75 149 361 minecraft:moss_block
setblock 74 149 323 minecraft:mossy_cobblestone
fill 74 149 324 76 149 324 minecraft:moss_block
setblock 74 149 327 minecraft:mossy_cobblestone
fill 74 149 328 76 149 328 minecraft:moss_block
setblock 74 149 331 minecraft:mossy_cobblestone
fill 74 149 332 76 149 332 minecraft:moss_block
setblock 74 149 334 minecraft:white_concrete
fill 74 149 336 75 149 336 minecraft:smooth_sandstone
setblock 74 149 337 minecraft:white_concrete
fill 74 149 339 78 149 339 minecraft:smooth_sandstone
fill 74 149 341 74 149 343 minecraft:white_concrete
fill 74 149 345 78 149 345 minecraft:smooth_sandstone
fill 74 149 348 75 149 348 minecraft:smooth_sandstone
setblock 74 149 350 minecraft:white_concrete
fill 74 149 352 76 149 352 minecraft:moss_block
setblock 74 149 355 minecraft:mossy_cobblestone
fill 74 149 356 76 149 356 minecraft:moss_block
setblock 74 149 359 minecraft:mossy_cobblestone
fill 74 149 360 76 149 360 minecraft:moss_block
setblock 74 149 363 minecraft:mossy_cobblestone
fill 75 149 323 77 149 323 minecraft:moss_block
setblock 75 149 326 minecraft:mossy_cobblestone
fill 75 149 327 77 149 327 minecraft:moss_block
setblock 75 149 330 minecraft:mossy_cobblestone
fill 75 149 331 77 149 331 minecraft:moss_block
setblock 75 149 333 minecraft:moss_block
setblock 75 149 334 minecraft:smooth_sandstone
setblock 75 149 335 minecraft:white_concrete
fill 75 149 337 77 149 337 minecraft:smooth_sandstone
setblock 75 149 338 minecraft:white_concrete
fill 75 149 341 75 149 343 minecraft:smooth_sandstone
setblock 75 149 346 minecraft:white_concrete
fill 75 149 347 77 149 347 minecraft:smooth_sandstone
setblock 75 149 349 minecraft:white_concrete
setblock 75 149 350 minecraft:smooth_sandstone
fill 75 149 351 77 149 351 minecraft:moss_block
setblock 75 149 354 minecraft:mossy_cobblestone
fill 75 149 355 77 149 355 minecraft:moss_block
setblock 75 149 358 minecraft:mossy_cobblestone
fill 75 149 359 77 149 359 minecraft:moss_block
setblock 75 149 362 minecraft:mossy_cobblestone
fill 75 149 363 77 149 363 minecraft:moss_block
setblock 76 149 325 minecraft:mossy_cobblestone
fill 76 149 326 78 149 326 minecraft:moss_block
setblock 76 149 329 minecraft:mossy_cobblestone
fill 76 149 330 78 149 330 minecraft:moss_block
setblock 76 149 333 minecraft:mossy_cobblestone
fill 76 149 334 78 149 334 minecraft:moss_block
setblock 76 149 335 minecraft:smooth_sandstone
setblock 76 149 336 minecraft:white_concrete
setblock 76 149 338 minecraft:smooth_sandstone
fill 76 149 341 76 149 343 minecraft:white_concrete
setblock 76 149 346 minecraft:smooth_sandstone
setblock 76 149 348 minecraft:white_concrete
setblock 76 149 349 minecraft:smooth_sandstone
fill 76 149 350 78 149 350 minecraft:moss_block
setblock 76 149 353 minecraft:mossy_cobblestone
fill 76 149 354 78 149 354 minecraft:moss_block
setblock 76 149 357 minecraft:mossy_cobblestone
fill 76 149 358 78 149 358 minecraft:moss_block
setblock 76 149 361 minecraft:mossy_cobblestone
fill 76 149 362 78 149 362 minecraft:moss_block
setblock 77 149 324 minecraft:mossy_cobblestone
fill 77 149 325 79 149 325 minecraft:moss_block
setblock 77 149 328 minecraft:mossy_cobblestone
fill 77 149 329 79 149 329 minecraft:moss_block
setblock 77 149 332 minecraft:mossy_cobblestone
fill 77 149 333 79 149 333 minecraft:moss_block
setblock 77 149 335 minecraft:moss_block
setblock 77 149 336 minecraft:smooth_sandstone
setblock 77 149 338 minecraft:white_concrete
fill 77 149 341 77 149 343 minecraft:smooth_sandstone
setblock 77 149 346 minecraft:white_concrete
setblock 77 149 348 minecraft:smooth_sandstone
fill 77 149 349 79 149 349 minecraft:moss_block
setblock 77 149 352 minecraft:mossy_cobblestone
fill 77 149 353 79 149 353 minecraft:moss_block
setblock 77 149 356 minecraft:mossy_cobblestone
fill 77 149 357 79 149 357 minecraft:moss_block
setblock 77 149 360 minecraft:mossy_cobblestone
fill 77 149 361 79 149 361 minecraft:moss_block
setblock 78 149 323 minecraft:mossy_cobblestone
fill 78 149 324 80 149 324 minecraft:moss_block
setblock 78 149 327 minecraft:mossy_cobblestone
fill 78 149 328 80 149 328 minecraft:moss_block
setblock 78 149 331 minecraft:mossy_cobblestone
fill 78 149 332 80 149 332 minecraft:moss_block
setblock 78 149 335 minecraft:mossy_cobblestone
fill 78 149 336 79 149 337 minecraft:moss_block
setblock 78 149 338 minecraft:smooth_sandstone
fill 78 149 340 78 149 344 minecraft:white_concrete
setblock 78 149 346 minecraft:smooth_sandstone
setblock 78 149 347 minecraft:mossy_cobblestone
fill 78 149 348 80 149 348 minecraft:moss_block
setblock 78 149 351 minecraft:mossy_cobblestone
fill 78 149 352 80 149 352 minecraft:moss_block
setblock 78 149 355 minecraft:mossy_cobblestone
fill 78 149 356 80 149 356 minecraft:moss_block
setblock 78 149 359 minecraft:mossy_cobblestone
fill 78 149 360 80 149 360 minecraft:moss_block
setblock 78 149 363 minecraft:mossy_cobblestone
fill 79 149 323 81 149 323 minecraft:moss_block
setblock 79 149 326 minecraft:mossy_cobblestone
fill 79 149 327 81 149 327 minecraft:moss_block
setblock 79 149 330 minecraft:mossy_cobblestone
fill 79 149 331 81 149 331 minecraft:moss_block
setblock 79 149 334 minecraft:mossy_cobblestone
fill 79 149 335 81 149 335 minecraft:moss_block
setblock 79 149 338 minecraft:mossy_cobblestone
fill 79 149 339 79 149 341 minecraft:moss_block
fill 79 149 343 79 149 345 minecraft:moss_block
setblock 79 149 346 minecraft:mossy_cobblestone
fill 79 149 347 81 149 347 minecraft:moss_block
setblock 79 149 350 minecraft:mossy_cobblestone
fill 79 149 351 81 149 351 minecraft:moss_block
setblock 79 149 354 minecraft:mossy_cobblestone
fill 79 149 355 81 149 355 minecraft:moss_block
setblock 79 149 358 minecraft:mossy_cobblestone
fill 79 149 359 81 149 359 minecraft:moss_block
setblock 79 149 362 minecraft:mossy_cobblestone
fill 79 149 363 81 149 363 minecraft:moss_block
setblock 80 149 325 minecraft:mossy_cobblestone
fill 80 149 326 82 149 326 minecraft:moss_block
setblock 80 149 329 minecraft:mossy_cobblestone
fill 80 149 330 82 149 330 minecraft:moss_block
setblock 80 149 333 minecraft:mossy_cobblestone
fill 80 149 334 82 149 334 minecraft:moss_block
setblock 80 149 336 minecraft:moss_block
setblock 80 149 337 minecraft:mossy_cobblestone
fill 80 149 338 80 149 340 minecraft:moss_block
setblock 80 149 341 minecraft:mossy_cobblestone
fill 80 149 342 80 149 344 minecraft:moss_block
setblock 80 149 345 minecraft:mossy_cobblestone
fill 80 149 346 82 149 346 minecraft:moss_block
setblock 80 149 349 minecraft:mossy_cobblestone
fill 80 149 350 82 149 350 minecraft:moss_block
setblock 80 149 353 minecraft:mossy_cobblestone
fill 80 149 354 82 149 354 minecraft:moss_block
setblock 80 149 357 minecraft:mossy_cobblestone
fill 80 149 358 82 149 358 minecraft:moss_block
setblock 80 149 361 minecraft:mossy_cobblestone
fill 80 149 362 82 149 362 minecraft:moss_block
setblock 81 149 324 minecraft:mossy_cobblestone
fill 81 149 325 83 149 325 minecraft:moss_block
setblock 81 149 328 minecraft:mossy_cobblestone
fill 81 149 329 83 149 329 minecraft:moss_block
setblock 81 149 332 minecraft:mossy_cobblestone
fill 81 149 333 83 149 333 minecraft:moss_block
setblock 81 149 336 minecraft:mossy_cobblestone
fill 81 149 337 81 149 339 minecraft:moss_block
setblock 81 149 340 minecraft:mossy_cobblestone
fill 81 149 341 81 149 343 minecraft:moss_block
setblock 81 149 344 minecraft:mossy_cobblestone
fill 81 149 345 83 149 345 minecraft:moss_block
setblock 81 149 348 minecraft:mossy_cobblestone
fill 81 149 349 83 149 349 minecraft:moss_block
setblock 81 149 352 minecraft:mossy_cobblestone
fill 81 149 353 83 149 353 minecraft:moss_block
setblock 81 149 356 minecraft:mossy_cobblestone
fill 81 149 357 83 149 357 minecraft:moss_block
setblock 81 149 360 minecraft:mossy_cobblestone
fill 81 149 361 83 149 361 minecraft:moss_block
setblock 82 149 323 minecraft:mossy_cobblestone
fill 82 149 324 84 149 324 minecraft:moss_block
setblock 82 149 327 minecraft:mossy_cobblestone
fill 82 149 328 84 149 328 minecraft:moss_block
setblock 82 149 331 minecraft:mossy_cobblestone
fill 82 149 332 84 149 332 minecraft:moss_block
setblock 82 149 335 minecraft:mossy_cobblestone
fill 82 149 336 82 149 338 minecraft:moss_block
setblock 82 149 339 minecraft:mossy_cobblestone
fill 82 149 340 82 149 342 minecraft:moss_block
setblock 82 149 343 minecraft:mossy_cobblestone
fill 82 149 344 84 149 344 minecraft:moss_block
setblock 82 149 347 minecraft:mossy_cobblestone
fill 82 149 348 84 149 348 minecraft:moss_block
setblock 82 149 351 minecraft:mossy_cobblestone
fill 82 149 352 84 149 352 minecraft:moss_block
setblock 82 149 355 minecraft:mossy_cobblestone
fill 82 149 356 84 149 356 minecraft:moss_block
setblock 82 149 359 minecraft:mossy_cobblestone
fill 82 149 360 84 149 360 minecraft:moss_block
setblock 82 149 363 minecraft:mossy_cobblestone
fill 83 149 323 85 149 323 minecraft:moss_block
setblock 83 149 326 minecraft:mossy_cobblestone
fill 83 149 327 85 149 327 minecraft:moss_block
setblock 83 149 330 minecraft:mossy_cobblestone
fill 83 149 331 85 149 331 minecraft:moss_block
setblock 83 149 334 minecraft:mossy_cobblestone
fill 83 149 335 83 149 337 minecraft:moss_block
setblock 83 149 338 minecraft:mossy_cobblestone
fill 83 149 339 83 149 341 minecraft:moss_block
setblock 83 149 342 minecraft:mossy_cobblestone
fill 83 149 343 85 149 343 minecraft:moss_block
setblock 83 149 346 minecraft:mossy_cobblestone
fill 83 149 347 85 149 347 minecraft:moss_block
setblock 83 149 350 minecraft:mossy_cobblestone
fill 83 149 351 85 149 351 minecraft:moss_block
setblock 83 149 354 minecraft:mossy_cobblestone
fill 83 149 355 85 149 355 minecraft:moss_block
setblock 83 149 358 minecraft:mossy_cobblestone
fill 83 149 359 85 149 359 minecraft:moss_block
setblock 83 149 362 minecraft:mossy_cobblestone
fill 83 149 363 85 149 363 minecraft:moss_block
setblock 84 149 325 minecraft:mossy_cobblestone
fill 84 149 326 86 149 326 minecraft:moss_block
setblock 84 149 329 minecraft:mossy_cobblestone
fill 84 149 330 86 149 330 minecraft:moss_block
setblock 84 149 333 minecraft:mossy_cobblestone
fill 84 149 334 84 149 336 minecraft:moss_block
setblock 84 149 337 minecraft:mossy_cobblestone
fill 84 149 338 84 149 340 minecraft:moss_block
setblock 84 149 341 minecraft:mossy_cobblestone
fill 84 149 342 86 149 342 minecraft:moss_block
setblock 84 149 345 minecraft:mossy_cobblestone
fill 84 149 346 86 149 346 minecraft:moss_block
setblock 84 149 349 minecraft:mossy_cobblestone
fill 84 149 350 86 149 350 minecraft:moss_block
setblock 84 149 353 minecraft:mossy_cobblestone
fill 84 149 354 86 149 354 minecraft:moss_block
setblock 84 149 357 minecraft:mossy_cobblestone
fill 84 149 358 86 149 358 minecraft:moss_block
setblock 84 149 361 minecraft:mossy_cobblestone
fill 84 149 362 86 149 362 minecraft:moss_block
setblock 85 149 324 minecraft:mossy_cobblestone
fill 85 149 325 87 149 325 minecraft:moss_block
setblock 85 149 328 minecraft:mossy_cobblestone
fill 85 149 329 87 149 329 minecraft:moss_block
setblock 85 149 332 minecraft:mossy_cobblestone
fill 85 149 333 85 149 335 minecraft:moss_block
setblock 85 149 336 minecraft:mossy_cobblestone
fill 85 149 337 85 149 339 minecraft:moss_block
setblock 85 149 340 minecraft:mossy_cobblestone
fill 85 149 341 87 149 341 minecraft:moss_block
setblock 85 149 344 minecraft:mossy_cobblestone
fill 85 149 345 87 149 345 minecraft:moss_block
setblock 85 149 348 minecraft:mossy_cobblestone
fill 85 149 349 87 149 349 minecraft:moss_block
setblock 85 149 352 minecraft:mossy_cobblestone
fill 85 149 353 87 149 353 minecraft:moss_block
setblock 85 149 356 minecraft:mossy_cobblestone
fill 85 149 357 87 149 357 minecraft:moss_block
setblock 85 149 360 minecraft:mossy_cobblestone
fill 85 149 361 87 149 361 minecraft:moss_block
setblock 86 149 323 minecraft:mossy_cobblestone
fill 86 149 324 88 149 324 minecraft:moss_block
setblock 86 149 327 minecraft:mossy_cobblestone
fill 86 149 328 88 149 328 minecraft:moss_block
setblock 86 149 331 minecraft:mossy_cobblestone
fill 86 149 332 86 149 334 minecraft:moss_block
setblock 86 149 335 minecraft:mossy_cobblestone
fill 86 149 336 86 149 338 minecraft:moss_block
setblock 86 149 339 minecraft:mossy_cobblestone
fill 86 149 340 88 149 340 minecraft:moss_block
setblock 86 149 343 minecraft:mossy_cobblestone
fill 86 149 344 88 149 344 minecraft:moss_block
setblock 86 149 347 minecraft:mossy_cobblestone
fill 86 149 348 88 149 348 minecraft:moss_block
setblock 86 149 351 minecraft:mossy_cobblestone
fill 86 149 352 88 149 352 minecraft:moss_block
setblock 86 149 355 minecraft:mossy_cobblestone
fill 86 149 356 88 149 356 minecraft:moss_block
setblock 86 149 359 minecraft:mossy_cobblestone
fill 86 149 360 88 149 360 minecraft:moss_block
setblock 86 149 363 minecraft:mossy_cobblestone
fill 87 149 323 88 149 323 minecraft:moss_block
setblock 87 149 326 minecraft:mossy_cobblestone
fill 87 149 327 88 149 327 minecraft:moss_block
setblock 87 149 330 minecraft:mossy_cobblestone
fill 87 149 331 87 149 333 minecraft:moss_block
setblock 87 149 334 minecraft:mossy_cobblestone
fill 87 149 335 87 149 337 minecraft:moss_block
setblock 87 149 338 minecraft:mossy_cobblestone
fill 87 149 339 88 149 339 minecraft:moss_block
setblock 87 149 342 minecraft:mossy_cobblestone
fill 87 149 343 88 149 343 minecraft:moss_block
setblock 87 149 346 minecraft:mossy_cobblestone
fill 87 149 347 88 149 347 minecraft:moss_block
setblock 87 149 350 minecraft:mossy_cobblestone
fill 87 149 351 88 149 351 minecraft:moss_block
setblock 87 149 354 minecraft:mossy_cobblestone
fill 87 149 355 88 149 355 minecraft:moss_block
setblock 87 149 358 minecraft:mossy_cobblestone
fill 87 149 359 88 149 359 minecraft:moss_block
setblock 87 149 362 minecraft:mossy_cobblestone
fill 87 149 363 88 149 363 minecraft:moss_block
setblock 88 149 325 minecraft:mossy_cobblestone
setblock 88 149 326 minecraft:moss_block
setblock 88 149 329 minecraft:mossy_cobblestone
fill 88 149 330 88 149 332 minecraft:moss_block
setblock 88 149 333 minecraft:mossy_cobblestone
fill 88 149 334 88 149 336 minecraft:moss_block
setblock 88 149 337 minecraft:mossy_cobblestone
setblock 88 149 338 minecraft:moss_block
setblock 88 149 341 minecraft:mossy_cobblestone
setblock 88 149 342 minecraft:moss_block
setblock 88 149 345 minecraft:mossy_cobblestone
setblock 88 149 346 minecraft:moss_block
setblock 88 149 349 minecraft:mossy_cobblestone
setblock 88 149 350 minecraft:moss_block
setblock 88 149 353 minecraft:mossy_cobblestone
setblock 88 149 354 minecraft:moss_block
setblock 88 149 357 minecraft:mossy_cobblestone
setblock 88 149 358 minecraft:moss_block
setblock 88 149 361 minecraft:mossy_cobblestone
setblock 88 149 362 minecraft:moss_block
setblock 89 149 338 minecraft:red_concrete
fill 89 149 339 89 226 339 minecraft:spruce_planks
fill 60 150 322 60 165 322 minecraft:spruce_planks
fill 69 150 335 70 150 335 minecraft:stone
setblock 70 150 334 minecraft:stone
fill 72 150 346 72 150 347 minecraft:stone
fill 89 150 338 89 226 338 minecraft:spruce_planks
setblock 73 151 347 minecraft:stone
fill 47 152 350 47 224 350 minecraft:spruce_planks
setblock 47 152 351 minecraft:red_concrete
fill 47 152 352 47 188 354 minecraft:spruce_planks
setblock 50 152 325 minecraft:light[level=15]
setblock 50 152 333 minecraft:light[level=15]
setblock 50 152 341 minecraft:light[level=15]
setblock 50 152 349 minecraft:light[level=15]
setblock 50 152 357 minecraft:light[level=15]
setblock 58 152 325 minecraft:light[level=15]
setblock 58 152 333 minecraft:light[level=15]
setblock 58 152 341 minecraft:light[level=15]
setblock 58 152 349 minecraft:light[level=15]
setblock 58 152 357 minecraft:light[level=15]
setblock 66 152 325 minecraft:light[level=15]
setblock 66 152 333 minecraft:light[level=15]
setblock 66 152 341 minecraft:light[level=15]
setblock 66 152 349 minecraft:light[level=15]
setblock 66 152 357 minecraft:light[level=15]
setblock 74 152 325 minecraft:light[level=15]
setblock 74 152 333 minecraft:light[level=15]
setblock 74 152 341 minecraft:light[level=15]
setblock 74 152 349 minecraft:light[level=15]
setblock 74 152 357 minecraft:light[level=15]
setblock 82 152 325 minecraft:light[level=15]
setblock 82 152 333 minecraft:light[level=15]
setblock 82 152 341 minecraft:light[level=15]
setblock 82 152 349 minecraft:light[level=15]
setblock 82 152 357 minecraft:light[level=15]
fill 47 153 351 47 226 351 minecraft:spruce_planks
setblock 47 153 358 minecraft:red_concrete
fill 48 153 327 48 153 328 minecraft:stripped_dark_oak_log
fill 48 153 334 48 153 335 minecraft:stripped_dark_oak_log
fill 48 153 341 48 153 342 minecraft:stripped_dark_oak_log
fill 48 153 348 48 153 349 minecraft:stripped_dark_oak_log
fill 48 153 355 48 153 356 minecraft:stripped_dark_oak_log
fill 48 153 362 48 153 363 minecraft:stripped_dark_oak_log
fill 49 153 354 49 165 358 minecraft:red_wool
fill 50 153 323 51 153 323 minecraft:stripped_dark_oak_log
fill 53 153 333 53 156 333 minecraft:iron_bars
fill 54 153 363 55 153 363 minecraft:stripped_dark_oak_log
fill 57 153 323 68 166 323 minecraft:stripped_dark_oak_log
fill 58 153 324 68 166 331 minecraft:stripped_dark_oak_log
fill 61 153 363 62 153 363 minecraft:stripped_dark_oak_log
fill 68 153 363 69 153 363 minecraft:stripped_dark_oak_log
fill 71 153 323 72 153 323 minecraft:stripped_dark_oak_log
fill 75 153 363 76 153 363 minecraft:stripped_dark_oak_log
fill 78 153 323 79 153 323 minecraft:stripped_dark_oak_log
fill 81 153 359 81 153 361 minecraft:dark_oak_planks
fill 82 153 358 85 153 358 minecraft:dark_oak_planks
fill 82 153 359 84 213 361 minecraft:stripped_dark_oak_log
fill 82 153 362 84 153 362 minecraft:dark_oak_planks
fill 82 153 363 83 153 363 minecraft:stripped_dark_oak_log
fill 85 153 323 86 153 323 minecraft:stripped_dark_oak_log
setblock 85 153 359 minecraft:dark_oak_planks
fill 85 153 360 85 213 360 minecraft:stripped_dark_oak_log
setblock 85 153 361 minecraft:dark_oak_planks
fill 88 153 327 88 153 328 minecraft:stripped_dark_oak_log
fill 88 153 334 88 153 335 minecraft:stripped_dark_oak_log
fill 88 153 341 88 153 342 minecraft:stripped_dark_oak_log
fill 88 153 348 88 153 349 minecraft:stripped_dark_oak_log
fill 88 153 355 88 153 356 minecraft:stripped_dark_oak_log
fill 88 153 362 88 213 362 minecraft:stripped_dark_oak_log
fill 47 154 358 47 226 358 minecraft:spruce_planks
fill 48 154 328 48 213 328 minecraft:stripped_dark_oak_log
fill 48 154 335 48 213 335 minecraft:stripped_dark_oak_log
fill 48 154 342 48 213 342 minecraft:stripped_dark_oak_log
fill 48 154 349 48 213 349 minecraft:stripped_dark_oak_log
fill 48 154 356 48 213 356 minecraft:stripped_dark_oak_log
fill 48 154 363 48 213 363 minecraft:stripped_dark_oak_log
fill 50 154 323 50 213 323 minecraft:stripped_dark_oak_log
setblock 50 154 325 minecraft:light[level=12]
setblock 50 154 332 minecraft:light[level=12]
setblock 50 154 339 minecraft:light[level=12]
setblock 50 154 346 minecraft:light[level=12]
setblock 50 154 353 minecraft:light[level=12]
setblock 50 154 360 minecraft:light[level=12]
fill 55 154 363 55 213 363 minecraft:stripped_dark_oak_log
setblock 57 154 325 minecraft:light[level=12]
setblock 57 154 332 minecraft:light[level=12]
setblock 57 154 339 minecraft:light[level=12]
setblock 57 154 346 minecraft:light[level=12]
setblock 57 154 353 minecraft:light[level=12]
setblock 57 154 360 minecraft:light[level=12]
fill 62 154 363 62 213 363 minecraft:stripped_dark_oak_log
setblock 64 154 332 minecraft:light[level=12]
setblock 64 154 339 minecraft:light[level=12]
setblock 64 154 346 minecraft:light[level=12]
setblock 64 154 353 minecraft:light[level=12]
setblock 64 154 360 minecraft:light[level=12]
fill 69 154 363 69 213 363 minecraft:stripped_dark_oak_log
fill 71 154 323 71 213 323 minecraft:stripped_dark_oak_log
setblock 71 154 325 minecraft:light[level=12]
setblock 71 154 332 minecraft:light[level=12]
setblock 71 154 339 minecraft:light[level=12]
setblock 71 154 346 minecraft:light[level=12]
setblock 71 154 353 minecraft:light[level=12]
setblock 71 154 360 minecraft:light[level=12]
fill 76 154 363 76 213 363 minecraft:stripped_dark_oak_log
fill 77 154 360 77 155 362 minecraft:iron_bars
fill 78 154 323 78 213 323 minecraft:stripped_dark_oak_log
setblock 78 154 325 minecraft:light[level=12]
setblock 78 154 332 minecraft:light[level=12]
setblock 78 154 339 minecraft:light[level=12]
setblock 78 154 346 minecraft:light[level=12]
setblock 78 154 353 minecraft:light[level=12]
setblock 78 154 360 minecraft:light[level=12]
fill 83 154 363 83 213 363 minecraft:stripped_dark_oak_log
fill 85 154 323 85 213 323 minecraft:stripped_dark_oak_log
setblock 85 154 325 minecraft:light[level=12]
setblock 85 154 332 minecraft:light[level=12]
setblock 85 154 339 minecraft:light[level=12]
setblock 85 154 346 minecraft:light[level=12]
setblock 85 154 353 minecraft:light[level=12]
fill 88 154 327 88 213 327 minecraft:stripped_dark_oak_log
fill 88 154 334 88 213 334 minecraft:stripped_dark_oak_log
fill 88 154 341 88 213 341 minecraft:stripped_dark_oak_log
fill 88 154 348 88 213 348 minecraft:stripped_dark_oak_log
fill 88 154 355 88 213 355 minecraft:stripped_dark_oak_log
setblock 48 155 329 minecraft:stripped_dark_oak_log
setblock 48 155 336 minecraft:stripped_dark_oak_log
setblock 48 155 343 minecraft:stripped_dark_oak_log
setblock 48 155 350 minecraft:stripped_dark_oak_log
setblock 48 155 357 minecraft:stripped_dark_oak_log
setblock 49 155 323 minecraft:stripped_dark_oak_log
setblock 49 155 363 minecraft:stripped_dark_oak_log
fill 52 155 322 53 202 322 minecraft:spruce_planks
setblock 54 155 322 minecraft:red_concrete
fill 55 155 322 59 155 322 minecraft:spruce_planks
setblock 56 155 323 minecraft:stripped_dark_oak_log
setblock 56 155 363 minecraft:stripped_dark_oak_log
setblock 63 155 363 minecraft:stripped_dark_oak_log
setblock 70 155 323 minecraft:stripped_dark_oak_log
setblock 70 155 363 minecraft:stripped_dark_oak_log
setblock 77 155 323 minecraft:stripped_dark_oak_log
setblock 77 155 363 minecraft:stripped_dark_oak_log
setblock 84 155 323 minecraft:stripped_dark_oak_log
setblock 84 155 363 minecraft:stripped_dark_oak_log
setblock 88 155 326 minecraft:stripped_dark_oak_log
setblock 88 155 333 minecraft:stripped_dark_oak_log
setblock 88 155 340 minecraft:stripped_dark_oak_log
setblock 88 155 347 minecraft:stripped_dark_oak_log
setblock 88 155 354 minecraft:stripped_dark_oak_log
setblock 88 155 361 minecraft:stripped_dark_oak_log
setblock 48 156 323 minecraft:stripped_dark_oak_log
setblock 48 156 330 minecraft:stripped_dark_oak_log
fill 48 156 331 52 156 334 minecraft:dark_oak_planks
fill 48 156 336 53 157 336 minecraft:dark_oak_planks
setblock 48 156 337 minecraft:stripped_dark_oak_log
setblock 48 156 344 minecraft:stripped_dark_oak_log
setblock 48 156 351 minecraft:stripped_dark_oak_log
setblock 48 156 358 minecraft:stripped_dark_oak_log
fill 49 156 330 53 157 330 minecraft:dark_oak_planks
fill 49 156 335 53 157 335 minecraft:dark_oak_planks
setblock 50 156 363 minecraft:stripped_dark_oak_log
fill 53 156 331 53 157 332 minecraft:dark_oak_planks
fill 53 156 334 53 157 334 minecraft:dark_oak_planks
fill 54 156 322 56 205 322 minecraft:spruce_planks
setblock 55 156 323 minecraft:stripped_dark_oak_log
setblock 57 156 322 minecraft:red_concrete
setblock 57 156 363 minecraft:stripped_dark_oak_log
fill 58 156 322 59 222 322 minecraft:spruce_planks
setblock 64 156 363 minecraft:stripped_dark_oak_log
setblock 69 156 323 minecraft:stripped_dark_oak_log
setblock 71 156 363 minecraft:stripped_dark_oak_log
setblock 76 156 323 minecraft:stripped_dark_oak_log
setblock 78 156 363 minecraft:stripped_dark_oak_log
setblock 83 156 323 minecraft:stripped_dark_oak_log
setblock 85 156 363 minecraft:stripped_dark_oak_log
setblock 88 156 325 minecraft:stripped_dark_oak_log
setblock 88 156 332 minecraft:stripped_dark_oak_log
setblock 88 156 339 minecraft:stripped_dark_oak_log
setblock 88 156 346 minecraft:stripped_dark_oak_log
setblock 88 156 353 minecraft:stripped_dark_oak_log
setblock 88 156 360 minecraft:stripped_dark_oak_log
setblock 48 157 324 minecraft:stripped_dark_oak_log
fill 48 157 329 48 157 330 minecraft:dark_oak_planks
fill 48 157 331 48 158 331 minecraft:stripped_dark_oak_log
fill 48 157 332 52 157 334 minecraft:dark_oak_planks
fill 48 157 337 53 157 337 minecraft:dark_oak_planks
fill 48 157 338 48 158 338 minecraft:stripped_dark_oak_log
setblock 48 157 345 minecraft:stripped_dark_oak_log
setblock 48 157 352 minecraft:stripped_dark_oak_log
setblock 48 157 359 minecraft:stripped_dark_oak_log
fill 49 157 328 53 157 329 minecraft:dark_oak_planks
fill 49 157 331 52 157 331 minecraft:dark_oak_planks
fill 49 157 338 53 157 338 minecraft:dark_oak_planks
setblock 51 157 363 minecraft:stripped_dark_oak_log
setblock 53 157 333 minecraft:dark_oak_planks
setblock 54 157 323 minecraft:stripped_dark_oak_log
fill 57 157 322 57 222 322 minecraft:spruce_planks
setblock 58 157 363 minecraft:stripped_dark_oak_log
setblock 65 157 363 minecraft:stripped_dark_oak_log
setblock 72 157 363 minecraft:stripped_dark_oak_log
setblock 75 157 323 minecraft:stripped_dark_oak_log
fill 79 157 322 80 181 322 minecraft:spruce_planks
setblock 79 157 363 minecraft:stripped_dark_oak_log
setblock 81 157 322 minecraft:red_concrete
fill 82 157 322 83 222 322 minecraft:spruce_planks
setblock 82 157 323 minecraft:stripped_dark_oak_log
setblock 86 157 363 minecraft:stripped_dark_oak_log
setblock 88 157 324 minecraft:stripped_dark_oak_log
setblock 88 157 331 minecraft:stripped_dark_oak_log
setblock 88 157 338 minecraft:stripped_dark_oak_log
setblock 88 157 345 minecraft:stripped_dark_oak_log
setblock 88 157 352 minecraft:stripped_dark_oak_log
setblock 88 157 359 minecraft:stripped_dark_oak_log
fill 89 157 328 89 194 331 minecraft:spruce_planks
setblock 89 157 332 minecraft:red_concrete
fill 89 157 333 89 223 335 minecraft:spruce_planks
fill 47 158 328 47 173 331 minecraft:spruce_planks
fill 47 158 332 47 162 334 minecraft:shroomlight
fill 47 158 335 47 226 335 minecraft:spruce_planks
setblock 48 158 325 minecraft:stripped_dark_oak_log
fill 48 158 329 53 158 330 minecraft:stripped_dark_oak_log
fill 48 158 332 53 158 334 minecraft:stripped_dark_oak_log
fill 48 158 336 53 158 337 minecraft:stripped_dark_oak_log
setblock 48 158 339 minecraft:stripped_dark_oak_log
setblock 48 158 346 minecraft:stripped_dark_oak_log
setblock 48 158 353 minecraft:stripped_dark_oak_log
setblock 48 158 360 minecraft:stripped_dark_oak_log
fill 49 158 328 53 158 328 minecraft:stripped_dark_oak_log
fill 49 158 331 53 158 331 minecraft:stripped_dark_oak_log
fill 49 158 335 53 158 335 minecraft:stripped_dark_oak_log
fill 49 158 338 53 158 338 minecraft:stripped_dark_oak_log
setblock 52 158 363 minecraft:stripped_dark_oak_log
setblock 53 158 323 minecraft:stripped_dark_oak_log
setblock 59 158 363 minecraft:stripped_dark_oak_log
setblock 66 158 363 minecraft:stripped_dark_oak_log
setblock 73 158 363 minecraft:stripped_dark_oak_log
setblock 74 158 323 minecraft:stripped_dark_oak_log
fill 79 158 343 79 159 343 minecraft:shroomlight
setblock 80 158 363 minecraft:stripped_dark_oak_log
fill 81 158 322 81 190 322 minecraft:spruce_planks
setblock 81 158 323 minecraft:stripped_dark_oak_log
fill 83 158 342 85 161 343 minecraft:cherry_leaves[persistent=true]
fill 84 158 341 85 160 341 minecraft:cherry_leaves[persistent=true]
fill 84 158 344 84 160 344 minecraft:cherry_leaves[persistent=true]
setblock 87 158 363 minecraft:stripped_dark_oak_log
setblock 88 158 323 minecraft:stripped_dark_oak_log
setblock 88 158 330 minecraft:stripped_dark_oak_log
setblock 88 158 337 minecraft:stripped_dark_oak_log
setblock 88 158 344 minecraft:stripped_dark_oak_log
setblock 88 158 351 minecraft:stripped_dark_oak_log
setblock 88 158 358 minecraft:stripped_dark_oak_log
fill 89 158 323 89 226 325 minecraft:spruce_planks
setblock 89 158 326 minecraft:red_concrete
fill 89 158 332 89 201 332 minecraft:spruce_planks
setblock 89 158 350 minecraft:red_concrete
fill 48 159 326 48 160 326 minecraft:stripped_dark_oak_log
fill 48 159 333 48 160 333 minecraft:stripped_dark_oak_log
fill 48 159 340 48 160 340 minecraft:stripped_dark_oak_log
fill 48 159 347 48 160 347 minecraft:stripped_dark_oak_log
fill 48 159 354 48 160 354 minecraft:stripped_dark_oak_log
fill 48 159 361 48 160 361 minecraft:stripped_dark_oak_log
fill 52 159 323 52 160 323 minecraft:stripped_dark_oak_log
fill 53 159 328 53 159 338 minecraft:red_concrete
fill 53 159 363 53 160 363 minecraft:stripped_dark_oak_log
fill 60 159 363 60 160 363 minecraft:stripped_dark_oak_log
fill 67 159 363 67 160 363 minecraft:stripped_dark_oak_log
fill 73 159 323 73 160 323 minecraft:stripped_dark_oak_log
fill 74 159 363 74 160 363 minecraft:stripped_dark_oak_log
fill 80 159 323 80 160 323 minecraft:stripped_dark_oak_log
fill 81 159 363 81 160 363 minecraft:stripped_dark_oak_log
fill 82 159 342 82 160 342 minecraft:cherry_leaves[persistent=true]
fill 83 159 341 83 161 341 minecraft:cherry_leaves[persistent=true]
fill 83 159 344 83 160 344 minecraft:cherry_leaves[persistent=true]
setblock 84 159 322 minecraft:red_concrete
fill 85 159 344 85 160 344 minecraft:cherry_leaves[persistent=true]
fill 86 159 342 86 160 342 minecraft:cherry_leaves[persistent=true]
fill 87 159 323 87 160 323 minecraft:stripped_dark_oak_log
fill 88 159 329 88 160 329 minecraft:stripped_dark_oak_log
fill 88 159 336 88 160 336 minecraft:stripped_dark_oak_log
fill 88 159 343 88 160 343 minecraft:stripped_dark_oak_log
fill 88 159 350 88 160 350 minecraft:stripped_dark_oak_log
fill 88 159 357 88 160 357 minecraft:stripped_dark_oak_log
fill 88 159 363 88 160 363 minecraft:stripped_dark_oak_log
fill 89 159 326 89 223 326 minecraft:spruce_planks
fill 89 159 350 89 226 350 minecraft:spruce_planks
fill 48 160 323 48 160 325 minecraft:stripped_dark_oak_log
setblock 48 160 327 minecraft:stripped_dark_oak_log
fill 48 160 329 48 160 332 minecraft:stripped_dark_oak_log
setblock 48 160 334 minecraft:stripped_dark_oak_log
fill 48 160 336 48 160 339 minecraft:stripped_dark_oak_log
setblock 48 160 341 minecraft:stripped_dark_oak_log
fill 48 160 343 48 160 346 minecraft:stripped_dark_oak_log
setblock 48 160 348 minecraft:stripped_dark_oak_log
fill 48 160 350 48 160 353 minecraft:stripped_dark_oak_log
setblock 48 160 355 minecraft:stripped_dark_oak_log
fill 48 160 357 48 160 360 minecraft:stripped_dark_oak_log
setblock 48 160 362 minecraft:stripped_dark_oak_log
setblock 49 160 323 minecraft:stripped_dark_oak_log
fill 49 160 363 52 160 363 minecraft:stripped_dark_oak_log
setblock 50 160 325 minecraft:light[level=15]
setblock 50 160 332 minecraft:light[level=12]
setblock 50 160 333 minecraft:light[level=15]
setblock 50 160 339 minecraft:light[level=12]
setblock 50 160 341 minecraft:light[level=15]
setblock 50 160 346 minecraft:light[level=12]
setblock 50 160 349 minecraft:light[level=15]
setblock 50 160 353 minecraft:light[level=12]
setblock 50 160 357 minecraft:light[level=15]
setblock 50 160 360 minecraft:light[level=12]
setblock 51 160 323 minecraft:stripped_dark_oak_log
fill 53 160 323 56 160 323 minecraft:stripped_dark_oak_log
setblock 53 160 328 minecraft:stripped_dark_oak_log
setblock 53 160 333 minecraft:stripped_dark_oak_log
setblock 53 160 338 minecraft:stripped_dark_oak_log
setblock 54 160 363 minecraft:stripped_dark_oak_log
fill 56 160 363 59 160 363 minecraft:stripped_dark_oak_log
setblock 57 160 325 minecraft:light[level=12]
setblock 57 160 332 minecraft:light[level=12]
setblock 57 160 339 minecraft:light[level=12]
setblock 57 160 346 minecraft:light[level=12]
setblock 57 160 353 minecraft:light[level=12]
setblock 57 160 360 minecraft:light[level=12]
setblock 58 160 333 minecraft:light[level=15]
setblock 58 160 341 minecraft:light[level=15]
setblock 58 160 349 minecraft:light[level=15]
setblock 58 160 357 minecraft:light[level=15]
setblock 61 160 363 minecraft:stripped_dark_oak_log
fill 63 160 363 66 160 363 minecraft:stripped_dark_oak_log
setblock 64 160 332 minecraft:light[level=12]
setblock 64 160 339 minecraft:light[level=12]
setblock 64 160 346 minecraft:light[level=12]
setblock 64 160 353 minecraft:light[level=12]
setblock 64 160 360 minecraft:light[level=12]
setblock 66 160 333 minecraft:light[level=15]
setblock 66 160 341 minecraft:light[level=15]
setblock 66 160 349 minecraft:light[level=15]
setblock 66 160 357 minecraft:light[level=15]
setblock 68 160 363 minecraft:stripped_dark_oak_log
fill 69 160 323 70 160 323 minecraft:stripped_dark_oak_log
fill 70 160 363 73 160 363 minecraft:stripped_dark_oak_log
setblock 71 160 325 minecraft:light[level=12]
setblock 71 160 332 minecraft:light[level=12]
setblock 71 160 339 minecraft:light[level=12]
setblock 71 160 346 minecraft:light[level=12]
setblock 71 160 353 minecraft:light[level=12]
setblock 71 160 360 minecraft:light[level=12]
setblock 72 160 323 minecraft:stripped_dark_oak_log
fill 74 160 323 77 160 323 minecraft:stripped_dark_oak_log
setblock 74 160 325 minecraft:light[level=15]
setblock 74 160 333 minecraft:light[level=15]
setblock 74 160 341 minecraft:light[level=15]
setblock 74 160 349 minecraft:light[level=15]
setblock 74 160 357 minecraft:light[level=15]
setblock 75 160 363 minecraft:stripped_dark_oak_log
fill 77 160 363 80 160 363 minecraft:stripped_dark_oak_log
setblock 78 160 325 minecraft:light[level=12]
setblock 78 160 332 minecraft:light[level=12]
setblock 78 160 339 minecraft:light[level=12]
setblock 78 160 346 minecraft:light[level=12]
setblock 78 160 353 minecraft:light[level=12]
setblock 78 160 360 minecraft:light[level=12]
setblock 79 160 323 minecraft:stripped_dark_oak_log
fill 79 160 343 79 166 343 minecraft:dark_oak_planks
fill 81 160 323 84 160 323 minecraft:stripped_dark_oak_log
setblock 82 160 325 minecraft:light[level=15]
setblock 82 160 333 minecraft:light[level=15]
setblock 82 160 341 minecraft:light[level=15]
setblock 82 160 349 minecraft:light[level=15]
setblock 82 160 357 minecraft:light[level=15]
setblock 82 160 363 minecraft:stripped_dark_oak_log
fill 84 160 322 84 226 322 minecraft:spruce_planks
fill 84 160 363 87 160 363 minecraft:stripped_dark_oak_log
setblock 85 160 325 minecraft:light[level=12]
setblock 85 160 332 minecraft:light[level=12]
setblock 85 160 339 minecraft:light[level=12]
setblock 85 160 346 minecraft:light[level=12]
setblock 85 160 353 minecraft:light[level=12]
setblock 86 160 323 minecraft:stripped_dark_oak_log
setblock 86 160 343 minecraft:cherry_leaves[persistent=true]
fill 88 160 323 88 160 326 minecraft:stripped_dark_oak_log
setblock 88 160 328 minecraft:stripped_dark_oak_log
fill 88 160 330 88 160 333 minecraft:stripped_dark_oak_log
setblock 88 160 335 minecraft:stripped_dark_oak_log
fill 88 160 337 88 160 340 minecraft:stripped_dark_oak_log
setblock 88 160 342 minecraft:stripped_dark_oak_log
fill 88 160 344 88 160 347 minecraft:stripped_dark_oak_log
setblock 88 160 349 minecraft:stripped_dark_oak_log
fill 88 160 351 88 160 354 minecraft:stripped_dark_oak_log
setblock 88 160 356 minecraft:stripped_dark_oak_log
fill 88 160 358 88 160 361 minecraft:stripped_dark_oak_log
fill 49 161 341 49 175 341 minecraft:red_wool
fill 78 161 343 78 166 343 minecraft:dark_oak_planks
fill 81 161 359 81 161 361 minecraft:dark_oak_planks
fill 82 161 358 85 161 358 minecraft:dark_oak_planks
fill 82 161 362 84 161 362 minecraft:dark_oak_planks
setblock 84 161 341 minecraft:cherry_leaves[persistent=true]
setblock 85 161 359 minecraft:dark_oak_planks
setblock 85 161 361 minecraft:dark_oak_planks
setblock 48 162 329 minecraft:stripped_dark_oak_log
setblock 48 162 336 minecraft:stripped_dark_oak_log
setblock 48 162 343 minecraft:stripped_dark_oak_log
setblock 48 162 350 minecraft:stripped_dark_oak_log
setblock 48 162 357 minecraft:stripped_dark_oak_log
setblock 49 162 323 minecraft:stripped_dark_oak_log
fill 49 162 339 49 175 340 minecraft:red_wool
fill 49 162 342 49 175 343 minecraft:red_wool
setblock 49 162 363 minecraft:stripped_dark_oak_log
setblock 56 162 323 minecraft:stripped_dark_oak_log
setblock 56 162 363 minecraft:stripped_dark_oak_log
setblock 63 162 363 minecraft:stripped_dark_oak_log
setblock 70 162 323 minecraft:stripped_dark_oak_log
setblock 70 162 363 minecraft:stripped_dark_oak_log
setblock 77 162 323 minecraft:stripped_dark_oak_log
setblock 77 162 363 minecraft:stripped_dark_oak_log
fill 78 162 342 79 166 342 minecraft:dark_oak_planks
fill 79 162 344 79 166 344 minecraft:dark_oak_planks
setblock 84 162 323 minecraft:stripped_dark_oak_log
setblock 84 162 363 minecraft:stripped_dark_oak_log
setblock 88 162 326 minecraft:stripped_dark_oak_log
setblock 88 162 333 minecraft:stripped_dark_oak_log
setblock 88 162 340 minecraft:stripped_dark_oak_log
setblock 88 162 347 minecraft:stripped_dark_oak_log
setblock 88 162 354 minecraft:stripped_dark_oak_log
setblock 88 162 361 minecraft:stripped_dark_oak_log
fill 47 163 332 47 176 334 minecraft:spruce_planks
setblock 48 163 323 minecraft:stripped_dark_oak_log
setblock 48 163 330 minecraft:stripped_dark_oak_log
setblock 48 163 337 minecraft:stripped_dark_oak_log
setblock 48 163 344 minecraft:stripped_dark_oak_log
setblock 48 163 351 minecraft:stripped_dark_oak_log
setblock 48 163 358 minecraft:stripped_dark_oak_log
setblock 50 163 363 minecraft:stripped_dark_oak_log
setblock 55 163 323 minecraft:stripped_dark_oak_log
setblock 57 163 363 minecraft:stripped_dark_oak_log
setblock 64 163 363 minecraft:stripped_dark_oak_log
setblock 69 163 323 minecraft:stripped_dark_oak_log
setblock 71 163 363 minecraft:stripped_dark_oak_log
setblock 76 163 323 minecraft:stripped_dark_oak_log
fill 77 163 343 77 166 343 minecraft:dark_oak_planks
fill 78 163 344 78 166 344 minecraft:dark_oak_planks
setblock 78 163 363 minecraft:stripped_dark_oak_log
fill 80 163 342 80 166 343 minecraft:dark_oak_planks
setblock 83 163 323 minecraft:stripped_dark_oak_log
fill 85 163 340 87 164 340 minecraft:iron_bars
setblock 85 163 363 minecraft:stripped_dark_oak_log
setblock 88 163 325 minecraft:stripped_dark_oak_log
setblock 88 163 332 minecraft:stripped_dark_oak_log
setblock 88 163 339 minecraft:stripped_dark_oak_log
setblock 88 163 346 minecraft:stripped_dark_oak_log
setblock 88 163 353 minecraft:stripped_dark_oak_log
setblock 88 163 360 minecraft:stripped_dark_oak_log
setblock 48 164 324 minecraft:stripped_dark_oak_log
setblock 48 164 331 minecraft:stripped_dark_oak_log
setblock 48 164 338 minecraft:stripped_dark_oak_log
setblock 48 164 345 minecraft:stripped_dark_oak_log
setblock 48 164 352 minecraft:stripped_dark_oak_log
setblock 48 164 359 minecraft:stripped_dark_oak_log
setblock 51 164 363 minecraft:stripped_dark_oak_log
setblock 54 164 323 minecraft:stripped_dark_oak_log
setblock 58 164 363 minecraft:stripped_dark_oak_log
setblock 65 164 363 minecraft:stripped_dark_oak_log
setblock 72 164 363 minecraft:stripped_dark_oak_log
setblock 75 164 323 minecraft:stripped_dark_oak_log
fill 75 164 364 75 222 364 minecraft:spruce_planks
setblock 76 164 364 minecraft:red_concrete
fill 77 164 342 77 166 342 minecraft:dark_oak_planks
fill 77 164 344 77 166 344 minecraft:dark_oak_planks
fill 78 164 341 79 166 341 minecraft:dark_oak_planks
setblock 79 164 363 minecraft:stripped_dark_oak_log
fill 80 164 344 80 166 344 minecraft:dark_oak_planks
fill 81 164 344 82 166 346 minecraft:cherry_leaves[persistent=true]
setblock 82 164 323 minecraft:stripped_dark_oak_log
fill 83 164 345 83 167 346 minecraft:cherry_leaves[persistent=true]
setblock 86 164 363 minecraft:stripped_dark_oak_log
setblock 88 164 324 minecraft:stripped_dark_oak_log
setblock 88 164 331 minecraft:stripped_dark_oak_log
setblock 88 164 338 minecraft:stripped_dark_oak_log
setblock 88 164 345 minecraft:stripped_dark_oak_log
setblock 88 164 352 minecraft:stripped_dark_oak_log
setblock 88 164 359 minecraft:stripped_dark_oak_log
fill 89 164 342 89 167 342 minecraft:spruce_planks
setblock 89 164 343 minecraft:red_concrete
fill 89 164 344 89 226 345 minecraft:spruce_planks
setblock 48 165 325 minecraft:stripped_dark_oak_log
setblock 48 165 332 minecraft:stripped_dark_oak_log
setblock 48 165 339 minecraft:stripped_dark_oak_log
setblock 48 165 346 minecraft:stripped_dark_oak_log
setblock 48 165 353 minecraft:stripped_dark_oak_log
setblock 48 165 360 minecraft:stripped_dark_oak_log
setblock 52 165 363 minecraft:stripped_dark_oak_log
setblock 53 165 323 minecraft:stripped_dark_oak_log
setblock 59 165 363 minecraft:stripped_dark_oak_log
setblock 66 165 363 minecraft:stripped_dark_oak_log
setblock 73 165 363 minecraft:stripped_dark_oak_log
setblock 74 165 323 minecraft:stripped_dark_oak_log
fill 76 165 364 76 226 364 minecraft:spruce_planks
fill 77 165 341 77 166 341 minecraft:dark_oak_planks
fill 78 165 345 80 165 345 minecraft:dark_oak_planks
fill 80 165 341 80 166 341 minecraft:dark_oak_planks
setblock 80 165 363 minecraft:stripped_dark_oak_log
setblock 81 165 323 minecraft:stripped_dark_oak_log
fill 81 165 342 81 166 343 minecraft:dark_oak_planks
fill 81 165 347 83 165 347 minecraft:cherry_leaves[persistent=true]
fill 82 165 343 83 166 343 minecraft:cherry_leaves[persistent=true]
fill 83 165 344 83 167 344 minecraft:cherry_leaves[persistent=true]
setblock 87 165 363 minecraft:stripped_dark_oak_log
setblock 88 165 323 minecraft:stripped_dark_oak_log
setblock 88 165 330 minecraft:stripped_dark_oak_log
setblock 88 165 337 minecraft:stripped_dark_oak_log
setblock 88 165 344 minecraft:stripped_dark_oak_log
setblock 88 165 351 minecraft:stripped_dark_oak_log
setblock 88 165 358 minecraft:stripped_dark_oak_log
fill 89 165 343 89 227 343 minecraft:spruce_planks
setblock 48 166 326 minecraft:stripped_dark_oak_log
setblock 48 166 333 minecraft:stripped_dark_oak_log
setblock 48 166 340 minecraft:stripped_dark_oak_log
setblock 48 166 347 minecraft:stripped_dark_oak_log
setblock 48 166 354 minecraft:stripped_dark_oak_log
setblock 48 166 361 minecraft:stripped_dark_oak_log
fill 49 166 353 49 167 359 minecraft:iron_bars
setblock 50 166 325 minecraft:light[level=12]
setblock 50 166 332 minecraft:light[level=12]
setblock 50 166 339 minecraft:light[level=12]
setblock 50 166 346 minecraft:light[level=12]
setblock 50 166 353 minecraft:light[level=12]
setblock 50 166 360 minecraft:light[level=12]
setblock 52 166 323 minecraft:stripped_dark_oak_log
setblock 53 166 363 minecraft:stripped_dark_oak_log
setblock 57 166 325 minecraft:light[level=12]
setblock 57 166 332 minecraft:light[level=12]
setblock 57 166 339 minecraft:light[level=12]
setblock 57 166 346 minecraft:light[level=12]
setblock 57 166 353 minecraft:light[level=12]
setblock 57 166 360 minecraft:light[level=12]
setblock 60 166 322 minecraft:red_concrete
setblock 60 166 363 minecraft:stripped_dark_oak_log
setblock 64 166 332 minecraft:light[level=12]
setblock 64 166 339 minecraft:light[level=12]
setblock 64 166 346 minecraft:light[level=12]
setblock 64 166 353 minecraft:light[level=12]
setblock 64 166 360 minecraft:light[level=12]
setblock 67 166 363 minecraft:stripped_dark_oak_log
setblock 71 166 325 minecraft:light[level=12]
setblock 71 166 332 minecraft:light[level=12]
setblock 71 166 339 minecraft:light[level=12]
setblock 71 166 346 minecraft:light[level=12]
setblock 71 166 353 minecraft:light[level=12]
setblock 71 166 360 minecraft:light[level=12]
setblock 73 166 323 minecraft:stripped_dark_oak_log
setblock 74 166 363 minecraft:stripped_dark_oak_log
fill 76 166 342 76 166 344 minecraft:dark_oak_planks
fill 77 166 345 79 166 345 minecraft:dark_oak_planks
setblock 78 166 325 minecraft:light[level=12]
setblock 78 166 332 minecraft:light[level=12]
setblock 78 166 339 minecraft:light[level=12]
fill 78 166 340 79 166 340 minecraft:dark_oak_planks
setblock 78 166 346 minecraft:light[level=12]
setblock 78 166 353 minecraft:light[level=12]
setblock 78 166 360 minecraft:light[level=12]
setblock 80 166 323 minecraft:stripped_dark_oak_log
setblock 80 166 345 minecraft:cherry_leaves[persistent=true]
setblock 81 166 341 minecraft:dark_oak_planks
setblock 81 166 363 minecraft:stripped_dark_oak_log
fill 82 166 347 83 166 347 minecraft:cherry_leaves[persistent=true]
setblock 85 166 325 minecraft:light[level=12]
setblock 85 166 332 minecraft:light[level=12]
setblock 85 166 339 minecraft:light[level=12]
setblock 85 166 346 minecraft:light[level=12]
setblock 85 166 353 minecraft:light[level=12]
setblock 87 166 323 minecraft:stripped_dark_oak_log
setblock 88 166 329 minecraft:stripped_dark_oak_log
setblock 88 166 336 minecraft:stripped_dark_oak_log
setblock 88 166 343 minecraft:stripped_dark_oak_log
setblock 88 166 350 minecraft:stripped_dark_oak_log
setblock 88 166 357 minecraft:stripped_dark_oak_log
setblock 88 166 363 minecraft:stripped_dark_oak_log
setblock 48 167 327 minecraft:stripped_dark_oak_log
setblock 48 167 334 minecraft:stripped_dark_oak_log
setblock 48 167 341 minecraft:stripped_dark_oak_log
setblock 48 167 348 minecraft:stripped_dark_oak_log
setblock 48 167 355 minecraft:stripped_dark_oak_log
setblock 48 167 362 minecraft:stripped_dark_oak_log
setblock 51 167 323 minecraft:stripped_dark_oak_log
setblock 54 167 363 minecraft:stripped_dark_oak_log
fill 57 167 323 58 167 323 minecraft:stripped_dark_oak_log
fill 59 167 324 67 167 330 minecraft:red_concrete
fill 60 167 322 60 193 322 minecraft:spruce_planks
setblock 61 167 363 minecraft:stripped_dark_oak_log
setblock 63 167 364 minecraft:red_concrete
fill 64 167 323 65 167 323 minecraft:stripped_dark_oak_log
setblock 68 167 363 minecraft:stripped_dark_oak_log
setblock 72 167 323 minecraft:stripped_dark_oak_log
setblock 75 167 363 minecraft:stripped_dark_oak_log
setblock 79 167 323 minecraft:stripped_dark_oak_log
fill 79 167 343 79 169 343 minecraft:stripped_dark_oak_log
fill 81 167 345 82 167 345 minecraft:cherry_leaves[persistent=true]
setblock 82 167 344 minecraft:cherry_leaves[persistent=true]
setblock 82 167 363 minecraft:stripped_dark_oak_log
setblock 86 167 323 minecraft:stripped_dark_oak_log
setblock 88 167 328 minecraft:stripped_dark_oak_log
setblock 88 167 335 minecraft:stripped_dark_oak_log
setblock 88 167 342 minecraft:stripped_dark_oak_log
setblock 88 167 349 minecraft:stripped_dark_oak_log
setblock 88 167 356 minecraft:stripped_dark_oak_log
fill 49 168 364 55 188 364 minecraft:spruce_planks
setblock 50 168 325 minecraft:light[level=15]
setblock 50 168 333 minecraft:light[level=15]
setblock 50 168 341 minecraft:light[level=15]
setblock 50 168 349 minecraft:light[level=15]
setblock 50 168 357 minecraft:light[level=15]
setblock 56 168 364 minecraft:red_concrete
fill 57 168 323 57 213 323 minecraft:stripped_dark_oak_log
fill 57 168 364 57 226 364 minecraft:spruce_planks
setblock 58 168 325 minecraft:light[level=15]
setblock 58 168 333 minecraft:light[level=15]
setblock 58 168 341 minecraft:light[level=15]
setblock 58 168 349 minecraft:light[level=15]
setblock 58 168 357 minecraft:light[level=15]
fill 60 168 325 66 168 329 minecraft:red_concrete
fill 63 168 364 63 220 364 minecraft:spruce_planks
fill 64 168 323 64 213 323 minecraft:stripped_dark_oak_log
setblock 66 168 333 minecraft:light[level=15]
setblock 66 168 341 minecraft:light[level=15]
setblock 66 168 349 minecraft:light[level=15]
setblock 66 168 357 minecraft:light[level=15]
setblock 74 168 325 minecraft:light[level=15]
setblock 74 168 333 minecraft:light[level=15]
setblock 74 168 341 minecraft:light[level=15]
setblock 74 168 349 minecraft:light[level=15]
setblock 74 168 357 minecraft:light[level=15]
setblock 82 168 325 minecraft:light[level=15]
setblock 82 168 333 minecraft:light[level=15]
setblock 82 168 341 minecraft:light[level=15]
setblock 82 168 349 minecraft:light[level=15]
setblock 82 168 357 minecraft:light[level=15]
setblock 89 168 342 minecraft:red_concrete
setblock 47 169 363 minecraft:red_concrete
fill 47 169 364 47 222 364 minecraft:spruce_planks
fill 48 169 329 48 170 329 minecraft:stripped_dark_oak_log
fill 48 169 336 48 170 336 minecraft:stripped_dark_oak_log
fill 48 169 343 48 170 343 minecraft:stripped_dark_oak_log
fill 48 169 350 48 170 350 minecraft:stripped_dark_oak_log
fill 48 169 357 48 170 357 minecraft:stripped_dark_oak_log
fill 49 169 323 49 170 323 minecraft:stripped_dark_oak_log
fill 49 169 363 49 170 363 minecraft:stripped_dark_oak_log
fill 56 169 323 56 170 323 minecraft:stripped_dark_oak_log
fill 56 169 363 56 170 363 minecraft:stripped_dark_oak_log
fill 56 169 364 56 215 364 minecraft:spruce_planks
fill 61 169 326 65 169 328 minecraft:red_concrete
fill 63 169 323 63 170 323 minecraft:stripped_dark_oak_log
fill 63 169 363 63 170 363 minecraft:stripped_dark_oak_log
fill 70 169 323 70 170 323 minecraft:stripped_dark_oak_log
fill 70 169 363 70 170 363 minecraft:stripped_dark_oak_log
fill 77 169 323 77 170 323 minecraft:stripped_dark_oak_log
fill 77 169 363 77 170 363 minecraft:stripped_dark_oak_log
fill 81 169 359 81 169 361 minecraft:dark_oak_planks
fill 82 169 358 85 169 358 minecraft:dark_oak_planks
fill 82 169 362 84 169 362 minecraft:dark_oak_planks
fill 84 169 323 84 170 323 minecraft:stripped_dark_oak_log
fill 84 169 363 84 170 363 minecraft:stripped_dark_oak_log
setblock 85 169 359 minecraft:dark_oak_planks
setblock 85 169 361 minecraft:dark_oak_planks
fill 88 169 326 88 170 326 minecraft:stripped_dark_oak_log
fill 88 169 333 88 170 333 minecraft:stripped_dark_oak_log
fill 88 169 340 88 170 340 minecraft:stripped_dark_oak_log
fill 88 169 347 88 170 347 minecraft:stripped_dark_oak_log
fill 88 169 354 88 170 354 minecraft:stripped_dark_oak_log
fill 88 169 361 88 170 361 minecraft:stripped_dark_oak_log
fill 89 169 342 89 226 342 minecraft:spruce_planks
fill 47 170 363 47 222 363 minecraft:spruce_planks
fill 48 170 323 48 170 327 minecraft:stripped_dark_oak_log
fill 48 170 330 48 170 334 minecraft:stripped_dark_oak_log
fill 48 170 337 48 170 341 minecraft:stripped_dark_oak_log
fill 48 170 344 48 170 348 minecraft:stripped_dark_oak_log
fill 48 170 351 48 170 355 minecraft:stripped_dark_oak_log
fill 48 170 358 48 170 362 minecraft:stripped_dark_oak_log
fill 50 170 363 54 170 363 minecraft:stripped_dark_oak_log
fill 51 170 323 55 170 323 minecraft:stripped_dark_oak_log
fill 57 170 363 61 170 363 minecraft:stripped_dark_oak_log
fill 58 170 323 62 170 323 minecraft:stripped_dark_oak_log
fill 59 170 360 59 171 362 minecraft:iron_bars
fill 62 170 327 64 170 327 minecraft:red_concrete
fill 64 170 363 68 170 363 minecraft:stripped_dark_oak_log
fill 65 170 323 69 170 323 minecraft:stripped_dark_oak_log
fill 71 170 363 75 170 363 minecraft:stripped_dark_oak_log
fill 72 170 323 76 170 323 minecraft:stripped_dark_oak_log
fill 77 170 342 80 172 343 minecraft:cherry_leaves[persistent=true]
fill 78 170 341 79 172 341 minecraft:cherry_leaves[persistent=true]
fill 78 170 344 80 172 344 minecraft:cherry_leaves[persistent=true]
fill 78 170 363 82 170 363 minecraft:stripped_dark_oak_log
fill 79 170 323 83 170 323 minecraft:stripped_dark_oak_log
fill 85 170 339 87 171 339 minecraft:iron_bars
fill 85 170 363 88 170 363 minecraft:stripped_dark_oak_log
fill 86 170 323 88 170 323 minecraft:stripped_dark_oak_log
fill 88 170 324 88 170 325 minecraft:stripped_dark_oak_log
fill 88 170 328 88 170 332 minecraft:stripped_dark_oak_log
fill 88 170 335 88 170 339 minecraft:stripped_dark_oak_log
fill 88 170 342 88 170 346 minecraft:stripped_dark_oak_log
fill 88 170 349 88 170 353 minecraft:stripped_dark_oak_log
fill 88 170 356 88 170 360 minecraft:stripped_dark_oak_log
fill 47 171 322 47 188 325 minecraft:spruce_planks
setblock 47 171 326 minecraft:red_concrete
setblock 47 171 342 minecraft:spruce_planks
setblock 47 171 343 minecraft:red_concrete
fill 47 171 344 47 226 345 minecraft:spruce_planks
fill 48 171 322 48 226 322 minecraft:spruce_planks
setblock 48 171 324 minecraft:stripped_dark_oak_log
setblock 48 171 331 minecraft:stripped_dark_oak_log
setblock 48 171 338 minecraft:stripped_dark_oak_log
setblock 48 171 345 minecraft:stripped_dark_oak_log
setblock 48 171 352 minecraft:stripped_dark_oak_log
fill 48 171 353 50 171 353 minecraft:iron_bars
setblock 48 171 359 minecraft:stripped_dark_oak_log
setblock 49 171 322 minecraft:red_concrete
fill 50 171 322 50 222 322 minecraft:spruce_planks
setblock 51 171 363 minecraft:stripped_dark_oak_log
setblock 54 171 323 minecraft:stripped_dark_oak_log
setblock 58 171 363 minecraft:stripped_dark_oak_log
setblock 61 171 323 minecraft:stripped_dark_oak_log
setblock 65 171 363 minecraft:stripped_dark_oak_log
setblock 68 171 323 minecraft:stripped_dark_oak_log
setblock 72 171 363 minecraft:stripped_dark_oak_log
setblock 75 171 323 minecraft:stripped_dark_oak_log
setblock 77 171 344 minecraft:cherry_leaves[persistent=true]
fill 78 171 345 79 171 345 minecraft:cherry_leaves[persistent=true]
setblock 79 171 363 minecraft:stripped_dark_oak_log
setblock 80 171 341 minecraft:cherry_leaves[persistent=true]
setblock 81 171 343 minecraft:cherry_leaves[persistent=true]
setblock 82 171 323 minecraft:stripped_dark_oak_log
setblock 86 171 363 minecraft:stripped_dark_oak_log
setblock 88 171 324 minecraft:stripped_dark_oak_log
setblock 88 171 331 minecraft:stripped_dark_oak_log
setblock 88 171 338 minecraft:stripped_dark_oak_log
setblock 88 171 345 minecraft:stripped_dark_oak_log
setblock 88 171 352 minecraft:stripped_dark_oak_log
setblock 88 171 359 minecraft:stripped_dark_oak_log
fill 47 172 326 47 209 326 minecraft:spruce_planks
setblock 47 172 342 minecraft:red_concrete
fill 47 172 343 47 223 343 minecraft:spruce_planks
setblock 48 172 325 minecraft:stripped_dark_oak_log
setblock 48 172 332 minecraft:stripped_dark_oak_log
setblock 48 172 339 minecraft:stripped_dark_oak_log
setblock 48 172 346 minecraft:stripped_dark_oak_log
setblock 48 172 353 minecraft:stripped_dark_oak_log
setblock 48 172 360 minecraft:stripped_dark_oak_log
fill 49 172 322 49 224 322 minecraft:spruce_planks
fill 49 172 353 50 172 353 minecraft:iron_bars
setblock 50 172 325 minecraft:light[level=12]
setblock 50 172 332 minecraft:light[level=12]
setblock 50 172 339 minecraft:light[level=12]
setblock 50 172 346 minecraft:light[level=12]
setblock 50 172 360 minecraft:light[level=12]
setblock 52 172 363 minecraft:stripped_dark_oak_log
setblock 53 172 323 minecraft:stripped_dark_oak_log
setblock 57 172 325 minecraft:light[level=12]
setblock 57 172 332 minecraft:light[level=12]
setblock 57 172 339 minecraft:light[level=12]
setblock 57 172 346 minecraft:light[level=12]
setblock 57 172 353 minecraft:light[level=12]
setblock 57 172 360 minecraft:light[level=12]
setblock 59 172 363 minecraft:stripped_dark_oak_log
setblock 60 172 323 minecraft:stripped_dark_oak_log
setblock 64 172 325 minecraft:light[level=12]
setblock 64 172 332 minecraft:light[level=12]
setblock 64 172 339 minecraft:light[level=12]
setblock 64 172 346 minecraft:light[level=12]
setblock 64 172 353 minecraft:light[level=12]
setblock 64 172 360 minecraft:light[level=12]
setblock 66 172 363 minecraft:stripped_dark_oak_log
setblock 67 172 323 minecraft:stripped_dark_oak_log
setblock 71 172 325 minecraft:light[level=12]
setblock 71 172 332 minecraft:light[level=12]
setblock 71 172 339 minecraft:light[level=12]
setblock 71 172 346 minecraft:light[level=12]
setblock 71 172 353 minecraft:light[level=12]
setblock 71 172 360 minecraft:light[level=12]
setblock 73 172 363 minecraft:stripped_dark_oak_log
setblock 74 172 323 minecraft:stripped_dark_oak_log
setblock 78 172 325 minecraft:light[level=12]
setblock 78 172 332 minecraft:light[level=12]
setblock 78 172 339 minecraft:light[level=12]
setblock 78 172 346 minecraft:light[level=12]
setblock 78 172 353 minecraft:light[level=12]
setblock 78 172 360 minecraft:light[level=12]
setblock 80 172 363 minecraft:stripped_dark_oak_log
setblock 81 172 323 minecraft:stripped_dark_oak_log
setblock 85 172 325 minecraft:light[level=12]
setblock 85 172 332 minecraft:light[level=12]
setblock 85 172 339 minecraft:light[level=12]
setblock 85 172 346 minecraft:light[level=12]
setblock 85 172 353 minecraft:light[level=12]
setblock 87 172 363 minecraft:stripped_dark_oak_log
setblock 88 172 323 minecraft:stripped_dark_oak_log
setblock 88 172 330 minecraft:stripped_dark_oak_log
setblock 88 172 337 minecraft:stripped_dark_oak_log
setblock 88 172 344 minecraft:stripped_dark_oak_log
setblock 88 172 351 minecraft:stripped_dark_oak_log
setblock 88 172 358 minecraft:stripped_dark_oak_log
fill 89 172 355 89 226 355 minecraft:spruce_planks
setblock 89 172 356 minecraft:red_concrete
fill 89 172 357 89 222 359 minecraft:spruce_planks
setblock 89 172 360 minecraft:red_concrete
fill 89 172 361 89 224 363 minecraft:spruce_planks
fill 47 173 342 47 226 342 minecraft:spruce_planks
fill 47 173 359 47 226 359 minecraft:spruce_planks
setblock 47 173 360 minecraft:red_concrete
fill 47 173 361 47 183 361 minecraft:spruce_planks
setblock 48 173 326 minecraft:stripped_dark_oak_log
setblock 48 173 333 minecraft:stripped_dark_oak_log
setblock 48 173 340 minecraft:stripped_dark_oak_log
setblock 48 173 347 minecraft:stripped_dark_oak_log
setblock 48 173 354 minecraft:stripped_dark_oak_log
setblock 48 173 361 minecraft:stripped_dark_oak_log
setblock 52 173 323 minecraft:stripped_dark_oak_log
setblock 53 173 363 minecraft:stripped_dark_oak_log
setblock 59 173 323 minecraft:stripped_dark_oak_log
setblock 60 173 363 minecraft:stripped_dark_oak_log
setblock 66 173 323 minecraft:stripped_dark_oak_log
setblock 67 173 363 minecraft:stripped_dark_oak_log
setblock 73 173 323 minecraft:stripped_dark_oak_log
setblock 74 173 363 minecraft:stripped_dark_oak_log
setblock 80 173 323 minecraft:stripped_dark_oak_log
setblock 81 173 363 minecraft:stripped_dark_oak_log
setblock 87 173 323 minecraft:stripped_dark_oak_log
setblock 88 173 329 minecraft:stripped_dark_oak_log
setblock 88 173 336 minecraft:stripped_dark_oak_log
setblock 88 173 343 minecraft:stripped_dark_oak_log
setblock 88 173 350 minecraft:stripped_dark_oak_log
setblock 88 173 357 minecraft:stripped_dark_oak_log
setblock 88 173 363 minecraft:stripped_dark_oak_log
fill 89 173 356 89 226 356 minecraft:spruce_planks
fill 89 173 360 89 226 360 minecraft:spruce_planks
fill 47 174 328 47 205 329 minecraft:spruce_planks
setblock 47 174 330 minecraft:red_concrete
fill 47 174 331 47 226 331 minecraft:spruce_planks
fill 47 174 360 47 226 360 minecraft:spruce_planks
setblock 48 174 327 minecraft:stripped_dark_oak_log
setblock 48 174 334 minecraft:stripped_dark_oak_log
setblock 48 174 341 minecraft:stripped_dark_oak_log
setblock 48 174 348 minecraft:stripped_dark_oak_log
setblock 48 174 355 minecraft:stripped_dark_oak_log
setblock 48 174 362 minecraft:stripped_dark_oak_log
setblock 51 174 323 minecraft:stripped_dark_oak_log
setblock 54 174 363 minecraft:stripped_dark_oak_log
setblock 58 174 323 minecraft:stripped_dark_oak_log
setblock 61 174 363 minecraft:stripped_dark_oak_log
setblock 65 174 323 minecraft:stripped_dark_oak_log
setblock 68 174 363 minecraft:stripped_dark_oak_log
setblock 72 174 323 minecraft:stripped_dark_oak_log
setblock 75 174 363 minecraft:stripped_dark_oak_log
setblock 79 174 323 minecraft:stripped_dark_oak_log
setblock 82 174 363 minecraft:stripped_dark_oak_log
setblock 86 174 323 minecraft:stripped_dark_oak_log
setblock 88 174 328 minecraft:stripped_dark_oak_log
setblock 88 174 335 minecraft:stripped_dark_oak_log
setblock 88 174 342 minecraft:stripped_dark_oak_log
setblock 88 174 349 minecraft:stripped_dark_oak_log
setblock 88 174 356 minecraft:stripped_dark_oak_log
fill 47 175 330 47 226 330 minecraft:spruce_planks
setblock 48 176 329 minecraft:stripped_dark_oak_log
setblock 48 176 336 minecraft:stripped_dark_oak_log
setblock 48 176 343 minecraft:stripped_dark_oak_log
setblock 48 176 350 minecraft:stripped_dark_oak_log
setblock 48 176 357 minecraft:stripped_dark_oak_log
setblock 49 176 323 minecraft:stripped_dark_oak_log
fill 49 176 338 49 177 344 minecraft:iron_bars
setblock 49 176 363 minecraft:stripped_dark_oak_log
setblock 50 176 325 minecraft:light[level=15]
setblock 50 176 333 minecraft:light[level=15]
setblock 50 176 341 minecraft:light[level=15]
setblock 50 176 349 minecraft:light[level=15]
setblock 50 176 357 minecraft:light[level=15]
setblock 56 176 323 minecraft:stripped_dark_oak_log
setblock 56 176 363 minecraft:stripped_dark_oak_log
setblock 58 176 325 minecraft:light[level=15]
setblock 58 176 333 minecraft:light[level=15]
setblock 58 176 341 minecraft:light[level=15]
setblock 58 176 349 minecraft:light[level=15]
setblock 58 176 357 minecraft:light[level=15]
setblock 63 176 323 minecraft:stripped_dark_oak_log
setblock 63 176 363 minecraft:stripped_dark_oak_log
setblock 66 176 325 minecraft:light[level=15]
setblock 66 176 333 minecraft:light[level=15]
setblock 66 176 341 minecraft:light[level=15]
setblock 66 176 349 minecraft:light[level=15]
setblock 66 176 357 minecraft:light[level=15]
fill 68 176 364 70 224 364 minecraft:spruce_planks
setblock 70 176 323 minecraft:stripped_dark_oak_log
setblock 70 176 363 minecraft:stripped_dark_oak_log
setblock 71 176 364 minecraft:red_concrete
fill 72 176 364 74 224 364 minecraft:spruce_planks
setblock 74 176 325 minecraft:light[level=15]
setblock 74 176 333 minecraft:light[level=15]
setblock 74 176 341 minecraft:light[level=15]
setblock 74 176 349 minecraft:light[level=15]
setblock 74 176 357 minecraft:light[level=15]
setblock 77 176 323 minecraft:stripped_dark_oak_log
setblock 77 176 363 minecraft:stripped_dark_oak_log
setblock 82 176 325 minecraft:light[level=15]
setblock 82 176 333 minecraft:light[level=15]
setblock 82 176 341 minecraft:light[level=15]
setblock 82 176 349 minecraft:light[level=15]
setblock 82 176 357 minecraft:light[level=15]
setblock 84 176 323 minecraft:stripped_dark_oak_log
setblock 84 176 363 minecraft:stripped_dark_oak_log
setblock 88 176 326 minecraft:stripped_dark_oak_log
setblock 88 176 333 minecraft:stripped_dark_oak_log
setblock 88 176 340 minecraft:stripped_dark_oak_log
setblock 88 176 347 minecraft:stripped_dark_oak_log
setblock 88 176 354 minecraft:stripped_dark_oak_log
setblock 88 176 361 minecraft:stripped_dark_oak_log
setblock 47 177 332 minecraft:red_concrete
fill 47 177 333 47 226 334 minecraft:spruce_planks
setblock 48 177 323 minecraft:stripped_dark_oak_log
setblock 48 177 330 minecraft:stripped_dark_oak_log
setblock 48 177 337 minecraft:stripped_dark_oak_log
setblock 48 177 344 minecraft:stripped_dark_oak_log
setblock 48 177 351 minecraft:stripped_dark_oak_log
setblock 48 177 358 minecraft:stripped_dark_oak_log
setblock 50 177 363 minecraft:stripped_dark_oak_log
setblock 55 177 323 minecraft:stripped_dark_oak_log
setblock 57 177 363 minecraft:stripped_dark_oak_log
setblock 62 177 323 minecraft:stripped_dark_oak_log
setblock 64 177 363 minecraft:stripped_dark_oak_log
setblock 69 177 323 minecraft:stripped_dark_oak_log
setblock 71 177 363 minecraft:stripped_dark_oak_log
fill 71 177 364 71 226 364 minecraft:spruce_planks
setblock 76 177 323 minecraft:stripped_dark_oak_log
setblock 78 177 363 minecraft:stripped_dark_oak_log
fill 81 177 359 81 177 361 minecraft:dark_oak_planks
fill 82 177 358 85 177 358 minecraft:dark_oak_planks
fill 82 177 362 84 177 362 minecraft:dark_oak_planks
setblock 83 177 323 minecraft:stripped_dark_oak_log
setblock 85 177 359 minecraft:dark_oak_planks
setblock 85 177 361 minecraft:dark_oak_planks
setblock 85 177 363 minecraft:stripped_dark_oak_log
setblock 88 177 325 minecraft:stripped_dark_oak_log
setblock 88 177 332 minecraft:stripped_dark_oak_log
setblock 88 177 339 minecraft:stripped_dark_oak_log
setblock 88 177 346 minecraft:stripped_dark_oak_log
setblock 88 177 353 minecraft:stripped_dark_oak_log
setblock 88 177 360 minecraft:stripped_dark_oak_log
setblock 89 177 327 minecraft:red_concrete
fill 47 178 332 47 222 332 minecraft:spruce_planks
setblock 48 178 324 minecraft:stripped_dark_oak_log
setblock 48 178 331 minecraft:stripped_dark_oak_log
setblock 48 178 338 minecraft:stripped_dark_oak_log
setblock 48 178 345 minecraft:stripped_dark_oak_log
setblock 48 178 352 minecraft:stripped_dark_oak_log
setblock 48 178 359 minecraft:stripped_dark_oak_log
setblock 50 178 325 minecraft:light[level=12]
setblock 50 178 332 minecraft:light[level=12]
setblock 50 178 339 minecraft:light[level=12]
setblock 50 178 346 minecraft:light[level=12]
setblock 50 178 353 minecraft:light[level=12]
setblock 50 178 360 minecraft:light[level=12]
setblock 51 178 363 minecraft:stripped_dark_oak_log
setblock 54 178 323 minecraft:stripped_dark_oak_log
setblock 57 178 325 minecraft:light[level=12]
setblock 57 178 332 minecraft:light[level=12]
setblock 57 178 339 minecraft:light[level=12]
setblock 57 178 346 minecraft:light[level=12]
setblock 57 178 353 minecraft:light[level=12]
setblock 57 178 360 minecraft:light[level=12]
setblock 58 178 363 minecraft:stripped_dark_oak_log
setblock 61 178 323 minecraft:stripped_dark_oak_log
setblock 64 178 325 minecraft:light[level=12]
setblock 64 178 332 minecraft:light[level=12]
setblock 64 178 339 minecraft:light[level=12]
setblock 64 178 346 minecraft:light[level=12]
setblock 64 178 353 minecraft:light[level=12]
setblock 64 178 360 minecraft:light[level=12]
setblock 65 178 363 minecraft:stripped_dark_oak_log
setblock 68 178 323 minecraft:stripped_dark_oak_log
setblock 71 178 325 minecraft:light[level=12]
setblock 71 178 332 minecraft:light[level=12]
setblock 71 178 339 minecraft:light[level=12]
setblock 71 178 346 minecraft:light[level=12]
setblock 71 178 353 minecraft:light[level=12]
setblock 71 178 360 minecraft:light[level=12]
setblock 72 178 363 minecraft:stripped_dark_oak_log
setblock 75 178 323 minecraft:stripped_dark_oak_log
setblock 78 178 325 minecraft:light[level=12]
setblock 78 178 332 minecraft:light[level=12]
setblock 78 178 339 minecraft:light[level=12]
setblock 78 178 346 minecraft:light[level=12]
setblock 78 178 353 minecraft:light[level=12]
setblock 78 178 360 minecraft:light[level=12]
setblock 79 178 363 minecraft:stripped_dark_oak_log
setblock 82 178 323 minecraft:stripped_dark_oak_log
setblock 85 178 325 minecraft:light[level=12]
setblock 85 178 332 minecraft:light[level=12]
setblock 85 178 339 minecraft:light[level=12]
setblock 85 178 346 minecraft:light[level=12]
setblock 85 178 353 minecraft:light[level=12]
fill 86 178 354 86 189 354 minecraft:red_wool
setblock 86 178 363 minecraft:stripped_dark_oak_log
setblock 88 178 324 minecraft:stripped_dark_oak_log
setblock 88 178 331 minecraft:stripped_dark_oak_log
setblock 88 178 338 minecraft:stripped_dark_oak_log
setblock 88 178 345 minecraft:stripped_dark_oak_log
setblock 88 178 352 minecraft:stripped_dark_oak_log
setblock 88 178 359 minecraft:stripped_dark_oak_log
fill 89 178 327 89 226 327 minecraft:spruce_planks
fill 48 179 325 48 180 325 minecraft:stripped_dark_oak_log
fill 48 179 332 48 180 332 minecraft:stripped_dark_oak_log
fill 48 179 339 48 180 339 minecraft:stripped_dark_oak_log
fill 48 179 346 48 180 346 minecraft:stripped_dark_oak_log
fill 48 179 353 48 180 353 minecraft:stripped_dark_oak_log
fill 48 179 360 48 180 360 minecraft:stripped_dark_oak_log
fill 52 179 363 52 180 363 minecraft:stripped_dark_oak_log
fill 53 179 323 53 180 323 minecraft:stripped_dark_oak_log
fill 59 179 363 59 180 363 minecraft:stripped_dark_oak_log
fill 60 179 323 60 180 323 minecraft:stripped_dark_oak_log
fill 63 179 330 65 181 331 minecraft:cherry_leaves[persistent=true]
fill 64 179 329 65 182 329 minecraft:cherry_leaves[persistent=true]
fill 66 179 330 66 182 330 minecraft:cherry_leaves[persistent=true]
fill 66 179 363 66 180 363 minecraft:stripped_dark_oak_log
fill 67 179 323 67 180 323 minecraft:stripped_dark_oak_log
fill 73 179 363 73 180 363 minecraft:stripped_dark_oak_log
fill 74 179 323 74 180 323 minecraft:stripped_dark_oak_log
fill 80 179 363 80 180 363 minecraft:stripped_dark_oak_log
fill 81 179 323 81 180 323 minecraft:stripped_dark_oak_log
fill 86 179 352 86 189 353 minecraft:red_wool
fill 86 179 355 86 189 356 minecraft:red_wool
fill 87 179 363 87 180 363 minecraft:stripped_dark_oak_log
fill 88 179 323 88 180 323 minecraft:stripped_dark_oak_log
fill 88 179 330 88 180 330 minecraft:stripped_dark_oak_log
fill 88 179 337 88 180 337 minecraft:stripped_dark_oak_log
fill 88 179 344 88 180 344 minecraft:stripped_dark_oak_log
fill 88 179 351 88 180 351 minecraft:stripped_dark_oak_log
fill 88 179 358 88 180 358 minecraft:stripped_dark_oak_log
fill 48 180 323 48 180 324 minecraft:stripped_dark_oak_log
fill 48 180 326 48 180 327 minecraft:stripped_dark_oak_log
fill 48 180 329 48 180 331 minecraft:stripped_dark_oak_log
fill 48 180 333 48 180 334 minecraft:stripped_dark_oak_log
fill 48 180 336 48 180 338 minecraft:stripped_dark_oak_log
fill 48 180 340 48 180 341 minecraft:stripped_dark_oak_log
fill 48 180 343 48 180 345 minecraft:stripped_dark_oak_log
fill 48 180 347 48 180 348 minecraft:stripped_dark_oak_log
fill 48 180 350 48 180 352 minecraft:stripped_dark_oak_log
fill 48 180 354 48 180 355 minecraft:stripped_dark_oak_log
fill 48 180 357 48 180 359 minecraft:stripped_dark_oak_log
fill 48 180 361 48 180 362 minecraft:stripped_dark_oak_log
setblock 49 180 323 minecraft:stripped_dark_oak_log
fill 49 180 363 51 180 363 minecraft:stripped_dark_oak_log
fill 51 180 323 52 180 323 minecraft:stripped_dark_oak_log
fill 53 180 363 54 180 363 minecraft:stripped_dark_oak_log
fill 54 180 323 56 180 323 minecraft:stripped_dark_oak_log
fill 56 180 363 58 180 363 minecraft:stripped_dark_oak_log
fill 58 180 323 59 180 323 minecraft:stripped_dark_oak_log
fill 60 180 363 61 180 363 minecraft:stripped_dark_oak_log
fill 61 180 323 63 180 323 minecraft:stripped_dark_oak_log
fill 63 180 329 63 181 329 minecraft:cherry_leaves[persistent=true]
fill 63 180 363 65 180 363 minecraft:stripped_dark_oak_log
fill 64 180 332 65 181 332 minecraft:cherry_leaves[persistent=true]
fill 65 180 323 66 180 323 minecraft:stripped_dark_oak_log
fill 66 180 329 66 181 329 minecraft:cherry_leaves[persistent=true]
fill 66 180 331 66 182 331 minecraft:cherry_leaves[persistent=true]
fill 67 180 363 68 180 363 minecraft:stripped_dark_oak_log
fill 68 180 323 70 180 323 minecraft:stripped_dark_oak_log
fill 70 180 363 72 180 363 minecraft:stripped_dark_oak_log
fill 72 180 323 73 180 323 minecraft:stripped_dark_oak_log
fill 74 180 363 75 180 363 minecraft:stripped_dark_oak_log
fill 75 180 323 77 180 323 minecraft:stripped_dark_oak_log
fill 77 180 363 79 180 363 minecraft:stripped_dark_oak_log
fill 79 180 323 80 180 323 minecraft:stripped_dark_oak_log
fill 81 180 363 82 180 363 minecraft:stripped_dark_oak_log
fill 82 180 323 84 180 323 minecraft:stripped_dark_oak_log
fill 84 180 363 86 180 363 minecraft:stripped_dark_oak_log
fill 86 180 323 87 180 323 minecraft:stripped_dark_oak_log
fill 88 180 324 88 180 326 minecraft:stripped_dark_oak_log
fill 88 180 328 88 180 329 minecraft:stripped_dark_oak_log
fill 88 180 331 88 180 333 minecraft:stripped_dark_oak_log
fill 88 180 335 88 180 336 minecraft:stripped_dark_oak_log
fill 88 180 338 88 180 340 minecraft:stripped_dark_oak_log
fill 88 180 342 88 180 343 minecraft:stripped_dark_oak_log
fill 88 180 345 88 180 347 minecraft:stripped_dark_oak_log
fill 88 180 349 88 180 350 minecraft:stripped_dark_oak_log
fill 88 180 352 88 180 354 minecraft:stripped_dark_oak_log
fill 88 180 356 88 180 357 minecraft:stripped_dark_oak_log
fill 88 180 359 88 180 361 minecraft:stripped_dark_oak_log
setblock 88 180 363 minecraft:stripped_dark_oak_log
setblock 48 181 327 minecraft:stripped_dark_oak_log
setblock 48 181 334 minecraft:stripped_dark_oak_log
setblock 48 181 341 minecraft:stripped_dark_oak_log
setblock 48 181 348 minecraft:stripped_dark_oak_log
setblock 48 181 355 minecraft:stripped_dark_oak_log
setblock 48 181 362 minecraft:stripped_dark_oak_log
setblock 51 181 323 minecraft:stripped_dark_oak_log
setblock 54 181 363 minecraft:stripped_dark_oak_log
setblock 58 181 323 minecraft:stripped_dark_oak_log
setblock 61 181 363 minecraft:stripped_dark_oak_log
setblock 65 181 323 minecraft:stripped_dark_oak_log
setblock 68 181 363 minecraft:stripped_dark_oak_log
setblock 72 181 323 minecraft:stripped_dark_oak_log
setblock 75 181 363 minecraft:stripped_dark_oak_log
setblock 79 181 323 minecraft:stripped_dark_oak_log
setblock 82 181 363 minecraft:stripped_dark_oak_log
setblock 86 181 323 minecraft:stripped_dark_oak_log
setblock 88 181 328 minecraft:stripped_dark_oak_log
setblock 88 181 335 minecraft:stripped_dark_oak_log
setblock 88 181 342 minecraft:stripped_dark_oak_log
setblock 88 181 349 minecraft:stripped_dark_oak_log
setblock 88 181 356 minecraft:stripped_dark_oak_log
setblock 89 181 352 minecraft:red_concrete
fill 89 181 353 89 224 354 minecraft:spruce_planks
setblock 56 182 325 minecraft:red_concrete
setblock 63 182 325 minecraft:red_concrete
fill 63 182 330 65 182 330 minecraft:cherry_leaves[persistent=true]
fill 64 182 331 65 182 331 minecraft:cherry_leaves[persistent=true]
setblock 79 182 322 minecraft:red_concrete
fill 80 182 322 80 227 322 minecraft:spruce_planks
fill 89 182 352 89 226 352 minecraft:spruce_planks
setblock 48 183 329 minecraft:stripped_dark_oak_log
setblock 48 183 336 minecraft:stripped_dark_oak_log
setblock 48 183 343 minecraft:stripped_dark_oak_log
setblock 48 183 350 minecraft:stripped_dark_oak_log
setblock 48 183 357 minecraft:stripped_dark_oak_log
setblock 49 183 323 minecraft:stripped_dark_oak_log
setblock 49 183 363 minecraft:stripped_dark_oak_log
fill 53 183 353 53 186 353 minecraft:iron_bars
setblock 56 183 323 minecraft:stripped_dark_oak_log
fill 56 183 325 56 184 325 minecraft:shroomlight
setblock 56 183 363 minecraft:stripped_dark_oak_log
setblock 63 183 323 minecraft:stripped_dark_oak_log
fill 63 183 325 63 184 325 minecraft:shroomlight
setblock 63 183 363 minecraft:stripped_dark_oak_log
setblock 70 183 323 minecraft:stripped_dark_oak_log
setblock 70 183 363 minecraft:stripped_dark_oak_log
setblock 77 183 323 minecraft:stripped_dark_oak_log
setblock 77 183 363 minecraft:stripped_dark_oak_log
fill 79 183 322 79 226 322 minecraft:spruce_planks
setblock 84 183 323 minecraft:stripped_dark_oak_log
setblock 84 183 363 minecraft:stripped_dark_oak_log
setblock 88 183 326 minecraft:stripped_dark_oak_log
setblock 88 183 333 minecraft:stripped_dark_oak_log
setblock 88 183 340 minecraft:stripped_dark_oak_log
setblock 88 183 347 minecraft:stripped_dark_oak_log
setblock 88 183 354 minecraft:stripped_dark_oak_log
setblock 88 183 361 minecraft:stripped_dark_oak_log
setblock 47 184 361 minecraft:red_concrete
setblock 48 184 323 minecraft:stripped_dark_oak_log
setblock 48 184 330 minecraft:stripped_dark_oak_log
setblock 48 184 337 minecraft:stripped_dark_oak_log
setblock 48 184 344 minecraft:stripped_dark_oak_log
setblock 48 184 351 minecraft:stripped_dark_oak_log
setblock 48 184 358 minecraft:stripped_dark_oak_log
setblock 50 184 325 minecraft:light[level=15]
setblock 50 184 332 minecraft:light[level=12]
setblock 50 184 333 minecraft:light[level=15]
setblock 50 184 339 minecraft:light[level=12]
setblock 50 184 341 minecraft:light[level=15]
setblock 50 184 346 minecraft:light[level=12]
setblock 50 184 349 minecraft:light[level=15]
setblock 50 184 353 minecraft:light[level=12]
setblock 50 184 357 minecraft:light[level=15]
setblock 50 184 360 minecraft:light[level=12]
setblock 50 184 363 minecraft:stripped_dark_oak_log
setblock 51 184 322 minecraft:red_concrete
setblock 55 184 323 minecraft:stripped_dark_oak_log
setblock 57 184 325 minecraft:light[level=12]
setblock 57 184 332 minecraft:light[level=12]
setblock 57 184 339 minecraft:light[level=12]
setblock 57 184 346 minecraft:light[level=12]
setblock 57 184 353 minecraft:light[level=12]
setblock 57 184 360 minecraft:light[level=12]
setblock 57 184 363 minecraft:stripped_dark_oak_log
setblock 58 184 325 minecraft:light[level=15]
setblock 58 184 333 minecraft:light[level=15]
setblock 58 184 341 minecraft:light[level=15]
setblock 58 184 349 minecraft:light[level=15]
setblock 58 184 357 minecraft:light[level=15]
setblock 62 184 323 minecraft:stripped_dark_oak_log
setblock 64 184 325 minecraft:light[level=12]
setblock 64 184 332 minecraft:light[level=12]
setblock 64 184 339 minecraft:light[level=12]
setblock 64 184 346 minecraft:light[level=12]
setblock 64 184 353 minecraft:light[level=12]
setblock 64 184 360 minecraft:light[level=12]
setblock 64 184 363 minecraft:stripped_dark_oak_log
setblock 66 184 325 minecraft:light[level=15]
setblock 66 184 333 minecraft:light[level=15]
setblock 66 184 341 minecraft:light[level=15]
setblock 66 184 349 minecraft:light[level=15]
setblock 66 184 357 minecraft:light[level=15]
setblock 69 184 323 minecraft:stripped_dark_oak_log
setblock 71 184 325 minecraft:light[level=12]
setblock 71 184 332 minecraft:light[level=12]
setblock 71 184 339 minecraft:light[level=12]
setblock 71 184 346 minecraft:light[level=12]
setblock 71 184 353 minecraft:light[level=12]
setblock 71 184 360 minecraft:light[level=12]
setblock 71 184 363 minecraft:stripped_dark_oak_log
setblock 74 184 325 minecraft:light[level=15]
setblock 74 184 333 minecraft:light[level=15]
setblock 74 184 341 minecraft:light[level=15]
setblock 74 184 349 minecraft:light[level=15]
setblock 74 184 357 minecraft:light[level=15]
setblock 76 184 323 minecraft:stripped_dark_oak_log
setblock 78 184 325 minecraft:light[level=12]
setblock 78 184 332 minecraft:light[level=12]
setblock 78 184 339 minecraft:light[level=12]
setblock 78 184 346 minecraft:light[level=12]
setblock 78 184 353 minecraft:light[level=12]
setblock 78 184 360 minecraft:light[level=12]
setblock 78 184 363 minecraft:stripped_dark_oak_log
setblock 82 184 325 minecraft:light[level=15]
setblock 82 184 333 minecraft:light[level=15]
setblock 82 184 341 minecraft:light[level=15]
setblock 82 184 349 minecraft:light[level=15]
setblock 82 184 357 minecraft:light[level=15]
setblock 83 184 323 minecraft:stripped_dark_oak_log
setblock 85 184 325 minecraft:light[level=12]
setblock 85 184 332 minecraft:light[level=12]
setblock 85 184 339 minecraft:light[level=12]
setblock 85 184 346 minecraft:light[level=12]
setblock 85 184 353 minecraft:light[level=12]
setblock 85 184 363 minecraft:stripped_dark_oak_log
setblock 88 184 325 minecraft:stripped_dark_oak_log
setblock 88 184 332 minecraft:stripped_dark_oak_log
setblock 88 184 339 minecraft:stripped_dark_oak_log
setblock 88 184 346 minecraft:stripped_dark_oak_log
setblock 88 184 353 minecraft:stripped_dark_oak_log
setblock 88 184 360 minecraft:stripped_dark_oak_log
fill 47 185 361 47 226 361 minecraft:spruce_planks
setblock 48 185 324 minecraft:stripped_dark_oak_log
setblock 48 185 331 minecraft:stripped_dark_oak_log
setblock 48 185 338 minecraft:stripped_dark_oak_log
setblock 48 185 345 minecraft:stripped_dark_oak_log
setblock 48 185 352 minecraft:stripped_dark_oak_log
setblock 48 185 359 minecraft:stripped_dark_oak_log
fill 51 185 322 51 226 322 minecraft:spruce_planks
setblock 51 185 363 minecraft:stripped_dark_oak_log
setblock 54 185 323 minecraft:stripped_dark_oak_log
setblock 56 185 325 minecraft:red_concrete
setblock 58 185 363 minecraft:stripped_dark_oak_log
setblock 61 185 323 minecraft:stripped_dark_oak_log
setblock 63 185 325 minecraft:red_concrete
setblock 65 185 363 minecraft:stripped_dark_oak_log
setblock 68 185 323 minecraft:stripped_dark_oak_log
setblock 72 185 363 minecraft:stripped_dark_oak_log
setblock 75 185 323 minecraft:stripped_dark_oak_log
setblock 79 185 363 minecraft:stripped_dark_oak_log
fill 81 185 359 81 185 361 minecraft:dark_oak_planks
setblock 82 185 323 minecraft:stripped_dark_oak_log
fill 82 185 358 85 185 358 minecraft:dark_oak_planks
fill 82 185 362 84 185 362 minecraft:dark_oak_planks
setblock 85 185 359 minecraft:dark_oak_planks
setblock 85 185 361 minecraft:dark_oak_planks
setblock 86 185 363 minecraft:stripped_dark_oak_log
setblock 88 185 324 minecraft:stripped_dark_oak_log
setblock 88 185 331 minecraft:stripped_dark_oak_log
setblock 88 185 338 minecraft:stripped_dark_oak_log
setblock 88 185 345 minecraft:stripped_dark_oak_log
setblock 88 185 352 minecraft:stripped_dark_oak_log
setblock 88 185 359 minecraft:stripped_dark_oak_log
setblock 48 186 325 minecraft:stripped_dark_oak_log
setblock 48 186 332 minecraft:stripped_dark_oak_log
setblock 48 186 339 minecraft:stripped_dark_oak_log
setblock 48 186 346 minecraft:stripped_dark_oak_log
setblock 48 186 353 minecraft:stripped_dark_oak_log
setblock 48 186 360 minecraft:stripped_dark_oak_log
setblock 52 186 363 minecraft:stripped_dark_oak_log
setblock 53 186 323 minecraft:stripped_dark_oak_log
setblock 59 186 363 minecraft:stripped_dark_oak_log
setblock 60 186 323 minecraft:stripped_dark_oak_log
setblock 66 186 363 minecraft:stripped_dark_oak_log
setblock 67 186 323 minecraft:stripped_dark_oak_log
setblock 73 186 363 minecraft:stripped_dark_oak_log
setblock 74 186 323 minecraft:stripped_dark_oak_log
setblock 80 186 363 minecraft:stripped_dark_oak_log
setblock 81 186 323 minecraft:stripped_dark_oak_log
fill 81 186 351 83 189 351 minecraft:cherry_leaves[persistent=true]
fill 82 186 350 83 189 350 minecraft:cherry_leaves[persistent=true]
fill 82 186 352 83 188 352 minecraft:cherry_leaves[persistent=true]
setblock 87 186 363 minecraft:stripped_dark_oak_log
setblock 88 186 323 minecraft:stripped_dark_oak_log
setblock 88 186 330 minecraft:stripped_dark_oak_log
setblock 88 186 337 minecraft:stripped_dark_oak_log
setblock 88 186 344 minecraft:stripped_dark_oak_log
setblock 88 186 351 minecraft:stripped_dark_oak_log
setblock 88 186 358 minecraft:stripped_dark_oak_log
setblock 47 187 355 minecraft:red_concrete
setblock 48 187 326 minecraft:stripped_dark_oak_log
fill 48 187 333 48 190 333 minecraft:stripped_dark_oak_log
setblock 48 187 340 minecraft:stripped_dark_oak_log
setblock 48 187 347 minecraft:stripped_dark_oak_log
fill 48 187 350 53 187 353 minecraft:dark_oak_planks
fill 48 187 354 48 188 354 minecraft:stripped_dark_oak_log
fill 48 187 355 53 187 355 minecraft:dark_oak_planks
fill 48 187 357 53 187 357 minecraft:dark_oak_planks
setblock 48 187 361 minecraft:stripped_dark_oak_log
fill 49 187 349 53 187 349 minecraft:dark_oak_planks
fill 49 187 354 53 187 354 minecraft:dark_oak_planks
fill 49 187 356 53 187 356 minecraft:dark_oak_planks
setblock 52 187 323 minecraft:stripped_dark_oak_log
setblock 53 187 363 minecraft:stripped_dark_oak_log
setblock 59 187 323 minecraft:stripped_dark_oak_log
setblock 60 187 363 minecraft:stripped_dark_oak_log
setblock 66 187 323 minecraft:stripped_dark_oak_log
setblock 67 187 363 minecraft:stripped_dark_oak_log
setblock 67 187 364 minecraft:red_concrete
setblock 73 187 323 minecraft:stripped_dark_oak_log
setblock 74 187 363 minecraft:stripped_dark_oak_log
setblock 80 187 323 minecraft:stripped_dark_oak_log
fill 81 187 350 81 189 350 minecraft:cherry_leaves[persistent=true]
fill 81 187 352 81 189 352 minecraft:cherry_leaves[persistent=true]
setblock 81 187 363 minecraft:stripped_dark_oak_log
fill 82 187 349 83 188 349 minecraft:cherry_leaves[persistent=true]
fill 82 187 353 83 187 353 minecraft:cherry_leaves[persistent=true]
fill 84 187 350 84 187 352 minecraft:cherry_leaves[persistent=true]
setblock 87 187 323 minecraft:stripped_dark_oak_log
setblock 88 187 329 minecraft:stripped_dark_oak_log
setblock 88 187 336 minecraft:stripped_dark_oak_log
setblock 88 187 343 minecraft:stripped_dark_oak_log
setblock 88 187 350 minecraft:stripped_dark_oak_log
setblock 88 187 357 minecraft:stripped_dark_oak_log
setblock 88 187 363 minecraft:stripped_dark_oak_log
fill 47 188 355 47 226 355 minecraft:spruce_planks
setblock 48 188 327 minecraft:stripped_dark_oak_log
fill 48 188 332 48 190 332 minecraft:stripped_dark_oak_log
fill 48 188 334 48 190 334 minecraft:stripped_dark_oak_log
setblock 48 188 341 minecraft:stripped_dark_oak_log
setblock 48 188 348 minecraft:stripped_dark_oak_log
fill 48 188 350 53 188 353 minecraft:stripped_dark_oak_log
fill 48 188 355 53 188 355 minecraft:stripped_dark_oak_log
fill 48 188 357 53 188 357 minecraft:stripped_dark_oak_log
setblock 48 188 362 minecraft:stripped_dark_oak_log
fill 49 188 349 53 188 349 minecraft:stripped_dark_oak_log
fill 49 188 354 53 188 354 minecraft:stripped_dark_oak_log
fill 49 188 356 53 188 356 minecraft:stripped_dark_oak_log
setblock 51 188 323 minecraft:stripped_dark_oak_log
setblock 54 188 363 minecraft:stripped_dark_oak_log
setblock 58 188 323 minecraft:stripped_dark_oak_log
fill 58 188 359 58 193 359 minecraft:red_concrete
setblock 61 188 363 minecraft:stripped_dark_oak_log
setblock 65 188 323 minecraft:stripped_dark_oak_log
fill 67 188 364 67 223 364 minecraft:spruce_planks
setblock 68 188 363 minecraft:stripped_dark_oak_log
setblock 72 188 323 minecraft:stripped_dark_oak_log
setblock 75 188 363 minecraft:stripped_dark_oak_log
setblock 79 188 323 minecraft:stripped_dark_oak_log
setblock 82 188 363 minecraft:stripped_dark_oak_log
fill 84 188 350 84 188 351 minecraft:cherry_leaves[persistent=true]
setblock 86 188 323 minecraft:stripped_dark_oak_log
fill 87 188 332 87 189 334 minecraft:stripped_dark_oak_log
setblock 88 188 328 minecraft:stripped_dark_oak_log
fill 88 188 332 88 190 333 minecraft:stripped_dark_oak_log
setblock 88 188 335 minecraft:stripped_dark_oak_log
setblock 88 188 342 minecraft:stripped_dark_oak_log
setblock 88 188 349 minecraft:stripped_dark_oak_log
setblock 88 188 356 minecraft:stripped_dark_oak_log
fill 47 189 322 47 226 322 minecraft:spruce_planks
setblock 47 189 323 minecraft:red_concrete
fill 47 189 324 47 222 325 minecraft:spruce_planks
fill 47 189 352 47 192 354 minecraft:shroomlight
fill 49 189 332 49 190 334 minecraft:stripped_dark_oak_log
fill 49 189 364 50 226 364 minecraft:spruce_planks
fill 50 189 333 50 192 333 minecraft:stripped_dark_oak_log
setblock 51 189 364 minecraft:red_concrete
fill 52 189 364 55 195 364 minecraft:spruce_planks
fill 53 189 349 53 189 357 minecraft:red_concrete
setblock 82 189 352 minecraft:cherry_leaves[persistent=true]
setblock 84 189 350 minecraft:cherry_leaves[persistent=true]
fill 85 189 333 86 191 333 minecraft:stripped_dark_oak_log
fill 86 189 332 86 190 332 minecraft:stripped_dark_oak_log
fill 86 189 334 86 190 334 minecraft:stripped_dark_oak_log
fill 89 189 336 89 194 336 minecraft:spruce_planks
setblock 89 189 337 minecraft:red_concrete
fill 47 190 323 47 223 323 minecraft:spruce_planks
fill 48 190 323 48 190 327 minecraft:stripped_dark_oak_log
fill 48 190 329 48 190 331 minecraft:stripped_dark_oak_log
fill 48 190 336 48 190 341 minecraft:stripped_dark_oak_log
fill 48 190 343 48 190 348 minecraft:stripped_dark_oak_log
fill 48 190 350 48 190 355 minecraft:stripped_dark_oak_log
fill 48 190 357 48 190 362 minecraft:stripped_dark_oak_log
setblock 49 190 323 minecraft:stripped_dark_oak_log
fill 49 190 363 54 190 363 minecraft:stripped_dark_oak_log
setblock 50 190 325 minecraft:light[level=12]
fill 50 190 332 50 191 332 minecraft:stripped_dark_oak_log
fill 50 190 334 50 191 334 minecraft:stripped_dark_oak_log
setblock 50 190 339 minecraft:light[level=12]
setblock 50 190 346 minecraft:light[level=12]
setblock 50 190 353 minecraft:light[level=12]
setblock 50 190 360 minecraft:light[level=12]
fill 51 190 323 56 190 323 minecraft:stripped_dark_oak_log
fill 51 190 333 51 192 333 minecraft:stripped_dark_oak_log
fill 51 190 364 51 226 364 minecraft:spruce_planks
setblock 53 190 349 minecraft:stripped_dark_oak_log
setblock 53 190 353 minecraft:stripped_dark_oak_log
setblock 53 190 357 minecraft:stripped_dark_oak_log
fill 56 190 363 61 190 363 minecraft:stripped_dark_oak_log
setblock 57 190 325 minecraft:light[level=12]
setblock 57 190 332 minecraft:light[level=12]
setblock 57 190 339 minecraft:light[level=12]
setblock 57 190 346 minecraft:light[level=12]
setblock 57 190 353 minecraft:light[level=12]
fill 57 190 359 57 193 359 minecraft:red_concrete
setblock 57 190 360 minecraft:light[level=12]
fill 58 190 323 63 190 323 minecraft:stripped_dark_oak_log
fill 58 190 360 58 193 360 minecraft:red_concrete
fill 59 190 359 59 193 359 minecraft:red_concrete
fill 63 190 363 68 190 363 minecraft:stripped_dark_oak_log
setblock 64 190 325 minecraft:light[level=12]
setblock 64 190 332 minecraft:light[level=12]
setblock 64 190 339 minecraft:light[level=12]
setblock 64 190 346 minecraft:light[level=12]
setblock 64 190 353 minecraft:light[level=12]
setblock 64 190 360 minecraft:light[level=12]
fill 65 190 323 70 190 323 minecraft:stripped_dark_oak_log
fill 70 190 363 75 190 363 minecraft:stripped_dark_oak_log
setblock 71 190 325 minecraft:light[level=12]
setblock 71 190 332 minecraft:light[level=12]
setblock 71 190 339 minecraft:light[level=12]
setblock 71 190 346 minecraft:light[level=12]
setblock 71 190 353 minecraft:light[level=12]
setblock 71 190 360 minecraft:light[level=12]
fill 72 190 323 77 190 323 minecraft:stripped_dark_oak_log
fill 77 190 363 82 190 363 minecraft:stripped_dark_oak_log
setblock 78 190 325 minecraft:light[level=12]
setblock 78 190 332 minecraft:light[level=12]
setblock 78 190 339 minecraft:light[level=12]
setblock 78 190 346 minecraft:light[level=12]
setblock 78 190 353 minecraft:light[level=12]
setblock 78 190 360 minecraft:light[level=12]
fill 79 190 323 84 190 323 minecraft:stripped_dark_oak_log
fill 84 190 333 84 192 333 minecraft:stripped_dark_oak_log
fill 84 190 363 88 190 363 minecraft:stripped_dark_oak_log
setblock 85 190 325 minecraft:light[level=12]
fill 85 190 332 85 191 332 minecraft:stripped_dark_oak_log
fill 85 190 334 85 191 334 minecraft:stripped_dark_oak_log
setblock 85 190 339 minecraft:light[level=12]
setblock 85 190 346 minecraft:light[level=12]
setblock 85 190 353 minecraft:light[level=12]
fill 86 190 323 88 190 323 minecraft:stripped_dark_oak_log
fill 86 190 351 86 191 357 minecraft:iron_bars
setblock 87 190 333 minecraft:stripped_dark_oak_log
fill 88 190 324 88 190 326 minecraft:stripped_dark_oak_log
fill 88 190 328 88 190 331 minecraft:stripped_dark_oak_log
fill 88 190 335 88 190 340 minecraft:stripped_dark_oak_log
fill 88 190 342 88 190 347 minecraft:stripped_dark_oak_log
fill 88 190 349 88 190 354 minecraft:stripped_dark_oak_log
fill 88 190 356 88 190 361 minecraft:stripped_dark_oak_log
fill 89 190 337 89 229 337 minecraft:spruce_planks
setblock 48 191 323 minecraft:stripped_dark_oak_log
setblock 48 191 330 minecraft:stripped_dark_oak_log
setblock 48 191 333 minecraft:red_concrete
setblock 48 191 337 minecraft:stripped_dark_oak_log
setblock 48 191 344 minecraft:stripped_dark_oak_log
setblock 48 191 351 minecraft:stripped_dark_oak_log
setblock 48 191 358 minecraft:stripped_dark_oak_log
setblock 49 191 333 minecraft:stripped_dark_oak_log
setblock 50 191 363 minecraft:stripped_dark_oak_log
fill 51 191 332 52 192 332 minecraft:stripped_dark_oak_log
fill 51 191 334 52 192 334 minecraft:stripped_dark_oak_log
fill 52 191 333 52 193 333 minecraft:stripped_dark_oak_log
setblock 54 191 324 minecraft:red_concrete
setblock 55 191 323 minecraft:stripped_dark_oak_log
fill 57 191 358 59 193 358 minecraft:red_concrete
fill 57 191 360 57 193 360 minecraft:red_concrete
setblock 57 191 363 minecraft:stripped_dark_oak_log
fill 59 191 360 59 193 360 minecraft:red_concrete
setblock 62 191 323 minecraft:stripped_dark_oak_log
setblock 64 191 363 minecraft:stripped_dark_oak_log
setblock 69 191 323 minecraft:stripped_dark_oak_log
setblock 71 191 363 minecraft:stripped_dark_oak_log
setblock 76 191 323 minecraft:stripped_dark_oak_log
setblock 78 191 363 minecraft:stripped_dark_oak_log
fill 78 191 364 81 210 364 minecraft:spruce_planks
setblock 81 191 322 minecraft:red_concrete
setblock 82 191 364 minecraft:red_concrete
setblock 83 191 323 minecraft:stripped_dark_oak_log
fill 83 191 332 83 192 334 minecraft:stripped_dark_oak_log
fill 83 191 364 84 222 364 minecraft:spruce_planks
fill 84 191 332 84 192 332 minecraft:stripped_dark_oak_log
fill 84 191 334 84 192 334 minecraft:stripped_dark_oak_log
setblock 85 191 363 minecraft:stripped_dark_oak_log
setblock 87 191 333 minecraft:red_concrete
setblock 88 191 325 minecraft:stripped_dark_oak_log
setblock 88 191 332 minecraft:stripped_dark_oak_log
setblock 88 191 339 minecraft:stripped_dark_oak_log
setblock 88 191 346 minecraft:stripped_dark_oak_log
setblock 88 191 353 minecraft:stripped_dark_oak_log
setblock 88 191 360 minecraft:stripped_dark_oak_log
setblock 47 192 341 minecraft:red_concrete
setblock 48 192 324 minecraft:stripped_dark_oak_log
setblock 48 192 331 minecraft:stripped_dark_oak_log
setblock 48 192 338 minecraft:stripped_dark_oak_log
setblock 48 192 345 minecraft:stripped_dark_oak_log
setblock 48 192 352 minecraft:stripped_dark_oak_log
setblock 48 192 359 minecraft:stripped_dark_oak_log
setblock 49 192 333 minecraft:red_concrete
setblock 50 192 325 minecraft:light[level=15]
setblock 50 192 341 minecraft:light[level=15]
setblock 50 192 349 minecraft:light[level=15]
setblock 50 192 357 minecraft:light[level=15]
setblock 51 192 363 minecraft:stripped_dark_oak_log
fill 53 192 332 53 193 334 minecraft:stripped_dark_oak_log
setblock 54 192 323 minecraft:stripped_dark_oak_log
fill 54 192 324 54 193 324 minecraft:shroomlight
fill 54 192 333 54 194 333 minecraft:stripped_dark_oak_log
fill 56 192 359 56 193 359 minecraft:red_concrete
fill 57 192 361 59 193 361 minecraft:red_concrete
setblock 58 192 325 minecraft:light[level=15]
setblock 58 192 333 minecraft:light[level=15]
setblock 58 192 341 minecraft:light[level=15]
setblock 58 192 349 minecraft:light[level=15]
setblock 58 192 357 minecraft:light[level=15]
setblock 58 192 363 minecraft:stripped_dark_oak_log
fill 60 192 359 60 193 359 minecraft:red_concrete
setblock 61 192 323 minecraft:stripped_dark_oak_log
setblock 65 192 363 minecraft:stripped_dark_oak_log
setblock 66 192 325 minecraft:light[level=15]
setblock 66 192 333 minecraft:light[level=15]
setblock 66 192 341 minecraft:light[level=15]
setblock 66 192 349 minecraft:light[level=15]
setblock 66 192 357 minecraft:light[level=15]
setblock 68 192 323 minecraft:stripped_dark_oak_log
setblock 72 192 363 minecraft:stripped_dark_oak_log
setblock 74 192 325 minecraft:light[level=15]
setblock 74 192 333 minecraft:light[level=15]
setblock 74 192 341 minecraft:light[level=15]
setblock 74 192 349 minecraft:light[level=15]
setblock 74 192 357 minecraft:light[level=15]
setblock 75 192 323 minecraft:stripped_dark_oak_log
setblock 79 192 363 minecraft:stripped_dark_oak_log
fill 81 192 322 81 224 322 minecraft:spruce_planks
fill 81 192 333 82 194 333 minecraft:stripped_dark_oak_log
setblock 82 192 323 minecraft:stripped_dark_oak_log
setblock 82 192 325 minecraft:light[level=15]
fill 82 192 332 82 193 332 minecraft:stripped_dark_oak_log
fill 82 192 334 82 193 334 minecraft:stripped_dark_oak_log
setblock 82 192 341 minecraft:light[level=15]
setblock 82 192 349 minecraft:light[level=15]
setblock 82 192 357 minecraft:light[level=15]
fill 82 192 364 82 226 364 minecraft:spruce_planks
setblock 85 192 333 minecraft:stripped_dark_oak_log
setblock 86 192 333 minecraft:red_concrete
setblock 86 192 363 minecraft:stripped_dark_oak_log
setblock 88 192 324 minecraft:stripped_dark_oak_log
setblock 88 192 331 minecraft:stripped_dark_oak_log
setblock 88 192 338 minecraft:stripped_dark_oak_log
setblock 88 192 345 minecraft:stripped_dark_oak_log
setblock 88 192 352 minecraft:stripped_dark_oak_log
setblock 88 192 359 minecraft:stripped_dark_oak_log
fill 47 193 341 47 226 341 minecraft:spruce_planks
fill 47 193 352 47 198 354 minecraft:spruce_planks
setblock 48 193 325 minecraft:stripped_dark_oak_log
setblock 48 193 332 minecraft:stripped_dark_oak_log
setblock 48 193 339 minecraft:stripped_dark_oak_log
setblock 48 193 346 minecraft:stripped_dark_oak_log
setblock 48 193 353 minecraft:stripped_dark_oak_log
setblock 48 193 360 minecraft:stripped_dark_oak_log
setblock 51 193 333 minecraft:red_concrete
setblock 52 193 363 minecraft:stripped_dark_oak_log
setblock 53 193 323 minecraft:stripped_dark_oak_log
fill 54 193 332 54 194 332 minecraft:stripped_dark_oak_log
fill 54 193 334 54 194 334 minecraft:stripped_dark_oak_log
fill 55 193 333 55 195 333 minecraft:stripped_dark_oak_log
setblock 56 193 358 minecraft:red_concrete
setblock 56 193 360 minecraft:red_concrete
fill 57 193 357 59 193 357 minecraft:red_concrete
fill 59 193 363 59 213 363 minecraft:stripped_dark_oak_log
setblock 60 193 323 minecraft:stripped_dark_oak_log
setblock 60 193 358 minecraft:red_concrete
setblock 60 193 360 minecraft:red_concrete
setblock 66 193 363 minecraft:stripped_dark_oak_log
setblock 67 193 323 minecraft:stripped_dark_oak_log
setblock 69 193 322 minecraft:red_concrete
setblock 73 193 363 minecraft:stripped_dark_oak_log
setblock 74 193 323 minecraft:stripped_dark_oak_log
fill 80 193 333 80 195 333 minecraft:stripped_dark_oak_log
setblock 80 193 363 minecraft:stripped_dark_oak_log
setblock 81 193 323 minecraft:stripped_dark_oak_log
fill 81 193 332 81 194 332 minecraft:stripped_dark_oak_log
fill 81 193 334 81 194 334 minecraft:stripped_dark_oak_log
fill 81 193 359 81 193 361 minecraft:dark_oak_planks
fill 82 193 358 85 193 358 minecraft:dark_oak_planks
fill 82 193 362 84 193 362 minecraft:dark_oak_planks
setblock 83 193 333 minecraft:stripped_dark_oak_log
setblock 84 193 333 minecraft:red_concrete
setblock 85 193 359 minecraft:dark_oak_planks
setblock 85 193 361 minecraft:dark_oak_planks
setblock 87 193 363 minecraft:stripped_dark_oak_log
setblock 88 193 323 minecraft:stripped_dark_oak_log
setblock 88 193 330 minecraft:stripped_dark_oak_log
setblock 88 193 337 minecraft:stripped_dark_oak_log
setblock 88 193 344 minecraft:stripped_dark_oak_log
setblock 88 193 351 minecraft:stripped_dark_oak_log
setblock 88 193 358 minecraft:stripped_dark_oak_log
setblock 48 194 326 minecraft:stripped_dark_oak_log
setblock 48 194 333 minecraft:stripped_dark_oak_log
setblock 48 194 340 minecraft:stripped_dark_oak_log
setblock 48 194 347 minecraft:stripped_dark_oak_log
setblock 48 194 354 minecraft:stripped_dark_oak_log
setblock 48 194 361 minecraft:stripped_dark_oak_log
setblock 52 194 323 minecraft:stripped_dark_oak_log
setblock 52 194 333 minecraft:red_concrete
setblock 53 194 333 minecraft:stripped_dark_oak_log
setblock 53 194 363 minecraft:stripped_dark_oak_log
setblock 54 194 324 minecraft:red_concrete
fill 55 194 332 56 194 332 minecraft:stripped_dark_oak_log
fill 55 194 334 56 194 334 minecraft:stripped_dark_oak_log
fill 55 194 356 61 195 362 minecraft:stripped_dark_oak_log
fill 56 194 333 57 196 333 minecraft:stripped_dark_oak_log
fill 56 194 363 58 195 363 minecraft:stripped_dark_oak_log
setblock 59 194 323 minecraft:stripped_dark_oak_log
setblock 60 194 322 minecraft:red_concrete
fill 60 194 363 61 195 363 minecraft:stripped_dark_oak_log
setblock 66 194 323 minecraft:stripped_dark_oak_log
setblock 67 194 363 minecraft:stripped_dark_oak_log
fill 69 194 322 69 202 322 minecraft:spruce_planks
setblock 73 194 323 minecraft:stripped_dark_oak_log
setblock 74 194 363 minecraft:stripped_dark_oak_log
fill 78 194 333 79 196 333 minecraft:stripped_dark_oak_log
fill 79 194 332 80 194 332 minecraft:stripped_dark_oak_log
fill 79 194 334 80 194 334 minecraft:stripped_dark_oak_log
setblock 80 194 323 minecraft:stripped_dark_oak_log
setblock 81 194 363 minecraft:stripped_dark_oak_log
setblock 83 194 333 minecraft:red_concrete
setblock 87 194 323 minecraft:stripped_dark_oak_log
setblock 88 194 329 minecraft:stripped_dark_oak_log
setblock 88 194 336 minecraft:stripped_dark_oak_log
setblock 88 194 343 minecraft:stripped_dark_oak_log
setblock 88 194 350 minecraft:stripped_dark_oak_log
setblock 88 194 357 minecraft:stripped_dark_oak_log
setblock 88 194 363 minecraft:stripped_dark_oak_log
setblock 48 195 327 minecraft:stripped_dark_oak_log
setblock 48 195 334 minecraft:stripped_dark_oak_log
setblock 48 195 341 minecraft:stripped_dark_oak_log
setblock 48 195 348 minecraft:stripped_dark_oak_log
setblock 48 195 355 minecraft:stripped_dark_oak_log
setblock 48 195 362 minecraft:stripped_dark_oak_log
setblock 51 195 323 minecraft:stripped_dark_oak_log
setblock 54 195 333 minecraft:red_concrete
setblock 54 195 363 minecraft:stripped_dark_oak_log
fill 56 195 332 58 195 332 minecraft:stripped_dark_oak_log
fill 56 195 334 58 195 334 minecraft:stripped_dark_oak_log
setblock 58 195 323 minecraft:stripped_dark_oak_log
fill 58 195 333 59 197 333 minecraft:stripped_dark_oak_log
fill 60 195 322 60 226 322 minecraft:spruce_planks
setblock 65 195 323 minecraft:stripped_dark_oak_log
setblock 68 195 363 minecraft:stripped_dark_oak_log
setblock 72 195 323 minecraft:stripped_dark_oak_log
setblock 75 195 363 minecraft:stripped_dark_oak_log
fill 76 195 333 77 197 333 minecraft:stripped_dark_oak_log
fill 77 195 332 79 195 332 minecraft:stripped_dark_oak_log
fill 77 195 334 79 195 334 minecraft:stripped_dark_oak_log
setblock 79 195 323 minecraft:stripped_dark_oak_log
setblock 81 195 333 minecraft:red_concrete
setblock 82 195 363 minecraft:stripped_dark_oak_log
setblock 86 195 323 minecraft:stripped_dark_oak_log
setblock 88 195 328 minecraft:stripped_dark_oak_log
setblock 88 195 335 minecraft:stripped_dark_oak_log
setblock 88 195 342 minecraft:stripped_dark_oak_log
setblock 88 195 349 minecraft:stripped_dark_oak_log
setblock 88 195 356 minecraft:stripped_dark_oak_log
fill 89 195 328 89 222 329 minecraft:spruce_planks
setblock 89 195 330 minecraft:red_concrete
fill 89 195 331 89 226 331 minecraft:spruce_planks
setblock 89 195 336 minecraft:red_concrete
setblock 50 196 325 minecraft:light[level=12]
setblock 50 196 332 minecraft:light[level=12]
setblock 50 196 339 minecraft:light[level=12]
setblock 50 196 346 minecraft:light[level=12]
setblock 50 196 353 minecraft:light[level=12]
setblock 50 196 360 minecraft:light[level=12]
fill 52 196 364 52 223 364 minecraft:spruce_planks
setblock 53 196 364 minecraft:red_concrete
fill 54 196 364 55 222 364 minecraft:spruce_planks
setblock 55 196 333 minecraft:red_concrete
setblock 55 196 356 minecraft:shroomlight
fill 55 196 357 55 213 357 minecraft:stripped_dark_oak_log
setblock 55 196 358 minecraft:shroomlight
fill 55 196 359 55 213 359 minecraft:stripped_dark_oak_log
setblock 55 196 360 minecraft:shroomlight
fill 55 196 361 55 213 361 minecraft:stripped_dark_oak_log
setblock 55 196 362 minecraft:shroomlight
fill 56 196 356 56 213 356 minecraft:stripped_dark_oak_log
setblock 56 196 357 minecraft:shroomlight
fill 56 196 358 56 213 358 minecraft:stripped_dark_oak_log
setblock 56 196 359 minecraft:shroomlight
fill 56 196 360 56 213 360 minecraft:stripped_dark_oak_log
setblock 56 196 361 minecraft:shroomlight
fill 56 196 362 56 213 362 minecraft:stripped_dark_oak_log
setblock 56 196 363 minecraft:shroomlight
setblock 57 196 325 minecraft:light[level=12]
fill 57 196 332 60 196 332 minecraft:stripped_dark_oak_log
fill 57 196 334 60 196 334 minecraft:stripped_dark_oak_log
schedule function dropper:buildpart/73_3 1t
