fill 124 150 317 125 151 317 minecraft:red_concrete
fill 126 150 275 127 151 275 minecraft:white_concrete
fill 126 150 317 127 151 317 minecraft:white_concrete
fill 128 150 275 129 151 275 minecraft:red_concrete
fill 128 150 317 129 151 317 minecraft:red_concrete
fill 130 150 275 131 151 275 minecraft:white_concrete
fill 130 150 317 131 151 317 minecraft:white_concrete
fill 132 150 275 133 151 275 minecraft:red_concrete
fill 132 150 317 133 151 317 minecraft:red_concrete
fill 134 150 275 135 151 275 minecraft:white_concrete
fill 134 150 317 135 151 317 minecraft:white_concrete
fill 136 150 276 136 151 276 minecraft:white_concrete
fill 136 150 277 136 151 278 minecraft:red_concrete
fill 136 150 279 136 151 280 minecraft:white_concrete
fill 136 150 281 136 151 282 minecraft:red_concrete
fill 136 150 283 136 151 284 minecraft:white_concrete
fill 136 150 285 136 151 286 minecraft:red_concrete
fill 136 150 287 136 151 288 minecraft:white_concrete
fill 136 150 289 136 151 290 minecraft:red_concrete
fill 136 150 291 136 151 292 minecraft:white_concrete
fill 136 150 293 136 151 294 minecraft:red_concrete
fill 136 150 295 136 151 296 minecraft:white_concrete
fill 136 150 297 136 151 298 minecraft:red_concrete
fill 136 150 299 136 151 300 minecraft:white_concrete
fill 136 150 301 136 151 302 minecraft:red_concrete
fill 136 150 303 136 151 304 minecraft:white_concrete
fill 136 150 305 136 151 306 minecraft:red_concrete
fill 136 150 307 136 151 308 minecraft:white_concrete
fill 136 150 309 136 151 310 minecraft:red_concrete
fill 136 150 311 136 151 312 minecraft:white_concrete
fill 136 150 313 136 151 314 minecraft:red_concrete
fill 136 150 315 136 151 316 minecraft:white_concrete
fill 136 150 317 136 151 317 minecraft:red_concrete
fill 94 152 275 94 153 276 minecraft:red_concrete
fill 94 152 277 94 153 278 minecraft:white_concrete
fill 94 152 279 94 153 280 minecraft:red_concrete
fill 94 152 281 94 153 282 minecraft:white_concrete
fill 94 152 283 94 153 284 minecraft:red_concrete
fill 94 152 285 94 153 286 minecraft:white_concrete
fill 94 152 287 94 153 288 minecraft:red_concrete
fill 94 152 289 94 153 290 minecraft:white_concrete
fill 94 152 291 94 153 292 minecraft:red_concrete
fill 94 152 293 94 153 294 minecraft:white_concrete
fill 94 152 295 94 153 296 minecraft:red_concrete
fill 94 152 297 94 153 298 minecraft:white_concrete
fill 94 152 299 94 153 300 minecraft:red_concrete
fill 94 152 301 94 153 302 minecraft:white_concrete
fill 94 152 303 94 153 304 minecraft:red_concrete
fill 94 152 305 94 153 306 minecraft:white_concrete
fill 94 152 307 94 153 308 minecraft:red_concrete
fill 94 152 309 94 153 310 minecraft:white_concrete
fill 94 152 311 94 153 312 minecraft:red_concrete
fill 94 152 313 94 153 314 minecraft:white_concrete
fill 94 152 315 94 153 316 minecraft:red_concrete
fill 95 152 275 95 153 275 minecraft:red_concrete
fill 95 152 317 95 153 317 minecraft:red_concrete
fill 96 152 275 97 153 275 minecraft:white_concrete
fill 96 152 317 97 153 317 minecraft:white_concrete
setblock 97 152 278 minecraft:light[level=12]
setblock 97 152 285 minecraft:light[level=12]
setblock 97 152 292 minecraft:light[level=12]
setblock 97 152 299 minecraft:light[level=12]
setblock 97 152 306 minecraft:light[level=12]
setblock 97 152 313 minecraft:light[level=12]
fill 98 152 275 99 153 275 minecraft:red_concrete
fill 98 152 317 99 153 317 minecraft:red_concrete
fill 100 152 275 101 153 275 minecraft:white_concrete
fill 100 152 317 101 153 317 minecraft:white_concrete
fill 102 152 275 103 153 275 minecraft:red_concrete
fill 102 152 317 103 153 317 minecraft:red_concrete
fill 104 152 275 105 153 275 minecraft:white_concrete
setblock 104 152 278 minecraft:light[level=12]
setblock 104 152 285 minecraft:light[level=12]
setblock 104 152 292 minecraft:light[level=12]
setblock 104 152 299 minecraft:light[level=12]
setblock 104 152 306 minecraft:light[level=12]
setblock 104 152 313 minecraft:light[level=12]
fill 104 152 317 105 153 317 minecraft:white_concrete
fill 106 152 275 107 153 275 minecraft:red_concrete
fill 106 152 317 107 153 317 minecraft:red_concrete
fill 108 152 275 109 153 275 minecraft:white_concrete
fill 108 152 317 109 153 317 minecraft:white_concrete
fill 110 152 275 111 153 275 minecraft:red_concrete
fill 110 152 317 111 153 317 minecraft:red_concrete
setblock 111 152 278 minecraft:light[level=12]
setblock 111 152 285 minecraft:light[level=12]
setblock 111 152 292 minecraft:light[level=12]
setblock 111 152 299 minecraft:light[level=12]
setblock 111 152 306 minecraft:light[level=12]
setblock 111 152 313 minecraft:light[level=12]
fill 112 152 275 113 153 275 minecraft:white_concrete
fill 112 152 317 113 153 317 minecraft:white_concrete
fill 114 152 275 115 153 275 minecraft:red_concrete
fill 114 152 317 115 153 317 minecraft:red_concrete
fill 116 152 275 117 153 275 minecraft:white_concrete
fill 116 152 317 117 153 317 minecraft:white_concrete
fill 118 152 275 119 153 275 minecraft:red_concrete
setblock 118 152 278 minecraft:light[level=12]
setblock 118 152 285 minecraft:light[level=12]
setblock 118 152 292 minecraft:light[level=12]
setblock 118 152 299 minecraft:light[level=12]
setblock 118 152 306 minecraft:light[level=12]
setblock 118 152 313 minecraft:light[level=12]
fill 118 152 317 119 153 317 minecraft:red_concrete
fill 120 152 275 121 153 275 minecraft:white_concrete
fill 120 152 317 121 153 317 minecraft:white_concrete
fill 122 152 275 123 153 275 minecraft:red_concrete
fill 122 152 317 123 153 317 minecraft:red_concrete
fill 124 152 275 125 153 275 minecraft:white_concrete
fill 124 152 317 125 153 317 minecraft:white_concrete
setblock 125 152 278 minecraft:light[level=12]
setblock 125 152 285 minecraft:light[level=12]
setblock 125 152 292 minecraft:light[level=12]
setblock 125 152 299 minecraft:light[level=12]
setblock 125 152 306 minecraft:light[level=12]
setblock 125 152 313 minecraft:light[level=12]
fill 126 152 275 127 153 275 minecraft:red_concrete
fill 126 152 317 127 153 317 minecraft:red_concrete
fill 128 152 275 129 153 275 minecraft:white_concrete
fill 128 152 317 129 153 317 minecraft:white_concrete
fill 130 152 275 131 153 275 minecraft:red_concrete
fill 130 152 317 131 153 317 minecraft:red_concrete
fill 132 152 275 133 153 275 minecraft:white_concrete
setblock 132 152 278 minecraft:light[level=12]
setblock 132 152 285 minecraft:light[level=12]
setblock 132 152 292 minecraft:light[level=12]
setblock 132 152 299 minecraft:light[level=12]
setblock 132 152 306 minecraft:light[level=12]
setblock 132 152 313 minecraft:light[level=12]
fill 132 152 317 133 153 317 minecraft:white_concrete
fill 134 152 275 135 153 275 minecraft:red_concrete
fill 134 152 317 135 153 317 minecraft:red_concrete
fill 136 152 276 136 153 276 minecraft:red_concrete
fill 136 152 277 136 153 278 minecraft:white_concrete
fill 136 152 279 136 153 280 minecraft:red_concrete
fill 136 152 281 136 153 282 minecraft:white_concrete
fill 136 152 283 136 153 284 minecraft:red_concrete
fill 136 152 285 136 153 286 minecraft:white_concrete
fill 136 152 287 136 153 288 minecraft:red_concrete
fill 136 152 289 136 153 290 minecraft:white_concrete
fill 136 152 291 136 153 292 minecraft:red_concrete
fill 136 152 293 136 153 294 minecraft:white_concrete
fill 136 152 295 136 153 296 minecraft:red_concrete
fill 136 152 297 136 153 298 minecraft:white_concrete
fill 136 152 299 136 153 300 minecraft:red_concrete
fill 136 152 301 136 153 302 minecraft:white_concrete
fill 136 152 303 136 153 304 minecraft:red_concrete
fill 136 152 305 136 153 306 minecraft:white_concrete
fill 136 152 307 136 153 308 minecraft:red_concrete
fill 136 152 309 136 153 310 minecraft:white_concrete
fill 136 152 311 136 153 312 minecraft:red_concrete
fill 136 152 313 136 153 314 minecraft:white_concrete
fill 136 152 315 136 153 316 minecraft:red_concrete
fill 136 152 317 136 153 317 minecraft:white_concrete
fill 94 154 275 94 155 276 minecraft:white_concrete
fill 94 154 277 94 155 278 minecraft:red_concrete
fill 94 154 279 94 155 280 minecraft:white_concrete
fill 94 154 281 94 155 282 minecraft:red_concrete
fill 94 154 283 94 155 284 minecraft:white_concrete
fill 94 154 285 94 155 286 minecraft:red_concrete
fill 94 154 287 94 155 288 minecraft:white_concrete
fill 94 154 289 94 155 290 minecraft:red_concrete
fill 94 154 291 94 155 292 minecraft:white_concrete
fill 94 154 293 94 155 294 minecraft:red_concrete
fill 94 154 295 94 155 296 minecraft:white_concrete
fill 94 154 297 94 155 298 minecraft:red_concrete
fill 94 154 299 94 155 300 minecraft:white_concrete
fill 94 154 301 94 155 302 minecraft:red_concrete
fill 94 154 303 94 155 304 minecraft:white_concrete
fill 94 154 305 94 155 306 minecraft:red_concrete
fill 94 154 307 94 155 308 minecraft:white_concrete
fill 94 154 309 94 155 310 minecraft:red_concrete
fill 94 154 311 94 155 312 minecraft:white_concrete
fill 94 154 313 94 155 314 minecraft:red_concrete
fill 94 154 315 94 155 316 minecraft:white_concrete
fill 95 154 275 95 155 275 minecraft:white_concrete
fill 95 154 317 95 155 317 minecraft:white_concrete
fill 96 154 275 97 155 275 minecraft:red_concrete
fill 96 154 317 97 155 317 minecraft:red_concrete
setblock 97 154 278 minecraft:light[level=15]
setblock 97 154 286 minecraft:light[level=15]
setblock 97 154 294 minecraft:light[level=15]
setblock 97 154 302 minecraft:light[level=15]
setblock 97 154 310 minecraft:light[level=15]
fill 98 154 275 99 155 275 minecraft:white_concrete
fill 98 154 317 99 155 317 minecraft:white_concrete
fill 100 154 275 101 155 275 minecraft:red_concrete
fill 100 154 317 101 155 317 minecraft:red_concrete
fill 102 154 275 103 155 275 minecraft:white_concrete
fill 102 154 317 103 155 317 minecraft:white_concrete
fill 104 154 275 105 155 275 minecraft:red_concrete
fill 104 154 317 105 155 317 minecraft:red_concrete
setblock 105 154 278 minecraft:light[level=15]
setblock 105 154 286 minecraft:light[level=15]
setblock 105 154 294 minecraft:light[level=15]
setblock 105 154 302 minecraft:light[level=15]
setblock 105 154 310 minecraft:light[level=15]
fill 106 154 275 107 155 275 minecraft:white_concrete
fill 106 154 317 107 155 317 minecraft:white_concrete
fill 108 154 275 109 155 275 minecraft:red_concrete
fill 108 154 317 109 155 317 minecraft:red_concrete
fill 110 154 275 111 155 275 minecraft:white_concrete
fill 110 154 317 111 155 317 minecraft:white_concrete
fill 112 154 275 113 155 275 minecraft:red_concrete
fill 112 154 317 113 155 317 minecraft:red_concrete
setblock 113 154 278 minecraft:light[level=15]
setblock 113 154 286 minecraft:light[level=15]
setblock 113 154 294 minecraft:light[level=15]
setblock 113 154 302 minecraft:light[level=15]
setblock 113 154 310 minecraft:light[level=15]
fill 114 154 275 115 155 275 minecraft:white_concrete
fill 114 154 317 115 155 317 minecraft:white_concrete
fill 116 154 275 117 155 275 minecraft:red_concrete
fill 116 154 317 117 155 317 minecraft:red_concrete
fill 118 154 275 119 155 275 minecraft:white_concrete
fill 118 154 317 119 155 317 minecraft:white_concrete
fill 120 154 275 121 155 275 minecraft:red_concrete
fill 120 154 317 121 155 317 minecraft:red_concrete
setblock 121 154 278 minecraft:light[level=15]
setblock 121 154 286 minecraft:light[level=15]
setblock 121 154 294 minecraft:light[level=15]
setblock 121 154 302 minecraft:light[level=15]
setblock 121 154 310 minecraft:light[level=15]
fill 122 154 275 123 155 275 minecraft:white_concrete
fill 122 154 317 123 155 317 minecraft:white_concrete
fill 124 154 275 125 155 275 minecraft:red_concrete
fill 124 154 317 125 155 317 minecraft:red_concrete
fill 126 154 275 127 155 275 minecraft:white_concrete
fill 126 154 317 127 155 317 minecraft:white_concrete
fill 128 154 275 129 155 275 minecraft:red_concrete
fill 128 154 317 129 155 317 minecraft:red_concrete
setblock 129 154 278 minecraft:light[level=15]
setblock 129 154 286 minecraft:light[level=15]
setblock 129 154 294 minecraft:light[level=15]
setblock 129 154 302 minecraft:light[level=15]
setblock 129 154 310 minecraft:light[level=15]
fill 130 154 275 131 155 275 minecraft:white_concrete
fill 130 154 317 131 155 317 minecraft:white_concrete
fill 132 154 275 133 155 275 minecraft:red_concrete
fill 132 154 317 133 155 317 minecraft:red_concrete
fill 134 154 275 135 155 275 minecraft:white_concrete
fill 134 154 317 135 155 317 minecraft:white_concrete
fill 136 154 276 136 155 276 minecraft:white_concrete
fill 136 154 277 136 155 278 minecraft:red_concrete
fill 136 154 279 136 155 280 minecraft:white_concrete
fill 136 154 281 136 155 282 minecraft:red_concrete
fill 136 154 283 136 155 284 minecraft:white_concrete
fill 136 154 285 136 155 286 minecraft:red_concrete
fill 136 154 287 136 155 288 minecraft:white_concrete
fill 136 154 289 136 155 290 minecraft:red_concrete
fill 136 154 291 136 155 292 minecraft:white_concrete
fill 136 154 293 136 155 294 minecraft:red_concrete
fill 136 154 295 136 155 296 minecraft:white_concrete
fill 136 154 297 136 155 298 minecraft:red_concrete
fill 136 154 299 136 155 300 minecraft:white_concrete
fill 136 154 301 136 155 302 minecraft:red_concrete
fill 136 154 303 136 155 304 minecraft:white_concrete
fill 136 154 305 136 155 306 minecraft:red_concrete
fill 136 154 307 136 155 308 minecraft:white_concrete
fill 136 154 309 136 155 310 minecraft:red_concrete
fill 136 154 311 136 155 312 minecraft:white_concrete
fill 136 154 313 136 155 314 minecraft:red_concrete
fill 136 154 315 136 155 316 minecraft:white_concrete
fill 136 154 317 136 155 317 minecraft:red_concrete
fill 94 156 275 94 157 276 minecraft:red_concrete
fill 94 156 277 94 157 278 minecraft:white_concrete
fill 94 156 279 94 157 280 minecraft:red_concrete
fill 94 156 281 94 157 282 minecraft:white_concrete
fill 94 156 283 94 157 284 minecraft:red_concrete
fill 94 156 285 94 157 286 minecraft:white_concrete
fill 94 156 287 94 156 288 minecraft:red_concrete
fill 94 156 289 94 157 290 minecraft:white_concrete
fill 94 156 291 94 157 292 minecraft:red_concrete
fill 94 156 293 94 157 294 minecraft:white_concrete
fill 94 156 295 94 157 296 minecraft:red_concrete
fill 94 156 297 94 157 298 minecraft:white_concrete
fill 94 156 299 94 157 300 minecraft:red_concrete
fill 94 156 301 94 157 302 minecraft:white_concrete
fill 94 156 303 94 157 304 minecraft:red_concrete
fill 94 156 305 94 157 306 minecraft:white_concrete
fill 94 156 307 94 157 308 minecraft:red_concrete
fill 94 156 309 94 157 310 minecraft:white_concrete
fill 94 156 311 94 157 312 minecraft:red_concrete
fill 94 156 313 94 157 314 minecraft:white_concrete
fill 94 156 315 94 157 316 minecraft:red_concrete
fill 95 156 275 95 157 275 minecraft:red_concrete
fill 95 156 284 109 156 308 minecraft:red_terracotta
fill 95 156 317 95 157 317 minecraft:red_concrete
fill 96 156 275 97 157 275 minecraft:white_concrete
fill 96 156 283 134 156 283 minecraft:red_terracotta
fill 96 156 309 134 156 309 minecraft:red_terracotta
fill 96 156 317 97 157 317 minecraft:white_concrete
fill 97 156 281 133 156 282 minecraft:red_terracotta
fill 97 156 310 133 156 311 minecraft:red_terracotta
fill 98 156 275 99 157 275 minecraft:red_concrete
fill 98 156 280 132 156 280 minecraft:red_terracotta
fill 98 156 312 132 156 312 minecraft:red_terracotta
fill 98 156 317 99 157 317 minecraft:red_concrete
fill 99 156 279 131 156 279 minecraft:red_terracotta
fill 99 156 313 131 156 313 minecraft:red_terracotta
fill 100 156 275 101 157 275 minecraft:white_concrete
fill 100 156 278 130 156 278 minecraft:red_terracotta
fill 100 156 314 130 156 314 minecraft:red_terracotta
fill 100 156 317 101 157 317 minecraft:white_concrete
fill 102 156 275 103 157 275 minecraft:red_concrete
fill 102 156 277 128 156 277 minecraft:red_terracotta
fill 102 156 315 128 156 315 minecraft:red_terracotta
fill 102 156 317 103 157 317 minecraft:red_concrete
fill 103 156 276 127 156 276 minecraft:red_terracotta
fill 103 156 316 127 156 316 minecraft:red_terracotta
fill 104 156 275 105 157 275 minecraft:white_concrete
fill 104 156 317 105 157 317 minecraft:white_concrete
fill 106 156 275 107 157 275 minecraft:red_concrete
fill 106 156 317 107 157 317 minecraft:red_concrete
fill 108 156 275 109 157 275 minecraft:white_concrete
fill 108 156 317 109 157 317 minecraft:white_concrete
fill 110 156 275 111 157 275 minecraft:red_concrete
fill 110 156 284 110 156 298 minecraft:red_terracotta
setblock 110 156 299 minecraft:shroomlight
setblock 110 156 301 minecraft:shroomlight
fill 110 156 302 110 156 308 minecraft:red_terracotta
fill 110 156 317 111 157 317 minecraft:red_concrete
fill 111 156 284 111 156 297 minecraft:red_terracotta
fill 111 156 303 111 156 308 minecraft:red_terracotta
fill 112 156 275 113 157 275 minecraft:white_concrete
fill 112 156 284 135 156 296 minecraft:red_terracotta
setblock 112 156 297 minecraft:shroomlight
setblock 112 156 303 minecraft:shroomlight
fill 112 156 304 135 156 308 minecraft:red_terracotta
fill 112 156 317 113 157 317 minecraft:white_concrete
fill 114 156 275 115 157 275 minecraft:red_concrete
fill 114 156 297 115 156 297 minecraft:shroomlight
setblock 114 156 303 minecraft:shroomlight
fill 114 156 317 115 157 317 minecraft:red_concrete
fill 115 156 303 135 156 303 minecraft:red_terracotta
fill 116 156 275 117 157 275 minecraft:white_concrete
fill 116 156 297 135 156 297 minecraft:red_terracotta
fill 116 156 298 116 156 299 minecraft:shroomlight
setblock 116 156 301 minecraft:shroomlight
fill 116 156 302 135 156 302 minecraft:red_terracotta
fill 116 156 317 117 157 317 minecraft:white_concrete
fill 117 156 298 135 156 301 minecraft:red_terracotta
fill 118 156 275 119 157 275 minecraft:red_concrete
fill 118 156 317 119 157 317 minecraft:red_concrete
fill 120 156 275 121 157 275 minecraft:white_concrete
fill 120 156 317 121 157 317 minecraft:white_concrete
fill 122 156 275 123 157 275 minecraft:red_concrete
fill 122 156 317 123 157 317 minecraft:red_concrete
fill 124 156 275 125 157 275 minecraft:white_concrete
fill 124 156 317 125 157 317 minecraft:white_concrete
fill 126 156 275 127 157 275 minecraft:red_concrete
fill 126 156 317 127 157 317 minecraft:red_concrete
fill 128 156 275 129 157 275 minecraft:white_concrete
fill 128 156 317 129 157 317 minecraft:white_concrete
fill 130 156 275 131 157 275 minecraft:red_concrete
fill 130 156 317 131 157 317 minecraft:red_concrete
fill 132 156 275 133 157 275 minecraft:white_concrete
fill 132 156 317 133 157 317 minecraft:white_concrete
fill 134 156 275 135 157 275 minecraft:red_concrete
fill 134 156 317 135 157 317 minecraft:red_concrete
fill 136 156 276 136 157 276 minecraft:red_concrete
fill 136 156 277 136 157 278 minecraft:white_concrete
fill 136 156 279 136 157 280 minecraft:red_concrete
fill 136 156 281 136 157 282 minecraft:white_concrete
fill 136 156 283 136 157 284 minecraft:red_concrete
fill 136 156 285 136 157 286 minecraft:white_concrete
fill 136 156 287 136 157 288 minecraft:red_concrete
fill 136 156 289 136 157 290 minecraft:white_concrete
fill 136 156 291 136 157 292 minecraft:red_concrete
fill 136 156 293 136 157 294 minecraft:white_concrete
fill 136 156 295 136 157 296 minecraft:red_concrete
fill 136 156 297 136 157 298 minecraft:white_concrete
fill 136 156 299 136 157 300 minecraft:red_concrete
fill 136 156 301 136 157 302 minecraft:white_concrete
fill 136 156 303 136 157 304 minecraft:red_concrete
fill 136 156 305 136 157 306 minecraft:white_concrete
fill 136 156 307 136 157 308 minecraft:red_concrete
fill 136 156 309 136 157 310 minecraft:white_concrete
fill 136 156 311 136 157 312 minecraft:red_concrete
fill 136 156 313 136 157 314 minecraft:white_concrete
fill 136 156 315 136 157 316 minecraft:red_concrete
fill 136 156 317 136 157 317 minecraft:white_concrete
setblock 94 157 287 minecraft:iron_block
setblock 94 157 288 minecraft:red_concrete
fill 95 157 276 95 157 284 minecraft:bricks
fill 95 157 285 95 157 307 minecraft:red_terracotta
fill 95 157 308 95 157 316 minecraft:bricks
fill 96 157 276 96 157 282 minecraft:bricks
fill 96 157 283 96 157 284 minecraft:red_terracotta
fill 96 157 285 108 157 307 minecraft:bricks
fill 96 157 308 96 157 309 minecraft:red_terracotta
fill 96 157 310 96 157 316 minecraft:bricks
fill 97 157 276 97 157 281 minecraft:bricks
setblock 97 157 282 minecraft:red_terracotta
fill 97 157 283 133 157 284 minecraft:bricks
fill 97 157 308 133 157 309 minecraft:bricks
setblock 97 157 310 minecraft:red_terracotta
fill 97 157 311 97 157 316 minecraft:bricks
fill 98 157 276 98 157 280 minecraft:bricks
setblock 98 157 281 minecraft:red_terracotta
fill 98 157 282 132 157 282 minecraft:bricks
fill 98 157 310 132 157 310 minecraft:bricks
setblock 98 157 311 minecraft:red_terracotta
fill 98 157 312 98 157 316 minecraft:bricks
fill 99 157 276 99 157 279 minecraft:bricks
setblock 99 157 280 minecraft:red_terracotta
fill 99 157 281 131 157 281 minecraft:bricks
fill 99 157 311 131 157 311 minecraft:bricks
setblock 99 157 312 minecraft:red_terracotta
fill 99 157 313 99 157 316 minecraft:bricks
fill 100 157 276 100 157 278 minecraft:bricks
setblock 100 157 279 minecraft:red_terracotta
fill 100 157 280 130 157 280 minecraft:bricks
fill 100 157 312 130 157 312 minecraft:bricks
setblock 100 157 313 minecraft:red_terracotta
fill 100 157 314 100 157 316 minecraft:bricks
fill 101 157 276 101 157 277 minecraft:bricks
setblock 101 157 278 minecraft:red_terracotta
fill 101 157 279 129 157 279 minecraft:bricks
fill 101 157 313 129 157 313 minecraft:bricks
setblock 101 157 314 minecraft:red_terracotta
fill 101 157 315 101 157 316 minecraft:bricks
fill 102 157 276 103 157 276 minecraft:bricks
fill 102 157 277 103 157 277 minecraft:red_terracotta
fill 102 157 278 128 157 278 minecraft:bricks
fill 102 157 314 128 157 314 minecraft:bricks
fill 102 157 315 103 157 315 minecraft:red_terracotta
fill 102 157 316 103 157 316 minecraft:bricks
fill 104 157 276 126 157 276 minecraft:red_terracotta
fill 104 157 277 126 157 277 minecraft:bricks
fill 104 157 315 126 157 315 minecraft:bricks
fill 104 157 316 126 157 316 minecraft:red_terracotta
fill 109 157 285 109 157 298 minecraft:bricks
fill 109 157 299 109 157 301 minecraft:ochre_froglight
fill 109 157 302 109 157 307 minecraft:bricks
fill 110 157 285 111 157 296 minecraft:bricks
fill 110 157 297 110 157 299 minecraft:ochre_froglight
fill 110 157 301 110 157 303 minecraft:ochre_froglight
fill 110 157 304 111 158 307 minecraft:bricks
fill 111 157 297 112 157 297 minecraft:ochre_froglight
fill 111 157 303 112 157 303 minecraft:ochre_froglight
fill 112 157 285 134 157 295 minecraft:bricks
fill 112 157 296 114 157 296 minecraft:ochre_froglight
fill 112 157 304 114 157 304 minecraft:ochre_froglight
fill 112 157 305 134 157 307 minecraft:bricks
fill 114 157 297 116 157 297 minecraft:ochre_froglight
fill 114 157 303 116 157 303 minecraft:ochre_froglight
setblock 115 157 296 minecraft:magma_block
fill 115 157 304 134 157 304 minecraft:bricks
fill 116 157 296 134 157 296 minecraft:bricks
fill 116 157 298 116 157 299 minecraft:ochre_froglight
fill 116 157 301 116 157 302 minecraft:ochre_froglight
fill 117 157 297 134 157 297 minecraft:bricks
setblock 117 157 298 minecraft:magma_block
fill 117 157 299 117 157 301 minecraft:ochre_froglight
fill 117 157 302 134 157 303 minecraft:bricks
fill 118 157 298 134 157 301 minecraft:bricks
fill 127 157 276 135 157 276 minecraft:bricks
fill 127 157 277 128 157 277 minecraft:red_terracotta
fill 127 157 315 128 157 315 minecraft:red_terracotta
fill 127 157 316 135 157 316 minecraft:bricks
fill 129 157 277 135 157 277 minecraft:bricks
setblock 129 157 278 minecraft:red_terracotta
setblock 129 157 314 minecraft:red_terracotta
fill 129 157 315 135 157 315 minecraft:bricks
fill 130 157 278 135 157 278 minecraft:bricks
setblock 130 157 279 minecraft:red_terracotta
setblock 130 157 313 minecraft:red_terracotta
fill 130 157 314 135 157 314 minecraft:bricks
fill 131 157 279 135 157 279 minecraft:bricks
setblock 131 157 280 minecraft:red_terracotta
setblock 131 157 312 minecraft:red_terracotta
fill 131 157 313 135 157 313 minecraft:bricks
fill 132 157 280 135 157 280 minecraft:bricks
setblock 132 157 281 minecraft:red_terracotta
setblock 132 157 311 minecraft:red_terracotta
fill 132 157 312 135 157 312 minecraft:bricks
fill 133 157 281 135 157 281 minecraft:bricks
setblock 133 157 282 minecraft:red_terracotta
setblock 133 157 310 minecraft:red_terracotta
fill 133 157 311 135 157 311 minecraft:bricks
fill 134 157 282 135 157 282 minecraft:bricks
fill 134 157 283 134 157 284 minecraft:red_terracotta
fill 134 157 308 134 157 309 minecraft:red_terracotta
fill 134 157 310 135 157 310 minecraft:bricks
fill 135 157 283 135 157 284 minecraft:bricks
fill 135 157 285 135 157 307 minecraft:red_terracotta
fill 135 157 308 135 157 309 minecraft:bricks
fill 94 158 275 94 159 276 minecraft:white_concrete
fill 94 158 277 94 159 278 minecraft:red_concrete
fill 94 158 279 94 159 280 minecraft:white_concrete
fill 94 158 281 94 159 282 minecraft:red_concrete
fill 94 158 283 94 159 284 minecraft:white_concrete
fill 94 158 285 94 159 286 minecraft:red_concrete
fill 94 158 287 94 159 288 minecraft:white_concrete
fill 94 158 289 94 159 290 minecraft:red_concrete
fill 94 158 291 94 159 292 minecraft:white_concrete
fill 94 158 293 94 159 294 minecraft:red_concrete
fill 94 158 295 94 159 296 minecraft:white_concrete
fill 94 158 297 94 159 298 minecraft:red_concrete
fill 94 158 299 94 159 300 minecraft:white_concrete
fill 94 158 301 94 159 302 minecraft:red_concrete
fill 94 158 303 94 159 304 minecraft:white_concrete
fill 94 158 305 94 159 306 minecraft:red_concrete
fill 94 158 307 94 159 308 minecraft:white_concrete
fill 94 158 309 94 159 310 minecraft:red_concrete
fill 94 158 311 94 159 312 minecraft:white_concrete
fill 94 158 313 94 159 314 minecraft:red_concrete
fill 94 158 315 94 159 316 minecraft:white_concrete
fill 95 158 275 95 159 275 minecraft:white_concrete
fill 95 158 286 95 158 306 minecraft:red_terracotta
fill 95 158 317 95 159 317 minecraft:white_concrete
fill 96 158 275 97 159 275 minecraft:red_concrete
fill 96 158 284 96 158 285 minecraft:red_terracotta
fill 96 158 286 108 158 306 minecraft:bricks
fill 96 158 307 96 158 308 minecraft:red_terracotta
fill 96 158 317 97 159 317 minecraft:red_concrete
setblock 97 158 278 minecraft:light[level=12]
setblock 97 158 283 minecraft:red_terracotta
fill 97 158 284 133 158 285 minecraft:bricks
fill 97 158 307 109 158 308 minecraft:bricks
setblock 97 158 309 minecraft:red_terracotta
setblock 97 158 313 minecraft:light[level=12]
fill 98 158 275 99 159 275 minecraft:white_concrete
fill 98 158 282 98 159 282 minecraft:red_terracotta
fill 98 158 283 132 158 283 minecraft:bricks
fill 98 158 309 132 158 309 minecraft:bricks
fill 98 158 310 98 159 310 minecraft:red_terracotta
fill 98 158 317 99 159 317 minecraft:white_concrete
fill 99 158 281 99 159 281 minecraft:red_terracotta
fill 99 158 282 131 159 282 minecraft:bricks
fill 99 158 310 131 159 310 minecraft:bricks
fill 99 158 311 99 159 311 minecraft:red_terracotta
fill 100 158 275 101 159 275 minecraft:red_concrete
fill 100 158 280 100 159 280 minecraft:red_terracotta
fill 100 158 281 130 159 281 minecraft:bricks
fill 100 158 311 130 159 311 minecraft:bricks
fill 100 158 312 100 159 312 minecraft:red_terracotta
fill 100 158 317 101 159 317 minecraft:red_concrete
fill 101 158 279 101 159 279 minecraft:red_terracotta
fill 101 158 280 129 159 280 minecraft:bricks
fill 101 158 312 129 159 312 minecraft:bricks
fill 101 158 313 101 159 313 minecraft:red_terracotta
fill 102 158 275 103 159 275 minecraft:white_concrete
setblock 102 158 278 minecraft:red_terracotta
fill 102 158 279 128 158 279 minecraft:bricks
fill 102 158 313 128 158 313 minecraft:bricks
setblock 102 158 314 minecraft:red_terracotta
fill 102 158 317 103 159 317 minecraft:white_concrete
fill 103 158 277 104 158 277 minecraft:red_terracotta
fill 103 158 278 127 158 278 minecraft:bricks
fill 103 158 314 127 158 314 minecraft:bricks
fill 103 158 315 104 158 315 minecraft:red_terracotta
fill 104 158 275 105 159 275 minecraft:red_concrete
fill 104 158 317 105 159 317 minecraft:red_concrete
fill 105 158 276 125 158 276 minecraft:red_terracotta
fill 105 158 277 125 158 277 minecraft:bricks
fill 105 158 315 125 158 315 minecraft:bricks
fill 105 158 316 125 158 316 minecraft:red_terracotta
fill 106 158 275 107 159 275 minecraft:white_concrete
fill 106 158 317 107 159 317 minecraft:white_concrete
fill 108 158 275 109 159 275 minecraft:red_concrete
fill 108 158 317 109 159 317 minecraft:red_concrete
fill 109 158 286 109 158 297 minecraft:bricks
fill 109 158 298 109 158 302 minecraft:magma_block
fill 109 158 303 109 160 306 minecraft:bricks
fill 110 158 275 111 159 275 minecraft:white_concrete
fill 110 158 286 111 158 295 minecraft:bricks
fill 110 158 296 110 158 297 minecraft:magma_block
fill 110 158 303 111 158 303 minecraft:magma_block
fill 110 158 308 133 158 308 minecraft:bricks
fill 110 158 317 111 159 317 minecraft:white_concrete
setblock 111 158 296 minecraft:magma_block
fill 112 158 275 113 159 275 minecraft:red_concrete
fill 112 158 286 134 158 294 minecraft:bricks
fill 112 158 295 115 158 295 minecraft:magma_block
fill 112 158 304 115 158 304 minecraft:magma_block
fill 112 158 305 133 159 307 minecraft:bricks
fill 112 158 317 113 159 317 minecraft:red_concrete
fill 114 158 275 115 159 275 minecraft:white_concrete
fill 114 158 317 115 159 317 minecraft:white_concrete
fill 116 158 275 117 159 275 minecraft:red_concrete
fill 116 158 295 134 158 295 minecraft:bricks
setblock 116 158 296 minecraft:magma_block
setblock 116 158 303 minecraft:magma_block
fill 116 158 304 134 158 304 minecraft:bricks
fill 116 158 317 117 159 317 minecraft:red_concrete
fill 117 158 296 134 158 296 minecraft:bricks
setblock 117 158 297 minecraft:magma_block
setblock 117 158 302 minecraft:magma_block
fill 117 158 303 134 158 303 minecraft:bricks
fill 118 158 275 119 159 275 minecraft:white_concrete
fill 118 158 297 134 158 297 minecraft:bricks
fill 118 158 298 118 158 301 minecraft:magma_block
fill 118 158 302 134 158 302 minecraft:bricks
fill 118 158 317 119 159 317 minecraft:white_concrete
fill 119 158 298 134 158 301 minecraft:bricks
fill 120 158 275 121 159 275 minecraft:red_concrete
fill 120 158 317 121 159 317 minecraft:red_concrete
fill 122 158 275 123 159 275 minecraft:white_concrete
fill 122 158 317 123 159 317 minecraft:white_concrete
fill 124 158 275 125 159 275 minecraft:red_concrete
fill 124 158 317 125 159 317 minecraft:red_concrete
fill 126 158 275 127 159 275 minecraft:white_concrete
fill 126 158 277 127 158 277 minecraft:red_terracotta
fill 126 158 315 127 158 315 minecraft:red_terracotta
fill 126 158 317 127 159 317 minecraft:white_concrete
fill 128 158 275 129 159 275 minecraft:red_concrete
setblock 128 158 278 minecraft:red_terracotta
setblock 128 158 314 minecraft:red_terracotta
fill 128 158 317 129 159 317 minecraft:red_concrete
fill 129 158 279 129 159 279 minecraft:red_terracotta
fill 129 158 313 129 159 313 minecraft:red_terracotta
fill 130 158 275 131 159 275 minecraft:white_concrete
fill 130 158 280 130 159 280 minecraft:red_terracotta
fill 130 158 312 130 159 312 minecraft:red_terracotta
fill 130 158 317 131 159 317 minecraft:white_concrete
fill 131 158 281 131 159 281 minecraft:red_terracotta
fill 131 158 311 131 159 311 minecraft:red_terracotta
fill 132 158 275 133 159 275 minecraft:red_concrete
setblock 132 158 278 minecraft:light[level=12]
fill 132 158 282 132 159 282 minecraft:red_terracotta
fill 132 158 310 132 159 310 minecraft:red_terracotta
setblock 132 158 313 minecraft:light[level=12]
fill 132 158 317 133 159 317 minecraft:red_concrete
setblock 133 158 283 minecraft:red_terracotta
setblock 133 158 309 minecraft:red_terracotta
fill 134 158 275 135 159 275 minecraft:white_concrete
fill 134 158 284 134 158 285 minecraft:red_terracotta
fill 134 158 305 134 158 306 minecraft:bricks
fill 134 158 307 134 158 308 minecraft:red_terracotta
fill 134 158 317 135 159 317 minecraft:white_concrete
fill 135 158 286 135 158 306 minecraft:red_terracotta
fill 136 158 276 136 159 276 minecraft:white_concrete
fill 136 158 277 136 159 278 minecraft:red_concrete
fill 136 158 279 136 159 280 minecraft:white_concrete
fill 136 158 281 136 159 282 minecraft:red_concrete
fill 136 158 283 136 159 284 minecraft:white_concrete
fill 136 158 285 136 159 286 minecraft:red_concrete
fill 136 158 287 136 159 288 minecraft:white_concrete
fill 136 158 289 136 159 290 minecraft:red_concrete
fill 136 158 291 136 159 292 minecraft:white_concrete
fill 136 158 293 136 159 294 minecraft:red_concrete
fill 136 158 295 136 159 296 minecraft:white_concrete
fill 136 158 297 136 159 298 minecraft:red_concrete
fill 136 158 299 136 159 300 minecraft:white_concrete
fill 136 158 301 136 159 302 minecraft:red_concrete
fill 136 158 303 136 159 304 minecraft:white_concrete
fill 136 158 305 136 159 306 minecraft:red_concrete
fill 136 158 307 136 159 308 minecraft:white_concrete
fill 136 158 309 136 159 310 minecraft:red_concrete
fill 136 158 311 136 159 312 minecraft:white_concrete
fill 136 158 313 136 159 314 minecraft:red_concrete
fill 136 158 315 136 159 316 minecraft:white_concrete
fill 136 158 317 136 159 317 minecraft:red_concrete
fill 95 159 287 95 159 305 minecraft:red_terracotta
fill 96 159 285 96 159 286 minecraft:red_terracotta
fill 96 159 287 107 159 305 minecraft:bricks
fill 96 159 306 96 159 307 minecraft:red_terracotta
fill 97 159 284 97 160 284 minecraft:red_terracotta
fill 97 159 285 133 159 286 minecraft:bricks
fill 97 159 306 108 159 307 minecraft:bricks
fill 97 159 308 97 160 308 minecraft:red_terracotta
fill 98 159 283 98 160 283 minecraft:red_terracotta
fill 98 159 284 132 160 284 minecraft:bricks
fill 98 159 308 132 160 308 minecraft:bricks
fill 98 159 309 98 161 309 minecraft:red_terracotta
fill 99 159 283 131 160 283 minecraft:bricks
fill 99 159 309 131 160 309 minecraft:bricks
fill 102 159 279 102 160 279 minecraft:red_terracotta
fill 102 159 313 102 161 313 minecraft:red_terracotta
fill 103 159 278 103 160 278 minecraft:red_terracotta
fill 103 159 279 127 160 279 minecraft:bricks
fill 103 159 313 127 160 313 minecraft:bricks
fill 103 159 314 103 160 314 minecraft:red_terracotta
fill 104 159 277 105 159 277 minecraft:red_terracotta
fill 104 159 278 126 159 278 minecraft:bricks
fill 104 159 314 126 159 314 minecraft:bricks
fill 104 159 315 105 159 315 minecraft:red_terracotta
fill 106 159 276 124 159 276 minecraft:red_terracotta
fill 106 159 277 124 159 277 minecraft:bricks
fill 106 159 315 124 159 315 minecraft:bricks
fill 106 159 316 124 159 316 minecraft:red_terracotta
fill 108 159 287 108 159 297 minecraft:bricks
fill 108 159 298 108 159 300 minecraft:shroomlight
fill 108 159 301 108 159 305 minecraft:bricks
fill 109 159 287 109 159 295 minecraft:bricks
fill 109 159 296 109 159 297 minecraft:shroomlight
fill 109 159 301 109 159 302 minecraft:shroomlight
fill 109 159 307 111 168 307 minecraft:bricks
fill 110 159 287 111 159 294 minecraft:bricks
fill 110 159 295 111 159 295 minecraft:shroomlight
setblock 110 159 303 minecraft:shroomlight
fill 110 159 304 110 160 306 minecraft:bricks
fill 111 159 304 116 159 304 minecraft:shroomlight
fill 111 159 305 111 161 306 minecraft:bricks
fill 112 159 287 134 159 293 minecraft:bricks
fill 112 159 294 115 159 294 minecraft:shroomlight
fill 116 159 294 134 159 294 minecraft:bricks
fill 116 159 295 117 159 295 minecraft:shroomlight
setblock 117 159 296 minecraft:shroomlight
setblock 117 159 303 minecraft:shroomlight
fill 117 159 304 134 160 304 minecraft:bricks
fill 118 159 295 134 159 296 minecraft:bricks
fill 118 159 297 118 159 298 minecraft:shroomlight
fill 118 159 301 118 159 302 minecraft:shroomlight
fill 118 159 303 134 160 303 minecraft:bricks
fill 119 159 297 134 159 298 minecraft:bricks
fill 119 159 299 119 159 300 minecraft:shroomlight
fill 119 159 301 134 159 302 minecraft:bricks
fill 120 159 299 134 160 300 minecraft:bricks
fill 125 159 277 126 159 277 minecraft:red_terracotta
fill 125 159 315 126 159 315 minecraft:red_terracotta
fill 127 159 278 127 160 278 minecraft:red_terracotta
fill 127 159 314 127 160 314 minecraft:red_terracotta
fill 128 159 279 128 161 279 minecraft:red_terracotta
fill 128 159 313 128 160 313 minecraft:red_terracotta
fill 132 159 283 132 161 283 minecraft:red_terracotta
fill 132 159 309 132 160 309 minecraft:red_terracotta
fill 133 159 284 133 160 284 minecraft:red_terracotta
fill 133 159 308 133 160 308 minecraft:red_terracotta
fill 134 159 285 134 159 286 minecraft:red_terracotta
setblock 134 159 305 minecraft:bricks
fill 134 159 306 134 159 307 minecraft:red_terracotta
fill 135 159 287 135 159 305 minecraft:red_terracotta
fill 94 160 275 94 161 276 minecraft:red_concrete
fill 94 160 277 94 161 278 minecraft:white_concrete
fill 94 160 279 94 160 280 minecraft:red_concrete
fill 94 160 281 94 161 282 minecraft:white_concrete
fill 94 160 283 94 161 284 minecraft:red_concrete
fill 94 160 285 94 161 286 minecraft:white_concrete
fill 94 160 287 94 160 288 minecraft:red_concrete
fill 94 160 289 94 161 290 minecraft:white_concrete
fill 94 160 291 94 161 292 minecraft:red_concrete
fill 94 160 293 94 161 294 minecraft:white_concrete
fill 94 160 295 94 160 296 minecraft:red_concrete
fill 94 160 297 94 161 298 minecraft:white_concrete
fill 94 160 299 94 161 300 minecraft:red_concrete
fill 94 160 301 94 161 302 minecraft:white_concrete
fill 94 160 303 94 160 304 minecraft:red_concrete
fill 94 160 305 94 161 306 minecraft:white_concrete
fill 94 160 307 94 161 308 minecraft:red_concrete
fill 94 160 309 94 161 310 minecraft:white_concrete
fill 94 160 311 94 160 312 minecraft:red_concrete
fill 94 160 313 94 161 314 minecraft:white_concrete
fill 94 160 315 94 161 316 minecraft:red_concrete
fill 95 160 275 95 161 275 minecraft:red_concrete
fill 95 160 288 95 160 304 minecraft:red_terracotta
fill 95 160 317 95 161 317 minecraft:red_concrete
fill 96 160 275 97 161 275 minecraft:white_concrete
fill 96 160 286 96 161 287 minecraft:red_terracotta
fill 96 160 288 107 160 304 minecraft:bricks
fill 96 160 305 96 160 306 minecraft:red_terracotta
fill 96 160 317 97 160 317 minecraft:white_concrete
fill 97 160 285 97 161 285 minecraft:red_terracotta
fill 97 160 286 133 160 287 minecraft:bricks
fill 97 160 305 108 160 306 minecraft:bricks
fill 97 160 307 97 161 307 minecraft:red_terracotta
fill 98 160 275 99 161 275 minecraft:red_concrete
fill 98 160 285 132 161 285 minecraft:bricks
fill 98 160 307 108 161 307 minecraft:bricks
fill 98 160 317 99 161 317 minecraft:red_concrete
setblock 99 160 282 minecraft:red_terracotta
setblock 99 160 310 minecraft:red_terracotta
fill 100 160 275 101 160 275 minecraft:white_concrete
setblock 100 160 281 minecraft:red_terracotta
fill 100 160 282 130 160 282 minecraft:bricks
fill 100 160 310 130 160 310 minecraft:bricks
setblock 100 160 311 minecraft:red_terracotta
fill 100 160 317 101 161 317 minecraft:white_concrete
setblock 101 160 280 minecraft:red_terracotta
fill 101 160 281 129 160 281 minecraft:bricks
fill 101 160 311 129 160 311 minecraft:bricks
setblock 101 160 312 minecraft:red_terracotta
fill 102 160 275 103 161 275 minecraft:red_concrete
fill 102 160 280 128 160 280 minecraft:bricks
fill 102 160 312 128 160 312 minecraft:bricks
fill 102 160 317 103 161 317 minecraft:red_concrete
fill 104 160 275 105 161 275 minecraft:white_concrete
fill 104 160 278 104 161 278 minecraft:red_terracotta
fill 104 160 314 104 161 314 minecraft:red_terracotta
fill 104 160 317 105 160 317 minecraft:white_concrete
fill 105 160 277 106 161 277 minecraft:red_terracotta
fill 105 160 278 125 160 278 minecraft:bricks
fill 105 160 314 125 160 314 minecraft:bricks
fill 105 160 315 106 160 315 minecraft:red_terracotta
fill 106 160 275 107 161 275 minecraft:red_concrete
fill 106 160 317 107 161 317 minecraft:red_concrete
fill 107 160 276 123 160 276 minecraft:red_terracotta
fill 107 160 277 123 160 277 minecraft:bricks
fill 107 160 315 123 160 315 minecraft:bricks
fill 107 160 316 123 160 316 minecraft:red_terracotta
fill 108 160 275 109 160 275 minecraft:white_concrete
fill 108 160 288 108 160 296 minecraft:bricks
fill 108 160 297 108 160 301 minecraft:magma_block
fill 108 160 302 108 160 304 minecraft:bricks
fill 108 160 317 109 161 317 minecraft:white_concrete
fill 109 160 288 109 160 294 minecraft:bricks
fill 109 160 295 109 160 296 minecraft:magma_block
setblock 109 160 302 minecraft:magma_block
fill 110 160 275 111 161 275 minecraft:red_concrete
fill 110 160 288 111 160 293 minecraft:bricks
fill 110 160 294 111 160 294 minecraft:magma_block
setblock 110 160 303 minecraft:magma_block
fill 110 160 317 111 161 317 minecraft:red_concrete
fill 111 160 304 112 160 304 minecraft:magma_block
fill 112 160 275 113 161 275 minecraft:white_concrete
fill 112 160 288 134 160 292 minecraft:bricks
fill 112 160 293 115 160 293 minecraft:magma_block
fill 112 160 305 112 160 307 minecraft:bricks
fill 112 160 317 113 160 317 minecraft:white_concrete
fill 113 160 305 115 161 305 minecraft:magma_block
fill 113 160 306 132 161 307 minecraft:bricks
fill 114 160 275 115 161 275 minecraft:red_concrete
fill 114 160 317 115 161 317 minecraft:red_concrete
fill 116 160 275 117 160 275 minecraft:white_concrete
fill 116 160 293 134 160 293 minecraft:bricks
fill 116 160 294 117 160 294 minecraft:magma_block
setblock 116 160 304 minecraft:magma_block
fill 116 160 305 133 160 305 minecraft:bricks
fill 116 160 317 117 161 317 minecraft:white_concrete
setblock 117 160 303 minecraft:magma_block
fill 118 160 275 119 161 275 minecraft:red_concrete
fill 118 160 294 134 160 294 minecraft:bricks
fill 118 160 295 118 160 296 minecraft:magma_block
setblock 118 160 302 minecraft:magma_block
fill 118 160 317 119 161 317 minecraft:red_concrete
fill 119 160 295 134 160 296 minecraft:bricks
fill 119 160 297 119 160 301 minecraft:magma_block
fill 119 160 302 134 160 302 minecraft:bricks
fill 120 160 275 121 161 275 minecraft:white_concrete
fill 120 160 297 134 160 298 minecraft:bricks
fill 120 160 301 134 160 301 minecraft:bricks
fill 120 160 317 121 160 317 minecraft:white_concrete
fill 122 160 275 123 161 275 minecraft:red_concrete
fill 122 160 317 123 161 317 minecraft:red_concrete
fill 124 160 275 125 160 275 minecraft:white_concrete
fill 124 160 277 125 160 277 minecraft:red_terracotta
fill 124 160 315 125 161 315 minecraft:red_terracotta
fill 124 160 317 125 161 317 minecraft:white_concrete
fill 126 160 275 127 161 275 minecraft:red_concrete
fill 126 160 278 126 161 278 minecraft:red_terracotta
fill 126 160 314 126 161 314 minecraft:red_terracotta
fill 126 160 317 127 161 317 minecraft:red_concrete
fill 128 160 275 129 161 275 minecraft:white_concrete
fill 128 160 317 129 160 317 minecraft:white_concrete
setblock 129 160 280 minecraft:red_terracotta
setblock 129 160 312 minecraft:red_terracotta
fill 130 160 275 131 161 275 minecraft:red_concrete
setblock 130 160 281 minecraft:red_terracotta
setblock 130 160 311 minecraft:red_terracotta
fill 130 160 317 131 161 317 minecraft:red_concrete
setblock 131 160 282 minecraft:red_terracotta
setblock 131 160 310 minecraft:red_terracotta
fill 132 160 275 133 160 275 minecraft:white_concrete
fill 132 160 317 133 161 317 minecraft:white_concrete
fill 133 160 285 133 161 285 minecraft:red_terracotta
setblock 133 160 306 minecraft:bricks
fill 133 160 307 133 161 307 minecraft:red_terracotta
fill 134 160 275 135 161 275 minecraft:red_concrete
fill 134 160 286 134 160 287 minecraft:red_terracotta
fill 134 160 305 134 161 306 minecraft:red_terracotta
fill 134 160 317 135 161 317 minecraft:red_concrete
fill 135 160 288 135 160 304 minecraft:red_terracotta
fill 136 160 276 136 161 276 minecraft:red_concrete
fill 136 160 277 136 161 278 minecraft:white_concrete
fill 136 160 279 136 160 280 minecraft:red_concrete
fill 136 160 281 136 161 282 minecraft:white_concrete
fill 136 160 283 136 161 284 minecraft:red_concrete
fill 136 160 285 136 161 286 minecraft:white_concrete
fill 136 160 287 136 160 288 minecraft:red_concrete
fill 136 160 289 136 161 290 minecraft:white_concrete
fill 136 160 291 136 161 292 minecraft:red_concrete
fill 136 160 293 136 161 294 minecraft:white_concrete
fill 136 160 295 136 160 296 minecraft:red_concrete
fill 136 160 297 136 161 298 minecraft:white_concrete
fill 136 160 299 136 161 300 minecraft:red_concrete
fill 136 160 301 136 161 302 minecraft:white_concrete
fill 136 160 303 136 160 304 minecraft:red_concrete
fill 136 160 305 136 161 306 minecraft:white_concrete
fill 136 160 307 136 161 308 minecraft:red_concrete
fill 136 160 309 136 161 310 minecraft:white_concrete
fill 136 160 311 136 160 312 minecraft:red_concrete
fill 136 160 313 136 161 314 minecraft:white_concrete
fill 136 160 315 136 161 316 minecraft:red_concrete
fill 136 160 317 136 161 317 minecraft:white_concrete
setblock 94 161 279 minecraft:red_concrete
fill 94 161 280 94 163 280 minecraft:shroomlight
setblock 94 161 287 minecraft:red_concrete
fill 94 161 288 94 163 288 minecraft:shroomlight
setblock 94 161 295 minecraft:red_concrete
fill 94 161 296 94 163 296 minecraft:shroomlight
setblock 94 161 303 minecraft:red_concrete
fill 94 161 304 94 163 304 minecraft:shroomlight
setblock 94 161 311 minecraft:red_concrete
fill 94 161 312 94 163 312 minecraft:shroomlight
fill 95 161 276 98 161 276 minecraft:red_terracotta
fill 95 161 278 95 161 279 minecraft:red_terracotta
fill 95 161 281 95 161 285 minecraft:red_terracotta
fill 95 161 287 95 161 288 minecraft:red_terracotta
fill 95 161 290 95 161 303 minecraft:red_terracotta
fill 95 161 305 95 161 309 minecraft:red_terracotta
fill 95 161 311 95 161 312 minecraft:red_terracotta
fill 95 161 314 95 219 315 minecraft:red_terracotta
fill 96 161 277 96 161 278 minecraft:red_terracotta
fill 96 161 280 96 161 281 minecraft:red_terracotta
fill 96 161 283 96 161 284 minecraft:red_terracotta
fill 96 161 288 96 161 289 minecraft:red_terracotta
fill 96 161 290 106 161 302 minecraft:bricks
fill 96 161 303 96 161 305 minecraft:red_terracotta
fill 96 161 307 96 161 308 minecraft:red_terracotta
fill 96 161 310 96 161 311 minecraft:red_terracotta
fill 96 161 313 96 161 314 minecraft:red_terracotta
fill 96 161 316 97 161 316 minecraft:red_terracotta
setblock 96 161 317 minecraft:white_concrete
setblock 97 161 277 minecraft:red_terracotta
fill 97 161 279 97 161 280 minecraft:red_terracotta
fill 97 161 282 97 161 283 minecraft:red_terracotta
setblock 97 161 286 minecraft:red_terracotta
fill 97 161 287 133 161 289 minecraft:bricks
fill 97 161 303 108 161 305 minecraft:bricks
setblock 97 161 306 minecraft:red_terracotta
fill 97 161 309 97 161 310 minecraft:red_terracotta
fill 97 161 312 97 161 313 minecraft:red_terracotta
fill 97 161 315 98 161 315 minecraft:red_terracotta
fill 97 161 317 97 163 317 minecraft:shroomlight
fill 98 161 278 98 161 279 minecraft:red_terracotta
fill 98 161 281 98 161 282 minecraft:red_terracotta
setblock 98 161 284 minecraft:red_terracotta
fill 98 161 286 132 161 286 minecraft:bricks
fill 98 161 306 110 161 306 minecraft:bricks
setblock 98 161 308 minecraft:red_terracotta
fill 98 161 311 98 161 312 minecraft:red_terracotta
fill 98 161 314 99 161 314 minecraft:red_terracotta
fill 99 161 277 99 161 278 minecraft:red_terracotta
setblock 99 161 283 minecraft:red_terracotta
fill 99 161 284 131 161 284 minecraft:bricks
fill 99 161 308 131 161 308 minecraft:bricks
setblock 99 161 309 minecraft:red_terracotta
fill 99 161 313 100 161 313 minecraft:red_terracotta
fill 99 161 316 103 161 316 minecraft:red_terracotta
setblock 100 161 275 minecraft:white_concrete
fill 100 161 276 100 161 277 minecraft:red_terracotta
fill 100 161 279 101 161 279 minecraft:red_terracotta
fill 100 161 282 100 162 282 minecraft:red_terracotta
fill 100 161 283 130 161 283 minecraft:bricks
fill 100 161 309 130 161 309 minecraft:bricks
fill 100 161 310 100 162 310 minecraft:red_terracotta
fill 100 161 315 101 161 315 minecraft:red_terracotta
fill 101 161 275 101 163 275 minecraft:shroomlight
setblock 101 161 276 minecraft:red_terracotta
fill 101 161 278 102 161 278 minecraft:red_terracotta
fill 101 161 281 101 162 281 minecraft:red_terracotta
fill 101 161 282 129 162 282 minecraft:bricks
fill 101 161 310 129 162 310 minecraft:bricks
fill 101 161 311 101 162 311 minecraft:red_terracotta
fill 101 161 314 102 161 314 minecraft:red_terracotta
fill 102 161 277 103 161 277 minecraft:red_terracotta
setblock 102 161 280 minecraft:red_terracotta
fill 102 161 281 128 161 281 minecraft:bricks
fill 102 161 311 128 161 311 minecraft:bricks
setblock 102 161 312 minecraft:red_terracotta
fill 103 161 276 107 161 276 minecraft:red_terracotta
setblock 103 161 279 minecraft:red_terracotta
fill 103 161 280 127 161 280 minecraft:bricks
fill 103 161 312 127 161 312 minecraft:bricks
setblock 103 161 313 minecraft:red_terracotta
fill 103 161 315 104 161 315 minecraft:red_terracotta
fill 104 161 279 126 161 279 minecraft:bricks
fill 104 161 313 126 161 313 minecraft:bricks
setblock 104 161 317 minecraft:white_concrete
setblock 105 161 278 minecraft:red_terracotta
setblock 105 161 314 minecraft:red_terracotta
fill 105 161 316 106 161 316 minecraft:red_terracotta
fill 105 161 317 105 163 317 minecraft:shroomlight
fill 106 161 278 124 161 278 minecraft:bricks
fill 106 161 314 124 161 314 minecraft:bricks
fill 106 161 315 108 161 315 minecraft:red_terracotta
fill 107 161 277 108 161 277 minecraft:red_terracotta
fill 107 161 290 107 161 297 minecraft:bricks
fill 107 161 298 107 161 300 minecraft:magma_block
fill 107 161 301 107 161 302 minecraft:bricks
setblock 108 161 275 minecraft:white_concrete
fill 108 161 290 108 161 295 minecraft:bricks
fill 108 161 296 108 161 297 minecraft:magma_block
fill 108 161 301 108 161 302 minecraft:magma_block
fill 108 161 316 121 161 316 minecraft:red_terracotta
fill 109 161 275 109 163 275 minecraft:shroomlight
fill 109 161 276 122 161 276 minecraft:red_terracotta
fill 109 161 277 121 161 277 minecraft:bricks
fill 109 161 290 110 161 293 minecraft:bricks
fill 109 161 294 109 161 295 minecraft:magma_block
setblock 109 161 303 minecraft:magma_block
fill 109 161 304 109 162 305 minecraft:bricks
fill 109 161 315 121 161 315 minecraft:bricks
setblock 110 161 294 minecraft:magma_block
fill 110 161 304 111 161 304 minecraft:magma_block
fill 110 161 305 110 163 305 minecraft:bricks
fill 111 161 290 111 161 292 minecraft:bricks
setblock 111 161 293 minecraft:magma_block
fill 112 161 290 134 161 291 minecraft:bricks
fill 112 161 292 115 161 292 minecraft:magma_block
setblock 112 161 305 minecraft:magma_block
fill 112 161 306 112 163 307 minecraft:bricks
setblock 112 161 317 minecraft:white_concrete
fill 113 161 317 113 163 317 minecraft:shroomlight
setblock 116 161 275 minecraft:white_concrete
fill 116 161 292 134 161 292 minecraft:bricks
fill 116 161 293 117 161 293 minecraft:magma_block
setblock 116 161 305 minecraft:magma_block
fill 117 161 275 117 163 275 minecraft:shroomlight
setblock 117 161 304 minecraft:magma_block
fill 117 161 305 133 161 305 minecraft:bricks
fill 118 161 293 134 161 293 minecraft:bricks
setblock 118 161 294 minecraft:magma_block
setblock 118 161 303 minecraft:magma_block
fill 118 161 304 133 161 304 minecraft:bricks
fill 119 161 294 134 161 294 minecraft:bricks
fill 119 161 295 119 161 296 minecraft:magma_block
setblock 119 161 302 minecraft:magma_block
fill 119 161 303 133 161 303 minecraft:bricks
fill 120 161 295 134 161 296 minecraft:bricks
fill 120 161 297 120 161 301 minecraft:magma_block
fill 120 161 302 134 161 302 minecraft:bricks
setblock 120 161 317 minecraft:white_concrete
fill 121 161 297 134 161 301 minecraft:bricks
fill 121 161 317 121 163 317 minecraft:shroomlight
fill 122 161 277 124 161 277 minecraft:red_terracotta
fill 122 161 315 123 161 315 minecraft:red_terracotta
fill 123 161 316 127 161 316 minecraft:red_terracotta
setblock 124 161 275 minecraft:white_concrete
fill 124 161 276 125 161 276 minecraft:red_terracotta
fill 125 161 275 125 163 275 minecraft:shroomlight
setblock 125 161 278 minecraft:red_terracotta
setblock 125 161 314 minecraft:red_terracotta
fill 126 161 277 127 161 277 minecraft:red_terracotta
fill 127 161 276 131 161 276 minecraft:red_terracotta
setblock 127 161 279 minecraft:red_terracotta
setblock 127 161 313 minecraft:red_terracotta
fill 127 161 315 128 161 315 minecraft:red_terracotta
fill 128 161 278 129 161 278 minecraft:red_terracotta
setblock 128 161 280 minecraft:red_terracotta
setblock 128 161 312 minecraft:red_terracotta
fill 128 161 314 129 161 314 minecraft:red_terracotta
setblock 128 161 317 minecraft:white_concrete
fill 129 161 277 130 161 277 minecraft:red_terracotta
fill 129 161 281 129 162 281 minecraft:red_terracotta
fill 129 161 311 129 162 311 minecraft:red_terracotta
fill 129 161 313 130 161 313 minecraft:red_terracotta
fill 129 161 316 130 161 316 minecraft:red_terracotta
fill 129 161 317 129 163 317 minecraft:shroomlight
fill 130 161 279 131 161 279 minecraft:red_terracotta
fill 130 161 282 130 162 282 minecraft:red_terracotta
fill 130 161 310 130 162 310 minecraft:red_terracotta
fill 130 161 315 131 161 315 minecraft:red_terracotta
fill 131 161 278 132 161 278 minecraft:red_terracotta
setblock 131 161 283 minecraft:red_terracotta
setblock 131 161 309 minecraft:red_terracotta
fill 131 161 314 132 161 314 minecraft:red_terracotta
setblock 132 161 275 minecraft:white_concrete
fill 132 161 277 133 161 277 minecraft:red_terracotta
fill 132 161 280 132 161 281 minecraft:red_terracotta
setblock 132 161 284 minecraft:red_terracotta
setblock 132 161 308 minecraft:red_terracotta
fill 132 161 310 132 161 311 minecraft:red_terracotta
fill 132 161 313 133 161 313 minecraft:red_terracotta
fill 132 161 316 135 161 316 minecraft:red_terracotta
fill 133 161 275 133 163 275 minecraft:shroomlight
fill 133 161 276 134 161 276 minecraft:red_terracotta
fill 133 161 279 133 161 280 minecraft:red_terracotta
fill 133 161 282 133 161 283 minecraft:red_terracotta
setblock 133 161 286 minecraft:red_terracotta
setblock 133 161 306 minecraft:red_terracotta
fill 133 161 309 133 161 310 minecraft:red_terracotta
fill 133 161 312 134 161 312 minecraft:red_terracotta
fill 133 161 315 134 161 315 minecraft:red_terracotta
fill 134 161 278 134 161 279 minecraft:red_terracotta
fill 134 161 281 134 161 282 minecraft:red_terracotta
fill 134 161 284 135 161 285 minecraft:red_terracotta
fill 134 161 287 134 161 289 minecraft:red_terracotta
fill 134 161 303 134 161 304 minecraft:red_terracotta
fill 134 161 308 135 161 309 minecraft:red_terracotta
fill 134 161 311 135 161 311 minecraft:red_terracotta
fill 134 161 314 135 161 314 minecraft:red_terracotta
fill 135 161 277 135 219 278 minecraft:red_terracotta
fill 135 161 280 135 161 281 minecraft:red_terracotta
setblock 135 161 283 minecraft:red_terracotta
fill 135 161 286 135 161 287 minecraft:red_terracotta
fill 135 161 289 135 161 302 minecraft:red_terracotta
fill 135 161 304 135 161 305 minecraft:red_terracotta
setblock 135 161 307 minecraft:red_terracotta
fill 135 161 310 135 219 310 minecraft:red_terracotta
setblock 135 161 313 minecraft:red_terracotta
setblock 136 161 279 minecraft:red_concrete
fill 136 161 280 136 163 280 minecraft:shroomlight
setblock 136 161 287 minecraft:red_concrete
fill 136 161 288 136 163 288 minecraft:shroomlight
setblock 136 161 295 minecraft:red_concrete
fill 136 161 296 136 163 296 minecraft:shroomlight
setblock 136 161 303 minecraft:red_concrete
fill 136 161 304 136 163 304 minecraft:shroomlight
setblock 136 161 311 minecraft:red_concrete
fill 136 161 312 136 163 312 minecraft:shroomlight
fill 94 162 275 94 163 276 minecraft:white_concrete
fill 94 162 277 94 163 278 minecraft:red_concrete
fill 94 162 279 94 163 279 minecraft:white_concrete
fill 94 162 281 94 163 282 minecraft:red_concrete
fill 94 162 283 94 163 284 minecraft:white_concrete
fill 94 162 285 94 163 286 minecraft:red_concrete
fill 94 162 287 94 163 287 minecraft:white_concrete
fill 94 162 289 94 163 290 minecraft:red_concrete
fill 94 162 291 94 163 292 minecraft:white_concrete
fill 94 162 293 94 163 294 minecraft:red_concrete
fill 94 162 295 94 163 295 minecraft:white_concrete
fill 94 162 297 94 163 298 minecraft:red_concrete
fill 94 162 299 94 163 300 minecraft:white_concrete
fill 94 162 301 94 163 302 minecraft:red_concrete
fill 94 162 303 94 163 303 minecraft:white_concrete
fill 94 162 305 94 163 306 minecraft:red_concrete
fill 94 162 307 94 163 308 minecraft:white_concrete
fill 94 162 309 94 163 310 minecraft:red_concrete
fill 94 162 311 94 163 311 minecraft:white_concrete
fill 94 162 313 94 163 314 minecraft:red_concrete
fill 94 162 315 94 163 316 minecraft:white_concrete
fill 95 162 275 95 163 275 minecraft:white_concrete
fill 95 162 282 95 219 283 minecraft:red_terracotta
fill 95 162 290 95 162 300 minecraft:red_terracotta
fill 95 162 306 95 219 307 minecraft:red_terracotta
fill 95 162 317 95 163 317 minecraft:white_concrete
fill 96 162 275 97 163 275 minecraft:red_concrete
fill 96 162 276 97 219 276 minecraft:red_terracotta
fill 96 162 289 96 162 291 minecraft:red_terracotta
fill 96 162 292 106 162 300 minecraft:bricks
fill 96 162 301 96 162 303 minecraft:red_terracotta
fill 96 162 317 96 163 317 minecraft:red_concrete
setblock 97 162 278 minecraft:light[level=15]
setblock 97 162 286 minecraft:light[level=15]
fill 97 162 287 97 162 288 minecraft:red_terracotta
fill 97 162 289 112 162 291 minecraft:bricks
fill 97 162 301 106 162 303 minecraft:bricks
fill 97 162 304 97 162 305 minecraft:red_terracotta
setblock 97 162 310 minecraft:light[level=15]
fill 98 162 275 99 163 275 minecraft:white_concrete
fill 98 162 279 98 162 284 minecraft:yellow_concrete
fill 98 162 285 98 162 286 minecraft:red_terracotta
fill 98 162 287 132 162 288 minecraft:bricks
fill 98 162 304 108 162 305 minecraft:bricks
fill 98 162 306 98 162 307 minecraft:red_terracotta
fill 98 162 308 98 162 313 minecraft:yellow_concrete
fill 98 162 317 99 163 317 minecraft:white_concrete
fill 99 162 279 103 162 279 minecraft:yellow_concrete
setblock 99 162 284 minecraft:red_terracotta
fill 99 162 285 131 162 286 minecraft:bricks
fill 99 162 306 108 162 307 minecraft:bricks
setblock 99 162 308 minecraft:red_terracotta
fill 99 162 313 103 162 313 minecraft:yellow_concrete
fill 100 162 275 100 163 275 minecraft:red_concrete
fill 100 162 283 100 163 283 minecraft:red_terracotta
fill 100 162 284 130 162 284 minecraft:bricks
fill 100 162 308 130 162 308 minecraft:bricks
fill 100 162 309 100 163 309 minecraft:red_terracotta
fill 100 162 317 101 163 317 minecraft:red_concrete
fill 101 162 283 129 163 283 minecraft:bricks
fill 101 162 309 129 163 309 minecraft:bricks
fill 101 162 316 102 219 316 minecraft:red_terracotta
fill 102 162 275 103 163 275 minecraft:white_concrete
fill 102 162 281 102 163 281 minecraft:red_terracotta
fill 102 162 311 102 163 311 minecraft:red_terracotta
fill 102 162 317 103 163 317 minecraft:white_concrete
setblock 103 162 280 minecraft:red_terracotta
fill 103 162 281 127 162 281 minecraft:bricks
fill 103 162 311 127 162 311 minecraft:bricks
setblock 103 162 312 minecraft:red_terracotta
fill 104 162 275 105 163 275 minecraft:red_concrete
fill 104 162 276 105 219 276 minecraft:red_terracotta
fill 104 162 279 105 162 279 minecraft:red_terracotta
fill 104 162 280 126 162 280 minecraft:bricks
fill 104 162 312 126 162 312 minecraft:bricks
fill 104 162 313 105 162 313 minecraft:red_terracotta
fill 104 162 317 104 163 317 minecraft:red_concrete
setblock 105 162 278 minecraft:light[level=15]
fill 106 162 275 107 163 275 minecraft:white_concrete
fill 106 162 278 107 162 278 minecraft:red_terracotta
fill 106 162 279 124 162 279 minecraft:bricks
fill 106 162 313 124 162 313 minecraft:bricks
fill 106 162 314 107 162 314 minecraft:red_terracotta
fill 106 162 317 107 163 317 minecraft:white_concrete
fill 107 162 292 107 162 295 minecraft:bricks
fill 107 162 296 107 162 301 minecraft:shroomlight
fill 107 162 302 107 163 303 minecraft:bricks
fill 108 162 275 108 163 275 minecraft:red_concrete
fill 108 162 277 110 162 277 minecraft:red_terracotta
fill 108 162 278 122 162 278 minecraft:bricks
fill 108 162 292 108 162 293 minecraft:bricks
fill 108 162 294 108 162 295 minecraft:shroomlight
setblock 108 162 302 minecraft:shroomlight
setblock 108 162 303 minecraft:bricks
fill 108 162 314 122 162 314 minecraft:bricks
fill 108 162 315 110 162 315 minecraft:red_terracotta
fill 108 162 317 109 163 317 minecraft:red_concrete
fill 109 162 292 110 162 292 minecraft:bricks
fill 109 162 293 110 162 293 minecraft:shroomlight
setblock 109 162 303 minecraft:shroomlight
fill 109 162 306 111 165 306 minecraft:bricks
fill 109 162 316 119 162 316 minecraft:red_terracotta
fill 110 162 275 111 163 275 minecraft:white_concrete
setblock 110 162 304 minecraft:shroomlight
fill 110 162 317 111 163 317 minecraft:white_concrete
fill 111 162 276 121 162 276 minecraft:red_terracotta
fill 111 162 277 119 162 277 minecraft:bricks
fill 111 162 292 112 162 292 minecraft:shroomlight
fill 111 162 305 116 162 305 minecraft:shroomlight
fill 111 162 315 119 162 315 minecraft:bricks
fill 112 162 275 113 163 275 minecraft:red_concrete
fill 112 162 317 112 163 317 minecraft:red_concrete
fill 113 162 289 133 162 290 minecraft:bricks
fill 113 162 291 115 162 291 minecraft:shroomlight
setblock 113 162 294 minecraft:light[level=15]
setblock 113 162 302 minecraft:light[level=15]
fill 113 162 306 131 162 307 minecraft:bricks
fill 114 162 275 115 163 275 minecraft:white_concrete
fill 114 162 317 115 163 317 minecraft:white_concrete
fill 116 162 275 116 163 275 minecraft:red_concrete
fill 116 162 291 133 162 291 minecraft:bricks
fill 116 162 292 117 162 292 minecraft:shroomlight
fill 116 162 317 117 163 317 minecraft:red_concrete
fill 117 162 304 118 162 304 minecraft:shroomlight
fill 117 162 305 132 162 305 minecraft:bricks
fill 118 162 275 119 163 275 minecraft:white_concrete
fill 118 162 292 134 162 292 minecraft:bricks
fill 118 162 293 119 162 293 minecraft:shroomlight
fill 118 162 317 119 163 317 minecraft:white_concrete
setblock 119 162 294 minecraft:shroomlight
setblock 119 162 303 minecraft:shroomlight
fill 119 162 304 132 162 304 minecraft:bricks
fill 120 162 275 121 163 275 minecraft:red_concrete
fill 120 162 277 122 162 277 minecraft:red_terracotta
fill 120 162 293 134 162 294 minecraft:bricks
fill 120 162 295 120 162 296 minecraft:shroomlight
fill 120 162 301 120 162 302 minecraft:shroomlight
fill 120 162 303 133 162 303 minecraft:bricks
fill 120 162 315 122 162 315 minecraft:red_terracotta
fill 120 162 317 120 163 317 minecraft:red_concrete
fill 121 162 295 134 162 296 minecraft:bricks
fill 121 162 297 121 162 300 minecraft:shroomlight
fill 121 162 301 133 162 302 minecraft:bricks
fill 122 162 275 123 163 275 minecraft:white_concrete
fill 122 162 297 134 162 300 minecraft:bricks
fill 122 162 317 123 163 317 minecraft:white_concrete
fill 123 162 278 124 162 278 minecraft:red_terracotta
fill 123 162 314 124 162 314 minecraft:red_terracotta
fill 124 162 275 124 163 275 minecraft:red_concrete
fill 124 162 317 125 163 317 minecraft:red_concrete
fill 125 162 279 126 162 279 minecraft:red_terracotta
fill 125 162 313 126 162 313 minecraft:red_terracotta
fill 125 162 316 126 219 316 minecraft:red_terracotta
fill 126 162 275 127 163 275 minecraft:white_concrete
fill 126 162 317 127 163 317 minecraft:white_concrete
fill 127 162 279 132 162 279 minecraft:yellow_concrete
setblock 127 162 280 minecraft:red_terracotta
setblock 127 162 312 minecraft:red_terracotta
fill 127 162 313 132 162 313 minecraft:yellow_concrete
fill 128 162 275 129 163 275 minecraft:red_concrete
fill 128 162 276 129 219 276 minecraft:red_terracotta
fill 128 162 281 128 163 281 minecraft:red_terracotta
fill 128 162 311 128 163 311 minecraft:red_terracotta
fill 128 162 317 128 163 317 minecraft:red_concrete
setblock 129 162 278 minecraft:light[level=15]
fill 130 162 275 131 163 275 minecraft:white_concrete
fill 130 162 283 130 163 283 minecraft:red_terracotta
fill 130 162 309 130 163 309 minecraft:red_terracotta
fill 130 162 317 131 163 317 minecraft:white_concrete
setblock 131 162 284 minecraft:red_terracotta
fill 131 162 308 131 163 308 minecraft:red_terracotta
fill 132 162 275 132 163 275 minecraft:red_concrete
fill 132 162 280 132 162 284 minecraft:yellow_concrete
fill 132 162 285 132 162 286 minecraft:red_terracotta
fill 132 162 306 132 162 307 minecraft:red_terracotta
fill 132 162 308 132 162 312 minecraft:yellow_concrete
fill 132 162 317 133 163 317 minecraft:red_concrete
fill 133 162 287 133 162 288 minecraft:red_terracotta
fill 133 162 304 133 162 305 minecraft:red_terracotta
fill 133 162 307 133 219 307 minecraft:iron_block
fill 133 162 316 134 219 316 minecraft:red_terracotta
fill 134 162 275 135 163 275 minecraft:white_concrete
fill 134 162 289 134 162 291 minecraft:red_terracotta
fill 134 162 301 134 162 303 minecraft:red_terracotta
fill 134 162 317 135 163 317 minecraft:white_concrete
fill 135 162 285 135 219 286 minecraft:red_terracotta
fill 135 162 292 135 162 302 minecraft:red_terracotta
fill 135 162 309 135 219 309 minecraft:red_terracotta
fill 136 162 276 136 163 276 minecraft:white_concrete
fill 136 162 277 136 163 278 minecraft:red_concrete
fill 136 162 279 136 163 279 minecraft:white_concrete
fill 136 162 281 136 163 282 minecraft:red_concrete
fill 136 162 283 136 163 284 minecraft:white_concrete
fill 136 162 285 136 163 286 minecraft:red_concrete
fill 136 162 287 136 163 287 minecraft:white_concrete
fill 136 162 289 136 163 290 minecraft:red_concrete
fill 136 162 291 136 163 292 minecraft:white_concrete
fill 136 162 293 136 163 294 minecraft:red_concrete
fill 136 162 295 136 163 295 minecraft:white_concrete
fill 136 162 297 136 163 298 minecraft:red_concrete
fill 136 162 299 136 163 300 minecraft:white_concrete
fill 136 162 301 136 163 302 minecraft:red_concrete
fill 136 162 303 136 163 303 minecraft:white_concrete
fill 136 162 305 136 163 306 minecraft:red_concrete
fill 136 162 307 136 163 308 minecraft:white_concrete
fill 136 162 309 136 163 310 minecraft:red_concrete
fill 136 162 311 136 163 311 minecraft:white_concrete
fill 136 162 313 136 163 314 minecraft:red_concrete
fill 136 162 315 136 163 316 minecraft:white_concrete
fill 136 162 317 136 163 317 minecraft:red_concrete
fill 95 163 290 96 163 291 minecraft:red_terracotta
fill 95 163 298 96 164 299 minecraft:red_terracotta
fill 96 163 292 96 163 297 minecraft:red_terracotta
fill 96 163 300 96 163 302 minecraft:red_terracotta
fill 97 163 288 97 163 289 minecraft:red_terracotta
fill 97 163 290 105 163 302 minecraft:bricks
fill 97 163 303 97 163 304 minecraft:red_terracotta
fill 98 163 286 98 163 287 minecraft:red_terracotta
fill 98 163 288 132 163 289 minecraft:bricks
fill 98 163 303 106 163 304 minecraft:bricks
fill 98 163 305 98 163 306 minecraft:red_terracotta
setblock 99 163 285 minecraft:red_terracotta
fill 99 163 286 131 163 287 minecraft:bricks
fill 99 163 305 108 163 306 minecraft:bricks
setblock 99 163 307 minecraft:red_terracotta
fill 100 163 284 100 164 284 minecraft:red_terracotta
fill 100 163 285 130 163 285 minecraft:bricks
fill 100 163 307 108 163 307 minecraft:bricks
fill 100 163 308 100 164 308 minecraft:red_terracotta
setblock 101 163 282 minecraft:red_terracotta
fill 101 163 284 129 164 284 minecraft:bricks
fill 101 163 308 129 164 308 minecraft:bricks
setblock 101 163 310 minecraft:red_terracotta
fill 102 163 282 128 163 282 minecraft:bricks
fill 102 163 310 128 163 310 minecraft:bricks
fill 103 163 281 103 164 281 minecraft:red_terracotta
fill 103 163 311 103 164 311 minecraft:red_terracotta
setblock 104 163 280 minecraft:red_terracotta
fill 104 163 281 126 163 281 minecraft:bricks
fill 104 163 311 126 163 311 minecraft:bricks
setblock 104 163 312 minecraft:red_terracotta
fill 105 163 279 106 163 279 minecraft:red_terracotta
fill 105 163 280 125 163 280 minecraft:bricks
fill 105 163 312 125 163 312 minecraft:bricks
fill 105 163 313 106 163 313 minecraft:red_terracotta
fill 106 163 290 106 163 296 minecraft:bricks
fill 106 163 297 106 164 299 minecraft:magma_block
fill 106 163 300 106 163 302 minecraft:bricks
fill 107 163 278 108 163 278 minecraft:red_terracotta
fill 107 163 279 123 163 279 minecraft:bricks
fill 107 163 290 107 163 294 minecraft:bricks
fill 107 163 295 107 163 296 minecraft:magma_block
fill 107 163 300 107 163 301 minecraft:magma_block
fill 107 163 304 108 165 304 minecraft:bricks
fill 107 163 313 123 163 313 minecraft:bricks
fill 107 163 314 108 163 314 minecraft:red_terracotta
fill 108 163 290 108 163 292 minecraft:bricks
fill 108 163 293 108 163 294 minecraft:magma_block
fill 108 163 302 108 163 303 minecraft:magma_block
fill 109 163 277 121 163 277 minecraft:red_terracotta
fill 109 163 278 121 163 278 minecraft:bricks
fill 109 163 290 110 163 291 minecraft:bricks
fill 109 163 292 110 163 292 minecraft:magma_block
fill 109 163 304 110 163 304 minecraft:magma_block
fill 109 163 305 109 165 305 minecraft:bricks
fill 109 163 314 121 163 314 minecraft:bricks
fill 109 163 315 110 163 316 minecraft:red_terracotta
fill 110 163 276 113 163 276 minecraft:red_terracotta
fill 111 163 290 112 163 290 minecraft:bricks
fill 111 163 291 112 163 291 minecraft:magma_block
fill 111 163 305 112 163 305 minecraft:magma_block
fill 111 163 315 121 163 315 minecraft:red_terracotta
fill 113 163 290 115 163 290 minecraft:magma_block
fill 113 163 306 115 164 306 minecraft:magma_block
fill 113 163 307 130 163 307 minecraft:bricks
fill 116 163 290 133 163 290 minecraft:bricks
fill 116 163 291 117 163 291 minecraft:magma_block
fill 116 163 305 117 163 305 minecraft:magma_block
fill 116 163 306 131 163 306 minecraft:bricks
fill 117 163 316 118 219 316 minecraft:red_terracotta
fill 118 163 291 133 163 291 minecraft:bricks
fill 118 163 292 119 163 292 minecraft:magma_block
fill 118 163 304 119 163 304 minecraft:magma_block
fill 118 163 305 131 163 305 minecraft:bricks
fill 120 163 276 121 219 276 minecraft:red_terracotta
fill 120 163 292 133 163 292 minecraft:bricks
fill 120 163 293 120 163 294 minecraft:magma_block
fill 120 163 302 120 163 303 minecraft:magma_block
fill 120 163 304 132 163 304 minecraft:bricks
fill 121 163 293 133 163 294 minecraft:bricks
fill 121 163 295 121 163 296 minecraft:magma_block
fill 121 163 300 121 163 301 minecraft:magma_block
fill 121 163 302 132 163 303 minecraft:bricks
fill 122 163 278 123 163 278 minecraft:red_terracotta
fill 122 163 295 133 163 296 minecraft:bricks
fill 122 163 297 122 164 299 minecraft:magma_block
fill 122 163 300 133 163 301 minecraft:bricks
fill 122 163 314 123 163 314 minecraft:red_terracotta
fill 123 163 297 133 164 299 minecraft:bricks
fill 124 163 279 125 163 279 minecraft:red_terracotta
fill 124 163 313 125 163 313 minecraft:red_terracotta
setblock 126 163 280 minecraft:red_terracotta
setblock 126 163 312 minecraft:red_terracotta
fill 127 163 281 127 164 281 minecraft:red_terracotta
fill 127 163 311 127 164 311 minecraft:red_terracotta
setblock 129 163 282 minecraft:red_terracotta
setblock 129 163 310 minecraft:red_terracotta
fill 130 163 284 130 164 284 minecraft:red_terracotta
fill 130 163 308 130 164 308 minecraft:red_terracotta
setblock 131 163 285 minecraft:red_terracotta
setblock 131 163 307 minecraft:red_terracotta
fill 132 163 286 132 163 287 minecraft:red_terracotta
fill 132 163 305 132 163 306 minecraft:red_terracotta
fill 132 163 307 132 219 308 minecraft:iron_block
fill 133 163 288 133 163 289 minecraft:red_terracotta
setblock 133 163 302 minecraft:bricks
fill 133 163 303 133 163 304 minecraft:red_terracotta
setblock 133 163 306 minecraft:red_terracotta
setblock 133 163 308 minecraft:red_terracotta
fill 134 163 290 134 163 302 minecraft:red_terracotta
fill 135 163 293 135 219 294 minecraft:red_terracotta
fill 135 163 301 135 219 302 minecraft:red_terracotta
fill 94 164 275 94 165 276 minecraft:red_concrete
fill 94 164 277 94 165 278 minecraft:white_concrete
fill 94 164 279 94 165 280 minecraft:red_concrete
fill 94 164 281 94 165 282 minecraft:white_concrete
fill 94 164 283 94 165 284 minecraft:red_concrete
fill 94 164 285 94 165 286 minecraft:white_concrete
fill 94 164 287 94 165 288 minecraft:red_concrete
fill 94 164 289 94 165 290 minecraft:white_concrete
fill 94 164 291 94 165 292 minecraft:red_concrete
fill 94 164 293 94 165 294 minecraft:white_concrete
fill 94 164 295 94 165 296 minecraft:red_concrete
fill 94 164 297 94 165 298 minecraft:white_concrete
fill 94 164 299 94 165 300 minecraft:red_concrete
fill 94 164 301 94 165 302 minecraft:white_concrete
fill 94 164 303 94 165 304 minecraft:red_concrete
fill 94 164 305 94 165 306 minecraft:white_concrete
fill 94 164 307 94 165 308 minecraft:red_concrete
fill 94 164 309 94 165 310 minecraft:white_concrete
fill 94 164 311 94 165 312 minecraft:red_concrete
fill 94 164 313 94 165 314 minecraft:white_concrete
fill 94 164 315 94 165 316 minecraft:red_concrete
fill 95 164 275 95 165 275 minecraft:red_concrete
fill 95 164 290 95 219 291 minecraft:red_terracotta
fill 95 164 317 95 165 317 minecraft:red_concrete
fill 96 164 275 97 165 275 minecraft:white_concrete
fill 96 164 293 96 164 297 minecraft:red_terracotta
fill 96 164 317 97 165 317 minecraft:white_concrete
setblock 97 164 278 minecraft:light[level=12]
setblock 97 164 285 minecraft:light[level=12]
fill 97 164 289 97 164 292 minecraft:red_terracotta
fill 97 164 293 105 164 299 minecraft:bricks
fill 97 164 300 97 164 303 minecraft:red_terracotta
setblock 97 164 306 minecraft:light[level=12]
setblock 97 164 313 minecraft:light[level=12]
fill 98 164 275 99 165 275 minecraft:red_concrete
fill 98 164 287 98 164 288 minecraft:red_terracotta
fill 98 164 289 107 164 292 minecraft:bricks
fill 98 164 300 105 164 303 minecraft:bricks
fill 98 164 304 98 164 305 minecraft:red_terracotta
fill 98 164 317 99 165 317 minecraft:red_concrete
setblock 99 164 286 minecraft:red_terracotta
fill 99 164 287 131 164 288 minecraft:bricks
fill 99 164 304 106 164 305 minecraft:bricks
setblock 99 164 306 minecraft:red_terracotta
fill 100 164 275 101 165 275 minecraft:white_concrete
fill 100 164 285 100 165 285 minecraft:red_terracotta
fill 100 164 286 130 164 286 minecraft:bricks
fill 100 164 306 108 164 306 minecraft:bricks
fill 100 164 307 100 165 307 minecraft:red_terracotta
fill 100 164 317 101 165 317 minecraft:white_concrete
setblock 101 164 283 minecraft:red_terracotta
fill 101 164 285 129 165 285 minecraft:bricks
fill 101 164 307 108 165 307 minecraft:bricks
setblock 101 164 309 minecraft:red_terracotta
fill 102 164 275 103 165 275 minecraft:red_concrete
setblock 102 164 282 minecraft:red_terracotta
fill 102 164 283 128 164 283 minecraft:bricks
fill 102 164 309 128 164 309 minecraft:bricks
setblock 102 164 310 minecraft:red_terracotta
fill 102 164 317 103 165 317 minecraft:red_concrete
fill 103 164 282 127 164 282 minecraft:bricks
fill 103 164 310 127 164 310 minecraft:bricks
fill 104 164 275 105 165 275 minecraft:white_concrete
setblock 104 164 278 minecraft:light[level=12]
fill 104 164 281 104 165 281 minecraft:red_terracotta
fill 104 164 311 104 165 311 minecraft:red_terracotta
setblock 104 164 313 minecraft:light[level=12]
fill 104 164 317 105 165 317 minecraft:white_concrete
setblock 105 164 280 minecraft:red_terracotta
fill 105 164 281 125 164 281 minecraft:bricks
fill 105 164 311 125 164 311 minecraft:bricks
setblock 105 164 312 minecraft:red_terracotta
fill 106 164 275 107 165 275 minecraft:red_concrete
fill 106 164 279 107 164 279 minecraft:red_terracotta
fill 106 164 280 124 164 280 minecraft:bricks
fill 106 164 293 106 164 294 minecraft:bricks
fill 106 164 295 106 164 296 minecraft:magma_block
setblock 106 164 300 minecraft:magma_block
fill 106 164 301 106 164 303 minecraft:bricks
fill 106 164 312 124 164 312 minecraft:bricks
fill 106 164 313 107 164 313 minecraft:red_terracotta
fill 106 164 317 107 165 317 minecraft:red_concrete
setblock 107 164 293 minecraft:bricks
setblock 107 164 294 minecraft:magma_block
fill 107 164 301 107 164 302 minecraft:magma_block
fill 107 164 303 107 165 303 minecraft:bricks
fill 107 164 305 108 168 305 minecraft:bricks
fill 108 164 275 109 165 275 minecraft:white_concrete
fill 108 164 278 111 164 278 minecraft:red_terracotta
fill 108 164 279 122 164 279 minecraft:bricks
fill 108 164 289 108 164 291 minecraft:bricks
fill 108 164 292 108 164 293 minecraft:magma_block
setblock 108 164 303 minecraft:magma_block
fill 108 164 313 122 164 313 minecraft:bricks
fill 108 164 314 111 164 314 minecraft:red_terracotta
fill 108 164 317 109 165 317 minecraft:white_concrete
fill 109 164 289 110 164 290 minecraft:bricks
fill 109 164 291 110 164 291 minecraft:magma_block
setblock 109 164 304 minecraft:magma_block
fill 109 164 316 110 219 316 minecraft:red_terracotta
fill 110 164 275 111 165 275 minecraft:red_concrete
fill 110 164 277 111 167 277 minecraft:iron_block
fill 110 164 305 111 164 305 minecraft:magma_block
fill 110 164 317 111 165 317 minecraft:red_concrete
fill 111 164 289 113 164 289 minecraft:bricks
fill 111 164 290 113 164 290 minecraft:magma_block
setblock 111 164 292 minecraft:light[level=12]
setblock 111 164 299 minecraft:light[level=12]
fill 112 164 275 113 165 275 minecraft:white_concrete
fill 112 164 276 113 164 277 minecraft:red_terracotta
fill 112 164 278 118 164 278 minecraft:bricks
setblock 112 164 306 minecraft:magma_block
fill 112 164 307 129 165 307 minecraft:bricks
fill 112 164 314 118 164 314 minecraft:bricks
fill 112 164 315 118 164 315 minecraft:red_terracotta
fill 112 164 317 113 165 317 minecraft:white_concrete
fill 114 164 275 115 165 275 minecraft:red_concrete
fill 114 164 277 118 164 277 minecraft:red_terracotta
setblock 114 164 289 minecraft:magma_block
fill 114 164 317 115 165 317 minecraft:red_concrete
fill 115 164 289 132 164 289 minecraft:bricks
fill 115 164 290 118 164 290 minecraft:magma_block
fill 116 164 275 117 165 275 minecraft:white_concrete
setblock 116 164 306 minecraft:magma_block
fill 116 164 317 117 165 317 minecraft:white_concrete
fill 117 164 305 118 164 305 minecraft:magma_block
fill 117 164 306 130 164 306 minecraft:bricks
fill 118 164 275 119 165 275 minecraft:red_concrete
fill 118 164 291 119 164 291 minecraft:magma_block
setblock 118 164 292 minecraft:light[level=12]
setblock 118 164 299 minecraft:light[level=12]
fill 118 164 317 119 165 317 minecraft:red_concrete
fill 119 164 278 122 164 278 minecraft:red_terracotta
fill 119 164 290 132 164 290 minecraft:bricks
setblock 119 164 304 minecraft:magma_block
fill 119 164 305 131 164 305 minecraft:bricks
fill 119 164 314 122 164 314 minecraft:red_terracotta
fill 120 164 275 121 165 275 minecraft:white_concrete
fill 120 164 291 132 164 291 minecraft:bricks
setblock 120 164 292 minecraft:magma_block
setblock 120 164 303 minecraft:magma_block
fill 120 164 304 131 164 304 minecraft:bricks
fill 120 164 317 121 165 317 minecraft:white_concrete
fill 121 164 292 132 164 292 minecraft:bricks
fill 121 164 293 121 164 294 minecraft:magma_block
setblock 121 164 302 minecraft:magma_block
fill 121 164 303 132 164 303 minecraft:bricks
fill 122 164 275 123 165 275 minecraft:red_concrete
fill 122 164 293 133 164 294 minecraft:bricks
fill 122 164 295 122 164 296 minecraft:magma_block
fill 122 164 300 122 164 301 minecraft:magma_block
fill 122 164 302 132 164 302 minecraft:bricks
fill 122 164 317 123 165 317 minecraft:red_concrete
fill 123 164 279 124 219 279 minecraft:red_terracotta
fill 123 164 295 133 164 296 minecraft:bricks
fill 123 164 300 132 164 301 minecraft:bricks
fill 123 164 313 124 164 313 minecraft:red_terracotta
fill 124 164 275 125 165 275 minecraft:white_concrete
fill 124 164 317 125 165 317 minecraft:white_concrete
setblock 125 164 278 minecraft:light[level=12]
fill 125 164 280 125 219 280 minecraft:red_terracotta
setblock 125 164 312 minecraft:red_terracotta
setblock 125 164 313 minecraft:light[level=12]
fill 126 164 275 127 165 275 minecraft:red_concrete
fill 126 164 281 126 219 281 minecraft:red_terracotta
fill 126 164 311 126 165 311 minecraft:red_terracotta
fill 126 164 317 127 165 317 minecraft:red_concrete
fill 128 164 275 129 165 275 minecraft:white_concrete
setblock 128 164 282 minecraft:red_terracotta
setblock 128 164 310 minecraft:red_terracotta
fill 128 164 317 129 165 317 minecraft:white_concrete
setblock 129 164 283 minecraft:red_terracotta
setblock 129 164 309 minecraft:red_terracotta
fill 130 164 275 131 165 275 minecraft:red_concrete
fill 130 164 285 130 165 285 minecraft:red_terracotta
fill 130 164 307 130 165 307 minecraft:red_terracotta
fill 130 164 317 131 165 317 minecraft:red_concrete
setblock 131 164 286 minecraft:red_terracotta
setblock 131 164 306 minecraft:red_terracotta
fill 131 164 307 131 219 307 minecraft:iron_block
fill 132 164 275 133 165 275 minecraft:white_concrete
setblock 132 164 278 minecraft:light[level=12]
setblock 132 164 285 minecraft:light[level=12]
fill 132 164 287 132 164 288 minecraft:red_terracotta
fill 132 164 304 132 164 305 minecraft:red_terracotta
fill 132 164 306 132 219 306 minecraft:iron_block
setblock 132 164 313 minecraft:light[level=12]
fill 132 164 317 133 165 317 minecraft:white_concrete
fill 133 164 289 133 164 292 minecraft:red_terracotta
fill 133 164 300 133 164 303 minecraft:red_terracotta
fill 134 164 275 135 165 275 minecraft:red_concrete
fill 134 164 293 134 164 299 minecraft:red_terracotta
fill 134 164 317 135 165 317 minecraft:red_concrete
fill 136 164 276 136 165 276 minecraft:red_concrete
fill 136 164 277 136 165 278 minecraft:white_concrete
fill 136 164 279 136 165 280 minecraft:red_concrete
fill 136 164 281 136 165 282 minecraft:white_concrete
fill 136 164 283 136 165 284 minecraft:red_concrete
fill 136 164 285 136 165 286 minecraft:white_concrete
fill 136 164 287 136 165 288 minecraft:red_concrete
fill 136 164 289 136 165 290 minecraft:white_concrete
fill 136 164 291 136 165 292 minecraft:red_concrete
fill 136 164 293 136 165 294 minecraft:white_concrete
fill 136 164 295 136 165 296 minecraft:red_concrete
fill 136 164 297 136 165 298 minecraft:white_concrete
fill 136 164 299 136 165 300 minecraft:red_concrete
fill 136 164 301 136 165 302 minecraft:white_concrete
fill 136 164 303 136 165 304 minecraft:red_concrete
fill 136 164 305 136 165 306 minecraft:white_concrete
fill 136 164 307 136 165 308 minecraft:red_concrete
fill 136 164 309 136 165 310 minecraft:white_concrete
fill 136 164 311 136 165 312 minecraft:red_concrete
fill 136 164 313 136 165 314 minecraft:white_concrete
fill 136 164 315 136 165 316 minecraft:red_concrete
fill 136 164 317 136 165 317 minecraft:white_concrete
fill 95 165 298 95 219 299 minecraft:red_terracotta
fill 97 165 292 97 165 300 minecraft:red_terracotta
fill 98 165 289 98 165 291 minecraft:red_terracotta
fill 98 165 292 105 165 300 minecraft:bricks
fill 98 165 301 98 165 303 minecraft:red_terracotta
fill 99 165 287 99 165 288 minecraft:red_terracotta
fill 99 165 289 107 165 291 minecraft:bricks
fill 99 165 301 105 165 303 minecraft:bricks
fill 99 165 304 99 165 305 minecraft:red_terracotta
setblock 100 165 286 minecraft:red_terracotta
fill 100 165 287 130 165 288 minecraft:bricks
fill 100 165 304 106 165 305 minecraft:bricks
setblock 100 165 306 minecraft:red_terracotta
setblock 101 165 284 minecraft:red_terracotta
fill 101 165 286 129 165 286 minecraft:bricks
fill 101 165 306 108 165 306 minecraft:bricks
setblock 101 165 308 minecraft:red_terracotta
setblock 102 165 283 minecraft:red_terracotta
fill 102 165 284 128 165 284 minecraft:bricks
fill 102 165 308 128 165 308 minecraft:bricks
setblock 102 165 309 minecraft:red_terracotta
setblock 103 165 282 minecraft:red_terracotta
fill 103 165 283 127 165 283 minecraft:bricks
fill 103 165 309 127 165 309 minecraft:bricks
setblock 103 165 310 minecraft:red_terracotta
fill 104 165 282 126 165 282 minecraft:bricks
fill 104 165 310 126 165 310 minecraft:bricks
setblock 105 165 281 minecraft:red_terracotta
setblock 105 165 311 minecraft:red_terracotta
fill 106 165 280 107 165 280 minecraft:red_terracotta
fill 106 165 281 124 165 281 minecraft:bricks
fill 106 165 292 106 165 293 minecraft:bricks
fill 106 165 294 106 165 301 minecraft:shroomlight
fill 106 165 302 106 166 303 minecraft:bricks
fill 106 165 311 124 165 311 minecraft:bricks
fill 106 165 312 107 165 312 minecraft:red_terracotta
fill 107 165 292 107 165 293 minecraft:shroomlight
setblock 107 165 302 minecraft:shroomlight
fill 108 165 279 110 165 279 minecraft:red_terracotta
fill 108 165 280 122 165 280 minecraft:bricks
fill 108 165 289 109 165 290 minecraft:bricks
fill 108 165 291 109 165 291 minecraft:shroomlight
setblock 108 165 303 minecraft:shroomlight
fill 108 165 312 122 165 312 minecraft:bricks
fill 108 165 313 110 165 313 minecraft:red_terracotta
setblock 109 165 304 minecraft:shroomlight
fill 110 165 278 110 219 278 minecraft:iron_block
setblock 110 165 289 minecraft:bricks
setblock 110 165 290 minecraft:shroomlight
fill 110 165 305 111 165 305 minecraft:shroomlight
fill 111 165 278 119 165 278 minecraft:red_terracotta
fill 111 165 279 119 165 279 minecraft:bricks
fill 111 165 289 118 165 289 minecraft:shroomlight
fill 111 165 313 119 165 313 minecraft:bricks
fill 111 165 314 119 165 314 minecraft:red_terracotta
fill 112 165 276 113 219 276 minecraft:red_terracotta
fill 112 165 277 112 167 277 minecraft:iron_block
fill 112 165 306 117 165 306 minecraft:shroomlight
fill 116 165 292 117 219 294 minecraft:red_terracotta
fill 118 165 292 118 219 293 minecraft:red_terracotta
fill 118 165 305 119 165 305 minecraft:shroomlight
fill 118 165 306 129 165 306 minecraft:bricks
fill 119 165 289 131 165 289 minecraft:bricks
setblock 119 165 290 minecraft:shroomlight
fill 120 165 279 122 165 279 minecraft:red_terracotta
fill 120 165 290 131 165 290 minecraft:bricks
setblock 120 165 291 minecraft:shroomlight
setblock 120 165 304 minecraft:shroomlight
fill 120 165 305 130 165 305 minecraft:bricks
fill 120 165 313 122 165 313 minecraft:red_terracotta
fill 121 165 291 131 165 291 minecraft:bricks
setblock 121 165 292 minecraft:shroomlight
setblock 121 165 303 minecraft:shroomlight
fill 121 165 304 130 165 304 minecraft:bricks
fill 122 165 292 132 165 292 minecraft:bricks
fill 122 165 293 122 165 294 minecraft:shroomlight
fill 122 165 301 122 165 302 minecraft:shroomlight
fill 122 165 303 131 165 303 minecraft:bricks
fill 123 165 280 124 219 280 minecraft:red_terracotta
fill 123 165 293 132 165 294 minecraft:bricks
fill 123 165 295 123 165 300 minecraft:shroomlight
fill 123 165 301 131 165 302 minecraft:bricks
fill 123 165 312 124 165 312 minecraft:red_terracotta
fill 124 165 278 125 219 278 minecraft:red_terracotta
fill 124 165 295 132 165 300 minecraft:bricks
fill 125 165 279 126 219 279 minecraft:red_terracotta
fill 125 165 281 125 219 281 minecraft:red_terracotta
setblock 125 165 311 minecraft:red_terracotta
fill 126 165 280 126 219 280 minecraft:red_terracotta
setblock 127 165 282 minecraft:red_terracotta
setblock 127 165 310 minecraft:red_terracotta
setblock 128 165 283 minecraft:red_terracotta
setblock 128 165 309 minecraft:red_terracotta
setblock 129 165 284 minecraft:red_terracotta
setblock 129 165 308 minecraft:red_terracotta
setblock 130 165 286 minecraft:red_terracotta
setblock 130 165 306 minecraft:red_terracotta
fill 131 165 287 131 165 288 minecraft:red_terracotta
fill 131 165 304 131 165 305 minecraft:red_terracotta
fill 132 165 289 132 165 291 minecraft:red_terracotta
fill 132 165 301 132 165 303 minecraft:red_terracotta
fill 133 165 292 133 165 300 minecraft:red_terracotta
fill 94 166 275 94 167 276 minecraft:white_concrete
fill 94 166 277 94 167 278 minecraft:red_concrete
fill 94 166 279 94 167 280 minecraft:white_concrete
fill 94 166 281 94 167 282 minecraft:red_concrete
fill 94 166 283 94 167 284 minecraft:white_concrete
fill 94 166 285 94 167 286 minecraft:red_concrete
fill 94 166 287 94 167 288 minecraft:white_concrete
fill 94 166 289 94 167 290 minecraft:red_concrete
fill 94 166 291 94 167 292 minecraft:white_concrete
fill 94 166 293 94 167 294 minecraft:red_concrete
fill 94 166 295 94 167 296 minecraft:white_concrete
fill 94 166 297 94 167 298 minecraft:red_concrete
fill 94 166 299 94 167 300 minecraft:white_concrete
fill 94 166 301 94 167 302 minecraft:red_concrete
fill 94 166 303 94 167 304 minecraft:white_concrete
fill 94 166 305 94 167 306 minecraft:red_concrete
fill 94 166 307 94 167 308 minecraft:white_concrete
fill 94 166 309 94 167 310 minecraft:red_concrete
fill 94 166 311 94 167 312 minecraft:white_concrete
fill 94 166 313 94 167 314 minecraft:red_concrete
fill 94 166 315 94 167 316 minecraft:white_concrete
fill 95 166 275 95 167 275 minecraft:white_concrete
fill 95 166 317 95 167 317 minecraft:white_concrete
fill 96 166 275 97 167 275 minecraft:red_concrete
fill 96 166 317 97 167 317 minecraft:red_concrete
fill 98 166 275 99 167 275 minecraft:white_concrete
fill 98 166 291 98 166 301 minecraft:red_terracotta
fill 98 166 317 99 167 317 minecraft:white_concrete
fill 99 166 289 99 166 290 minecraft:red_terracotta
fill 99 166 291 104 166 301 minecraft:bricks
fill 99 166 302 99 166 303 minecraft:red_terracotta
fill 100 166 275 101 167 275 minecraft:red_concrete
fill 100 166 287 100 166 288 minecraft:red_terracotta
fill 100 166 289 107 166 290 minecraft:bricks
fill 100 166 302 105 166 303 minecraft:bricks
fill 100 166 304 100 166 305 minecraft:red_terracotta
fill 100 166 317 101 167 317 minecraft:red_concrete
fill 101 166 285 101 166 286 minecraft:red_terracotta
fill 101 166 287 110 166 288 minecraft:bricks
fill 101 166 304 106 166 305 minecraft:bricks
fill 101 166 306 101 166 307 minecraft:red_terracotta
fill 102 166 275 103 167 275 minecraft:white_concrete
fill 102 166 284 102 166 285 minecraft:red_terracotta
fill 102 166 286 128 166 286 minecraft:bricks
fill 102 166 306 110 166 306 minecraft:bricks
fill 102 166 307 102 166 308 minecraft:red_terracotta
fill 102 166 317 103 167 317 minecraft:white_concrete
fill 103 166 283 103 166 284 minecraft:red_terracotta
fill 103 166 285 127 166 285 minecraft:bricks
fill 103 166 307 108 166 307 minecraft:bricks
fill 103 166 308 103 166 309 minecraft:red_terracotta
fill 104 166 275 105 167 275 minecraft:red_concrete
fill 104 166 282 104 166 283 minecraft:red_terracotta
fill 104 166 284 126 166 284 minecraft:bricks
fill 104 166 308 126 166 308 minecraft:bricks
fill 104 166 309 104 166 310 minecraft:red_terracotta
fill 104 166 317 105 167 317 minecraft:red_concrete
setblock 105 166 282 minecraft:red_terracotta
fill 105 166 283 125 166 283 minecraft:bricks
fill 105 166 291 105 166 294 minecraft:bricks
fill 105 166 295 105 167 299 minecraft:magma_block
fill 105 166 300 105 166 301 minecraft:bricks
fill 105 166 309 125 166 309 minecraft:bricks
setblock 105 166 310 minecraft:red_terracotta
fill 106 166 275 107 167 275 minecraft:white_concrete
fill 106 166 281 107 166 281 minecraft:red_terracotta
fill 106 166 282 124 166 282 minecraft:bricks
fill 106 166 291 106 166 292 minecraft:bricks
fill 106 166 293 106 166 294 minecraft:magma_block
fill 106 166 300 106 166 301 minecraft:magma_block
fill 106 166 310 124 166 310 minecraft:bricks
fill 106 166 311 107 166 311 minecraft:red_terracotta
fill 106 166 317 107 167 317 minecraft:white_concrete
fill 107 166 291 107 166 292 minecraft:magma_block
fill 107 166 302 107 166 303 minecraft:magma_block
fill 107 166 304 107 168 304 minecraft:bricks
fill 108 166 275 109 167 275 minecraft:red_concrete
fill 108 166 280 109 166 280 minecraft:red_terracotta
fill 108 166 281 122 166 281 minecraft:bricks
fill 108 166 289 109 166 289 minecraft:bricks
fill 108 166 290 109 166 290 minecraft:magma_block
fill 108 166 304 108 167 304 minecraft:magma_block
fill 108 166 311 122 166 311 minecraft:bricks
fill 108 166 312 109 166 312 minecraft:red_terracotta
fill 108 166 317 109 167 317 minecraft:red_concrete
fill 109 166 305 110 166 305 minecraft:magma_block
fill 110 166 275 111 167 275 minecraft:white_concrete
fill 110 166 276 111 167 276 minecraft:iron_block
fill 110 166 279 120 166 279 minecraft:red_terracotta
fill 110 166 280 120 166 280 minecraft:bricks
setblock 110 166 289 minecraft:magma_block
fill 110 166 312 120 166 312 minecraft:bricks
fill 110 166 313 120 166 313 minecraft:red_terracotta
fill 110 166 317 111 167 317 minecraft:white_concrete
fill 111 166 278 112 167 278 minecraft:iron_block
fill 111 166 287 129 166 287 minecraft:bricks
fill 111 166 288 118 166 288 minecraft:magma_block
fill 111 166 306 118 166 306 minecraft:magma_block
fill 112 166 275 113 167 275 minecraft:red_concrete
fill 112 166 307 127 166 307 minecraft:bricks
fill 112 166 317 113 167 317 minecraft:red_concrete
fill 114 166 275 115 167 275 minecraft:white_concrete
fill 114 166 317 115 167 317 minecraft:white_concrete
fill 115 166 292 115 167 294 minecraft:brown_terracotta
fill 116 166 275 117 167 275 minecraft:red_concrete
fill 116 166 291 118 167 291 minecraft:brown_terracotta
fill 116 166 317 117 167 317 minecraft:red_concrete
fill 118 166 275 119 167 275 minecraft:white_concrete
fill 118 166 294 118 167 294 minecraft:brown_terracotta
fill 118 166 317 119 167 317 minecraft:white_concrete
fill 119 166 288 129 166 288 minecraft:bricks
fill 119 166 289 120 166 289 minecraft:magma_block
fill 119 166 305 120 166 305 minecraft:magma_block
fill 119 166 306 128 166 306 minecraft:bricks
fill 120 166 275 121 167 275 minecraft:red_concrete
fill 120 166 290 121 166 290 minecraft:magma_block
fill 120 166 317 121 167 317 minecraft:red_concrete
fill 121 166 280 122 166 280 minecraft:red_terracotta
fill 121 166 289 130 166 289 minecraft:bricks
fill 121 166 291 122 166 291 minecraft:magma_block
fill 121 166 304 121 167 304 minecraft:magma_block
fill 121 166 305 129 166 305 minecraft:bricks
fill 121 166 312 122 166 312 minecraft:red_terracotta
fill 122 166 275 123 167 275 minecraft:white_concrete
fill 122 166 278 122 167 279 minecraft:brown_terracotta
fill 122 166 290 130 166 290 minecraft:bricks
setblock 122 166 292 minecraft:magma_block
fill 122 166 302 122 166 303 minecraft:magma_block
fill 122 166 304 129 166 304 minecraft:bricks
fill 122 166 317 123 167 317 minecraft:white_concrete
fill 123 166 278 123 167 278 minecraft:brown_terracotta
fill 123 166 281 124 219 281 minecraft:red_terracotta
fill 123 166 291 131 166 292 minecraft:bricks
fill 123 166 293 123 166 294 minecraft:magma_block
fill 123 166 300 123 166 301 minecraft:magma_block
fill 123 166 302 130 166 303 minecraft:bricks
fill 123 166 311 124 166 311 minecraft:red_terracotta
fill 124 166 275 125 167 275 minecraft:red_concrete
fill 124 166 277 125 167 277 minecraft:brown_terracotta
fill 124 166 293 131 166 294 minecraft:bricks
fill 124 166 295 124 166 299 minecraft:magma_block
fill 124 166 300 131 166 301 minecraft:bricks
fill 124 166 317 125 167 317 minecraft:red_concrete
fill 125 166 282 126 166 282 minecraft:red_terracotta
fill 125 166 295 131 166 299 minecraft:bricks
fill 125 166 310 126 166 310 minecraft:red_terracotta
fill 126 166 275 127 167 275 minecraft:white_concrete
fill 126 166 278 126 167 278 minecraft:brown_terracotta
fill 126 166 283 127 166 283 minecraft:red_terracotta
fill 126 166 309 127 166 309 minecraft:red_terracotta
fill 126 166 317 127 167 317 minecraft:white_concrete
fill 127 166 279 127 167 281 minecraft:brown_terracotta
fill 127 166 284 128 166 284 minecraft:red_terracotta
fill 127 166 308 128 166 308 minecraft:red_terracotta
fill 128 166 275 129 167 275 minecraft:red_concrete
fill 128 166 285 129 166 285 minecraft:red_terracotta
fill 128 166 307 129 166 307 minecraft:red_terracotta
fill 128 166 317 129 167 317 minecraft:red_concrete
setblock 129 166 286 minecraft:red_terracotta
setblock 129 166 306 minecraft:red_terracotta
fill 130 166 275 131 167 275 minecraft:white_concrete
fill 130 166 287 130 166 288 minecraft:red_terracotta
fill 130 166 304 130 166 305 minecraft:red_terracotta
fill 130 166 317 131 167 317 minecraft:white_concrete
fill 131 166 289 131 166 290 minecraft:red_terracotta
fill 131 166 302 131 166 303 minecraft:red_terracotta
fill 132 166 275 133 167 275 minecraft:red_concrete
fill 132 166 291 132 166 301 minecraft:red_terracotta
fill 132 166 317 133 167 317 minecraft:red_concrete
fill 134 166 275 135 167 275 minecraft:white_concrete
fill 134 166 317 135 167 317 minecraft:white_concrete
fill 136 166 276 136 167 276 minecraft:white_concrete
fill 136 166 277 136 167 278 minecraft:red_concrete
fill 136 166 279 136 167 280 minecraft:white_concrete
fill 136 166 281 136 167 282 minecraft:red_concrete
fill 136 166 283 136 167 284 minecraft:white_concrete
fill 136 166 285 136 167 286 minecraft:red_concrete
fill 136 166 287 136 167 288 minecraft:white_concrete
fill 136 166 289 136 167 290 minecraft:red_concrete
fill 136 166 291 136 167 292 minecraft:white_concrete
fill 136 166 293 136 167 294 minecraft:red_concrete
fill 136 166 295 136 167 296 minecraft:white_concrete
fill 136 166 297 136 167 298 minecraft:red_concrete
fill 136 166 299 136 167 300 minecraft:white_concrete
fill 136 166 301 136 167 302 minecraft:red_concrete
fill 136 166 303 136 167 304 minecraft:white_concrete
fill 136 166 305 136 167 306 minecraft:red_concrete
fill 136 166 307 136 167 308 minecraft:white_concrete
fill 136 166 309 136 167 310 minecraft:red_concrete
fill 136 166 311 136 167 312 minecraft:white_concrete
fill 136 166 313 136 167 314 minecraft:red_concrete
fill 136 166 315 136 167 316 minecraft:white_concrete
fill 136 166 317 136 167 317 minecraft:red_concrete
fill 99 167 291 99 167 301 minecraft:red_terracotta
fill 100 167 289 100 167 290 minecraft:red_terracotta
fill 100 167 291 104 167 301 minecraft:bricks
fill 100 167 302 100 167 303 minecraft:red_terracotta
fill 101 167 287 101 167 288 minecraft:red_terracotta
fill 101 167 289 106 167 290 minecraft:bricks
fill 101 167 302 105 167 303 minecraft:bricks
fill 101 167 304 101 167 305 minecraft:red_terracotta
setblock 102 167 286 minecraft:red_terracotta
fill 102 167 287 109 167 288 minecraft:bricks
fill 102 167 304 106 167 305 minecraft:bricks
setblock 102 167 306 minecraft:red_terracotta
setblock 103 167 285 minecraft:red_terracotta
fill 103 167 286 127 167 286 minecraft:bricks
fill 103 167 306 109 167 306 minecraft:bricks
setblock 103 167 307 minecraft:red_terracotta
setblock 104 167 284 minecraft:red_terracotta
fill 104 167 285 126 167 285 minecraft:bricks
fill 104 167 307 108 167 307 minecraft:bricks
setblock 104 167 308 minecraft:red_terracotta
setblock 105 167 283 minecraft:red_terracotta
fill 105 167 284 125 167 284 minecraft:bricks
fill 105 167 291 105 167 292 minecraft:bricks
fill 105 167 293 105 167 294 minecraft:magma_block
setblock 105 167 300 minecraft:magma_block
setblock 105 167 301 minecraft:bricks
fill 105 167 308 125 167 308 minecraft:bricks
setblock 105 167 309 minecraft:red_terracotta
fill 106 167 282 107 167 282 minecraft:red_terracotta
fill 106 167 283 124 167 283 minecraft:bricks
setblock 106 167 291 minecraft:bricks
setblock 106 167 292 minecraft:magma_block
fill 106 167 301 106 167 302 minecraft:magma_block
fill 106 167 303 106 168 303 minecraft:bricks
fill 106 167 309 124 167 309 minecraft:bricks
fill 106 167 310 107 167 310 minecraft:red_terracotta
setblock 107 167 289 minecraft:bricks
fill 107 167 290 107 167 291 minecraft:magma_block
setblock 107 167 303 minecraft:magma_block
fill 108 167 281 109 167 281 minecraft:red_terracotta
fill 108 167 282 122 167 282 minecraft:bricks
fill 108 167 289 109 167 289 minecraft:magma_block
fill 108 167 310 122 167 310 minecraft:bricks
fill 108 167 311 109 167 311 minecraft:red_terracotta
setblock 109 167 305 minecraft:magma_block
fill 110 167 279 112 167 279 minecraft:iron_block
fill 110 167 280 120 167 280 minecraft:red_terracotta
fill 110 167 281 120 167 281 minecraft:bricks
setblock 110 167 287 minecraft:bricks
setblock 110 167 288 minecraft:magma_block
fill 110 167 306 112 167 306 minecraft:magma_block
fill 110 167 311 120 167 311 minecraft:bricks
fill 110 167 312 120 167 312 minecraft:red_terracotta
fill 111 167 287 118 167 287 minecraft:magma_block
setblock 112 167 307 minecraft:bricks
fill 113 167 307 116 167 307 minecraft:magma_block
fill 114 167 292 114 167 293 minecraft:brown_terracotta
setblock 115 167 291 minecraft:brown_terracotta
fill 116 167 290 117 167 290 minecraft:brown_terracotta
fill 116 167 295 118 167 295 minecraft:brown_terracotta
fill 117 167 306 119 167 306 minecraft:magma_block
fill 117 167 307 126 167 307 minecraft:bricks
fill 119 167 287 128 167 287 minecraft:bricks
fill 119 167 288 120 167 288 minecraft:magma_block
fill 119 167 291 119 167 294 minecraft:brown_terracotta
setblock 120 167 305 minecraft:magma_block
fill 120 167 306 127 167 306 minecraft:bricks
fill 121 167 278 121 167 280 minecraft:brown_terracotta
fill 121 167 281 122 167 281 minecraft:red_terracotta
fill 121 167 288 128 167 288 minecraft:bricks
setblock 121 167 289 minecraft:magma_block
fill 121 167 305 128 167 305 minecraft:bricks
fill 121 167 311 122 167 311 minecraft:red_terracotta
fill 122 167 277 123 167 277 minecraft:brown_terracotta
fill 122 167 280 122 219 280 minecraft:red_terracotta
fill 122 167 289 129 167 289 minecraft:bricks
setblock 122 167 290 minecraft:magma_block
setblock 122 167 303 minecraft:magma_block
fill 122 167 304 128 167 304 minecraft:bricks
fill 123 167 282 125 219 282 minecraft:red_terracotta
fill 123 167 290 129 167 290 minecraft:bricks
fill 123 167 291 123 167 292 minecraft:magma_block
setblock 123 167 302 minecraft:magma_block
fill 123 167 303 129 167 303 minecraft:bricks
fill 123 167 310 124 167 310 minecraft:red_terracotta
setblock 124 167 276 minecraft:brown_terracotta
fill 124 167 291 130 167 292 minecraft:bricks
fill 124 167 293 124 167 295 minecraft:magma_block
fill 124 167 299 124 167 301 minecraft:magma_block
fill 124 167 302 129 167 302 minecraft:bricks
setblock 125 167 283 minecraft:red_terracotta
fill 125 167 293 130 167 295 minecraft:bricks
fill 125 167 296 125 167 298 minecraft:magma_block
fill 125 167 299 130 167 301 minecraft:bricks
setblock 125 167 309 minecraft:red_terracotta
setblock 126 167 277 minecraft:brown_terracotta
fill 126 167 282 127 167 283 minecraft:brown_terracotta
setblock 126 167 284 minecraft:red_terracotta
fill 126 167 296 130 167 298 minecraft:bricks
setblock 126 167 308 minecraft:red_terracotta
setblock 127 167 278 minecraft:brown_terracotta
setblock 127 167 285 minecraft:red_terracotta
setblock 127 167 307 minecraft:red_terracotta
fill 128 167 279 128 167 281 minecraft:brown_terracotta
setblock 128 167 286 minecraft:red_terracotta
setblock 128 167 306 minecraft:red_terracotta
fill 129 167 287 129 167 288 minecraft:red_terracotta
fill 129 167 304 129 167 305 minecraft:red_terracotta
fill 130 167 289 130 167 290 minecraft:red_terracotta
fill 130 167 302 130 167 303 minecraft:red_terracotta
fill 131 167 291 131 167 301 minecraft:red_terracotta
fill 132 167 298 132 219 298 minecraft:iron_block
fill 94 168 275 94 169 276 minecraft:red_concrete
fill 94 168 277 94 169 278 minecraft:white_concrete
fill 94 168 279 94 169 280 minecraft:red_concrete
fill 94 168 281 94 169 282 minecraft:white_concrete
fill 94 168 283 94 169 284 minecraft:red_concrete
fill 94 168 285 94 169 286 minecraft:white_concrete
fill 94 168 287 94 169 288 minecraft:red_concrete
fill 94 168 289 94 169 290 minecraft:white_concrete
fill 94 168 291 94 169 292 minecraft:red_concrete
fill 94 168 293 94 169 294 minecraft:white_concrete
fill 94 168 295 94 169 296 minecraft:red_concrete
fill 94 168 297 94 169 298 minecraft:white_concrete
fill 94 168 299 94 169 300 minecraft:red_concrete
fill 94 168 301 94 169 302 minecraft:white_concrete
fill 94 168 303 94 169 304 minecraft:red_concrete
fill 94 168 305 94 169 306 minecraft:white_concrete
fill 94 168 307 94 169 308 minecraft:red_concrete
fill 94 168 309 94 169 310 minecraft:white_concrete
fill 94 168 311 94 169 312 minecraft:red_concrete
fill 94 168 313 94 169 314 minecraft:white_concrete
fill 94 168 315 94 169 316 minecraft:red_concrete
fill 95 168 275 95 169 275 minecraft:red_concrete
fill 95 168 276 95 169 281 minecraft:red_terracotta
fill 95 168 284 96 168 289 minecraft:red_terracotta
fill 95 168 292 96 168 297 minecraft:red_terracotta
fill 95 168 300 96 168 305 minecraft:red_terracotta
fill 95 168 308 96 168 313 minecraft:red_terracotta
fill 95 168 316 100 169 316 minecraft:red_terracotta
fill 95 168 317 95 169 317 minecraft:red_concrete
fill 96 168 275 97 169 275 minecraft:white_concrete
fill 96 168 277 96 168 283 minecraft:red_terracotta
fill 96 168 290 96 168 291 minecraft:red_terracotta
fill 96 168 298 96 168 299 minecraft:red_terracotta
fill 96 168 306 96 168 307 minecraft:red_terracotta
fill 96 168 314 96 168 315 minecraft:red_terracotta
fill 96 168 317 97 169 317 minecraft:white_concrete
fill 97 168 277 134 168 277 minecraft:red_terracotta
fill 97 168 315 135 168 315 minecraft:red_terracotta
fill 98 168 275 99 169 275 minecraft:red_concrete
fill 98 168 276 103 169 276 minecraft:red_terracotta
fill 98 168 317 99 169 317 minecraft:red_concrete
fill 100 168 275 101 169 275 minecraft:white_concrete
fill 100 168 291 100 168 301 minecraft:red_terracotta
fill 100 168 317 101 169 317 minecraft:white_concrete
fill 101 168 289 101 168 293 minecraft:red_terracotta
fill 101 168 294 103 168 298 minecraft:bricks
fill 101 168 299 101 168 303 minecraft:red_terracotta
fill 102 168 275 103 169 275 minecraft:red_concrete
fill 102 168 287 102 168 290 minecraft:red_terracotta
fill 102 168 291 104 168 293 minecraft:bricks
fill 102 168 299 103 168 301 minecraft:bricks
fill 102 168 302 102 168 305 minecraft:red_terracotta
fill 102 168 317 103 169 317 minecraft:red_concrete
fill 103 168 286 103 168 288 minecraft:red_terracotta
fill 103 168 289 106 168 290 minecraft:bricks
fill 103 168 302 105 168 303 minecraft:bricks
fill 103 168 304 103 168 306 minecraft:red_terracotta
fill 103 168 316 108 169 316 minecraft:red_terracotta
fill 104 168 275 105 169 275 minecraft:white_concrete
fill 104 168 285 104 168 286 minecraft:red_terracotta
fill 104 168 287 107 168 288 minecraft:bricks
fill 104 168 294 104 168 299 minecraft:shroomlight
fill 104 168 300 104 168 301 minecraft:bricks
fill 104 168 304 106 168 305 minecraft:bricks
fill 104 168 306 104 168 307 minecraft:red_terracotta
fill 104 168 317 105 169 317 minecraft:white_concrete
fill 105 168 284 105 168 285 minecraft:red_terracotta
fill 105 168 286 111 168 286 minecraft:bricks
setblock 105 168 291 minecraft:bricks
fill 105 168 292 105 168 293 minecraft:shroomlight
fill 105 168 300 105 168 301 minecraft:shroomlight
fill 105 168 306 109 168 306 minecraft:bricks
fill 105 168 307 105 168 308 minecraft:red_terracotta
fill 106 168 275 107 169 275 minecraft:red_concrete
fill 106 168 276 111 169 276 minecraft:red_terracotta
fill 106 168 283 107 168 284 minecraft:red_terracotta
fill 106 168 285 124 168 285 minecraft:bricks
setblock 106 168 291 minecraft:shroomlight
setblock 106 168 302 minecraft:shroomlight
fill 106 168 307 108 168 307 minecraft:bricks
fill 106 168 308 107 168 309 minecraft:red_terracotta
fill 106 168 317 107 169 317 minecraft:red_concrete
fill 107 168 289 107 168 290 minecraft:shroomlight
setblock 107 168 303 minecraft:shroomlight
fill 108 168 275 109 169 275 minecraft:white_concrete
fill 108 168 282 109 168 283 minecraft:red_terracotta
fill 108 168 284 122 168 284 minecraft:bricks
fill 108 168 287 109 168 287 minecraft:bricks
fill 108 168 288 109 168 288 minecraft:shroomlight
setblock 108 168 304 minecraft:shroomlight
fill 108 168 308 122 168 308 minecraft:bricks
fill 108 168 309 109 168 310 minecraft:red_terracotta
fill 108 168 317 109 169 317 minecraft:white_concrete
setblock 109 168 305 minecraft:shroomlight
fill 110 168 275 111 169 275 minecraft:red_concrete
fill 110 168 279 110 219 279 minecraft:iron_block
fill 110 168 281 112 168 282 minecraft:red_terracotta
fill 110 168 283 120 168 283 minecraft:bricks
fill 110 168 287 111 168 287 minecraft:shroomlight
fill 110 168 306 111 168 306 minecraft:shroomlight
fill 110 168 309 120 168 309 minecraft:bricks
fill 110 168 310 112 168 311 minecraft:red_terracotta
fill 110 168 317 111 169 317 minecraft:red_concrete
fill 111 168 278 111 168 279 minecraft:red_terracotta
fill 111 168 316 116 169 316 minecraft:red_terracotta
fill 112 168 275 113 169 275 minecraft:white_concrete
fill 112 168 278 112 219 278 minecraft:iron_block
fill 112 168 279 113 168 279 minecraft:red_terracotta
fill 112 168 286 118 168 286 minecraft:shroomlight
fill 112 168 307 118 168 307 minecraft:shroomlight
fill 112 168 317 113 169 317 minecraft:white_concrete
fill 113 168 278 113 169 278 minecraft:red_terracotta
fill 113 168 281 120 168 281 minecraft:red_terracotta
fill 113 168 282 117 168 282 minecraft:bricks
fill 113 168 310 117 168 310 minecraft:bricks
fill 113 168 311 120 168 311 minecraft:red_terracotta
fill 114 168 275 115 169 275 minecraft:red_concrete
fill 114 168 276 119 169 276 minecraft:red_terracotta
fill 114 168 317 115 169 317 minecraft:red_concrete
fill 116 168 275 117 169 275 minecraft:white_concrete
fill 116 168 317 117 169 317 minecraft:white_concrete
fill 118 168 275 119 169 275 minecraft:red_concrete
fill 118 168 282 122 168 282 minecraft:red_terracotta
fill 118 168 310 122 168 310 minecraft:red_terracotta
fill 118 168 317 119 169 317 minecraft:red_concrete
fill 119 168 286 125 168 286 minecraft:bricks
fill 119 168 287 120 168 287 minecraft:shroomlight
fill 119 168 306 120 168 306 minecraft:shroomlight
fill 119 168 307 124 168 307 minecraft:bricks
fill 119 168 316 124 169 316 minecraft:red_terracotta
fill 120 168 275 121 169 275 minecraft:white_concrete
fill 120 168 317 121 169 317 minecraft:white_concrete
fill 121 168 283 124 168 283 minecraft:red_terracotta
fill 121 168 287 126 168 287 minecraft:bricks
setblock 121 168 288 minecraft:shroomlight
setblock 121 168 305 minecraft:shroomlight
fill 121 168 306 125 168 306 minecraft:bricks
fill 121 168 309 124 168 309 minecraft:red_terracotta
fill 122 168 275 123 169 275 minecraft:red_concrete
fill 122 168 276 127 169 276 minecraft:red_terracotta
fill 122 168 281 122 219 281 minecraft:red_terracotta
fill 122 168 288 126 168 288 minecraft:bricks
setblock 122 168 289 minecraft:shroomlight
setblock 122 168 304 minecraft:shroomlight
fill 122 168 305 126 168 305 minecraft:bricks
fill 122 168 317 123 169 317 minecraft:red_concrete
fill 123 168 284 125 168 284 minecraft:red_terracotta
fill 123 168 289 127 168 289 minecraft:bricks
setblock 123 168 290 minecraft:shroomlight
setblock 123 168 303 minecraft:shroomlight
fill 123 168 304 126 168 304 minecraft:bricks
fill 123 168 308 125 168 308 minecraft:red_terracotta
fill 124 168 275 125 169 275 minecraft:white_concrete
fill 124 168 290 127 168 290 minecraft:bricks
fill 124 168 291 124 168 292 minecraft:shroomlight
fill 124 168 301 124 168 302 minecraft:shroomlight
fill 124 168 303 127 168 303 minecraft:bricks
fill 124 168 317 125 169 317 minecraft:white_concrete
fill 125 168 285 126 168 285 minecraft:red_terracotta
fill 125 168 291 128 168 292 minecraft:bricks
fill 125 168 293 125 168 300 minecraft:shroomlight
fill 125 168 301 127 168 302 minecraft:bricks
fill 125 168 307 126 168 307 minecraft:red_terracotta
fill 126 168 275 127 169 275 minecraft:red_concrete
fill 126 168 286 127 168 286 minecraft:red_terracotta
fill 126 168 293 128 168 300 minecraft:bricks
fill 126 168 306 127 168 306 minecraft:red_terracotta
fill 126 168 317 127 169 317 minecraft:red_concrete
fill 127 168 287 128 168 288 minecraft:red_terracotta
fill 127 168 304 128 168 305 minecraft:red_terracotta
fill 127 168 316 132 169 316 minecraft:red_terracotta
fill 128 168 275 129 169 275 minecraft:white_concrete
fill 128 168 289 129 168 290 minecraft:red_terracotta
setblock 128 168 301 minecraft:bricks
fill 128 168 302 129 168 303 minecraft:red_terracotta
fill 128 168 317 129 169 317 minecraft:white_concrete
fill 129 168 291 130 168 293 minecraft:red_terracotta
fill 129 168 294 129 168 298 minecraft:bricks
fill 129 168 299 130 168 301 minecraft:red_terracotta
fill 130 168 275 131 169 275 minecraft:red_concrete
fill 130 168 276 135 169 276 minecraft:red_terracotta
fill 130 168 294 130 168 298 minecraft:red_terracotta
fill 130 168 317 131 169 317 minecraft:red_concrete
fill 132 168 275 133 169 275 minecraft:white_concrete
fill 132 168 317 133 169 317 minecraft:white_concrete
setblock 133 168 298 minecraft:iron_block
fill 134 168 275 135 169 275 minecraft:red_concrete
fill 134 168 278 134 168 314 minecraft:red_terracotta
fill 134 168 317 135 169 317 minecraft:red_concrete
fill 135 168 279 135 169 284 minecraft:red_terracotta
fill 135 168 287 135 169 292 minecraft:red_terracotta
fill 135 168 295 135 169 300 minecraft:red_terracotta
fill 135 168 303 135 169 308 minecraft:red_terracotta
fill 135 168 311 135 169 314 minecraft:red_terracotta
fill 135 168 316 135 169 316 minecraft:red_terracotta
fill 136 168 276 136 169 276 minecraft:red_concrete
fill 136 168 277 136 169 278 minecraft:white_concrete
fill 136 168 279 136 169 280 minecraft:red_concrete
fill 136 168 281 136 169 282 minecraft:white_concrete
fill 136 168 283 136 169 284 minecraft:red_concrete
fill 136 168 285 136 169 286 minecraft:white_concrete
fill 136 168 287 136 169 288 minecraft:red_concrete
fill 136 168 289 136 169 290 minecraft:white_concrete
fill 136 168 291 136 169 292 minecraft:red_concrete
fill 136 168 293 136 169 294 minecraft:white_concrete
fill 136 168 295 136 169 296 minecraft:red_concrete
fill 136 168 297 136 169 298 minecraft:white_concrete
fill 136 168 299 136 169 300 minecraft:red_concrete
fill 136 168 301 136 169 302 minecraft:white_concrete
fill 136 168 303 136 169 304 minecraft:red_concrete
fill 136 168 305 136 169 306 minecraft:white_concrete
fill 136 168 307 136 169 308 minecraft:red_concrete
fill 136 168 309 136 169 310 minecraft:white_concrete
fill 136 168 311 136 169 312 minecraft:red_concrete
fill 136 168 313 136 169 314 minecraft:white_concrete
fill 136 168 315 136 169 316 minecraft:red_concrete
fill 136 168 317 136 169 317 minecraft:white_concrete
fill 95 169 284 95 169 289 minecraft:red_terracotta
fill 95 169 292 95 169 297 minecraft:red_terracotta
fill 95 169 300 95 169 305 minecraft:red_terracotta
fill 95 169 308 95 169 313 minecraft:red_terracotta
fill 101 169 294 103 169 298 minecraft:red_terracotta
fill 102 169 291 103 169 293 minecraft:red_terracotta
fill 102 169 299 103 169 301 minecraft:red_terracotta
fill 103 169 289 105 169 290 minecraft:red_terracotta
fill 103 169 302 104 169 303 minecraft:red_terracotta
fill 104 169 287 106 169 288 minecraft:red_terracotta
fill 104 169 291 104 169 292 minecraft:red_terracotta
fill 104 169 293 104 169 300 minecraft:magma_block
setblock 104 169 301 minecraft:red_terracotta
fill 104 169 304 106 169 305 minecraft:red_terracotta
fill 105 169 286 109 169 286 minecraft:red_terracotta
fill 105 169 291 105 169 292 minecraft:magma_block
fill 105 169 301 105 169 302 minecraft:magma_block
setblock 105 169 303 minecraft:red_terracotta
fill 105 169 306 108 169 306 minecraft:red_terracotta
fill 106 169 285 111 169 285 minecraft:red_terracotta
fill 106 169 289 106 169 290 minecraft:magma_block
setblock 106 169 303 minecraft:magma_block
fill 106 169 307 110 169 307 minecraft:red_terracotta
setblock 107 169 287 minecraft:red_terracotta
setblock 107 169 288 minecraft:magma_block
setblock 107 169 304 minecraft:magma_block
setblock 107 169 305 minecraft:red_terracotta
fill 108 169 281 110 170 281 minecraft:brown_terracotta
fill 108 169 284 122 169 284 minecraft:red_terracotta
fill 108 169 287 109 169 287 minecraft:magma_block
setblock 108 169 305 minecraft:magma_block
fill 108 169 308 122 169 308 minecraft:red_terracotta
fill 109 169 277 109 169 279 minecraft:red_terracotta
fill 109 169 280 109 170 280 minecraft:brown_terracotta
fill 109 169 282 109 170 282 minecraft:brown_terracotta
fill 109 169 306 110 169 306 minecraft:magma_block
fill 110 169 277 112 172 277 minecraft:iron_block
fill 110 169 280 112 169 280 minecraft:red_terracotta
fill 110 169 283 120 169 283 minecraft:red_terracotta
fill 110 169 286 111 169 286 minecraft:magma_block
fill 110 169 309 120 169 309 minecraft:red_terracotta
fill 111 169 278 111 172 279 minecraft:iron_block
fill 111 169 307 119 169 307 minecraft:magma_block
fill 112 169 279 112 172 279 minecraft:iron_block
fill 112 169 285 118 169 285 minecraft:magma_block
setblock 113 169 277 minecraft:red_terracotta
setblock 113 169 279 minecraft:red_terracotta
fill 113 169 282 117 169 282 minecraft:red_terracotta
fill 113 169 310 117 169 310 minecraft:red_terracotta
fill 119 169 285 124 169 285 minecraft:red_terracotta
fill 119 169 286 120 169 286 minecraft:magma_block
setblock 120 169 306 minecraft:magma_block
fill 120 169 307 124 169 307 minecraft:red_terracotta
fill 121 169 286 125 169 286 minecraft:red_terracotta
setblock 121 169 287 minecraft:magma_block
fill 121 169 305 122 169 305 minecraft:magma_block
fill 121 169 306 125 169 306 minecraft:red_terracotta
fill 122 169 287 126 169 287 minecraft:red_terracotta
setblock 122 169 288 minecraft:magma_block
fill 123 169 288 126 169 288 minecraft:red_terracotta
setblock 123 169 289 minecraft:magma_block
setblock 123 169 304 minecraft:magma_block
fill 123 169 305 126 169 305 minecraft:red_terracotta
fill 124 169 289 127 169 289 minecraft:red_terracotta
setblock 124 169 290 minecraft:magma_block
fill 124 169 302 124 169 303 minecraft:magma_block
fill 124 169 304 126 169 304 minecraft:red_terracotta
fill 125 169 290 127 169 290 minecraft:red_terracotta
fill 125 169 291 125 169 292 minecraft:magma_block
fill 125 169 300 125 169 301 minecraft:magma_block
fill 125 169 302 127 169 303 minecraft:red_terracotta
fill 126 169 291 128 169 292 minecraft:red_terracotta
fill 126 169 293 126 169 299 minecraft:magma_block
fill 126 169 300 128 169 301 minecraft:red_terracotta
fill 127 169 293 128 169 299 minecraft:red_terracotta
fill 129 169 294 129 169 298 minecraft:red_terracotta
setblock 130 169 297 minecraft:green_concrete
fill 131 169 297 131 169 299 minecraft:red_terracotta
setblock 131 169 306 minecraft:red_terracotta
setblock 131 169 308 minecraft:red_terracotta
fill 132 169 297 133 169 297 minecraft:red_terracotta
fill 132 169 299 133 169 299 minecraft:red_terracotta
setblock 133 169 298 minecraft:red_terracotta
setblock 133 169 306 minecraft:red_terracotta
setblock 133 169 308 minecraft:red_terracotta
setblock 134 169 298 minecraft:iron_block
setblock 135 169 315 minecraft:red_terracotta
fill 94 170 275 94 171 276 minecraft:white_concrete
fill 94 170 277 94 171 278 minecraft:red_concrete
fill 94 170 279 94 171 280 minecraft:white_concrete
fill 94 170 281 94 171 282 minecraft:red_concrete
fill 94 170 283 94 171 284 minecraft:white_concrete
fill 94 170 285 94 171 286 minecraft:red_concrete
fill 94 170 287 94 171 288 minecraft:white_concrete
fill 94 170 289 94 171 290 minecraft:red_concrete
fill 94 170 291 94 171 292 minecraft:white_concrete
fill 94 170 293 94 171 294 minecraft:red_concrete
fill 94 170 295 94 171 296 minecraft:white_concrete
fill 94 170 297 94 171 298 minecraft:red_concrete
fill 94 170 299 94 171 300 minecraft:white_concrete
fill 94 170 301 94 171 302 minecraft:red_concrete
fill 94 170 303 94 171 304 minecraft:white_concrete
fill 94 170 305 94 171 306 minecraft:red_concrete
fill 94 170 307 94 171 308 minecraft:white_concrete
fill 94 170 309 94 171 310 minecraft:red_concrete
fill 94 170 311 94 171 312 minecraft:white_concrete
fill 94 170 313 94 171 314 minecraft:red_concrete
fill 94 170 315 94 171 316 minecraft:white_concrete
fill 95 170 275 95 171 275 minecraft:white_concrete
fill 95 170 317 95 171 317 minecraft:white_concrete
fill 96 170 275 97 171 275 minecraft:red_concrete
fill 96 170 317 97 171 317 minecraft:red_concrete
setblock 97 170 278 minecraft:light[level=15]
setblock 97 170 285 minecraft:light[level=12]
setblock 97 170 286 minecraft:light[level=15]
setblock 97 170 292 minecraft:light[level=12]
setblock 97 170 294 minecraft:light[level=15]
setblock 97 170 299 minecraft:light[level=12]
setblock 97 170 302 minecraft:light[level=15]
setblock 97 170 306 minecraft:light[level=12]
setblock 97 170 310 minecraft:light[level=15]
setblock 97 170 313 minecraft:light[level=12]
fill 98 170 275 99 171 275 minecraft:white_concrete
fill 98 170 317 99 171 317 minecraft:white_concrete
fill 100 170 275 101 171 275 minecraft:red_concrete
fill 100 170 317 101 171 317 minecraft:red_concrete
fill 102 170 275 103 171 275 minecraft:white_concrete
fill 102 170 317 103 171 317 minecraft:white_concrete
fill 104 170 275 105 171 275 minecraft:red_concrete
setblock 104 170 278 minecraft:light[level=12]
setblock 104 170 285 minecraft:light[level=12]
setblock 104 170 292 minecraft:light[level=12]
setblock 104 170 299 minecraft:light[level=12]
setblock 104 170 306 minecraft:light[level=12]
setblock 104 170 313 minecraft:light[level=12]
fill 104 170 317 105 171 317 minecraft:red_concrete
setblock 105 170 278 minecraft:light[level=15]
setblock 105 170 286 minecraft:light[level=15]
setblock 105 170 294 minecraft:light[level=15]
setblock 105 170 302 minecraft:light[level=15]
setblock 105 170 310 minecraft:light[level=15]
fill 106 170 275 107 171 275 minecraft:white_concrete
fill 106 170 317 107 171 317 minecraft:white_concrete
fill 108 170 275 109 171 275 minecraft:red_concrete
fill 108 170 317 109 171 317 minecraft:red_concrete
fill 110 170 275 111 171 275 minecraft:white_concrete
fill 110 170 317 111 171 317 minecraft:white_concrete
setblock 111 170 285 minecraft:light[level=12]
setblock 111 170 292 minecraft:light[level=12]
setblock 111 170 299 minecraft:light[level=12]
setblock 111 170 306 minecraft:light[level=12]
setblock 111 170 313 minecraft:light[level=12]
fill 112 170 275 113 171 275 minecraft:red_concrete
fill 112 170 317 113 171 317 minecraft:red_concrete
setblock 113 170 278 minecraft:light[level=15]
setblock 113 170 286 minecraft:light[level=15]
setblock 113 170 294 minecraft:light[level=15]
setblock 113 170 302 minecraft:light[level=15]
setblock 113 170 310 minecraft:light[level=15]
fill 114 170 275 115 171 275 minecraft:white_concrete
fill 114 170 317 115 171 317 minecraft:white_concrete
fill 116 170 275 117 171 275 minecraft:red_concrete
fill 116 170 317 117 171 317 minecraft:red_concrete
fill 118 170 275 119 171 275 minecraft:white_concrete
setblock 118 170 278 minecraft:light[level=12]
setblock 118 170 285 minecraft:light[level=12]
setblock 118 170 299 minecraft:light[level=12]
setblock 118 170 306 minecraft:light[level=12]
setblock 118 170 313 minecraft:light[level=12]
fill 118 170 317 119 171 317 minecraft:white_concrete
fill 120 170 275 121 171 275 minecraft:red_concrete
fill 120 170 317 121 171 317 minecraft:red_concrete
setblock 121 170 278 minecraft:light[level=15]
setblock 121 170 286 minecraft:light[level=15]
setblock 121 170 294 minecraft:light[level=15]
setblock 121 170 302 minecraft:light[level=15]
setblock 121 170 310 minecraft:light[level=15]
fill 122 170 275 123 171 275 minecraft:white_concrete
fill 122 170 317 123 171 317 minecraft:white_concrete
fill 124 170 275 125 171 275 minecraft:red_concrete
fill 124 170 317 125 171 317 minecraft:red_concrete
setblock 125 170 285 minecraft:light[level=12]
setblock 125 170 292 minecraft:light[level=12]
setblock 125 170 299 minecraft:light[level=12]
setblock 125 170 306 minecraft:light[level=12]
setblock 125 170 313 minecraft:light[level=12]
fill 126 170 275 127 171 275 minecraft:white_concrete
fill 126 170 317 127 171 317 minecraft:white_concrete
fill 128 170 275 129 171 275 minecraft:red_concrete
fill 128 170 317 129 171 317 minecraft:red_concrete
setblock 129 170 278 minecraft:light[level=15]
setblock 129 170 286 minecraft:light[level=15]
setblock 129 170 294 minecraft:light[level=15]
setblock 129 170 302 minecraft:light[level=15]
setblock 129 170 310 minecraft:light[level=15]
fill 130 170 275 131 171 275 minecraft:white_concrete
fill 130 170 317 131 171 317 minecraft:white_concrete
fill 132 170 275 133 171 275 minecraft:red_concrete
setblock 132 170 278 minecraft:light[level=12]
setblock 132 170 285 minecraft:light[level=12]
setblock 132 170 292 minecraft:light[level=12]
setblock 132 170 299 minecraft:light[level=12]
setblock 132 170 313 minecraft:light[level=12]
fill 132 170 317 133 171 317 minecraft:red_concrete
fill 134 170 275 135 171 275 minecraft:white_concrete
fill 134 170 317 135 171 317 minecraft:white_concrete
fill 136 170 276 136 171 276 minecraft:white_concrete
fill 136 170 277 136 171 278 minecraft:red_concrete
fill 136 170 279 136 171 280 minecraft:white_concrete
fill 136 170 281 136 171 282 minecraft:red_concrete
fill 136 170 283 136 171 284 minecraft:white_concrete
fill 136 170 285 136 171 286 minecraft:red_concrete
fill 136 170 287 136 171 288 minecraft:white_concrete
fill 136 170 289 136 171 290 minecraft:red_concrete
fill 136 170 291 136 171 292 minecraft:white_concrete
fill 136 170 293 136 171 294 minecraft:red_concrete
fill 136 170 295 136 171 296 minecraft:white_concrete
fill 136 170 297 136 171 298 minecraft:red_concrete
fill 136 170 299 136 171 300 minecraft:white_concrete
fill 136 170 301 136 171 302 minecraft:red_concrete
fill 136 170 303 136 171 304 minecraft:white_concrete
fill 136 170 305 136 171 306 minecraft:red_concrete
fill 136 170 307 136 171 308 minecraft:white_concrete
fill 136 170 309 136 171 310 minecraft:red_concrete
fill 136 170 311 136 171 312 minecraft:white_concrete
fill 136 170 313 136 171 314 minecraft:red_concrete
fill 136 170 315 136 171 316 minecraft:white_concrete
fill 136 170 317 136 171 317 minecraft:red_concrete
fill 127 171 289 128 172 289 minecraft:green_concrete
fill 128 171 288 128 172 288 minecraft:green_concrete
fill 128 171 290 128 172 290 minecraft:green_concrete
fill 94 172 275 94 173 276 minecraft:red_concrete
fill 94 172 277 94 173 278 minecraft:white_concrete
fill 94 172 279 94 173 279 minecraft:red_concrete
fill 94 172 280 94 177 280 minecraft:shroomlight
fill 94 172 281 94 173 282 minecraft:white_concrete
schedule function dropper:buildpart/62_3 1t
