fill 464 265 502 464 268 502 minecraft:blackstone
setblock 424 266 465 minecraft:polished_blackstone_bricks
fill 424 266 466 424 269 466 minecraft:blackstone
setblock 424 266 470 minecraft:polished_blackstone_bricks
fill 424 266 471 424 269 471 minecraft:blackstone
setblock 424 266 475 minecraft:polished_blackstone_bricks
fill 424 266 476 424 269 476 minecraft:blackstone
setblock 424 266 479 minecraft:blackstone
setblock 424 266 480 minecraft:polished_blackstone_bricks
fill 424 266 481 424 269 481 minecraft:blackstone
setblock 424 266 485 minecraft:polished_blackstone_bricks
setblock 424 266 486 minecraft:blackstone
setblock 424 266 490 minecraft:polished_blackstone_bricks
fill 424 266 491 424 267 491 minecraft:blackstone
setblock 424 266 495 minecraft:polished_blackstone_bricks
fill 424 266 496 424 269 496 minecraft:blackstone
setblock 424 266 500 minecraft:polished_blackstone_bricks
fill 424 266 501 424 269 501 minecraft:blackstone
setblock 425 266 464 minecraft:polished_blackstone_bricks
fill 425 266 465 425 269 465 minecraft:blackstone
setblock 425 266 469 minecraft:polished_blackstone_bricks
fill 425 266 470 425 269 470 minecraft:blackstone
setblock 425 266 474 minecraft:polished_blackstone_bricks
fill 425 266 475 425 269 475 minecraft:blackstone
setblock 425 266 478 minecraft:blackstone
setblock 425 266 479 minecraft:polished_blackstone_bricks
fill 425 266 480 425 269 480 minecraft:blackstone
setblock 425 266 494 minecraft:polished_blackstone_bricks
fill 425 266 495 425 268 495 minecraft:blackstone
setblock 425 266 499 minecraft:polished_blackstone_bricks
fill 425 266 500 425 269 500 minecraft:blackstone
setblock 425 266 503 minecraft:blackstone
setblock 425 266 504 minecraft:polished_blackstone_bricks
fill 426 266 464 426 269 464 minecraft:blackstone
setblock 426 266 468 minecraft:polished_blackstone_bricks
setblock 426 266 469 minecraft:blackstone
setblock 426 266 473 minecraft:polished_blackstone_bricks
fill 426 266 474 426 268 474 minecraft:blackstone
setblock 426 266 478 minecraft:polished_blackstone_bricks
setblock 426 266 498 minecraft:polished_blackstone_bricks
fill 426 266 499 426 268 499 minecraft:blackstone
fill 426 266 501 426 267 501 minecraft:blackstone
setblock 426 266 503 minecraft:polished_blackstone_bricks
fill 426 266 504 426 269 504 minecraft:blackstone
fill 427 266 503 427 269 503 minecraft:blackstone
fill 428 266 476 428 267 476 minecraft:polished_blackstone_bricks
fill 428 266 478 428 267 478 minecraft:polished_blackstone_bricks
fill 429 266 503 429 267 503 minecraft:blackstone
setblock 430 266 464 minecraft:polished_blackstone_bricks
setblock 430 266 504 minecraft:polished_blackstone_bricks
setblock 431 266 464 minecraft:blackstone
fill 431 266 504 434 266 504 minecraft:blackstone
setblock 435 266 503 minecraft:blackstone
setblock 435 266 504 minecraft:polished_blackstone_bricks
setblock 436 266 503 minecraft:polished_blackstone_bricks
fill 436 266 504 436 269 504 minecraft:blackstone
fill 437 266 464 437 268 464 minecraft:blackstone
setblock 437 266 502 minecraft:polished_blackstone_bricks
fill 437 266 503 437 269 503 minecraft:blackstone
fill 438 266 502 441 266 502 minecraft:blackstone
fill 439 266 501 440 268 501 minecraft:blackstone
setblock 440 266 464 minecraft:polished_blackstone_bricks
setblock 440 266 504 minecraft:polished_blackstone_bricks
fill 441 266 464 441 269 464 minecraft:blackstone
setblock 441 266 503 minecraft:polished_blackstone_bricks
fill 441 266 504 441 269 504 minecraft:blackstone
setblock 442 266 502 minecraft:polished_blackstone_bricks
fill 442 266 503 442 269 503 minecraft:blackstone
setblock 443 266 501 minecraft:polished_blackstone_bricks
fill 443 266 502 443 269 502 minecraft:blackstone
fill 444 266 501 444 268 501 minecraft:blackstone
setblock 445 266 464 minecraft:polished_blackstone_bricks
setblock 445 266 504 minecraft:polished_blackstone_bricks
setblock 446 266 503 minecraft:polished_blackstone_bricks
fill 446 266 504 446 269 504 minecraft:blackstone
fill 447 266 503 447 267 503 minecraft:blackstone
setblock 460 266 464 minecraft:polished_blackstone_bricks
setblock 460 266 504 minecraft:polished_blackstone_bricks
fill 461 266 464 461 269 464 minecraft:blackstone
fill 461 266 471 461 266 472 minecraft:blackstone
setblock 461 266 473 minecraft:polished_blackstone_bricks
fill 461 266 474 461 269 474 minecraft:blackstone
fill 461 266 476 461 266 477 minecraft:blackstone
setblock 461 266 478 minecraft:polished_blackstone_bricks
fill 461 266 479 461 268 480 minecraft:blackstone
fill 461 266 504 461 269 504 minecraft:blackstone
fill 462 266 468 462 266 471 minecraft:blackstone
setblock 462 266 472 minecraft:polished_blackstone_bricks
fill 462 266 473 462 269 473 minecraft:blackstone
setblock 462 266 477 minecraft:polished_blackstone_bricks
fill 462 266 478 462 269 478 minecraft:blackstone
fill 462 266 480 462 266 481 minecraft:blackstone
setblock 462 266 482 minecraft:polished_blackstone_bricks
fill 462 266 483 462 269 483 minecraft:blackstone
setblock 462 266 493 minecraft:blackstone
fill 462 266 495 462 266 496 minecraft:blackstone
setblock 462 266 497 minecraft:polished_blackstone_bricks
fill 462 266 498 462 267 499 minecraft:blackstone
setblock 463 266 466 minecraft:polished_blackstone_bricks
fill 463 266 467 463 266 470 minecraft:blackstone
setblock 463 266 471 minecraft:polished_blackstone_bricks
fill 463 266 472 463 269 472 minecraft:blackstone
setblock 463 266 476 minecraft:polished_blackstone_bricks
fill 463 266 477 463 269 477 minecraft:blackstone
setblock 463 266 481 minecraft:polished_blackstone_bricks
fill 463 266 482 463 269 482 minecraft:blackstone
setblock 463 266 486 minecraft:polished_blackstone_bricks
fill 463 266 487 463 267 487 minecraft:blackstone
setblock 463 266 491 minecraft:polished_blackstone_bricks
fill 463 266 492 463 267 492 minecraft:blackstone
setblock 463 266 496 minecraft:polished_blackstone_bricks
fill 463 266 497 463 269 497 minecraft:blackstone
setblock 463 266 501 minecraft:polished_blackstone_bricks
fill 463 266 502 463 269 502 minecraft:blackstone
setblock 464 266 465 minecraft:polished_blackstone_bricks
fill 464 266 466 464 269 466 minecraft:blackstone
setblock 464 266 470 minecraft:polished_blackstone_bricks
fill 464 266 471 464 269 471 minecraft:blackstone
setblock 464 266 475 minecraft:polished_blackstone_bricks
fill 464 266 476 464 269 476 minecraft:blackstone
setblock 464 266 480 minecraft:polished_blackstone_bricks
fill 464 266 481 464 269 481 minecraft:blackstone
setblock 464 266 485 minecraft:polished_blackstone_bricks
fill 464 266 486 464 269 486 minecraft:blackstone
setblock 464 266 490 minecraft:polished_blackstone_bricks
fill 464 266 491 464 268 491 minecraft:blackstone
setblock 464 266 495 minecraft:polished_blackstone_bricks
fill 464 266 496 464 269 496 minecraft:blackstone
setblock 464 266 500 minecraft:polished_blackstone_bricks
fill 464 266 501 464 269 501 minecraft:blackstone
setblock 424 267 464 minecraft:polished_blackstone_bricks
fill 424 267 465 424 270 465 minecraft:blackstone
setblock 424 267 469 minecraft:polished_blackstone_bricks
fill 424 267 470 424 270 470 minecraft:blackstone
setblock 424 267 474 minecraft:polished_blackstone_bricks
fill 424 267 475 424 270 475 minecraft:blackstone
setblock 424 267 479 minecraft:polished_blackstone_bricks
fill 424 267 480 424 270 480 minecraft:blackstone
setblock 424 267 484 minecraft:polished_blackstone_bricks
setblock 424 267 485 minecraft:blackstone
setblock 424 267 490 minecraft:blackstone
setblock 424 267 494 minecraft:polished_blackstone_bricks
fill 424 267 495 424 270 495 minecraft:blackstone
setblock 424 267 499 minecraft:polished_blackstone_bricks
fill 424 267 500 424 270 500 minecraft:blackstone
setblock 424 267 504 minecraft:polished_blackstone_bricks
fill 425 267 464 425 270 464 minecraft:blackstone
setblock 425 267 468 minecraft:polished_blackstone_bricks
fill 425 267 469 425 268 469 minecraft:blackstone
setblock 425 267 473 minecraft:polished_blackstone_bricks
fill 425 267 474 425 270 474 minecraft:blackstone
setblock 425 267 478 minecraft:polished_blackstone_bricks
fill 425 267 479 425 270 479 minecraft:blackstone
setblock 425 267 494 minecraft:blackstone
setblock 425 267 497 minecraft:blackstone
setblock 425 267 498 minecraft:polished_blackstone_bricks
fill 425 267 499 425 270 499 minecraft:blackstone
setblock 425 267 503 minecraft:polished_blackstone_bricks
fill 425 267 504 425 270 504 minecraft:blackstone
setblock 426 267 472 minecraft:polished_blackstone_bricks
setblock 426 267 473 minecraft:blackstone
setblock 426 267 477 minecraft:polished_blackstone_bricks
setblock 426 267 478 minecraft:blackstone
setblock 426 267 497 minecraft:polished_blackstone_bricks
setblock 426 267 498 minecraft:blackstone
fill 426 267 503 426 270 503 minecraft:blackstone
setblock 429 267 464 minecraft:polished_blackstone_bricks
setblock 429 267 504 minecraft:polished_blackstone_bricks
setblock 430 267 464 minecraft:blackstone
setblock 430 267 503 minecraft:polished_blackstone_bricks
fill 430 267 504 433 267 504 minecraft:blackstone
fill 433 267 503 434 267 503 minecraft:blackstone
setblock 434 267 504 minecraft:polished_blackstone_bricks
setblock 435 267 503 minecraft:polished_blackstone_bricks
fill 435 267 504 435 270 504 minecraft:blackstone
setblock 436 267 502 minecraft:polished_blackstone_bricks
fill 436 267 503 436 270 503 minecraft:blackstone
fill 437 267 502 440 267 502 minecraft:blackstone
fill 438 267 501 438 270 501 minecraft:blackstone
setblock 439 267 464 minecraft:polished_blackstone_bricks
setblock 439 267 504 minecraft:polished_blackstone_bricks
fill 440 267 464 440 270 464 minecraft:blackstone
setblock 440 267 503 minecraft:polished_blackstone_bricks
fill 440 267 504 440 270 504 minecraft:blackstone
setblock 441 267 501 minecraft:blackstone
setblock 441 267 502 minecraft:polished_blackstone_bricks
fill 441 267 503 441 270 503 minecraft:blackstone
setblock 442 267 501 minecraft:polished_blackstone_bricks
fill 442 267 502 442 270 502 minecraft:blackstone
fill 443 267 501 443 269 501 minecraft:blackstone
setblock 444 267 464 minecraft:polished_blackstone_bricks
setblock 444 267 504 minecraft:polished_blackstone_bricks
setblock 445 267 502 minecraft:blackstone
setblock 445 267 503 minecraft:polished_blackstone_bricks
fill 445 267 504 445 270 504 minecraft:blackstone
setblock 446 267 502 minecraft:polished_blackstone_bricks
fill 446 267 503 446 269 503 minecraft:blackstone
setblock 459 267 464 minecraft:polished_blackstone_bricks
setblock 459 267 504 minecraft:polished_blackstone_bricks
fill 460 267 464 460 270 464 minecraft:blackstone
fill 460 267 504 460 270 504 minecraft:blackstone
setblock 461 267 472 minecraft:polished_blackstone_bricks
fill 461 267 473 461 269 473 minecraft:blackstone
setblock 461 267 476 minecraft:blackstone
setblock 461 267 477 minecraft:polished_blackstone_bricks
fill 461 267 478 461 270 478 minecraft:blackstone
setblock 461 267 481 minecraft:blackstone
fill 462 267 469 462 267 470 minecraft:blackstone
setblock 462 267 471 minecraft:polished_blackstone_bricks
fill 462 267 472 462 270 472 minecraft:blackstone
setblock 462 267 476 minecraft:polished_blackstone_bricks
fill 462 267 477 462 270 477 minecraft:blackstone
setblock 462 267 480 minecraft:blackstone
setblock 462 267 481 minecraft:polished_blackstone_bricks
fill 462 267 482 462 270 482 minecraft:blackstone
setblock 462 267 495 minecraft:blackstone
setblock 462 267 496 minecraft:polished_blackstone_bricks
setblock 462 267 497 minecraft:blackstone
fill 462 267 503 463 268 503 minecraft:blackstone
setblock 463 267 464 minecraft:blackstone
setblock 463 267 465 minecraft:polished_blackstone_bricks
fill 463 267 466 463 267 469 minecraft:blackstone
setblock 463 267 470 minecraft:polished_blackstone_bricks
fill 463 267 471 463 270 471 minecraft:blackstone
setblock 463 267 475 minecraft:polished_blackstone_bricks
fill 463 267 476 463 270 476 minecraft:blackstone
setblock 463 267 480 minecraft:polished_blackstone_bricks
fill 463 267 481 463 270 481 minecraft:blackstone
setblock 463 267 485 minecraft:polished_blackstone_bricks
fill 463 267 486 463 268 486 minecraft:blackstone
setblock 463 267 490 minecraft:polished_blackstone_bricks
setblock 463 267 491 minecraft:blackstone
setblock 463 267 495 minecraft:polished_blackstone_bricks
fill 463 267 496 463 269 496 minecraft:blackstone
setblock 463 267 499 minecraft:blackstone
setblock 463 267 500 minecraft:polished_blackstone_bricks
fill 463 267 501 463 270 501 minecraft:blackstone
setblock 463 267 504 minecraft:blackstone
setblock 464 267 464 minecraft:polished_blackstone_bricks
fill 464 267 465 464 270 465 minecraft:blackstone
setblock 464 267 469 minecraft:polished_blackstone_bricks
fill 464 267 470 464 270 470 minecraft:blackstone
setblock 464 267 474 minecraft:polished_blackstone_bricks
fill 464 267 475 464 270 475 minecraft:blackstone
setblock 464 267 479 minecraft:polished_blackstone_bricks
fill 464 267 480 464 270 480 minecraft:blackstone
setblock 464 267 484 minecraft:polished_blackstone_bricks
fill 464 267 485 464 270 485 minecraft:blackstone
setblock 464 267 489 minecraft:polished_blackstone_bricks
fill 464 267 490 464 268 490 minecraft:blackstone
setblock 464 267 494 minecraft:polished_blackstone_bricks
fill 464 267 495 464 270 495 minecraft:blackstone
setblock 464 267 499 minecraft:polished_blackstone_bricks
fill 464 267 500 464 270 500 minecraft:blackstone
setblock 464 267 504 minecraft:polished_blackstone_bricks
fill 424 268 464 424 271 464 minecraft:blackstone
setblock 424 268 468 minecraft:polished_blackstone_bricks
fill 424 268 469 424 271 469 minecraft:blackstone
setblock 424 268 473 minecraft:polished_blackstone_bricks
fill 424 268 474 424 271 474 minecraft:blackstone
setblock 424 268 478 minecraft:polished_blackstone_bricks
fill 424 268 479 424 271 479 minecraft:blackstone
setblock 424 268 483 minecraft:polished_blackstone_bricks
setblock 424 268 484 minecraft:blackstone
setblock 424 268 493 minecraft:polished_blackstone_bricks
fill 424 268 494 424 269 494 minecraft:blackstone
setblock 424 268 498 minecraft:polished_blackstone_bricks
fill 424 268 499 424 271 499 minecraft:blackstone
setblock 424 268 502 minecraft:blackstone
setblock 424 268 503 minecraft:polished_blackstone_bricks
fill 424 268 504 424 271 504 minecraft:blackstone
setblock 425 268 467 minecraft:polished_blackstone_bricks
setblock 425 268 468 minecraft:blackstone
setblock 425 268 472 minecraft:polished_blackstone_bricks
fill 425 268 473 425 269 473 minecraft:blackstone
setblock 425 268 477 minecraft:polished_blackstone_bricks
fill 425 268 478 425 270 478 minecraft:blackstone
setblock 425 268 497 minecraft:polished_blackstone_bricks
fill 425 268 498 425 270 498 minecraft:blackstone
setblock 425 268 502 minecraft:polished_blackstone_bricks
fill 425 268 503 425 271 503 minecraft:blackstone
setblock 426 268 476 minecraft:polished_blackstone_bricks
setblock 426 268 501 minecraft:polished_blackstone_bricks
setblock 428 268 464 minecraft:polished_blackstone_bricks
setblock 428 268 504 minecraft:polished_blackstone_bricks
setblock 429 268 464 minecraft:blackstone
setblock 429 268 503 minecraft:polished_blackstone_bricks
fill 429 268 504 432 268 504 minecraft:blackstone
fill 430 268 503 433 268 503 minecraft:blackstone
setblock 433 268 504 minecraft:polished_blackstone_bricks
setblock 434 268 503 minecraft:polished_blackstone_bricks
fill 434 268 504 434 271 504 minecraft:blackstone
fill 435 268 503 435 271 503 minecraft:blackstone
fill 436 268 502 439 268 502 minecraft:blackstone
setblock 438 268 464 minecraft:polished_blackstone_bricks
setblock 438 268 504 minecraft:polished_blackstone_bricks
fill 439 268 464 439 271 464 minecraft:blackstone
setblock 439 268 503 minecraft:polished_blackstone_bricks
fill 439 268 504 439 271 504 minecraft:blackstone
setblock 440 268 502 minecraft:polished_blackstone_bricks
fill 440 268 503 440 271 503 minecraft:blackstone
setblock 441 268 501 minecraft:polished_blackstone_bricks
fill 441 268 502 441 271 502 minecraft:blackstone
fill 442 268 496 442 269 496 minecraft:light_blue_stained_glass
fill 442 268 501 442 270 501 minecraft:blackstone
setblock 443 268 464 minecraft:polished_blackstone_bricks
setblock 443 268 504 minecraft:polished_blackstone_bricks
setblock 444 268 503 minecraft:polished_blackstone_bricks
fill 444 268 504 444 271 504 minecraft:blackstone
setblock 445 268 502 minecraft:polished_blackstone_bricks
fill 445 268 503 445 271 503 minecraft:blackstone
setblock 448 268 504 minecraft:polished_blackstone_bricks
setblock 458 268 504 minecraft:polished_blackstone_bricks
fill 459 268 464 459 271 464 minecraft:blackstone
fill 459 268 504 459 271 504 minecraft:blackstone
setblock 461 268 472 minecraft:blackstone
setblock 461 268 476 minecraft:polished_blackstone_bricks
fill 461 268 477 461 271 477 minecraft:blackstone
setblock 461 268 481 minecraft:polished_blackstone_bricks
fill 461 268 503 461 270 503 minecraft:blackstone
setblock 462 268 464 minecraft:blackstone
setblock 462 268 465 minecraft:polished_blackstone_bricks
setblock 462 268 469 minecraft:blackstone
setblock 462 268 470 minecraft:polished_blackstone_bricks
fill 462 268 471 462 269 471 minecraft:blackstone
setblock 462 268 475 minecraft:polished_blackstone_bricks
fill 462 268 476 462 271 476 minecraft:blackstone
setblock 462 268 480 minecraft:polished_blackstone_bricks
fill 462 268 481 462 271 481 minecraft:blackstone
setblock 462 268 498 minecraft:blackstone
setblock 463 268 464 minecraft:polished_blackstone_bricks
fill 463 268 465 463 268 468 minecraft:blackstone
setblock 463 268 469 minecraft:polished_blackstone_bricks
fill 463 268 470 463 271 470 minecraft:blackstone
setblock 463 268 474 minecraft:polished_blackstone_bricks
fill 463 268 475 463 271 475 minecraft:blackstone
setblock 463 268 479 minecraft:polished_blackstone_bricks
fill 463 268 480 463 271 480 minecraft:blackstone
setblock 463 268 484 minecraft:polished_blackstone_bricks
fill 463 268 485 463 269 485 minecraft:blackstone
setblock 463 268 494 minecraft:polished_blackstone_bricks
fill 463 268 495 463 269 495 minecraft:blackstone
setblock 463 268 499 minecraft:polished_blackstone_bricks
fill 463 268 500 463 271 500 minecraft:blackstone
setblock 463 268 504 minecraft:polished_blackstone_bricks
fill 464 268 464 464 271 464 minecraft:blackstone
setblock 464 268 468 minecraft:polished_blackstone_bricks
fill 464 268 469 464 271 469 minecraft:blackstone
setblock 464 268 473 minecraft:polished_blackstone_bricks
fill 464 268 474 464 271 474 minecraft:blackstone
setblock 464 268 478 minecraft:polished_blackstone_bricks
fill 464 268 479 464 271 479 minecraft:blackstone
setblock 464 268 483 minecraft:polished_blackstone_bricks
fill 464 268 484 464 271 484 minecraft:blackstone
setblock 464 268 488 minecraft:polished_blackstone_bricks
setblock 464 268 489 minecraft:blackstone
setblock 464 268 493 minecraft:polished_blackstone_bricks
fill 464 268 494 464 269 494 minecraft:blackstone
setblock 464 268 498 minecraft:polished_blackstone_bricks
fill 464 268 499 464 271 499 minecraft:blackstone
setblock 464 268 503 minecraft:polished_blackstone_bricks
fill 464 268 504 464 271 504 minecraft:blackstone
setblock 424 269 467 minecraft:polished_blackstone_bricks
fill 424 269 468 424 271 468 minecraft:blackstone
setblock 424 269 472 minecraft:polished_blackstone_bricks
fill 424 269 473 424 272 473 minecraft:blackstone
setblock 424 269 477 minecraft:polished_blackstone_bricks
fill 424 269 478 424 272 478 minecraft:blackstone
setblock 424 269 482 minecraft:polished_blackstone_bricks
fill 424 269 483 424 270 483 minecraft:blackstone
setblock 424 269 493 minecraft:blackstone
setblock 424 269 497 minecraft:polished_blackstone_bricks
fill 424 269 498 424 272 498 minecraft:blackstone
setblock 424 269 502 minecraft:polished_blackstone_bricks
fill 424 269 503 424 272 503 minecraft:blackstone
setblock 425 269 471 minecraft:polished_blackstone_bricks
setblock 425 269 472 minecraft:blackstone
setblock 425 269 476 minecraft:polished_blackstone_bricks
fill 425 269 477 425 270 477 minecraft:blackstone
setblock 425 269 496 minecraft:polished_blackstone_bricks
fill 425 269 497 425 270 497 minecraft:blackstone
setblock 425 269 501 minecraft:polished_blackstone_bricks
fill 425 269 502 425 272 502 minecraft:blackstone
setblock 427 269 464 minecraft:polished_blackstone_bricks
setblock 427 269 504 minecraft:polished_blackstone_bricks
setblock 428 269 464 minecraft:blackstone
setblock 428 269 503 minecraft:polished_blackstone_bricks
fill 428 269 504 431 269 504 minecraft:blackstone
fill 429 269 503 432 269 503 minecraft:blackstone
setblock 432 269 504 minecraft:polished_blackstone_bricks
setblock 433 269 503 minecraft:polished_blackstone_bricks
fill 433 269 504 433 272 504 minecraft:blackstone
fill 434 269 503 434 272 503 minecraft:blackstone
fill 435 269 502 438 269 502 minecraft:blackstone
setblock 437 269 464 minecraft:polished_blackstone_bricks
setblock 437 269 504 minecraft:polished_blackstone_bricks
fill 438 269 464 438 272 464 minecraft:blackstone
setblock 438 269 503 minecraft:polished_blackstone_bricks
fill 438 269 504 438 272 504 minecraft:blackstone
setblock 439 269 501 minecraft:blackstone
setblock 439 269 502 minecraft:polished_blackstone_bricks
fill 439 269 503 439 272 503 minecraft:blackstone
setblock 440 269 501 minecraft:polished_blackstone_bricks
fill 440 269 502 440 272 502 minecraft:blackstone
fill 441 269 501 441 271 501 minecraft:blackstone
setblock 442 269 464 minecraft:polished_blackstone_bricks
setblock 442 269 504 minecraft:polished_blackstone_bricks
setblock 443 269 503 minecraft:polished_blackstone_bricks
fill 443 269 504 443 272 504 minecraft:blackstone
setblock 444 269 502 minecraft:polished_blackstone_bricks
fill 444 269 503 444 272 503 minecraft:blackstone
setblock 445 269 502 minecraft:blackstone
setblock 447 269 504 minecraft:polished_blackstone_bricks
fill 458 269 464 458 272 464 minecraft:blackstone
fill 458 269 504 458 272 504 minecraft:blackstone
fill 460 269 503 460 271 503 minecraft:blackstone
setblock 461 269 475 minecraft:polished_blackstone_bricks
fill 461 269 476 461 271 476 minecraft:blackstone
setblock 461 269 479 minecraft:blackstone
setblock 461 269 480 minecraft:polished_blackstone_bricks
fill 461 269 481 461 270 481 minecraft:blackstone
setblock 462 269 464 minecraft:polished_blackstone_bricks
fill 462 269 465 463 269 465 minecraft:blackstone
setblock 462 269 470 minecraft:blackstone
setblock 462 269 474 minecraft:polished_blackstone_bricks
fill 462 269 475 462 272 475 minecraft:blackstone
setblock 462 269 479 minecraft:polished_blackstone_bricks
fill 462 269 480 462 272 480 minecraft:blackstone
setblock 462 269 503 minecraft:blackstone
setblock 462 269 504 minecraft:polished_blackstone_bricks
fill 463 269 464 463 272 464 minecraft:blackstone
fill 463 269 466 463 269 467 minecraft:blackstone
setblock 463 269 468 minecraft:polished_blackstone_bricks
fill 463 269 469 463 270 469 minecraft:blackstone
setblock 463 269 473 minecraft:polished_blackstone_bricks
fill 463 269 474 463 272 474 minecraft:blackstone
setblock 463 269 478 minecraft:polished_blackstone_bricks
fill 463 269 479 463 272 479 minecraft:blackstone
setblock 463 269 483 minecraft:polished_blackstone_bricks
fill 463 269 484 463 271 484 minecraft:blackstone
setblock 463 269 498 minecraft:polished_blackstone_bricks
fill 463 269 499 463 270 499 minecraft:blackstone
setblock 463 269 503 minecraft:polished_blackstone_bricks
fill 463 269 504 463 272 504 minecraft:blackstone
setblock 464 269 467 minecraft:polished_blackstone_bricks
fill 464 269 468 464 272 468 minecraft:blackstone
setblock 464 269 472 minecraft:polished_blackstone_bricks
fill 464 269 473 464 272 473 minecraft:blackstone
setblock 464 269 477 minecraft:polished_blackstone_bricks
fill 464 269 478 464 272 478 minecraft:blackstone
setblock 464 269 482 minecraft:polished_blackstone_bricks
fill 464 269 483 464 272 483 minecraft:blackstone
setblock 464 269 487 minecraft:polished_blackstone_bricks
setblock 464 269 492 minecraft:polished_blackstone_bricks
setblock 464 269 493 minecraft:blackstone
setblock 464 269 497 minecraft:polished_blackstone_bricks
fill 464 269 498 464 271 498 minecraft:blackstone
setblock 464 269 502 minecraft:polished_blackstone_bricks
fill 464 269 503 464 272 503 minecraft:blackstone
setblock 424 270 466 minecraft:polished_blackstone_bricks
fill 424 270 467 424 272 467 minecraft:blackstone
setblock 424 270 471 minecraft:polished_blackstone_bricks
fill 424 270 472 424 271 472 minecraft:blackstone
setblock 424 270 476 minecraft:polished_blackstone_bricks
fill 424 270 477 424 273 477 minecraft:blackstone
setblock 424 270 481 minecraft:polished_blackstone_bricks
fill 424 270 482 424 272 482 minecraft:blackstone
setblock 424 270 496 minecraft:polished_blackstone_bricks
fill 424 270 497 424 272 497 minecraft:blackstone
setblock 424 270 501 minecraft:polished_blackstone_bricks
fill 424 270 502 424 273 502 minecraft:blackstone
setblock 425 270 475 minecraft:polished_blackstone_bricks
setblock 425 270 476 minecraft:blackstone
setblock 425 270 500 minecraft:polished_blackstone_bricks
fill 425 270 501 425 273 501 minecraft:blackstone
setblock 426 270 464 minecraft:polished_blackstone_bricks
setblock 426 270 466 minecraft:light[level=11]
setblock 426 270 474 minecraft:light[level=11]
setblock 426 270 482 minecraft:light[level=11]
setblock 426 270 490 minecraft:light[level=11]
setblock 426 270 498 minecraft:light[level=11]
fill 426 270 501 427 270 502 minecraft:cyan_concrete
setblock 426 270 504 minecraft:polished_blackstone_bricks
fill 427 270 464 427 271 464 minecraft:blackstone
fill 427 270 499 428 270 500 minecraft:cyan_concrete
setblock 427 270 503 minecraft:polished_blackstone_bricks
fill 427 270 504 430 270 504 minecraft:blackstone
fill 428 270 466 429 270 470 minecraft:cyan_concrete
fill 428 270 503 429 270 503 minecraft:blackstone
fill 429 270 465 434 270 465 minecraft:cyan_concrete
fill 429 270 471 434 270 471 minecraft:cyan_concrete
fill 429 270 499 430 270 499 minecraft:cyan_concrete
fill 430 270 464 433 270 464 minecraft:cyan_concrete
fill 430 270 470 435 270 470 minecraft:cyan_concrete
fill 430 270 500 431 270 500 minecraft:cyan_concrete
fill 430 270 503 430 271 503 minecraft:cyan_concrete
fill 431 270 501 431 271 502 minecraft:cyan_concrete
setblock 431 270 503 minecraft:blackstone
setblock 431 270 504 minecraft:polished_blackstone_bricks
setblock 432 270 503 minecraft:polished_blackstone_bricks
fill 432 270 504 432 273 504 minecraft:blackstone
fill 433 270 503 433 273 503 minecraft:blackstone
fill 434 270 466 435 270 469 minecraft:cyan_concrete
setblock 434 270 474 minecraft:light[level=11]
setblock 434 270 482 minecraft:light[level=11]
setblock 434 270 490 minecraft:light[level=11]
setblock 434 270 498 minecraft:light[level=11]
fill 435 270 502 437 270 502 minecraft:blackstone
setblock 436 270 504 minecraft:polished_blackstone_bricks
fill 437 270 464 437 273 464 minecraft:blackstone
fill 437 270 501 437 271 501 minecraft:blackstone
setblock 437 270 503 minecraft:polished_blackstone_bricks
fill 437 270 504 437 273 504 minecraft:blackstone
setblock 438 270 502 minecraft:polished_blackstone_bricks
fill 438 270 503 438 273 503 minecraft:blackstone
setblock 439 270 501 minecraft:polished_blackstone_bricks
fill 439 270 502 439 273 502 minecraft:blackstone
fill 440 270 479 440 270 482 minecraft:cyan_concrete
fill 440 270 501 440 272 501 minecraft:blackstone
setblock 441 270 464 minecraft:polished_blackstone_bricks
fill 441 270 479 443 270 479 minecraft:cyan_concrete
setblock 441 270 504 minecraft:polished_blackstone_bricks
setblock 442 270 466 minecraft:light[level=11]
setblock 442 270 474 minecraft:light[level=11]
setblock 442 270 482 minecraft:light[level=11]
setblock 442 270 490 minecraft:light[level=11]
setblock 442 270 498 minecraft:light[level=11]
setblock 442 270 503 minecraft:polished_blackstone_bricks
fill 442 270 504 442 273 504 minecraft:blackstone
fill 443 270 480 443 271 481 minecraft:cyan_concrete
setblock 443 270 502 minecraft:polished_blackstone_bricks
fill 443 270 503 443 273 503 minecraft:blackstone
setblock 444 270 502 minecraft:blackstone
setblock 446 270 504 minecraft:polished_blackstone_bricks
setblock 450 270 466 minecraft:light[level=11]
setblock 450 270 474 minecraft:light[level=11]
setblock 450 270 482 minecraft:light[level=11]
setblock 450 270 490 minecraft:light[level=11]
setblock 450 270 498 minecraft:light[level=11]
fill 457 270 504 457 273 504 minecraft:blackstone
setblock 458 270 466 minecraft:light[level=11]
setblock 458 270 474 minecraft:light[level=11]
setblock 458 270 482 minecraft:light[level=11]
setblock 458 270 490 minecraft:light[level=11]
setblock 458 270 498 minecraft:light[level=11]
setblock 461 270 464 minecraft:polished_blackstone_bricks
setblock 461 270 474 minecraft:polished_blackstone_bricks
setblock 461 270 475 minecraft:blackstone
setblock 461 270 479 minecraft:polished_blackstone_bricks
fill 461 270 480 461 271 480 minecraft:blackstone
setblock 461 270 504 minecraft:polished_blackstone_bricks
fill 462 270 464 462 273 464 minecraft:blackstone
setblock 462 270 473 minecraft:polished_blackstone_bricks
fill 462 270 474 462 271 474 minecraft:blackstone
setblock 462 270 478 minecraft:polished_blackstone_bricks
fill 462 270 479 462 273 479 minecraft:blackstone
setblock 462 270 483 minecraft:polished_blackstone_bricks
setblock 462 270 503 minecraft:polished_blackstone_bricks
fill 462 270 504 462 273 504 minecraft:blackstone
setblock 463 270 468 minecraft:blackstone
setblock 463 270 472 minecraft:polished_blackstone_bricks
fill 463 270 473 463 272 473 minecraft:blackstone
setblock 463 270 477 minecraft:polished_blackstone_bricks
fill 463 270 478 463 273 478 minecraft:blackstone
setblock 463 270 482 minecraft:polished_blackstone_bricks
fill 463 270 483 463 273 483 minecraft:blackstone
setblock 463 270 498 minecraft:blackstone
setblock 463 270 502 minecraft:polished_blackstone_bricks
fill 463 270 503 463 271 503 minecraft:blackstone
setblock 464 270 466 minecraft:polished_blackstone_bricks
fill 464 270 467 464 273 467 minecraft:blackstone
setblock 464 270 471 minecraft:polished_blackstone_bricks
fill 464 270 472 464 273 472 minecraft:blackstone
setblock 464 270 476 minecraft:polished_blackstone_bricks
fill 464 270 477 464 273 477 minecraft:blackstone
setblock 464 270 481 minecraft:polished_blackstone_bricks
fill 464 270 482 464 273 482 minecraft:blackstone
setblock 464 270 486 minecraft:polished_blackstone_bricks
setblock 464 270 496 minecraft:polished_blackstone_bricks
fill 464 270 497 464 271 497 minecraft:blackstone
setblock 464 270 501 minecraft:polished_blackstone_bricks
fill 464 270 502 464 273 502 minecraft:blackstone
setblock 424 271 465 minecraft:polished_blackstone_bricks
fill 424 271 466 424 273 466 minecraft:blackstone
setblock 424 271 470 minecraft:polished_blackstone_bricks
setblock 424 271 471 minecraft:blackstone
setblock 424 271 475 minecraft:polished_blackstone_bricks
fill 424 271 476 424 273 476 minecraft:blackstone
setblock 424 271 480 minecraft:polished_blackstone_bricks
fill 424 271 481 424 273 481 minecraft:blackstone
setblock 424 271 496 minecraft:blackstone
setblock 424 271 500 minecraft:polished_blackstone_bricks
fill 424 271 501 424 273 501 minecraft:blackstone
setblock 425 271 464 minecraft:polished_blackstone_bricks
setblock 425 271 499 minecraft:polished_blackstone_bricks
fill 425 271 500 425 272 500 minecraft:blackstone
setblock 425 271 504 minecraft:polished_blackstone_bricks
fill 426 271 464 426 273 464 minecraft:blackstone
setblock 426 271 503 minecraft:polished_blackstone_bricks
fill 426 271 504 429 271 504 minecraft:blackstone
fill 427 271 500 427 271 502 minecraft:cyan_concrete
fill 427 271 503 428 273 503 minecraft:blackstone
fill 428 271 467 429 271 468 minecraft:cyan_concrete
fill 428 271 499 428 271 500 minecraft:cyan_concrete
setblock 429 271 466 minecraft:cyan_concrete
fill 429 271 469 429 271 470 minecraft:cyan_concrete
setblock 429 271 499 minecraft:cyan_concrete
fill 429 271 503 429 272 503 minecraft:cyan_concrete
fill 430 271 465 433 271 465 minecraft:cyan_concrete
fill 430 271 470 434 271 470 minecraft:cyan_concrete
fill 430 271 500 430 272 500 minecraft:cyan_concrete
setblock 430 271 504 minecraft:polished_blackstone_bricks
fill 431 271 471 432 271 471 minecraft:cyan_concrete
setblock 431 271 503 minecraft:polished_blackstone_bricks
fill 431 271 504 431 273 504 minecraft:blackstone
fill 432 271 503 432 273 503 minecraft:blackstone
fill 434 271 466 434 271 469 minecraft:cyan_concrete
fill 434 271 502 436 271 502 minecraft:blackstone
fill 435 271 467 435 271 468 minecraft:cyan_concrete
setblock 435 271 504 minecraft:polished_blackstone_bricks
fill 436 271 464 436 273 464 minecraft:blackstone
setblock 436 271 503 minecraft:polished_blackstone_bricks
fill 436 271 504 436 273 504 minecraft:blackstone
setblock 437 271 502 minecraft:polished_blackstone_bricks
fill 437 271 503 437 273 503 minecraft:blackstone
setblock 438 271 501 minecraft:polished_blackstone_bricks
fill 438 271 502 438 273 502 minecraft:blackstone
fill 439 271 501 439 273 501 minecraft:blackstone
setblock 440 271 464 minecraft:polished_blackstone_bricks
fill 440 271 480 440 271 481 minecraft:cyan_concrete
setblock 440 271 504 minecraft:polished_blackstone_bricks
fill 441 271 464 441 273 464 minecraft:blackstone
fill 441 271 479 442 271 479 minecraft:cyan_concrete
setblock 441 271 503 minecraft:polished_blackstone_bricks
fill 441 271 504 441 273 504 minecraft:blackstone
setblock 442 271 502 minecraft:polished_blackstone_bricks
fill 442 271 503 442 273 503 minecraft:blackstone
setblock 443 271 502 minecraft:blackstone
setblock 445 271 504 minecraft:polished_blackstone_bricks
setblock 446 271 504 minecraft:blackstone
fill 457 271 464 457 273 464 minecraft:blackstone
fill 459 271 503 459 272 503 minecraft:blackstone
setblock 460 271 464 minecraft:polished_blackstone_bricks
setblock 460 271 504 minecraft:polished_blackstone_bricks
fill 461 271 464 461 273 464 minecraft:blackstone
setblock 461 271 478 minecraft:polished_blackstone_bricks
fill 461 271 479 461 272 479 minecraft:blackstone
setblock 461 271 503 minecraft:polished_blackstone_bricks
fill 461 271 504 461 273 504 minecraft:blackstone
setblock 462 271 473 minecraft:blackstone
setblock 462 271 477 minecraft:polished_blackstone_bricks
fill 462 271 478 462 273 478 minecraft:blackstone
setblock 462 271 482 minecraft:polished_blackstone_bricks
fill 462 271 503 462 273 503 minecraft:blackstone
setblock 463 271 471 minecraft:polished_blackstone_bricks
fill 463 271 472 463 272 472 minecraft:blackstone
setblock 463 271 476 minecraft:polished_blackstone_bricks
fill 463 271 477 463 273 477 minecraft:blackstone
setblock 463 271 481 minecraft:polished_blackstone_bricks
fill 463 271 482 463 273 482 minecraft:blackstone
setblock 463 271 501 minecraft:polished_blackstone_bricks
setblock 463 271 502 minecraft:blackstone
setblock 464 271 465 minecraft:polished_blackstone_bricks
fill 464 271 466 464 273 466 minecraft:blackstone
setblock 464 271 470 minecraft:polished_blackstone_bricks
fill 464 271 471 464 273 471 minecraft:blackstone
setblock 464 271 475 minecraft:polished_blackstone_bricks
fill 464 271 476 464 273 476 minecraft:blackstone
setblock 464 271 480 minecraft:polished_blackstone_bricks
fill 464 271 481 464 273 481 minecraft:blackstone
setblock 464 271 485 minecraft:polished_blackstone_bricks
setblock 464 271 500 minecraft:polished_blackstone_bricks
fill 464 271 501 464 273 501 minecraft:blackstone
setblock 424 272 464 minecraft:polished_blackstone_bricks
fill 424 272 465 424 273 465 minecraft:blackstone
setblock 424 272 474 minecraft:polished_blackstone_bricks
setblock 424 272 475 minecraft:blackstone
setblock 424 272 479 minecraft:polished_blackstone_bricks
fill 424 272 480 424 273 480 minecraft:blackstone
setblock 424 272 499 minecraft:polished_blackstone_bricks
fill 424 272 500 424 273 500 minecraft:blackstone
setblock 424 272 504 minecraft:polished_blackstone_bricks
fill 425 272 464 425 273 464 minecraft:blackstone
setblock 425 272 503 minecraft:polished_blackstone_bricks
fill 425 272 504 428 272 504 minecraft:blackstone
fill 426 272 503 426 273 503 minecraft:blackstone
fill 427 272 501 427 272 502 minecraft:cyan_concrete
setblock 428 272 500 minecraft:cyan_concrete
fill 429 272 467 429 272 469 minecraft:cyan_concrete
setblock 429 272 504 minecraft:polished_blackstone_bricks
fill 430 272 470 433 272 470 minecraft:cyan_concrete
setblock 430 272 503 minecraft:polished_blackstone_bricks
fill 430 272 504 430 273 504 minecraft:blackstone
fill 431 272 465 432 272 465 minecraft:cyan_concrete
fill 431 272 503 431 273 503 minecraft:blackstone
fill 434 272 467 434 272 469 minecraft:cyan_concrete
fill 434 272 502 435 272 502 minecraft:blackstone
setblock 434 272 504 minecraft:polished_blackstone_bricks
fill 435 272 464 435 273 464 minecraft:blackstone
setblock 435 272 503 minecraft:polished_blackstone_bricks
fill 435 272 504 435 273 504 minecraft:blackstone
setblock 436 272 502 minecraft:polished_blackstone_bricks
fill 436 272 503 436 273 503 minecraft:blackstone
fill 437 272 502 437 273 502 minecraft:blackstone
fill 438 272 501 438 273 501 minecraft:blackstone
setblock 439 272 464 minecraft:polished_blackstone_bricks
setblock 439 272 504 minecraft:polished_blackstone_bricks
fill 440 272 464 440 273 464 minecraft:blackstone
setblock 440 272 481 minecraft:cyan_concrete
setblock 440 272 503 minecraft:polished_blackstone_bricks
fill 440 272 504 440 273 504 minecraft:blackstone
setblock 441 272 502 minecraft:polished_blackstone_bricks
fill 441 272 503 441 273 503 minecraft:blackstone
fill 442 272 502 442 273 502 minecraft:blackstone
setblock 444 272 504 minecraft:polished_blackstone_bricks
fill 445 272 504 445 273 504 minecraft:blackstone
fill 456 272 504 456 273 504 minecraft:blackstone
setblock 459 272 464 minecraft:polished_blackstone_bricks
setblock 459 272 504 minecraft:polished_blackstone_bricks
fill 460 272 464 460 273 464 minecraft:blackstone
setblock 460 272 503 minecraft:polished_blackstone_bricks
fill 460 272 504 460 273 504 minecraft:blackstone
fill 461 272 465 461 273 465 minecraft:blackstone
setblock 461 272 478 minecraft:blackstone
fill 461 272 503 461 273 503 minecraft:blackstone
setblock 462 272 476 minecraft:polished_blackstone_bricks
fill 462 272 477 462 273 477 minecraft:blackstone
setblock 462 272 481 minecraft:polished_blackstone_bricks
fill 462 272 482 462 273 482 minecraft:blackstone
setblock 463 272 475 minecraft:polished_blackstone_bricks
fill 463 272 476 463 273 476 minecraft:blackstone
setblock 463 272 480 minecraft:polished_blackstone_bricks
fill 463 272 481 463 273 481 minecraft:blackstone
setblock 464 272 464 minecraft:polished_blackstone_bricks
fill 464 272 465 464 273 465 minecraft:blackstone
setblock 464 272 469 minecraft:polished_blackstone_bricks
fill 464 272 470 464 273 470 minecraft:blackstone
setblock 464 272 474 minecraft:polished_blackstone_bricks
fill 464 272 475 464 273 475 minecraft:blackstone
setblock 464 272 479 minecraft:polished_blackstone_bricks
fill 464 272 480 464 273 480 minecraft:blackstone
setblock 464 272 484 minecraft:polished_blackstone_bricks
setblock 464 272 485 minecraft:blackstone
setblock 464 272 499 minecraft:polished_blackstone_bricks
fill 464 272 500 464 273 500 minecraft:blackstone
setblock 464 272 504 minecraft:polished_blackstone_bricks
setblock 424 273 464 minecraft:blackstone
setblock 424 273 478 minecraft:polished_blackstone_bricks
setblock 424 273 479 minecraft:blackstone
setblock 424 273 498 minecraft:polished_blackstone_bricks
setblock 424 273 499 minecraft:blackstone
setblock 424 273 503 minecraft:polished_blackstone_bricks
fill 424 273 504 427 273 504 minecraft:blackstone
setblock 425 273 502 minecraft:polished_blackstone_bricks
setblock 425 273 503 minecraft:blackstone
setblock 428 273 504 minecraft:polished_blackstone_bricks
setblock 429 273 503 minecraft:polished_blackstone_bricks
setblock 429 273 504 minecraft:blackstone
setblock 430 273 503 minecraft:blackstone
setblock 433 273 504 minecraft:polished_blackstone_bricks
setblock 434 273 464 minecraft:blackstone
setblock 434 273 502 minecraft:blackstone
setblock 434 273 503 minecraft:polished_blackstone_bricks
setblock 434 273 504 minecraft:blackstone
setblock 435 273 502 minecraft:polished_blackstone_bricks
setblock 435 273 503 minecraft:blackstone
setblock 436 273 502 minecraft:blackstone
setblock 438 273 464 minecraft:polished_blackstone_bricks
setblock 438 273 504 minecraft:polished_blackstone_bricks
setblock 439 273 464 minecraft:blackstone
setblock 439 273 503 minecraft:polished_blackstone_bricks
setblock 439 273 504 minecraft:blackstone
setblock 440 273 502 minecraft:polished_blackstone_bricks
setblock 440 273 503 minecraft:blackstone
setblock 441 273 502 minecraft:blackstone
setblock 443 273 504 minecraft:polished_blackstone_bricks
setblock 444 273 504 minecraft:blackstone
setblock 455 273 504 minecraft:blackstone
setblock 456 273 464 minecraft:blackstone
setblock 458 273 464 minecraft:polished_blackstone_bricks
setblock 458 273 503 minecraft:blackstone
setblock 458 273 504 minecraft:polished_blackstone_bricks
fill 459 273 464 459 273 465 minecraft:blackstone
setblock 459 273 503 minecraft:polished_blackstone_bricks
setblock 459 273 504 minecraft:blackstone
setblock 460 273 465 minecraft:blackstone
setblock 460 273 503 minecraft:blackstone
setblock 462 273 465 minecraft:polished_blackstone_bricks
setblock 462 273 476 minecraft:blackstone
setblock 462 273 480 minecraft:polished_blackstone_bricks
setblock 462 273 481 minecraft:blackstone
setblock 463 273 464 minecraft:polished_blackstone_bricks
setblock 463 273 474 minecraft:polished_blackstone_bricks
setblock 463 273 475 minecraft:blackstone
setblock 463 273 479 minecraft:polished_blackstone_bricks
setblock 463 273 480 minecraft:blackstone
setblock 463 273 504 minecraft:polished_blackstone_bricks
setblock 464 273 464 minecraft:blackstone
setblock 464 273 468 minecraft:polished_blackstone_bricks
setblock 464 273 469 minecraft:blackstone
setblock 464 273 473 minecraft:polished_blackstone_bricks
setblock 464 273 474 minecraft:blackstone
setblock 464 273 478 minecraft:polished_blackstone_bricks
setblock 464 273 479 minecraft:blackstone
setblock 464 273 483 minecraft:polished_blackstone_bricks
setblock 464 273 484 minecraft:blackstone
setblock 464 273 503 minecraft:polished_blackstone_bricks
setblock 464 273 504 minecraft:blackstone
setblock 426 278 466 minecraft:light[level=11]
setblock 426 278 474 minecraft:light[level=11]
setblock 426 278 482 minecraft:light[level=11]
setblock 426 278 490 minecraft:light[level=11]
setblock 426 278 498 minecraft:light[level=11]
setblock 434 278 466 minecraft:light[level=11]
setblock 434 278 474 minecraft:light[level=11]
setblock 434 278 482 minecraft:light[level=11]
setblock 434 278 490 minecraft:light[level=11]
setblock 434 278 498 minecraft:light[level=11]
setblock 442 278 466 minecraft:light[level=11]
setblock 442 278 474 minecraft:light[level=11]
setblock 442 278 490 minecraft:light[level=11]
setblock 442 278 498 minecraft:light[level=11]
setblock 450 278 466 minecraft:light[level=11]
setblock 450 278 474 minecraft:light[level=11]
setblock 450 278 482 minecraft:light[level=11]
setblock 450 278 490 minecraft:light[level=11]
setblock 450 278 498 minecraft:light[level=11]
setblock 458 278 466 minecraft:light[level=11]
setblock 458 278 474 minecraft:light[level=11]
setblock 458 278 482 minecraft:light[level=11]
setblock 458 278 490 minecraft:light[level=11]
setblock 458 278 498 minecraft:light[level=11]
fill 424 279 481 439 279 487 minecraft:blackstone
fill 425 279 477 463 279 480 minecraft:blackstone
fill 425 279 488 463 279 491 minecraft:blackstone
fill 426 279 475 462 279 476 minecraft:blackstone
fill 426 279 492 462 279 493 minecraft:blackstone
fill 427 279 473 461 279 474 minecraft:blackstone
fill 427 279 494 461 279 495 minecraft:blackstone
fill 428 279 472 460 279 472 minecraft:blackstone
fill 428 279 496 460 279 496 minecraft:blackstone
fill 429 279 471 459 279 471 minecraft:blackstone
fill 429 279 497 459 279 497 minecraft:blackstone
fill 430 279 470 458 279 470 minecraft:blackstone
fill 430 279 498 458 279 498 minecraft:blackstone
fill 431 279 469 457 279 469 minecraft:blackstone
fill 431 279 499 457 279 499 minecraft:blackstone
fill 432 279 468 456 279 468 minecraft:blackstone
fill 432 279 500 456 279 500 minecraft:blackstone
fill 433 279 467 455 279 467 minecraft:blackstone
fill 433 279 501 455 279 501 minecraft:blackstone
fill 435 279 466 453 279 466 minecraft:blackstone
fill 435 279 502 453 279 502 minecraft:blackstone
fill 437 279 465 451 280 465 minecraft:blackstone
fill 437 279 503 451 280 503 minecraft:blackstone
fill 440 279 481 441 279 481 minecraft:blackstone
fill 440 279 482 440 279 483 minecraft:cyan_concrete
fill 440 279 485 440 279 486 minecraft:cyan_concrete
fill 440 279 487 441 279 487 minecraft:blackstone
fill 441 279 464 447 280 464 minecraft:blackstone
setblock 441 279 482 minecraft:cyan_concrete
setblock 441 279 486 minecraft:cyan_concrete
fill 441 279 504 447 280 504 minecraft:blackstone
fill 442 279 481 443 279 481 minecraft:cyan_concrete
fill 442 279 487 443 279 487 minecraft:cyan_concrete
fill 443 279 482 444 279 482 minecraft:cyan_concrete
fill 443 279 486 444 279 486 minecraft:cyan_concrete
fill 444 279 481 464 279 481 minecraft:blackstone
fill 444 279 483 445 279 483 minecraft:cyan_concrete
fill 444 279 485 445 279 485 minecraft:cyan_concrete
fill 444 279 487 464 279 487 minecraft:blackstone
fill 445 279 482 464 279 482 minecraft:blackstone
setblock 445 279 484 minecraft:cyan_concrete
fill 445 279 486 464 279 486 minecraft:blackstone
fill 446 279 483 464 279 485 minecraft:blackstone
fill 424 280 464 425 280 504 minecraft:blackstone
fill 426 280 464 426 280 479 minecraft:blackstone
fill 426 280 480 437 280 488 minecraft:polished_blackstone_bricks
fill 426 280 489 426 280 504 minecraft:blackstone
fill 427 280 464 427 280 476 minecraft:blackstone
fill 427 280 477 441 280 479 minecraft:polished_blackstone_bricks
fill 427 280 489 441 280 491 minecraft:polished_blackstone_bricks
fill 427 280 492 427 280 504 minecraft:blackstone
fill 428 280 464 428 280 474 minecraft:blackstone
fill 428 280 475 460 280 476 minecraft:polished_blackstone_bricks
fill 428 280 492 460 280 493 minecraft:polished_blackstone_bricks
fill 428 280 494 428 280 504 minecraft:blackstone
fill 429 280 464 429 280 472 minecraft:blackstone
fill 429 280 473 459 280 474 minecraft:polished_blackstone_bricks
fill 429 280 494 459 280 495 minecraft:polished_blackstone_bricks
fill 429 280 496 429 280 504 minecraft:blackstone
fill 430 280 464 430 280 471 minecraft:blackstone
fill 430 280 472 458 280 472 minecraft:polished_blackstone_bricks
fill 430 280 496 458 280 496 minecraft:polished_blackstone_bricks
fill 430 280 497 430 280 504 minecraft:blackstone
fill 431 280 464 431 280 470 minecraft:blackstone
fill 431 280 471 457 280 471 minecraft:polished_blackstone_bricks
fill 431 280 497 457 280 497 minecraft:polished_blackstone_bricks
fill 431 280 498 431 280 504 minecraft:blackstone
fill 432 280 464 432 280 469 minecraft:blackstone
fill 432 280 470 456 280 470 minecraft:polished_blackstone_bricks
fill 432 280 498 456 280 498 minecraft:polished_blackstone_bricks
fill 432 280 499 432 280 504 minecraft:blackstone
fill 433 280 464 434 280 468 minecraft:blackstone
fill 433 280 469 455 280 469 minecraft:polished_blackstone_bricks
fill 433 280 499 455 280 499 minecraft:polished_blackstone_bricks
fill 433 280 500 434 280 504 minecraft:blackstone
fill 435 280 464 436 280 467 minecraft:blackstone
fill 435 280 468 453 280 468 minecraft:polished_blackstone_bricks
fill 435 280 500 453 280 500 minecraft:polished_blackstone_bricks
fill 435 280 501 436 280 504 minecraft:blackstone
fill 437 280 464 440 280 464 minecraft:blackstone
fill 437 280 466 439 280 466 minecraft:blackstone
fill 437 280 467 451 280 467 minecraft:polished_blackstone_bricks
fill 437 280 501 451 280 501 minecraft:polished_blackstone_bricks
fill 437 280 502 439 280 502 minecraft:blackstone
fill 437 280 504 440 280 504 minecraft:blackstone
fill 438 280 480 438 280 481 minecraft:polished_blackstone_bricks
fill 438 280 482 438 280 486 minecraft:cyan_concrete
fill 438 280 487 438 280 488 minecraft:polished_blackstone_bricks
setblock 439 280 480 minecraft:polished_blackstone_bricks
fill 439 280 481 439 280 482 minecraft:cyan_concrete
fill 439 280 483 439 280 485 minecraft:sea_lantern
fill 439 280 486 439 280 487 minecraft:cyan_concrete
setblock 439 280 488 minecraft:polished_blackstone_bricks
fill 440 280 466 448 280 466 minecraft:polished_blackstone_bricks
fill 440 280 480 440 280 481 minecraft:cyan_concrete
fill 440 280 482 440 280 483 minecraft:sea_lantern
fill 440 280 485 440 280 486 minecraft:sea_lantern
fill 440 280 487 440 280 488 minecraft:cyan_concrete
fill 440 280 502 448 280 502 minecraft:polished_blackstone_bricks
fill 441 280 480 445 280 480 minecraft:cyan_concrete
fill 441 280 481 441 280 482 minecraft:sea_lantern
fill 441 280 486 441 280 487 minecraft:sea_lantern
fill 441 280 488 445 280 488 minecraft:cyan_concrete
fill 442 280 477 461 280 478 minecraft:polished_blackstone_bricks
fill 442 280 479 443 280 479 minecraft:cyan_concrete
fill 442 280 481 443 280 481 minecraft:sea_lantern
fill 442 280 487 443 280 487 minecraft:sea_lantern
fill 442 280 489 443 280 489 minecraft:cyan_concrete
fill 442 280 490 461 280 491 minecraft:polished_blackstone_bricks
fill 443 280 482 444 280 482 minecraft:sea_lantern
fill 443 280 486 444 280 486 minecraft:sea_lantern
fill 444 280 479 461 280 479 minecraft:polished_blackstone_bricks
fill 444 280 481 446 280 481 minecraft:cyan_concrete
fill 444 280 483 445 280 483 minecraft:sea_lantern
fill 444 280 485 445 280 485 minecraft:sea_lantern
fill 444 280 487 446 280 487 minecraft:cyan_concrete
fill 444 280 489 461 280 489 minecraft:polished_blackstone_bricks
fill 445 280 482 447 280 482 minecraft:cyan_concrete
setblock 445 280 484 minecraft:sea_lantern
fill 445 280 486 447 280 486 minecraft:cyan_concrete
fill 446 280 480 462 280 480 minecraft:polished_blackstone_bricks
fill 446 280 483 447 280 485 minecraft:cyan_concrete
fill 446 280 488 462 280 488 minecraft:polished_blackstone_bricks
fill 447 280 481 462 280 481 minecraft:polished_blackstone_bricks
fill 447 280 487 462 280 487 minecraft:polished_blackstone_bricks
fill 448 280 464 464 280 464 minecraft:blackstone
fill 448 280 482 462 280 486 minecraft:polished_blackstone_bricks
fill 448 280 504 464 280 504 minecraft:blackstone
fill 449 280 466 464 280 466 minecraft:blackstone
fill 449 280 502 464 280 502 minecraft:blackstone
fill 452 280 465 464 280 465 minecraft:blackstone
fill 452 280 467 464 280 467 minecraft:blackstone
fill 452 280 501 464 280 501 minecraft:blackstone
fill 452 280 503 464 280 503 minecraft:blackstone
fill 454 280 468 464 280 468 minecraft:blackstone
fill 454 280 500 464 280 500 minecraft:blackstone
fill 456 280 469 464 280 469 minecraft:blackstone
fill 456 280 499 464 280 499 minecraft:blackstone
fill 457 280 470 464 280 470 minecraft:blackstone
fill 457 280 498 464 280 498 minecraft:blackstone
fill 458 280 471 464 280 471 minecraft:blackstone
fill 458 280 497 464 280 497 minecraft:blackstone
fill 459 280 472 464 280 472 minecraft:blackstone
fill 459 280 496 464 280 496 minecraft:blackstone
fill 460 280 473 464 280 474 minecraft:blackstone
fill 460 280 494 464 280 495 minecraft:blackstone
fill 461 280 475 464 280 476 minecraft:blackstone
fill 461 280 492 464 280 493 minecraft:blackstone
fill 462 280 477 464 280 479 minecraft:blackstone
fill 462 280 489 464 280 491 minecraft:blackstone
fill 463 280 480 464 280 488 minecraft:blackstone
fill 426 281 479 426 281 489 minecraft:blackstone
fill 427 281 476 427 281 478 minecraft:blackstone
fill 427 281 479 435 281 489 minecraft:polished_blackstone_bricks
fill 427 281 490 427 281 492 minecraft:blackstone
setblock 428 281 475 minecraft:blackstone
fill 428 281 476 439 281 478 minecraft:polished_blackstone_bricks
fill 428 281 490 439 281 492 minecraft:polished_blackstone_bricks
setblock 428 281 493 minecraft:blackstone
fill 429 281 473 429 281 474 minecraft:blackstone
fill 429 281 475 459 281 475 minecraft:polished_blackstone_bricks
fill 429 281 493 459 281 493 minecraft:polished_blackstone_bricks
fill 429 281 494 429 281 495 minecraft:blackstone
setblock 430 281 472 minecraft:blackstone
fill 430 281 473 458 281 474 minecraft:polished_blackstone_bricks
fill 430 281 494 458 281 495 minecraft:polished_blackstone_bricks
setblock 430 281 496 minecraft:blackstone
setblock 431 281 471 minecraft:blackstone
fill 431 281 472 457 281 472 minecraft:polished_blackstone_bricks
fill 431 281 496 457 281 496 minecraft:polished_blackstone_bricks
setblock 431 281 497 minecraft:blackstone
setblock 432 281 470 minecraft:blackstone
fill 432 281 471 456 281 471 minecraft:polished_blackstone_bricks
fill 432 281 497 456 281 497 minecraft:polished_blackstone_bricks
setblock 432 281 498 minecraft:blackstone
fill 433 281 469 434 281 469 minecraft:blackstone
fill 433 281 470 455 281 470 minecraft:polished_blackstone_bricks
fill 433 281 498 455 281 498 minecraft:polished_blackstone_bricks
fill 433 281 499 434 281 499 minecraft:blackstone
setblock 435 281 468 minecraft:blackstone
fill 435 281 469 453 281 469 minecraft:polished_blackstone_bricks
fill 435 281 499 453 281 499 minecraft:polished_blackstone_bricks
setblock 435 281 500 minecraft:blackstone
fill 436 281 467 438 281 467 minecraft:blackstone
fill 436 281 468 452 281 468 minecraft:polished_blackstone_bricks
fill 436 281 479 436 281 482 minecraft:polished_blackstone_bricks
fill 436 281 483 437 281 485 minecraft:cyan_concrete
fill 436 281 486 436 281 489 minecraft:polished_blackstone_bricks
fill 436 281 500 452 281 500 minecraft:polished_blackstone_bricks
fill 436 281 501 438 281 501 minecraft:blackstone
fill 437 281 479 437 281 480 minecraft:polished_blackstone_bricks
fill 437 281 481 437 281 482 minecraft:cyan_concrete
fill 437 281 486 437 281 487 minecraft:cyan_concrete
fill 437 281 488 437 281 489 minecraft:polished_blackstone_bricks
fill 438 281 479 438 281 481 minecraft:cyan_concrete
fill 438 281 487 438 281 489 minecraft:cyan_concrete
fill 439 281 466 449 281 466 minecraft:blackstone
fill 439 281 467 449 281 467 minecraft:polished_blackstone_bricks
fill 439 281 479 439 281 480 minecraft:cyan_concrete
fill 439 281 488 439 281 489 minecraft:cyan_concrete
fill 439 281 501 449 281 501 minecraft:polished_blackstone_bricks
fill 439 281 502 449 281 502 minecraft:blackstone
fill 440 281 476 441 281 477 minecraft:polished_blackstone_bricks
fill 440 281 478 441 281 479 minecraft:cyan_concrete
fill 440 281 489 441 281 490 minecraft:cyan_concrete
fill 440 281 491 441 281 492 minecraft:polished_blackstone_bricks
fill 442 281 476 460 281 476 minecraft:polished_blackstone_bricks
fill 442 281 477 444 281 478 minecraft:cyan_concrete
fill 442 281 490 444 281 491 minecraft:cyan_concrete
fill 442 281 492 460 281 492 minecraft:polished_blackstone_bricks
fill 444 281 479 448 281 479 minecraft:cyan_concrete
fill 444 281 489 448 281 489 minecraft:cyan_concrete
fill 445 281 477 460 281 477 minecraft:polished_blackstone_bricks
fill 445 281 478 446 281 478 minecraft:cyan_concrete
fill 445 281 490 446 281 490 minecraft:cyan_concrete
fill 445 281 491 460 281 491 minecraft:polished_blackstone_bricks
fill 446 281 480 448 281 480 minecraft:cyan_concrete
fill 446 281 488 448 281 488 minecraft:cyan_concrete
fill 447 281 478 460 281 478 minecraft:polished_blackstone_bricks
fill 447 281 481 449 281 481 minecraft:cyan_concrete
fill 447 281 487 449 281 487 minecraft:cyan_concrete
fill 447 281 490 460 281 490 minecraft:polished_blackstone_bricks
fill 448 281 482 449 281 486 minecraft:cyan_concrete
fill 449 281 479 461 281 480 minecraft:polished_blackstone_bricks
fill 449 281 488 461 281 489 minecraft:polished_blackstone_bricks
fill 450 281 467 452 281 467 minecraft:blackstone
fill 450 281 481 461 281 482 minecraft:polished_blackstone_bricks
fill 450 281 483 450 281 485 minecraft:cyan_concrete
fill 450 281 486 461 281 487 minecraft:polished_blackstone_bricks
fill 450 281 501 452 281 501 minecraft:blackstone
fill 451 281 483 461 281 485 minecraft:polished_blackstone_bricks
setblock 453 281 468 minecraft:blackstone
setblock 453 281 500 minecraft:blackstone
fill 454 281 469 455 281 469 minecraft:blackstone
fill 454 281 499 455 281 499 minecraft:blackstone
setblock 456 281 470 minecraft:blackstone
setblock 456 281 498 minecraft:blackstone
setblock 457 281 471 minecraft:blackstone
setblock 457 281 497 minecraft:blackstone
setblock 458 281 472 minecraft:blackstone
setblock 458 281 496 minecraft:blackstone
fill 459 281 473 459 281 474 minecraft:blackstone
fill 459 281 494 459 281 495 minecraft:blackstone
setblock 460 281 475 minecraft:blackstone
setblock 460 281 493 minecraft:blackstone
fill 461 281 476 461 281 478 minecraft:blackstone
fill 461 281 490 461 281 492 minecraft:blackstone
fill 462 281 479 462 281 489 minecraft:blackstone
fill 427 282 479 427 282 489 minecraft:blackstone
fill 428 282 476 428 282 478 minecraft:blackstone
fill 428 282 479 434 282 489 minecraft:polished_blackstone_bricks
fill 428 282 490 428 282 492 minecraft:blackstone
fill 429 282 475 429 282 476 minecraft:blackstone
fill 429 282 477 436 282 478 minecraft:polished_blackstone_bricks
fill 429 282 490 436 282 491 minecraft:polished_blackstone_bricks
fill 429 282 492 429 282 493 minecraft:blackstone
fill 430 282 473 430 282 474 minecraft:blackstone
fill 430 282 475 439 282 476 minecraft:polished_blackstone_bricks
fill 430 282 492 439 282 493 minecraft:polished_blackstone_bricks
fill 430 282 494 430 282 495 minecraft:blackstone
fill 431 282 472 431 282 473 minecraft:blackstone
fill 431 282 474 457 282 474 minecraft:polished_blackstone_bricks
fill 431 282 494 457 282 494 minecraft:polished_blackstone_bricks
fill 431 282 495 431 282 496 minecraft:blackstone
fill 432 282 471 432 282 472 minecraft:blackstone
fill 432 282 473 456 282 473 minecraft:polished_blackstone_bricks
fill 432 282 495 456 282 495 minecraft:polished_blackstone_bricks
fill 432 282 496 432 282 497 minecraft:blackstone
fill 433 282 470 433 282 471 minecraft:blackstone
fill 433 282 472 455 282 472 minecraft:polished_blackstone_bricks
fill 433 282 496 455 282 496 minecraft:polished_blackstone_bricks
fill 433 282 497 433 282 498 minecraft:blackstone
setblock 434 282 470 minecraft:blackstone
fill 434 282 471 454 282 471 minecraft:polished_blackstone_bricks
fill 434 282 497 454 282 497 minecraft:polished_blackstone_bricks
setblock 434 282 498 minecraft:blackstone
fill 435 282 469 436 282 469 minecraft:blackstone
fill 435 282 470 453 282 470 minecraft:polished_blackstone_bricks
fill 435 282 479 435 282 480 minecraft:polished_blackstone_bricks
fill 435 282 481 435 282 487 minecraft:cyan_concrete
fill 435 282 488 435 282 489 minecraft:polished_blackstone_bricks
fill 435 282 498 453 282 498 minecraft:polished_blackstone_bricks
fill 435 282 499 436 282 499 minecraft:blackstone
fill 436 282 468 438 282 468 minecraft:blackstone
fill 436 282 479 436 282 482 minecraft:cyan_concrete
fill 436 282 486 436 282 489 minecraft:cyan_concrete
fill 436 282 500 438 282 500 minecraft:blackstone
fill 437 282 469 451 282 469 minecraft:polished_blackstone_bricks
setblock 437 282 477 minecraft:polished_blackstone_bricks
fill 437 282 478 437 282 480 minecraft:cyan_concrete
fill 437 282 488 437 282 490 minecraft:cyan_concrete
setblock 437 282 491 minecraft:polished_blackstone_bricks
fill 437 282 499 451 282 499 minecraft:polished_blackstone_bricks
fill 438 282 477 439 282 478 minecraft:cyan_concrete
fill 438 282 490 439 282 491 minecraft:cyan_concrete
fill 439 282 467 449 282 467 minecraft:blackstone
fill 439 282 468 449 282 468 minecraft:polished_blackstone_bricks
fill 439 282 500 449 282 500 minecraft:polished_blackstone_bricks
fill 439 282 501 449 282 501 minecraft:blackstone
fill 440 282 475 442 282 475 minecraft:polished_blackstone_bricks
fill 440 282 476 441 282 477 minecraft:cyan_concrete
fill 440 282 491 441 282 492 minecraft:cyan_concrete
fill 440 282 493 442 282 493 minecraft:polished_blackstone_bricks
fill 442 282 476 447 282 476 minecraft:cyan_concrete
fill 442 282 492 447 282 492 minecraft:cyan_concrete
fill 443 282 475 444 282 475 minecraft:cyan_concrete
fill 443 282 493 444 282 493 minecraft:cyan_concrete
fill 445 282 475 458 282 475 minecraft:polished_blackstone_bricks
fill 445 282 477 449 282 477 minecraft:cyan_concrete
fill 445 282 491 449 282 491 minecraft:cyan_concrete
fill 445 282 493 458 282 493 minecraft:polished_blackstone_bricks
fill 447 282 478 450 282 478 minecraft:cyan_concrete
fill 447 282 490 450 282 490 minecraft:cyan_concrete
fill 448 282 476 458 282 476 minecraft:polished_blackstone_bricks
fill 448 282 492 458 282 492 minecraft:polished_blackstone_bricks
fill 449 282 479 450 282 480 minecraft:cyan_concrete
fill 449 282 488 450 282 489 minecraft:cyan_concrete
fill 450 282 468 452 282 468 minecraft:blackstone
fill 450 282 477 459 282 477 minecraft:polished_blackstone_bricks
fill 450 282 481 451 282 482 minecraft:cyan_concrete
fill 450 282 486 451 282 487 minecraft:cyan_concrete
fill 450 282 491 459 282 491 minecraft:polished_blackstone_bricks
fill 450 282 500 452 282 500 minecraft:blackstone
fill 451 282 478 459 282 479 minecraft:polished_blackstone_bricks
setblock 451 282 480 minecraft:cyan_concrete
fill 451 282 483 452 282 485 minecraft:cyan_concrete
setblock 451 282 488 minecraft:cyan_concrete
fill 451 282 489 459 282 490 minecraft:polished_blackstone_bricks
fill 452 282 469 453 282 469 minecraft:blackstone
fill 452 282 480 460 282 481 minecraft:polished_blackstone_bricks
setblock 452 282 482 minecraft:cyan_concrete
setblock 452 282 486 minecraft:cyan_concrete
fill 452 282 487 460 282 488 minecraft:polished_blackstone_bricks
fill 452 282 499 453 282 499 minecraft:blackstone
fill 453 282 482 460 282 486 minecraft:polished_blackstone_bricks
fill 454 282 470 455 282 470 minecraft:blackstone
fill 454 282 498 455 282 498 minecraft:blackstone
fill 455 282 471 456 282 471 minecraft:blackstone
fill 455 282 497 456 282 497 minecraft:blackstone
fill 456 282 472 457 282 472 minecraft:blackstone
fill 456 282 496 457 282 496 minecraft:blackstone
fill 457 282 473 458 282 473 minecraft:blackstone
fill 457 282 495 458 282 495 minecraft:blackstone
setblock 458 282 474 minecraft:blackstone
setblock 458 282 494 minecraft:blackstone
fill 459 282 475 459 282 476 minecraft:blackstone
fill 459 282 492 459 282 493 minecraft:blackstone
fill 460 282 476 460 282 478 minecraft:blackstone
setblock 460 282 479 minecraft:polished_blackstone_bricks
setblock 460 282 489 minecraft:polished_blackstone_bricks
fill 460 282 490 460 282 492 minecraft:blackstone
fill 461 282 479 461 282 489 minecraft:blackstone
fill 428 283 479 428 283 489 minecraft:blackstone
fill 429 283 477 429 283 481 minecraft:blackstone
fill 429 283 482 432 283 486 minecraft:polished_blackstone_bricks
fill 429 283 487 429 283 491 minecraft:blackstone
fill 430 283 475 430 283 478 minecraft:blackstone
fill 430 283 479 433 283 481 minecraft:polished_blackstone_bricks
fill 430 283 487 433 283 489 minecraft:polished_blackstone_bricks
fill 430 283 490 430 283 493 minecraft:blackstone
fill 431 283 474 431 283 476 minecraft:blackstone
fill 431 283 477 434 283 478 minecraft:polished_blackstone_bricks
fill 431 283 490 434 283 491 minecraft:polished_blackstone_bricks
fill 431 283 492 431 283 494 minecraft:blackstone
fill 432 283 473 432 283 474 minecraft:blackstone
fill 432 283 475 436 283 476 minecraft:polished_blackstone_bricks
fill 432 283 492 436 283 493 minecraft:polished_blackstone_bricks
fill 432 283 494 432 283 495 minecraft:blackstone
fill 433 283 472 433 283 473 minecraft:blackstone
fill 433 283 474 439 283 474 minecraft:polished_blackstone_bricks
fill 433 283 482 434 283 486 minecraft:cyan_concrete
fill 433 283 494 439 283 494 minecraft:polished_blackstone_bricks
fill 433 283 495 433 283 496 minecraft:blackstone
fill 434 283 471 434 283 472 minecraft:blackstone
fill 434 283 473 443 283 473 minecraft:polished_blackstone_bricks
fill 434 283 479 434 283 481 minecraft:cyan_concrete
fill 434 283 487 434 283 489 minecraft:cyan_concrete
fill 434 283 495 443 283 495 minecraft:polished_blackstone_bricks
fill 434 283 496 434 283 497 minecraft:blackstone
fill 435 283 470 436 283 471 minecraft:blackstone
fill 435 283 472 453 283 472 minecraft:polished_blackstone_bricks
setblock 435 283 477 minecraft:polished_blackstone_bricks
fill 435 283 478 435 283 480 minecraft:cyan_concrete
fill 435 283 488 435 283 490 minecraft:cyan_concrete
setblock 435 283 491 minecraft:polished_blackstone_bricks
fill 435 283 496 453 283 496 minecraft:polished_blackstone_bricks
fill 435 283 497 436 283 498 minecraft:blackstone
fill 436 283 477 436 283 478 minecraft:cyan_concrete
fill 436 283 490 436 283 491 minecraft:cyan_concrete
fill 437 283 469 438 283 470 minecraft:blackstone
fill 437 283 471 451 283 471 minecraft:polished_blackstone_bricks
setblock 437 283 475 minecraft:polished_blackstone_bricks
fill 437 283 476 437 283 477 minecraft:cyan_concrete
fill 437 283 491 437 283 492 minecraft:cyan_concrete
setblock 437 283 493 minecraft:polished_blackstone_bricks
fill 437 283 497 451 283 497 minecraft:polished_blackstone_bricks
fill 437 283 498 438 283 499 minecraft:blackstone
fill 438 283 475 439 283 476 minecraft:cyan_concrete
fill 438 283 492 439 283 493 minecraft:cyan_concrete
fill 439 283 468 441 283 469 minecraft:blackstone
fill 439 283 470 449 283 470 minecraft:polished_blackstone_bricks
fill 439 283 498 449 283 498 minecraft:polished_blackstone_bricks
fill 439 283 499 441 283 500 minecraft:blackstone
fill 440 283 474 442 283 475 minecraft:cyan_concrete
fill 440 283 493 442 283 494 minecraft:cyan_concrete
fill 442 283 468 449 283 468 minecraft:blackstone
fill 442 283 469 446 283 469 minecraft:polished_blackstone_bricks
fill 442 283 499 446 283 499 minecraft:polished_blackstone_bricks
fill 442 283 500 449 283 500 minecraft:blackstone
fill 443 283 474 448 283 474 minecraft:cyan_concrete
fill 443 283 494 448 283 494 minecraft:cyan_concrete
setblock 444 283 473 minecraft:cyan_concrete
setblock 444 283 495 minecraft:cyan_concrete
fill 445 283 473 454 283 473 minecraft:polished_blackstone_bricks
fill 445 283 475 450 283 475 minecraft:cyan_concrete
fill 445 283 493 450 283 493 minecraft:cyan_concrete
fill 445 283 495 454 283 495 minecraft:polished_blackstone_bricks
fill 447 283 469 451 283 469 minecraft:blackstone
fill 447 283 499 451 283 499 minecraft:blackstone
fill 448 283 476 451 283 476 minecraft:cyan_concrete
fill 448 283 492 451 283 492 minecraft:cyan_concrete
fill 449 283 474 455 283 474 minecraft:polished_blackstone_bricks
fill 449 283 494 455 283 494 minecraft:polished_blackstone_bricks
fill 450 283 470 453 283 470 minecraft:blackstone
fill 450 283 477 452 283 477 minecraft:cyan_concrete
fill 450 283 491 452 283 491 minecraft:cyan_concrete
fill 450 283 498 453 283 498 minecraft:blackstone
fill 451 283 475 456 283 475 minecraft:polished_blackstone_bricks
fill 451 283 478 453 283 479 minecraft:cyan_concrete
fill 451 283 489 453 283 490 minecraft:cyan_concrete
fill 451 283 493 456 283 493 minecraft:polished_blackstone_bricks
fill 452 283 471 454 283 471 minecraft:blackstone
fill 452 283 476 456 283 476 minecraft:polished_blackstone_bricks
fill 452 283 480 454 283 481 minecraft:cyan_concrete
fill 452 283 487 454 283 488 minecraft:cyan_concrete
fill 452 283 492 456 283 492 minecraft:polished_blackstone_bricks
fill 452 283 497 454 283 497 minecraft:blackstone
fill 453 283 477 457 283 477 minecraft:polished_blackstone_bricks
fill 453 283 482 454 283 486 minecraft:cyan_concrete
fill 453 283 491 457 283 491 minecraft:polished_blackstone_bricks
fill 454 283 472 455 283 472 minecraft:blackstone
fill 454 283 478 457 283 479 minecraft:polished_blackstone_bricks
fill 454 283 489 457 283 490 minecraft:polished_blackstone_bricks
fill 454 283 496 455 283 496 minecraft:blackstone
fill 455 283 473 456 283 473 minecraft:blackstone
fill 455 283 480 458 283 488 minecraft:polished_blackstone_bricks
fill 455 283 495 456 283 495 minecraft:blackstone
fill 456 283 474 457 283 474 minecraft:blackstone
fill 456 283 494 457 283 494 minecraft:blackstone
fill 457 283 475 458 283 476 minecraft:blackstone
fill 457 283 492 458 283 493 minecraft:blackstone
fill 458 283 477 459 283 478 minecraft:blackstone
setblock 458 283 479 minecraft:polished_blackstone_bricks
setblock 458 283 489 minecraft:polished_blackstone_bricks
fill 458 283 490 459 283 491 minecraft:blackstone
fill 459 283 479 460 283 481 minecraft:blackstone
fill 459 283 482 459 283 486 minecraft:polished_blackstone_bricks
fill 459 283 487 460 283 489 minecraft:blackstone
fill 460 283 482 460 283 486 minecraft:blackstone
fill 424 284 464 424 284 466 minecraft:blackstone
setblock 424 284 467 minecraft:polished_blackstone_bricks
fill 424 284 468 424 284 469 minecraft:blackstone
setblock 424 284 487 minecraft:polished_blackstone_bricks
fill 424 284 488 424 284 491 minecraft:blackstone
setblock 424 284 492 minecraft:polished_blackstone_bricks
fill 424 284 493 424 287 493 minecraft:blackstone
fill 424 284 503 424 284 504 minecraft:blackstone
fill 425 284 464 426 284 464 minecraft:blackstone
fill 425 284 504 426 284 504 minecraft:blackstone
setblock 427 284 464 minecraft:polished_blackstone_bricks
fill 427 284 465 430 284 465 minecraft:blackstone
setblock 427 284 504 minecraft:polished_blackstone_bricks
fill 428 284 464 431 284 464 minecraft:blackstone
setblock 428 284 503 minecraft:polished_blackstone_bricks
fill 428 284 504 431 284 504 minecraft:blackstone
fill 429 284 482 431 284 486 minecraft:blackstone
fill 429 284 503 432 284 503 minecraft:blackstone
fill 430 284 479 432 284 481 minecraft:blackstone
fill 430 284 487 432 284 489 minecraft:blackstone
setblock 431 284 465 minecraft:polished_blackstone_bricks
fill 431 284 477 433 284 478 minecraft:blackstone
fill 431 284 490 433 284 491 minecraft:blackstone
setblock 432 284 464 minecraft:polished_blackstone_bricks
fill 432 284 465 435 284 465 minecraft:blackstone
fill 432 284 475 435 284 476 minecraft:blackstone
fill 432 284 482 432 284 486 minecraft:cyan_concrete
fill 432 284 492 435 284 493 minecraft:blackstone
setblock 432 284 504 minecraft:polished_blackstone_bricks
fill 433 284 464 436 284 464 minecraft:blackstone
fill 433 284 474 437 284 474 minecraft:blackstone
fill 433 284 479 433 284 481 minecraft:cyan_concrete
fill 433 284 487 433 284 489 minecraft:cyan_concrete
fill 433 284 494 437 284 494 minecraft:blackstone
setblock 433 284 503 minecraft:polished_blackstone_bricks
fill 433 284 504 436 284 504 minecraft:blackstone
fill 434 284 473 439 284 473 minecraft:blackstone
setblock 434 284 477 minecraft:blackstone
setblock 434 284 478 minecraft:cyan_concrete
setblock 434 284 490 minecraft:cyan_concrete
setblock 434 284 491 minecraft:blackstone
fill 434 284 495 439 284 495 minecraft:blackstone
fill 434 284 503 435 284 503 minecraft:blackstone
fill 435 284 472 443 284 472 minecraft:blackstone
setblock 435 284 477 minecraft:cyan_concrete
setblock 435 284 491 minecraft:cyan_concrete
fill 435 284 496 443 284 496 minecraft:blackstone
setblock 436 284 465 minecraft:polished_blackstone_bricks
setblock 436 284 475 minecraft:blackstone
setblock 436 284 476 minecraft:cyan_concrete
setblock 436 284 492 minecraft:cyan_concrete
setblock 436 284 493 minecraft:blackstone
setblock 437 284 464 minecraft:polished_blackstone_bricks
fill 437 284 471 451 284 471 minecraft:blackstone
setblock 437 284 475 minecraft:cyan_concrete
setblock 437 284 493 minecraft:cyan_concrete
fill 437 284 497 451 284 497 minecraft:blackstone
setblock 437 284 504 minecraft:polished_blackstone_bricks
setblock 438 284 464 minecraft:blackstone
fill 438 284 474 439 284 474 minecraft:cyan_concrete
fill 438 284 494 439 284 494 minecraft:cyan_concrete
fill 439 284 470 449 284 470 minecraft:blackstone
fill 439 284 498 449 284 498 minecraft:blackstone
fill 440 284 473 443 284 473 minecraft:cyan_concrete
fill 440 284 495 443 284 495 minecraft:cyan_concrete
fill 442 284 469 446 284 469 minecraft:blackstone
fill 442 284 499 446 284 499 minecraft:blackstone
setblock 444 284 472 minecraft:cyan_concrete
setblock 444 284 496 minecraft:cyan_concrete
fill 445 284 472 453 284 472 minecraft:blackstone
fill 445 284 473 448 284 473 minecraft:cyan_concrete
fill 445 284 495 448 284 495 minecraft:cyan_concrete
fill 445 284 496 453 284 496 minecraft:blackstone
setblock 446 284 464 minecraft:blackstone
setblock 447 284 464 minecraft:polished_blackstone_bricks
fill 448 284 464 450 284 465 minecraft:blackstone
setblock 449 284 466 minecraft:blackstone
fill 449 284 473 454 284 473 minecraft:blackstone
fill 449 284 474 450 284 474 minecraft:cyan_concrete
fill 449 284 494 450 284 494 minecraft:cyan_concrete
fill 449 284 495 454 284 495 minecraft:blackstone
setblock 450 284 466 minecraft:polished_blackstone_bricks
fill 450 284 504 451 284 504 minecraft:blackstone
setblock 451 284 464 minecraft:blackstone
setblock 451 284 465 minecraft:polished_blackstone_bricks
fill 451 284 466 453 284 467 minecraft:blackstone
fill 451 284 474 455 284 474 minecraft:blackstone
setblock 451 284 475 minecraft:cyan_concrete
setblock 451 284 493 minecraft:cyan_concrete
fill 451 284 494 455 284 494 minecraft:blackstone
setblock 452 284 464 minecraft:polished_blackstone_bricks
fill 452 284 465 455 284 465 minecraft:blackstone
fill 452 284 475 456 284 475 minecraft:blackstone
setblock 452 284 476 minecraft:cyan_concrete
setblock 452 284 492 minecraft:cyan_concrete
fill 452 284 493 456 284 493 minecraft:blackstone
setblock 452 284 504 minecraft:polished_blackstone_bricks
fill 453 284 464 456 284 464 minecraft:blackstone
fill 453 284 476 456 284 476 minecraft:blackstone
setblock 453 284 477 minecraft:cyan_concrete
setblock 453 284 491 minecraft:cyan_concrete
fill 453 284 492 456 284 492 minecraft:blackstone
fill 453 284 504 456 284 504 minecraft:blackstone
setblock 454 284 466 minecraft:blackstone
setblock 454 284 467 minecraft:polished_blackstone_bricks
fill 454 284 477 457 284 477 minecraft:blackstone
fill 454 284 478 454 284 479 minecraft:cyan_concrete
fill 454 284 489 454 284 490 minecraft:cyan_concrete
fill 454 284 491 457 284 491 minecraft:blackstone
setblock 455 284 466 minecraft:polished_blackstone_bricks
fill 455 284 467 457 284 467 minecraft:blackstone
fill 455 284 478 457 284 479 minecraft:blackstone
fill 455 284 480 455 284 488 minecraft:cyan_concrete
fill 455 284 489 457 284 490 minecraft:blackstone
setblock 456 284 465 minecraft:polished_blackstone_bricks
fill 456 284 466 459 284 466 minecraft:blackstone
fill 456 284 480 458 284 483 minecraft:blackstone
setblock 456 284 484 minecraft:cyan_concrete
fill 456 284 485 458 284 488 minecraft:blackstone
setblock 457 284 464 minecraft:polished_blackstone_bricks
fill 457 284 465 460 284 465 minecraft:blackstone
fill 457 284 484 459 284 484 minecraft:blackstone
setblock 457 284 504 minecraft:polished_blackstone_bricks
fill 458 284 464 461 284 464 minecraft:blackstone
setblock 458 284 479 minecraft:blackstone
setblock 458 284 489 minecraft:blackstone
fill 458 284 504 460 284 504 minecraft:blackstone
fill 459 284 482 459 284 483 minecraft:blackstone
fill 459 284 485 459 284 486 minecraft:blackstone
setblock 460 284 466 minecraft:polished_blackstone_bricks
setblock 461 284 465 minecraft:polished_blackstone_bricks
setblock 462 284 464 minecraft:polished_blackstone_bricks
fill 462 284 465 464 285 465 minecraft:blackstone
fill 463 284 464 464 286 464 minecraft:blackstone
fill 463 284 466 463 284 467 minecraft:blackstone
setblock 463 284 468 minecraft:polished_blackstone_bricks
fill 463 284 469 464 284 469 minecraft:blackstone
setblock 464 284 466 minecraft:blackstone
setblock 464 284 467 minecraft:polished_blackstone_bricks
fill 464 284 468 464 287 468 minecraft:blackstone
fill 464 284 470 464 284 471 minecraft:blackstone
setblock 464 284 504 minecraft:blackstone
fill 424 285 464 424 285 465 minecraft:blackstone
setblock 424 285 466 minecraft:polished_blackstone_bricks
fill 424 285 467 424 286 468 minecraft:blackstone
fill 424 285 488 424 285 490 minecraft:blackstone
setblock 424 285 491 minecraft:polished_blackstone_bricks
fill 424 285 492 424 288 492 minecraft:blackstone
fill 424 285 494 424 286 494 minecraft:blackstone
fill 424 285 504 425 285 504 minecraft:blackstone
setblock 425 285 464 minecraft:blackstone
setblock 426 285 464 minecraft:polished_blackstone_bricks
setblock 426 285 504 minecraft:polished_blackstone_bricks
fill 427 285 464 430 285 464 minecraft:blackstone
fill 427 285 504 430 285 504 minecraft:blackstone
setblock 429 285 465 minecraft:blackstone
fill 429 285 503 431 285 503 minecraft:blackstone
setblock 430 285 465 minecraft:polished_blackstone_bricks
setblock 431 285 464 minecraft:polished_blackstone_bricks
fill 431 285 465 434 285 465 minecraft:blackstone
setblock 431 285 504 minecraft:polished_blackstone_bricks
fill 432 285 464 435 285 464 minecraft:blackstone
setblock 432 285 503 minecraft:polished_blackstone_bricks
fill 432 285 504 435 285 504 minecraft:blackstone
setblock 433 285 503 minecraft:blackstone
setblock 436 285 464 minecraft:polished_blackstone_bricks
setblock 436 285 504 minecraft:polished_blackstone_bricks
setblock 437 285 464 minecraft:blackstone
fill 447 285 464 450 285 464 minecraft:blackstone
fill 448 285 465 449 285 465 minecraft:blackstone
setblock 449 285 466 minecraft:polished_blackstone_bricks
setblock 450 285 465 minecraft:polished_blackstone_bricks
fill 450 285 466 453 285 466 minecraft:blackstone
setblock 451 285 464 minecraft:polished_blackstone_bricks
fill 451 285 465 454 285 465 minecraft:blackstone
setblock 451 285 504 minecraft:polished_blackstone_bricks
fill 452 285 464 455 285 464 minecraft:blackstone
setblock 452 285 467 minecraft:blackstone
fill 452 285 504 455 285 504 minecraft:blackstone
setblock 453 285 467 minecraft:polished_blackstone_bricks
setblock 454 285 466 minecraft:polished_blackstone_bricks
fill 454 285 467 456 285 467 minecraft:blackstone
setblock 455 285 465 minecraft:polished_blackstone_bricks
fill 455 285 466 458 285 466 minecraft:blackstone
setblock 456 285 464 minecraft:polished_blackstone_bricks
fill 456 285 465 459 285 465 minecraft:blackstone
setblock 456 285 504 minecraft:polished_blackstone_bricks
fill 457 285 464 460 285 464 minecraft:blackstone
setblock 457 285 504 minecraft:blackstone
setblock 459 285 466 minecraft:polished_blackstone_bricks
setblock 460 285 465 minecraft:polished_blackstone_bricks
setblock 461 285 464 minecraft:polished_blackstone_bricks
setblock 461 285 465 minecraft:blackstone
fill 462 285 464 462 288 464 minecraft:blackstone
setblock 463 285 466 minecraft:blackstone
setblock 463 285 467 minecraft:polished_blackstone_bricks
setblock 463 285 468 minecraft:blackstone
setblock 464 285 466 minecraft:polished_blackstone_bricks
fill 464 285 467 464 288 467 minecraft:blackstone
fill 464 285 469 464 285 470 minecraft:blackstone
setblock 464 285 471 minecraft:polished_blackstone_bricks
setblock 424 286 465 minecraft:polished_blackstone_bricks
setblock 424 286 466 minecraft:blackstone
fill 424 286 488 424 286 489 minecraft:blackstone
setblock 424 286 490 minecraft:polished_blackstone_bricks
fill 424 286 491 425 288 491 minecraft:blackstone
setblock 424 286 495 minecraft:polished_blackstone_bricks
setblock 425 286 464 minecraft:polished_blackstone_bricks
fill 425 286 492 425 287 492 minecraft:blackstone
fill 426 286 464 429 286 464 minecraft:blackstone
setblock 426 286 466 minecraft:light[level=11]
setblock 426 286 474 minecraft:light[level=11]
setblock 426 286 482 minecraft:light[level=11]
setblock 426 286 490 minecraft:light[level=11]
setblock 426 286 498 minecraft:light[level=11]
fill 426 286 504 429 286 504 minecraft:blackstone
setblock 430 286 464 minecraft:polished_blackstone_bricks
fill 430 286 465 432 286 465 minecraft:blackstone
setblock 430 286 504 minecraft:polished_blackstone_bricks
fill 431 286 464 434 286 464 minecraft:blackstone
fill 431 286 504 434 286 504 minecraft:blackstone
setblock 434 286 466 minecraft:light[level=11]
setblock 434 286 474 minecraft:light[level=11]
setblock 434 286 482 minecraft:light[level=11]
setblock 434 286 490 minecraft:light[level=11]
setblock 434 286 498 minecraft:light[level=11]
setblock 435 286 464 minecraft:polished_blackstone_bricks
setblock 442 286 466 minecraft:light[level=11]
setblock 442 286 474 minecraft:light[level=11]
setblock 442 286 482 minecraft:light[level=11]
setblock 442 286 490 minecraft:light[level=11]
setblock 442 286 498 minecraft:light[level=11]
fill 447 286 464 449 286 464 minecraft:blackstone
setblock 448 286 465 minecraft:blackstone
setblock 449 286 465 minecraft:polished_blackstone_bricks
setblock 450 286 464 minecraft:polished_blackstone_bricks
fill 450 286 465 452 286 466 minecraft:blackstone
setblock 450 286 474 minecraft:light[level=11]
setblock 450 286 482 minecraft:light[level=11]
setblock 450 286 490 minecraft:light[level=11]
setblock 450 286 498 minecraft:light[level=11]
fill 451 286 464 454 286 464 minecraft:blackstone
setblock 452 286 467 minecraft:polished_blackstone_bricks
setblock 453 286 465 minecraft:blackstone
setblock 453 286 466 minecraft:polished_blackstone_bricks
fill 453 286 467 454 286 467 minecraft:blackstone
fill 453 286 504 454 286 504 minecraft:blackstone
setblock 454 286 465 minecraft:polished_blackstone_bricks
fill 454 286 466 457 286 466 minecraft:blackstone
setblock 455 286 464 minecraft:polished_blackstone_bricks
fill 455 286 465 458 286 465 minecraft:blackstone
fill 456 286 464 459 286 464 minecraft:blackstone
setblock 458 286 466 minecraft:light[level=11]
setblock 458 286 474 minecraft:light[level=11]
setblock 458 286 482 minecraft:light[level=11]
setblock 458 286 490 minecraft:light[level=11]
setblock 458 286 498 minecraft:light[level=11]
setblock 459 286 465 minecraft:polished_blackstone_bricks
setblock 460 286 464 minecraft:polished_blackstone_bricks
setblock 460 286 465 minecraft:blackstone
fill 461 286 464 461 288 464 minecraft:blackstone
setblock 463 286 467 minecraft:blackstone
setblock 464 286 465 minecraft:polished_blackstone_bricks
fill 464 286 466 464 289 466 minecraft:blackstone
setblock 464 286 469 minecraft:blackstone
setblock 464 286 470 minecraft:polished_blackstone_bricks
fill 464 286 471 464 289 471 minecraft:blackstone
setblock 424 287 488 minecraft:blackstone
setblock 424 287 489 minecraft:polished_blackstone_bricks
fill 424 287 490 425 289 490 minecraft:blackstone
setblock 424 287 494 minecraft:polished_blackstone_bricks
fill 424 287 495 424 288 497 minecraft:blackstone
setblock 425 287 493 minecraft:polished_blackstone_bricks
fill 425 287 494 425 290 494 minecraft:blackstone
fill 426 287 504 428 287 504 minecraft:blackstone
fill 427 287 464 428 287 464 minecraft:blackstone
setblock 429 287 464 minecraft:polished_blackstone_bricks
setblock 429 287 504 minecraft:polished_blackstone_bricks
fill 430 287 464 433 287 464 minecraft:blackstone
fill 430 287 504 433 287 504 minecraft:blackstone
fill 447 287 464 448 287 464 minecraft:blackstone
setblock 448 287 465 minecraft:polished_blackstone_bricks
setblock 449 287 464 minecraft:polished_blackstone_bricks
fill 449 287 465 452 287 465 minecraft:blackstone
fill 450 287 464 453 287 464 minecraft:blackstone
fill 450 287 466 451 287 466 minecraft:blackstone
setblock 452 287 466 minecraft:polished_blackstone_bricks
setblock 453 287 465 minecraft:polished_blackstone_bricks
fill 453 287 466 456 287 466 minecraft:blackstone
setblock 454 287 464 minecraft:polished_blackstone_bricks
fill 454 287 465 457 287 465 minecraft:blackstone
fill 455 287 464 458 287 464 minecraft:blackstone
setblock 458 287 465 minecraft:polished_blackstone_bricks
setblock 459 287 464 minecraft:polished_blackstone_bricks
fill 460 287 464 460 288 464 minecraft:blackstone
setblock 463 287 464 minecraft:blackstone
setblock 464 287 464 minecraft:polished_blackstone_bricks
fill 464 287 465 464 290 465 minecraft:blackstone
setblock 464 287 469 minecraft:polished_blackstone_bricks
fill 464 287 470 464 290 470 minecraft:blackstone
setblock 424 288 488 minecraft:polished_blackstone_bricks
fill 424 288 489 425 290 489 minecraft:blackstone
setblock 424 288 493 minecraft:polished_blackstone_bricks
fill 424 288 494 424 291 494 minecraft:blackstone
setblock 424 288 498 minecraft:polished_blackstone_bricks
setblock 425 288 492 minecraft:polished_blackstone_bricks
fill 425 288 493 426 290 493 minecraft:blackstone
fill 425 288 495 425 288 496 minecraft:blackstone
fill 426 288 492 426 291 492 minecraft:blackstone
fill 426 288 504 427 288 504 minecraft:blackstone
setblock 427 288 464 minecraft:blackstone
setblock 428 288 464 minecraft:polished_blackstone_bricks
setblock 428 288 504 minecraft:polished_blackstone_bricks
fill 429 288 464 432 288 464 minecraft:blackstone
fill 429 288 504 432 288 504 minecraft:blackstone
setblock 447 288 464 minecraft:blackstone
setblock 448 288 464 minecraft:polished_blackstone_bricks
fill 448 288 465 451 288 465 minecraft:blackstone
fill 449 288 464 452 288 464 minecraft:blackstone
fill 449 288 466 450 288 466 minecraft:blackstone
setblock 451 288 466 minecraft:polished_blackstone_bricks
setblock 452 288 465 minecraft:polished_blackstone_bricks
fill 452 288 466 455 288 466 minecraft:blackstone
fill 452 288 497 456 289 501 minecraft:blackstone
setblock 453 288 464 minecraft:polished_blackstone_bricks
fill 453 288 465 456 288 465 minecraft:blackstone
fill 454 288 464 457 288 464 minecraft:blackstone
fill 454 288 502 454 288 503 minecraft:blackstone
setblock 457 288 465 minecraft:polished_blackstone_bricks
setblock 458 288 464 minecraft:polished_blackstone_bricks
fill 459 288 464 459 289 464 minecraft:blackstone
setblock 463 288 464 minecraft:polished_blackstone_bricks
fill 464 288 464 464 291 464 minecraft:blackstone
setblock 464 288 468 minecraft:polished_blackstone_bricks
fill 464 288 469 464 291 469 minecraft:blackstone
setblock 464 288 472 minecraft:blackstone
fill 424 289 469 424 290 470 minecraft:blackstone
fill 424 289 488 424 292 488 minecraft:blackstone
setblock 424 289 491 minecraft:blackstone
setblock 424 289 492 minecraft:polished_blackstone_bricks
fill 424 289 493 424 292 493 minecraft:blackstone
fill 424 289 495 424 289 496 minecraft:blackstone
setblock 424 289 497 minecraft:polished_blackstone_bricks
fill 424 289 498 424 290 500 minecraft:blackstone
setblock 425 289 491 minecraft:polished_blackstone_bricks
fill 425 289 492 425 292 492 minecraft:blackstone
setblock 425 289 495 minecraft:blackstone
setblock 425 289 496 minecraft:polished_blackstone_bricks
fill 425 289 497 425 291 498 minecraft:blackstone
setblock 426 289 490 minecraft:polished_blackstone_bricks
fill 426 289 491 426 292 491 minecraft:blackstone
setblock 426 289 494 minecraft:blackstone
setblock 426 289 495 minecraft:polished_blackstone_bricks
setblock 426 289 504 minecraft:blackstone
setblock 427 289 504 minecraft:polished_blackstone_bricks
fill 428 289 464 431 289 464 minecraft:blackstone
fill 428 289 504 431 289 504 minecraft:blackstone
setblock 447 289 464 minecraft:polished_blackstone_bricks
fill 448 289 464 450 289 465 minecraft:blackstone
setblock 449 289 466 minecraft:blackstone
setblock 450 289 466 minecraft:polished_blackstone_bricks
setblock 451 289 464 minecraft:blackstone
setblock 451 289 465 minecraft:polished_blackstone_bricks
fill 451 289 466 454 289 466 minecraft:blackstone
setblock 452 289 464 minecraft:polished_blackstone_bricks
fill 452 289 465 455 289 465 minecraft:blackstone
fill 453 289 464 456 289 464 minecraft:blackstone
setblock 456 289 465 minecraft:polished_blackstone_bricks
setblock 457 289 464 minecraft:polished_blackstone_bricks
fill 458 289 464 458 291 464 minecraft:blackstone
fill 463 289 464 463 292 464 minecraft:blackstone
setblock 464 289 467 minecraft:polished_blackstone_bricks
fill 464 289 468 464 292 468 minecraft:blackstone
setblock 464 289 472 minecraft:polished_blackstone_bricks
fill 464 289 473 464 292 473 minecraft:blackstone
setblock 464 289 491 minecraft:blackstone
setblock 464 289 492 minecraft:polished_blackstone_bricks
fill 464 289 493 464 289 496 minecraft:blackstone
fill 424 290 468 424 292 468 minecraft:blackstone
setblock 424 290 471 minecraft:polished_blackstone_bricks
fill 424 290 472 424 293 472 minecraft:blackstone
fill 424 290 487 424 293 487 minecraft:blackstone
setblock 424 290 490 minecraft:blackstone
setblock 424 290 491 minecraft:polished_blackstone_bricks
fill 424 290 492 424 293 492 minecraft:blackstone
setblock 424 290 495 minecraft:blackstone
setblock 424 290 496 minecraft:polished_blackstone_bricks
fill 424 290 497 424 293 497 minecraft:blackstone
setblock 424 290 501 minecraft:polished_blackstone_bricks
fill 424 290 502 424 293 502 minecraft:blackstone
fill 425 290 488 425 291 488 minecraft:blackstone
setblock 425 290 490 minecraft:polished_blackstone_bricks
fill 425 290 491 425 293 491 minecraft:blackstone
setblock 425 290 495 minecraft:polished_blackstone_bricks
fill 425 290 496 426 292 496 minecraft:blackstone
setblock 425 290 499 minecraft:blackstone
setblock 425 290 504 minecraft:blackstone
setblock 426 290 489 minecraft:polished_blackstone_bricks
fill 426 290 490 426 293 490 minecraft:blackstone
setblock 426 290 494 minecraft:polished_blackstone_bricks
fill 426 290 495 427 292 495 minecraft:blackstone
fill 426 290 497 426 291 497 minecraft:blackstone
setblock 426 290 504 minecraft:polished_blackstone_bricks
fill 427 290 491 427 290 492 minecraft:blackstone
setblock 427 290 493 minecraft:polished_blackstone_bricks
fill 427 290 494 427 293 494 minecraft:blackstone
fill 427 290 504 430 290 504 minecraft:blackstone
fill 428 290 464 430 290 464 minecraft:blackstone
setblock 431 290 504 minecraft:polished_blackstone_bricks
setblock 446 290 464 minecraft:polished_blackstone_bricks
fill 447 290 464 449 290 465 minecraft:blackstone
setblock 449 290 466 minecraft:polished_blackstone_bricks
setblock 450 290 464 minecraft:blackstone
setblock 450 290 465 minecraft:polished_blackstone_bricks
fill 450 290 466 453 290 466 minecraft:blackstone
setblock 451 290 464 minecraft:polished_blackstone_bricks
fill 451 290 465 454 290 465 minecraft:blackstone
fill 452 290 464 455 290 464 minecraft:blackstone
fill 453 290 499 455 294 499 minecraft:polished_blackstone_bricks
setblock 455 290 465 minecraft:polished_blackstone_bricks
setblock 456 290 464 minecraft:polished_blackstone_bricks
fill 457 290 464 457 293 464 minecraft:blackstone
setblock 464 290 466 minecraft:polished_blackstone_bricks
fill 464 290 467 464 293 467 minecraft:blackstone
setblock 464 290 471 minecraft:polished_blackstone_bricks
fill 464 290 472 464 293 472 minecraft:blackstone
fill 464 290 474 464 291 474 minecraft:blackstone
setblock 464 290 490 minecraft:blackstone
setblock 464 290 491 minecraft:polished_blackstone_bricks
fill 464 290 492 464 290 495 minecraft:blackstone
setblock 464 290 496 minecraft:polished_blackstone_bricks
fill 464 290 497 464 290 500 minecraft:blackstone
fill 424 291 467 424 293 467 minecraft:blackstone
setblock 424 291 469 minecraft:blackstone
setblock 424 291 470 minecraft:polished_blackstone_bricks
fill 424 291 471 424 294 471 minecraft:blackstone
fill 424 291 473 424 291 474 minecraft:blackstone
setblock 424 291 475 minecraft:polished_blackstone_bricks
fill 424 291 486 424 294 486 minecraft:blackstone
setblock 424 291 489 minecraft:blackstone
setblock 424 291 490 minecraft:polished_blackstone_bricks
fill 424 291 491 424 294 491 minecraft:blackstone
setblock 424 291 495 minecraft:polished_blackstone_bricks
fill 424 291 496 424 294 496 minecraft:blackstone
fill 424 291 498 424 291 499 minecraft:blackstone
setblock 424 291 500 minecraft:polished_blackstone_bricks
fill 424 291 501 425 293 501 minecraft:blackstone
fill 424 291 503 424 291 504 minecraft:blackstone
setblock 425 291 489 minecraft:polished_blackstone_bricks
fill 425 291 490 425 294 490 minecraft:blackstone
setblock 425 291 493 minecraft:blackstone
setblock 425 291 494 minecraft:polished_blackstone_bricks
fill 425 291 495 425 294 495 minecraft:blackstone
setblock 425 291 499 minecraft:polished_blackstone_bricks
fill 425 291 500 425 294 500 minecraft:blackstone
setblock 425 291 504 minecraft:polished_blackstone_bricks
fill 426 291 489 426 294 489 minecraft:blackstone
setblock 426 291 493 minecraft:polished_blackstone_bricks
fill 426 291 494 426 294 494 minecraft:blackstone
setblock 426 291 498 minecraft:polished_blackstone_bricks
fill 426 291 499 426 294 499 minecraft:blackstone
fill 426 291 504 429 291 504 minecraft:blackstone
fill 427 291 464 429 291 464 minecraft:blackstone
setblock 427 291 491 minecraft:blackstone
setblock 427 291 492 minecraft:polished_blackstone_bricks
fill 427 291 493 427 294 493 minecraft:blackstone
setblock 427 291 496 minecraft:blackstone
setblock 427 291 497 minecraft:polished_blackstone_bricks
setblock 430 291 504 minecraft:polished_blackstone_bricks
fill 431 291 504 431 294 504 minecraft:blackstone
setblock 445 291 464 minecraft:polished_blackstone_bricks
fill 446 291 464 449 291 464 minecraft:blackstone
fill 447 291 465 448 291 465 minecraft:blackstone
setblock 448 291 466 minecraft:polished_blackstone_bricks
setblock 449 291 465 minecraft:polished_blackstone_bricks
fill 449 291 466 452 291 466 minecraft:blackstone
setblock 450 291 464 minecraft:polished_blackstone_bricks
fill 450 291 465 453 291 465 minecraft:blackstone
setblock 450 291 504 minecraft:polished_blackstone_bricks
fill 451 291 464 454 291 464 minecraft:blackstone
fill 451 291 504 451 294 504 minecraft:blackstone
setblock 454 291 465 minecraft:polished_blackstone_bricks
setblock 455 291 464 minecraft:polished_blackstone_bricks
setblock 455 291 465 minecraft:blackstone
fill 456 291 464 456 294 464 minecraft:blackstone
fill 462 291 464 462 293 464 minecraft:blackstone
fill 463 291 469 463 291 470 minecraft:blackstone
setblock 463 291 471 minecraft:polished_blackstone_bricks
fill 463 291 494 463 291 495 minecraft:blackstone
setblock 463 291 496 minecraft:polished_blackstone_bricks
setblock 464 291 465 minecraft:polished_blackstone_bricks
fill 464 291 466 464 294 466 minecraft:blackstone
setblock 464 291 470 minecraft:polished_blackstone_bricks
fill 464 291 471 464 294 471 minecraft:blackstone
setblock 464 291 475 minecraft:polished_blackstone_bricks
setblock 464 291 489 minecraft:blackstone
setblock 464 291 490 minecraft:polished_blackstone_bricks
fill 464 291 491 464 291 494 minecraft:blackstone
setblock 464 291 495 minecraft:polished_blackstone_bricks
fill 464 291 496 464 291 499 minecraft:blackstone
setblock 464 291 500 minecraft:polished_blackstone_bricks
fill 464 291 501 464 291 504 minecraft:blackstone
setblock 424 292 469 minecraft:polished_blackstone_bricks
fill 424 292 470 425 294 470 minecraft:blackstone
setblock 424 292 473 minecraft:blackstone
setblock 424 292 474 minecraft:polished_blackstone_bricks
fill 424 292 475 424 292 478 minecraft:blackstone
fill 424 292 485 424 295 485 minecraft:blackstone
setblock 424 292 489 minecraft:polished_blackstone_bricks
fill 424 292 490 424 295 490 minecraft:blackstone
setblock 424 292 494 minecraft:polished_blackstone_bricks
fill 424 292 495 424 295 495 minecraft:blackstone
setblock 424 292 498 minecraft:blackstone
setblock 424 292 499 minecraft:polished_blackstone_bricks
fill 424 292 500 424 295 500 minecraft:blackstone
setblock 424 292 503 minecraft:blackstone
setblock 424 292 504 minecraft:polished_blackstone_bricks
fill 425 292 471 425 292 472 minecraft:blackstone
setblock 425 292 473 minecraft:polished_blackstone_bricks
fill 425 292 474 425 294 475 minecraft:blackstone
setblock 425 292 487 minecraft:blackstone
setblock 425 292 488 minecraft:polished_blackstone_bricks
fill 425 292 489 425 295 489 minecraft:blackstone
setblock 425 292 493 minecraft:polished_blackstone_bricks
fill 425 292 494 425 295 494 minecraft:blackstone
setblock 425 292 497 minecraft:blackstone
setblock 425 292 498 minecraft:polished_blackstone_bricks
fill 425 292 499 425 295 499 minecraft:blackstone
setblock 425 292 502 minecraft:blackstone
setblock 425 292 503 minecraft:polished_blackstone_bricks
fill 425 292 504 428 292 504 minecraft:blackstone
fill 426 292 464 428 292 464 minecraft:blackstone
fill 426 292 488 426 295 488 minecraft:blackstone
setblock 426 292 492 minecraft:polished_blackstone_bricks
fill 426 292 493 426 295 493 minecraft:blackstone
setblock 426 292 497 minecraft:polished_blackstone_bricks
fill 426 292 498 427 294 498 minecraft:blackstone
fill 426 292 500 426 293 500 minecraft:blackstone
fill 426 292 503 429 292 503 minecraft:blackstone
setblock 427 292 490 minecraft:blackstone
setblock 427 292 491 minecraft:polished_blackstone_bricks
fill 427 292 492 427 295 492 minecraft:blackstone
setblock 427 292 496 minecraft:polished_blackstone_bricks
fill 427 292 497 427 295 497 minecraft:blackstone
fill 428 292 493 428 292 494 minecraft:blackstone
setblock 428 292 495 minecraft:polished_blackstone_bricks
setblock 429 292 464 minecraft:polished_blackstone_bricks
setblock 429 292 504 minecraft:polished_blackstone_bricks
fill 430 292 504 430 295 504 minecraft:blackstone
fill 443 292 468 443 293 468 minecraft:light_blue_stained_glass
fill 445 292 464 448 292 464 minecraft:blackstone
fill 446 292 465 447 292 465 minecraft:blackstone
setblock 448 292 465 minecraft:polished_blackstone_bricks
fill 448 292 466 451 292 466 minecraft:blackstone
setblock 448 292 504 minecraft:blackstone
setblock 449 292 464 minecraft:polished_blackstone_bricks
fill 449 292 465 452 292 465 minecraft:blackstone
setblock 449 292 504 minecraft:polished_blackstone_bricks
fill 450 292 464 453 292 464 minecraft:blackstone
fill 450 292 504 450 295 504 minecraft:blackstone
setblock 452 292 466 minecraft:polished_blackstone_bricks
fill 452 292 504 452 293 504 minecraft:blackstone
setblock 453 292 465 minecraft:polished_blackstone_bricks
setblock 454 292 464 minecraft:polished_blackstone_bricks
fill 454 292 465 454 293 465 minecraft:blackstone
fill 455 292 464 455 295 464 minecraft:blackstone
fill 461 292 464 461 294 464 minecraft:blackstone
fill 462 292 504 463 292 504 minecraft:blackstone
fill 463 292 468 463 292 469 minecraft:blackstone
setblock 463 292 470 minecraft:polished_blackstone_bricks
fill 463 292 471 463 293 473 minecraft:blackstone
fill 463 292 492 463 292 494 minecraft:blackstone
setblock 463 292 495 minecraft:polished_blackstone_bricks
fill 463 292 496 463 292 499 minecraft:blackstone
setblock 463 292 500 minecraft:polished_blackstone_bricks
setblock 464 292 464 minecraft:polished_blackstone_bricks
fill 464 292 465 464 295 465 minecraft:blackstone
setblock 464 292 469 minecraft:polished_blackstone_bricks
fill 464 292 470 464 295 470 minecraft:blackstone
setblock 464 292 474 minecraft:polished_blackstone_bricks
fill 464 292 475 464 293 477 minecraft:blackstone
setblock 464 292 489 minecraft:polished_blackstone_bricks
fill 464 292 490 464 292 493 minecraft:blackstone
setblock 464 292 494 minecraft:polished_blackstone_bricks
fill 464 292 495 464 292 498 minecraft:blackstone
setblock 464 292 499 minecraft:polished_blackstone_bricks
fill 464 292 500 464 292 503 minecraft:blackstone
setblock 464 292 504 minecraft:polished_blackstone_bricks
fill 424 293 466 424 294 466 minecraft:blackstone
setblock 424 293 468 minecraft:polished_blackstone_bricks
fill 424 293 469 425 294 469 minecraft:blackstone
setblock 424 293 473 minecraft:polished_blackstone_bricks
fill 424 293 474 424 293 477 minecraft:blackstone
setblock 424 293 478 minecraft:polished_blackstone_bricks
fill 424 293 479 424 293 482 minecraft:blackstone
setblock 424 293 483 minecraft:polished_blackstone_bricks
fill 424 293 484 424 296 484 minecraft:blackstone
setblock 424 293 488 minecraft:polished_blackstone_bricks
fill 424 293 489 424 296 489 minecraft:blackstone
setblock 424 293 493 minecraft:polished_blackstone_bricks
fill 424 293 494 424 296 494 minecraft:blackstone
setblock 424 293 498 minecraft:polished_blackstone_bricks
fill 424 293 499 424 296 499 minecraft:blackstone
setblock 424 293 503 minecraft:polished_blackstone_bricks
fill 424 293 504 427 293 504 minecraft:blackstone
fill 425 293 464 427 293 464 minecraft:blackstone
setblock 425 293 471 minecraft:blackstone
setblock 425 293 472 minecraft:polished_blackstone_bricks
fill 425 293 473 425 296 473 minecraft:blackstone
setblock 425 293 476 minecraft:blackstone
setblock 425 293 477 minecraft:polished_blackstone_bricks
fill 425 293 478 425 296 478 minecraft:blackstone
setblock 425 293 486 minecraft:blackstone
setblock 425 293 487 minecraft:polished_blackstone_bricks
fill 425 293 488 425 296 488 minecraft:blackstone
setblock 425 293 492 minecraft:polished_blackstone_bricks
fill 425 293 493 425 296 493 minecraft:blackstone
setblock 425 293 496 minecraft:blackstone
setblock 425 293 497 minecraft:polished_blackstone_bricks
fill 425 293 498 425 296 498 minecraft:blackstone
setblock 425 293 502 minecraft:polished_blackstone_bricks
fill 425 293 503 428 293 503 minecraft:blackstone
setblock 426 293 491 minecraft:polished_blackstone_bricks
fill 426 293 492 426 296 492 minecraft:blackstone
setblock 426 293 495 minecraft:blackstone
setblock 426 293 496 minecraft:polished_blackstone_bricks
fill 426 293 497 426 296 497 minecraft:blackstone
setblock 426 293 501 minecraft:polished_blackstone_bricks
setblock 427 293 490 minecraft:polished_blackstone_bricks
fill 427 293 491 427 296 491 minecraft:blackstone
setblock 427 293 495 minecraft:polished_blackstone_bricks
fill 427 293 496 428 295 496 minecraft:blackstone
setblock 427 293 499 minecraft:blackstone
setblock 428 293 464 minecraft:polished_blackstone_bricks
setblock 428 293 493 minecraft:blackstone
setblock 428 293 494 minecraft:polished_blackstone_bricks
fill 428 293 495 428 295 495 minecraft:blackstone
setblock 428 293 504 minecraft:polished_blackstone_bricks
setblock 429 293 464 minecraft:blackstone
setblock 429 293 503 minecraft:polished_blackstone_bricks
fill 429 293 504 429 296 504 minecraft:blackstone
fill 444 293 464 447 293 464 minecraft:blackstone
fill 445 293 465 446 293 465 minecraft:blackstone
fill 446 293 504 447 293 504 minecraft:blackstone
setblock 447 293 465 minecraft:polished_blackstone_bricks
fill 447 293 466 450 293 466 minecraft:blackstone
setblock 448 293 464 minecraft:polished_blackstone_bricks
fill 448 293 465 451 293 465 minecraft:blackstone
setblock 448 293 504 minecraft:polished_blackstone_bricks
fill 449 293 464 452 293 464 minecraft:blackstone
fill 449 293 504 449 296 504 minecraft:blackstone
setblock 451 293 466 minecraft:polished_blackstone_bricks
setblock 452 293 465 minecraft:polished_blackstone_bricks
setblock 453 293 464 minecraft:polished_blackstone_bricks
fill 453 293 465 453 294 465 minecraft:blackstone
setblock 453 293 504 minecraft:polished_blackstone_bricks
fill 454 293 464 454 296 464 minecraft:blackstone
fill 454 293 498 454 294 498 minecraft:polished_blackstone_bricks
fill 454 293 500 454 294 500 minecraft:polished_blackstone_bricks
setblock 458 293 464 minecraft:polished_blackstone_bricks
fill 460 293 464 460 295 464 minecraft:blackstone
fill 461 293 504 462 293 504 minecraft:blackstone
setblock 463 293 464 minecraft:polished_blackstone_bricks
setblock 463 293 468 minecraft:blackstone
setblock 463 293 469 minecraft:polished_blackstone_bricks
fill 463 293 470 463 296 470 minecraft:blackstone
setblock 463 293 474 minecraft:polished_blackstone_bricks
fill 463 293 475 463 296 475 minecraft:blackstone
fill 463 293 492 463 293 493 minecraft:blackstone
setblock 463 293 494 minecraft:polished_blackstone_bricks
fill 463 293 495 463 293 498 minecraft:blackstone
setblock 463 293 499 minecraft:polished_blackstone_bricks
fill 463 293 500 463 293 503 minecraft:blackstone
setblock 463 293 504 minecraft:polished_blackstone_bricks
fill 464 293 464 464 296 464 minecraft:blackstone
setblock 464 293 468 minecraft:polished_blackstone_bricks
fill 464 293 469 464 296 469 minecraft:blackstone
setblock 464 293 473 minecraft:polished_blackstone_bricks
fill 464 293 474 464 296 474 minecraft:blackstone
setblock 464 293 478 minecraft:polished_blackstone_bricks
setblock 464 293 488 minecraft:polished_blackstone_bricks
fill 464 293 489 464 293 492 minecraft:blackstone
setblock 464 293 493 minecraft:polished_blackstone_bricks
fill 464 293 494 464 293 497 minecraft:blackstone
setblock 464 293 498 minecraft:polished_blackstone_bricks
fill 464 293 499 464 293 502 minecraft:blackstone
setblock 464 293 503 minecraft:polished_blackstone_bricks
fill 464 293 504 464 296 504 minecraft:blackstone
fill 424 294 465 424 295 465 minecraft:blackstone
setblock 424 294 467 minecraft:polished_blackstone_bricks
fill 424 294 468 424 297 468 minecraft:blackstone
setblock 424 294 472 minecraft:polished_blackstone_bricks
fill 424 294 473 424 294 476 minecraft:blackstone
setblock 424 294 477 minecraft:polished_blackstone_bricks
fill 424 294 478 424 294 481 minecraft:blackstone
setblock 424 294 482 minecraft:polished_blackstone_bricks
fill 424 294 483 425 296 483 minecraft:blackstone
setblock 424 294 487 minecraft:polished_blackstone_bricks
fill 424 294 488 424 297 488 minecraft:blackstone
setblock 424 294 492 minecraft:polished_blackstone_bricks
fill 424 294 493 424 297 493 minecraft:blackstone
setblock 424 294 497 minecraft:polished_blackstone_bricks
fill 424 294 498 424 297 498 minecraft:blackstone
setblock 424 294 501 minecraft:blackstone
setblock 424 294 502 minecraft:polished_blackstone_bricks
fill 424 294 503 426 294 504 minecraft:blackstone
fill 425 294 464 426 294 464 minecraft:blackstone
setblock 425 294 471 minecraft:polished_blackstone_bricks
fill 425 294 472 426 295 472 minecraft:blackstone
setblock 425 294 476 minecraft:polished_blackstone_bricks
fill 425 294 477 426 296 477 minecraft:blackstone
fill 425 294 479 425 294 480 minecraft:blackstone
setblock 425 294 481 minecraft:polished_blackstone_bricks
fill 425 294 482 425 297 482 minecraft:blackstone
fill 425 294 484 425 294 485 minecraft:blackstone
setblock 425 294 486 minecraft:polished_blackstone_bricks
fill 425 294 487 425 297 487 minecraft:blackstone
setblock 425 294 491 minecraft:polished_blackstone_bricks
fill 425 294 492 425 297 492 minecraft:blackstone
setblock 425 294 496 minecraft:polished_blackstone_bricks
fill 425 294 497 425 297 497 minecraft:blackstone
setblock 425 294 501 minecraft:polished_blackstone_bricks
fill 425 294 502 428 294 502 minecraft:blackstone
setblock 426 294 466 minecraft:light[level=11]
fill 426 294 473 426 294 474 minecraft:blackstone
setblock 426 294 475 minecraft:polished_blackstone_bricks
fill 426 294 476 426 297 476 minecraft:blackstone
fill 426 294 478 426 295 478 minecraft:blackstone
setblock 426 294 482 minecraft:light[level=11]
setblock 426 294 490 minecraft:polished_blackstone_bricks
fill 426 294 491 426 297 491 minecraft:blackstone
setblock 426 294 495 minecraft:polished_blackstone_bricks
fill 426 294 496 426 297 496 minecraft:blackstone
setblock 426 294 500 minecraft:polished_blackstone_bricks
fill 426 294 501 426 297 501 minecraft:blackstone
setblock 427 294 464 minecraft:polished_blackstone_bricks
fill 427 294 490 427 295 490 minecraft:blackstone
setblock 427 294 494 minecraft:polished_blackstone_bricks
fill 427 294 495 427 297 495 minecraft:blackstone
setblock 427 294 499 minecraft:polished_blackstone_bricks
fill 427 294 500 427 297 500 minecraft:blackstone
setblock 427 294 503 minecraft:blackstone
setblock 427 294 504 minecraft:polished_blackstone_bricks
fill 428 294 464 428 295 464 minecraft:blackstone
setblock 428 294 493 minecraft:polished_blackstone_bricks
fill 428 294 494 428 295 494 minecraft:blackstone
setblock 428 294 497 minecraft:blackstone
setblock 428 294 503 minecraft:polished_blackstone_bricks
fill 428 294 504 428 297 504 minecraft:blackstone
fill 429 294 503 430 295 503 minecraft:blackstone
setblock 434 294 466 minecraft:light[level=11]
setblock 434 294 474 minecraft:light[level=11]
setblock 434 294 482 minecraft:light[level=11]
setblock 434 294 490 minecraft:light[level=11]
setblock 434 294 498 minecraft:light[level=11]
setblock 442 294 466 minecraft:light[level=11]
setblock 442 294 474 minecraft:light[level=11]
setblock 442 294 482 minecraft:light[level=11]
setblock 442 294 490 minecraft:light[level=11]
setblock 442 294 498 minecraft:light[level=11]
fill 443 294 464 446 294 464 minecraft:blackstone
fill 444 294 475 445 295 475 minecraft:light_blue_stained_glass
setblock 445 294 465 minecraft:blackstone
fill 445 294 504 446 294 504 minecraft:blackstone
setblock 446 294 465 minecraft:polished_blackstone_bricks
setblock 447 294 464 minecraft:polished_blackstone_bricks
fill 447 294 465 449 294 466 minecraft:blackstone
setblock 447 294 504 minecraft:polished_blackstone_bricks
fill 448 294 464 451 294 464 minecraft:blackstone
fill 448 294 504 448 297 504 minecraft:blackstone
setblock 450 294 465 minecraft:blackstone
setblock 450 294 466 minecraft:polished_blackstone_bricks
setblock 450 294 474 minecraft:light[level=11]
setblock 450 294 482 minecraft:light[level=11]
setblock 450 294 490 minecraft:light[level=11]
setblock 450 294 498 minecraft:light[level=11]
setblock 451 294 465 minecraft:polished_blackstone_bricks
setblock 451 294 466 minecraft:blackstone
setblock 452 294 464 minecraft:polished_blackstone_bricks
fill 452 294 465 452 295 465 minecraft:blackstone
setblock 452 294 504 minecraft:polished_blackstone_bricks
fill 453 294 464 453 297 464 minecraft:blackstone
fill 453 294 504 454 296 504 minecraft:blackstone
setblock 457 294 464 minecraft:polished_blackstone_bricks
fill 458 294 464 459 294 464 minecraft:blackstone
setblock 458 294 466 minecraft:light[level=11]
setblock 458 294 474 minecraft:light[level=11]
setblock 458 294 482 minecraft:light[level=11]
setblock 458 294 490 minecraft:light[level=11]
setblock 458 294 498 minecraft:light[level=11]
fill 459 294 504 461 294 504 minecraft:blackstone
setblock 462 294 464 minecraft:polished_blackstone_bricks
fill 462 294 495 462 294 498 minecraft:blackstone
setblock 462 294 499 minecraft:polished_blackstone_bricks
setblock 462 294 503 minecraft:blackstone
setblock 462 294 504 minecraft:polished_blackstone_bricks
fill 463 294 464 463 297 464 minecraft:blackstone
setblock 463 294 468 minecraft:polished_blackstone_bricks
fill 463 294 469 463 295 469 minecraft:blackstone
fill 463 294 471 463 294 472 minecraft:blackstone
setblock 463 294 473 minecraft:polished_blackstone_bricks
fill 463 294 474 463 297 474 minecraft:blackstone
fill 463 294 476 464 294 476 minecraft:blackstone
fill 463 294 491 463 294 492 minecraft:blackstone
setblock 463 294 493 minecraft:polished_blackstone_bricks
fill 463 294 494 463 294 497 minecraft:blackstone
setblock 463 294 498 minecraft:polished_blackstone_bricks
fill 463 294 499 463 294 502 minecraft:blackstone
setblock 463 294 503 minecraft:polished_blackstone_bricks
fill 463 294 504 463 297 504 minecraft:blackstone
setblock 464 294 467 minecraft:polished_blackstone_bricks
fill 464 294 468 464 297 468 minecraft:blackstone
setblock 464 294 472 minecraft:polished_blackstone_bricks
fill 464 294 473 464 297 473 minecraft:blackstone
fill 464 294 475 464 295 475 minecraft:blackstone
setblock 464 294 477 minecraft:polished_blackstone_bricks
fill 464 294 478 464 295 480 minecraft:blackstone
fill 464 294 488 464 294 491 minecraft:blackstone
setblock 464 294 492 minecraft:polished_blackstone_bricks
fill 464 294 493 464 294 496 minecraft:blackstone
setblock 464 294 497 minecraft:polished_blackstone_bricks
fill 464 294 498 464 294 501 minecraft:blackstone
setblock 464 294 502 minecraft:polished_blackstone_bricks
fill 464 294 503 464 297 503 minecraft:blackstone
fill 424 295 464 425 295 464 minecraft:blackstone
setblock 424 295 466 minecraft:polished_blackstone_bricks
fill 424 295 467 424 296 467 minecraft:blackstone
fill 424 295 469 424 295 470 minecraft:blackstone
setblock 424 295 471 minecraft:polished_blackstone_bricks
fill 424 295 472 424 295 475 minecraft:blackstone
setblock 424 295 476 minecraft:polished_blackstone_bricks
fill 424 295 477 424 295 480 minecraft:blackstone
setblock 424 295 481 minecraft:polished_blackstone_bricks
fill 424 295 482 424 298 482 minecraft:blackstone
setblock 424 295 486 minecraft:polished_blackstone_bricks
fill 424 295 487 424 298 487 minecraft:blackstone
setblock 424 295 491 minecraft:polished_blackstone_bricks
fill 424 295 492 424 298 492 minecraft:blackstone
setblock 424 295 496 minecraft:polished_blackstone_bricks
fill 424 295 497 424 298 497 minecraft:blackstone
setblock 424 295 501 minecraft:polished_blackstone_bricks
fill 424 295 502 425 295 504 minecraft:blackstone
setblock 425 295 470 minecraft:polished_blackstone_bricks
fill 425 295 471 425 297 471 minecraft:blackstone
setblock 425 295 474 minecraft:blackstone
setblock 425 295 475 minecraft:polished_blackstone_bricks
fill 425 295 476 425 298 476 minecraft:blackstone
setblock 425 295 479 minecraft:blackstone
setblock 425 295 480 minecraft:polished_blackstone_bricks
fill 425 295 481 425 298 481 minecraft:blackstone
setblock 425 295 484 minecraft:blackstone
setblock 425 295 485 minecraft:polished_blackstone_bricks
fill 425 295 486 425 298 486 minecraft:blackstone
setblock 425 295 490 minecraft:polished_blackstone_bricks
fill 425 295 491 425 298 491 minecraft:blackstone
setblock 425 295 495 minecraft:polished_blackstone_bricks
fill 425 295 496 425 298 496 minecraft:blackstone
setblock 425 295 500 minecraft:polished_blackstone_bricks
fill 425 295 501 425 298 501 minecraft:blackstone
setblock 426 295 464 minecraft:polished_blackstone_bricks
setblock 426 295 473 minecraft:blackstone
setblock 426 295 474 minecraft:polished_blackstone_bricks
fill 426 295 475 426 298 475 minecraft:blackstone
setblock 426 295 479 minecraft:polished_blackstone_bricks
fill 426 295 480 426 298 480 minecraft:blackstone
setblock 426 295 487 minecraft:blackstone
setblock 426 295 489 minecraft:polished_blackstone_bricks
fill 426 295 490 426 298 490 minecraft:blackstone
setblock 426 295 494 minecraft:polished_blackstone_bricks
fill 426 295 495 426 298 495 minecraft:blackstone
setblock 426 295 498 minecraft:blackstone
setblock 426 295 499 minecraft:polished_blackstone_bricks
fill 426 295 500 426 298 500 minecraft:blackstone
fill 426 295 502 426 295 503 minecraft:blackstone
setblock 426 295 504 minecraft:polished_blackstone_bricks
fill 427 295 464 427 296 464 minecraft:blackstone
setblock 427 295 493 minecraft:polished_blackstone_bricks
fill 427 295 494 427 297 494 minecraft:blackstone
setblock 427 295 498 minecraft:polished_blackstone_bricks
fill 427 295 499 427 298 499 minecraft:blackstone
setblock 427 295 502 minecraft:blackstone
setblock 427 295 503 minecraft:polished_blackstone_bricks
fill 427 295 504 427 298 504 minecraft:blackstone
setblock 428 295 497 minecraft:polished_blackstone_bricks
setblock 428 295 502 minecraft:polished_blackstone_bricks
fill 428 295 503 428 298 503 minecraft:blackstone
setblock 431 295 504 minecraft:polished_blackstone_bricks
fill 443 295 464 445 295 464 minecraft:blackstone
setblock 444 295 465 minecraft:blackstone
fill 444 295 504 445 295 504 minecraft:blackstone
setblock 445 295 465 minecraft:polished_blackstone_bricks
setblock 446 295 464 minecraft:polished_blackstone_bricks
fill 446 295 465 448 295 466 minecraft:blackstone
setblock 446 295 504 minecraft:polished_blackstone_bricks
fill 447 295 464 450 295 464 minecraft:blackstone
setblock 447 295 503 minecraft:polished_blackstone_bricks
fill 447 295 504 447 298 504 minecraft:blackstone
fill 448 295 503 450 296 503 minecraft:blackstone
setblock 449 295 465 minecraft:blackstone
setblock 449 295 466 minecraft:polished_blackstone_bricks
setblock 450 295 465 minecraft:polished_blackstone_bricks
setblock 451 295 464 minecraft:polished_blackstone_bricks
fill 451 295 465 451 296 465 minecraft:blackstone
setblock 451 295 504 minecraft:polished_blackstone_bricks
fill 452 295 464 452 298 464 minecraft:blackstone
fill 452 295 504 452 298 504 minecraft:blackstone
setblock 455 295 504 minecraft:blackstone
setblock 456 295 464 minecraft:polished_blackstone_bricks
setblock 456 295 504 minecraft:polished_blackstone_bricks
setblock 457 295 464 minecraft:blackstone
fill 457 295 504 460 295 504 minecraft:blackstone
fill 459 295 464 459 296 464 minecraft:blackstone
setblock 461 295 464 minecraft:polished_blackstone_bricks
setblock 461 295 503 minecraft:blackstone
setblock 461 295 504 minecraft:polished_blackstone_bricks
fill 462 295 464 462 298 464 minecraft:blackstone
fill 462 295 494 462 295 497 minecraft:blackstone
setblock 462 295 498 minecraft:polished_blackstone_bricks
fill 462 295 499 463 295 501 minecraft:blackstone
setblock 462 295 503 minecraft:polished_blackstone_bricks
fill 462 295 504 462 298 504 minecraft:blackstone
setblock 463 295 468 minecraft:blackstone
setblock 463 295 471 minecraft:blackstone
setblock 463 295 472 minecraft:polished_blackstone_bricks
fill 463 295 473 463 298 473 minecraft:blackstone
setblock 463 295 476 minecraft:blackstone
setblock 463 295 477 minecraft:polished_blackstone_bricks
setblock 463 295 491 minecraft:blackstone
setblock 463 295 492 minecraft:polished_blackstone_bricks
fill 463 295 493 463 295 496 minecraft:blackstone
setblock 463 295 497 minecraft:polished_blackstone_bricks
fill 463 295 498 464 297 498 minecraft:blackstone
setblock 463 295 502 minecraft:polished_blackstone_bricks
fill 463 295 503 463 298 503 minecraft:blackstone
setblock 464 295 466 minecraft:polished_blackstone_bricks
fill 464 295 467 464 298 467 minecraft:blackstone
setblock 464 295 471 minecraft:polished_blackstone_bricks
fill 464 295 472 464 298 472 minecraft:blackstone
setblock 464 295 476 minecraft:polished_blackstone_bricks
fill 464 295 477 464 298 477 minecraft:blackstone
setblock 464 295 481 minecraft:polished_blackstone_bricks
fill 464 295 482 464 298 482 minecraft:blackstone
fill 464 295 487 464 295 490 minecraft:blackstone
setblock 464 295 491 minecraft:polished_blackstone_bricks
fill 464 295 492 464 295 495 minecraft:blackstone
setblock 464 295 496 minecraft:polished_blackstone_bricks
fill 464 295 497 464 298 497 minecraft:blackstone
fill 464 295 499 464 295 500 minecraft:blackstone
setblock 464 295 501 minecraft:polished_blackstone_bricks
fill 464 295 502 464 298 502 minecraft:blackstone
setblock 424 296 464 minecraft:blackstone
setblock 424 296 469 minecraft:blackstone
setblock 424 296 470 minecraft:polished_blackstone_bricks
fill 424 296 471 424 296 474 minecraft:blackstone
setblock 424 296 475 minecraft:polished_blackstone_bricks
fill 424 296 476 424 296 479 minecraft:blackstone
setblock 424 296 480 minecraft:polished_blackstone_bricks
fill 424 296 481 424 299 481 minecraft:blackstone
setblock 424 296 485 minecraft:polished_blackstone_bricks
fill 424 296 486 424 299 486 minecraft:blackstone
setblock 424 296 490 minecraft:polished_blackstone_bricks
fill 424 296 491 424 299 491 minecraft:blackstone
setblock 424 296 495 minecraft:polished_blackstone_bricks
fill 424 296 496 424 299 496 minecraft:blackstone
setblock 424 296 500 minecraft:polished_blackstone_bricks
fill 424 296 501 424 296 504 minecraft:blackstone
setblock 425 296 464 minecraft:polished_blackstone_bricks
setblock 425 296 470 minecraft:blackstone
fill 425 296 472 425 297 472 minecraft:blackstone
setblock 425 296 474 minecraft:polished_blackstone_bricks
fill 425 296 475 425 299 475 minecraft:blackstone
setblock 425 296 479 minecraft:polished_blackstone_bricks
fill 425 296 480 425 299 480 minecraft:blackstone
setblock 425 296 484 minecraft:polished_blackstone_bricks
fill 425 296 485 425 299 485 minecraft:blackstone
setblock 425 296 489 minecraft:polished_blackstone_bricks
fill 425 296 490 425 299 490 minecraft:blackstone
setblock 425 296 494 minecraft:polished_blackstone_bricks
fill 425 296 495 425 299 495 minecraft:blackstone
setblock 425 296 499 minecraft:polished_blackstone_bricks
fill 425 296 500 425 299 500 minecraft:blackstone
fill 425 296 502 425 296 503 minecraft:blackstone
setblock 425 296 504 minecraft:polished_blackstone_bricks
setblock 426 296 464 minecraft:blackstone
setblock 426 296 473 minecraft:polished_blackstone_bricks
fill 426 296 474 426 297 474 minecraft:blackstone
setblock 426 296 478 minecraft:polished_blackstone_bricks
fill 426 296 479 426 299 479 minecraft:blackstone
fill 426 296 481 426 296 482 minecraft:blackstone
setblock 426 296 488 minecraft:polished_blackstone_bricks
fill 426 296 489 426 297 489 minecraft:blackstone
setblock 426 296 493 minecraft:polished_blackstone_bricks
fill 426 296 494 426 299 494 minecraft:blackstone
setblock 426 296 498 minecraft:polished_blackstone_bricks
fill 426 296 499 426 299 499 minecraft:blackstone
setblock 426 296 502 minecraft:blackstone
setblock 426 296 503 minecraft:polished_blackstone_bricks
fill 426 296 504 426 299 504 minecraft:blackstone
setblock 427 296 492 minecraft:polished_blackstone_bricks
fill 427 296 493 427 297 493 minecraft:blackstone
setblock 427 296 496 minecraft:blackstone
setblock 427 296 497 minecraft:polished_blackstone_bricks
fill 427 296 498 427 298 498 minecraft:blackstone
setblock 427 296 502 minecraft:polished_blackstone_bricks
fill 427 296 503 427 299 503 minecraft:blackstone
fill 428 296 502 428 297 502 minecraft:blackstone
fill 429 296 503 429 297 503 minecraft:blackstone
setblock 430 296 504 minecraft:polished_blackstone_bricks
setblock 431 296 504 minecraft:blackstone
fill 442 296 464 444 296 464 minecraft:blackstone
fill 443 296 504 444 296 504 minecraft:blackstone
setblock 444 296 465 minecraft:polished_blackstone_bricks
setblock 445 296 464 minecraft:polished_blackstone_bricks
fill 445 296 465 448 296 465 minecraft:blackstone
setblock 445 296 503 minecraft:blackstone
setblock 445 296 504 minecraft:polished_blackstone_bricks
fill 446 296 464 449 296 464 minecraft:blackstone
setblock 446 296 503 minecraft:polished_blackstone_bricks
fill 446 296 504 446 299 504 minecraft:blackstone
setblock 447 296 466 minecraft:blackstone
fill 447 296 503 447 299 503 minecraft:blackstone
setblock 448 296 466 minecraft:polished_blackstone_bricks
setblock 449 296 465 minecraft:polished_blackstone_bricks
setblock 450 296 464 minecraft:polished_blackstone_bricks
fill 450 296 465 450 297 465 minecraft:blackstone
setblock 450 296 504 minecraft:polished_blackstone_bricks
fill 451 296 464 451 299 464 minecraft:blackstone
setblock 451 296 503 minecraft:polished_blackstone_bricks
fill 451 296 504 451 299 504 minecraft:blackstone
setblock 455 296 464 minecraft:polished_blackstone_bricks
setblock 455 296 504 minecraft:polished_blackstone_bricks
fill 456 296 504 459 296 504 minecraft:blackstone
setblock 460 296 464 minecraft:polished_blackstone_bricks
setblock 460 296 503 minecraft:blackstone
setblock 460 296 504 minecraft:polished_blackstone_bricks
fill 461 296 464 461 299 464 minecraft:blackstone
setblock 461 296 503 minecraft:polished_blackstone_bricks
fill 461 296 504 461 299 504 minecraft:blackstone
fill 462 296 494 462 296 496 minecraft:blackstone
setblock 462 296 497 minecraft:polished_blackstone_bricks
fill 462 296 498 462 296 501 minecraft:blackstone
setblock 462 296 502 minecraft:polished_blackstone_bricks
fill 462 296 503 462 299 503 minecraft:blackstone
setblock 463 296 471 minecraft:polished_blackstone_bricks
fill 463 296 472 463 297 472 minecraft:blackstone
setblock 463 296 476 minecraft:polished_blackstone_bricks
fill 463 296 477 463 298 478 minecraft:blackstone
setblock 463 296 491 minecraft:polished_blackstone_bricks
fill 463 296 492 463 296 495 minecraft:blackstone
setblock 463 296 496 minecraft:polished_blackstone_bricks
fill 463 296 497 463 299 497 minecraft:blackstone
fill 463 296 499 463 296 500 minecraft:blackstone
setblock 463 296 501 minecraft:polished_blackstone_bricks
fill 463 296 502 463 299 502 minecraft:blackstone
setblock 464 296 465 minecraft:polished_blackstone_bricks
fill 464 296 466 464 299 466 minecraft:blackstone
setblock 464 296 470 minecraft:polished_blackstone_bricks
fill 464 296 471 464 299 471 minecraft:blackstone
setblock 464 296 475 minecraft:polished_blackstone_bricks
fill 464 296 476 464 299 476 minecraft:blackstone
fill 464 296 478 464 296 479 minecraft:blackstone
setblock 464 296 480 minecraft:polished_blackstone_bricks
fill 464 296 481 464 299 481 minecraft:blackstone
fill 464 296 483 464 296 484 minecraft:blackstone
setblock 464 296 485 minecraft:polished_blackstone_bricks
fill 464 296 486 464 296 489 minecraft:blackstone
setblock 464 296 490 minecraft:polished_blackstone_bricks
fill 464 296 491 464 296 494 minecraft:blackstone
setblock 464 296 495 minecraft:polished_blackstone_bricks
fill 464 296 496 464 299 496 minecraft:blackstone
setblock 464 296 499 minecraft:blackstone
setblock 464 296 500 minecraft:polished_blackstone_bricks
fill 464 296 501 464 299 501 minecraft:blackstone
setblock 424 297 469 minecraft:polished_blackstone_bricks
fill 424 297 470 424 297 473 minecraft:blackstone
setblock 424 297 474 minecraft:polished_blackstone_bricks
fill 424 297 475 424 297 478 minecraft:blackstone
setblock 424 297 479 minecraft:polished_blackstone_bricks
fill 424 297 480 424 300 480 minecraft:blackstone
setblock 424 297 483 minecraft:blackstone
setblock 424 297 484 minecraft:polished_blackstone_bricks
fill 424 297 485 424 300 485 minecraft:blackstone
setblock 424 297 489 minecraft:polished_blackstone_bricks
fill 424 297 490 424 300 490 minecraft:blackstone
setblock 424 297 494 minecraft:polished_blackstone_bricks
fill 424 297 495 424 300 495 minecraft:blackstone
setblock 424 297 499 minecraft:polished_blackstone_bricks
fill 424 297 500 424 297 503 minecraft:blackstone
setblock 424 297 504 minecraft:polished_blackstone_bricks
setblock 425 297 464 minecraft:blackstone
setblock 425 297 473 minecraft:polished_blackstone_bricks
fill 425 297 474 425 300 474 minecraft:blackstone
setblock 425 297 477 minecraft:blackstone
setblock 425 297 478 minecraft:polished_blackstone_bricks
fill 425 297 479 425 300 479 minecraft:blackstone
setblock 425 297 483 minecraft:polished_blackstone_bricks
fill 425 297 484 425 300 484 minecraft:blackstone
setblock 425 297 488 minecraft:polished_blackstone_bricks
fill 425 297 489 425 300 489 minecraft:blackstone
setblock 425 297 493 minecraft:polished_blackstone_bricks
fill 425 297 494 425 300 494 minecraft:blackstone
setblock 425 297 498 minecraft:polished_blackstone_bricks
fill 425 297 499 425 300 499 minecraft:blackstone
setblock 425 297 502 minecraft:blackstone
setblock 425 297 503 minecraft:polished_blackstone_bricks
fill 425 297 504 425 300 504 minecraft:blackstone
setblock 426 297 477 minecraft:polished_blackstone_bricks
fill 426 297 478 426 300 478 minecraft:blackstone
setblock 426 297 481 minecraft:blackstone
setblock 426 297 482 minecraft:polished_blackstone_bricks
fill 426 297 483 426 300 483 minecraft:blackstone
setblock 426 297 492 minecraft:polished_blackstone_bricks
fill 426 297 493 426 299 493 minecraft:blackstone
setblock 426 297 497 minecraft:polished_blackstone_bricks
fill 426 297 498 426 300 498 minecraft:blackstone
setblock 426 297 502 minecraft:polished_blackstone_bricks
fill 426 297 503 426 300 503 minecraft:blackstone
setblock 427 297 496 minecraft:polished_blackstone_bricks
fill 427 297 497 427 298 497 minecraft:blackstone
fill 427 297 502 427 298 502 minecraft:blackstone
setblock 429 297 504 minecraft:polished_blackstone_bricks
fill 430 297 504 430 298 504 minecraft:blackstone
fill 442 297 464 443 297 464 minecraft:blackstone
fill 442 297 504 443 297 504 minecraft:blackstone
setblock 444 297 464 minecraft:polished_blackstone_bricks
fill 444 297 465 447 297 465 minecraft:blackstone
setblock 444 297 504 minecraft:polished_blackstone_bricks
fill 445 297 464 448 297 464 minecraft:blackstone
setblock 445 297 503 minecraft:polished_blackstone_bricks
fill 445 297 504 445 300 504 minecraft:blackstone
fill 446 297 503 446 300 503 minecraft:blackstone
setblock 448 297 465 minecraft:polished_blackstone_bricks
fill 448 297 503 449 297 503 minecraft:blackstone
setblock 449 297 464 minecraft:polished_blackstone_bricks
fill 449 297 465 449 298 465 minecraft:blackstone
setblock 449 297 504 minecraft:polished_blackstone_bricks
fill 450 297 464 450 300 464 minecraft:blackstone
setblock 450 297 503 minecraft:polished_blackstone_bricks
fill 450 297 504 450 300 504 minecraft:blackstone
setblock 451 297 503 minecraft:blackstone
setblock 453 297 504 minecraft:blackstone
setblock 454 297 464 minecraft:polished_blackstone_bricks
setblock 454 297 504 minecraft:polished_blackstone_bricks
fill 455 297 504 458 297 504 minecraft:blackstone
setblock 459 297 464 minecraft:polished_blackstone_bricks
setblock 459 297 503 minecraft:blackstone
setblock 459 297 504 minecraft:polished_blackstone_bricks
fill 460 297 464 460 300 464 minecraft:blackstone
setblock 460 297 503 minecraft:polished_blackstone_bricks
fill 460 297 504 460 300 504 minecraft:blackstone
setblock 461 297 502 minecraft:polished_blackstone_bricks
fill 461 297 503 461 300 503 minecraft:blackstone
fill 462 297 494 462 297 495 minecraft:blackstone
setblock 462 297 496 minecraft:polished_blackstone_bricks
fill 462 297 497 462 297 500 minecraft:blackstone
setblock 462 297 501 minecraft:polished_blackstone_bricks
fill 462 297 502 462 300 502 minecraft:blackstone
setblock 463 297 471 minecraft:blackstone
setblock 463 297 475 minecraft:polished_blackstone_bricks
fill 463 297 476 463 300 476 minecraft:blackstone
setblock 463 297 479 minecraft:blackstone
fill 463 297 491 463 297 494 minecraft:blackstone
setblock 463 297 495 minecraft:polished_blackstone_bricks
fill 463 297 496 463 300 496 minecraft:blackstone
setblock 463 297 499 minecraft:blackstone
setblock 463 297 500 minecraft:polished_blackstone_bricks
fill 463 297 501 463 300 501 minecraft:blackstone
setblock 464 297 464 minecraft:polished_blackstone_bricks
fill 464 297 465 464 300 465 minecraft:blackstone
setblock 464 297 469 minecraft:polished_blackstone_bricks
fill 464 297 470 464 299 470 minecraft:blackstone
setblock 464 297 474 minecraft:polished_blackstone_bricks
fill 464 297 475 464 300 475 minecraft:blackstone
setblock 464 297 478 minecraft:blackstone
setblock 464 297 479 minecraft:polished_blackstone_bricks
fill 464 297 480 464 300 480 minecraft:blackstone
setblock 464 297 483 minecraft:blackstone
setblock 464 297 484 minecraft:polished_blackstone_bricks
fill 464 297 485 464 297 488 minecraft:blackstone
setblock 464 297 489 minecraft:polished_blackstone_bricks
fill 464 297 490 464 297 493 minecraft:blackstone
setblock 464 297 494 minecraft:polished_blackstone_bricks
fill 464 297 495 464 300 495 minecraft:blackstone
setblock 464 297 499 minecraft:polished_blackstone_bricks
fill 464 297 500 464 300 500 minecraft:blackstone
setblock 464 297 504 minecraft:polished_blackstone_bricks
fill 424 298 470 424 298 472 minecraft:blackstone
setblock 424 298 473 minecraft:polished_blackstone_bricks
fill 424 298 474 424 298 477 minecraft:blackstone
setblock 424 298 478 minecraft:polished_blackstone_bricks
fill 424 298 479 424 300 479 minecraft:blackstone
setblock 424 298 483 minecraft:polished_blackstone_bricks
fill 424 298 484 424 300 484 minecraft:blackstone
setblock 424 298 488 minecraft:polished_blackstone_bricks
fill 424 298 489 424 300 489 minecraft:blackstone
setblock 424 298 493 minecraft:polished_blackstone_bricks
fill 424 298 494 424 300 494 minecraft:blackstone
setblock 424 298 498 minecraft:polished_blackstone_bricks
fill 424 298 499 424 298 502 minecraft:blackstone
setblock 424 298 503 minecraft:polished_blackstone_bricks
fill 424 298 504 424 300 504 minecraft:blackstone
setblock 425 298 472 minecraft:polished_blackstone_bricks
fill 425 298 473 425 299 473 minecraft:blackstone
setblock 425 298 477 minecraft:polished_blackstone_bricks
fill 425 298 478 425 300 478 minecraft:blackstone
setblock 425 298 482 minecraft:polished_blackstone_bricks
fill 425 298 483 425 300 483 minecraft:blackstone
setblock 425 298 487 minecraft:polished_blackstone_bricks
fill 425 298 488 425 300 488 minecraft:blackstone
schedule function dropper:buildpart/117_10 1t
