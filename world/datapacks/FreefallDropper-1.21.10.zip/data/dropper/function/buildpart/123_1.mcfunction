fill 156 143 552 156 206 552 minecraft:crying_obsidian
setblock 157 143 552 minecraft:white_concrete
setblock 160 143 513 minecraft:light[level=12]
setblock 160 143 521 minecraft:light[level=12]
setblock 160 143 537 minecraft:light[level=12]
setblock 160 143 545 minecraft:light[level=12]
setblock 168 143 513 minecraft:light[level=12]
setblock 168 143 521 minecraft:light[level=12]
setblock 168 143 529 minecraft:light[level=12]
setblock 168 143 537 minecraft:light[level=12]
setblock 168 143 545 minecraft:light[level=12]
setblock 176 143 513 minecraft:light[level=12]
setblock 176 143 521 minecraft:light[level=12]
setblock 176 143 529 minecraft:light[level=12]
setblock 176 143 537 minecraft:light[level=12]
setblock 176 143 545 minecraft:light[level=12]
fill 157 144 552 157 159 552 minecraft:crying_obsidian
setblock 159 144 510 minecraft:white_concrete
setblock 183 144 516 minecraft:white_concrete
fill 141 145 518 141 146 518 minecraft:purple_stained_glass
fill 141 145 534 141 146 534 minecraft:purple_stained_glass
fill 141 145 550 141 146 550 minecraft:purple_stained_glass
fill 145 145 510 145 146 510 minecraft:purple_stained_glass
fill 146 145 510 146 206 510 minecraft:crying_obsidian
fill 155 145 552 155 146 552 minecraft:purple_stained_glass
fill 159 145 510 159 160 510 minecraft:crying_obsidian
fill 161 145 510 161 146 510 minecraft:purple_stained_glass
setblock 166 145 510 minecraft:amethyst_block
fill 171 145 552 171 146 552 minecraft:purple_stained_glass
fill 177 145 510 177 146 510 minecraft:purple_stained_glass
fill 183 145 516 183 186 516 minecraft:crying_obsidian
fill 183 145 520 183 146 520 minecraft:purple_stained_glass
fill 183 145 536 183 146 536 minecraft:purple_stained_glass
fill 153 146 543 153 147 545 minecraft:obsidian
fill 154 146 544 154 147 545 minecraft:obsidian
fill 166 146 510 166 206 510 minecraft:crying_obsidian
fill 141 147 518 141 153 518 minecraft:crying_obsidian
fill 141 147 534 141 153 534 minecraft:crying_obsidian
fill 141 147 550 141 153 550 minecraft:crying_obsidian
setblock 145 147 510 minecraft:crying_obsidian
fill 155 147 552 155 153 552 minecraft:crying_obsidian
fill 161 147 510 161 153 510 minecraft:crying_obsidian
setblock 162 147 510 minecraft:amethyst_block
fill 171 147 552 171 153 552 minecraft:crying_obsidian
fill 177 147 510 177 150 510 minecraft:crying_obsidian
fill 183 147 520 183 153 520 minecraft:crying_obsidian
fill 183 147 536 183 153 536 minecraft:crying_obsidian
setblock 145 148 510 minecraft:amethyst_block
fill 162 148 510 162 202 510 minecraft:crying_obsidian
setblock 141 149 548 minecraft:amethyst_block
fill 145 149 510 145 153 510 minecraft:crying_obsidian
fill 170 149 510 170 206 510 minecraft:crying_obsidian
setblock 171 149 510 minecraft:white_concrete
fill 173 149 534 175 150 534 minecraft:crying_obsidian
fill 174 149 533 174 150 533 minecraft:crying_obsidian
fill 174 149 535 174 150 535 minecraft:crying_obsidian
setblock 180 149 510 minecraft:amethyst_block
fill 141 150 548 141 206 548 minecraft:crying_obsidian
fill 171 150 510 171 204 510 minecraft:crying_obsidian
fill 180 150 510 180 203 510 minecraft:crying_obsidian
setblock 144 151 513 minecraft:light[level=12]
setblock 144 151 521 minecraft:light[level=12]
setblock 144 151 529 minecraft:light[level=12]
setblock 144 151 537 minecraft:light[level=12]
setblock 144 151 545 minecraft:light[level=12]
setblock 152 151 513 minecraft:light[level=12]
setblock 152 151 521 minecraft:light[level=12]
setblock 152 151 529 minecraft:light[level=12]
setblock 152 151 537 minecraft:light[level=12]
setblock 152 151 545 minecraft:light[level=12]
setblock 155 151 510 minecraft:amethyst_block
setblock 160 151 513 minecraft:light[level=12]
setblock 160 151 521 minecraft:light[level=12]
setblock 160 151 537 minecraft:light[level=12]
setblock 160 151 545 minecraft:light[level=12]
setblock 168 151 513 minecraft:light[level=12]
setblock 168 151 521 minecraft:light[level=12]
setblock 168 151 529 minecraft:light[level=12]
setblock 168 151 537 minecraft:light[level=12]
setblock 168 151 545 minecraft:light[level=12]
setblock 176 151 513 minecraft:light[level=12]
setblock 176 151 521 minecraft:light[level=12]
setblock 176 151 529 minecraft:light[level=12]
setblock 176 151 537 minecraft:light[level=12]
setblock 176 151 545 minecraft:light[level=12]
setblock 177 151 510 minecraft:white_concrete
fill 155 152 510 155 207 510 minecraft:crying_obsidian
setblock 172 152 510 minecraft:amethyst_block
setblock 177 152 510 minecraft:crying_obsidian
fill 142 153 552 142 206 552 minecraft:crying_obsidian
setblock 143 153 552 minecraft:amethyst_block
fill 154 153 533 155 154 534 minecraft:crying_obsidian
fill 172 153 510 172 196 510 minecraft:crying_obsidian
setblock 172 153 552 minecraft:white_concrete
setblock 177 153 510 minecraft:white_concrete
fill 183 153 547 183 206 547 minecraft:crying_obsidian
setblock 183 153 548 minecraft:amethyst_block
fill 141 154 518 141 155 518 minecraft:purple_stained_glass
fill 141 154 534 141 155 534 minecraft:purple_stained_glass
fill 141 154 550 141 155 550 minecraft:purple_stained_glass
fill 143 154 552 143 203 552 minecraft:crying_obsidian
fill 145 154 510 145 155 510 minecraft:purple_stained_glass
fill 155 154 552 155 155 552 minecraft:purple_stained_glass
fill 161 154 510 161 155 510 minecraft:purple_stained_glass
fill 171 154 552 171 155 552 minecraft:purple_stained_glass
fill 172 154 552 172 206 552 minecraft:crying_obsidian
fill 177 154 510 177 155 510 minecraft:purple_stained_glass
fill 183 154 520 183 155 520 minecraft:purple_stained_glass
fill 183 154 536 183 155 536 minecraft:purple_stained_glass
fill 183 154 548 183 171 548 minecraft:crying_obsidian
fill 157 155 510 157 156 510 minecraft:amethyst_block
fill 141 156 518 141 161 518 minecraft:crying_obsidian
fill 141 156 534 141 161 534 minecraft:crying_obsidian
fill 141 156 550 141 161 550 minecraft:crying_obsidian
fill 145 156 510 145 161 510 minecraft:crying_obsidian
fill 155 156 552 155 161 552 minecraft:crying_obsidian
fill 161 156 510 161 161 510 minecraft:crying_obsidian
fill 171 156 552 171 161 552 minecraft:crying_obsidian
fill 173 156 552 176 179 552 minecraft:crying_obsidian
fill 177 156 510 177 161 510 minecraft:crying_obsidian
setblock 177 156 552 minecraft:amethyst_block
fill 183 156 520 183 161 520 minecraft:crying_obsidian
fill 183 156 536 183 161 536 minecraft:crying_obsidian
fill 157 157 510 157 206 510 minecraft:crying_obsidian
fill 177 157 552 177 206 552 minecraft:crying_obsidian
setblock 144 159 510 minecraft:white_concrete
setblock 144 159 513 minecraft:light[level=12]
setblock 144 159 521 minecraft:light[level=12]
setblock 144 159 529 minecraft:light[level=12]
setblock 144 159 537 minecraft:light[level=12]
setblock 144 159 545 minecraft:light[level=12]
setblock 149 159 510 minecraft:white_concrete
setblock 152 159 513 minecraft:light[level=12]
setblock 152 159 521 minecraft:light[level=12]
setblock 152 159 529 minecraft:light[level=12]
setblock 152 159 537 minecraft:light[level=12]
setblock 152 159 545 minecraft:light[level=12]
setblock 160 159 513 minecraft:light[level=12]
setblock 160 159 521 minecraft:light[level=12]
setblock 160 159 537 minecraft:light[level=12]
setblock 160 159 545 minecraft:light[level=12]
setblock 168 159 513 minecraft:light[level=12]
setblock 168 159 521 minecraft:light[level=12]
setblock 168 159 529 minecraft:light[level=12]
setblock 168 159 537 minecraft:light[level=12]
setblock 168 159 545 minecraft:light[level=12]
setblock 176 159 513 minecraft:light[level=12]
setblock 176 159 521 minecraft:light[level=12]
setblock 176 159 529 minecraft:light[level=12]
setblock 176 159 537 minecraft:light[level=12]
setblock 176 159 545 minecraft:light[level=12]
fill 144 160 510 144 202 510 minecraft:crying_obsidian
fill 149 160 510 149 206 510 minecraft:crying_obsidian
setblock 157 160 552 minecraft:amethyst_block
setblock 163 160 510 minecraft:white_concrete
fill 183 160 534 183 206 534 minecraft:crying_obsidian
setblock 183 160 535 minecraft:amethyst_block
fill 183 160 549 183 168 550 minecraft:crying_obsidian
setblock 183 160 551 minecraft:amethyst_block
setblock 141 161 521 minecraft:white_concrete
fill 157 161 552 157 206 552 minecraft:crying_obsidian
setblock 159 161 510 minecraft:white_concrete
fill 163 161 510 163 165 510 minecraft:crying_obsidian
setblock 180 161 552 minecraft:white_concrete
fill 181 161 552 181 204 552 minecraft:crying_obsidian
fill 183 161 535 183 196 535 minecraft:crying_obsidian
fill 183 161 540 183 171 541 minecraft:crying_obsidian
setblock 183 161 542 minecraft:white_concrete
fill 183 161 551 183 162 551 minecraft:crying_obsidian
setblock 141 162 518 minecraft:purple_stained_glass
fill 141 162 521 141 202 521 minecraft:crying_obsidian
setblock 141 162 534 minecraft:purple_stained_glass
setblock 141 162 550 minecraft:purple_stained_glass
setblock 145 162 510 minecraft:purple_stained_glass
setblock 155 162 552 minecraft:purple_stained_glass
fill 159 162 510 159 188 510 minecraft:crying_obsidian
setblock 161 162 510 minecraft:purple_stained_glass
setblock 171 162 552 minecraft:purple_stained_glass
setblock 177 162 510 minecraft:purple_stained_glass
fill 180 162 552 180 185 552 minecraft:crying_obsidian
setblock 183 162 520 minecraft:purple_stained_glass
setblock 183 162 536 minecraft:purple_stained_glass
fill 183 162 542 183 206 542 minecraft:crying_obsidian
fill 141 163 518 141 172 518 minecraft:crying_obsidian
setblock 141 163 522 minecraft:white_concrete
fill 141 163 534 141 172 534 minecraft:crying_obsidian
fill 141 163 550 141 172 550 minecraft:crying_obsidian
fill 145 163 510 145 172 510 minecraft:crying_obsidian
fill 155 163 552 155 172 552 minecraft:crying_obsidian
fill 161 163 510 161 172 510 minecraft:crying_obsidian
fill 165 163 552 165 203 552 minecraft:crying_obsidian
setblock 166 163 552 minecraft:white_concrete
fill 171 163 552 171 172 552 minecraft:crying_obsidian
fill 177 163 510 177 172 510 minecraft:crying_obsidian
fill 183 163 513 183 207 513 minecraft:crying_obsidian
setblock 183 163 514 minecraft:white_concrete
setblock 183 163 520 minecraft:white_concrete
fill 183 163 536 183 172 536 minecraft:crying_obsidian
setblock 183 163 551 minecraft:amethyst_block
fill 141 164 522 141 202 522 minecraft:crying_obsidian
setblock 141 164 539 minecraft:white_concrete
fill 141 164 540 141 206 540 minecraft:crying_obsidian
fill 166 164 552 166 204 552 minecraft:crying_obsidian
setblock 182 164 552 minecraft:white_concrete
fill 183 164 514 183 206 514 minecraft:crying_obsidian
fill 183 164 520 183 172 520 minecraft:crying_obsidian
setblock 183 164 551 minecraft:white_concrete
fill 141 165 539 141 207 539 minecraft:crying_obsidian
fill 164 165 510 164 203 510 minecraft:crying_obsidian
setblock 165 165 510 minecraft:white_concrete
setblock 169 165 510 minecraft:white_concrete
setblock 173 165 510 minecraft:white_concrete
fill 182 165 552 182 189 552 minecraft:crying_obsidian
fill 183 165 551 183 206 551 minecraft:crying_obsidian
setblock 141 166 537 minecraft:amethyst_block
setblock 161 166 552 minecraft:white_concrete
setblock 163 166 510 minecraft:amethyst_block
fill 165 166 510 165 206 510 minecraft:crying_obsidian
fill 169 166 510 169 204 510 minecraft:crying_obsidian
fill 173 166 510 173 206 510 minecraft:crying_obsidian
setblock 141 167 512 minecraft:white_concrete
fill 141 167 513 141 204 513 minecraft:crying_obsidian
setblock 141 167 535 minecraft:amethyst_block
fill 141 167 537 141 204 537 minecraft:crying_obsidian
setblock 144 167 513 minecraft:light[level=12]
setblock 144 167 521 minecraft:light[level=12]
setblock 144 167 529 minecraft:light[level=12]
setblock 144 167 537 minecraft:light[level=12]
setblock 144 167 545 minecraft:light[level=12]
setblock 152 167 513 minecraft:light[level=12]
setblock 152 167 521 minecraft:light[level=12]
setblock 152 167 529 minecraft:light[level=12]
setblock 152 167 537 minecraft:light[level=12]
setblock 152 167 545 minecraft:light[level=12]
fill 156 167 526 158 167 528 minecraft:redstone_block
fill 157 167 533 159 167 535 minecraft:redstone_block
setblock 160 167 513 minecraft:light[level=12]
setblock 160 167 521 minecraft:light[level=12]
setblock 160 167 537 minecraft:light[level=12]
setblock 160 167 545 minecraft:light[level=12]
fill 161 167 552 161 206 552 minecraft:crying_obsidian
fill 163 167 510 163 203 510 minecraft:crying_obsidian
fill 165 167 529 167 167 531 minecraft:redstone_block
fill 167 167 552 168 204 552 minecraft:crying_obsidian
setblock 168 167 513 minecraft:light[level=12]
setblock 168 167 521 minecraft:light[level=12]
setblock 168 167 529 minecraft:light[level=12]
setblock 168 167 537 minecraft:light[level=12]
setblock 168 167 545 minecraft:light[level=12]
setblock 169 167 552 minecraft:white_concrete
fill 170 167 552 170 170 552 minecraft:crying_obsidian
setblock 176 167 513 minecraft:light[level=12]
setblock 176 167 521 minecraft:light[level=12]
setblock 176 167 529 minecraft:light[level=12]
setblock 176 167 537 minecraft:light[level=12]
setblock 176 167 545 minecraft:light[level=12]
fill 141 168 512 141 193 512 minecraft:crying_obsidian
fill 141 168 535 141 206 535 minecraft:crying_obsidian
fill 147 168 530 148 169 530 minecraft:magenta_concrete
fill 148 168 525 148 169 526 minecraft:purple_concrete
fill 148 168 527 149 169 529 minecraft:magenta_concrete
fill 148 168 531 148 169 531 minecraft:magenta_concrete
fill 148 168 532 151 169 535 minecraft:purple_concrete
fill 149 168 523 150 169 525 minecraft:purple_concrete
fill 149 168 526 155 168 526 minecraft:magenta_concrete
fill 149 168 530 154 169 531 minecraft:purple_concrete
fill 149 168 536 151 169 537 minecraft:purple_concrete
fill 150 168 522 159 168 522 minecraft:purple_concrete
fill 150 168 527 151 169 528 minecraft:magenta_concrete
fill 150 168 529 157 168 529 minecraft:purple_concrete
fill 150 168 538 151 169 538 minecraft:purple_concrete
fill 151 168 521 158 169 521 minecraft:purple_concrete
fill 151 168 523 160 168 524 minecraft:purple_concrete
fill 151 168 525 157 168 525 minecraft:magenta_concrete
fill 151 168 539 151 169 539 minecraft:purple_concrete
fill 152 168 520 156 169 520 minecraft:purple_concrete
fill 152 168 527 153 169 527 minecraft:magenta_concrete
fill 152 168 528 155 168 528 minecraft:purple_concrete
fill 152 168 532 152 169 534 minecraft:purple_concrete
fill 152 168 535 154 169 540 minecraft:magenta_concrete
fill 153 168 519 160 169 519 minecraft:magenta_concrete
fill 153 168 532 153 169 532 minecraft:purple_concrete
fill 153 168 533 155 169 534 minecraft:magenta_concrete
fill 153 168 541 155 169 541 minecraft:magenta_concrete
fill 154 168 518 159 169 518 minecraft:magenta_concrete
fill 154 168 527 155 168 527 minecraft:purple_concrete
fill 154 168 532 156 168 532 minecraft:magenta_concrete
fill 154 168 542 155 169 542 minecraft:magenta_concrete
fill 155 168 530 155 169 530 minecraft:purple_concrete
fill 155 168 531 157 169 531 minecraft:magenta_concrete
fill 155 168 535 156 168 540 minecraft:purple_concrete
fill 156 168 517 157 169 517 minecraft:magenta_concrete
fill 156 168 530 157 169 530 minecraft:magenta_concrete
fill 156 168 533 156 168 534 minecraft:purple_concrete
fill 156 168 541 161 169 542 minecraft:purple_concrete
fill 156 168 543 156 169 543 minecraft:magenta_concrete
fill 157 168 520 161 169 520 minecraft:magenta_concrete
fill 157 168 532 158 168 532 minecraft:purple_concrete
fill 157 168 536 158 168 540 minecraft:purple_concrete
fill 157 168 543 164 169 543 minecraft:purple_concrete
fill 158 168 517 165 169 517 minecraft:purple_concrete
fill 158 168 525 161 168 525 minecraft:purple_concrete
fill 158 168 529 159 168 531 minecraft:black_concrete
fill 159 168 521 162 169 521 minecraft:magenta_concrete
fill 159 168 526 161 168 526 minecraft:purple_concrete
setblock 159 168 527 minecraft:magenta_concrete
fill 159 168 528 163 168 528 minecraft:black_concrete
fill 159 168 532 163 168 532 minecraft:black_concrete
fill 159 168 536 160 168 537 minecraft:magenta_concrete
fill 159 168 538 159 168 540 minecraft:purple_concrete
fill 160 168 518 166 169 518 minecraft:purple_concrete
fill 160 168 522 162 168 522 minecraft:magenta_concrete
fill 160 168 527 162 169 527 minecraft:black_concrete
fill 160 168 533 162 168 533 minecraft:black_concrete
fill 160 168 534 160 168 535 minecraft:magenta_concrete
fill 160 168 538 162 168 539 minecraft:magenta_concrete
fill 160 168 540 160 169 540 minecraft:purple_concrete
fill 161 168 516 161 169 516 minecraft:purple_concrete
fill 161 168 519 166 169 519 minecraft:purple_concrete
fill 161 168 523 163 168 523 minecraft:magenta_concrete
setblock 161 168 524 minecraft:purple_concrete
fill 161 168 534 163 168 536 minecraft:purple_concrete
setblock 161 168 537 minecraft:magenta_concrete
fill 161 168 540 165 169 540 minecraft:magenta_concrete
fill 161 168 544 161 169 544 minecraft:purple_concrete
fill 162 168 520 167 169 520 minecraft:purple_concrete
fill 162 168 524 163 168 526 minecraft:magenta_concrete
fill 162 168 537 173 168 537 minecraft:purple_concrete
fill 162 168 541 169 169 541 minecraft:magenta_concrete
fill 162 168 542 162 169 542 minecraft:purple_concrete
fill 163 168 521 167 168 522 minecraft:purple_concrete
fill 163 168 527 163 169 527 minecraft:magenta_concrete
fill 163 168 529 164 168 531 minecraft:black_concrete
fill 163 168 533 164 169 533 minecraft:magenta_concrete
fill 163 168 538 172 168 538 minecraft:purple_concrete
fill 163 168 539 163 169 539 minecraft:magenta_concrete
fill 163 168 542 168 169 542 minecraft:magenta_concrete
fill 164 168 523 165 168 528 minecraft:purple_concrete
fill 164 168 532 170 168 532 minecraft:purple_concrete
fill 164 168 534 173 169 534 minecraft:magenta_concrete
fill 164 168 535 164 168 536 minecraft:purple_concrete
fill 164 168 539 171 169 539 minecraft:purple_concrete
fill 165 168 533 168 169 533 minecraft:purple_concrete
fill 165 168 535 171 169 535 minecraft:magenta_concrete
fill 165 168 536 173 168 536 minecraft:purple_concrete
fill 165 168 543 166 169 543 minecraft:magenta_concrete
fill 166 168 517 166 169 517 minecraft:magenta_concrete
fill 166 168 523 166 169 527 minecraft:purple_concrete
fill 166 168 528 168 168 528 minecraft:magenta_concrete
fill 166 168 540 170 169 540 minecraft:purple_concrete
fill 167 168 518 168 169 519 minecraft:magenta_concrete
fill 167 168 523 167 169 525 minecraft:purple_concrete
fill 167 168 526 169 169 527 minecraft:magenta_concrete
fill 168 168 520 170 169 525 minecraft:magenta_concrete
fill 168 168 529 172 168 531 minecraft:purple_concrete
fill 169 168 519 169 169 519 minecraft:magenta_concrete
fill 169 168 528 174 169 528 minecraft:purple_concrete
fill 169 168 533 174 169 533 minecraft:magenta_concrete
fill 169 168 552 169 206 552 minecraft:crying_obsidian
fill 170 168 526 174 169 527 minecraft:purple_concrete
fill 171 168 521 171 169 525 minecraft:purple_concrete
fill 171 168 532 174 169 532 minecraft:magenta_concrete
fill 172 168 522 172 169 525 minecraft:purple_concrete
fill 172 168 535 174 169 535 minecraft:purple_concrete
fill 173 168 523 173 169 525 minecraft:purple_concrete
fill 173 168 529 173 169 530 minecraft:purple_concrete
fill 173 168 531 174 169 531 minecraft:magenta_concrete
fill 174 168 525 174 169 525 minecraft:purple_concrete
fill 174 168 529 174 169 530 minecraft:magenta_concrete
fill 174 168 534 174 169 534 minecraft:purple_concrete
fill 175 168 510 175 206 510 minecraft:crying_obsidian
fill 175 168 530 175 169 530 minecraft:magenta_concrete
setblock 176 168 510 minecraft:white_concrete
fill 183 168 517 183 206 517 minecraft:crying_obsidian
setblock 183 168 518 minecraft:white_concrete
fill 183 168 519 183 204 519 minecraft:crying_obsidian
fill 142 169 511 146 169 551 minecraft:black_concrete
fill 147 169 511 147 169 529 minecraft:black_concrete
fill 147 169 531 147 169 551 minecraft:black_concrete
fill 148 169 511 148 169 524 minecraft:black_concrete
fill 148 169 536 148 169 551 minecraft:black_concrete
fill 149 169 511 149 169 522 minecraft:black_concrete
fill 149 169 526 154 169 526 minecraft:magenta_concrete
fill 149 169 538 149 169 551 minecraft:black_concrete
fill 150 169 511 150 169 521 minecraft:black_concrete
fill 150 169 522 158 169 522 minecraft:purple_concrete
fill 150 169 529 154 169 529 minecraft:purple_concrete
fill 150 169 539 150 169 551 minecraft:black_concrete
fill 151 169 511 151 169 520 minecraft:black_concrete
fill 151 169 523 156 169 524 minecraft:purple_concrete
fill 151 169 525 154 169 525 minecraft:magenta_concrete
fill 151 169 540 151 169 551 minecraft:black_concrete
fill 152 169 511 152 169 519 minecraft:black_concrete
fill 152 169 528 154 169 528 minecraft:purple_concrete
fill 152 169 541 152 169 551 minecraft:black_concrete
fill 153 169 511 153 169 518 minecraft:black_concrete
fill 153 169 542 153 169 551 minecraft:black_concrete
fill 154 169 511 155 169 517 minecraft:black_concrete
setblock 154 169 527 minecraft:purple_concrete
fill 154 169 532 155 169 532 minecraft:magenta_concrete
fill 154 169 543 155 169 551 minecraft:black_concrete
fill 155 169 525 155 169 529 minecraft:crying_obsidian
fill 155 169 535 155 169 540 minecraft:purple_concrete
fill 156 169 511 160 169 516 minecraft:black_concrete
fill 156 169 525 158 169 525 minecraft:crying_obsidian
fill 156 169 526 158 169 528 minecraft:black_concrete
fill 156 169 529 158 169 529 minecraft:crying_obsidian
fill 156 169 532 156 169 536 minecraft:crying_obsidian
fill 156 169 537 156 169 540 minecraft:purple_concrete
fill 156 169 544 160 169 551 minecraft:black_concrete
fill 157 169 523 165 180 524 minecraft:green_terracotta
fill 157 169 532 159 169 532 minecraft:crying_obsidian
fill 157 169 533 158 169 535 minecraft:black_concrete
fill 157 169 536 165 180 537 minecraft:lime_terracotta
fill 157 169 538 158 169 540 minecraft:purple_concrete
fill 158 169 530 158 169 531 minecraft:black_concrete
fill 159 169 522 163 180 522 minecraft:green_terracotta
fill 159 169 525 163 180 525 minecraft:green_terracotta
fill 159 169 526 159 169 528 minecraft:crying_obsidian
fill 159 169 529 159 169 531 minecraft:verdant_froglight
fill 159 169 533 159 169 534 minecraft:black_concrete
fill 159 169 535 163 180 535 minecraft:lime_terracotta
fill 159 169 538 163 180 538 minecraft:lime_terracotta
fill 159 169 539 159 169 540 minecraft:purple_concrete
fill 160 169 526 161 169 526 minecraft:purple_concrete
fill 160 169 528 162 169 528 minecraft:verdant_froglight
fill 160 169 532 162 169 532 minecraft:verdant_froglight
fill 160 169 533 160 169 534 minecraft:crying_obsidian
fill 160 169 539 162 169 539 minecraft:magenta_concrete
fill 161 169 511 182 169 515 minecraft:black_concrete
fill 161 169 533 162 169 533 minecraft:black_concrete
fill 161 169 534 163 169 534 minecraft:purple_concrete
fill 161 169 545 182 169 551 minecraft:black_concrete
fill 162 169 516 182 169 516 minecraft:black_concrete
fill 162 169 526 163 169 526 minecraft:magenta_concrete
fill 162 169 544 182 169 544 minecraft:black_concrete
fill 163 169 521 167 169 521 minecraft:purple_concrete
fill 163 169 528 168 169 528 minecraft:crying_obsidian
fill 163 169 529 163 169 531 minecraft:verdant_froglight
fill 163 169 532 168 169 532 minecraft:crying_obsidian
fill 164 169 522 167 169 522 minecraft:purple_concrete
fill 164 169 525 165 169 527 minecraft:purple_concrete
fill 164 169 529 164 169 531 minecraft:crying_obsidian
setblock 164 169 535 minecraft:purple_concrete
fill 164 169 538 172 169 538 minecraft:purple_concrete
fill 165 169 529 167 169 531 minecraft:black_concrete
fill 166 169 536 173 169 537 minecraft:purple_concrete
fill 167 169 517 182 169 517 minecraft:black_concrete
fill 167 169 543 182 169 543 minecraft:black_concrete
fill 168 169 529 168 169 531 minecraft:crying_obsidian
fill 169 169 518 182 169 518 minecraft:black_concrete
fill 169 169 529 170 169 532 minecraft:purple_concrete
fill 169 169 542 182 169 542 minecraft:black_concrete
fill 170 169 519 182 169 519 minecraft:black_concrete
fill 170 169 541 182 169 541 minecraft:black_concrete
fill 171 169 520 182 169 520 minecraft:black_concrete
fill 171 169 529 172 169 531 minecraft:purple_concrete
fill 171 169 540 182 169 540 minecraft:black_concrete
fill 172 169 521 182 169 521 minecraft:black_concrete
fill 172 169 539 182 169 539 minecraft:black_concrete
fill 173 169 522 182 169 522 minecraft:black_concrete
fill 173 169 538 182 169 538 minecraft:black_concrete
fill 174 169 523 182 169 524 minecraft:black_concrete
fill 174 169 536 182 169 537 minecraft:black_concrete
fill 175 169 525 182 169 529 minecraft:black_concrete
fill 175 169 531 182 169 535 minecraft:black_concrete
fill 176 169 510 176 202 510 minecraft:crying_obsidian
fill 176 169 530 182 169 530 minecraft:black_concrete
fill 183 169 518 183 202 518 minecraft:crying_obsidian
setblock 183 169 549 minecraft:amethyst_block
fill 183 169 550 183 204 550 minecraft:crying_obsidian
fill 144 170 552 144 206 552 minecraft:crying_obsidian
setblock 145 170 552 minecraft:white_concrete
fill 155 170 522 156 179 525 minecraft:green_terracotta
fill 155 170 535 156 179 538 minecraft:lime_terracotta
fill 157 170 522 158 180 522 minecraft:green_terracotta
fill 157 170 525 158 180 525 minecraft:green_terracotta
fill 157 170 535 158 180 535 minecraft:lime_terracotta
fill 157 170 538 158 180 538 minecraft:lime_terracotta
fill 158 170 521 164 179 521 minecraft:green_terracotta
fill 158 170 526 164 177 526 minecraft:green_terracotta
fill 158 170 534 164 177 534 minecraft:lime_terracotta
fill 158 170 539 164 179 539 minecraft:lime_terracotta
setblock 160 170 552 minecraft:white_concrete
fill 164 170 522 167 179 522 minecraft:green_terracotta
fill 164 170 525 167 179 525 minecraft:green_terracotta
fill 164 170 535 167 179 535 minecraft:lime_terracotta
fill 164 170 538 167 179 538 minecraft:lime_terracotta
fill 166 170 523 167 179 524 minecraft:green_terracotta
fill 166 170 536 167 179 537 minecraft:lime_terracotta
fill 183 170 549 183 208 549 minecraft:crying_obsidian
fill 145 171 552 145 206 552 minecraft:crying_obsidian
fill 153 171 523 154 179 524 minecraft:green_terracotta
fill 153 171 536 154 179 537 minecraft:lime_terracotta
fill 154 171 522 154 179 522 minecraft:green_terracotta
fill 154 171 525 154 179 525 minecraft:green_terracotta
fill 154 171 535 154 179 535 minecraft:lime_terracotta
fill 154 171 538 154 179 538 minecraft:lime_terracotta
fill 155 171 521 157 178 521 minecraft:green_terracotta
fill 155 171 526 157 178 526 minecraft:green_terracotta
fill 155 171 534 157 178 534 minecraft:lime_terracotta
fill 155 171 539 157 178 539 minecraft:lime_terracotta
fill 160 171 520 162 178 520 minecraft:green_terracotta
fill 160 171 527 162 173 527 minecraft:green_terracotta
fill 160 171 533 162 173 533 minecraft:lime_terracotta
fill 160 171 540 162 178 540 minecraft:lime_terracotta
fill 160 171 552 160 201 552 minecraft:crying_obsidian
fill 165 171 521 167 178 521 minecraft:green_terracotta
fill 165 171 526 167 178 526 minecraft:green_terracotta
fill 165 171 534 167 178 534 minecraft:lime_terracotta
fill 165 171 539 167 178 539 minecraft:lime_terracotta
fill 168 171 522 168 179 525 minecraft:green_terracotta
fill 168 171 535 168 179 538 minecraft:lime_terracotta
fill 169 171 523 169 179 524 minecraft:green_terracotta
fill 169 171 536 169 179 537 minecraft:lime_terracotta
setblock 170 171 552 minecraft:amethyst_block
setblock 141 172 524 minecraft:amethyst_block
setblock 141 172 528 minecraft:white_concrete
setblock 141 172 545 minecraft:amethyst_block
fill 141 172 546 141 187 546 minecraft:crying_obsidian
setblock 141 172 549 minecraft:white_concrete
fill 152 172 522 152 177 525 minecraft:green_terracotta
fill 152 172 535 152 177 538 minecraft:lime_terracotta
fill 153 172 522 153 178 522 minecraft:green_terracotta
fill 153 172 525 153 178 525 minecraft:green_terracotta
fill 153 172 535 153 178 535 minecraft:lime_terracotta
fill 153 172 538 153 178 538 minecraft:lime_terracotta
fill 154 172 521 154 178 521 minecraft:green_terracotta
fill 154 172 526 154 178 526 minecraft:green_terracotta
fill 154 172 534 154 178 534 minecraft:lime_terracotta
fill 154 172 539 154 178 539 minecraft:lime_terracotta
fill 157 172 520 159 178 520 minecraft:green_terracotta
fill 157 172 527 159 174 527 minecraft:green_terracotta
fill 157 172 533 159 174 533 minecraft:lime_terracotta
fill 157 172 540 159 178 540 minecraft:lime_terracotta
fill 163 172 520 165 178 520 minecraft:green_terracotta
fill 163 172 527 165 174 527 minecraft:green_terracotta
fill 163 172 533 165 174 533 minecraft:lime_terracotta
fill 163 172 540 165 178 540 minecraft:lime_terracotta
fill 168 172 521 168 178 521 minecraft:green_terracotta
fill 168 172 526 168 178 526 minecraft:green_terracotta
fill 168 172 534 168 178 534 minecraft:lime_terracotta
fill 168 172 539 168 178 539 minecraft:lime_terracotta
fill 169 172 522 170 177 522 minecraft:green_terracotta
fill 169 172 525 170 177 525 minecraft:green_terracotta
fill 169 172 535 170 177 535 minecraft:lime_terracotta
fill 169 172 538 170 177 538 minecraft:lime_terracotta
fill 170 172 523 170 178 524 minecraft:green_terracotta
fill 170 172 536 170 178 537 minecraft:lime_terracotta
fill 170 172 552 170 193 552 minecraft:crying_obsidian
fill 183 172 540 183 206 540 minecraft:crying_obsidian
setblock 183 172 541 minecraft:white_concrete
setblock 183 172 548 minecraft:amethyst_block
setblock 141 173 518 minecraft:purple_stained_glass
fill 141 173 524 141 206 524 minecraft:crying_obsidian
fill 141 173 528 141 183 528 minecraft:crying_obsidian
setblock 141 173 534 minecraft:purple_stained_glass
fill 141 173 545 141 176 545 minecraft:crying_obsidian
fill 141 173 549 141 206 549 minecraft:crying_obsidian
setblock 141 173 550 minecraft:purple_stained_glass
setblock 145 173 510 minecraft:purple_stained_glass
fill 147 173 539 150 177 540 minecraft:obsidian
fill 148 173 538 149 177 538 minecraft:obsidian
fill 148 173 541 149 177 541 minecraft:obsidian
fill 151 173 523 151 177 524 minecraft:green_terracotta
fill 151 173 536 151 177 537 minecraft:lime_terracotta
fill 153 173 521 153 177 521 minecraft:green_terracotta
fill 153 173 526 153 177 526 minecraft:green_terracotta
fill 153 173 534 153 177 534 minecraft:lime_terracotta
fill 153 173 539 153 177 539 minecraft:lime_terracotta
fill 155 173 520 156 176 520 minecraft:green_terracotta
fill 155 173 527 156 174 527 minecraft:green_terracotta
fill 155 173 533 156 174 533 minecraft:lime_terracotta
fill 155 173 540 156 176 540 minecraft:lime_terracotta
setblock 155 173 552 minecraft:purple_stained_glass
setblock 161 173 510 minecraft:purple_stained_glass
fill 166 173 520 167 176 520 minecraft:green_terracotta
fill 166 173 527 167 175 527 minecraft:green_terracotta
fill 166 173 533 167 175 533 minecraft:lime_terracotta
fill 166 173 540 167 176 540 minecraft:lime_terracotta
fill 169 173 521 169 177 521 minecraft:green_terracotta
fill 169 173 526 169 177 526 minecraft:green_terracotta
fill 169 173 534 169 177 534 minecraft:lime_terracotta
fill 169 173 539 169 177 539 minecraft:lime_terracotta
fill 171 173 523 171 177 524 minecraft:green_terracotta
fill 171 173 536 171 177 537 minecraft:lime_terracotta
setblock 171 173 552 minecraft:purple_stained_glass
setblock 177 173 510 minecraft:purple_stained_glass
setblock 183 173 520 minecraft:purple_stained_glass
setblock 183 173 536 minecraft:purple_stained_glass
fill 183 173 541 183 188 541 minecraft:crying_obsidian
fill 183 173 548 183 207 548 minecraft:crying_obsidian
fill 141 174 518 141 179 518 minecraft:crying_obsidian
fill 141 174 534 141 179 534 minecraft:crying_obsidian
fill 141 174 550 141 179 550 minecraft:crying_obsidian
fill 145 174 510 145 179 510 minecraft:crying_obsidian
fill 147 174 538 147 177 538 minecraft:obsidian
fill 147 174 541 147 177 541 minecraft:obsidian
fill 150 174 538 150 177 538 minecraft:obsidian
fill 150 174 541 150 177 541 minecraft:obsidian
fill 151 174 522 151 176 522 minecraft:green_terracotta
fill 151 174 525 151 176 525 minecraft:green_terracotta
fill 151 174 535 151 176 535 minecraft:lime_terracotta
fill 151 174 538 151 176 538 minecraft:lime_terracotta
fill 151 174 539 151 177 540 minecraft:obsidian
fill 152 174 521 152 175 521 minecraft:green_terracotta
fill 152 174 526 152 175 526 minecraft:green_terracotta
fill 152 174 534 152 175 534 minecraft:lime_terracotta
fill 152 174 539 152 175 539 minecraft:lime_terracotta
fill 155 174 552 155 179 552 minecraft:crying_obsidian
setblock 160 174 527 minecraft:green_terracotta
setblock 160 174 533 minecraft:lime_terracotta
fill 161 174 510 161 179 510 minecraft:crying_obsidian
setblock 162 174 527 minecraft:green_terracotta
setblock 162 174 533 minecraft:lime_terracotta
fill 170 174 521 170 175 521 minecraft:green_terracotta
fill 170 174 526 170 175 526 minecraft:green_terracotta
fill 170 174 534 170 175 534 minecraft:lime_terracotta
fill 170 174 539 170 175 539 minecraft:lime_terracotta
fill 171 174 522 171 176 522 minecraft:green_terracotta
fill 171 174 525 171 176 525 minecraft:green_terracotta
fill 171 174 535 171 176 535 minecraft:lime_terracotta
fill 171 174 538 171 176 538 minecraft:lime_terracotta
fill 171 174 552 171 179 552 minecraft:crying_obsidian
fill 177 174 510 177 179 510 minecraft:crying_obsidian
fill 183 174 520 183 178 520 minecraft:crying_obsidian
setblock 183 174 524 minecraft:white_concrete
fill 183 174 525 183 179 529 minecraft:crying_obsidian
fill 183 174 536 183 179 536 minecraft:crying_obsidian
setblock 142 175 510 minecraft:amethyst_block
setblock 144 175 513 minecraft:light[level=12]
setblock 144 175 521 minecraft:light[level=12]
setblock 144 175 529 minecraft:light[level=12]
setblock 144 175 537 minecraft:light[level=12]
setblock 144 175 545 minecraft:light[level=12]
fill 146 175 539 146 177 540 minecraft:obsidian
setblock 147 175 510 minecraft:white_concrete
fill 148 175 537 150 177 537 minecraft:obsidian
fill 148 175 542 150 177 542 minecraft:obsidian
fill 151 175 541 151 177 541 minecraft:obsidian
setblock 152 175 513 minecraft:light[level=12]
setblock 152 175 529 minecraft:light[level=12]
setblock 152 175 545 minecraft:light[level=12]
fill 155 175 527 155 177 527 minecraft:white_concrete
fill 155 175 533 155 177 533 minecraft:white_concrete
fill 156 175 527 158 177 527 minecraft:green_terracotta
fill 156 175 533 158 177 533 minecraft:lime_terracotta
fill 159 175 527 159 177 528 minecraft:white_concrete
fill 159 175 532 159 177 533 minecraft:white_concrete
setblock 160 175 513 minecraft:light[level=12]
setblock 160 175 545 minecraft:light[level=12]
fill 163 175 527 164 176 527 minecraft:green_terracotta
fill 163 175 533 164 176 533 minecraft:lime_terracotta
fill 165 175 527 165 177 528 minecraft:white_concrete
fill 165 175 532 165 177 533 minecraft:white_concrete
setblock 168 175 513 minecraft:light[level=12]
fill 168 175 527 168 177 527 minecraft:white_concrete
setblock 168 175 529 minecraft:light[level=12]
fill 168 175 533 168 177 533 minecraft:white_concrete
setblock 168 175 545 minecraft:light[level=12]
setblock 176 175 513 minecraft:light[level=12]
setblock 176 175 521 minecraft:light[level=12]
setblock 176 175 529 minecraft:light[level=12]
setblock 176 175 537 minecraft:light[level=12]
setblock 176 175 545 minecraft:light[level=12]
fill 183 175 524 183 206 524 minecraft:crying_obsidian
fill 142 176 510 142 187 510 minecraft:crying_obsidian
fill 146 176 538 146 177 538 minecraft:obsidian
fill 146 176 541 146 177 541 minecraft:obsidian
fill 147 176 510 147 206 510 minecraft:crying_obsidian
fill 147 176 537 147 177 537 minecraft:obsidian
fill 147 176 542 147 177 542 minecraft:obsidian
fill 152 176 539 152 177 540 minecraft:obsidian
fill 153 176 527 153 177 527 minecraft:crying_obsidian
fill 154 176 527 154 177 527 minecraft:white_concrete
fill 154 176 533 154 177 533 minecraft:white_concrete
fill 155 176 528 155 177 528 minecraft:white_concrete
fill 155 176 532 155 177 532 minecraft:white_concrete
setblock 158 176 552 minecraft:white_concrete
fill 160 176 527 160 177 528 minecraft:white_concrete
fill 160 176 532 160 177 533 minecraft:white_concrete
fill 166 176 527 166 177 528 minecraft:white_concrete
fill 166 176 532 166 177 533 minecraft:white_concrete
setblock 167 176 527 minecraft:green_terracotta
setblock 167 176 533 minecraft:lime_terracotta
fill 168 176 528 168 177 528 minecraft:white_concrete
fill 168 176 532 168 177 532 minecraft:white_concrete
setblock 183 176 511 minecraft:white_concrete
setblock 141 177 515 minecraft:amethyst_block
setblock 141 177 545 minecraft:white_concrete
setblock 146 177 537 minecraft:obsidian
setblock 146 177 542 minecraft:obsidian
fill 148 177 536 150 177 536 minecraft:obsidian
fill 148 177 543 150 177 543 minecraft:obsidian
setblock 151 177 538 minecraft:obsidian
setblock 151 177 542 minecraft:obsidian
setblock 152 177 541 minecraft:obsidian
setblock 154 177 528 minecraft:white_concrete
setblock 154 177 532 minecraft:white_concrete
setblock 156 177 510 minecraft:white_concrete
setblock 156 177 520 minecraft:green_terracotta
setblock 156 177 540 minecraft:lime_terracotta
fill 158 177 552 158 187 552 minecraft:crying_obsidian
fill 164 177 527 164 178 527 minecraft:green_terracotta
fill 164 177 533 164 178 533 minecraft:lime_terracotta
setblock 166 177 520 minecraft:green_terracotta
setblock 166 177 540 minecraft:lime_terracotta
fill 183 177 511 183 206 511 minecraft:crying_obsidian
fill 141 178 515 141 206 515 minecraft:crying_obsidian
fill 141 178 545 141 202 545 minecraft:crying_obsidian
fill 148 178 539 149 179 540 minecraft:amethyst_block
fill 152 178 523 152 178 524 minecraft:green_terracotta
fill 152 178 536 152 178 537 minecraft:lime_terracotta
fill 156 178 510 156 207 510 minecraft:crying_obsidian
fill 157 178 527 158 178 527 minecraft:green_terracotta
fill 157 178 533 158 178 533 minecraft:lime_terracotta
fill 158 178 526 160 178 526 minecraft:green_terracotta
fill 158 178 534 160 178 534 minecraft:lime_terracotta
fill 162 178 526 164 178 526 minecraft:green_terracotta
fill 162 178 534 164 178 534 minecraft:lime_terracotta
setblock 165 178 527 minecraft:green_terracotta
setblock 165 178 533 minecraft:lime_terracotta
setblock 169 178 522 minecraft:green_terracotta
setblock 169 178 525 minecraft:green_terracotta
setblock 169 178 535 minecraft:lime_terracotta
setblock 169 178 538 minecraft:lime_terracotta
fill 156 179 521 157 179 521 minecraft:green_terracotta
fill 156 179 526 159 179 526 minecraft:green_terracotta
fill 156 179 534 159 179 534 minecraft:lime_terracotta
fill 156 179 539 157 179 539 minecraft:lime_terracotta
fill 163 179 526 166 179 526 minecraft:green_terracotta
fill 163 179 534 166 179 534 minecraft:lime_terracotta
fill 165 179 521 166 179 521 minecraft:green_terracotta
fill 165 179 539 166 179 539 minecraft:lime_terracotta
setblock 183 179 520 minecraft:white_concrete
fill 141 180 518 141 182 518 minecraft:purple_stained_glass
fill 141 180 534 141 182 534 minecraft:purple_stained_glass
setblock 141 180 538 minecraft:white_concrete
fill 141 180 550 141 182 550 minecraft:purple_stained_glass
fill 145 180 510 145 182 510 minecraft:purple_stained_glass
fill 149 180 539 149 180 540 minecraft:amethyst_block
fill 155 180 523 156 180 524 minecraft:green_terracotta
fill 155 180 536 156 180 537 minecraft:lime_terracotta
fill 155 180 552 155 182 552 minecraft:purple_stained_glass
setblock 156 180 522 minecraft:green_terracotta
setblock 156 180 525 minecraft:green_terracotta
setblock 156 180 535 minecraft:lime_terracotta
setblock 156 180 538 minecraft:lime_terracotta
fill 159 180 521 163 180 521 minecraft:green_terracotta
fill 159 180 539 163 180 539 minecraft:lime_terracotta
fill 161 180 510 161 182 510 minecraft:purple_stained_glass
fill 164 180 522 166 180 522 minecraft:green_terracotta
fill 164 180 525 166 180 525 minecraft:green_terracotta
fill 164 180 535 166 180 535 minecraft:lime_terracotta
fill 164 180 538 166 180 538 minecraft:lime_terracotta
setblock 166 180 523 minecraft:green_terracotta
fill 166 180 524 168 181 524 minecraft:pearlescent_froglight
fill 166 180 536 168 181 536 minecraft:pearlescent_froglight
setblock 166 180 537 minecraft:lime_terracotta
fill 167 180 523 167 181 523 minecraft:pearlescent_froglight
fill 167 180 525 167 181 525 minecraft:pearlescent_froglight
fill 167 180 535 167 181 535 minecraft:pearlescent_froglight
fill 167 180 537 167 181 537 minecraft:pearlescent_froglight
fill 171 180 552 171 182 552 minecraft:purple_stained_glass
setblock 173 180 552 minecraft:white_concrete
fill 174 180 552 176 197 552 minecraft:crying_obsidian
fill 177 180 510 177 182 510 minecraft:purple_stained_glass
fill 183 180 520 183 182 520 minecraft:purple_stained_glass
fill 183 180 525 183 202 526 minecraft:crying_obsidian
setblock 183 180 527 minecraft:white_concrete
fill 183 180 528 183 192 529 minecraft:crying_obsidian
fill 183 180 536 183 182 536 minecraft:purple_stained_glass
fill 141 181 538 141 206 538 minecraft:crying_obsidian
setblock 149 181 539 minecraft:amethyst_block
fill 158 181 523 164 181 524 minecraft:green_terracotta
fill 158 181 536 164 181 537 minecraft:lime_terracotta
fill 173 181 552 173 202 552 minecraft:crying_obsidian
fill 183 181 527 183 204 527 minecraft:crying_obsidian
fill 174 182 519 174 183 520 minecraft:obsidian
fill 141 183 518 141 188 518 minecraft:crying_obsidian
fill 141 183 534 141 188 534 minecraft:crying_obsidian
fill 141 183 550 141 188 550 minecraft:crying_obsidian
setblock 144 183 513 minecraft:light[level=12]
setblock 144 183 521 minecraft:light[level=12]
setblock 144 183 529 minecraft:light[level=12]
setblock 144 183 537 minecraft:light[level=12]
setblock 144 183 545 minecraft:light[level=12]
fill 145 183 510 145 188 510 minecraft:crying_obsidian
setblock 152 183 513 minecraft:light[level=12]
setblock 152 183 521 minecraft:light[level=12]
setblock 152 183 529 minecraft:light[level=12]
setblock 152 183 537 minecraft:light[level=12]
setblock 152 183 545 minecraft:light[level=12]
fill 155 183 552 155 188 552 minecraft:crying_obsidian
setblock 160 183 513 minecraft:light[level=12]
setblock 160 183 521 minecraft:light[level=12]
setblock 160 183 537 minecraft:light[level=12]
setblock 160 183 545 minecraft:light[level=12]
fill 161 183 510 161 188 510 minecraft:crying_obsidian
setblock 168 183 513 minecraft:light[level=12]
setblock 168 183 521 minecraft:light[level=12]
setblock 168 183 529 minecraft:light[level=12]
setblock 168 183 537 minecraft:light[level=12]
setblock 168 183 545 minecraft:light[level=12]
fill 171 183 552 171 188 552 minecraft:crying_obsidian
setblock 176 183 513 minecraft:light[level=12]
setblock 176 183 521 minecraft:light[level=12]
setblock 176 183 529 minecraft:light[level=12]
setblock 176 183 537 minecraft:light[level=12]
setblock 176 183 545 minecraft:light[level=12]
fill 177 183 510 177 188 510 minecraft:crying_obsidian
fill 183 183 520 183 188 520 minecraft:crying_obsidian
fill 183 183 536 183 188 536 minecraft:crying_obsidian
setblock 141 184 528 minecraft:amethyst_block
fill 141 185 528 141 206 528 minecraft:crying_obsidian
setblock 150 185 552 minecraft:amethyst_block
fill 151 185 552 152 198 552 minecraft:crying_obsidian
fill 150 186 552 150 206 552 minecraft:crying_obsidian
setblock 180 186 552 minecraft:white_concrete
fill 180 187 552 180 206 552 minecraft:crying_obsidian
setblock 183 187 516 minecraft:white_concrete
setblock 141 188 546 minecraft:white_concrete
setblock 141 188 547 minecraft:amethyst_block
setblock 142 188 510 minecraft:white_concrete
setblock 158 188 552 minecraft:white_concrete
fill 183 188 516 183 206 516 minecraft:crying_obsidian
fill 141 189 518 141 191 518 minecraft:purple_stained_glass
fill 141 189 534 141 191 534 minecraft:purple_stained_glass
fill 141 189 546 141 204 547 minecraft:crying_obsidian
fill 141 189 550 141 191 550 minecraft:purple_stained_glass
fill 142 189 510 142 206 510 minecraft:crying_obsidian
fill 145 189 510 145 191 510 minecraft:purple_stained_glass
fill 155 189 552 155 191 552 minecraft:purple_stained_glass
fill 158 189 552 158 206 552 minecraft:crying_obsidian
setblock 159 189 510 minecraft:white_concrete
fill 161 189 510 161 191 510 minecraft:purple_stained_glass
fill 171 189 552 171 191 552 minecraft:purple_stained_glass
fill 177 189 510 177 191 510 minecraft:purple_stained_glass
fill 183 189 520 183 191 520 minecraft:purple_stained_glass
fill 183 189 536 183 191 536 minecraft:purple_stained_glass
setblock 183 189 541 minecraft:white_concrete
fill 159 190 510 159 203 510 minecraft:crying_obsidian
setblock 182 190 552 minecraft:amethyst_block
fill 183 190 541 183 206 541 minecraft:crying_obsidian
setblock 144 191 513 minecraft:light[level=12]
setblock 144 191 521 minecraft:light[level=12]
setblock 144 191 529 minecraft:light[level=12]
setblock 144 191 537 minecraft:light[level=12]
setblock 144 191 545 minecraft:light[level=12]
setblock 152 191 513 minecraft:light[level=12]
setblock 152 191 521 minecraft:light[level=12]
setblock 152 191 529 minecraft:light[level=12]
setblock 152 191 537 minecraft:light[level=12]
setblock 152 191 545 minecraft:light[level=12]
setblock 160 191 513 minecraft:light[level=12]
setblock 160 191 521 minecraft:light[level=12]
setblock 160 191 537 minecraft:light[level=12]
setblock 160 191 545 minecraft:light[level=12]
setblock 168 191 513 minecraft:light[level=12]
setblock 168 191 521 minecraft:light[level=12]
setblock 168 191 529 minecraft:light[level=12]
setblock 168 191 537 minecraft:light[level=12]
setblock 168 191 545 minecraft:light[level=12]
fill 169 191 544 169 192 544 minecraft:amethyst_block
setblock 176 191 513 minecraft:light[level=12]
setblock 176 191 521 minecraft:light[level=12]
setblock 176 191 529 minecraft:light[level=12]
setblock 176 191 537 minecraft:light[level=12]
setblock 176 191 545 minecraft:light[level=12]
fill 182 191 552 182 206 552 minecraft:crying_obsidian
fill 141 192 518 141 196 518 minecraft:crying_obsidian
fill 141 192 534 141 197 534 minecraft:crying_obsidian
setblock 141 192 550 minecraft:amethyst_block
fill 142 192 513 147 192 513 minecraft:amethyst_block
fill 145 192 510 145 197 510 minecraft:crying_obsidian
setblock 146 192 552 minecraft:amethyst_block
fill 155 192 552 155 197 552 minecraft:crying_obsidian
fill 161 192 510 161 197 510 minecraft:crying_obsidian
fill 171 192 552 171 197 552 minecraft:crying_obsidian
fill 177 192 510 177 197 510 minecraft:crying_obsidian
setblock 182 192 510 minecraft:amethyst_block
fill 183 192 520 183 197 520 minecraft:crying_obsidian
fill 183 192 536 183 197 536 minecraft:crying_obsidian
fill 141 193 550 141 197 550 minecraft:crying_obsidian
fill 142 193 512 145 193 514 minecraft:amethyst_block
setblock 146 193 513 minecraft:amethyst_block
fill 146 193 552 146 206 552 minecraft:crying_obsidian
setblock 154 193 510 minecraft:amethyst_block
fill 169 193 544 169 202 544 minecraft:obsidian
fill 171 193 525 172 194 526 minecraft:obsidian
fill 182 193 510 182 206 510 minecraft:crying_obsidian
setblock 183 193 528 minecraft:white_concrete
fill 183 193 529 183 202 529 minecraft:crying_obsidian
setblock 141 194 512 minecraft:white_concrete
fill 142 194 512 143 194 514 minecraft:amethyst_block
setblock 144 194 513 minecraft:amethyst_block
fill 154 194 510 154 206 510 minecraft:crying_obsidian
fill 169 194 545 169 202 545 minecraft:obsidian
setblock 170 194 552 minecraft:amethyst_block
fill 183 194 528 183 206 528 minecraft:crying_obsidian
fill 141 195 512 141 206 512 minecraft:crying_obsidian
setblock 142 195 513 minecraft:amethyst_block
fill 168 195 544 168 202 545 minecraft:obsidian
fill 169 195 543 169 202 543 minecraft:obsidian
fill 170 195 544 170 202 545 minecraft:obsidian
fill 170 195 552 170 202 552 minecraft:crying_obsidian
fill 171 195 529 172 196 530 minecraft:obsidian
setblock 141 196 529 minecraft:white_concrete
fill 143 196 532 144 196 532 minecraft:crying_obsidian
fill 168 196 543 168 202 543 minecraft:obsidian
fill 169 196 546 169 202 546 minecraft:obsidian
fill 170 196 543 170 202 543 minecraft:obsidian
setblock 141 197 518 minecraft:amethyst_block
fill 141 197 529 141 206 529 minecraft:crying_obsidian
setblock 143 197 532 minecraft:crying_obsidian
fill 144 197 527 145 198 535 minecraft:obsidian
fill 145 197 524 146 198 526 minecraft:obsidian
fill 145 197 536 146 198 538 minecraft:obsidian
fill 146 197 522 147 198 523 minecraft:obsidian
fill 146 197 539 147 198 540 minecraft:obsidian
fill 147 197 521 148 198 521 minecraft:obsidian
fill 147 197 524 147 198 524 minecraft:obsidian
fill 147 197 538 147 198 538 minecraft:obsidian
fill 147 197 541 148 198 541 minecraft:obsidian
fill 148 197 519 149 198 520 minecraft:obsidian
fill 148 197 522 148 198 522 minecraft:obsidian
fill 148 197 540 148 198 540 minecraft:obsidian
fill 148 197 542 149 198 543 minecraft:obsidian
fill 149 197 518 151 198 518 minecraft:obsidian
fill 149 197 544 151 198 544 minecraft:obsidian
fill 150 197 517 153 198 517 minecraft:obsidian
fill 150 197 519 150 198 519 minecraft:obsidian
fill 150 197 543 150 198 543 minecraft:obsidian
fill 150 197 545 153 198 545 minecraft:obsidian
fill 152 197 516 155 198 516 minecraft:obsidian
fill 152 197 546 155 198 546 minecraft:obsidian
fill 153 197 515 157 198 515 minecraft:obsidian
fill 153 197 547 157 198 547 minecraft:obsidian
fill 155 197 514 169 198 514 minecraft:obsidian
fill 155 197 548 169 198 548 minecraft:obsidian
fill 158 197 513 166 198 513 minecraft:obsidian
fill 158 197 549 166 198 549 minecraft:obsidian
fill 167 197 515 171 198 515 minecraft:obsidian
fill 167 197 543 167 202 545 minecraft:obsidian
fill 167 197 547 171 198 547 minecraft:obsidian
fill 168 197 542 170 202 542 minecraft:obsidian
fill 168 197 546 168 202 546 minecraft:obsidian
fill 169 197 516 172 198 516 minecraft:obsidian
fill 170 197 546 172 198 546 minecraft:obsidian
fill 171 197 517 174 198 517 minecraft:obsidian
fill 171 197 543 171 202 545 minecraft:obsidian
setblock 172 197 510 minecraft:amethyst_block
fill 172 197 545 174 198 545 minecraft:obsidian
fill 173 197 518 175 198 518 minecraft:obsidian
fill 173 197 544 175 198 544 minecraft:obsidian
fill 174 197 519 176 198 519 minecraft:obsidian
fill 174 197 543 176 198 543 minecraft:obsidian
fill 175 197 520 176 198 520 minecraft:obsidian
fill 175 197 542 176 198 542 minecraft:obsidian
fill 176 197 521 177 198 522 minecraft:obsidian
fill 176 197 540 177 198 541 minecraft:obsidian
fill 177 197 523 178 198 524 minecraft:obsidian
fill 177 197 538 178 198 539 minecraft:obsidian
fill 178 197 522 178 198 522 minecraft:obsidian
fill 178 197 525 179 198 526 minecraft:obsidian
fill 178 197 536 179 198 537 minecraft:obsidian
fill 178 197 540 178 198 540 minecraft:obsidian
fill 179 197 524 179 198 524 minecraft:obsidian
fill 179 197 527 180 198 535 minecraft:obsidian
fill 179 197 538 179 198 538 minecraft:obsidian
setblock 183 197 535 minecraft:amethyst_block
setblock 183 197 537 minecraft:amethyst_block
fill 141 198 518 141 200 518 minecraft:purple_stained_glass
fill 141 198 534 141 200 534 minecraft:purple_stained_glass
fill 141 198 550 141 200 550 minecraft:purple_stained_glass
fill 145 198 510 145 200 510 minecraft:purple_stained_glass
fill 155 198 552 155 200 552 minecraft:purple_stained_glass
fill 161 198 510 161 200 510 minecraft:purple_stained_glass
fill 167 198 546 167 202 546 minecraft:obsidian
fill 171 198 552 171 200 552 minecraft:purple_stained_glass
fill 172 198 510 172 206 510 minecraft:crying_obsidian
setblock 174 198 552 minecraft:white_concrete
fill 175 198 552 176 206 552 minecraft:crying_obsidian
fill 177 198 510 177 200 510 minecraft:purple_stained_glass
fill 183 198 520 183 200 520 minecraft:purple_stained_glass
fill 183 198 535 183 206 535 minecraft:crying_obsidian
fill 183 198 536 183 200 536 minecraft:purple_stained_glass
fill 183 198 537 183 199 537 minecraft:crying_obsidian
setblock 144 199 513 minecraft:light[level=12]
setblock 144 199 521 minecraft:light[level=12]
fill 144 199 527 144 199 535 minecraft:crying_obsidian
setblock 144 199 537 minecraft:light[level=12]
setblock 144 199 545 minecraft:light[level=12]
fill 145 199 524 145 199 526 minecraft:crying_obsidian
fill 145 199 536 145 199 538 minecraft:crying_obsidian
fill 146 199 522 146 199 523 minecraft:crying_obsidian
fill 146 199 539 146 199 540 minecraft:crying_obsidian
setblock 147 199 521 minecraft:crying_obsidian
setblock 147 199 541 minecraft:crying_obsidian
fill 148 199 519 148 199 520 minecraft:crying_obsidian
fill 148 199 542 148 199 543 minecraft:crying_obsidian
fill 149 199 518 149 199 519 minecraft:crying_obsidian
fill 149 199 543 149 199 544 minecraft:crying_obsidian
setblock 150 199 510 minecraft:amethyst_block
fill 150 199 517 150 199 518 minecraft:crying_obsidian
fill 150 199 544 150 199 545 minecraft:crying_obsidian
fill 151 199 510 153 202 510 minecraft:crying_obsidian
setblock 151 199 517 minecraft:crying_obsidian
setblock 151 199 545 minecraft:crying_obsidian
setblock 151 199 552 minecraft:amethyst_block
setblock 152 199 513 minecraft:light[level=12]
setblock 152 199 516 minecraft:crying_obsidian
setblock 152 199 521 minecraft:light[level=12]
setblock 152 199 529 minecraft:light[level=12]
setblock 152 199 537 minecraft:light[level=12]
setblock 152 199 545 minecraft:light[level=12]
fill 152 199 552 152 206 552 minecraft:crying_obsidian
fill 153 199 515 154 199 515 minecraft:crying_obsidian
setblock 154 199 552 minecraft:white_concrete
fill 155 199 514 157 199 514 minecraft:crying_obsidian
fill 158 199 513 166 199 513 minecraft:crying_obsidian
setblock 160 199 521 minecraft:light[level=12]
setblock 160 199 537 minecraft:light[level=12]
setblock 160 199 545 minecraft:light[level=12]
fill 166 199 543 166 202 545 minecraft:obsidian
fill 167 199 514 169 199 514 minecraft:crying_obsidian
fill 167 199 542 167 202 542 minecraft:obsidian
setblock 168 199 513 minecraft:light[level=12]
setblock 168 199 521 minecraft:light[level=12]
setblock 168 199 529 minecraft:light[level=12]
setblock 168 199 537 minecraft:light[level=12]
fill 168 199 541 170 202 541 minecraft:obsidian
fill 168 199 547 170 202 547 minecraft:obsidian
fill 170 199 515 171 199 515 minecraft:crying_obsidian
fill 170 199 546 171 202 546 minecraft:obsidian
fill 171 199 542 171 202 542 minecraft:obsidian
setblock 172 199 516 minecraft:crying_obsidian
fill 172 199 543 172 202 545 minecraft:obsidian
fill 173 199 517 174 199 517 minecraft:crying_obsidian
fill 174 199 518 175 199 518 minecraft:crying_obsidian
fill 174 199 552 174 206 552 minecraft:crying_obsidian
fill 175 199 519 176 199 519 minecraft:crying_obsidian
setblock 176 199 513 minecraft:light[level=12]
setblock 176 199 520 minecraft:crying_obsidian
setblock 176 199 521 minecraft:light[level=12]
setblock 176 199 529 minecraft:light[level=12]
setblock 176 199 537 minecraft:light[level=12]
setblock 176 199 545 minecraft:light[level=12]
setblock 177 199 521 minecraft:crying_obsidian
fill 178 199 522 178 199 523 minecraft:crying_obsidian
fill 179 199 524 179 199 525 minecraft:crying_obsidian
setblock 183 199 515 minecraft:amethyst_block
fill 150 200 510 150 202 510 minecraft:crying_obsidian
fill 151 200 552 151 206 552 minecraft:crying_obsidian
fill 154 200 552 154 202 552 minecraft:crying_obsidian
fill 166 200 542 166 202 542 minecraft:obsidian
fill 166 200 546 166 202 546 minecraft:obsidian
fill 167 200 541 167 202 541 minecraft:obsidian
fill 167 200 547 167 202 547 minecraft:obsidian
fill 169 200 548 169 202 548 minecraft:obsidian
fill 171 200 541 171 202 541 minecraft:obsidian
fill 171 200 547 171 202 547 minecraft:obsidian
fill 172 200 542 172 202 542 minecraft:obsidian
fill 172 200 546 172 202 546 minecraft:obsidian
fill 183 200 515 183 206 515 minecraft:crying_obsidian
setblock 183 200 523 minecraft:amethyst_block
setblock 183 200 537 minecraft:amethyst_block
setblock 141 201 517 minecraft:amethyst_block
fill 141 201 518 141 202 518 minecraft:crying_obsidian
fill 141 201 534 141 206 534 minecraft:crying_obsidian
fill 141 201 550 141 206 550 minecraft:crying_obsidian
fill 145 201 510 145 204 510 minecraft:crying_obsidian
fill 155 201 552 155 206 552 minecraft:crying_obsidian
fill 161 201 510 161 202 510 minecraft:crying_obsidian
setblock 162 201 552 minecraft:white_concrete
fill 165 201 543 165 202 546 minecraft:obsidian
fill 166 201 541 166 202 541 minecraft:obsidian
fill 166 201 547 166 202 547 minecraft:obsidian
fill 167 201 548 168 202 548 minecraft:obsidian
fill 168 201 540 170 202 540 minecraft:obsidian
fill 170 201 548 171 202 548 minecraft:obsidian
fill 171 201 552 171 203 552 minecraft:crying_obsidian
fill 172 201 547 172 202 547 minecraft:obsidian
fill 173 201 543 173 202 545 minecraft:obsidian
fill 177 201 510 177 204 510 minecraft:crying_obsidian
fill 183 201 520 183 206 520 minecraft:crying_obsidian
fill 183 201 523 183 204 523 minecraft:crying_obsidian
fill 183 201 536 183 202 537 minecraft:crying_obsidian
fill 141 202 517 141 206 517 minecraft:crying_obsidian
setblock 160 202 552 minecraft:amethyst_block
fill 162 202 552 162 206 552 minecraft:crying_obsidian
setblock 165 202 542 minecraft:obsidian
setblock 166 202 548 minecraft:obsidian
setblock 167 202 540 minecraft:obsidian
setblock 169 202 549 minecraft:obsidian
setblock 171 202 540 minecraft:obsidian
setblock 172 202 541 minecraft:obsidian
setblock 173 202 542 minecraft:obsidian
setblock 173 202 546 minecraft:obsidian
setblock 141 203 518 minecraft:obsidian
fill 141 203 521 141 204 522 minecraft:obsidian
setblock 141 203 545 minecraft:obsidian
setblock 144 203 510 minecraft:obsidian
setblock 150 203 510 minecraft:obsidian
fill 151 203 510 152 206 510 minecraft:crying_obsidian
setblock 153 203 510 minecraft:obsidian
setblock 154 203 552 minecraft:white_concrete
fill 160 203 552 160 207 552 minecraft:crying_obsidian
fill 161 203 510 162 203 510 minecraft:obsidian
setblock 167 203 510 minecraft:white_concrete
fill 168 203 544 169 203 545 minecraft:amethyst_block
setblock 169 203 543 minecraft:amethyst_block
fill 170 203 544 170 204 544 minecraft:amethyst_block
setblock 170 203 552 minecraft:obsidian
setblock 173 203 552 minecraft:white_concrete
setblock 176 203 510 minecraft:obsidian
setblock 178 203 510 minecraft:obsidian
setblock 183 203 518 minecraft:obsidian
fill 183 203 525 183 206 525 minecraft:crying_obsidian
setblock 183 203 526 minecraft:obsidian
setblock 183 203 529 minecraft:obsidian
fill 183 203 536 183 206 536 minecraft:crying_obsidian
setblock 183 203 537 minecraft:obsidian
setblock 183 203 546 minecraft:obsidian
setblock 141 204 518 minecraft:crying_obsidian
setblock 141 204 527 minecraft:obsidian
fill 141 204 545 141 206 545 minecraft:crying_obsidian
setblock 143 204 552 minecraft:obsidian
fill 144 204 510 144 206 510 minecraft:crying_obsidian
setblock 150 204 510 minecraft:crying_obsidian
fill 153 204 510 153 206 510 minecraft:crying_obsidian
fill 154 204 552 154 206 552 minecraft:crying_obsidian
fill 159 204 510 160 204 510 minecraft:obsidian
setblock 159 204 552 minecraft:obsidian
fill 161 204 510 162 206 510 minecraft:crying_obsidian
fill 163 204 510 164 204 510 minecraft:obsidian
setblock 163 204 552 minecraft:obsidian
setblock 165 204 552 minecraft:obsidian
fill 167 204 510 167 206 510 minecraft:crying_obsidian
fill 168 204 544 169 204 544 minecraft:amethyst_block
setblock 169 204 545 minecraft:amethyst_block
fill 170 204 552 170 206 552 minecraft:crying_obsidian
setblock 171 204 552 minecraft:white_concrete
fill 173 204 552 173 206 552 minecraft:crying_obsidian
setblock 174 204 510 minecraft:obsidian
fill 176 204 510 176 206 510 minecraft:crying_obsidian
fill 178 204 510 178 206 510 minecraft:crying_obsidian
setblock 179 204 552 minecraft:obsidian
fill 180 204 510 181 204 510 minecraft:obsidian
fill 183 204 518 183 206 518 minecraft:crying_obsidian
fill 183 204 526 183 206 526 minecraft:crying_obsidian
fill 183 204 529 183 206 529 minecraft:crying_obsidian
fill 183 204 533 183 205 533 minecraft:obsidian
fill 183 204 537 183 206 537 minecraft:crying_obsidian
fill 183 204 546 183 206 546 minecraft:crying_obsidian
setblock 141 205 513 minecraft:obsidian
setblock 141 205 518 minecraft:obsidian
setblock 141 205 521 minecraft:obsidian
fill 141 205 522 141 207 522 minecraft:crying_obsidian
fill 141 205 525 141 206 525 minecraft:crying_obsidian
setblock 141 205 526 minecraft:obsidian
fill 141 205 527 141 206 527 minecraft:crying_obsidian
setblock 141 205 530 minecraft:obsidian
fill 141 205 536 141 205 537 minecraft:obsidian
fill 141 205 546 141 206 546 minecraft:crying_obsidian
setblock 141 205 547 minecraft:obsidian
fill 143 205 552 143 206 552 minecraft:crying_obsidian
setblock 145 205 510 minecraft:obsidian
setblock 150 205 510 minecraft:obsidian
fill 159 205 510 160 206 510 minecraft:crying_obsidian
fill 159 205 552 159 206 552 minecraft:crying_obsidian
fill 163 205 510 164 206 510 minecraft:crying_obsidian
fill 163 205 552 163 206 552 minecraft:crying_obsidian
fill 165 205 552 165 207 552 minecraft:crying_obsidian
fill 166 205 552 167 205 552 minecraft:obsidian
fill 168 205 552 168 206 552 minecraft:crying_obsidian
setblock 169 205 510 minecraft:obsidian
fill 169 205 544 169 207 544 minecraft:amethyst_block
setblock 171 205 510 minecraft:obsidian
fill 171 205 552 171 206 552 minecraft:crying_obsidian
fill 174 205 510 174 206 510 minecraft:crying_obsidian
setblock 177 205 510 minecraft:obsidian
fill 179 205 552 179 206 552 minecraft:crying_obsidian
fill 180 205 510 180 206 510 minecraft:crying_obsidian
setblock 181 205 510 minecraft:obsidian
setblock 181 205 552 minecraft:obsidian
setblock 183 205 519 minecraft:obsidian
setblock 183 205 521 minecraft:obsidian
setblock 183 205 523 minecraft:obsidian
setblock 183 205 527 minecraft:obsidian
setblock 183 205 550 minecraft:obsidian
fill 141 206 513 141 207 513 minecraft:crying_obsidian
setblock 141 206 518 minecraft:crying_obsidian
setblock 141 206 521 minecraft:crying_obsidian
setblock 141 206 526 minecraft:crying_obsidian
setblock 141 206 530 minecraft:crying_obsidian
fill 141 206 536 141 206 537 minecraft:crying_obsidian
setblock 141 206 547 minecraft:crying_obsidian
setblock 145 206 510 minecraft:crying_obsidian
setblock 150 206 510 minecraft:crying_obsidian
fill 166 206 552 167 206 552 minecraft:crying_obsidian
setblock 169 206 510 minecraft:crying_obsidian
setblock 171 206 510 minecraft:crying_obsidian
setblock 177 206 510 minecraft:crying_obsidian
setblock 181 206 510 minecraft:crying_obsidian
setblock 181 206 552 minecraft:crying_obsidian
setblock 183 206 519 minecraft:crying_obsidian
setblock 183 206 521 minecraft:crying_obsidian
setblock 183 206 523 minecraft:crying_obsidian
setblock 183 206 527 minecraft:crying_obsidian
setblock 183 206 533 minecraft:crying_obsidian
fill 183 206 550 183 207 550 minecraft:crying_obsidian
fill 141 207 510 144 207 510 minecraft:obsidian
setblock 141 207 511 minecraft:crying_obsidian
fill 141 207 512 141 279 512 minecraft:obsidian
fill 141 207 514 141 208 517 minecraft:obsidian
fill 141 207 518 141 209 518 minecraft:purple_stained_glass
fill 141 207 519 141 208 521 minecraft:obsidian
fill 141 207 523 141 221 527 minecraft:obsidian
setblock 141 207 528 minecraft:white_concrete
fill 141 207 529 141 207 533 minecraft:obsidian
fill 141 207 534 141 209 534 minecraft:purple_stained_glass
fill 141 207 535 141 233 536 minecraft:obsidian
setblock 141 207 537 minecraft:crying_obsidian
fill 141 207 538 141 208 538 minecraft:obsidian
fill 141 207 540 141 207 549 minecraft:obsidian
fill 141 207 550 141 209 550 minecraft:purple_stained_glass
fill 141 207 551 141 230 552 minecraft:obsidian
fill 142 207 552 154 207 552 minecraft:obsidian
setblock 144 207 513 minecraft:light[level=12]
setblock 144 207 521 minecraft:light[level=12]
setblock 144 207 529 minecraft:light[level=12]
setblock 144 207 537 minecraft:light[level=12]
setblock 144 207 545 minecraft:light[level=12]
fill 145 207 510 145 209 510 minecraft:purple_stained_glass
fill 146 207 510 150 223 510 minecraft:obsidian
setblock 151 207 510 minecraft:crying_obsidian
fill 152 207 510 154 224 510 minecraft:obsidian
setblock 152 207 513 minecraft:light[level=12]
setblock 152 207 521 minecraft:light[level=12]
setblock 152 207 529 minecraft:light[level=12]
setblock 152 207 537 minecraft:light[level=12]
setblock 152 207 545 minecraft:light[level=12]
fill 155 207 552 155 209 552 minecraft:purple_stained_glass
fill 156 207 552 159 207 552 minecraft:obsidian
fill 157 207 510 160 207 510 minecraft:obsidian
setblock 160 207 513 minecraft:light[level=12]
setblock 160 207 521 minecraft:light[level=12]
setblock 160 207 529 minecraft:light[level=12]
setblock 160 207 537 minecraft:light[level=12]
setblock 160 207 545 minecraft:light[level=12]
fill 161 207 510 161 209 510 minecraft:purple_stained_glass
fill 161 207 552 164 207 552 minecraft:obsidian
fill 162 207 510 163 224 510 minecraft:obsidian
setblock 164 207 510 minecraft:crying_obsidian
fill 165 207 510 176 208 510 minecraft:obsidian
fill 166 207 552 170 207 552 minecraft:obsidian
setblock 168 207 513 minecraft:light[level=12]
setblock 168 207 521 minecraft:light[level=12]
setblock 168 207 529 minecraft:light[level=12]
setblock 168 207 537 minecraft:light[level=12]
setblock 168 207 545 minecraft:light[level=12]
fill 171 207 552 171 209 552 minecraft:purple_stained_glass
fill 172 207 552 182 208 552 minecraft:obsidian
setblock 176 207 513 minecraft:light[level=12]
setblock 176 207 521 minecraft:light[level=12]
setblock 176 207 529 minecraft:light[level=12]
setblock 176 207 537 minecraft:light[level=12]
setblock 176 207 545 minecraft:light[level=12]
fill 177 207 510 177 209 510 minecraft:purple_stained_glass
fill 178 207 510 183 208 510 minecraft:obsidian
fill 183 207 511 183 208 512 minecraft:obsidian
fill 183 207 514 183 214 519 minecraft:obsidian
fill 183 207 520 183 209 520 minecraft:purple_stained_glass
fill 183 207 521 183 207 535 minecraft:obsidian
fill 183 207 536 183 209 536 minecraft:purple_stained_glass
fill 183 207 537 183 257 537 minecraft:obsidian
fill 183 207 539 183 208 543 minecraft:obsidian
fill 183 207 545 183 208 547 minecraft:obsidian
fill 183 207 551 183 307 551 minecraft:obsidian
fill 141 208 510 141 214 511 minecraft:obsidian
fill 141 208 513 141 213 513 minecraft:obsidian
fill 141 208 522 141 307 522 minecraft:obsidian
fill 141 208 528 141 209 532 minecraft:obsidian
setblock 141 208 533 minecraft:crying_obsidian
setblock 141 208 537 minecraft:obsidian
fill 141 208 539 141 208 543 minecraft:obsidian
setblock 141 208 544 minecraft:crying_obsidian
fill 141 208 545 141 208 549 minecraft:obsidian
setblock 142 208 510 minecraft:amethyst_block
fill 142 208 552 142 276 552 minecraft:obsidian
setblock 143 208 510 minecraft:crying_obsidian
setblock 143 208 552 minecraft:crying_obsidian
fill 144 208 510 144 210 510 minecraft:obsidian
fill 144 208 552 152 208 552 minecraft:obsidian
setblock 151 208 510 minecraft:obsidian
fill 153 208 552 153 209 552 minecraft:crying_obsidian
fill 154 208 552 154 235 552 minecraft:obsidian
fill 155 208 510 156 209 510 minecraft:obsidian
fill 156 208 552 157 208 552 minecraft:obsidian
setblock 157 208 510 minecraft:crying_obsidian
fill 158 208 510 160 216 510 minecraft:obsidian
setblock 158 208 552 minecraft:crying_obsidian
fill 159 208 552 161 211 552 minecraft:obsidian
fill 162 208 552 163 208 552 minecraft:crying_obsidian
fill 164 208 510 164 254 510 minecraft:obsidian
fill 164 208 552 168 208 552 minecraft:obsidian
setblock 169 208 552 minecraft:crying_obsidian
fill 170 208 552 170 241 552 minecraft:obsidian
fill 183 208 513 183 240 513 minecraft:obsidian
fill 183 208 521 183 220 527 minecraft:obsidian
setblock 183 208 528 minecraft:crying_obsidian
fill 183 208 529 183 209 530 minecraft:obsidian
fill 183 208 531 183 208 532 minecraft:crying_obsidian
fill 183 208 533 183 307 534 minecraft:obsidian
setblock 183 208 535 minecraft:crying_obsidian
fill 183 208 538 183 220 538 minecraft:obsidian
fill 183 208 544 183 216 544 minecraft:obsidian
fill 183 208 548 183 254 548 minecraft:obsidian
setblock 183 208 550 minecraft:obsidian
fill 183 208 552 183 307 552 minecraft:obsidian
setblock 141 209 514 minecraft:crying_obsidian
fill 141 209 515 141 223 517 minecraft:obsidian
setblock 141 209 519 minecraft:crying_obsidian
fill 141 209 520 141 210 520 minecraft:obsidian
setblock 141 209 521 minecraft:amethyst_block
fill 141 209 533 141 210 533 minecraft:obsidian
setblock 141 209 537 minecraft:amethyst_block
setblock 141 209 538 minecraft:crying_obsidian
fill 141 209 539 141 222 541 minecraft:obsidian
fill 141 209 542 141 209 543 minecraft:crying_obsidian
fill 141 209 544 141 212 547 minecraft:obsidian
fill 141 209 548 141 209 549 minecraft:crying_obsidian
fill 142 209 510 143 232 510 minecraft:obsidian
fill 143 209 552 145 276 552 minecraft:obsidian
setblock 146 209 552 minecraft:crying_obsidian
fill 147 209 552 152 237 552 minecraft:obsidian
setblock 151 209 510 minecraft:crying_obsidian
setblock 156 209 552 minecraft:crying_obsidian
setblock 157 209 510 minecraft:white_concrete
fill 157 209 552 158 234 552 minecraft:obsidian
setblock 162 209 552 minecraft:white_concrete
fill 163 209 552 165 238 552 minecraft:obsidian
fill 165 209 510 169 210 510 minecraft:obsidian
setblock 166 209 552 minecraft:crying_obsidian
fill 167 209 552 169 221 552 minecraft:obsidian
setblock 170 209 510 minecraft:white_concrete
fill 171 209 510 176 213 510 minecraft:obsidian
fill 172 209 552 174 231 552 minecraft:obsidian
setblock 175 209 552 minecraft:crying_obsidian
fill 176 209 552 182 218 552 minecraft:obsidian
fill 178 209 510 179 211 510 minecraft:obsidian
setblock 180 209 510 minecraft:crying_obsidian
fill 181 209 510 183 213 510 minecraft:obsidian
fill 183 209 511 183 219 511 minecraft:obsidian
setblock 183 209 512 minecraft:crying_obsidian
fill 183 209 528 183 230 528 minecraft:obsidian
fill 183 209 531 183 251 532 minecraft:obsidian
fill 183 209 535 183 307 535 minecraft:obsidian
fill 183 209 539 183 301 539 minecraft:obsidian
setblock 183 209 540 minecraft:crying_obsidian
fill 183 209 541 183 223 543 minecraft:obsidian
setblock 183 209 545 minecraft:crying_obsidian
fill 183 209 546 183 233 547 minecraft:obsidian
fill 183 209 549 183 270 549 minecraft:obsidian
setblock 183 209 550 minecraft:crying_obsidian
fill 141 210 514 141 219 514 minecraft:obsidian
fill 141 210 518 141 215 519 minecraft:obsidian
fill 141 210 521 141 258 521 minecraft:obsidian
fill 141 210 528 141 307 528 minecraft:obsidian
setblock 141 210 529 minecraft:crying_obsidian
fill 141 210 530 141 227 532 minecraft:obsidian
fill 141 210 534 141 215 534 minecraft:obsidian
fill 141 210 537 141 218 538 minecraft:obsidian
fill 141 210 542 141 236 543 minecraft:obsidian
fill 141 210 548 141 211 550 minecraft:obsidian
fill 145 210 510 145 215 510 minecraft:obsidian
fill 146 210 552 146 256 552 minecraft:obsidian
fill 151 210 510 151 231 510 minecraft:obsidian
fill 153 210 552 153 281 552 minecraft:obsidian
fill 155 210 510 155 251 510 minecraft:obsidian
setblock 155 210 552 minecraft:crying_obsidian
setblock 156 210 510 minecraft:white_concrete
fill 156 210 552 156 263 552 minecraft:obsidian
fill 157 210 510 157 272 510 minecraft:obsidian
fill 161 210 510 161 215 510 minecraft:obsidian
fill 162 210 552 162 307 552 minecraft:obsidian
fill 166 210 552 166 242 552 minecraft:obsidian
fill 170 210 510 170 307 510 minecraft:obsidian
fill 171 210 552 171 215 552 minecraft:obsidian
fill 175 210 552 175 305 552 minecraft:obsidian
fill 177 210 510 177 215 510 minecraft:obsidian
fill 180 210 510 180 228 510 minecraft:obsidian
fill 183 210 512 183 260 512 minecraft:obsidian
fill 183 210 520 183 215 520 minecraft:obsidian
setblock 183 210 529 minecraft:white_concrete
fill 183 210 530 183 229 530 minecraft:obsidian
fill 183 210 536 183 215 536 minecraft:obsidian
fill 183 210 540 183 214 540 minecraft:obsidian
fill 183 210 545 183 212 545 minecraft:obsidian
fill 183 210 550 183 269 550 minecraft:obsidian
setblock 141 211 520 minecraft:crying_obsidian
fill 141 211 529 141 283 529 minecraft:obsidian
setblock 141 211 533 minecraft:white_concrete
setblock 144 211 510 minecraft:crying_obsidian
fill 155 211 552 155 215 552 minecraft:obsidian
fill 156 211 510 156 214 510 minecraft:obsidian
fill 161 211 517 161 212 517 minecraft:amethyst_block
fill 165 211 510 165 238 510 minecraft:obsidian
setblock 166 211 510 minecraft:crying_obsidian
fill 167 211 510 169 215 510 minecraft:obsidian
fill 183 211 529 183 307 529 minecraft:obsidian
fill 141 212 520 141 247 520 minecraft:obsidian
fill 141 212 533 141 219 533 minecraft:obsidian
setblock 141 212 548 minecraft:crying_obsidian
fill 141 212 549 141 215 550 minecraft:obsidian
fill 144 212 510 144 224 510 minecraft:obsidian
setblock 159 212 552 minecraft:amethyst_block
fill 160 212 552 161 235 552 minecraft:obsidian
fill 166 212 510 166 236 510 minecraft:obsidian
setblock 178 212 510 minecraft:white_concrete
fill 179 212 510 179 274 510 minecraft:obsidian
fill 141 213 544 141 231 545 minecraft:obsidian
setblock 141 213 546 minecraft:crying_obsidian
fill 141 213 547 141 228 548 minecraft:obsidian
fill 159 213 552 159 288 552 minecraft:obsidian
fill 161 213 517 161 221 517 minecraft:obsidian
fill 178 213 510 178 233 510 minecraft:obsidian
setblock 183 213 545 minecraft:amethyst_block
setblock 141 214 513 minecraft:crying_obsidian
fill 141 214 546 141 253 546 minecraft:obsidian
fill 161 214 518 161 221 518 minecraft:obsidian
fill 162 214 517 162 221 517 minecraft:obsidian
setblock 171 214 510 minecraft:crying_obsidian
fill 172 214 510 176 220 510 minecraft:obsidian
fill 181 214 510 181 226 510 minecraft:obsidian
setblock 182 214 510 minecraft:crying_obsidian
fill 183 214 510 183 307 510 minecraft:obsidian
fill 183 214 545 183 262 545 minecraft:obsidian
fill 141 215 510 141 307 510 minecraft:obsidian
setblock 141 215 511 minecraft:amethyst_block
fill 141 215 513 141 263 513 minecraft:obsidian
setblock 144 215 513 minecraft:light[level=12]
setblock 144 215 521 minecraft:light[level=12]
setblock 144 215 529 minecraft:light[level=12]
setblock 144 215 537 minecraft:light[level=12]
setblock 144 215 545 minecraft:light[level=12]
setblock 152 215 513 minecraft:light[level=12]
setblock 152 215 521 minecraft:light[level=12]
setblock 152 215 529 minecraft:light[level=12]
setblock 152 215 537 minecraft:light[level=12]
setblock 152 215 545 minecraft:light[level=12]
setblock 156 215 510 minecraft:white_concrete
fill 159 215 545 159 216 545 minecraft:amethyst_block
setblock 160 215 513 minecraft:light[level=12]
setblock 160 215 521 minecraft:light[level=12]
setblock 160 215 529 minecraft:light[level=12]
setblock 160 215 537 minecraft:light[level=12]
setblock 160 215 545 minecraft:light[level=12]
fill 162 215 518 162 221 518 minecraft:obsidian
setblock 168 215 513 minecraft:light[level=12]
setblock 168 215 521 minecraft:light[level=12]
setblock 168 215 529 minecraft:light[level=12]
setblock 168 215 537 minecraft:light[level=12]
setblock 168 215 545 minecraft:light[level=12]
fill 171 215 510 171 307 510 minecraft:obsidian
setblock 176 215 513 minecraft:light[level=12]
setblock 176 215 521 minecraft:light[level=12]
setblock 176 215 529 minecraft:light[level=12]
setblock 176 215 537 minecraft:light[level=12]
setblock 176 215 545 minecraft:light[level=12]
fill 182 215 510 182 307 510 minecraft:obsidian
fill 183 215 514 183 219 517 minecraft:obsidian
setblock 183 215 518 minecraft:white_concrete
fill 183 215 519 183 307 519 minecraft:obsidian
setblock 183 215 540 minecraft:amethyst_block
fill 141 216 511 141 297 511 minecraft:obsidian
fill 141 216 518 141 218 518 minecraft:purple_stained_glass
fill 141 216 519 141 262 519 minecraft:obsidian
fill 141 216 534 141 218 534 minecraft:purple_stained_glass
fill 141 216 549 141 223 549 minecraft:obsidian
fill 141 216 550 141 218 550 minecraft:purple_stained_glass
fill 145 216 510 145 218 510 minecraft:purple_stained_glass
fill 155 216 552 155 218 552 minecraft:purple_stained_glass
fill 156 216 510 156 303 510 minecraft:obsidian
fill 160 216 517 160 221 518 minecraft:obsidian
fill 161 216 510 161 218 510 minecraft:purple_stained_glass
fill 161 216 516 162 221 516 minecraft:obsidian
fill 161 216 519 162 221 519 minecraft:obsidian
fill 163 216 517 163 221 518 minecraft:obsidian
setblock 167 216 510 minecraft:crying_obsidian
setblock 168 216 510 minecraft:white_concrete
fill 169 216 510 169 252 510 minecraft:obsidian
fill 171 216 552 171 218 552 minecraft:purple_stained_glass
fill 177 216 510 177 218 510 minecraft:purple_stained_glass
fill 183 216 518 183 254 518 minecraft:obsidian
fill 183 216 520 183 218 520 minecraft:purple_stained_glass
fill 183 216 536 183 218 536 minecraft:purple_stained_glass
fill 183 216 540 183 219 540 minecraft:obsidian
setblock 158 217 510 minecraft:crying_obsidian
fill 159 217 510 160 225 510 minecraft:obsidian
fill 159 217 545 159 224 545 minecraft:obsidian
fill 160 217 516 160 221 516 minecraft:obsidian
fill 160 217 519 160 221 519 minecraft:obsidian
fill 163 217 516 163 221 516 minecraft:obsidian
fill 167 217 510 168 255 510 minecraft:obsidian
setblock 183 217 544 minecraft:white_concrete
fill 158 218 510 158 229 510 minecraft:obsidian
fill 159 218 517 159 221 518 minecraft:obsidian
fill 159 218 546 159 224 546 minecraft:obsidian
fill 160 218 515 162 221 515 minecraft:obsidian
fill 161 218 520 162 221 520 minecraft:obsidian
fill 163 218 519 163 221 519 minecraft:obsidian
fill 164 218 517 164 221 518 minecraft:obsidian
fill 183 218 544 183 286 544 minecraft:obsidian
fill 141 219 518 141 234 518 minecraft:obsidian
fill 141 219 534 141 234 534 minecraft:obsidian
setblock 141 219 537 minecraft:white_concrete
fill 141 219 538 141 235 538 minecraft:obsidian
setblock 141 219 550 minecraft:crying_obsidian
fill 144 219 529 145 220 533 minecraft:obsidian
setblock 145 219 510 minecraft:obsidian
fill 145 219 525 145 220 528 minecraft:obsidian
fill 145 219 534 145 220 537 minecraft:obsidian
fill 146 219 523 146 220 525 minecraft:obsidian
fill 146 219 537 146 220 539 minecraft:obsidian
fill 147 219 521 147 220 523 minecraft:obsidian
fill 147 219 539 147 220 541 minecraft:obsidian
fill 148 219 520 148 220 521 minecraft:obsidian
fill 148 219 541 148 220 542 minecraft:obsidian
fill 149 219 519 149 220 520 minecraft:obsidian
fill 149 219 542 149 220 543 minecraft:obsidian
fill 150 219 518 150 220 519 minecraft:obsidian
fill 150 219 543 150 220 544 minecraft:obsidian
fill 151 219 517 151 220 518 minecraft:obsidian
fill 151 219 544 151 220 545 minecraft:obsidian
fill 152 219 516 152 220 517 minecraft:obsidian
fill 152 219 545 152 220 546 minecraft:obsidian
fill 153 219 516 154 220 516 minecraft:obsidian
fill 153 219 546 154 220 546 minecraft:obsidian
fill 154 219 515 156 220 515 minecraft:obsidian
fill 154 219 547 156 220 547 minecraft:obsidian
fill 155 219 552 155 234 552 minecraft:obsidian
fill 156 219 514 168 220 514 minecraft:obsidian
fill 156 219 548 168 220 548 minecraft:obsidian
fill 158 219 545 158 224 545 minecraft:obsidian
fill 159 219 516 159 221 516 minecraft:obsidian
fill 159 219 519 159 221 519 minecraft:obsidian
fill 160 219 513 164 220 513 minecraft:obsidian
fill 160 219 520 160 221 520 minecraft:obsidian
fill 160 219 545 160 224 546 minecraft:obsidian
fill 160 219 549 164 220 549 minecraft:obsidian
fill 161 219 510 161 234 510 minecraft:obsidian
fill 163 219 515 163 221 515 minecraft:obsidian
fill 163 219 520 163 221 520 minecraft:obsidian
fill 164 219 516 164 221 516 minecraft:obsidian
fill 164 219 519 164 221 519 minecraft:obsidian
fill 168 219 515 170 220 515 minecraft:obsidian
fill 168 219 547 170 220 547 minecraft:obsidian
fill 170 219 516 172 220 516 minecraft:obsidian
fill 170 219 546 172 220 546 minecraft:obsidian
fill 171 219 552 171 234 552 minecraft:obsidian
fill 172 219 517 173 220 517 minecraft:obsidian
fill 172 219 545 173 220 545 minecraft:obsidian
fill 173 219 518 174 220 518 minecraft:obsidian
fill 173 219 544 174 220 544 minecraft:obsidian
fill 174 219 519 175 220 519 minecraft:obsidian
fill 174 219 543 175 220 543 minecraft:obsidian
fill 175 219 520 176 220 520 minecraft:obsidian
fill 175 219 542 176 220 542 minecraft:obsidian
fill 176 219 521 177 220 521 minecraft:obsidian
fill 176 219 541 177 220 541 minecraft:obsidian
fill 176 219 552 181 227 552 minecraft:obsidian
fill 177 219 510 177 234 510 minecraft:obsidian
fill 177 219 522 177 220 523 minecraft:obsidian
fill 177 219 539 177 220 540 minecraft:obsidian
fill 178 219 523 178 220 525 minecraft:obsidian
fill 178 219 531 180 220 532 minecraft:obsidian
fill 178 219 537 178 220 539 minecraft:obsidian
fill 179 219 525 179 220 530 minecraft:obsidian
fill 179 219 533 179 220 537 minecraft:obsidian
fill 180 219 529 180 220 530 minecraft:obsidian
fill 180 219 533 180 220 533 minecraft:obsidian
setblock 182 219 552 minecraft:amethyst_block
fill 183 219 520 183 234 520 minecraft:obsidian
fill 183 219 536 183 234 536 minecraft:obsidian
setblock 141 220 514 minecraft:amethyst_block
setblock 141 220 533 minecraft:white_concrete
fill 141 220 537 141 307 537 minecraft:obsidian
fill 141 220 550 141 234 550 minecraft:obsidian
setblock 145 220 510 minecraft:white_concrete
fill 158 220 516 158 221 518 minecraft:obsidian
fill 158 220 546 158 224 546 minecraft:obsidian
fill 159 220 515 159 221 515 minecraft:obsidian
fill 159 220 520 159 221 520 minecraft:obsidian
fill 159 220 544 160 224 544 minecraft:obsidian
fill 159 220 547 159 224 547 minecraft:obsidian
fill 164 220 515 164 221 515 minecraft:obsidian
fill 165 220 517 165 221 518 minecraft:obsidian
fill 182 220 552 182 307 552 minecraft:obsidian
setblock 183 220 511 minecraft:crying_obsidian
fill 183 220 514 183 287 515 minecraft:obsidian
setblock 183 220 516 minecraft:crying_obsidian
fill 183 220 517 183 238 517 minecraft:obsidian
setblock 183 220 540 minecraft:amethyst_block
fill 141 221 514 141 246 514 minecraft:obsidian
fill 141 221 533 141 265 533 minecraft:obsidian
fill 144 221 527 144 221 535 minecraft:crying_obsidian
fill 145 221 510 145 230 510 minecraft:obsidian
fill 145 221 536 145 221 538 minecraft:crying_obsidian
fill 146 221 539 146 221 540 minecraft:crying_obsidian
setblock 147 221 541 minecraft:crying_obsidian
fill 148 221 542 148 221 543 minecraft:crying_obsidian
fill 149 221 543 149 221 544 minecraft:crying_obsidian
fill 150 221 544 150 221 545 minecraft:crying_obsidian
setblock 151 221 545 minecraft:crying_obsidian
setblock 152 221 546 minecraft:crying_obsidian
fill 153 221 547 154 221 547 minecraft:crying_obsidian
fill 155 221 548 157 221 548 minecraft:crying_obsidian
setblock 158 221 515 minecraft:obsidian
setblock 158 221 519 minecraft:obsidian
fill 158 221 544 158 224 544 minecraft:obsidian
fill 158 221 547 158 224 547 minecraft:obsidian
fill 158 221 549 166 221 549 minecraft:crying_obsidian
fill 159 221 514 163 221 514 minecraft:obsidian
fill 160 221 521 163 221 521 minecraft:obsidian
fill 160 221 547 160 224 547 minecraft:obsidian
fill 161 221 545 161 224 546 minecraft:obsidian
setblock 164 221 520 minecraft:obsidian
setblock 165 221 516 minecraft:obsidian
setblock 165 221 519 minecraft:obsidian
fill 167 221 514 169 221 514 minecraft:crying_obsidian
fill 167 221 548 169 221 548 minecraft:crying_obsidian
fill 170 221 515 171 221 515 minecraft:crying_obsidian
fill 170 221 547 171 221 547 minecraft:crying_obsidian
fill 172 221 510 172 261 510 minecraft:obsidian
setblock 172 221 516 minecraft:crying_obsidian
setblock 172 221 546 minecraft:crying_obsidian
setblock 173 221 510 minecraft:white_concrete
fill 173 221 517 174 221 517 minecraft:crying_obsidian
fill 173 221 545 174 221 545 minecraft:crying_obsidian
fill 174 221 510 176 254 510 minecraft:obsidian
fill 174 221 518 175 221 518 minecraft:crying_obsidian
fill 174 221 544 175 221 544 minecraft:crying_obsidian
fill 175 221 519 176 221 519 minecraft:crying_obsidian
fill 175 221 543 176 221 543 minecraft:crying_obsidian
setblock 176 221 520 minecraft:crying_obsidian
setblock 176 221 542 minecraft:crying_obsidian
setblock 177 221 521 minecraft:crying_obsidian
setblock 177 221 541 minecraft:crying_obsidian
fill 178 221 522 178 221 523 minecraft:crying_obsidian
fill 178 221 539 178 221 540 minecraft:crying_obsidian
fill 179 221 524 179 221 526 minecraft:crying_obsidian
fill 179 221 536 179 221 538 minecraft:crying_obsidian
fill 180 221 527 180 221 535 minecraft:crying_obsidian
fill 183 221 511 183 261 511 minecraft:obsidian
fill 183 221 516 183 222 516 minecraft:obsidian
setblock 183 221 521 minecraft:amethyst_block
fill 183 221 522 183 236 527 minecraft:obsidian
setblock 183 221 538 minecraft:amethyst_block
fill 183 221 540 183 307 540 minecraft:obsidian
setblock 141 222 523 minecraft:white_concrete
fill 141 222 524 141 236 527 minecraft:obsidian
fill 157 222 544 157 224 546 minecraft:obsidian
fill 158 222 543 160 224 543 minecraft:obsidian
fill 161 222 517 162 223 518 minecraft:amethyst_block
fill 161 222 544 161 224 544 minecraft:obsidian
fill 161 222 547 161 224 547 minecraft:obsidian
fill 167 222 552 168 224 552 minecraft:obsidian
setblock 169 222 552 minecraft:white_concrete
fill 173 222 510 173 307 510 minecraft:obsidian
fill 183 222 521 183 286 521 minecraft:obsidian
fill 183 222 538 183 282 538 minecraft:obsidian
fill 141 223 523 141 247 523 minecraft:obsidian
fill 141 223 539 141 227 539 minecraft:obsidian
setblock 141 223 540 minecraft:white_concrete
fill 141 223 541 141 227 541 minecraft:obsidian
setblock 144 223 513 minecraft:light[level=12]
setblock 144 223 521 minecraft:light[level=12]
setblock 144 223 529 minecraft:light[level=12]
setblock 144 223 537 minecraft:light[level=12]
setblock 144 223 545 minecraft:light[level=12]
setblock 152 223 513 minecraft:light[level=12]
setblock 152 223 521 minecraft:light[level=12]
setblock 152 223 529 minecraft:light[level=12]
setblock 152 223 537 minecraft:light[level=12]
setblock 152 223 545 minecraft:light[level=12]
fill 157 223 547 157 224 547 minecraft:obsidian
fill 158 223 548 160 224 548 minecraft:obsidian
setblock 160 223 513 minecraft:light[level=12]
setblock 160 223 521 minecraft:light[level=12]
setblock 160 223 529 minecraft:light[level=12]
setblock 160 223 537 minecraft:light[level=12]
fill 161 223 543 161 224 543 minecraft:obsidian
fill 162 223 545 162 224 546 minecraft:obsidian
setblock 168 223 513 minecraft:light[level=12]
setblock 168 223 521 minecraft:light[level=12]
setblock 168 223 529 minecraft:light[level=12]
setblock 168 223 537 minecraft:light[level=12]
setblock 168 223 545 minecraft:light[level=12]
fill 169 223 552 169 307 552 minecraft:obsidian
setblock 176 223 513 minecraft:light[level=12]
setblock 176 223 521 minecraft:light[level=12]
setblock 176 223 529 minecraft:light[level=12]
setblock 176 223 537 minecraft:light[level=12]
setblock 176 223 545 minecraft:light[level=12]
setblock 183 223 516 minecraft:amethyst_block
fill 141 224 515 141 307 515 minecraft:obsidian
setblock 141 224 516 minecraft:crying_obsidian
fill 141 224 517 141 230 517 minecraft:obsidian
fill 141 224 540 141 233 540 minecraft:obsidian
setblock 141 224 549 minecraft:crying_obsidian
fill 146 224 510 148 235 510 minecraft:obsidian
setblock 149 224 510 minecraft:white_concrete
fill 150 224 510 150 242 510 minecraft:obsidian
fill 156 224 544 156 224 546 minecraft:obsidian
setblock 157 224 543 minecraft:obsidian
setblock 157 224 548 minecraft:obsidian
fill 159 224 542 160 224 542 minecraft:obsidian
fill 161 224 517 162 224 517 minecraft:amethyst_block
setblock 161 224 548 minecraft:obsidian
setblock 162 224 544 minecraft:obsidian
setblock 162 224 547 minecraft:obsidian
fill 183 224 516 183 291 516 minecraft:obsidian
fill 183 224 541 183 252 541 minecraft:obsidian
setblock 183 224 542 minecraft:crying_obsidian
fill 183 224 543 183 307 543 minecraft:obsidian
fill 141 225 516 141 288 516 minecraft:obsidian
fill 141 225 549 141 307 549 minecraft:obsidian
setblock 144 225 510 minecraft:white_concrete
fill 149 225 510 149 249 510 minecraft:obsidian
setblock 152 225 510 minecraft:white_concrete
fill 153 225 510 154 249 510 minecraft:obsidian
setblock 162 225 510 minecraft:amethyst_block
fill 163 225 510 163 228 510 minecraft:obsidian
fill 167 225 552 167 230 552 minecraft:obsidian
setblock 168 225 552 minecraft:white_concrete
fill 183 225 542 183 307 542 minecraft:obsidian
fill 144 226 510 144 257 510 minecraft:obsidian
fill 152 226 510 152 265 510 minecraft:obsidian
fill 159 226 510 159 228 510 minecraft:obsidian
setblock 160 226 510 minecraft:white_concrete
fill 162 226 510 162 281 510 minecraft:obsidian
fill 168 226 552 168 271 552 minecraft:obsidian
fill 160 227 510 160 273 510 minecraft:obsidian
setblock 181 227 510 minecraft:white_concrete
setblock 141 228 530 minecraft:amethyst_block
fill 141 228 531 141 235 532 minecraft:obsidian
setblock 141 228 539 minecraft:amethyst_block
setblock 141 228 541 minecraft:amethyst_block
fill 176 228 552 180 228 552 minecraft:obsidian
fill 181 228 510 181 268 510 minecraft:obsidian
setblock 181 228 552 minecraft:amethyst_block
fill 141 229 530 141 294 530 minecraft:obsidian
fill 141 229 539 141 251 539 minecraft:obsidian
fill 141 229 541 141 231 541 minecraft:obsidian
fill 141 229 547 141 252 547 minecraft:obsidian
setblock 141 229 548 minecraft:amethyst_block
setblock 159 229 510 minecraft:white_concrete
setblock 163 229 510 minecraft:white_concrete
fill 176 229 552 177 246 552 minecraft:obsidian
setblock 178 229 552 minecraft:amethyst_block
fill 179 229 552 181 229 552 minecraft:obsidian
setblock 180 229 510 minecraft:amethyst_block
fill 141 230 548 141 256 548 minecraft:obsidian
fill 149 230 520 150 230 538 minecraft:crying_obsidian
fill 151 230 520 167 230 521 minecraft:crying_obsidian
fill 151 230 522 155 230 536 minecraft:magenta_stained_glass
fill 151 230 537 167 230 538 minecraft:crying_obsidian
fill 156 230 522 156 230 528 minecraft:magenta_stained_glass
fill 156 230 530 156 230 536 minecraft:magenta_stained_glass
fill 157 230 522 157 230 527 minecraft:magenta_stained_glass
fill 157 230 531 157 230 536 minecraft:magenta_stained_glass
setblock 158 230 510 minecraft:crying_obsidian
fill 158 230 522 165 230 526 minecraft:magenta_stained_glass
fill 158 230 532 165 230 536 minecraft:magenta_stained_glass
fill 159 230 510 159 305 510 minecraft:obsidian
fill 159 230 527 165 230 527 minecraft:magenta_stained_glass
fill 159 230 531 165 230 531 minecraft:magenta_stained_glass
fill 160 230 528 165 230 528 minecraft:magenta_stained_glass
fill 160 230 530 165 230 530 minecraft:magenta_stained_glass
fill 161 230 529 165 230 529 minecraft:magenta_stained_glass
fill 163 230 510 163 307 510 minecraft:obsidian
fill 166 230 522 167 230 536 minecraft:crying_obsidian
fill 178 230 552 178 292 552 minecraft:obsidian
setblock 179 230 552 minecraft:crying_obsidian
fill 180 230 510 180 268 510 minecraft:obsidian
fill 180 230 552 181 238 552 minecraft:obsidian
setblock 183 230 530 minecraft:amethyst_block
setblock 141 231 517 minecraft:amethyst_block
setblock 141 231 551 minecraft:amethyst_block
fill 141 231 552 141 307 552 minecraft:obsidian
fill 142 231 511 148 231 551 minecraft:obsidian
setblock 145 231 510 minecraft:amethyst_block
fill 149 231 511 182 231 519 minecraft:obsidian
fill 149 231 520 149 231 521 minecraft:crying_obsidian
setblock 149 231 522 minecraft:amethyst_block
fill 149 231 523 149 231 525 minecraft:crying_obsidian
setblock 149 231 526 minecraft:amethyst_block
fill 149 231 527 149 231 529 minecraft:crying_obsidian
setblock 149 231 530 minecraft:amethyst_block
fill 149 231 531 149 231 533 minecraft:crying_obsidian
setblock 149 231 534 minecraft:amethyst_block
fill 149 231 535 149 231 537 minecraft:crying_obsidian
setblock 149 231 538 minecraft:amethyst_block
fill 149 231 539 182 231 551 minecraft:obsidian
fill 150 231 520 150 235 520 minecraft:crying_obsidian
setblock 150 231 521 minecraft:amethyst_block
fill 150 231 522 150 231 524 minecraft:crying_obsidian
setblock 150 231 525 minecraft:amethyst_block
fill 150 231 526 150 231 528 minecraft:crying_obsidian
setblock 150 231 529 minecraft:amethyst_block
fill 150 231 530 150 231 532 minecraft:crying_obsidian
setblock 150 231 533 minecraft:amethyst_block
fill 150 231 534 150 231 536 minecraft:crying_obsidian
setblock 150 231 537 minecraft:amethyst_block
fill 150 231 538 152 231 538 minecraft:crying_obsidian
setblock 151 231 520 minecraft:amethyst_block
fill 151 231 521 153 231 521 minecraft:crying_obsidian
fill 151 231 522 154 231 536 minecraft:magenta_stained_glass
fill 151 231 537 153 231 537 minecraft:crying_obsidian
fill 152 231 520 154 231 520 minecraft:crying_obsidian
setblock 153 231 538 minecraft:amethyst_block
setblock 154 231 521 minecraft:amethyst_block
setblock 154 231 537 minecraft:amethyst_block
fill 154 231 538 156 231 538 minecraft:crying_obsidian
setblock 155 231 520 minecraft:amethyst_block
fill 155 231 521 157 231 521 minecraft:crying_obsidian
fill 155 231 522 155 231 527 minecraft:magenta_stained_glass
fill 155 231 528 155 231 530 minecraft:crying_obsidian
fill 155 231 531 155 231 536 minecraft:magenta_stained_glass
fill 155 231 537 157 231 537 minecraft:crying_obsidian
fill 156 231 520 158 231 520 minecraft:crying_obsidian
fill 156 231 522 156 231 526 minecraft:magenta_stained_glass
fill 156 231 527 156 231 528 minecraft:crying_obsidian
fill 156 231 530 156 231 531 minecraft:crying_obsidian
fill 156 231 532 156 231 536 minecraft:magenta_stained_glass
fill 157 231 522 165 231 525 minecraft:magenta_stained_glass
fill 157 231 526 157 231 527 minecraft:crying_obsidian
fill 157 231 531 157 231 532 minecraft:crying_obsidian
fill 157 231 533 165 231 536 minecraft:magenta_stained_glass
setblock 157 231 538 minecraft:amethyst_block
fill 158 231 510 158 247 510 minecraft:obsidian
setblock 158 231 521 minecraft:amethyst_block
fill 158 231 526 159 231 526 minecraft:crying_obsidian
fill 158 231 532 159 231 532 minecraft:crying_obsidian
setblock 158 231 537 minecraft:amethyst_block
fill 158 231 538 160 231 538 minecraft:crying_obsidian
setblock 159 231 520 minecraft:amethyst_block
fill 159 231 521 161 231 521 minecraft:crying_obsidian
fill 159 231 527 160 231 527 minecraft:crying_obsidian
fill 159 231 531 160 231 531 minecraft:crying_obsidian
fill 159 231 537 161 231 537 minecraft:crying_obsidian
fill 160 231 520 162 231 520 minecraft:crying_obsidian
fill 160 231 526 165 231 526 minecraft:magenta_stained_glass
fill 160 231 528 161 231 528 minecraft:crying_obsidian
fill 160 231 530 161 231 530 minecraft:crying_obsidian
fill 160 231 532 165 231 532 minecraft:magenta_stained_glass
fill 161 231 527 165 231 527 minecraft:magenta_stained_glass
setblock 161 231 529 minecraft:crying_obsidian
fill 161 231 531 165 231 531 minecraft:magenta_stained_glass
setblock 161 231 538 minecraft:amethyst_block
setblock 162 231 521 minecraft:amethyst_block
fill 162 231 528 165 231 530 minecraft:magenta_stained_glass
setblock 162 231 537 minecraft:amethyst_block
fill 162 231 538 164 231 538 minecraft:crying_obsidian
setblock 163 231 520 minecraft:amethyst_block
fill 163 231 521 165 231 521 minecraft:crying_obsidian
fill 163 231 537 165 231 537 minecraft:crying_obsidian
fill 164 231 520 166 231 520 minecraft:crying_obsidian
setblock 165 231 538 minecraft:amethyst_block
setblock 166 231 521 minecraft:amethyst_block
fill 166 231 522 166 231 524 minecraft:crying_obsidian
setblock 166 231 525 minecraft:amethyst_block
fill 166 231 526 166 231 528 minecraft:crying_obsidian
setblock 166 231 529 minecraft:amethyst_block
fill 166 231 530 166 231 532 minecraft:crying_obsidian
setblock 166 231 533 minecraft:amethyst_block
fill 166 231 534 166 231 536 minecraft:crying_obsidian
setblock 166 231 537 minecraft:amethyst_block
fill 166 231 538 167 231 538 minecraft:crying_obsidian
setblock 167 231 520 minecraft:amethyst_block
fill 167 231 521 167 231 523 minecraft:crying_obsidian
setblock 167 231 524 minecraft:amethyst_block
fill 167 231 525 167 231 527 minecraft:crying_obsidian
setblock 167 231 528 minecraft:amethyst_block
fill 167 231 529 167 231 531 minecraft:crying_obsidian
setblock 167 231 532 minecraft:amethyst_block
fill 167 231 533 167 231 535 minecraft:crying_obsidian
setblock 167 231 536 minecraft:amethyst_block
fill 167 231 537 167 235 537 minecraft:crying_obsidian
setblock 167 231 552 minecraft:white_concrete
fill 168 231 520 182 231 538 minecraft:obsidian
fill 179 231 552 179 307 552 minecraft:obsidian
setblock 183 231 528 minecraft:crying_obsidian
fill 183 231 530 183 240 530 minecraft:obsidian
fill 141 232 517 141 243 517 minecraft:obsidian
setblock 141 232 541 minecraft:amethyst_block
setblock 141 232 544 minecraft:crying_obsidian
fill 141 232 545 141 293 545 minecraft:obsidian
fill 141 232 551 141 245 551 minecraft:obsidian
fill 145 232 510 145 233 510 minecraft:obsidian
fill 149 232 521 151 235 521 minecraft:crying_obsidian
fill 149 232 537 151 235 537 minecraft:crying_obsidian
fill 150 232 522 150 235 522 minecraft:crying_obsidian
fill 150 232 536 150 235 536 minecraft:crying_obsidian
fill 150 232 538 150 235 538 minecraft:crying_obsidian
setblock 151 232 510 minecraft:crying_obsidian
fill 165 232 521 167 235 521 minecraft:crying_obsidian
fill 165 232 537 166 235 537 minecraft:crying_obsidian
fill 166 232 520 166 235 520 minecraft:crying_obsidian
fill 166 232 522 166 235 522 minecraft:crying_obsidian
fill 166 232 536 166 235 536 minecraft:crying_obsidian
fill 166 232 538 166 235 538 minecraft:crying_obsidian
fill 167 232 552 167 255 552 minecraft:obsidian
setblock 172 232 552 minecraft:crying_obsidian
fill 173 232 552 174 239 552 minecraft:obsidian
fill 183 232 528 183 260 528 minecraft:obsidian
fill 141 233 541 141 254 541 minecraft:obsidian
fill 141 233 544 141 307 544 minecraft:obsidian
setblock 142 233 510 minecraft:white_concrete
fill 143 233 510 143 281 510 minecraft:obsidian
fill 151 233 510 151 273 510 minecraft:obsidian
fill 172 233 552 172 253 552 minecraft:obsidian
setblock 141 234 535 minecraft:white_concrete
fill 141 234 536 141 277 536 minecraft:obsidian
setblock 141 234 540 minecraft:amethyst_block
fill 142 234 510 142 307 510 minecraft:obsidian
setblock 145 234 510 minecraft:amethyst_block
setblock 178 234 510 minecraft:white_concrete
fill 183 234 546 183 307 546 minecraft:obsidian
setblock 183 234 547 minecraft:crying_obsidian
fill 141 235 518 141 236 518 minecraft:purple_stained_glass
fill 141 235 534 141 236 534 minecraft:purple_stained_glass
fill 141 235 535 141 297 535 minecraft:obsidian
fill 141 235 540 141 302 540 minecraft:obsidian
fill 141 235 550 141 236 550 minecraft:purple_stained_glass
fill 145 235 510 145 236 510 minecraft:purple_stained_glass
fill 155 235 552 155 236 552 minecraft:purple_stained_glass
fill 157 235 552 157 238 552 minecraft:obsidian
setblock 158 235 552 minecraft:crying_obsidian
fill 161 235 510 161 236 510 minecraft:purple_stained_glass
fill 171 235 552 171 236 552 minecraft:purple_stained_glass
fill 176 235 511 180 236 512 minecraft:amethyst_block
fill 177 235 510 177 236 510 minecraft:purple_stained_glass
fill 177 235 513 179 235 516 minecraft:amethyst_block
fill 178 235 510 178 259 510 minecraft:obsidian
fill 183 235 520 183 236 520 minecraft:purple_stained_glass
fill 183 235 536 183 236 536 minecraft:purple_stained_glass
fill 183 235 547 183 240 547 minecraft:obsidian
fill 141 236 531 141 249 531 minecraft:obsidian
setblock 141 236 532 minecraft:white_concrete
setblock 141 236 538 minecraft:white_concrete
setblock 146 236 510 minecraft:white_concrete
fill 147 236 510 148 244 510 minecraft:obsidian
setblock 154 236 552 minecraft:amethyst_block
fill 158 236 552 158 307 552 minecraft:obsidian
fill 160 236 552 160 307 552 minecraft:obsidian
setblock 161 236 552 minecraft:amethyst_block
fill 177 236 513 179 236 514 minecraft:amethyst_block
setblock 178 236 515 minecraft:amethyst_block
fill 141 237 518 141 239 518 minecraft:obsidian
setblock 141 237 524 minecraft:amethyst_block
fill 141 237 525 141 277 527 minecraft:obsidian
fill 141 237 532 141 251 532 minecraft:obsidian
fill 141 237 534 141 239 534 minecraft:obsidian
setblock 141 237 538 minecraft:obsidian
fill 141 237 542 141 256 542 minecraft:obsidian
setblock 141 237 543 minecraft:white_concrete
fill 141 237 550 141 242 550 minecraft:obsidian
fill 145 237 510 146 242 510 minecraft:obsidian
fill 154 237 552 155 242 552 minecraft:obsidian
fill 161 237 510 161 242 510 minecraft:obsidian
fill 161 237 552 161 243 552 minecraft:obsidian
setblock 166 237 510 minecraft:white_concrete
fill 171 237 552 171 242 552 minecraft:obsidian
fill 177 237 510 177 242 510 minecraft:obsidian
fill 177 237 511 179 237 512 minecraft:amethyst_block
setblock 178 237 513 minecraft:amethyst_block
fill 183 237 520 183 242 520 minecraft:obsidian
fill 183 237 522 183 238 522 minecraft:crying_obsidian
fill 183 237 523 183 257 527 minecraft:obsidian
fill 183 237 536 183 242 536 minecraft:obsidian
fill 141 238 524 141 307 524 minecraft:obsidian
setblock 141 238 538 minecraft:amethyst_block
fill 141 238 543 141 307 543 minecraft:obsidian
fill 147 238 552 150 244 552 minecraft:obsidian
setblock 151 238 552 minecraft:crying_obsidian
fill 152 238 552 152 307 552 minecraft:obsidian
fill 166 238 510 166 279 510 minecraft:obsidian
fill 141 239 538 141 259 538 minecraft:obsidian
setblock 144 239 513 minecraft:light[level=12]
setblock 144 239 521 minecraft:light[level=12]
setblock 144 239 529 minecraft:light[level=12]
setblock 144 239 537 minecraft:light[level=12]
setblock 144 239 545 minecraft:light[level=12]
fill 151 239 552 151 307 552 minecraft:obsidian
setblock 152 239 513 minecraft:light[level=12]
setblock 152 239 521 minecraft:light[level=12]
setblock 152 239 529 minecraft:light[level=12]
setblock 152 239 537 minecraft:light[level=12]
setblock 152 239 545 minecraft:light[level=12]
setblock 157 239 552 minecraft:amethyst_block
setblock 160 239 513 minecraft:light[level=12]
setblock 160 239 521 minecraft:light[level=12]
setblock 160 239 529 minecraft:light[level=12]
setblock 160 239 537 minecraft:light[level=12]
setblock 160 239 545 minecraft:light[level=12]
setblock 163 239 552 minecraft:amethyst_block
fill 164 239 552 165 279 552 minecraft:obsidian
setblock 165 239 510 minecraft:white_concrete
setblock 168 239 513 minecraft:light[level=12]
setblock 168 239 521 minecraft:light[level=12]
setblock 168 239 529 minecraft:light[level=12]
setblock 168 239 537 minecraft:light[level=12]
setblock 168 239 545 minecraft:light[level=12]
setblock 176 239 513 minecraft:light[level=12]
setblock 176 239 521 minecraft:light[level=12]
setblock 176 239 529 minecraft:light[level=12]
setblock 176 239 537 minecraft:light[level=12]
setblock 176 239 545 minecraft:light[level=12]
fill 180 239 552 180 268 552 minecraft:obsidian
setblock 181 239 552 minecraft:crying_obsidian
setblock 183 239 517 minecraft:amethyst_block
fill 183 239 522 183 241 522 minecraft:obsidian
setblock 141 240 518 minecraft:white_concrete
setblock 141 240 534 minecraft:amethyst_block
fill 157 240 552 157 307 552 minecraft:obsidian
fill 163 240 552 163 276 552 minecraft:obsidian
fill 165 240 510 165 285 510 minecraft:obsidian
fill 173 240 552 173 275 552 minecraft:obsidian
setblock 174 240 552 minecraft:crying_obsidian
fill 181 240 552 181 305 552 minecraft:obsidian
fill 183 240 517 183 261 517 minecraft:obsidian
setblock 141 241 518 minecraft:obsidian
fill 141 241 534 141 242 534 minecraft:obsidian
fill 144 241 527 145 242 535 minecraft:obsidian
fill 145 241 524 146 242 526 minecraft:obsidian
fill 145 241 536 146 242 538 minecraft:obsidian
fill 146 241 522 147 242 523 minecraft:obsidian
fill 146 241 530 146 242 530 minecraft:obsidian
fill 146 241 539 147 242 540 minecraft:obsidian
fill 147 241 521 148 242 521 minecraft:obsidian
fill 147 241 524 147 242 524 minecraft:obsidian
fill 147 241 538 147 242 538 minecraft:obsidian
fill 147 241 541 148 242 541 minecraft:obsidian
fill 148 241 519 149 242 520 minecraft:obsidian
fill 148 241 522 148 242 522 minecraft:obsidian
fill 148 241 540 148 242 540 minecraft:obsidian
fill 148 241 542 149 242 543 minecraft:obsidian
fill 149 241 518 151 242 518 minecraft:obsidian
fill 149 241 544 151 242 544 minecraft:obsidian
fill 150 241 517 153 242 517 minecraft:obsidian
fill 150 241 519 150 242 519 minecraft:obsidian
fill 150 241 543 150 242 543 minecraft:obsidian
fill 150 241 545 153 242 545 minecraft:obsidian
fill 152 241 516 155 242 516 minecraft:obsidian
fill 152 241 546 155 242 546 minecraft:obsidian
fill 153 241 515 157 242 515 minecraft:obsidian
fill 153 241 547 157 242 547 minecraft:obsidian
fill 155 241 514 169 242 514 minecraft:obsidian
fill 155 241 548 169 242 548 minecraft:obsidian
fill 158 241 513 166 242 513 minecraft:obsidian
fill 158 241 549 166 242 549 minecraft:obsidian
fill 167 241 515 171 242 515 minecraft:obsidian
fill 167 241 547 171 242 547 minecraft:obsidian
fill 169 241 516 172 242 516 minecraft:obsidian
fill 169 241 546 172 242 546 minecraft:obsidian
fill 171 241 517 174 242 517 minecraft:obsidian
fill 171 241 545 174 242 545 minecraft:obsidian
fill 173 241 518 175 242 518 minecraft:obsidian
fill 173 241 544 175 242 544 minecraft:obsidian
fill 174 241 519 176 242 519 minecraft:obsidian
fill 174 241 543 176 242 543 minecraft:obsidian
fill 174 241 552 174 307 552 minecraft:obsidian
fill 175 241 520 176 242 520 minecraft:obsidian
fill 175 241 542 176 242 542 minecraft:obsidian
fill 176 241 521 177 242 522 minecraft:obsidian
fill 176 241 540 177 242 541 minecraft:obsidian
fill 177 241 523 178 242 524 minecraft:obsidian
fill 177 241 538 178 242 539 minecraft:obsidian
fill 178 241 522 178 242 522 minecraft:obsidian
fill 178 241 525 179 242 526 minecraft:obsidian
fill 178 241 536 179 242 537 minecraft:obsidian
fill 178 241 540 178 242 540 minecraft:obsidian
fill 179 241 524 179 242 524 minecraft:obsidian
fill 179 241 527 180 242 535 minecraft:obsidian
fill 179 241 538 179 242 538 minecraft:obsidian
setblock 183 241 513 minecraft:white_concrete
setblock 183 241 530 minecraft:crying_obsidian
setblock 183 241 547 minecraft:amethyst_block
setblock 141 242 518 minecraft:crying_obsidian
setblock 170 242 552 minecraft:amethyst_block
fill 183 242 513 183 304 513 minecraft:obsidian
setblock 183 242 522 minecraft:crying_obsidian
setblock 183 242 530 minecraft:obsidian
fill 183 242 547 183 257 547 minecraft:obsidian
fill 141 243 518 141 245 518 minecraft:purple_stained_glass
fill 141 243 534 141 245 534 minecraft:purple_stained_glass
fill 141 243 550 141 245 550 minecraft:purple_stained_glass
fill 144 243 527 144 243 535 minecraft:crying_obsidian
fill 145 243 510 145 245 510 minecraft:purple_stained_glass
fill 145 243 524 145 243 526 minecraft:crying_obsidian
fill 145 243 536 145 243 538 minecraft:crying_obsidian
fill 146 243 510 146 272 510 minecraft:obsidian
fill 146 243 522 146 243 523 minecraft:crying_obsidian
fill 146 243 539 146 243 540 minecraft:crying_obsidian
setblock 147 243 521 minecraft:crying_obsidian
setblock 147 243 541 minecraft:crying_obsidian
fill 148 243 519 148 243 520 minecraft:crying_obsidian
fill 148 243 542 148 243 543 minecraft:crying_obsidian
fill 149 243 518 149 243 519 minecraft:crying_obsidian
fill 149 243 543 149 243 544 minecraft:crying_obsidian
setblock 150 243 510 minecraft:amethyst_block
fill 150 243 517 150 243 518 minecraft:crying_obsidian
fill 150 243 544 150 243 545 minecraft:crying_obsidian
setblock 151 243 517 minecraft:crying_obsidian
setblock 151 243 545 minecraft:crying_obsidian
setblock 152 243 516 minecraft:crying_obsidian
setblock 152 243 546 minecraft:crying_obsidian
fill 153 243 515 154 243 515 minecraft:crying_obsidian
fill 153 243 547 154 243 547 minecraft:crying_obsidian
fill 154 243 552 154 307 552 minecraft:obsidian
fill 155 243 514 157 243 514 minecraft:crying_obsidian
fill 155 243 548 157 243 548 minecraft:crying_obsidian
fill 155 243 552 155 245 552 minecraft:purple_stained_glass
fill 158 243 513 166 243 513 minecraft:crying_obsidian
fill 158 243 549 161 243 549 minecraft:crying_obsidian
fill 161 243 510 161 245 510 minecraft:purple_stained_glass
setblock 166 243 552 minecraft:white_concrete
fill 167 243 514 169 243 514 minecraft:crying_obsidian
fill 170 243 515 171 243 515 minecraft:crying_obsidian
fill 170 243 552 170 307 552 minecraft:obsidian
fill 171 243 552 171 245 552 minecraft:purple_stained_glass
setblock 172 243 516 minecraft:crying_obsidian
fill 173 243 517 174 243 517 minecraft:crying_obsidian
setblock 174 243 518 minecraft:crying_obsidian
fill 177 243 510 177 245 510 minecraft:purple_stained_glass
fill 183 243 520 183 245 520 minecraft:purple_stained_glass
fill 183 243 522 183 307 522 minecraft:obsidian
setblock 183 243 530 minecraft:crying_obsidian
fill 183 243 536 183 245 536 minecraft:purple_stained_glass
setblock 141 244 517 minecraft:crying_obsidian
fill 150 244 510 150 273 510 minecraft:obsidian
setblock 161 244 552 minecraft:white_concrete
fill 166 244 552 166 307 552 minecraft:obsidian
fill 183 244 530 183 257 530 minecraft:obsidian
fill 141 245 517 141 253 517 minecraft:obsidian
setblock 147 245 510 minecraft:amethyst_block
fill 147 245 552 149 255 552 minecraft:obsidian
fill 148 245 510 148 307 510 minecraft:obsidian
setblock 150 245 552 minecraft:crying_obsidian
fill 161 245 552 161 266 552 minecraft:obsidian
fill 141 246 518 141 251 518 minecraft:obsidian
fill 141 246 534 141 251 534 minecraft:obsidian
fill 141 246 550 141 251 550 minecraft:obsidian
setblock 141 246 551 minecraft:amethyst_block
fill 145 246 510 145 251 510 minecraft:obsidian
fill 147 246 510 147 254 510 minecraft:obsidian
fill 150 246 552 150 277 552 minecraft:obsidian
fill 155 246 552 155 251 552 minecraft:obsidian
fill 161 246 510 161 251 510 minecraft:obsidian
fill 171 246 552 171 251 552 minecraft:obsidian
fill 177 246 510 177 247 510 minecraft:obsidian
fill 183 246 520 183 251 520 minecraft:obsidian
fill 183 246 536 183 251 536 minecraft:obsidian
setblock 141 247 514 minecraft:white_concrete
fill 141 247 551 141 307 551 minecraft:obsidian
setblock 144 247 513 minecraft:light[level=12]
setblock 144 247 521 minecraft:light[level=12]
setblock 144 247 529 minecraft:light[level=12]
setblock 144 247 537 minecraft:light[level=12]
setblock 144 247 545 minecraft:light[level=12]
setblock 152 247 513 minecraft:light[level=12]
setblock 152 247 521 minecraft:light[level=12]
setblock 152 247 529 minecraft:light[level=12]
setblock 152 247 537 minecraft:light[level=12]
setblock 152 247 545 minecraft:light[level=12]
setblock 160 247 513 minecraft:light[level=12]
setblock 160 247 521 minecraft:light[level=12]
setblock 160 247 529 minecraft:light[level=12]
setblock 160 247 537 minecraft:light[level=12]
setblock 160 247 545 minecraft:light[level=12]
setblock 168 247 513 minecraft:light[level=12]
setblock 168 247 521 minecraft:light[level=12]
setblock 168 247 529 minecraft:light[level=12]
setblock 168 247 537 minecraft:light[level=12]
setblock 168 247 545 minecraft:light[level=12]
setblock 176 247 513 minecraft:light[level=12]
setblock 176 247 521 minecraft:light[level=12]
setblock 176 247 529 minecraft:light[level=12]
setblock 176 247 537 minecraft:light[level=12]
setblock 176 247 545 minecraft:light[level=12]
setblock 176 247 552 minecraft:white_concrete
fill 177 247 552 177 251 552 minecraft:obsidian
fill 141 248 514 141 275 514 minecraft:obsidian
setblock 141 248 520 minecraft:crying_obsidian
setblock 141 248 523 minecraft:amethyst_block
setblock 158 248 510 minecraft:crying_obsidian
fill 176 248 552 176 307 552 minecraft:obsidian
setblock 177 248 510 minecraft:amethyst_block
fill 141 249 520 141 276 520 minecraft:obsidian
fill 141 249 523 141 282 523 minecraft:obsidian
fill 158 249 510 158 307 510 minecraft:obsidian
fill 177 249 510 177 250 510 minecraft:obsidian
setblock 141 250 531 minecraft:amethyst_block
fill 144 250 529 145 251 533 minecraft:obsidian
fill 145 250 525 145 251 528 minecraft:obsidian
fill 145 250 534 145 251 537 minecraft:obsidian
fill 146 250 523 146 251 525 minecraft:obsidian
fill 146 250 537 146 251 539 minecraft:obsidian
fill 147 250 521 147 251 523 minecraft:obsidian
fill 147 250 539 147 251 541 minecraft:obsidian
fill 148 250 520 148 251 521 minecraft:obsidian
fill 148 250 541 148 251 542 minecraft:obsidian
setblock 149 250 510 minecraft:crying_obsidian
fill 149 250 519 149 251 520 minecraft:obsidian
fill 149 250 542 149 251 543 minecraft:obsidian
fill 150 250 518 150 251 519 minecraft:obsidian
fill 150 250 543 150 251 544 minecraft:obsidian
fill 151 250 517 151 251 518 minecraft:obsidian
fill 151 250 544 151 251 545 minecraft:obsidian
fill 152 250 516 152 251 517 minecraft:obsidian
fill 152 250 545 152 251 546 minecraft:obsidian
fill 153 250 510 153 307 510 minecraft:obsidian
fill 153 250 516 154 251 516 minecraft:obsidian
fill 153 250 546 154 251 546 minecraft:obsidian
setblock 154 250 510 minecraft:crying_obsidian
fill 154 250 515 156 251 515 minecraft:obsidian
fill 154 250 547 156 251 547 minecraft:obsidian
fill 156 250 514 168 251 514 minecraft:obsidian
fill 156 250 548 168 251 548 minecraft:obsidian
fill 160 250 513 164 251 513 minecraft:obsidian
fill 160 250 549 164 251 549 minecraft:obsidian
fill 168 250 515 170 251 515 minecraft:obsidian
fill 168 250 547 170 251 547 minecraft:obsidian
fill 170 250 516 172 251 516 minecraft:obsidian
fill 170 250 546 172 251 546 minecraft:obsidian
fill 172 250 517 173 251 517 minecraft:obsidian
fill 172 250 545 173 251 545 minecraft:obsidian
fill 173 250 518 174 251 518 minecraft:obsidian
fill 173 250 544 174 251 544 minecraft:obsidian
fill 174 250 519 175 251 519 minecraft:obsidian
fill 174 250 543 175 251 543 minecraft:obsidian
fill 175 250 520 176 251 520 minecraft:obsidian
fill 175 250 542 176 251 542 minecraft:obsidian
fill 176 250 521 177 251 521 minecraft:obsidian
fill 176 250 541 177 251 541 minecraft:obsidian
fill 177 250 522 177 251 523 minecraft:obsidian
fill 177 250 539 177 251 540 minecraft:obsidian
fill 178 250 523 178 251 525 minecraft:obsidian
fill 178 250 537 178 251 539 minecraft:obsidian
fill 179 250 525 179 251 537 minecraft:obsidian
fill 180 250 529 180 251 533 minecraft:obsidian
fill 141 251 531 141 276 531 minecraft:obsidian
fill 149 251 510 149 271 510 minecraft:obsidian
fill 154 251 510 154 307 510 minecraft:obsidian
fill 163 251 516 163 252 517 minecraft:amethyst_block
setblock 177 251 510 minecraft:amethyst_block
fill 141 252 518 141 254 518 minecraft:purple_stained_glass
setblock 141 252 532 minecraft:amethyst_block
fill 141 252 534 141 254 534 minecraft:purple_stained_glass
setblock 141 252 539 minecraft:amethyst_block
fill 141 252 550 141 254 550 minecraft:purple_stained_glass
fill 144 252 527 144 252 535 minecraft:crying_obsidian
fill 145 252 510 145 254 510 minecraft:purple_stained_glass
fill 145 252 524 145 252 526 minecraft:crying_obsidian
fill 145 252 536 145 252 538 minecraft:crying_obsidian
fill 146 252 522 146 252 523 minecraft:crying_obsidian
fill 146 252 539 146 252 540 minecraft:crying_obsidian
setblock 147 252 521 minecraft:crying_obsidian
setblock 147 252 541 minecraft:crying_obsidian
fill 148 252 519 148 252 520 minecraft:crying_obsidian
fill 148 252 542 148 252 543 minecraft:crying_obsidian
fill 149 252 518 149 252 519 minecraft:crying_obsidian
fill 149 252 543 149 252 544 minecraft:crying_obsidian
fill 150 252 517 150 252 518 minecraft:crying_obsidian
fill 150 252 544 150 252 545 minecraft:crying_obsidian
setblock 151 252 517 minecraft:crying_obsidian
setblock 151 252 545 minecraft:crying_obsidian
setblock 152 252 516 minecraft:crying_obsidian
setblock 152 252 546 minecraft:crying_obsidian
fill 153 252 515 154 252 515 minecraft:crying_obsidian
fill 153 252 547 154 252 547 minecraft:crying_obsidian
fill 154 252 544 154 253 545 minecraft:obsidian
setblock 155 252 510 minecraft:crying_obsidian
fill 155 252 514 157 252 514 minecraft:crying_obsidian
fill 155 252 548 157 252 548 minecraft:crying_obsidian
fill 155 252 552 155 254 552 minecraft:purple_stained_glass
setblock 158 252 513 minecraft:crying_obsidian
fill 158 252 549 166 252 549 minecraft:crying_obsidian
fill 161 252 510 161 254 510 minecraft:purple_stained_glass
fill 162 252 511 164 252 515 minecraft:amethyst_block
fill 167 252 548 169 252 548 minecraft:crying_obsidian
fill 171 252 552 171 254 552 minecraft:purple_stained_glass
fill 177 252 510 177 254 510 minecraft:purple_stained_glass
setblock 177 252 552 minecraft:crying_obsidian
fill 183 252 520 183 254 520 minecraft:purple_stained_glass
setblock 183 252 531 minecraft:amethyst_block
fill 183 252 532 183 283 532 minecraft:obsidian
fill 183 252 536 183 254 536 minecraft:purple_stained_glass
fill 141 253 532 141 305 532 minecraft:obsidian
fill 141 253 539 141 307 539 minecraft:obsidian
setblock 141 253 547 minecraft:white_concrete
fill 155 253 510 155 266 510 minecraft:obsidian
fill 162 253 511 164 253 514 minecraft:amethyst_block
setblock 163 253 515 minecraft:amethyst_block
setblock 169 253 510 minecraft:crying_obsidian
fill 177 253 552 177 269 552 minecraft:obsidian
setblock 183 253 531 minecraft:obsidian
setblock 183 253 541 minecraft:crying_obsidian
setblock 141 254 517 minecraft:crying_obsidian
setblock 141 254 546 minecraft:white_concrete
fill 141 254 547 141 258 547 minecraft:obsidian
fill 146 254 550 146 257 550 minecraft:amethyst_block
fill 162 254 511 164 254 513 minecraft:amethyst_block
setblock 163 254 514 minecraft:amethyst_block
fill 169 254 510 169 292 510 minecraft:obsidian
setblock 172 254 552 minecraft:amethyst_block
setblock 183 254 531 minecraft:crying_obsidian
fill 183 254 541 183 255 541 minecraft:obsidian
fill 141 255 517 141 260 518 minecraft:obsidian
fill 141 255 534 141 260 534 minecraft:obsidian
setblock 141 255 541 minecraft:crying_obsidian
fill 141 255 546 141 266 546 minecraft:obsidian
fill 141 255 550 141 260 550 minecraft:obsidian
setblock 144 255 513 minecraft:light[level=12]
setblock 144 255 521 minecraft:light[level=12]
setblock 144 255 529 minecraft:light[level=12]
setblock 144 255 537 minecraft:light[level=12]
setblock 144 255 545 minecraft:light[level=12]
fill 145 255 510 145 260 510 minecraft:obsidian
fill 145 255 548 145 256 551 minecraft:amethyst_block
fill 146 255 548 147 257 549 minecraft:amethyst_block
fill 146 255 551 147 256 551 minecraft:amethyst_block
fill 147 255 510 147 256 510 minecraft:crying_obsidian
fill 147 255 550 147 256 550 minecraft:amethyst_block
setblock 152 255 513 minecraft:light[level=12]
setblock 152 255 521 minecraft:light[level=12]
setblock 152 255 529 minecraft:light[level=12]
setblock 152 255 537 minecraft:light[level=12]
setblock 152 255 545 minecraft:light[level=12]
fill 155 255 552 155 260 552 minecraft:obsidian
setblock 160 255 513 minecraft:light[level=12]
setblock 160 255 521 minecraft:light[level=12]
setblock 160 255 529 minecraft:light[level=12]
setblock 160 255 537 minecraft:light[level=12]
setblock 160 255 545 minecraft:light[level=12]
fill 161 255 510 161 260 510 minecraft:obsidian
fill 162 255 511 164 255 511 minecraft:amethyst_block
setblock 163 255 512 minecraft:amethyst_block
setblock 164 255 510 minecraft:amethyst_block
setblock 168 255 513 minecraft:light[level=12]
setblock 168 255 521 minecraft:light[level=12]
setblock 168 255 529 minecraft:light[level=12]
setblock 168 255 537 minecraft:light[level=12]
setblock 168 255 545 minecraft:light[level=12]
fill 171 255 552 172 260 552 minecraft:obsidian
fill 174 255 510 174 307 510 minecraft:obsidian
setblock 175 255 510 minecraft:amethyst_block
fill 176 255 510 177 260 510 minecraft:obsidian
setblock 176 255 513 minecraft:light[level=12]
setblock 176 255 521 minecraft:light[level=12]
setblock 176 255 529 minecraft:light[level=12]
setblock 176 255 537 minecraft:light[level=12]
setblock 176 255 545 minecraft:light[level=12]
setblock 183 255 518 minecraft:amethyst_block
fill 183 255 520 183 260 520 minecraft:obsidian
fill 183 255 531 183 307 531 minecraft:obsidian
fill 183 255 536 183 260 536 minecraft:obsidian
setblock 183 255 548 minecraft:white_concrete
fill 141 256 541 141 307 541 minecraft:obsidian
fill 145 256 547 147 257 547 minecraft:amethyst_block
fill 146 256 546 146 257 546 minecraft:amethyst_block
setblock 147 256 552 minecraft:crying_obsidian
fill 148 256 552 149 305 552 minecraft:obsidian
fill 164 256 510 164 277 510 minecraft:obsidian
setblock 167 256 510 minecraft:crying_obsidian
setblock 167 256 552 minecraft:white_concrete
fill 168 256 510 168 283 510 minecraft:obsidian
fill 175 256 510 175 307 510 minecraft:obsidian
fill 183 256 518 183 273 518 minecraft:obsidian
setblock 183 256 541 minecraft:amethyst_block
fill 183 256 548 183 260 548 minecraft:obsidian
setblock 141 257 542 minecraft:amethyst_block
setblock 141 257 548 minecraft:amethyst_block
setblock 145 257 546 minecraft:amethyst_block
fill 145 257 548 145 257 549 minecraft:amethyst_block
fill 146 257 544 146 258 545 minecraft:amethyst_block
setblock 146 257 552 minecraft:amethyst_block
fill 147 257 510 147 307 510 minecraft:obsidian
setblock 147 257 546 minecraft:amethyst_block
fill 147 257 552 147 307 552 minecraft:obsidian
fill 167 257 510 167 274 510 minecraft:obsidian
fill 167 257 552 167 307 552 minecraft:obsidian
fill 183 257 541 183 307 541 minecraft:obsidian
fill 141 258 542 141 307 542 minecraft:obsidian
fill 141 258 548 141 294 548 minecraft:obsidian
setblock 144 258 510 minecraft:crying_obsidian
setblock 146 258 543 minecraft:amethyst_block
fill 146 258 552 146 307 552 minecraft:obsidian
fill 183 258 523 183 262 525 minecraft:obsidian
setblock 183 258 526 minecraft:crying_obsidian
fill 183 258 527 183 307 527 minecraft:obsidian
setblock 183 258 530 minecraft:white_concrete
setblock 183 258 537 minecraft:amethyst_block
setblock 183 258 547 minecraft:white_concrete
setblock 141 259 521 minecraft:amethyst_block
setblock 141 259 547 minecraft:amethyst_block
fill 144 259 510 144 265 510 minecraft:obsidian
fill 180 259 523 182 262 525 minecraft:amethyst_block
fill 183 259 526 183 283 526 minecraft:obsidian
fill 183 259 530 183 260 530 minecraft:obsidian
fill 183 259 537 183 307 537 minecraft:obsidian
fill 183 259 547 183 307 547 minecraft:obsidian
fill 141 260 521 141 266 521 minecraft:obsidian
setblock 141 260 538 minecraft:amethyst_block
fill 141 260 547 141 307 547 minecraft:obsidian
fill 147 260 511 149 263 511 minecraft:amethyst_block
fill 148 260 512 148 263 512 minecraft:amethyst_block
setblock 178 260 510 minecraft:amethyst_block
fill 179 260 523 179 263 525 minecraft:amethyst_block
fill 180 260 522 182 261 522 minecraft:amethyst_block
fill 180 260 526 182 261 526 minecraft:amethyst_block
fill 141 261 517 141 307 517 minecraft:obsidian
fill 141 261 518 141 263 518 minecraft:purple_stained_glass
fill 141 261 534 141 263 534 minecraft:purple_stained_glass
fill 141 261 538 141 267 538 minecraft:obsidian
fill 141 261 550 141 263 550 minecraft:purple_stained_glass
fill 145 261 510 145 263 510 minecraft:purple_stained_glass
fill 147 261 512 147 262 514 minecraft:amethyst_block
fill 148 261 513 148 262 516 minecraft:amethyst_block
fill 149 261 512 149 262 514 minecraft:amethyst_block
fill 155 261 552 155 263 552 minecraft:purple_stained_glass
fill 161 261 510 161 263 510 minecraft:purple_stained_glass
fill 171 261 552 171 263 552 minecraft:purple_stained_glass
fill 172 261 552 172 269 552 minecraft:obsidian
fill 176 261 510 176 297 510 minecraft:obsidian
fill 177 261 510 177 263 510 minecraft:purple_stained_glass
fill 178 261 510 178 263 510 minecraft:obsidian
fill 179 261 527 179 262 527 minecraft:crying_obsidian
setblock 183 261 512 minecraft:amethyst_block
fill 183 261 520 183 263 520 minecraft:purple_stained_glass
setblock 183 261 528 minecraft:crying_obsidian
setblock 183 261 530 minecraft:crying_obsidian
fill 183 261 536 183 263 536 minecraft:purple_stained_glass
setblock 183 261 548 minecraft:white_concrete
setblock 147 262 515 minecraft:amethyst_block
fill 148 262 517 148 262 518 minecraft:amethyst_block
setblock 149 262 515 minecraft:amethyst_block
setblock 172 262 510 minecraft:amethyst_block
fill 178 262 524 178 264 524 minecraft:amethyst_block
setblock 183 262 511 minecraft:white_concrete
fill 183 262 512 183 274 512 minecraft:obsidian
setblock 183 262 517 minecraft:crying_obsidian
fill 183 262 528 183 306 528 minecraft:obsidian
fill 183 262 530 183 296 530 minecraft:obsidian
fill 183 262 548 183 281 548 minecraft:obsidian
setblock 141 263 519 minecraft:amethyst_block
setblock 144 263 513 minecraft:light[level=12]
setblock 144 263 521 minecraft:light[level=12]
setblock 144 263 529 minecraft:light[level=12]
setblock 144 263 537 minecraft:light[level=12]
setblock 144 263 545 minecraft:light[level=12]
setblock 148 263 513 minecraft:amethyst_block
setblock 152 263 513 minecraft:light[level=12]
setblock 152 263 521 minecraft:light[level=12]
setblock 152 263 529 minecraft:light[level=12]
setblock 152 263 537 minecraft:light[level=12]
setblock 152 263 545 minecraft:light[level=12]
setblock 160 263 513 minecraft:light[level=12]
setblock 160 263 521 minecraft:light[level=12]
setblock 160 263 529 minecraft:light[level=12]
setblock 160 263 537 minecraft:light[level=12]
setblock 160 263 545 minecraft:light[level=12]
setblock 168 263 513 minecraft:light[level=12]
setblock 168 263 521 minecraft:light[level=12]
setblock 168 263 529 minecraft:light[level=12]
setblock 168 263 537 minecraft:light[level=12]
setblock 168 263 545 minecraft:light[level=12]
fill 171 263 530 171 264 531 minecraft:obsidian
fill 172 263 510 172 307 510 minecraft:obsidian
setblock 176 263 513 minecraft:light[level=12]
setblock 176 263 521 minecraft:light[level=12]
setblock 176 263 529 minecraft:light[level=12]
setblock 176 263 537 minecraft:light[level=12]
setblock 176 263 545 minecraft:light[level=12]
setblock 178 263 523 minecraft:amethyst_block
setblock 178 263 525 minecraft:amethyst_block
fill 180 263 523 180 263 525 minecraft:amethyst_block
setblock 181 263 524 minecraft:amethyst_block
fill 183 263 511 183 265 511 minecraft:obsidian
fill 183 263 517 183 307 517 minecraft:obsidian
setblock 183 263 523 minecraft:crying_obsidian
fill 183 263 524 183 307 525 minecraft:obsidian
setblock 183 263 545 minecraft:crying_obsidian
setblock 141 264 513 minecraft:amethyst_block
fill 141 264 518 141 269 519 minecraft:obsidian
fill 141 264 534 141 269 534 minecraft:obsidian
fill 141 264 550 141 269 550 minecraft:obsidian
schedule function dropper:buildpart/123_2 1t
