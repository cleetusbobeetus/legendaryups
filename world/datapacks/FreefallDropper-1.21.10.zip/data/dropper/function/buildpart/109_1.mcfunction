setblock 50 143 466 minecraft:light[level=14]
setblock 50 143 474 minecraft:light[level=14]
setblock 50 143 482 minecraft:light[level=14]
setblock 50 143 490 minecraft:light[level=14]
setblock 50 143 498 minecraft:light[level=14]
setblock 58 143 466 minecraft:light[level=14]
setblock 58 143 474 minecraft:light[level=14]
setblock 58 143 482 minecraft:light[level=14]
setblock 58 143 490 minecraft:light[level=14]
setblock 58 143 498 minecraft:light[level=14]
fill 64 143 469 69 143 469 minecraft:black_concrete
setblock 66 143 466 minecraft:light[level=14]
setblock 66 143 474 minecraft:light[level=14]
setblock 66 143 482 minecraft:light[level=14]
setblock 66 143 490 minecraft:light[level=14]
setblock 66 143 498 minecraft:light[level=14]
fill 70 143 464 71 143 468 minecraft:quartz_block
setblock 72 143 464 minecraft:quartz_block
fill 72 143 468 76 143 468 minecraft:quartz_block
fill 73 143 465 76 143 467 minecraft:quartz_block
setblock 74 143 474 minecraft:light[level=14]
setblock 74 143 482 minecraft:light[level=14]
setblock 74 143 490 minecraft:light[level=14]
setblock 74 143 498 minecraft:light[level=14]
fill 75 143 464 78 143 464 minecraft:quartz_block
fill 77 143 465 77 144 466 minecraft:quartz_block
setblock 82 143 466 minecraft:light[level=14]
setblock 82 143 474 minecraft:light[level=14]
setblock 82 143 482 minecraft:light[level=14]
setblock 82 143 490 minecraft:light[level=14]
setblock 82 143 498 minecraft:light[level=14]
fill 47 144 468 47 149 468 minecraft:sea_lantern
fill 47 144 476 47 149 476 minecraft:sea_lantern
fill 47 144 484 47 149 484 minecraft:sea_lantern
fill 47 144 492 47 149 492 minecraft:sea_lantern
fill 47 144 500 47 149 500 minecraft:sea_lantern
fill 50 144 505 50 149 505 minecraft:sea_lantern
fill 54 144 463 54 149 463 minecraft:sea_lantern
fill 58 144 505 58 149 505 minecraft:sea_lantern
fill 62 144 463 62 149 463 minecraft:sea_lantern
fill 66 144 505 66 149 505 minecraft:sea_lantern
fill 68 144 469 73 144 469 minecraft:black_concrete
fill 70 144 463 70 149 463 minecraft:sea_lantern
fill 74 144 467 82 144 468 minecraft:quartz_block
fill 74 144 505 74 149 505 minecraft:sea_lantern
fill 75 144 465 76 144 466 minecraft:quartz_block
fill 76 144 464 80 144 464 minecraft:quartz_block
fill 78 144 463 78 149 463 minecraft:sea_lantern
fill 78 144 465 83 144 466 minecraft:quartz_block
fill 82 144 505 82 149 505 minecraft:sea_lantern
fill 83 144 464 85 145 464 minecraft:quartz_block
fill 83 144 467 83 145 467 minecraft:quartz_block
fill 84 144 465 84 145 465 minecraft:quartz_block
fill 86 144 463 86 149 463 minecraft:sea_lantern
fill 89 144 468 89 149 468 minecraft:sea_lantern
fill 89 144 476 89 149 476 minecraft:sea_lantern
fill 89 144 484 89 149 484 minecraft:sea_lantern
fill 89 144 492 89 149 492 minecraft:sea_lantern
fill 89 144 500 89 149 500 minecraft:sea_lantern
fill 71 145 469 77 145 469 minecraft:black_concrete
fill 79 145 468 88 145 468 minecraft:quartz_block
fill 80 145 466 82 145 467 minecraft:quartz_block
fill 81 145 465 83 145 465 minecraft:quartz_block
fill 83 145 466 87 145 466 minecraft:quartz_block
fill 84 145 467 88 145 467 minecraft:quartz_block
fill 84 145 469 85 145 472 minecraft:quartz_block
fill 85 145 465 87 145 465 minecraft:quartz_block
fill 86 145 464 88 145 464 minecraft:quartz_block
fill 86 145 469 86 146 471 minecraft:quartz_block
fill 87 145 469 88 146 470 minecraft:quartz_block
fill 50 146 500 50 146 501 minecraft:gray_concrete
fill 51 146 499 54 146 499 minecraft:gray_concrete
fill 51 146 502 51 146 503 minecraft:gray_concrete
fill 52 146 503 53 146 503 minecraft:gray_concrete
setblock 54 146 500 minecraft:gray_concrete
setblock 54 146 502 minecraft:gray_concrete
fill 75 146 469 83 146 469 minecraft:black_concrete
fill 82 146 499 82 146 501 minecraft:gray_concrete
fill 83 146 470 83 147 470 minecraft:black_concrete
fill 83 146 498 86 146 498 minecraft:gray_concrete
fill 83 146 502 85 146 502 minecraft:gray_concrete
fill 84 146 470 85 146 477 minecraft:quartz_block
setblock 85 146 469 minecraft:quartz_block
fill 86 146 468 88 146 468 minecraft:quartz_block
fill 86 146 472 86 146 477 minecraft:quartz_block
setblock 86 146 499 minecraft:gray_concrete
setblock 86 146 501 minecraft:gray_concrete
fill 87 146 467 88 146 467 minecraft:quartz_block
fill 87 146 471 87 146 476 minecraft:quartz_block
fill 88 146 471 88 146 472 minecraft:quartz_block
fill 88 146 475 88 147 476 minecraft:quartz_block
fill 81 147 469 83 147 469 minecraft:black_concrete
fill 83 147 471 83 147 475 minecraft:black_concrete
fill 84 147 476 84 147 482 minecraft:quartz_block
fill 85 147 475 87 147 481 minecraft:quartz_block
fill 86 147 474 87 147 474 minecraft:quartz_block
fill 88 147 477 88 147 480 minecraft:quartz_block
fill 83 148 473 83 148 479 minecraft:black_concrete
fill 84 148 480 87 148 485 minecraft:quartz_block
fill 85 148 486 88 149 486 minecraft:quartz_block
fill 87 148 479 88 148 479 minecraft:quartz_block
setblock 88 148 480 minecraft:quartz_block
fill 88 148 483 88 148 485 minecraft:quartz_block
fill 83 149 478 83 149 483 minecraft:black_concrete
fill 84 149 484 84 149 490 minecraft:quartz_block
fill 85 149 484 88 149 485 minecraft:quartz_block
fill 85 149 487 87 149 490 minecraft:quartz_block
fill 87 149 491 88 150 491 minecraft:quartz_block
fill 88 149 487 88 149 488 minecraft:quartz_block
fill 47 150 468 47 157 468 minecraft:gray_concrete
fill 47 150 476 47 157 476 minecraft:gray_concrete
fill 47 150 484 47 157 484 minecraft:gray_concrete
fill 47 150 492 47 157 492 minecraft:gray_concrete
fill 47 150 500 47 157 500 minecraft:gray_concrete
fill 50 150 505 50 157 505 minecraft:gray_concrete
fill 54 150 463 54 157 463 minecraft:gray_concrete
fill 58 150 505 58 157 505 minecraft:gray_concrete
fill 62 150 463 62 157 463 minecraft:gray_concrete
fill 66 150 505 66 157 505 minecraft:gray_concrete
fill 70 150 463 70 157 463 minecraft:gray_concrete
fill 74 150 505 74 157 505 minecraft:gray_concrete
fill 78 150 463 78 157 463 minecraft:gray_concrete
fill 82 150 505 82 157 505 minecraft:gray_concrete
fill 83 150 482 83 150 487 minecraft:black_concrete
fill 84 150 488 86 150 495 minecraft:quartz_block
fill 86 150 463 86 157 463 minecraft:gray_concrete
fill 86 150 496 88 151 496 minecraft:quartz_block
fill 87 150 489 87 150 490 minecraft:quartz_block
fill 87 150 492 88 150 495 minecraft:quartz_block
fill 87 150 497 87 151 497 minecraft:quartz_block
fill 89 150 468 89 157 468 minecraft:gray_concrete
fill 89 150 476 89 157 476 minecraft:gray_concrete
fill 89 150 484 89 157 484 minecraft:gray_concrete
fill 89 150 492 89 157 492 minecraft:gray_concrete
fill 89 150 500 89 157 500 minecraft:gray_concrete
setblock 50 151 466 minecraft:light[level=14]
setblock 50 151 474 minecraft:light[level=14]
setblock 50 151 482 minecraft:light[level=14]
setblock 50 151 490 minecraft:light[level=14]
setblock 50 151 498 minecraft:light[level=14]
setblock 58 151 466 minecraft:light[level=14]
setblock 58 151 474 minecraft:light[level=14]
setblock 58 151 482 minecraft:light[level=14]
setblock 58 151 490 minecraft:light[level=14]
setblock 58 151 498 minecraft:light[level=14]
setblock 66 151 466 minecraft:light[level=14]
setblock 66 151 474 minecraft:light[level=14]
setblock 66 151 482 minecraft:light[level=14]
setblock 66 151 490 minecraft:light[level=14]
setblock 66 151 498 minecraft:light[level=14]
setblock 74 151 466 minecraft:light[level=14]
setblock 74 151 474 minecraft:light[level=14]
setblock 74 151 482 minecraft:light[level=14]
setblock 74 151 490 minecraft:light[level=14]
setblock 74 151 498 minecraft:light[level=14]
setblock 82 151 466 minecraft:light[level=14]
setblock 82 151 474 minecraft:light[level=14]
setblock 82 151 482 minecraft:light[level=14]
setblock 82 151 490 minecraft:light[level=14]
setblock 82 151 498 minecraft:light[level=14]
fill 83 151 486 83 151 491 minecraft:black_concrete
fill 84 151 492 84 151 498 minecraft:quartz_block
fill 84 151 502 88 152 502 minecraft:quartz_block
fill 85 151 493 85 151 498 minecraft:quartz_block
fill 85 151 503 88 152 503 minecraft:quartz_block
fill 86 151 493 86 151 495 minecraft:quartz_block
fill 86 151 497 86 151 499 minecraft:quartz_block
fill 86 151 501 88 152 501 minecraft:quartz_block
fill 87 151 494 88 151 495 minecraft:quartz_block
fill 87 151 498 87 151 500 minecraft:quartz_block
fill 88 151 499 88 151 500 minecraft:quartz_block
fill 88 151 504 88 152 504 minecraft:quartz_block
fill 77 152 500 82 152 501 minecraft:quartz_block
fill 78 152 502 83 152 503 minecraft:quartz_block
fill 80 152 504 85 152 504 minecraft:quartz_block
fill 83 152 489 83 152 496 minecraft:black_concrete
setblock 84 152 498 minecraft:quartz_block
setblock 84 152 503 minecraft:quartz_block
fill 72 153 500 79 153 500 minecraft:quartz_block
fill 73 153 501 77 153 504 minecraft:quartz_block
fill 78 153 501 80 153 503 minecraft:quartz_block
fill 79 153 499 83 153 499 minecraft:black_concrete
fill 80 153 504 82 155 504 minecraft:quartz_block
fill 81 153 502 81 153 503 minecraft:quartz_block
fill 83 153 494 83 153 498 minecraft:black_concrete
fill 48 154 464 48 155 469 minecraft:quartz_block
fill 48 154 472 49 154 477 minecraft:quartz_block
fill 48 154 480 49 154 485 minecraft:quartz_block
fill 48 154 488 49 154 493 minecraft:quartz_block
fill 48 154 496 49 154 501 minecraft:quartz_block
fill 48 154 504 53 155 504 minecraft:quartz_block
fill 49 154 465 49 154 471 minecraft:quartz_block
fill 49 154 478 49 154 479 minecraft:quartz_block
fill 49 154 486 49 154 487 minecraft:quartz_block
fill 49 154 494 49 154 495 minecraft:quartz_block
fill 49 154 502 49 154 503 minecraft:quartz_block
fill 50 154 465 87 154 465 minecraft:quartz_block
fill 50 154 500 50 154 501 minecraft:gray_concrete
fill 50 154 503 88 154 503 minecraft:quartz_block
fill 51 154 464 56 155 464 minecraft:quartz_block
fill 51 154 499 54 154 499 minecraft:gray_concrete
setblock 51 154 502 minecraft:gray_concrete
setblock 54 154 500 minecraft:gray_concrete
setblock 54 154 502 minecraft:gray_concrete
fill 56 154 466 56 155 466 minecraft:iron_block
fill 56 154 504 61 155 504 minecraft:quartz_block
fill 59 154 464 64 155 464 minecraft:quartz_block
fill 64 154 504 69 155 504 minecraft:quartz_block
fill 67 154 464 72 155 464 minecraft:quartz_block
fill 68 154 500 74 154 502 minecraft:quartz_block
fill 72 154 504 77 155 504 minecraft:quartz_block
fill 75 154 464 80 155 464 minecraft:quartz_block
fill 75 154 499 82 154 499 minecraft:black_concrete
setblock 75 154 502 minecraft:quartz_block
fill 82 154 500 82 154 501 minecraft:gray_concrete
fill 83 154 464 88 155 464 minecraft:quartz_block
fill 83 154 498 86 154 498 minecraft:gray_concrete
fill 83 154 499 83 174 499 minecraft:quartz_block
fill 83 154 502 85 154 502 minecraft:gray_concrete
fill 83 154 504 85 155 504 minecraft:quartz_block
setblock 86 154 499 minecraft:gray_concrete
setblock 86 154 501 minecraft:gray_concrete
fill 87 154 466 87 154 502 minecraft:quartz_block
fill 88 154 467 88 155 472 minecraft:quartz_block
fill 88 154 475 88 155 480 minecraft:quartz_block
fill 88 154 483 88 155 488 minecraft:quartz_block
fill 88 154 491 88 155 496 minecraft:quartz_block
fill 88 154 499 88 155 502 minecraft:quartz_block
fill 88 154 504 88 155 504 minecraft:quartz_block
fill 48 155 472 48 155 477 minecraft:quartz_block
fill 48 155 480 48 155 485 minecraft:quartz_block
fill 48 155 488 48 155 493 minecraft:quartz_block
fill 48 155 496 48 155 501 minecraft:quartz_block
setblock 56 155 465 minecraft:iron_block
fill 64 155 501 70 155 503 minecraft:quartz_block
fill 65 155 500 70 155 500 minecraft:quartz_block
fill 71 155 499 76 155 499 minecraft:black_concrete
setblock 88 155 503 minecraft:quartz_block
fill 58 156 504 61 156 504 minecraft:quartz_block
fill 59 156 502 66 156 503 minecraft:quartz_block
fill 60 156 500 66 156 501 minecraft:quartz_block
fill 64 156 504 66 156 504 minecraft:quartz_block
fill 67 156 499 72 156 499 minecraft:black_concrete
fill 51 157 504 53 158 504 minecraft:quartz_block
fill 52 157 503 61 157 503 minecraft:quartz_block
fill 54 157 500 62 157 500 minecraft:quartz_block
fill 54 157 502 61 157 502 minecraft:quartz_block
fill 55 157 501 62 157 501 minecraft:quartz_block
fill 56 157 504 60 157 504 minecraft:quartz_block
fill 63 157 499 68 157 499 minecraft:black_concrete
fill 47 158 468 47 163 468 minecraft:sea_lantern
fill 47 158 476 47 163 476 minecraft:sea_lantern
fill 47 158 484 47 163 484 minecraft:sea_lantern
fill 47 158 492 47 163 492 minecraft:sea_lantern
fill 47 158 500 47 163 500 minecraft:sea_lantern
fill 48 158 498 50 158 501 minecraft:quartz_block
fill 48 158 504 50 158 504 minecraft:quartz_block
fill 49 158 502 51 158 503 minecraft:quartz_block
fill 50 158 497 52 159 497 minecraft:quartz_block
fill 50 158 505 50 163 505 minecraft:sea_lantern
fill 51 158 496 52 159 496 minecraft:quartz_block
fill 51 158 498 52 158 499 minecraft:quartz_block
fill 52 158 503 55 158 503 minecraft:quartz_block
fill 54 158 463 54 163 463 minecraft:sea_lantern
fill 54 158 500 57 158 500 minecraft:quartz_block
fill 54 158 502 56 158 502 minecraft:quartz_block
fill 55 158 501 56 158 501 minecraft:quartz_block
fill 58 158 505 58 163 505 minecraft:sea_lantern
fill 59 158 499 65 158 499 minecraft:black_concrete
fill 62 158 463 62 163 463 minecraft:sea_lantern
fill 66 158 505 66 163 505 minecraft:sea_lantern
fill 70 158 463 70 163 463 minecraft:sea_lantern
fill 74 158 505 74 163 505 minecraft:sea_lantern
fill 78 158 463 78 163 463 minecraft:sea_lantern
fill 82 158 505 82 163 505 minecraft:sea_lantern
fill 86 158 463 86 163 463 minecraft:sea_lantern
fill 89 158 468 89 163 468 minecraft:sea_lantern
fill 89 158 476 89 163 476 minecraft:sea_lantern
fill 89 158 484 89 163 484 minecraft:sea_lantern
fill 89 158 492 89 163 492 minecraft:sea_lantern
fill 89 158 500 89 163 500 minecraft:sea_lantern
fill 48 159 492 52 159 493 minecraft:quartz_block
fill 48 159 496 49 159 501 minecraft:quartz_block
fill 49 159 494 52 159 495 minecraft:quartz_block
setblock 50 159 466 minecraft:light[level=14]
setblock 50 159 474 minecraft:light[level=14]
setblock 50 159 482 minecraft:light[level=14]
setblock 50 159 490 minecraft:light[level=14]
fill 50 159 491 52 160 491 minecraft:quartz_block
setblock 50 159 496 minecraft:quartz_block
fill 50 159 498 50 159 500 minecraft:quartz_block
fill 51 159 498 51 159 499 minecraft:quartz_block
setblock 52 159 498 minecraft:quartz_block
fill 53 159 498 53 160 499 minecraft:black_concrete
fill 54 159 499 61 159 499 minecraft:black_concrete
setblock 58 159 466 minecraft:light[level=14]
setblock 58 159 474 minecraft:light[level=14]
setblock 58 159 482 minecraft:light[level=14]
setblock 58 159 490 minecraft:light[level=14]
setblock 58 159 498 minecraft:light[level=14]
setblock 66 159 466 minecraft:light[level=14]
setblock 66 159 474 minecraft:light[level=14]
setblock 66 159 482 minecraft:light[level=14]
setblock 66 159 490 minecraft:light[level=14]
setblock 66 159 498 minecraft:light[level=14]
setblock 74 159 466 minecraft:light[level=14]
setblock 74 159 474 minecraft:light[level=14]
setblock 74 159 482 minecraft:light[level=14]
setblock 74 159 490 minecraft:light[level=14]
setblock 74 159 498 minecraft:light[level=14]
setblock 82 159 466 minecraft:light[level=14]
setblock 82 159 474 minecraft:light[level=14]
setblock 82 159 482 minecraft:light[level=14]
setblock 82 159 490 minecraft:light[level=14]
setblock 82 159 498 minecraft:light[level=14]
fill 48 160 488 49 160 493 minecraft:quartz_block
fill 49 160 487 52 161 487 minecraft:quartz_block
fill 49 160 494 50 160 494 minecraft:quartz_block
fill 50 160 488 52 160 490 minecraft:quartz_block
fill 50 160 492 51 160 493 minecraft:quartz_block
fill 52 160 486 52 161 486 minecraft:quartz_block
setblock 52 160 492 minecraft:quartz_block
fill 53 160 493 53 160 497 minecraft:black_concrete
fill 54 160 499 55 160 499 minecraft:black_concrete
fill 48 161 482 51 161 485 minecraft:quartz_block
fill 48 161 488 49 161 489 minecraft:quartz_block
fill 49 161 486 51 161 486 minecraft:quartz_block
fill 50 161 488 52 161 488 minecraft:quartz_block
fill 52 161 483 52 161 485 minecraft:quartz_block
fill 53 161 489 53 161 495 minecraft:black_concrete
fill 48 162 477 49 163 477 minecraft:quartz_block
fill 48 162 480 52 162 484 minecraft:quartz_block
fill 49 162 478 52 163 479 minecraft:quartz_block
fill 50 162 500 50 162 501 minecraft:gray_concrete
fill 51 162 499 54 162 499 minecraft:gray_concrete
fill 51 162 502 51 162 503 minecraft:gray_concrete
fill 52 162 503 53 162 503 minecraft:gray_concrete
fill 53 162 485 53 162 490 minecraft:black_concrete
setblock 54 162 500 minecraft:gray_concrete
setblock 54 162 502 minecraft:gray_concrete
fill 82 162 499 82 162 501 minecraft:gray_concrete
fill 83 162 498 86 162 498 minecraft:gray_concrete
fill 83 162 502 85 162 502 minecraft:gray_concrete
setblock 86 162 499 minecraft:gray_concrete
setblock 86 162 501 minecraft:gray_concrete
fill 48 163 472 50 163 476 minecraft:quartz_block
fill 49 163 471 49 164 471 minecraft:quartz_block
fill 50 163 477 52 163 477 minecraft:quartz_block
fill 50 163 480 52 163 480 minecraft:quartz_block
fill 51 163 473 52 163 476 minecraft:quartz_block
fill 53 163 481 53 163 486 minecraft:black_concrete
fill 47 164 468 47 168 468 minecraft:gray_concrete
setblock 47 164 476 minecraft:gray_concrete
fill 47 164 484 47 168 484 minecraft:gray_concrete
fill 47 164 492 47 168 492 minecraft:gray_concrete
fill 47 164 500 47 166 500 minecraft:gray_concrete
fill 48 164 464 48 164 469 minecraft:quartz_block
fill 48 164 472 52 164 474 minecraft:quartz_block
fill 49 164 465 51 164 470 minecraft:quartz_block
fill 50 164 471 52 164 471 minecraft:quartz_block
fill 50 164 475 52 164 475 minecraft:quartz_block
fill 50 164 505 50 168 505 minecraft:gray_concrete
fill 52 164 466 52 165 470 minecraft:quartz_block
setblock 52 164 476 minecraft:quartz_block
fill 53 164 468 53 165 468 minecraft:quartz_block
fill 53 164 477 53 164 482 minecraft:black_concrete
fill 54 164 463 54 168 463 minecraft:gray_concrete
fill 58 164 505 58 168 505 minecraft:gray_concrete
fill 62 164 463 62 168 463 minecraft:gray_concrete
fill 66 164 505 66 168 505 minecraft:gray_concrete
fill 70 164 463 70 168 463 minecraft:gray_concrete
fill 74 164 505 74 169 505 minecraft:gray_concrete
fill 78 164 463 78 168 463 minecraft:gray_concrete
fill 82 164 505 82 168 505 minecraft:gray_concrete
fill 86 164 463 86 168 463 minecraft:gray_concrete
fill 89 164 468 89 168 468 minecraft:gray_concrete
fill 89 164 476 89 169 476 minecraft:gray_concrete
fill 89 164 484 89 168 484 minecraft:gray_concrete
fill 89 164 492 89 168 492 minecraft:gray_concrete
fill 89 164 500 89 168 500 minecraft:gray_concrete
fill 47 165 463 47 168 464 minecraft:gray_concrete
setblock 47 165 465 minecraft:light_gray_concrete
fill 47 165 466 47 168 467 minecraft:gray_concrete
fill 47 165 476 47 166 476 minecraft:light_gray_concrete
setblock 47 165 481 minecraft:light_gray_concrete
fill 47 165 482 47 166 482 minecraft:gray_concrete
setblock 47 165 485 minecraft:light_gray_concrete
fill 47 165 486 47 168 486 minecraft:gray_concrete
setblock 47 165 496 minecraft:light_gray_concrete
fill 47 165 497 47 168 497 minecraft:gray_concrete
fill 47 165 501 47 168 503 minecraft:gray_concrete
setblock 47 165 504 minecraft:light_gray_concrete
fill 48 165 464 48 165 467 minecraft:quartz_block
fill 49 165 465 51 165 467 minecraft:quartz_block
fill 50 165 468 51 165 468 minecraft:quartz_block
fill 51 165 464 56 165 464 minecraft:quartz_block
setblock 51 165 469 minecraft:quartz_block
fill 51 165 505 51 168 505 minecraft:gray_concrete
fill 52 165 465 58 165 465 minecraft:quartz_block
setblock 52 165 505 minecraft:light_gray_concrete
fill 53 165 466 58 165 467 minecraft:quartz_block
fill 53 165 472 53 165 479 minecraft:black_concrete
fill 53 165 505 55 165 505 minecraft:gray_concrete
fill 54 165 468 59 165 468 minecraft:quartz_block
setblock 56 165 505 minecraft:light_gray_concrete
setblock 57 165 505 minecraft:gray_concrete
fill 59 165 467 59 166 467 minecraft:quartz_block
fill 64 165 463 68 168 463 minecraft:gray_concrete
setblock 69 165 463 minecraft:light_gray_concrete
setblock 73 165 463 minecraft:light_gray_concrete
fill 74 165 463 75 165 463 minecraft:gray_concrete
fill 89 165 469 89 169 469 minecraft:gray_concrete
fill 89 165 470 89 166 470 minecraft:light_gray_concrete
fill 89 165 485 89 168 489 minecraft:gray_concrete
setblock 89 165 490 minecraft:light_gray_concrete
fill 89 165 491 89 166 491 minecraft:gray_concrete
fill 47 166 465 47 168 465 minecraft:gray_concrete
setblock 47 166 475 minecraft:light_gray_concrete
setblock 47 166 477 minecraft:light_gray_concrete
fill 47 166 478 47 169 478 minecraft:gray_concrete
setblock 47 166 479 minecraft:light_gray_concrete
fill 47 166 481 47 168 481 minecraft:gray_concrete
setblock 47 166 483 minecraft:light_gray_concrete
fill 47 166 485 47 168 485 minecraft:gray_concrete
fill 47 166 496 47 168 496 minecraft:gray_concrete
fill 47 166 504 47 168 504 minecraft:gray_concrete
setblock 48 166 463 minecraft:light_gray_concrete
fill 49 166 463 53 168 463 minecraft:gray_concrete
fill 52 166 505 53 168 505 minecraft:gray_concrete
fill 53 166 469 53 166 474 minecraft:black_concrete
fill 54 166 464 56 166 464 minecraft:quartz_block
fill 54 166 469 57 167 469 minecraft:black_concrete
setblock 54 166 505 minecraft:light_gray_concrete
fill 55 166 465 63 166 466 minecraft:quartz_block
fill 55 166 505 56 168 505 minecraft:gray_concrete
fill 56 166 467 58 166 467 minecraft:quartz_block
fill 57 166 468 64 166 468 minecraft:quartz_block
setblock 57 166 505 minecraft:light_gray_concrete
fill 59 166 464 63 166 464 minecraft:quartz_block
fill 59 166 505 59 168 505 minecraft:gray_concrete
fill 60 166 467 63 166 467 minecraft:quartz_block
setblock 60 166 505 minecraft:light_gray_concrete
setblock 62 166 505 minecraft:light_gray_concrete
setblock 63 166 463 minecraft:light_gray_concrete
setblock 68 166 505 minecraft:light_gray_concrete
fill 69 166 463 69 168 463 minecraft:gray_concrete
fill 69 166 505 69 169 505 minecraft:gray_concrete
setblock 70 166 505 minecraft:light_gray_concrete
fill 71 166 463 72 166 463 minecraft:light_gray_concrete
fill 71 166 505 71 168 505 minecraft:gray_concrete
setblock 72 166 505 minecraft:light_gray_concrete
fill 73 166 463 74 168 463 minecraft:gray_concrete
fill 73 166 505 73 168 505 minecraft:gray_concrete
setblock 75 166 463 minecraft:light_gray_concrete
fill 79 166 463 80 166 463 minecraft:gray_concrete
fill 81 166 463 81 167 463 minecraft:light_gray_concrete
fill 82 166 463 85 168 463 minecraft:gray_concrete
fill 83 166 505 83 167 505 minecraft:light_gray_concrete
fill 87 166 463 87 168 463 minecraft:gray_concrete
fill 87 166 505 88 168 505 minecraft:gray_concrete
setblock 88 166 463 minecraft:light_gray_concrete
fill 89 166 464 89 166 465 minecraft:gray_concrete
fill 89 166 466 89 167 466 minecraft:light_gray_concrete
setblock 89 166 477 minecraft:light_gray_concrete
fill 89 166 478 89 168 482 minecraft:gray_concrete
setblock 89 166 483 minecraft:light_gray_concrete
setblock 89 166 490 minecraft:gray_concrete
fill 89 166 493 89 166 498 minecraft:gray_concrete
setblock 89 166 499 minecraft:light_gray_concrete
setblock 89 166 505 minecraft:light_gray_concrete
fill 47 167 475 47 168 477 minecraft:gray_concrete
fill 47 167 479 47 168 479 minecraft:gray_concrete
setblock 47 167 482 minecraft:light_gray_concrete
fill 47 167 483 47 168 483 minecraft:gray_concrete
setblock 47 167 490 minecraft:light_gray_concrete
fill 47 167 491 47 168 491 minecraft:gray_concrete
setblock 47 167 500 minecraft:light_gray_concrete
fill 48 167 463 48 168 463 minecraft:gray_concrete
setblock 50 167 466 minecraft:light[level=14]
setblock 50 167 474 minecraft:light[level=14]
setblock 50 167 482 minecraft:light[level=14]
setblock 50 167 490 minecraft:light[level=14]
setblock 50 167 498 minecraft:light[level=14]
fill 54 167 505 54 168 505 minecraft:gray_concrete
fill 55 167 463 59 168 463 minecraft:gray_concrete
fill 57 167 505 57 169 505 minecraft:gray_concrete
setblock 58 167 466 minecraft:light[level=14]
fill 58 167 469 61 167 469 minecraft:black_concrete
setblock 58 167 474 minecraft:light[level=14]
setblock 58 167 482 minecraft:light[level=14]
setblock 58 167 490 minecraft:light[level=14]
setblock 58 167 498 minecraft:light[level=14]
setblock 60 167 463 minecraft:light_gray_concrete
fill 60 167 464 64 169 464 minecraft:quartz_block
fill 60 167 505 60 169 505 minecraft:gray_concrete
fill 61 167 463 61 168 463 minecraft:gray_concrete
fill 61 167 465 68 167 466 minecraft:quartz_block
fill 62 167 467 68 167 468 minecraft:quartz_block
fill 62 167 505 62 168 505 minecraft:gray_concrete
fill 63 167 463 63 168 463 minecraft:gray_concrete
setblock 66 167 474 minecraft:light[level=14]
setblock 66 167 482 minecraft:light[level=14]
setblock 66 167 490 minecraft:light[level=14]
setblock 66 167 498 minecraft:light[level=14]
fill 67 167 464 68 169 464 minecraft:quartz_block
fill 68 167 505 68 169 505 minecraft:gray_concrete
fill 70 167 505 70 168 505 minecraft:gray_concrete
fill 71 167 463 72 168 463 minecraft:gray_concrete
fill 72 167 505 72 168 505 minecraft:gray_concrete
setblock 74 167 466 minecraft:light[level=14]
setblock 74 167 474 minecraft:light[level=14]
setblock 74 167 482 minecraft:light[level=14]
setblock 74 167 490 minecraft:light[level=14]
setblock 74 167 498 minecraft:light[level=14]
fill 75 167 463 75 168 463 minecraft:gray_concrete
setblock 79 167 463 minecraft:light_gray_concrete
fill 80 167 463 80 168 463 minecraft:gray_concrete
setblock 81 167 505 minecraft:light_gray_concrete
setblock 82 167 466 minecraft:light[level=14]
setblock 82 167 474 minecraft:light[level=14]
setblock 82 167 482 minecraft:light[level=14]
setblock 82 167 490 minecraft:light[level=14]
setblock 82 167 498 minecraft:light[level=14]
setblock 84 167 505 minecraft:light_gray_concrete
fill 85 167 505 85 169 505 minecraft:gray_concrete
setblock 86 167 505 minecraft:light_gray_concrete
fill 88 167 463 88 168 463 minecraft:gray_concrete
fill 89 167 464 89 167 465 minecraft:light_gray_concrete
setblock 89 167 467 minecraft:light_gray_concrete
fill 89 167 470 89 168 470 minecraft:gray_concrete
fill 89 167 477 89 168 477 minecraft:gray_concrete
fill 89 167 483 89 168 483 minecraft:gray_concrete
fill 89 167 490 89 167 491 minecraft:light_gray_concrete
fill 89 167 493 89 168 495 minecraft:gray_concrete
fill 89 167 496 89 167 498 minecraft:light_gray_concrete
fill 89 167 499 89 168 499 minecraft:gray_concrete
fill 89 167 505 89 168 505 minecraft:gray_concrete
setblock 47 168 482 minecraft:gray_concrete
setblock 47 168 490 minecraft:gray_concrete
setblock 47 168 500 minecraft:gray_concrete
fill 48 168 464 48 169 469 minecraft:quartz_block
fill 48 168 472 49 168 477 minecraft:quartz_block
fill 48 168 480 49 168 485 minecraft:quartz_block
fill 48 168 488 49 168 493 minecraft:quartz_block
fill 48 168 496 49 168 501 minecraft:quartz_block
fill 48 168 504 53 169 504 minecraft:quartz_block
fill 49 168 465 49 168 471 minecraft:quartz_block
fill 49 168 478 49 168 479 minecraft:quartz_block
fill 49 168 486 49 168 487 minecraft:quartz_block
fill 49 168 494 49 168 495 minecraft:quartz_block
fill 49 168 502 49 168 503 minecraft:quartz_block
fill 50 168 465 87 168 465 minecraft:quartz_block
fill 50 168 503 88 168 503 minecraft:quartz_block
fill 51 168 464 56 169 464 minecraft:quartz_block
fill 56 168 504 61 169 504 minecraft:quartz_block
fill 59 168 464 59 169 464 minecraft:quartz_block
setblock 60 168 463 minecraft:gray_concrete
fill 60 168 469 65 168 469 minecraft:black_concrete
fill 64 168 504 69 169 504 minecraft:quartz_block
fill 66 168 466 71 168 468 minecraft:quartz_block
fill 69 168 464 72 169 464 minecraft:quartz_block
fill 72 168 466 72 169 467 minecraft:quartz_block
fill 72 168 504 77 169 504 minecraft:quartz_block
fill 75 168 464 80 169 464 minecraft:quartz_block
setblock 79 168 463 minecraft:gray_concrete
fill 80 168 504 85 169 504 minecraft:quartz_block
fill 81 168 463 81 169 463 minecraft:gray_concrete
setblock 81 168 505 minecraft:gray_concrete
fill 83 168 464 88 169 464 minecraft:quartz_block
fill 83 168 505 84 168 505 minecraft:gray_concrete
setblock 86 168 505 minecraft:gray_concrete
fill 87 168 466 87 168 502 minecraft:quartz_block
fill 88 168 467 88 169 472 minecraft:quartz_block
fill 88 168 475 88 169 480 minecraft:quartz_block
fill 88 168 483 88 169 488 minecraft:quartz_block
fill 88 168 491 88 169 496 minecraft:quartz_block
fill 88 168 499 88 169 502 minecraft:quartz_block
fill 88 168 504 88 169 504 minecraft:quartz_block
fill 89 168 464 89 168 467 minecraft:gray_concrete
fill 89 168 490 89 168 491 minecraft:gray_concrete
fill 89 168 496 89 168 498 minecraft:gray_concrete
fill 47 169 463 48 170 463 minecraft:light_gray_concrete
setblock 47 169 464 minecraft:gray_concrete
fill 47 169 465 47 169 466 minecraft:light_gray_concrete
setblock 47 169 467 minecraft:gray_concrete
fill 47 169 468 47 171 469 minecraft:light_gray_concrete
setblock 47 169 471 minecraft:gray_concrete
fill 47 169 472 47 170 477 minecraft:light_gray_concrete
fill 47 169 479 47 169 505 minecraft:light_gray_concrete
fill 48 169 472 48 169 477 minecraft:quartz_block
fill 48 169 480 48 169 485 minecraft:quartz_block
fill 48 169 488 48 169 493 minecraft:quartz_block
fill 48 169 496 48 169 501 minecraft:quartz_block
fill 48 169 505 56 169 505 minecraft:light_gray_concrete
setblock 49 169 463 minecraft:gray_concrete
fill 50 169 463 80 169 463 minecraft:light_gray_concrete
fill 58 169 505 59 171 505 minecraft:light_gray_concrete
fill 61 169 505 67 169 505 minecraft:light_gray_concrete
fill 64 169 469 69 169 469 minecraft:black_concrete
fill 70 169 465 71 169 468 minecraft:quartz_block
fill 70 169 505 73 234 505 minecraft:light_gray_concrete
fill 72 169 465 77 169 465 minecraft:quartz_block
fill 72 169 468 76 169 468 minecraft:quartz_block
fill 73 169 466 76 169 467 minecraft:quartz_block
fill 75 169 505 76 169 505 minecraft:light_gray_concrete
fill 77 169 466 77 170 466 minecraft:quartz_block
fill 78 169 505 84 169 505 minecraft:light_gray_concrete
fill 82 169 463 89 169 463 minecraft:light_gray_concrete
fill 86 169 505 89 170 505 minecraft:light_gray_concrete
setblock 88 169 503 minecraft:quartz_block
fill 89 169 464 89 171 468 minecraft:light_gray_concrete
fill 89 169 470 89 169 474 minecraft:light_gray_concrete
fill 89 169 477 89 169 488 minecraft:light_gray_concrete
setblock 89 169 489 minecraft:gray_concrete
fill 89 169 490 89 171 496 minecraft:light_gray_concrete
setblock 89 169 497 minecraft:gray_concrete
fill 89 169 498 89 170 504 minecraft:light_gray_concrete
fill 47 170 464 47 238 465 minecraft:light_gray_concrete
setblock 47 170 466 minecraft:gray_concrete
fill 47 170 467 47 239 467 minecraft:light_gray_concrete
fill 47 170 470 47 170 471 minecraft:light_gray_concrete
fill 47 170 478 47 170 497 minecraft:light_gray_concrete
setblock 47 170 498 minecraft:gray_concrete
fill 47 170 499 47 171 500 minecraft:light_gray_concrete
setblock 47 170 501 minecraft:gray_concrete
fill 47 170 502 47 238 504 minecraft:light_gray_concrete
setblock 47 170 505 minecraft:gray_concrete
fill 48 170 505 55 170 505 minecraft:light_gray_concrete
fill 49 170 463 68 170 463 minecraft:light_gray_concrete
fill 50 170 500 50 170 501 minecraft:gray_concrete
fill 51 170 499 54 170 499 minecraft:gray_concrete
fill 51 170 502 51 170 503 minecraft:gray_concrete
fill 52 170 503 53 170 503 minecraft:gray_concrete
setblock 54 170 500 minecraft:gray_concrete
setblock 54 170 502 minecraft:gray_concrete
setblock 56 170 505 minecraft:gray_concrete
fill 57 170 505 57 238 505 minecraft:light_gray_concrete
fill 60 170 505 65 170 505 minecraft:light_gray_concrete
setblock 66 170 505 minecraft:gray_concrete
fill 67 170 505 69 236 505 minecraft:light_gray_concrete
fill 68 170 469 73 170 469 minecraft:black_concrete
fill 69 170 463 69 171 463 minecraft:gray_concrete
fill 70 170 463 75 170 463 minecraft:light_gray_concrete
fill 74 170 467 82 170 468 minecraft:quartz_block
fill 74 170 505 75 171 505 minecraft:light_gray_concrete
fill 75 170 465 76 170 466 minecraft:quartz_block
setblock 76 170 463 minecraft:gray_concrete
fill 76 170 464 80 170 464 minecraft:quartz_block
setblock 76 170 505 minecraft:gray_concrete
fill 77 170 463 82 171 463 minecraft:light_gray_concrete
fill 77 170 465 84 170 465 minecraft:quartz_block
fill 77 170 505 83 170 505 minecraft:light_gray_concrete
fill 78 170 466 83 170 466 minecraft:quartz_block
fill 82 170 499 82 170 501 minecraft:gray_concrete
setblock 83 170 463 minecraft:gray_concrete
fill 83 170 464 85 171 464 minecraft:quartz_block
fill 83 170 467 83 171 467 minecraft:quartz_block
fill 83 170 498 86 170 498 minecraft:gray_concrete
fill 83 170 502 85 170 502 minecraft:gray_concrete
fill 84 170 463 88 170 463 minecraft:light_gray_concrete
fill 84 170 505 84 171 505 minecraft:gray_concrete
fill 85 170 505 85 238 505 minecraft:light_gray_concrete
setblock 86 170 499 minecraft:gray_concrete
setblock 86 170 501 minecraft:gray_concrete
setblock 89 170 463 minecraft:gray_concrete
fill 89 170 469 89 170 473 minecraft:light_gray_concrete
setblock 89 170 474 minecraft:gray_concrete
fill 89 170 475 89 170 483 minecraft:light_gray_concrete
setblock 89 170 484 minecraft:gray_concrete
fill 89 170 485 89 234 489 minecraft:light_gray_concrete
fill 89 170 497 89 238 497 minecraft:light_gray_concrete
setblock 47 171 463 minecraft:gray_concrete
fill 47 171 466 47 238 466 minecraft:light_gray_concrete
setblock 47 171 470 minecraft:gray_concrete
fill 47 171 471 47 239 471 minecraft:light_gray_concrete
setblock 47 171 472 minecraft:gray_concrete
fill 47 171 473 47 171 477 minecraft:light_gray_concrete
setblock 47 171 478 minecraft:gray_concrete
fill 47 171 479 47 171 498 minecraft:light_gray_concrete
fill 47 171 501 47 238 501 minecraft:light_gray_concrete
fill 47 171 505 52 171 505 minecraft:light_gray_concrete
fill 48 171 463 50 238 463 minecraft:light_gray_concrete
fill 51 171 463 52 171 463 minecraft:gray_concrete
fill 53 171 463 68 171 463 minecraft:light_gray_concrete
fill 53 171 505 54 171 505 minecraft:gray_concrete
fill 55 171 505 56 238 505 minecraft:light_gray_concrete
fill 60 171 505 61 238 505 minecraft:light_gray_concrete
setblock 62 171 505 minecraft:gray_concrete
fill 63 171 505 66 171 505 minecraft:light_gray_concrete
setblock 70 171 463 minecraft:light_gray_concrete
setblock 71 171 463 minecraft:gray_concrete
fill 71 171 469 77 171 469 minecraft:black_concrete
fill 72 171 463 72 236 463 minecraft:light_gray_concrete
setblock 73 171 463 minecraft:gray_concrete
fill 74 171 463 74 238 463 minecraft:light_gray_concrete
setblock 75 171 463 minecraft:gray_concrete
fill 76 171 463 76 239 463 minecraft:light_gray_concrete
fill 76 171 505 77 238 505 minecraft:light_gray_concrete
fill 78 171 505 79 171 505 minecraft:gray_concrete
fill 79 171 468 88 171 468 minecraft:quartz_block
fill 80 171 466 82 171 467 minecraft:quartz_block
fill 80 171 505 80 238 505 minecraft:light_gray_concrete
fill 81 171 465 87 171 465 minecraft:quartz_block
fill 81 171 505 82 171 505 minecraft:gray_concrete
fill 83 171 463 85 238 463 minecraft:light_gray_concrete
fill 83 171 466 87 171 466 minecraft:quartz_block
fill 83 171 505 83 234 505 minecraft:light_gray_concrete
fill 84 171 467 88 171 467 minecraft:quartz_block
fill 84 171 469 85 171 472 minecraft:quartz_block
setblock 86 171 463 minecraft:gray_concrete
fill 86 171 464 88 171 464 minecraft:quartz_block
fill 86 171 469 86 172 471 minecraft:quartz_block
fill 86 171 505 88 238 505 minecraft:light_gray_concrete
fill 87 171 463 89 235 463 minecraft:light_gray_concrete
fill 87 171 469 88 172 470 minecraft:quartz_block
fill 89 171 469 89 236 470 minecraft:light_gray_concrete
setblock 89 171 471 minecraft:gray_concrete
fill 89 171 472 89 234 474 minecraft:light_gray_concrete
setblock 89 171 475 minecraft:gray_concrete
fill 89 171 476 89 171 477 minecraft:light_gray_concrete
setblock 89 171 478 minecraft:gray_concrete
fill 89 171 479 89 171 484 minecraft:light_gray_concrete
fill 89 171 498 89 238 498 minecraft:light_gray_concrete
setblock 89 171 499 minecraft:gray_concrete
fill 89 171 500 89 171 504 minecraft:light_gray_concrete
setblock 89 171 505 minecraft:gray_concrete
fill 47 172 463 47 236 463 minecraft:light_gray_concrete
fill 47 172 468 47 174 468 minecraft:sea_lantern
fill 47 172 469 47 234 470 minecraft:light_gray_concrete
fill 47 172 472 47 234 475 minecraft:light_gray_concrete
fill 47 172 476 47 174 476 minecraft:sea_lantern
fill 47 172 477 47 235 483 minecraft:light_gray_concrete
fill 47 172 484 47 174 484 minecraft:sea_lantern
fill 47 172 485 47 234 491 minecraft:light_gray_concrete
fill 47 172 492 47 174 492 minecraft:sea_lantern
fill 47 172 493 47 235 499 minecraft:light_gray_concrete
fill 47 172 500 47 174 500 minecraft:sea_lantern
fill 47 172 505 49 236 505 minecraft:light_gray_concrete
fill 50 172 505 50 174 505 minecraft:sea_lantern
fill 51 172 463 53 235 463 minecraft:light_gray_concrete
fill 51 172 505 54 235 505 minecraft:light_gray_concrete
fill 54 172 463 54 174 463 minecraft:sea_lantern
fill 55 172 463 61 234 463 minecraft:light_gray_concrete
fill 58 172 505 58 174 505 minecraft:sea_lantern
fill 59 172 505 59 238 505 minecraft:light_gray_concrete
fill 62 172 463 62 174 463 minecraft:sea_lantern
fill 62 172 505 65 236 505 minecraft:light_gray_concrete
fill 63 172 463 69 235 463 minecraft:light_gray_concrete
fill 66 172 505 66 174 505 minecraft:sea_lantern
fill 70 172 463 70 174 463 minecraft:sea_lantern
fill 71 172 463 71 238 463 minecraft:light_gray_concrete
fill 73 172 463 73 235 463 minecraft:light_gray_concrete
fill 74 172 505 74 174 505 minecraft:sea_lantern
fill 75 172 463 75 234 463 minecraft:light_gray_concrete
fill 75 172 469 83 172 469 minecraft:black_concrete
fill 75 172 505 75 238 505 minecraft:light_gray_concrete
fill 77 172 463 77 238 463 minecraft:light_gray_concrete
fill 78 172 463 78 174 463 minecraft:sea_lantern
fill 78 172 505 79 234 505 minecraft:light_gray_concrete
fill 79 172 463 82 235 463 minecraft:light_gray_concrete
fill 81 172 505 81 238 505 minecraft:light_gray_concrete
fill 82 172 505 82 174 505 minecraft:sea_lantern
fill 83 172 470 83 173 470 minecraft:black_concrete
fill 84 172 470 85 172 477 minecraft:quartz_block
fill 84 172 505 84 238 505 minecraft:light_gray_concrete
setblock 85 172 469 minecraft:quartz_block
fill 86 172 463 86 174 463 minecraft:sea_lantern
fill 86 172 468 88 172 468 minecraft:quartz_block
fill 86 172 472 86 172 477 minecraft:quartz_block
fill 87 172 467 88 172 467 minecraft:quartz_block
fill 87 172 471 87 172 476 minecraft:quartz_block
fill 88 172 471 88 172 472 minecraft:quartz_block
fill 88 172 475 88 173 476 minecraft:quartz_block
fill 89 172 464 89 238 467 minecraft:light_gray_concrete
fill 89 172 468 89 174 468 minecraft:sea_lantern
fill 89 172 471 89 238 471 minecraft:light_gray_concrete
fill 89 172 475 89 238 475 minecraft:light_gray_concrete
fill 89 172 476 89 174 476 minecraft:sea_lantern
fill 89 172 477 89 234 483 minecraft:light_gray_concrete
fill 89 172 484 89 174 484 minecraft:sea_lantern
fill 89 172 490 89 235 491 minecraft:light_gray_concrete
fill 89 172 492 89 174 492 minecraft:sea_lantern
fill 89 172 493 89 238 496 minecraft:light_gray_concrete
fill 89 172 499 89 238 499 minecraft:light_gray_concrete
fill 89 172 500 89 174 500 minecraft:sea_lantern
fill 89 172 501 89 235 505 minecraft:light_gray_concrete
fill 50 173 501 50 174 501 minecraft:black_concrete
fill 51 173 499 53 174 499 minecraft:black_concrete
fill 51 173 502 51 174 502 minecraft:black_concrete
fill 52 173 503 53 174 503 minecraft:black_concrete
fill 54 173 500 54 174 500 minecraft:black_concrete
fill 54 173 502 54 174 502 minecraft:black_concrete
fill 81 173 469 83 173 469 minecraft:black_concrete
fill 82 173 499 82 174 500 minecraft:black_concrete
fill 83 173 471 83 173 475 minecraft:black_concrete
fill 83 173 498 85 174 498 minecraft:black_concrete
fill 84 173 476 84 173 482 minecraft:quartz_block
fill 84 173 502 85 174 502 minecraft:black_concrete
fill 85 173 475 87 173 481 minecraft:quartz_block
fill 86 173 474 87 173 474 minecraft:quartz_block
fill 86 173 499 86 174 499 minecraft:black_concrete
fill 86 173 501 86 174 501 minecraft:black_concrete
fill 88 173 477 88 173 480 minecraft:quartz_block
fill 83 174 473 83 174 479 minecraft:black_concrete
fill 84 174 480 87 174 485 minecraft:quartz_block
fill 85 174 486 88 174 486 minecraft:quartz_block
fill 87 174 479 88 174 479 minecraft:quartz_block
setblock 88 174 480 minecraft:quartz_block
fill 88 174 483 88 174 485 minecraft:quartz_block
fill 47 175 468 47 185 468 minecraft:light_gray_concrete
fill 47 175 476 47 185 476 minecraft:light_gray_concrete
fill 47 175 484 47 185 484 minecraft:light_gray_concrete
fill 47 175 492 47 185 492 minecraft:light_gray_concrete
fill 47 175 500 47 185 500 minecraft:light_gray_concrete
setblock 50 175 466 minecraft:light[level=14]
setblock 50 175 474 minecraft:light[level=14]
setblock 50 175 482 minecraft:light[level=14]
setblock 50 175 490 minecraft:light[level=14]
setblock 50 175 498 minecraft:light[level=14]
fill 50 175 505 50 185 505 minecraft:light_gray_concrete
fill 54 175 463 54 185 463 minecraft:light_gray_concrete
setblock 58 175 466 minecraft:light[level=14]
setblock 58 175 474 minecraft:light[level=14]
setblock 58 175 482 minecraft:light[level=14]
setblock 58 175 490 minecraft:light[level=14]
setblock 58 175 498 minecraft:light[level=14]
fill 58 175 505 58 185 505 minecraft:light_gray_concrete
fill 62 175 463 62 185 463 minecraft:light_gray_concrete
setblock 66 175 466 minecraft:light[level=14]
setblock 66 175 474 minecraft:light[level=14]
setblock 66 175 482 minecraft:light[level=14]
setblock 66 175 490 minecraft:light[level=14]
setblock 66 175 498 minecraft:light[level=14]
fill 66 175 505 66 185 505 minecraft:light_gray_concrete
fill 70 175 463 70 185 463 minecraft:light_gray_concrete
setblock 74 175 466 minecraft:light[level=14]
setblock 74 175 474 minecraft:light[level=14]
setblock 74 175 482 minecraft:light[level=14]
setblock 74 175 490 minecraft:light[level=14]
setblock 74 175 498 minecraft:light[level=14]
fill 74 175 505 74 185 505 minecraft:light_gray_concrete
fill 78 175 463 78 185 463 minecraft:light_gray_concrete
setblock 82 175 466 minecraft:light[level=14]
setblock 82 175 474 minecraft:light[level=14]
setblock 82 175 482 minecraft:light[level=14]
setblock 82 175 490 minecraft:light[level=14]
setblock 82 175 498 minecraft:light[level=14]
fill 82 175 505 82 185 505 minecraft:light_gray_concrete
fill 86 175 463 86 185 463 minecraft:light_gray_concrete
fill 89 175 468 89 185 468 minecraft:light_gray_concrete
fill 89 175 476 89 185 476 minecraft:light_gray_concrete
fill 89 175 484 89 185 484 minecraft:light_gray_concrete
fill 89 175 492 89 185 492 minecraft:light_gray_concrete
fill 89 175 500 89 185 500 minecraft:light_gray_concrete
fill 48 180 464 48 181 465 minecraft:quartz_block
fill 48 180 466 48 180 468 minecraft:gray_concrete
fill 48 180 469 48 180 471 minecraft:quartz_block
fill 48 180 472 48 180 474 minecraft:gray_concrete
fill 48 180 475 48 180 477 minecraft:quartz_block
fill 48 180 478 48 180 480 minecraft:gray_concrete
fill 48 180 481 48 180 483 minecraft:quartz_block
fill 48 180 484 48 180 486 minecraft:gray_concrete
fill 48 180 487 48 180 489 minecraft:quartz_block
fill 48 180 490 48 180 492 minecraft:gray_concrete
fill 48 180 493 48 180 495 minecraft:quartz_block
fill 48 180 496 48 180 498 minecraft:gray_concrete
fill 48 180 499 48 180 501 minecraft:quartz_block
fill 48 180 502 48 180 504 minecraft:gray_concrete
fill 49 180 464 51 180 465 minecraft:gray_concrete
fill 49 180 466 51 180 468 minecraft:quartz_block
fill 49 180 469 51 180 471 minecraft:gray_concrete
fill 49 180 472 51 180 474 minecraft:quartz_block
fill 49 180 475 51 180 477 minecraft:gray_concrete
fill 49 180 478 51 180 480 minecraft:quartz_block
fill 49 180 481 51 180 483 minecraft:gray_concrete
fill 49 180 484 51 180 486 minecraft:quartz_block
fill 49 180 487 51 180 489 minecraft:gray_concrete
fill 49 180 490 51 180 492 minecraft:quartz_block
fill 49 180 493 51 180 495 minecraft:gray_concrete
fill 49 180 496 51 180 498 minecraft:quartz_block
fill 49 180 499 51 180 501 minecraft:gray_concrete
fill 49 180 502 51 180 504 minecraft:quartz_block
fill 52 180 464 54 180 465 minecraft:quartz_block
fill 52 180 466 54 180 468 minecraft:gray_concrete
fill 52 180 469 54 180 471 minecraft:quartz_block
fill 52 180 472 54 180 474 minecraft:gray_concrete
fill 52 180 475 54 180 477 minecraft:quartz_block
fill 52 180 478 54 180 480 minecraft:gray_concrete
fill 52 180 481 54 180 483 minecraft:quartz_block
fill 52 180 484 54 180 486 minecraft:gray_concrete
fill 52 180 487 54 180 489 minecraft:quartz_block
fill 52 180 490 54 180 492 minecraft:gray_concrete
fill 52 180 493 54 180 495 minecraft:quartz_block
fill 52 180 496 54 180 498 minecraft:gray_concrete
fill 52 180 499 54 180 501 minecraft:quartz_block
fill 52 180 502 54 180 504 minecraft:gray_concrete
fill 55 180 464 57 180 465 minecraft:gray_concrete
fill 55 180 466 57 180 468 minecraft:quartz_block
fill 55 180 469 57 180 471 minecraft:gray_concrete
fill 55 180 472 57 180 474 minecraft:quartz_block
fill 55 180 475 57 180 477 minecraft:gray_concrete
fill 55 180 478 57 180 480 minecraft:quartz_block
fill 55 180 481 57 180 483 minecraft:gray_concrete
fill 55 180 484 57 180 486 minecraft:quartz_block
fill 55 180 487 57 180 489 minecraft:gray_concrete
fill 55 180 490 57 180 492 minecraft:quartz_block
fill 55 180 493 57 180 495 minecraft:gray_concrete
fill 55 180 496 57 180 498 minecraft:quartz_block
fill 55 180 499 57 180 501 minecraft:gray_concrete
fill 55 180 502 57 180 504 minecraft:quartz_block
fill 58 180 464 60 180 465 minecraft:quartz_block
fill 58 180 466 60 180 468 minecraft:gray_concrete
fill 58 180 469 60 180 471 minecraft:quartz_block
fill 58 180 472 60 180 474 minecraft:gray_concrete
fill 58 180 475 60 180 477 minecraft:quartz_block
fill 58 180 478 60 180 480 minecraft:gray_concrete
fill 58 180 481 60 180 483 minecraft:quartz_block
fill 58 180 484 60 180 486 minecraft:gray_concrete
fill 58 180 487 60 180 489 minecraft:quartz_block
fill 58 180 490 60 180 492 minecraft:gray_concrete
fill 58 180 493 60 180 495 minecraft:quartz_block
fill 58 180 496 60 180 498 minecraft:gray_concrete
fill 58 180 499 60 180 501 minecraft:quartz_block
fill 58 180 502 60 180 504 minecraft:gray_concrete
fill 61 180 464 63 180 465 minecraft:gray_concrete
fill 61 180 466 63 180 468 minecraft:quartz_block
fill 61 180 469 63 180 471 minecraft:gray_concrete
fill 61 180 472 63 180 474 minecraft:quartz_block
fill 61 180 475 63 180 477 minecraft:gray_concrete
fill 61 180 478 63 180 480 minecraft:quartz_block
fill 61 180 481 63 180 483 minecraft:gray_concrete
fill 61 180 484 63 180 486 minecraft:quartz_block
fill 61 180 487 63 180 489 minecraft:gray_concrete
fill 61 180 490 63 180 492 minecraft:quartz_block
fill 61 180 493 63 180 495 minecraft:gray_concrete
fill 61 180 496 63 180 498 minecraft:quartz_block
fill 61 180 499 63 180 501 minecraft:gray_concrete
fill 61 180 502 63 180 504 minecraft:quartz_block
fill 64 180 464 66 180 465 minecraft:quartz_block
fill 64 180 466 66 180 468 minecraft:gray_concrete
fill 64 180 469 66 180 471 minecraft:quartz_block
fill 64 180 472 66 180 474 minecraft:gray_concrete
fill 64 180 475 66 180 477 minecraft:quartz_block
fill 64 180 478 66 180 480 minecraft:gray_concrete
fill 64 180 481 66 180 483 minecraft:quartz_block
fill 64 180 484 66 180 486 minecraft:gray_concrete
fill 64 180 487 66 180 489 minecraft:quartz_block
fill 64 180 490 66 180 492 minecraft:gray_concrete
fill 64 180 493 66 180 495 minecraft:quartz_block
fill 64 180 496 66 180 498 minecraft:gray_concrete
fill 64 180 499 66 180 501 minecraft:quartz_block
fill 64 180 502 66 180 504 minecraft:gray_concrete
fill 67 180 464 69 180 465 minecraft:gray_concrete
fill 67 180 466 69 180 468 minecraft:quartz_block
fill 67 180 469 69 180 471 minecraft:gray_concrete
fill 67 180 472 69 180 474 minecraft:quartz_block
fill 67 180 475 69 180 477 minecraft:gray_concrete
fill 67 180 478 68 180 480 minecraft:quartz_block
fill 67 180 481 67 180 483 minecraft:gray_concrete
fill 67 180 484 69 180 486 minecraft:quartz_block
fill 67 180 487 69 180 489 minecraft:gray_concrete
fill 67 180 490 69 180 492 minecraft:quartz_block
fill 67 180 493 69 180 495 minecraft:gray_concrete
fill 67 180 496 69 180 498 minecraft:quartz_block
fill 67 180 499 69 180 501 minecraft:gray_concrete
fill 67 180 502 69 180 504 minecraft:quartz_block
fill 68 180 482 68 180 483 minecraft:gray_concrete
fill 69 180 478 69 180 479 minecraft:quartz_block
setblock 69 180 483 minecraft:gray_concrete
fill 70 180 464 72 180 465 minecraft:quartz_block
fill 70 180 466 72 180 468 minecraft:gray_concrete
fill 70 180 469 72 180 471 minecraft:quartz_block
fill 70 180 472 72 180 474 minecraft:gray_concrete
fill 70 180 475 72 180 477 minecraft:quartz_block
fill 70 180 478 72 180 478 minecraft:gray_concrete
fill 70 180 484 72 180 486 minecraft:gray_concrete
fill 70 180 487 72 180 489 minecraft:quartz_block
fill 70 180 490 72 180 492 minecraft:gray_concrete
fill 70 180 493 72 180 495 minecraft:quartz_block
fill 70 180 496 72 180 498 minecraft:gray_concrete
fill 70 180 499 72 180 501 minecraft:quartz_block
fill 70 180 502 72 180 504 minecraft:gray_concrete
fill 71 180 479 72 180 479 minecraft:gray_concrete
fill 71 180 483 72 180 483 minecraft:quartz_block
setblock 72 180 480 minecraft:gray_concrete
setblock 72 180 482 minecraft:quartz_block
fill 73 180 464 75 180 465 minecraft:gray_concrete
fill 73 180 466 75 180 468 minecraft:quartz_block
fill 73 180 469 75 180 471 minecraft:gray_concrete
fill 73 180 472 75 180 474 minecraft:quartz_block
fill 73 180 475 75 180 477 minecraft:gray_concrete
fill 73 180 478 75 180 480 minecraft:quartz_block
fill 73 180 481 75 180 483 minecraft:gray_concrete
fill 73 180 484 75 180 486 minecraft:quartz_block
fill 73 180 487 75 180 489 minecraft:gray_concrete
fill 73 180 490 75 180 492 minecraft:quartz_block
fill 73 180 493 75 180 495 minecraft:gray_concrete
fill 73 180 496 75 180 498 minecraft:quartz_block
fill 73 180 499 75 180 501 minecraft:gray_concrete
fill 73 180 502 75 180 504 minecraft:quartz_block
fill 76 180 464 78 180 465 minecraft:quartz_block
fill 76 180 466 78 180 468 minecraft:gray_concrete
fill 76 180 469 78 180 471 minecraft:quartz_block
fill 76 180 472 78 180 474 minecraft:gray_concrete
fill 76 180 475 78 180 477 minecraft:quartz_block
fill 76 180 478 78 180 480 minecraft:gray_concrete
fill 76 180 481 78 180 483 minecraft:quartz_block
fill 76 180 484 78 180 486 minecraft:gray_concrete
fill 76 180 487 78 180 489 minecraft:quartz_block
fill 76 180 490 78 180 492 minecraft:gray_concrete
fill 76 180 493 78 180 495 minecraft:quartz_block
fill 76 180 496 78 180 498 minecraft:gray_concrete
fill 76 180 499 78 180 501 minecraft:quartz_block
fill 76 180 502 78 180 504 minecraft:gray_concrete
fill 79 180 464 81 180 465 minecraft:gray_concrete
fill 79 180 466 81 180 468 minecraft:quartz_block
fill 79 180 469 81 180 471 minecraft:gray_concrete
fill 79 180 472 81 180 474 minecraft:quartz_block
fill 79 180 475 81 180 477 minecraft:gray_concrete
fill 79 180 478 81 180 480 minecraft:quartz_block
fill 79 180 481 81 180 483 minecraft:gray_concrete
fill 79 180 484 81 180 486 minecraft:quartz_block
fill 79 180 487 81 180 489 minecraft:gray_concrete
fill 79 180 490 81 180 492 minecraft:quartz_block
fill 79 180 493 81 180 495 minecraft:gray_concrete
fill 79 180 496 81 180 498 minecraft:quartz_block
fill 79 180 499 81 180 501 minecraft:gray_concrete
fill 79 180 502 81 180 504 minecraft:quartz_block
fill 82 180 464 84 180 465 minecraft:quartz_block
fill 82 180 466 84 180 468 minecraft:gray_concrete
fill 82 180 469 84 180 471 minecraft:quartz_block
fill 82 180 472 84 180 474 minecraft:gray_concrete
fill 82 180 475 84 180 477 minecraft:quartz_block
fill 82 180 478 84 180 480 minecraft:gray_concrete
fill 82 180 481 84 180 483 minecraft:quartz_block
fill 82 180 484 84 180 486 minecraft:gray_concrete
fill 82 180 487 84 180 489 minecraft:quartz_block
fill 82 180 490 84 180 492 minecraft:gray_concrete
fill 82 180 493 84 180 495 minecraft:quartz_block
fill 82 180 496 84 180 498 minecraft:gray_concrete
fill 82 180 499 84 180 501 minecraft:quartz_block
fill 82 180 502 84 180 504 minecraft:gray_concrete
fill 85 180 464 87 180 465 minecraft:gray_concrete
fill 85 180 466 87 180 468 minecraft:quartz_block
fill 85 180 469 87 180 471 minecraft:gray_concrete
fill 85 180 472 87 180 474 minecraft:quartz_block
fill 85 180 475 87 180 477 minecraft:gray_concrete
fill 85 180 478 87 180 480 minecraft:quartz_block
fill 85 180 481 87 180 483 minecraft:gray_concrete
fill 85 180 484 87 180 486 minecraft:quartz_block
fill 85 180 487 87 180 489 minecraft:gray_concrete
fill 85 180 490 87 180 492 minecraft:quartz_block
fill 85 180 493 87 180 495 minecraft:gray_concrete
fill 85 180 496 87 180 498 minecraft:quartz_block
fill 85 180 499 87 180 501 minecraft:gray_concrete
fill 85 180 502 87 180 504 minecraft:quartz_block
fill 88 180 464 88 180 465 minecraft:quartz_block
fill 88 180 466 88 180 468 minecraft:gray_concrete
fill 88 180 469 88 180 471 minecraft:quartz_block
fill 88 180 472 88 180 474 minecraft:gray_concrete
fill 88 180 475 88 180 477 minecraft:quartz_block
fill 88 180 478 88 180 480 minecraft:gray_concrete
fill 88 180 481 88 180 483 minecraft:quartz_block
fill 88 180 484 88 180 486 minecraft:gray_concrete
fill 88 180 487 88 180 489 minecraft:quartz_block
fill 88 180 490 88 180 492 minecraft:gray_concrete
fill 88 180 493 88 180 495 minecraft:quartz_block
fill 88 180 496 88 180 498 minecraft:gray_concrete
fill 88 180 499 88 180 501 minecraft:quartz_block
fill 88 180 502 88 180 504 minecraft:gray_concrete
fill 48 181 466 88 181 466 minecraft:black_concrete
fill 48 181 467 48 181 468 minecraft:gray_concrete
fill 48 181 469 88 181 469 minecraft:black_concrete
fill 48 181 470 48 181 471 minecraft:quartz_block
fill 48 181 472 88 181 472 minecraft:black_concrete
fill 48 181 473 48 181 474 minecraft:gray_concrete
fill 48 181 475 88 181 475 minecraft:black_concrete
fill 48 181 476 48 181 477 minecraft:quartz_block
fill 48 181 478 68 181 478 minecraft:black_concrete
fill 48 181 479 48 181 480 minecraft:gray_concrete
fill 48 181 481 66 181 481 minecraft:black_concrete
fill 48 181 482 48 181 483 minecraft:quartz_block
fill 48 181 484 68 181 484 minecraft:black_concrete
fill 48 181 485 48 181 486 minecraft:gray_concrete
fill 48 181 487 88 181 487 minecraft:black_concrete
fill 48 181 488 48 181 489 minecraft:quartz_block
fill 48 181 490 88 181 490 minecraft:black_concrete
fill 48 181 491 48 181 492 minecraft:gray_concrete
fill 48 181 493 88 181 493 minecraft:black_concrete
fill 48 181 494 48 181 495 minecraft:quartz_block
fill 48 181 496 88 181 496 minecraft:black_concrete
fill 48 181 497 48 181 498 minecraft:gray_concrete
fill 48 181 499 88 181 499 minecraft:black_concrete
fill 48 181 500 48 181 501 minecraft:quartz_block
fill 48 181 502 88 181 502 minecraft:black_concrete
fill 48 181 503 48 181 504 minecraft:gray_concrete
fill 49 181 464 49 181 465 minecraft:black_concrete
fill 49 181 467 49 181 468 minecraft:black_concrete
fill 49 181 470 49 181 471 minecraft:black_concrete
fill 49 181 473 49 181 474 minecraft:black_concrete
fill 49 181 476 49 181 477 minecraft:black_concrete
fill 49 181 479 49 181 480 minecraft:black_concrete
fill 49 181 482 49 181 483 minecraft:black_concrete
fill 49 181 485 49 181 486 minecraft:black_concrete
fill 49 181 488 49 181 489 minecraft:black_concrete
fill 49 181 491 49 181 492 minecraft:black_concrete
fill 49 181 494 49 181 495 minecraft:black_concrete
fill 49 181 497 49 181 498 minecraft:black_concrete
fill 49 181 500 49 181 501 minecraft:black_concrete
fill 49 181 503 49 181 504 minecraft:black_concrete
fill 50 181 464 51 181 465 minecraft:gray_concrete
fill 50 181 467 51 181 468 minecraft:quartz_block
fill 50 181 470 51 181 471 minecraft:gray_concrete
fill 50 181 473 51 181 474 minecraft:quartz_block
fill 50 181 476 51 181 477 minecraft:gray_concrete
fill 50 181 479 51 181 480 minecraft:quartz_block
fill 50 181 482 51 181 483 minecraft:gray_concrete
fill 50 181 485 51 181 486 minecraft:quartz_block
fill 50 181 488 51 181 489 minecraft:gray_concrete
fill 50 181 491 51 181 492 minecraft:quartz_block
fill 50 181 494 51 181 495 minecraft:gray_concrete
fill 50 181 497 51 181 498 minecraft:quartz_block
fill 50 181 500 51 181 501 minecraft:gray_concrete
fill 50 181 503 51 181 504 minecraft:quartz_block
fill 52 181 464 52 181 465 minecraft:black_concrete
fill 52 181 467 52 181 468 minecraft:black_concrete
fill 52 181 470 52 181 471 minecraft:black_concrete
fill 52 181 473 52 181 474 minecraft:black_concrete
fill 52 181 476 52 181 477 minecraft:black_concrete
fill 52 181 479 52 181 480 minecraft:black_concrete
fill 52 181 482 52 181 483 minecraft:black_concrete
fill 52 181 485 52 181 486 minecraft:black_concrete
fill 52 181 488 52 181 489 minecraft:black_concrete
fill 52 181 491 52 181 492 minecraft:black_concrete
fill 52 181 494 52 181 495 minecraft:black_concrete
fill 52 181 497 52 181 498 minecraft:black_concrete
fill 52 181 500 52 181 501 minecraft:black_concrete
fill 52 181 503 52 181 504 minecraft:black_concrete
fill 53 181 464 54 181 465 minecraft:quartz_block
fill 53 181 467 54 181 468 minecraft:gray_concrete
fill 53 181 470 54 181 471 minecraft:quartz_block
fill 53 181 473 54 181 474 minecraft:gray_concrete
fill 53 181 476 54 181 477 minecraft:quartz_block
fill 53 181 479 54 181 480 minecraft:gray_concrete
fill 53 181 482 54 181 483 minecraft:quartz_block
fill 53 181 485 54 181 486 minecraft:gray_concrete
fill 53 181 488 54 181 489 minecraft:quartz_block
fill 53 181 491 54 181 492 minecraft:gray_concrete
fill 53 181 494 54 181 495 minecraft:quartz_block
fill 53 181 497 54 181 498 minecraft:gray_concrete
fill 53 181 500 54 181 501 minecraft:quartz_block
fill 53 181 503 54 181 504 minecraft:gray_concrete
fill 55 181 464 55 181 465 minecraft:black_concrete
fill 55 181 467 55 181 468 minecraft:black_concrete
fill 55 181 470 55 181 471 minecraft:black_concrete
fill 55 181 473 55 181 474 minecraft:black_concrete
fill 55 181 476 55 181 477 minecraft:black_concrete
fill 55 181 479 55 181 480 minecraft:black_concrete
fill 55 181 482 55 181 483 minecraft:black_concrete
fill 55 181 485 55 181 486 minecraft:black_concrete
fill 55 181 488 55 181 489 minecraft:black_concrete
fill 55 181 491 55 181 492 minecraft:black_concrete
fill 55 181 494 55 181 495 minecraft:black_concrete
fill 55 181 497 55 181 498 minecraft:black_concrete
fill 55 181 500 55 181 501 minecraft:black_concrete
fill 55 181 503 55 181 504 minecraft:black_concrete
fill 56 181 464 57 181 465 minecraft:gray_concrete
fill 56 181 467 57 181 468 minecraft:quartz_block
fill 56 181 470 57 181 471 minecraft:gray_concrete
fill 56 181 473 57 181 474 minecraft:quartz_block
fill 56 181 476 57 181 477 minecraft:gray_concrete
fill 56 181 479 57 181 480 minecraft:quartz_block
fill 56 181 482 57 181 483 minecraft:gray_concrete
fill 56 181 485 57 181 486 minecraft:quartz_block
fill 56 181 488 57 181 489 minecraft:gray_concrete
fill 56 181 491 57 181 492 minecraft:quartz_block
fill 56 181 494 57 181 495 minecraft:gray_concrete
fill 56 181 497 57 181 498 minecraft:quartz_block
fill 56 181 500 57 181 501 minecraft:gray_concrete
fill 56 181 503 57 181 504 minecraft:quartz_block
fill 58 181 464 58 181 465 minecraft:black_concrete
fill 58 181 467 58 181 468 minecraft:black_concrete
fill 58 181 470 58 181 471 minecraft:black_concrete
fill 58 181 473 58 181 474 minecraft:black_concrete
fill 58 181 476 58 181 477 minecraft:black_concrete
fill 58 181 479 58 181 480 minecraft:black_concrete
fill 58 181 482 58 181 483 minecraft:black_concrete
fill 58 181 485 58 181 486 minecraft:black_concrete
fill 58 181 488 58 181 489 minecraft:black_concrete
fill 58 181 491 58 181 492 minecraft:black_concrete
fill 58 181 494 58 181 495 minecraft:black_concrete
fill 58 181 497 58 181 498 minecraft:black_concrete
fill 58 181 500 58 181 501 minecraft:black_concrete
fill 58 181 503 58 181 504 minecraft:black_concrete
fill 59 181 464 60 181 465 minecraft:quartz_block
fill 59 181 467 60 181 468 minecraft:gray_concrete
fill 59 181 470 60 181 471 minecraft:quartz_block
fill 59 181 473 60 181 474 minecraft:gray_concrete
fill 59 181 476 60 181 477 minecraft:quartz_block
fill 59 181 479 60 181 480 minecraft:gray_concrete
fill 59 181 482 60 181 483 minecraft:quartz_block
fill 59 181 485 60 181 486 minecraft:gray_concrete
fill 59 181 488 60 181 489 minecraft:quartz_block
fill 59 181 491 60 181 492 minecraft:gray_concrete
fill 59 181 494 60 181 495 minecraft:quartz_block
fill 59 181 497 60 181 498 minecraft:gray_concrete
fill 59 181 500 60 181 501 minecraft:quartz_block
fill 59 181 503 60 181 504 minecraft:gray_concrete
fill 61 181 464 61 181 465 minecraft:black_concrete
fill 61 181 467 61 181 468 minecraft:black_concrete
fill 61 181 470 61 181 471 minecraft:black_concrete
fill 61 181 473 61 181 474 minecraft:black_concrete
fill 61 181 476 61 181 477 minecraft:black_concrete
fill 61 181 479 61 181 480 minecraft:black_concrete
fill 61 181 482 61 181 483 minecraft:black_concrete
fill 61 181 485 61 181 486 minecraft:black_concrete
fill 61 181 488 61 181 489 minecraft:black_concrete
fill 61 181 491 61 181 492 minecraft:black_concrete
fill 61 181 494 61 181 495 minecraft:black_concrete
fill 61 181 497 61 181 498 minecraft:black_concrete
fill 61 181 500 61 181 501 minecraft:black_concrete
fill 61 181 503 61 181 504 minecraft:black_concrete
fill 62 181 464 63 181 465 minecraft:gray_concrete
fill 62 181 467 63 181 468 minecraft:quartz_block
fill 62 181 470 63 181 471 minecraft:gray_concrete
fill 62 181 473 63 181 474 minecraft:quartz_block
fill 62 181 476 63 181 477 minecraft:gray_concrete
fill 62 181 479 63 181 480 minecraft:quartz_block
fill 62 181 482 63 181 483 minecraft:gray_concrete
fill 62 181 485 63 181 486 minecraft:quartz_block
fill 62 181 488 63 181 489 minecraft:gray_concrete
fill 62 181 491 63 181 492 minecraft:quartz_block
fill 62 181 494 63 181 495 minecraft:gray_concrete
fill 62 181 497 63 181 498 minecraft:quartz_block
fill 62 181 500 63 181 501 minecraft:gray_concrete
fill 62 181 503 63 181 504 minecraft:quartz_block
fill 64 181 464 64 181 465 minecraft:black_concrete
fill 64 181 467 64 181 468 minecraft:black_concrete
fill 64 181 470 64 181 471 minecraft:black_concrete
fill 64 181 473 64 181 474 minecraft:black_concrete
fill 64 181 476 64 181 477 minecraft:black_concrete
fill 64 181 479 64 181 480 minecraft:black_concrete
fill 64 181 482 64 181 483 minecraft:black_concrete
fill 64 181 485 64 181 486 minecraft:black_concrete
fill 64 181 488 64 181 489 minecraft:black_concrete
fill 64 181 491 64 181 492 minecraft:black_concrete
fill 64 181 494 64 181 495 minecraft:black_concrete
fill 64 181 497 64 181 498 minecraft:black_concrete
fill 64 181 500 64 181 501 minecraft:black_concrete
fill 64 181 503 64 181 504 minecraft:black_concrete
fill 65 181 464 66 181 465 minecraft:quartz_block
fill 65 181 467 66 181 468 minecraft:gray_concrete
fill 65 181 470 66 181 471 minecraft:quartz_block
fill 65 181 473 66 181 474 minecraft:gray_concrete
fill 65 181 476 66 181 477 minecraft:quartz_block
fill 65 181 479 66 181 480 minecraft:gray_concrete
fill 65 181 482 66 181 483 minecraft:quartz_block
fill 65 181 485 66 181 486 minecraft:gray_concrete
fill 65 181 488 66 181 489 minecraft:quartz_block
fill 65 181 491 66 181 492 minecraft:gray_concrete
fill 65 181 494 66 181 495 minecraft:quartz_block
fill 65 181 497 66 181 498 minecraft:gray_concrete
fill 65 181 500 66 181 501 minecraft:quartz_block
fill 65 181 503 66 181 504 minecraft:gray_concrete
fill 67 181 464 67 181 465 minecraft:black_concrete
fill 67 181 467 67 181 468 minecraft:black_concrete
fill 67 181 470 67 181 471 minecraft:black_concrete
fill 67 181 473 67 181 474 minecraft:black_concrete
fill 67 181 476 67 181 477 minecraft:black_concrete
setblock 67 181 479 minecraft:black_concrete
fill 67 181 480 67 181 482 minecraft:sea_lantern
setblock 67 181 483 minecraft:black_concrete
fill 67 181 485 67 181 486 minecraft:black_concrete
fill 67 181 488 67 181 489 minecraft:black_concrete
fill 67 181 491 67 181 492 minecraft:black_concrete
fill 67 181 494 67 181 495 minecraft:black_concrete
fill 67 181 497 67 181 498 minecraft:black_concrete
fill 67 181 500 67 181 501 minecraft:black_concrete
fill 67 181 503 67 181 504 minecraft:black_concrete
fill 68 181 464 69 181 465 minecraft:gray_concrete
fill 68 181 467 69 181 468 minecraft:quartz_block
fill 68 181 470 69 181 471 minecraft:gray_concrete
fill 68 181 473 69 181 474 minecraft:quartz_block
fill 68 181 476 69 181 477 minecraft:gray_concrete
fill 68 181 479 68 181 480 minecraft:shroomlight
fill 68 181 482 68 181 483 minecraft:shroomlight
fill 68 181 485 69 181 486 minecraft:quartz_block
fill 68 181 488 69 181 489 minecraft:gray_concrete
fill 68 181 491 69 181 492 minecraft:quartz_block
fill 68 181 494 69 181 495 minecraft:gray_concrete
fill 68 181 497 69 181 498 minecraft:quartz_block
fill 68 181 500 69 181 501 minecraft:gray_concrete
fill 68 181 503 69 181 504 minecraft:quartz_block
fill 69 181 478 71 181 478 minecraft:sea_lantern
setblock 69 181 479 minecraft:shroomlight
setblock 69 181 483 minecraft:shroomlight
fill 69 181 484 71 181 484 minecraft:sea_lantern
fill 70 181 464 70 181 465 minecraft:black_concrete
fill 70 181 467 70 181 468 minecraft:black_concrete
fill 70 181 470 70 181 471 minecraft:black_concrete
fill 70 181 473 70 181 474 minecraft:black_concrete
fill 70 181 476 70 181 477 minecraft:black_concrete
fill 70 181 485 70 181 486 minecraft:black_concrete
fill 70 181 488 70 181 489 minecraft:black_concrete
fill 70 181 491 70 181 492 minecraft:black_concrete
fill 70 181 494 70 181 495 minecraft:black_concrete
fill 70 181 497 70 181 498 minecraft:black_concrete
fill 70 181 500 70 181 501 minecraft:black_concrete
fill 70 181 503 70 181 504 minecraft:black_concrete
fill 71 181 464 72 181 465 minecraft:quartz_block
fill 71 181 467 72 181 468 minecraft:gray_concrete
fill 71 181 470 72 181 471 minecraft:quartz_block
fill 71 181 473 72 181 474 minecraft:gray_concrete
fill 71 181 476 72 181 477 minecraft:quartz_block
fill 71 181 479 72 181 479 minecraft:shroomlight
fill 71 181 483 72 181 483 minecraft:shroomlight
fill 71 181 485 72 181 486 minecraft:gray_concrete
fill 71 181 488 72 181 489 minecraft:quartz_block
fill 71 181 491 72 181 492 minecraft:gray_concrete
fill 71 181 494 72 181 495 minecraft:quartz_block
fill 71 181 497 72 181 498 minecraft:gray_concrete
fill 71 181 500 72 181 501 minecraft:quartz_block
fill 71 181 503 72 181 504 minecraft:gray_concrete
fill 72 181 478 88 181 478 minecraft:black_concrete
setblock 72 181 480 minecraft:shroomlight
setblock 72 181 482 minecraft:shroomlight
fill 72 181 484 88 181 484 minecraft:black_concrete
fill 73 181 464 73 181 465 minecraft:black_concrete
fill 73 181 467 73 181 468 minecraft:black_concrete
fill 73 181 470 73 181 471 minecraft:black_concrete
fill 73 181 473 73 181 474 minecraft:black_concrete
fill 73 181 476 73 181 477 minecraft:black_concrete
setblock 73 181 479 minecraft:black_concrete
fill 73 181 480 73 181 482 minecraft:sea_lantern
setblock 73 181 483 minecraft:black_concrete
fill 73 181 485 73 181 486 minecraft:black_concrete
fill 73 181 488 73 181 489 minecraft:black_concrete
fill 73 181 491 73 181 492 minecraft:black_concrete
fill 73 181 494 73 181 495 minecraft:black_concrete
fill 73 181 497 73 181 498 minecraft:black_concrete
fill 73 181 500 73 181 501 minecraft:black_concrete
fill 73 181 503 73 181 504 minecraft:black_concrete
fill 74 181 464 75 181 465 minecraft:gray_concrete
fill 74 181 467 75 181 468 minecraft:quartz_block
fill 74 181 470 75 181 471 minecraft:gray_concrete
fill 74 181 473 75 181 474 minecraft:quartz_block
fill 74 181 476 75 181 477 minecraft:gray_concrete
fill 74 181 479 75 181 480 minecraft:quartz_block
fill 74 181 481 88 181 481 minecraft:black_concrete
fill 74 181 482 75 181 483 minecraft:gray_concrete
fill 74 181 485 75 181 486 minecraft:quartz_block
fill 74 181 488 75 181 489 minecraft:gray_concrete
fill 74 181 491 75 181 492 minecraft:quartz_block
fill 74 181 494 75 181 495 minecraft:gray_concrete
fill 74 181 497 75 181 498 minecraft:quartz_block
fill 74 181 500 75 181 501 minecraft:gray_concrete
fill 74 181 503 75 181 504 minecraft:quartz_block
fill 76 181 464 76 181 465 minecraft:black_concrete
fill 76 181 467 76 181 468 minecraft:black_concrete
fill 76 181 470 76 181 471 minecraft:black_concrete
fill 76 181 473 76 181 474 minecraft:black_concrete
fill 76 181 476 76 181 477 minecraft:black_concrete
fill 76 181 479 76 181 480 minecraft:black_concrete
fill 76 181 482 76 181 483 minecraft:black_concrete
fill 76 181 485 76 181 486 minecraft:black_concrete
fill 76 181 488 76 181 489 minecraft:black_concrete
fill 76 181 491 76 181 492 minecraft:black_concrete
fill 76 181 494 76 181 495 minecraft:black_concrete
fill 76 181 497 76 181 498 minecraft:black_concrete
fill 76 181 500 76 181 501 minecraft:black_concrete
fill 76 181 503 76 181 504 minecraft:black_concrete
fill 77 181 464 78 181 465 minecraft:quartz_block
fill 77 181 467 78 181 468 minecraft:gray_concrete
fill 77 181 470 78 181 471 minecraft:quartz_block
fill 77 181 473 78 181 474 minecraft:gray_concrete
fill 77 181 476 78 181 477 minecraft:quartz_block
fill 77 181 479 78 181 480 minecraft:gray_concrete
fill 77 181 482 78 181 483 minecraft:quartz_block
fill 77 181 485 78 181 486 minecraft:gray_concrete
fill 77 181 488 78 181 489 minecraft:quartz_block
fill 77 181 491 78 181 492 minecraft:gray_concrete
fill 77 181 494 78 181 495 minecraft:quartz_block
fill 77 181 497 78 181 498 minecraft:gray_concrete
fill 77 181 500 78 181 501 minecraft:quartz_block
fill 77 181 503 78 181 504 minecraft:gray_concrete
fill 79 181 464 79 181 465 minecraft:black_concrete
fill 79 181 467 79 181 468 minecraft:black_concrete
fill 79 181 470 79 181 471 minecraft:black_concrete
fill 79 181 473 79 181 474 minecraft:black_concrete
fill 79 181 476 79 181 477 minecraft:black_concrete
fill 79 181 479 79 181 480 minecraft:black_concrete
fill 79 181 482 79 181 483 minecraft:black_concrete
fill 79 181 485 79 181 486 minecraft:black_concrete
fill 79 181 488 79 181 489 minecraft:black_concrete
fill 79 181 491 79 181 492 minecraft:black_concrete
fill 79 181 494 79 181 495 minecraft:black_concrete
fill 79 181 497 79 181 498 minecraft:black_concrete
fill 79 181 500 79 181 501 minecraft:black_concrete
fill 79 181 503 79 181 504 minecraft:black_concrete
fill 80 181 464 81 181 465 minecraft:gray_concrete
fill 80 181 467 81 181 468 minecraft:quartz_block
fill 80 181 470 81 181 471 minecraft:gray_concrete
fill 80 181 473 81 181 474 minecraft:quartz_block
fill 80 181 476 81 181 477 minecraft:gray_concrete
fill 80 181 479 81 181 480 minecraft:quartz_block
fill 80 181 482 81 181 483 minecraft:gray_concrete
fill 80 181 485 81 181 486 minecraft:quartz_block
fill 80 181 488 81 181 489 minecraft:gray_concrete
fill 80 181 491 81 181 492 minecraft:quartz_block
fill 80 181 494 81 181 495 minecraft:gray_concrete
fill 80 181 497 81 181 498 minecraft:quartz_block
fill 80 181 500 81 181 501 minecraft:gray_concrete
fill 80 181 503 81 181 504 minecraft:quartz_block
fill 82 181 464 82 181 465 minecraft:black_concrete
fill 82 181 467 82 181 468 minecraft:black_concrete
fill 82 181 470 82 181 471 minecraft:black_concrete
fill 82 181 473 82 181 474 minecraft:black_concrete
fill 82 181 476 82 181 477 minecraft:black_concrete
fill 82 181 479 82 181 480 minecraft:black_concrete
fill 82 181 482 82 181 483 minecraft:black_concrete
fill 82 181 485 82 181 486 minecraft:black_concrete
fill 82 181 488 82 181 489 minecraft:black_concrete
fill 82 181 491 82 181 492 minecraft:black_concrete
fill 82 181 494 82 181 495 minecraft:black_concrete
fill 82 181 497 82 181 498 minecraft:black_concrete
fill 82 181 500 82 181 501 minecraft:black_concrete
fill 82 181 503 82 181 504 minecraft:black_concrete
fill 83 181 464 84 181 465 minecraft:quartz_block
fill 83 181 467 84 181 468 minecraft:gray_concrete
fill 83 181 470 84 181 471 minecraft:quartz_block
fill 83 181 473 84 181 474 minecraft:gray_concrete
fill 83 181 476 84 181 477 minecraft:quartz_block
fill 83 181 479 84 181 480 minecraft:gray_concrete
fill 83 181 482 84 181 483 minecraft:quartz_block
fill 83 181 485 84 181 486 minecraft:gray_concrete
fill 83 181 488 84 181 489 minecraft:quartz_block
fill 83 181 491 84 181 492 minecraft:gray_concrete
fill 83 181 494 84 181 495 minecraft:quartz_block
fill 83 181 497 84 181 498 minecraft:gray_concrete
fill 83 181 500 84 181 501 minecraft:quartz_block
fill 83 181 503 84 181 504 minecraft:gray_concrete
fill 85 181 464 85 181 465 minecraft:black_concrete
fill 85 181 467 85 181 468 minecraft:black_concrete
fill 85 181 470 85 181 471 minecraft:black_concrete
fill 85 181 473 85 181 474 minecraft:black_concrete
fill 85 181 476 85 181 477 minecraft:black_concrete
fill 85 181 479 85 181 480 minecraft:black_concrete
fill 85 181 482 85 181 483 minecraft:black_concrete
fill 85 181 485 85 181 486 minecraft:black_concrete
fill 85 181 488 85 181 489 minecraft:black_concrete
fill 85 181 491 85 181 492 minecraft:black_concrete
fill 85 181 494 85 181 495 minecraft:black_concrete
fill 85 181 497 85 181 498 minecraft:black_concrete
fill 85 181 500 85 181 501 minecraft:black_concrete
fill 85 181 503 85 181 504 minecraft:black_concrete
fill 86 181 464 87 181 465 minecraft:gray_concrete
fill 86 181 467 87 181 468 minecraft:quartz_block
fill 86 181 470 87 181 471 minecraft:gray_concrete
fill 86 181 473 87 181 474 minecraft:quartz_block
fill 86 181 476 87 181 477 minecraft:gray_concrete
fill 86 181 479 87 181 480 minecraft:quartz_block
fill 86 181 482 87 181 483 minecraft:gray_concrete
fill 86 181 485 87 181 486 minecraft:quartz_block
fill 86 181 488 87 181 489 minecraft:gray_concrete
fill 86 181 491 87 181 492 minecraft:quartz_block
fill 86 181 494 87 181 495 minecraft:gray_concrete
fill 86 181 497 87 181 498 minecraft:quartz_block
fill 86 181 500 87 181 501 minecraft:gray_concrete
fill 86 181 503 87 181 504 minecraft:quartz_block
fill 88 181 464 88 181 465 minecraft:black_concrete
fill 88 181 467 88 181 468 minecraft:black_concrete
fill 88 181 470 88 181 471 minecraft:black_concrete
fill 88 181 473 88 181 474 minecraft:black_concrete
fill 88 181 476 88 181 477 minecraft:black_concrete
fill 88 181 479 88 181 480 minecraft:black_concrete
fill 88 181 482 88 181 483 minecraft:black_concrete
fill 88 181 485 88 181 486 minecraft:black_concrete
fill 88 181 488 88 181 489 minecraft:black_concrete
fill 88 181 491 88 181 492 minecraft:black_concrete
fill 88 181 494 88 181 495 minecraft:black_concrete
fill 88 181 497 88 181 498 minecraft:black_concrete
fill 88 181 500 88 181 501 minecraft:black_concrete
fill 88 181 503 88 181 504 minecraft:black_concrete
fill 48 182 473 48 182 489 minecraft:basalt
setblock 49 182 471 minecraft:magma_block
fill 49 182 472 51 182 473 minecraft:basalt
setblock 49 182 474 minecraft:magma_block
fill 49 182 475 51 183 476 minecraft:basalt
setblock 49 182 477 minecraft:magma_block
fill 49 182 478 51 184 479 minecraft:basalt
setblock 49 182 480 minecraft:magma_block
fill 49 182 481 51 184 482 minecraft:basalt
setblock 49 182 483 minecraft:magma_block
fill 49 182 484 51 184 485 minecraft:basalt
setblock 49 182 486 minecraft:magma_block
fill 49 182 487 51 183 488 minecraft:basalt
setblock 49 182 489 minecraft:magma_block
fill 49 182 490 51 182 491 minecraft:basalt
fill 50 182 469 51 182 471 minecraft:basalt
fill 50 182 474 57 183 474 minecraft:basalt
fill 50 182 477 55 185 477 minecraft:basalt
fill 50 182 480 55 186 480 minecraft:basalt
fill 50 182 483 55 185 483 minecraft:basalt
fill 50 182 486 56 185 486 minecraft:basalt
fill 50 182 489 57 183 489 minecraft:basalt
fill 50 182 492 54 182 493 minecraft:basalt
fill 51 182 468 57 182 468 minecraft:basalt
setblock 51 182 494 minecraft:basalt
fill 52 182 466 54 182 466 minecraft:basalt
setblock 52 182 467 minecraft:magma_block
fill 52 182 469 54 184 469 minecraft:basalt
setblock 52 182 470 minecraft:magma_block
fill 52 182 471 54 184 472 minecraft:basalt
setblock 52 182 473 minecraft:magma_block
fill 52 182 475 54 187 475 minecraft:basalt
setblock 52 182 476 minecraft:magma_block
fill 52 182 478 54 188 478 minecraft:basalt
setblock 52 182 479 minecraft:magma_block
fill 52 182 481 54 188 481 minecraft:basalt
setblock 52 182 482 minecraft:magma_block
fill 52 182 484 54 188 484 minecraft:basalt
setblock 52 182 485 minecraft:magma_block
fill 52 182 487 54 187 487 minecraft:basalt
setblock 52 182 488 minecraft:magma_block
fill 52 182 490 54 184 490 minecraft:basalt
setblock 52 182 491 minecraft:magma_block
setblock 52 182 494 minecraft:magma_block
fill 52 182 495 54 182 496 minecraft:basalt
fill 53 182 465 57 182 465 minecraft:basalt
fill 53 182 467 60 183 467 minecraft:basalt
fill 53 182 470 60 185 470 minecraft:basalt
fill 53 182 473 57 187 473 minecraft:basalt
fill 53 182 476 56 188 476 minecraft:basalt
fill 53 182 479 55 189 479 minecraft:basalt
fill 53 182 482 55 189 482 minecraft:basalt
fill 53 182 485 55 188 485 minecraft:basalt
fill 53 182 488 57 182 488 minecraft:basalt
fill 53 182 491 59 186 491 minecraft:basalt
fill 53 182 494 60 183 494 minecraft:basalt
fill 53 182 497 60 182 497 minecraft:basalt
fill 54 182 464 60 182 464 minecraft:basalt
fill 54 182 498 57 182 498 minecraft:basalt
setblock 55 182 466 minecraft:magma_block
setblock 55 182 469 minecraft:magma_block
fill 55 182 471 57 188 471 minecraft:basalt
setblock 55 182 472 minecraft:magma_block
setblock 55 182 475 minecraft:magma_block
setblock 55 182 478 minecraft:magma_block
setblock 55 182 481 minecraft:magma_block
setblock 55 182 484 minecraft:magma_block
setblock 55 182 487 minecraft:magma_block
setblock 55 182 490 minecraft:magma_block
fill 55 182 492 57 187 492 minecraft:basalt
setblock 55 182 493 minecraft:magma_block
fill 55 182 495 57 184 495 minecraft:basalt
setblock 55 182 496 minecraft:magma_block
setblock 55 182 499 minecraft:magma_block
fill 56 182 466 63 185 466 minecraft:basalt
fill 56 182 469 61 187 469 minecraft:basalt
fill 56 182 472 58 189 472 minecraft:basalt
fill 56 182 475 56 191 475 minecraft:basalt
fill 56 182 487 56 191 487 minecraft:basalt
fill 56 182 490 58 189 490 minecraft:basalt
fill 56 182 493 61 187 493 minecraft:basalt
fill 56 182 496 63 185 496 minecraft:basalt
fill 56 182 499 63 182 499 minecraft:basalt
fill 57 182 500 60 182 500 minecraft:basalt
setblock 58 182 465 minecraft:magma_block
setblock 58 182 468 minecraft:magma_block
setblock 58 182 471 minecraft:magma_block
setblock 58 182 492 minecraft:magma_block
setblock 58 182 495 minecraft:magma_block
setblock 58 182 498 minecraft:magma_block
setblock 58 182 501 minecraft:magma_block
fill 59 182 465 66 186 465 minecraft:basalt
fill 59 182 468 63 182 468 minecraft:basalt
fill 59 182 471 59 191 471 minecraft:basalt
fill 59 182 492 60 191 492 minecraft:basalt
fill 59 182 495 65 188 495 minecraft:basalt
fill 59 182 498 66 185 498 minecraft:basalt
fill 59 182 501 66 182 501 minecraft:basalt
fill 60 182 502 63 182 502 minecraft:basalt
setblock 61 182 464 minecraft:magma_block
setblock 61 182 467 minecraft:magma_block
setblock 61 182 494 minecraft:magma_block
setblock 61 182 497 minecraft:magma_block
setblock 61 182 500 minecraft:magma_block
fill 62 182 464 69 187 464 minecraft:basalt
fill 62 182 467 65 190 467 minecraft:basalt
fill 62 182 494 63 191 494 minecraft:basalt
fill 62 182 497 69 188 497 minecraft:basalt
fill 62 182 500 69 185 500 minecraft:basalt
fill 62 182 503 69 182 503 minecraft:basalt
setblock 64 182 466 minecraft:magma_block
setblock 64 182 496 minecraft:magma_block
setblock 64 182 499 minecraft:magma_block
setblock 64 182 502 minecraft:magma_block
fill 65 182 466 72 182 466 minecraft:basalt
fill 65 182 496 72 182 496 minecraft:basalt
fill 65 182 499 72 187 499 minecraft:basalt
fill 65 182 502 72 183 502 minecraft:basalt
fill 65 182 504 66 182 504 minecraft:basalt
setblock 67 182 465 minecraft:magma_block
setblock 67 182 498 minecraft:magma_block
setblock 67 182 501 minecraft:magma_block
setblock 67 182 504 minecraft:magma_block
fill 68 182 465 75 188 465 minecraft:basalt
fill 68 182 498 75 188 498 minecraft:basalt
fill 68 182 501 75 184 501 minecraft:basalt
fill 68 182 504 75 182 504 minecraft:basalt
setblock 70 182 464 minecraft:magma_block
setblock 70 182 497 minecraft:magma_block
setblock 70 182 500 minecraft:magma_block
setblock 70 182 503 minecraft:magma_block
fill 71 182 464 78 186 464 minecraft:basalt
fill 71 182 497 78 188 497 minecraft:basalt
fill 71 182 500 78 185 500 minecraft:basalt
fill 71 182 503 78 182 503 minecraft:basalt
setblock 73 182 466 minecraft:magma_block
setblock 73 182 496 minecraft:magma_block
setblock 73 182 499 minecraft:magma_block
setblock 73 182 502 minecraft:magma_block
fill 74 182 466 81 187 466 minecraft:basalt
fill 74 182 496 81 187 496 minecraft:basalt
fill 74 182 499 81 184 499 minecraft:basalt
fill 74 182 502 80 182 502 minecraft:basalt
fill 75 182 467 78 182 467 minecraft:basalt
fill 75 182 495 75 191 495 minecraft:basalt
setblock 76 182 465 minecraft:magma_block
setblock 76 182 495 minecraft:magma_block
setblock 76 182 498 minecraft:magma_block
setblock 76 182 501 minecraft:magma_block
fill 77 182 465 84 184 465 minecraft:basalt
fill 77 182 468 84 186 468 minecraft:basalt
fill 77 182 494 78 190 495 minecraft:basalt
fill 77 182 498 84 183 498 minecraft:basalt
fill 77 182 501 82 182 501 minecraft:basalt
setblock 79 182 464 minecraft:magma_block
setblock 79 182 467 minecraft:magma_block
fill 79 182 469 81 190 469 minecraft:basalt
fill 79 182 493 81 190 493 minecraft:basalt
setblock 79 182 494 minecraft:magma_block
fill 79 182 495 84 186 495 minecraft:basalt
setblock 79 182 497 minecraft:magma_block
setblock 79 182 500 minecraft:magma_block
fill 80 182 464 86 182 464 minecraft:basalt
fill 80 182 467 87 183 467 minecraft:basalt
fill 80 182 470 87 185 470 minecraft:basalt
fill 80 182 492 84 188 492 minecraft:basalt
fill 80 182 494 87 184 494 minecraft:basalt
fill 80 182 497 87 182 497 minecraft:basalt
fill 80 182 500 83 182 500 minecraft:basalt
fill 81 182 471 84 188 471 minecraft:basalt
fill 81 182 491 87 186 491 minecraft:basalt
setblock 82 182 466 minecraft:magma_block
setblock 82 182 469 minecraft:magma_block
setblock 82 182 472 minecraft:magma_block
setblock 82 182 490 minecraft:magma_block
setblock 82 182 493 minecraft:magma_block
setblock 82 182 496 minecraft:magma_block
setblock 82 182 499 minecraft:magma_block
fill 83 182 466 88 182 466 minecraft:basalt
fill 83 182 469 88 184 469 minecraft:basalt
fill 83 182 472 84 189 474 minecraft:basalt
fill 83 182 488 84 189 490 minecraft:basalt
fill 83 182 493 88 184 493 minecraft:basalt
fill 83 182 496 88 182 496 minecraft:basalt
fill 83 182 499 85 182 499 minecraft:basalt
fill 84 182 475 87 182 476 minecraft:basalt
fill 84 182 486 84 191 487 minecraft:basalt
setblock 85 182 465 minecraft:magma_block
setblock 85 182 468 minecraft:magma_block
setblock 85 182 471 minecraft:magma_block
fill 85 182 472 87 186 473 minecraft:basalt
setblock 85 182 474 minecraft:magma_block
setblock 85 182 477 minecraft:magma_block
fill 85 182 478 87 188 479 minecraft:basalt
setblock 85 182 480 minecraft:magma_block
fill 85 182 481 87 188 482 minecraft:basalt
setblock 85 182 483 minecraft:magma_block
fill 85 182 484 87 188 485 minecraft:basalt
setblock 85 182 486 minecraft:magma_block
fill 85 182 487 87 187 488 minecraft:basalt
setblock 85 182 489 minecraft:magma_block
fill 85 182 490 88 184 490 minecraft:basalt
setblock 85 182 492 minecraft:magma_block
setblock 85 182 495 minecraft:magma_block
setblock 85 182 498 minecraft:magma_block
fill 86 182 465 87 182 465 minecraft:basalt
fill 86 182 468 88 183 468 minecraft:basalt
fill 86 182 471 88 185 471 minecraft:basalt
fill 86 182 474 88 186 474 minecraft:basalt
fill 86 182 477 88 187 477 minecraft:basalt
fill 86 182 480 88 187 480 minecraft:basalt
fill 86 182 483 88 187 483 minecraft:basalt
fill 86 182 486 88 187 486 minecraft:basalt
fill 86 182 489 88 186 489 minecraft:basalt
fill 86 182 492 88 184 492 minecraft:basalt
fill 86 182 495 88 182 495 minecraft:basalt
setblock 86 182 498 minecraft:basalt
setblock 88 182 467 minecraft:magma_block
setblock 88 182 470 minecraft:magma_block
fill 88 182 472 88 184 472 minecraft:basalt
setblock 88 182 473 minecraft:magma_block
fill 88 182 475 88 187 475 minecraft:basalt
setblock 88 182 476 minecraft:magma_block
fill 88 182 478 88 188 478 minecraft:basalt
setblock 88 182 479 minecraft:magma_block
fill 88 182 481 88 188 481 minecraft:basalt
setblock 88 182 482 minecraft:magma_block
fill 88 182 484 88 188 484 minecraft:basalt
setblock 88 182 485 minecraft:magma_block
fill 88 182 487 88 187 487 minecraft:basalt
setblock 88 182 488 minecraft:magma_block
setblock 88 182 491 minecraft:magma_block
setblock 88 182 494 minecraft:magma_block
setblock 48 183 476 minecraft:magma_block
fill 48 183 477 48 183 478 minecraft:basalt
setblock 48 183 479 minecraft:magma_block
fill 48 183 480 48 183 481 minecraft:basalt
setblock 48 183 482 minecraft:magma_block
fill 48 183 483 48 183 484 minecraft:basalt
setblock 48 183 485 minecraft:magma_block
fill 48 183 486 49 183 486 minecraft:basalt
fill 49 183 473 49 183 474 minecraft:basalt
fill 49 183 477 49 184 477 minecraft:basalt
fill 49 183 480 49 184 480 minecraft:basalt
fill 49 183 483 49 184 483 minecraft:basalt
setblock 49 183 489 minecraft:basalt
setblock 50 183 466 minecraft:light[level=14]
fill 50 183 471 51 183 473 minecraft:basalt
fill 50 183 490 51 183 491 minecraft:basalt
setblock 50 183 498 minecraft:light[level=14]
setblock 51 183 469 minecraft:magma_block
fill 51 183 470 52 183 470 minecraft:basalt
fill 51 183 492 54 183 492 minecraft:basalt
setblock 51 183 493 minecraft:magma_block
fill 52 183 468 62 183 468 minecraft:basalt
fill 52 183 473 52 186 473 minecraft:basalt
fill 52 183 476 52 187 476 minecraft:basalt
fill 52 183 479 52 188 479 minecraft:basalt
fill 52 183 482 52 188 482 minecraft:basalt
fill 52 183 485 52 187 485 minecraft:basalt
fill 52 183 488 56 186 488 minecraft:basalt
fill 52 183 491 52 185 491 minecraft:basalt
fill 52 183 493 52 183 494 minecraft:basalt
fill 53 183 466 55 183 466 minecraft:basalt
fill 53 183 493 55 185 493 minecraft:basalt
fill 53 183 495 54 183 496 minecraft:basalt
setblock 54 183 465 minecraft:magma_block
fill 54 183 497 61 183 497 minecraft:basalt
fill 55 183 464 58 183 465 minecraft:basalt
fill 55 183 469 55 186 469 minecraft:basalt
fill 55 183 472 55 188 472 minecraft:basalt
fill 55 183 475 55 190 475 minecraft:basalt
fill 55 183 478 56 183 478 minecraft:basalt
fill 55 183 481 55 190 481 minecraft:basalt
fill 55 183 484 56 183 484 minecraft:basalt
fill 55 183 487 55 190 487 minecraft:basalt
fill 55 183 490 55 188 490 minecraft:basalt
fill 55 183 496 55 184 496 minecraft:basalt
fill 55 183 498 58 183 498 minecraft:basalt
fill 56 183 477 56 192 477 minecraft:basalt
fill 56 183 479 56 192 479 minecraft:basalt
fill 56 183 483 56 192 483 minecraft:basalt
fill 56 183 485 56 192 485 minecraft:basalt
fill 57 183 475 57 192 475 minecraft:basalt
fill 57 183 487 57 192 487 minecraft:basalt
setblock 57 183 488 minecraft:magma_block
fill 57 183 499 64 183 499 minecraft:basalt
fill 58 183 471 58 190 471 minecraft:basalt
fill 58 183 473 58 192 473 minecraft:basalt
setblock 58 183 474 minecraft:light[level=14]
setblock 58 183 482 minecraft:light[level=14]
fill 58 183 489 58 192 489 minecraft:basalt
fill 58 183 492 58 190 492 minecraft:basalt
fill 58 183 495 58 187 495 minecraft:basalt
fill 58 183 500 61 183 500 minecraft:basalt
fill 59 183 464 61 185 464 minecraft:basalt
fill 59 183 472 59 192 472 minecraft:basalt
fill 59 183 490 59 192 490 minecraft:basalt
fill 60 183 471 60 192 471 minecraft:basalt
fill 60 183 491 60 192 491 minecraft:basalt
fill 60 183 501 67 183 501 minecraft:basalt
fill 61 183 467 61 189 467 minecraft:basalt
fill 61 183 470 61 192 470 minecraft:basalt
fill 61 183 492 61 192 492 minecraft:basalt
fill 61 183 494 61 190 494 minecraft:basalt
fill 62 183 469 62 192 469 minecraft:basalt
fill 62 183 493 62 192 493 minecraft:basalt
fill 62 183 502 64 183 502 minecraft:basalt
setblock 63 183 468 minecraft:magma_block
fill 64 183 466 68 190 466 minecraft:basalt
fill 64 183 468 64 192 468 minecraft:basalt
fill 64 183 494 64 192 494 minecraft:basalt
fill 64 183 496 68 190 496 minecraft:basalt
setblock 65 183 503 minecraft:basalt
setblock 66 183 467 minecraft:magma_block
setblock 66 183 474 minecraft:light[level=14]
setblock 66 183 482 minecraft:light[level=14]
setblock 66 183 490 minecraft:light[level=14]
fill 66 183 495 68 183 495 minecraft:basalt
setblock 66 183 503 minecraft:magma_block
fill 67 183 465 67 190 465 minecraft:basalt
fill 67 183 467 68 192 467 minecraft:basalt
fill 67 183 498 67 189 498 minecraft:basalt
fill 67 183 503 74 183 503 minecraft:basalt
setblock 69 183 466 minecraft:magma_block
setblock 69 183 496 minecraft:magma_block
fill 70 183 464 70 189 464 minecraft:basalt
fill 70 183 466 73 190 466 minecraft:basalt
fill 70 183 496 70 190 497 minecraft:basalt
fill 70 183 500 70 187 500 minecraft:basalt
fill 71 183 496 73 190 496 minecraft:basalt
fill 72 183 467 74 192 467 minecraft:basalt
setblock 72 183 495 minecraft:magma_block
fill 73 183 495 74 192 495 minecraft:basalt
fill 73 183 499 73 188 499 minecraft:basalt
fill 73 183 502 77 183 502 minecraft:basalt
setblock 74 183 474 minecraft:light[level=14]
setblock 74 183 482 minecraft:light[level=14]
setblock 74 183 490 minecraft:light[level=14]
setblock 75 183 467 minecraft:magma_block
setblock 75 183 503 minecraft:magma_block
fill 76 183 465 76 189 465 minecraft:basalt
fill 76 183 467 76 191 468 minecraft:basalt
fill 76 183 494 76 190 495 minecraft:basalt
fill 76 183 498 76 188 498 minecraft:basalt
fill 76 183 501 80 183 501 minecraft:basalt
fill 77 183 467 79 189 467 minecraft:basalt
setblock 78 183 469 minecraft:magma_block
setblock 78 183 493 minecraft:magma_block
setblock 78 183 502 minecraft:magma_block
fill 79 183 464 83 184 464 minecraft:basalt
fill 79 183 470 79 192 470 minecraft:basalt
fill 79 183 492 79 192 492 minecraft:basalt
fill 79 183 494 79 190 494 minecraft:basalt
fill 79 183 497 86 183 497 minecraft:basalt
fill 79 183 500 82 183 500 minecraft:basalt
fill 80 183 471 80 192 471 minecraft:basalt
fill 80 183 491 80 192 491 minecraft:basalt
fill 81 183 472 82 190 472 minecraft:basalt
fill 81 183 490 82 190 490 minecraft:basalt
fill 82 183 466 86 183 466 minecraft:basalt
fill 82 183 469 82 189 469 minecraft:basalt
fill 82 183 473 82 192 473 minecraft:basalt
setblock 82 183 474 minecraft:light[level=14]
setblock 82 183 482 minecraft:light[level=14]
fill 82 183 489 82 192 489 minecraft:basalt
fill 82 183 493 82 189 493 minecraft:basalt
fill 82 183 496 86 183 496 minecraft:basalt
fill 82 183 499 83 183 499 minecraft:basalt
fill 83 183 475 87 183 475 minecraft:basalt
setblock 83 183 487 minecraft:basalt
setblock 84 183 464 minecraft:magma_block
setblock 84 183 476 minecraft:magma_block
fill 84 183 477 84 192 478 minecraft:basalt
setblock 84 183 479 minecraft:magma_block
fill 84 183 483 84 192 484 minecraft:basalt
setblock 84 183 485 minecraft:magma_block
fill 85 183 464 85 183 465 minecraft:basalt
fill 85 183 468 85 186 468 minecraft:basalt
fill 85 183 471 85 188 471 minecraft:basalt
fill 85 183 474 85 190 474 minecraft:basalt
fill 85 183 476 85 190 477 minecraft:basalt
fill 85 183 480 85 190 480 minecraft:basalt
fill 85 183 483 85 190 483 minecraft:basalt
fill 85 183 486 85 190 486 minecraft:basalt
fill 85 183 489 85 189 489 minecraft:basalt
fill 85 183 492 85 187 492 minecraft:basalt
fill 85 183 495 87 183 495 minecraft:basalt
setblock 85 183 498 minecraft:basalt
setblock 86 183 465 minecraft:basalt
fill 86 183 476 88 187 476 minecraft:basalt
setblock 87 183 466 minecraft:magma_block
setblock 87 183 496 minecraft:magma_block
fill 88 183 470 88 184 470 minecraft:basalt
fill 88 183 473 88 186 473 minecraft:basalt
fill 88 183 479 88 188 479 minecraft:basalt
fill 88 183 482 88 188 482 minecraft:basalt
fill 88 183 485 88 187 485 minecraft:basalt
fill 88 183 488 88 186 488 minecraft:basalt
fill 88 183 491 88 185 491 minecraft:basalt
setblock 88 183 494 minecraft:basalt
fill 49 184 476 51 184 476 minecraft:basalt
setblock 49 184 486 minecraft:basalt
fill 50 184 473 51 184 473 minecraft:basalt
setblock 50 184 474 minecraft:magma_block
fill 50 184 475 51 185 475 minecraft:basalt
fill 50 184 487 51 184 488 minecraft:basalt
setblock 50 184 489 minecraft:magma_block
fill 51 184 471 51 184 472 minecraft:basalt
fill 51 184 474 58 185 474 minecraft:basalt
fill 51 184 489 51 184 491 minecraft:basalt
setblock 52 184 470 minecraft:basalt
fill 52 184 489 57 186 489 minecraft:basalt
fill 52 184 492 52 184 493 minecraft:basalt
fill 53 184 468 63 184 468 minecraft:basalt
fill 53 184 492 54 185 492 minecraft:basalt
setblock 53 184 494 minecraft:magma_block
fill 54 184 467 60 184 467 minecraft:basalt
fill 54 184 494 54 184 495 minecraft:basalt
setblock 55 184 466 minecraft:basalt
fill 55 184 478 55 190 478 minecraft:basalt
fill 55 184 484 55 190 484 minecraft:basalt
fill 55 184 494 60 186 494 minecraft:basalt
fill 56 184 465 58 184 465 minecraft:basalt
setblock 56 184 478 minecraft:magma_block
fill 56 184 480 56 192 480 minecraft:basalt
setblock 56 184 481 minecraft:magma_block
fill 56 184 482 56 192 482 minecraft:basalt
setblock 56 184 484 minecraft:magma_block
fill 56 184 497 61 184 497 minecraft:basalt
fill 57 184 464 58 184 464 minecraft:basalt
fill 57 184 476 57 191 477 minecraft:basalt
fill 57 184 485 57 193 486 minecraft:basalt
fill 57 184 488 58 191 488 minecraft:basalt
fill 57 184 498 58 184 498 minecraft:basalt
fill 58 184 499 64 184 499 minecraft:basalt
fill 59 184 473 59 193 473 minecraft:basalt
setblock 59 184 489 minecraft:magma_block
fill 60 184 472 60 193 472 minecraft:basalt
fill 60 184 490 60 193 490 minecraft:basalt
fill 60 184 500 61 184 500 minecraft:basalt
fill 61 184 471 61 193 471 minecraft:basalt
fill 61 184 491 61 193 491 minecraft:basalt
setblock 62 184 470 minecraft:magma_block
fill 62 184 492 62 193 492 minecraft:basalt
fill 62 184 501 67 184 501 minecraft:basalt
fill 63 184 469 63 193 469 minecraft:basalt
fill 63 184 493 63 193 493 minecraft:basalt
fill 65 184 468 66 193 468 minecraft:basalt
fill 65 184 494 66 193 494 minecraft:basalt
setblock 65 184 502 minecraft:magma_block
fill 66 184 467 66 191 467 minecraft:basalt
fill 66 184 495 67 192 495 minecraft:basalt
fill 66 184 502 73 184 502 minecraft:basalt
setblock 68 184 495 minecraft:magma_block
fill 69 184 466 69 191 467 minecraft:basalt
fill 69 184 495 69 191 496 minecraft:basalt
fill 70 184 467 70 192 467 minecraft:basalt
fill 70 184 495 72 191 495 minecraft:basalt
setblock 71 184 467 minecraft:magma_block
fill 74 184 468 75 193 468 minecraft:basalt
fill 74 184 494 75 191 494 minecraft:basalt
setblock 74 184 502 minecraft:magma_block
fill 75 184 467 75 191 467 minecraft:basalt
setblock 75 184 502 minecraft:basalt
fill 76 184 501 76 185 501 minecraft:basalt
fill 77 184 469 78 191 469 minecraft:basalt
fill 77 184 493 78 191 493 minecraft:basalt
fill 77 184 498 83 184 498 minecraft:basalt
setblock 77 184 501 minecraft:magma_block
fill 78 184 470 78 193 470 minecraft:basalt
fill 78 184 492 78 193 492 minecraft:basalt
setblock 78 184 501 minecraft:basalt
fill 79 184 471 79 193 471 minecraft:basalt
fill 79 184 491 79 193 491 minecraft:basalt
fill 79 184 497 84 184 497 minecraft:basalt
setblock 79 184 500 minecraft:basalt
fill 80 184 467 86 184 467 minecraft:basalt
fill 80 184 472 80 193 472 minecraft:basalt
fill 80 184 490 80 193 490 minecraft:basalt
setblock 80 184 500 minecraft:magma_block
fill 81 184 473 81 193 473 minecraft:basalt
fill 81 184 489 81 193 489 minecraft:basalt
fill 82 184 466 85 184 466 minecraft:basalt
fill 82 184 474 82 193 474 minecraft:basalt
fill 82 184 488 82 193 488 minecraft:basalt
fill 82 184 496 85 184 496 minecraft:basalt
setblock 82 184 499 minecraft:basalt
setblock 83 184 475 minecraft:magma_block
fill 83 184 476 83 193 477 minecraft:basalt
fill 83 184 485 83 193 486 minecraft:basalt
setblock 83 184 487 minecraft:magma_block
fill 84 184 475 84 191 476 minecraft:basalt
fill 84 184 479 84 191 482 minecraft:basalt
fill 84 184 485 84 191 485 minecraft:basalt
fill 85 184 475 87 188 475 minecraft:basalt
fill 85 184 495 85 185 495 minecraft:basalt
fill 86 184 468 87 184 468 minecraft:basalt
setblock 86 184 495 minecraft:magma_block
fill 48 185 470 48 230 471 minecraft:quartz_block
fill 48 185 478 48 230 479 minecraft:quartz_block
fill 48 185 486 48 230 487 minecraft:quartz_block
fill 48 185 494 48 230 495 minecraft:quartz_block
fill 48 185 502 48 230 503 minecraft:quartz_block
fill 49 185 464 50 230 464 minecraft:quartz_block
fill 50 185 467 50 185 469 minecraft:gray_concrete
fill 50 185 476 51 185 476 minecraft:basalt
fill 50 185 478 51 185 479 minecraft:basalt
fill 50 185 481 51 186 482 minecraft:basalt
fill 50 185 484 51 185 485 minecraft:basalt
fill 50 185 487 51 185 487 minecraft:basalt
fill 51 185 466 53 185 466 minecraft:gray_concrete
fill 51 185 467 52 230 469 minecraft:quartz_block
fill 51 185 470 52 185 470 minecraft:gray_concrete
setblock 51 185 473 minecraft:basalt
fill 51 185 488 51 185 489 minecraft:basalt
fill 52 185 471 54 185 471 minecraft:basalt
setblock 52 185 472 minecraft:magma_block
setblock 52 185 490 minecraft:magma_block
fill 53 185 467 53 230 468 minecraft:quartz_block
fill 53 185 469 54 185 469 minecraft:basalt
fill 53 185 472 54 186 472 minecraft:basalt
fill 53 185 490 54 186 490 minecraft:basalt
setblock 54 185 467 minecraft:gray_concrete
fill 54 185 468 63 185 468 minecraft:basalt
setblock 54 185 494 minecraft:basalt
fill 54 185 504 55 230 504 minecraft:quartz_block
fill 55 185 467 60 185 467 minecraft:basalt
setblock 55 185 495 minecraft:magma_block
fill 56 185 478 57 192 478 minecraft:basalt
fill 56 185 481 57 185 481 minecraft:basalt
fill 56 185 484 57 192 484 minecraft:basalt
fill 56 185 495 57 186 495 minecraft:basalt
fill 57 185 464 57 230 464 minecraft:quartz_block
fill 57 185 465 58 185 465 minecraft:basalt
fill 57 185 479 57 193 480 minecraft:basalt
fill 57 185 482 57 193 483 minecraft:basalt
fill 57 185 497 61 185 497 minecraft:basalt
setblock 58 185 464 minecraft:magma_block
fill 58 185 475 58 193 475 minecraft:basalt
setblock 58 185 476 minecraft:magma_block
fill 58 185 486 58 193 487 minecraft:basalt
setblock 58 185 498 minecraft:basalt
fill 59 185 474 59 194 474 minecraft:basalt
fill 59 185 488 59 192 489 minecraft:basalt
setblock 60 185 499 minecraft:basalt
setblock 61 185 499 minecraft:magma_block
fill 62 185 470 63 192 470 minecraft:basalt
fill 62 185 499 64 186 499 minecraft:basalt
fill 62 185 504 63 230 504 minecraft:quartz_block
fill 63 185 492 63 194 492 minecraft:basalt
fill 64 185 469 65 193 469 minecraft:basalt
fill 64 185 493 65 193 493 minecraft:basalt
setblock 64 185 501 minecraft:magma_block
fill 65 185 501 72 185 501 minecraft:basalt
fill 67 185 468 72 185 468 minecraft:basalt
setblock 67 185 494 minecraft:magma_block
fill 68 185 494 68 192 495 minecraft:basalt
fill 69 185 494 73 185 494 minecraft:basalt
fill 70 185 504 71 230 504 minecraft:quartz_block
fill 71 185 467 71 192 467 minecraft:basalt
setblock 73 185 468 minecraft:magma_block
setblock 73 185 501 minecraft:magma_block
fill 74 185 499 78 186 499 minecraft:basalt
fill 74 185 501 75 185 501 minecraft:basalt
fill 75 185 469 76 185 469 minecraft:basalt
fill 75 185 493 76 185 493 minecraft:basalt
fill 77 185 465 83 185 465 minecraft:basalt
fill 77 185 470 77 194 470 minecraft:basalt
fill 77 185 492 77 194 492 minecraft:basalt
fill 77 185 498 81 185 498 minecraft:basalt
fill 78 185 504 79 230 504 minecraft:quartz_block
fill 79 185 464 82 185 464 minecraft:basalt
fill 79 185 497 83 185 497 minecraft:basalt
setblock 79 185 499 minecraft:magma_block
fill 80 185 467 84 186 467 minecraft:basalt
fill 80 185 494 86 185 494 minecraft:basalt
setblock 80 185 499 minecraft:basalt
fill 81 185 474 81 194 474 minecraft:basalt
fill 81 185 488 81 194 488 minecraft:basalt
fill 82 185 466 84 185 466 minecraft:basalt
fill 82 185 475 82 193 476 minecraft:basalt
setblock 82 185 486 minecraft:magma_block
fill 82 185 487 83 192 487 minecraft:basalt
fill 82 185 496 84 185 496 minecraft:basalt
setblock 82 185 498 minecraft:magma_block
fill 83 185 469 87 185 469 minecraft:basalt
fill 83 185 475 83 192 475 minecraft:basalt
fill 83 185 478 83 192 484 minecraft:basalt
fill 83 185 493 87 185 493 minecraft:basalt
setblock 85 185 467 minecraft:magma_block
fill 85 185 490 87 186 490 minecraft:basalt
setblock 86 185 468 minecraft:basalt
fill 86 185 492 87 185 492 minecraft:basalt
fill 86 185 504 87 230 504 minecraft:quartz_block
fill 88 185 465 88 230 466 minecraft:quartz_block
setblock 88 185 472 minecraft:magma_block
setblock 88 185 490 minecraft:magma_block
fill 88 185 497 88 230 498 minecraft:quartz_block
fill 47 186 468 47 191 468 minecraft:sea_lantern
fill 47 186 476 47 191 476 minecraft:sea_lantern
fill 47 186 484 47 191 484 minecraft:sea_lantern
fill 47 186 492 47 191 492 minecraft:sea_lantern
fill 47 186 500 47 191 500 minecraft:sea_lantern
fill 50 186 505 50 191 505 minecraft:sea_lantern
fill 51 186 475 51 186 476 minecraft:basalt
setblock 51 186 477 minecraft:magma_block
fill 51 186 478 51 186 479 minecraft:basalt
setblock 51 186 483 minecraft:magma_block
fill 51 186 484 51 186 485 minecraft:basalt
setblock 51 186 486 minecraft:magma_block
setblock 51 186 487 minecraft:basalt
fill 52 186 474 58 186 474 minecraft:basalt
fill 52 186 477 55 187 477 minecraft:basalt
fill 52 186 483 55 187 483 minecraft:basalt
fill 52 186 486 56 187 486 minecraft:basalt
fill 53 186 469 53 202 469 minecraft:quartz_block
fill 53 186 471 54 186 471 minecraft:basalt
fill 54 186 463 54 191 463 minecraft:sea_lantern
setblock 54 186 469 minecraft:basalt
setblock 54 186 470 minecraft:magma_block
fill 54 186 492 54 186 493 minecraft:basalt
fill 55 186 468 63 186 468 minecraft:basalt
fill 55 186 470 60 187 470 minecraft:basalt
setblock 55 186 493 minecraft:basalt
fill 56 186 467 60 186 467 minecraft:basalt
fill 56 186 481 56 192 481 minecraft:basalt
setblock 57 186 466 minecraft:magma_block
setblock 57 186 481 minecraft:magma_block
setblock 57 186 496 minecraft:magma_block
fill 58 186 464 58 230 464 minecraft:quartz_block
fill 58 186 465 58 186 466 minecraft:basalt
fill 58 186 476 58 193 478 minecraft:basalt
fill 58 186 484 58 193 485 minecraft:basalt
fill 58 186 496 61 186 497 minecraft:basalt
fill 58 186 505 58 191 505 minecraft:sea_lantern
fill 59 186 466 63 187 466 minecraft:basalt
fill 59 186 475 59 194 475 minecraft:basalt
fill 59 186 487 59 194 487 minecraft:basalt
fill 60 186 464 61 186 464 minecraft:basalt
fill 60 186 473 60 194 473 minecraft:basalt
setblock 60 186 474 minecraft:magma_block
fill 60 186 488 60 194 488 minecraft:basalt
setblock 60 186 489 minecraft:magma_block
setblock 60 186 498 minecraft:magma_block
fill 61 186 472 61 193 472 minecraft:basalt
fill 61 186 490 61 193 490 minecraft:basalt
fill 61 186 498 66 186 498 minecraft:basalt
fill 62 186 463 62 191 463 minecraft:sea_lantern
fill 62 186 471 63 194 471 minecraft:basalt
fill 62 186 491 62 194 491 minecraft:basalt
fill 62 186 496 63 188 496 minecraft:basalt
setblock 63 186 491 minecraft:magma_block
fill 64 186 470 64 194 470 minecraft:basalt
fill 64 186 492 64 193 492 minecraft:basalt
fill 64 186 500 69 186 500 minecraft:basalt
setblock 66 186 469 minecraft:magma_block
setblock 66 186 493 minecraft:magma_block
fill 66 186 505 66 191 505 minecraft:sea_lantern
fill 67 186 468 67 193 469 minecraft:basalt
fill 67 186 493 67 193 494 minecraft:basalt
fill 68 186 468 68 192 468 minecraft:basalt
setblock 69 186 468 minecraft:magma_block
fill 69 186 494 71 192 494 minecraft:basalt
setblock 69 186 501 minecraft:magma_block
fill 70 186 463 70 191 463 minecraft:sea_lantern
fill 70 186 468 73 193 468 minecraft:basalt
fill 70 186 501 71 186 501 minecraft:basalt
fill 71 186 500 71 187 500 minecraft:basalt
setblock 72 186 494 minecraft:magma_block
setblock 72 186 500 minecraft:magma_block
fill 73 186 469 74 194 469 minecraft:basalt
fill 73 186 493 73 193 494 minecraft:basalt
fill 73 186 500 76 186 500 minecraft:basalt
fill 74 186 493 74 194 493 minecraft:basalt
fill 74 186 505 74 191 505 minecraft:sea_lantern
setblock 75 186 469 minecraft:magma_block
setblock 75 186 493 minecraft:magma_block
fill 76 186 469 76 193 470 minecraft:basalt
fill 76 186 492 76 193 493 minecraft:basalt
fill 77 186 465 82 186 465 minecraft:basalt
fill 77 186 471 77 194 471 minecraft:basalt
fill 77 186 491 78 186 491 minecraft:basalt
fill 77 186 498 80 186 498 minecraft:basalt
fill 78 186 463 78 191 463 minecraft:sea_lantern
setblock 78 186 471 minecraft:magma_block
fill 79 186 464 80 186 464 minecraft:basalt
fill 79 186 472 79 193 472 minecraft:basalt
fill 79 186 490 79 193 490 minecraft:basalt
fill 79 186 497 80 187 497 minecraft:basalt
fill 80 186 470 86 186 470 minecraft:basalt
fill 80 186 473 80 194 474 minecraft:basalt
fill 80 186 488 80 194 489 minecraft:basalt
fill 80 186 494 85 186 494 minecraft:basalt
fill 81 186 464 82 230 464 minecraft:quartz_block
fill 81 186 475 81 194 475 minecraft:basalt
fill 81 186 487 81 194 487 minecraft:basalt
setblock 81 186 497 minecraft:magma_block
fill 82 186 466 83 186 466 minecraft:basalt
fill 82 186 477 82 193 478 minecraft:basalt
fill 82 186 484 82 193 486 minecraft:basalt
fill 82 186 496 82 186 497 minecraft:basalt
fill 82 186 505 82 191 505 minecraft:sea_lantern
fill 83 186 469 86 186 469 minecraft:basalt
fill 83 186 493 86 186 493 minecraft:basalt
setblock 83 186 496 minecraft:basalt
fill 86 186 463 86 191 463 minecraft:sea_lantern
fill 86 186 471 86 187 471 minecraft:basalt
setblock 86 186 492 minecraft:basalt
setblock 87 186 471 minecraft:magma_block
fill 88 186 490 88 187 491 minecraft:quartz_block
fill 89 186 468 89 191 468 minecraft:sea_lantern
fill 89 186 476 89 191 476 minecraft:sea_lantern
fill 89 186 484 89 191 484 minecraft:sea_lantern
fill 89 186 492 89 191 492 minecraft:sea_lantern
fill 89 186 500 89 191 500 minecraft:sea_lantern
fill 51 187 479 51 187 483 minecraft:basalt
fill 52 187 480 55 187 480 minecraft:basalt
fill 53 187 474 58 187 474 minecraft:basalt
fill 53 187 488 56 187 489 minecraft:basalt
fill 54 187 471 54 187 472 minecraft:basalt
fill 54 187 490 54 187 491 minecraft:basalt
fill 55 187 491 59 187 491 minecraft:basalt
setblock 56 187 468 minecraft:magma_block
fill 56 187 494 60 187 494 minecraft:basalt
fill 57 187 467 60 187 468 minecraft:basalt
fill 57 187 481 58 194 481 minecraft:basalt
fill 57 187 489 57 191 489 minecraft:basalt
setblock 57 187 495 minecraft:basalt
fill 58 187 479 58 193 480 minecraft:basalt
fill 58 187 482 58 195 483 minecraft:basalt
setblock 59 187 476 minecraft:magma_block
fill 59 187 477 59 195 477 minecraft:basalt
setblock 59 187 485 minecraft:magma_block
fill 59 187 486 59 195 486 minecraft:basalt
fill 59 187 496 61 187 496 minecraft:basalt
fill 60 187 465 66 187 465 minecraft:basalt
fill 60 187 474 60 194 475 minecraft:basalt
fill 60 187 487 60 195 487 minecraft:basalt
fill 60 187 489 61 194 489 minecraft:basalt
fill 60 187 497 61 187 497 minecraft:basalt
fill 61 187 468 63 190 468 minecraft:basalt
fill 61 187 473 61 195 473 minecraft:basalt
setblock 62 187 472 minecraft:magma_block
setblock 62 187 490 minecraft:magma_block
fill 62 187 498 66 187 498 minecraft:basalt
fill 63 187 491 64 187 491 minecraft:basalt
fill 64 187 471 64 195 471 minecraft:basalt
setblock 64 187 499 minecraft:basalt
fill 65 187 470 66 195 470 minecraft:basalt
setblock 65 187 492 minecraft:magma_block
fill 66 187 469 66 194 469 minecraft:basalt
fill 66 187 492 66 194 493 minecraft:basalt
fill 68 187 469 70 195 469 minecraft:basalt
fill 68 187 493 70 195 493 minecraft:basalt
setblock 68 187 500 minecraft:magma_block
fill 69 187 468 69 194 468 minecraft:basalt
setblock 69 187 500 minecraft:basalt
fill 71 187 464 76 188 464 minecraft:basalt
setblock 71 187 469 minecraft:magma_block
setblock 71 187 493 minecraft:magma_block
fill 72 187 469 72 195 469 minecraft:basalt
fill 72 187 493 72 193 494 minecraft:basalt
setblock 72 187 500 minecraft:basalt
fill 74 187 470 75 195 470 minecraft:basalt
setblock 74 187 492 minecraft:magma_block
fill 74 187 499 76 187 499 minecraft:basalt
fill 75 187 469 75 194 469 minecraft:basalt
fill 75 187 492 75 194 493 minecraft:basalt
fill 76 187 471 76 195 471 minecraft:basalt
fill 76 187 491 76 195 491 minecraft:basalt
setblock 77 187 464 minecraft:magma_block
fill 77 187 465 80 187 465 minecraft:basalt
fill 77 187 468 82 188 468 minecraft:basalt
setblock 77 187 491 minecraft:magma_block
fill 77 187 498 78 187 498 minecraft:basalt
setblock 78 187 464 minecraft:basalt
fill 78 187 471 78 194 472 minecraft:basalt
fill 78 187 490 78 194 491 minecraft:basalt
fill 79 187 473 79 195 473 minecraft:basalt
fill 79 187 489 79 195 489 minecraft:basalt
fill 79 187 495 82 187 495 minecraft:basalt
fill 80 187 467 83 187 467 minecraft:basalt
fill 80 187 470 85 187 470 minecraft:basalt
setblock 80 187 475 minecraft:magma_block
setblock 80 187 487 minecraft:magma_block
fill 80 187 494 84 187 494 minecraft:basalt
fill 81 187 476 81 194 477 minecraft:basalt
fill 81 187 485 81 194 486 minecraft:basalt
fill 81 187 491 85 188 491 minecraft:basalt
fill 82 187 479 82 193 483 minecraft:basalt
setblock 83 187 468 minecraft:magma_block
fill 83 187 469 84 187 469 minecraft:basalt
fill 83 187 493 84 187 493 minecraft:basalt
setblock 83 187 495 minecraft:magma_block
setblock 84 187 468 minecraft:basalt
fill 84 187 495 88 188 495 minecraft:quartz_block
fill 85 187 472 86 187 473 minecraft:basalt
fill 85 187 490 86 187 490 minecraft:basalt
fill 85 187 493 88 187 494 minecraft:quartz_block
fill 86 187 474 87 187 474 minecraft:basalt
fill 86 187 489 87 187 489 minecraft:basalt
setblock 86 187 491 minecraft:magma_block
fill 86 187 492 88 187 492 minecraft:quartz_block
fill 86 187 496 88 188 496 minecraft:quartz_block
setblock 87 187 473 minecraft:basalt
fill 87 187 490 87 187 491 minecraft:quartz_block
fill 87 187 497 87 188 497 minecraft:quartz_block
fill 88 187 473 88 230 474 minecraft:quartz_block
fill 88 187 489 88 230 489 minecraft:quartz_block
setblock 52 188 480 minecraft:magma_block
setblock 52 188 483 minecraft:magma_block
fill 53 188 475 54 188 475 minecraft:basalt
fill 53 188 477 55 188 477 minecraft:basalt
fill 53 188 480 55 189 480 minecraft:basalt
fill 53 188 483 55 189 483 minecraft:basalt
fill 53 188 486 54 188 487 minecraft:basalt
fill 54 188 473 57 188 474 minecraft:basalt
fill 54 188 488 56 188 489 minecraft:basalt
fill 55 188 486 56 190 486 minecraft:basalt
setblock 55 188 491 minecraft:magma_block
fill 56 188 470 60 188 470 minecraft:basalt
fill 56 188 491 57 188 492 minecraft:basalt
fill 57 188 469 61 188 469 minecraft:basalt
fill 57 188 493 61 188 493 minecraft:basalt
fill 58 188 468 60 188 468 minecraft:basalt
fill 58 188 474 58 193 474 minecraft:basalt
fill 58 188 491 59 191 491 minecraft:basalt
fill 58 188 494 60 188 494 minecraft:basalt
fill 59 188 467 60 188 467 minecraft:basalt
fill 59 188 476 60 188 476 minecraft:basalt
fill 59 188 478 59 195 485 minecraft:basalt
fill 60 188 466 63 188 466 minecraft:basalt
fill 60 188 486 60 196 486 minecraft:basalt
fill 60 188 496 61 188 496 minecraft:basalt
setblock 61 188 474 minecraft:magma_block
fill 61 188 488 61 195 488 minecraft:basalt
fill 62 188 465 66 188 465 minecraft:basalt
fill 62 188 472 62 195 473 minecraft:basalt
fill 62 188 489 62 195 490 minecraft:basalt
fill 63 188 472 63 195 472 minecraft:basalt
fill 63 188 490 63 194 491 minecraft:basalt
setblock 64 188 464 minecraft:magma_block
setblock 64 188 491 minecraft:magma_block
fill 64 188 498 66 188 498 minecraft:basalt
fill 65 188 464 69 188 464 minecraft:basalt
fill 65 188 471 65 195 471 minecraft:basalt
fill 65 188 491 65 195 492 minecraft:basalt
fill 67 188 470 72 188 470 minecraft:basalt
fill 67 188 492 69 195 492 minecraft:basalt
setblock 67 188 499 minecraft:magma_block
fill 68 188 499 72 188 499 minecraft:basalt
setblock 70 188 492 minecraft:magma_block
fill 71 188 469 71 195 469 minecraft:basalt
fill 71 188 492 71 195 493 minecraft:basalt
fill 72 188 492 74 195 492 minecraft:basalt
setblock 73 188 470 minecraft:magma_block
fill 74 188 466 80 188 466 minecraft:basalt
fill 74 188 496 80 188 496 minecraft:basalt
setblock 75 188 471 minecraft:basalt
fill 75 188 491 75 196 491 minecraft:basalt
fill 77 188 465 78 188 465 minecraft:basalt
fill 77 188 472 77 195 472 minecraft:basalt
fill 77 188 490 77 194 491 minecraft:basalt
fill 78 188 473 78 195 473 minecraft:basalt
fill 78 188 489 78 194 489 minecraft:basalt
setblock 79 188 474 minecraft:magma_block
fill 79 188 488 79 195 488 minecraft:basalt
fill 79 188 495 81 188 495 minecraft:basalt
fill 80 188 467 81 188 467 minecraft:basalt
fill 80 188 470 84 188 470 minecraft:basalt
fill 80 188 475 80 195 476 minecraft:basalt
fill 80 188 486 80 195 487 minecraft:basalt
fill 80 188 494 81 189 494 minecraft:basalt
fill 81 188 478 81 188 484 minecraft:basalt
setblock 82 188 494 minecraft:magma_block
setblock 83 188 469 minecraft:basalt
setblock 83 188 493 minecraft:basalt
fill 83 188 500 88 188 500 minecraft:quartz_block
fill 84 188 493 86 188 494 minecraft:quartz_block
fill 84 188 496 85 188 499 minecraft:quartz_block
fill 84 188 501 88 189 502 minecraft:quartz_block
setblock 85 188 472 minecraft:magma_block
fill 85 188 473 86 188 473 minecraft:basalt
fill 85 188 487 86 188 488 minecraft:basalt
setblock 85 188 490 minecraft:magma_block
fill 85 188 503 88 189 503 minecraft:quartz_block
setblock 86 188 474 minecraft:basalt
fill 86 188 476 87 188 477 minecraft:basalt
fill 86 188 480 87 189 480 minecraft:basalt
fill 86 188 483 87 189 483 minecraft:basalt
fill 86 188 486 87 188 486 minecraft:basalt
setblock 86 188 489 minecraft:basalt
fill 86 188 497 86 188 499 minecraft:quartz_block
setblock 87 188 487 minecraft:basalt
fill 87 188 494 88 188 494 minecraft:quartz_block
fill 87 188 498 87 188 499 minecraft:quartz_block
setblock 88 188 480 minecraft:magma_block
setblock 88 188 483 minecraft:magma_block
fill 88 188 490 88 230 490 minecraft:quartz_block
setblock 88 188 499 minecraft:quartz_block
fill 88 188 504 88 189 504 minecraft:quartz_block
fill 53 189 478 54 189 478 minecraft:basalt
fill 53 189 481 54 189 481 minecraft:basalt
fill 53 189 484 54 189 484 minecraft:basalt
setblock 54 189 475 minecraft:magma_block
fill 54 189 476 55 189 477 minecraft:basalt
fill 54 189 485 54 189 486 minecraft:basalt
setblock 54 189 487 minecraft:magma_block
fill 55 189 473 57 189 474 minecraft:basalt
fill 55 189 485 55 191 485 minecraft:basalt
fill 55 189 488 56 189 489 minecraft:basalt
fill 56 189 471 57 189 471 minecraft:basalt
fill 56 189 476 56 191 476 minecraft:basalt
fill 56 189 491 57 189 491 minecraft:basalt
fill 57 189 470 60 189 470 minecraft:basalt
setblock 57 189 492 minecraft:magma_block
fill 58 189 469 61 189 469 minecraft:basalt
fill 58 189 493 61 189 493 minecraft:basalt
fill 59 189 468 60 189 468 minecraft:basalt
fill 59 189 476 59 195 476 minecraft:basalt
fill 59 189 494 60 189 494 minecraft:basalt
setblock 60 189 467 minecraft:magma_block
setblock 60 189 476 minecraft:magma_block
fill 60 189 477 60 196 478 minecraft:basalt
fill 60 189 484 60 196 484 minecraft:basalt
setblock 60 189 485 minecraft:magma_block
fill 60 189 495 65 189 495 minecraft:basalt
fill 61 189 474 61 195 475 minecraft:basalt
fill 61 189 487 61 196 487 minecraft:basalt
setblock 62 189 466 minecraft:basalt
fill 62 189 474 62 196 474 minecraft:basalt
fill 62 189 488 62 196 488 minecraft:basalt
setblock 62 189 496 minecraft:basalt
setblock 63 189 466 minecraft:magma_block
fill 63 189 473 63 196 473 minecraft:basalt
fill 63 189 489 63 196 489 minecraft:basalt
setblock 63 189 496 minecraft:magma_block
fill 64 189 465 65 189 465 minecraft:basalt
fill 64 189 472 64 196 472 minecraft:basalt
fill 64 189 490 64 195 491 minecraft:basalt
fill 64 189 497 69 189 497 minecraft:basalt
fill 65 189 464 66 230 464 minecraft:quartz_block
setblock 66 189 465 minecraft:magma_block
setblock 66 189 471 minecraft:magma_block
fill 66 189 491 67 196 491 minecraft:basalt
fill 67 189 464 68 189 464 minecraft:basalt
fill 67 189 470 67 195 471 minecraft:basalt
fill 68 189 465 74 189 465 minecraft:basalt
fill 68 189 470 68 195 470 minecraft:basalt
fill 68 189 498 73 189 498 minecraft:basalt
setblock 69 189 464 minecraft:magma_block
setblock 69 189 470 minecraft:magma_block
fill 70 189 470 73 195 470 minecraft:basalt
fill 70 189 492 70 196 492 minecraft:basalt
fill 71 189 464 73 189 464 minecraft:basalt
fill 71 189 497 76 189 497 minecraft:basalt
fill 73 189 471 74 195 471 minecraft:basalt
fill 73 189 491 74 196 491 minecraft:basalt
fill 74 189 464 74 230 464 minecraft:quartz_block
fill 74 189 466 78 189 466 minecraft:basalt
fill 74 189 496 78 189 496 minecraft:basalt
setblock 75 189 465 minecraft:magma_block
setblock 75 189 471 minecraft:magma_block
fill 76 189 472 76 196 472 minecraft:basalt
fill 76 189 490 76 196 490 minecraft:basalt
fill 77 189 468 81 189 468 minecraft:basalt
fill 77 189 473 77 195 473 minecraft:basalt
fill 77 189 489 77 196 489 minecraft:basalt
fill 77 189 500 83 189 501 minecraft:quartz_block
fill 78 189 474 79 195 474 minecraft:basalt
setblock 78 189 488 minecraft:magma_block
fill 78 189 502 83 189 503 minecraft:quartz_block
fill 79 189 475 79 196 475 minecraft:basalt
fill 79 189 487 79 196 487 minecraft:basalt
fill 79 189 495 80 189 495 minecraft:basalt
setblock 80 189 467 minecraft:basalt
fill 80 189 470 83 189 470 minecraft:basalt
fill 80 189 477 80 195 478 minecraft:basalt
fill 80 189 484 80 195 485 minecraft:basalt
fill 80 189 492 83 189 492 minecraft:basalt
fill 80 189 504 85 189 504 minecraft:quartz_block
fill 81 189 471 83 190 471 minecraft:basalt
fill 81 189 478 81 195 480 minecraft:basalt
setblock 81 189 481 minecraft:magma_block
fill 81 189 482 81 195 484 minecraft:basalt
fill 81 189 491 84 189 491 minecraft:basalt
fill 83 189 493 83 189 496 minecraft:black_concrete
setblock 84 189 471 minecraft:magma_block
fill 84 189 498 84 189 500 minecraft:quartz_block
setblock 84 189 503 minecraft:quartz_block
setblock 85 189 473 minecraft:basalt
fill 85 189 475 86 189 475 minecraft:basalt
fill 85 189 478 86 189 479 minecraft:basalt
fill 85 189 481 86 189 482 minecraft:basalt
fill 85 189 484 86 189 485 minecraft:basalt
fill 85 189 487 85 190 488 minecraft:basalt
fill 85 189 499 85 189 500 minecraft:quartz_block
fill 86 189 476 86 189 477 minecraft:basalt
fill 86 189 486 86 189 487 minecraft:basalt
setblock 86 189 500 minecraft:quartz_block
setblock 87 189 478 minecraft:basalt
setblock 87 189 479 minecraft:magma_block
setblock 87 189 481 minecraft:basalt
setblock 87 189 482 minecraft:magma_block
setblock 87 189 484 minecraft:basalt
fill 88 189 481 88 230 482 minecraft:quartz_block
fill 54 190 477 54 190 485 minecraft:basalt
fill 55 190 474 57 190 474 minecraft:basalt
fill 55 190 476 55 190 477 minecraft:basalt
fill 55 190 479 55 191 480 minecraft:basalt
fill 55 190 482 55 191 483 minecraft:basalt
fill 55 190 488 56 190 488 minecraft:basalt
setblock 56 190 473 minecraft:magma_block
setblock 56 190 489 minecraft:basalt
fill 57 190 471 57 190 473 minecraft:basalt
fill 57 190 490 57 190 491 minecraft:basalt
schedule function dropper:buildpart/109_2 1t
