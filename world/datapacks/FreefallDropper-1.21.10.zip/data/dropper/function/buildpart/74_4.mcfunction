fill 95 147 341 95 147 342 minecraft:stone
setblock 95 147 343 minecraft:stripped_spruce_log
fill 95 147 351 95 147 352 minecraft:stone
setblock 95 147 353 minecraft:stripped_spruce_log
fill 95 147 354 95 147 357 minecraft:stone
setblock 95 147 358 minecraft:stripped_spruce_log
fill 95 147 359 95 150 359 minecraft:stone
setblock 95 147 363 minecraft:stripped_spruce_log
setblock 96 147 337 minecraft:stripped_spruce_log
fill 96 147 338 96 150 338 minecraft:stone
fill 96 147 340 96 148 340 minecraft:stone
fill 96 147 354 96 147 356 minecraft:stone
setblock 96 147 357 minecraft:stripped_spruce_log
fill 96 147 358 96 150 358 minecraft:stone
setblock 96 147 361 minecraft:stone
fill 96 147 363 99 147 363 minecraft:stone
fill 98 147 362 100 147 362 minecraft:stone
setblock 100 147 363 minecraft:stripped_spruce_log
setblock 101 147 362 minecraft:stripped_spruce_log
fill 101 147 363 101 150 363 minecraft:stone
fill 102 147 362 102 150 362 minecraft:stone
fill 104 147 358 104 160 358 minecraft:iron_bars
setblock 105 147 363 minecraft:stripped_spruce_log
fill 109 147 322 109 170 322 minecraft:deepslate
fill 110 147 353 110 148 359 minecraft:stripped_spruce_log
fill 111 147 357 111 148 363 minecraft:stripped_spruce_log
fill 115 147 364 115 172 364 minecraft:deepslate
fill 116 147 323 119 147 323 minecraft:stone
fill 117 147 322 117 170 322 minecraft:deepslate
fill 117 147 363 119 147 363 minecraft:stone
fill 118 147 362 120 147 362 minecraft:stone
setblock 119 147 324 minecraft:stripped_spruce_log
setblock 120 147 323 minecraft:stripped_spruce_log
fill 120 147 324 123 147 324 minecraft:stone
setblock 120 147 363 minecraft:stripped_spruce_log
fill 121 147 323 124 147 323 minecraft:stone
setblock 121 147 361 minecraft:stone
setblock 121 147 362 minecraft:stripped_spruce_log
fill 121 147 363 124 147 363 minecraft:stone
setblock 122 147 361 minecraft:stripped_spruce_log
fill 122 147 362 125 147 362 minecraft:stone
fill 123 147 341 123 148 343 minecraft:cobbled_deepslate
fill 123 147 361 123 150 361 minecraft:stone
setblock 124 147 324 minecraft:stripped_spruce_log
fill 124 147 340 124 148 340 minecraft:cobbled_deepslate
fill 124 147 344 126 148 344 minecraft:cobbled_deepslate
setblock 125 147 323 minecraft:stripped_spruce_log
fill 125 147 361 125 148 361 minecraft:stone
setblock 125 147 363 minecraft:stripped_spruce_log
fill 126 147 323 126 150 323 minecraft:stone
fill 126 147 340 127 148 340 minecraft:cobbled_deepslate
setblock 126 147 362 minecraft:stripped_spruce_log
fill 126 147 363 129 147 363 minecraft:stone
fill 127 147 341 127 148 341 minecraft:cobbled_deepslate
fill 127 147 343 127 148 343 minecraft:cobbled_deepslate
fill 127 147 362 127 150 362 minecraft:stone
fill 128 147 323 128 148 323 minecraft:stone
fill 129 147 362 129 148 362 minecraft:stone
setblock 130 147 363 minecraft:stripped_spruce_log
fill 131 147 363 134 147 363 minecraft:stone
fill 134 147 356 134 147 358 minecraft:stone
setblock 134 147 359 minecraft:stripped_spruce_log
fill 134 147 360 134 148 362 minecraft:stone
setblock 135 147 353 minecraft:stripped_spruce_log
fill 135 147 354 135 147 357 minecraft:stone
setblock 135 147 358 minecraft:stripped_spruce_log
fill 135 147 359 135 150 359 minecraft:stone
setblock 135 147 363 minecraft:stripped_spruce_log
fill 94 148 344 94 154 346 minecraft:deepslate
setblock 94 148 347 minecraft:raw_iron_block
fill 95 148 334 95 148 336 minecraft:stone
setblock 95 148 337 minecraft:stripped_spruce_log
fill 95 148 338 95 151 338 minecraft:stone
setblock 95 148 341 minecraft:stone
setblock 95 148 342 minecraft:stripped_spruce_log
fill 95 148 343 95 148 346 minecraft:stone
setblock 95 148 347 minecraft:stripped_spruce_log
fill 95 148 348 95 148 351 minecraft:stone
setblock 95 148 352 minecraft:stripped_spruce_log
fill 95 148 353 95 148 356 minecraft:stone
setblock 95 148 357 minecraft:stripped_spruce_log
fill 95 148 358 95 151 358 minecraft:stone
fill 95 148 360 95 148 361 minecraft:stone
setblock 95 148 362 minecraft:stripped_spruce_log
fill 95 148 363 98 148 363 minecraft:stone
setblock 96 148 336 minecraft:stripped_spruce_log
fill 96 148 337 96 151 337 minecraft:stone
setblock 96 148 341 minecraft:stripped_spruce_log
fill 96 148 342 96 149 344 minecraft:stone
fill 96 148 353 96 148 355 minecraft:stone
setblock 96 148 356 minecraft:stripped_spruce_log
fill 96 148 357 97 150 357 minecraft:stone
setblock 96 148 361 minecraft:stripped_spruce_log
fill 96 148 362 99 148 362 minecraft:stone
fill 97 148 338 97 148 339 minecraft:stone
setblock 97 148 340 minecraft:stripped_spruce_log
fill 97 148 341 97 151 341 minecraft:stone
fill 97 148 358 97 148 359 minecraft:stone
setblock 99 148 363 minecraft:stripped_spruce_log
setblock 100 148 362 minecraft:stripped_spruce_log
fill 100 148 363 100 151 363 minecraft:stone
fill 101 148 323 102 149 323 minecraft:stone
fill 101 148 362 101 151 362 minecraft:stone
fill 102 148 363 103 148 363 minecraft:stone
fill 103 148 362 103 149 362 minecraft:stone
setblock 104 148 363 minecraft:stripped_spruce_log
fill 105 148 363 105 151 363 minecraft:stone
fill 108 148 334 108 148 344 minecraft:stripped_spruce_log
fill 109 148 339 109 148 353 minecraft:stripped_spruce_log
setblock 110 148 346 minecraft:stripped_spruce_log
fill 110 148 348 110 149 352 minecraft:stripped_spruce_log
fill 110 148 360 110 148 361 minecraft:stripped_spruce_log
fill 111 148 354 111 148 356 minecraft:stripped_spruce_log
fill 115 148 323 118 148 323 minecraft:stone
fill 115 148 363 118 148 363 minecraft:stone
fill 117 148 362 119 148 362 minecraft:stone
setblock 118 148 324 minecraft:stripped_spruce_log
setblock 119 148 323 minecraft:stripped_spruce_log
fill 119 148 324 122 148 324 minecraft:stone
fill 119 148 361 120 148 361 minecraft:stone
setblock 119 148 363 minecraft:stripped_spruce_log
fill 120 148 323 123 148 323 minecraft:stone
setblock 120 148 362 minecraft:stripped_spruce_log
fill 120 148 363 123 148 363 minecraft:stone
setblock 121 148 361 minecraft:stripped_spruce_log
fill 121 148 362 124 148 362 minecraft:stone
setblock 122 148 342 minecraft:cobbled_deepslate
fill 122 148 361 122 151 361 minecraft:stone
setblock 123 148 324 minecraft:stripped_spruce_log
setblock 123 148 340 minecraft:cobbled_deepslate
setblock 123 148 344 minecraft:cobbled_deepslate
setblock 124 148 323 minecraft:stripped_spruce_log
fill 124 148 324 125 150 324 minecraft:stone
fill 124 148 339 127 148 339 minecraft:cobbled_deepslate
setblock 124 148 363 minecraft:stripped_spruce_log
fill 125 148 323 125 151 323 minecraft:stone
fill 125 148 345 126 148 345 minecraft:cobbled_deepslate
setblock 125 148 362 minecraft:stripped_spruce_log
fill 125 148 363 128 148 363 minecraft:stone
setblock 126 148 361 minecraft:stripped_spruce_log
fill 126 148 362 126 151 362 minecraft:stone
setblock 127 148 344 minecraft:cobbled_deepslate
fill 128 148 340 128 148 343 minecraft:cobbled_deepslate
fill 129 148 325 129 158 325 minecraft:stripped_spruce_log
setblock 129 148 363 minecraft:stripped_spruce_log
setblock 130 148 362 minecraft:stripped_spruce_log
fill 130 148 363 133 148 363 minecraft:stone
fill 131 148 362 133 149 362 minecraft:stone
setblock 134 148 322 minecraft:raw_iron_block
fill 134 148 356 134 148 357 minecraft:stone
setblock 134 148 358 minecraft:stripped_spruce_log
fill 134 148 359 134 151 359 minecraft:stone
setblock 134 148 363 minecraft:stripped_spruce_log
fill 135 148 338 135 149 340 minecraft:stone
setblock 135 148 352 minecraft:stripped_spruce_log
fill 135 148 353 135 148 356 minecraft:stone
setblock 135 148 357 minecraft:stripped_spruce_log
fill 135 148 358 135 151 358 minecraft:stone
fill 135 148 360 135 148 361 minecraft:stone
setblock 135 148 362 minecraft:stripped_spruce_log
fill 135 148 363 135 151 363 minecraft:stone
fill 94 149 347 94 174 347 minecraft:deepslate
fill 95 149 334 95 149 335 minecraft:stone
setblock 95 149 336 minecraft:stripped_spruce_log
fill 95 149 337 95 152 337 minecraft:stone
setblock 95 149 341 minecraft:stripped_spruce_log
fill 95 149 342 95 149 345 minecraft:stone
setblock 95 149 346 minecraft:stripped_spruce_log
fill 95 149 347 95 149 350 minecraft:stone
setblock 95 149 351 minecraft:stripped_spruce_log
fill 95 149 352 95 149 355 minecraft:stone
setblock 95 149 356 minecraft:stripped_spruce_log
fill 95 149 357 95 152 357 minecraft:stone
setblock 95 149 360 minecraft:stone
setblock 95 149 361 minecraft:stripped_spruce_log
fill 95 149 362 97 149 363 minecraft:stone
setblock 96 149 335 minecraft:stripped_spruce_log
fill 96 149 336 97 151 336 minecraft:stone
setblock 96 149 340 minecraft:stripped_spruce_log
fill 96 149 341 96 152 341 minecraft:stone
setblock 96 149 345 minecraft:stripped_spruce_log
fill 96 149 346 96 151 347 minecraft:stone
fill 96 149 352 96 149 354 minecraft:stone
setblock 96 149 355 minecraft:stripped_spruce_log
fill 96 149 356 97 151 356 minecraft:stone
setblock 96 149 359 minecraft:stone
setblock 96 149 360 minecraft:stripped_spruce_log
fill 96 149 361 99 149 361 minecraft:stone
fill 97 149 337 97 149 338 minecraft:stone
setblock 97 149 339 minecraft:stripped_spruce_log
fill 97 149 340 98 151 340 minecraft:stone
fill 97 149 342 97 149 343 minecraft:stone
setblock 97 149 344 minecraft:stripped_spruce_log
setblock 97 149 358 minecraft:stone
setblock 97 149 359 minecraft:stripped_spruce_log
fill 97 149 360 97 152 360 minecraft:stone
setblock 98 149 323 minecraft:stripped_spruce_log
setblock 98 149 338 minecraft:stripped_spruce_log
fill 98 149 339 98 152 339 minecraft:stone
fill 98 149 341 98 150 341 minecraft:stone
setblock 98 149 362 minecraft:stone
setblock 98 149 363 minecraft:stripped_spruce_log
fill 99 149 323 100 151 323 minecraft:stone
setblock 99 149 362 minecraft:stripped_spruce_log
fill 99 149 363 99 152 363 minecraft:stone
setblock 100 149 361 minecraft:stripped_spruce_log
fill 100 149 362 100 152 362 minecraft:stone
fill 101 149 361 101 152 361 minecraft:stone
setblock 102 149 363 minecraft:stone
setblock 103 149 323 minecraft:stripped_spruce_log
setblock 103 149 363 minecraft:stripped_spruce_log
fill 104 149 323 104 152 323 minecraft:stone
setblock 104 149 362 minecraft:stripped_spruce_log
fill 104 149 363 104 152 363 minecraft:stone
fill 106 149 323 107 149 327 minecraft:stripped_spruce_log
fill 106 149 363 106 150 363 minecraft:stone
fill 107 149 328 107 149 336 minecraft:stripped_spruce_log
fill 108 149 329 108 149 343 minecraft:stripped_spruce_log
fill 108 149 348 109 204 349 minecraft:stripped_spruce_log
fill 109 149 337 109 149 347 minecraft:stripped_spruce_log
fill 109 149 350 109 204 350 minecraft:stripped_spruce_log
fill 110 149 353 110 149 357 minecraft:stripped_dark_oak_log
fill 111 149 347 111 204 349 minecraft:stripped_spruce_log
fill 111 149 358 111 149 363 minecraft:stripped_dark_oak_log
setblock 113 149 323 minecraft:stripped_spruce_log
fill 114 149 323 117 149 323 minecraft:stone
fill 114 149 363 117 149 363 minecraft:stone
setblock 116 149 324 minecraft:stone
fill 116 149 362 118 149 362 minecraft:stone
setblock 117 149 324 minecraft:stripped_spruce_log
setblock 118 149 323 minecraft:stripped_spruce_log
fill 118 149 324 121 149 324 minecraft:stone
fill 118 149 361 119 149 361 minecraft:stone
setblock 118 149 363 minecraft:stripped_spruce_log
fill 119 149 323 122 149 323 minecraft:stone
setblock 119 149 362 minecraft:stripped_spruce_log
fill 119 149 363 122 149 363 minecraft:stone
setblock 120 149 325 minecraft:stone
setblock 120 149 361 minecraft:stripped_spruce_log
fill 120 149 362 123 149 362 minecraft:stone
setblock 121 149 325 minecraft:stripped_spruce_log
fill 121 149 361 121 152 361 minecraft:stone
setblock 122 149 324 minecraft:stripped_spruce_log
setblock 123 149 323 minecraft:stripped_spruce_log
fill 123 149 324 123 152 324 minecraft:stone
setblock 123 149 363 minecraft:stripped_spruce_log
fill 124 149 323 124 152 323 minecraft:stone
setblock 124 149 362 minecraft:stripped_spruce_log
fill 124 149 363 127 149 363 minecraft:stone
setblock 125 149 361 minecraft:stripped_spruce_log
fill 125 149 362 125 152 362 minecraft:stone
fill 126 149 361 127 151 361 minecraft:stone
setblock 128 149 323 minecraft:stripped_spruce_log
setblock 128 149 363 minecraft:stripped_spruce_log
fill 129 149 323 129 152 323 minecraft:stone
setblock 129 149 362 minecraft:stripped_spruce_log
fill 129 149 363 132 149 363 minecraft:stone
fill 130 149 362 130 152 362 minecraft:stone
setblock 133 149 363 minecraft:stripped_spruce_log
fill 134 149 322 134 160 322 minecraft:deepslate
fill 134 149 355 134 149 356 minecraft:stone
setblock 134 149 357 minecraft:stripped_spruce_log
fill 134 149 358 134 152 358 minecraft:stone
fill 134 149 360 134 149 361 minecraft:stone
setblock 134 149 362 minecraft:stripped_spruce_log
fill 134 149 363 134 152 363 minecraft:stone
setblock 135 149 336 minecraft:stripped_spruce_log
fill 135 149 337 135 152 337 minecraft:stone
setblock 135 149 341 minecraft:stripped_spruce_log
fill 135 149 342 135 150 344 minecraft:stone
setblock 135 149 351 minecraft:stripped_spruce_log
fill 135 149 352 135 149 355 minecraft:stone
setblock 135 149 356 minecraft:stripped_spruce_log
fill 135 149 357 135 152 357 minecraft:stone
setblock 135 149 360 minecraft:stone
setblock 135 149 361 minecraft:stripped_spruce_log
fill 135 149 362 135 152 362 minecraft:stone
setblock 136 149 333 minecraft:diamond_block
fill 136 149 334 136 151 335 minecraft:deepslate
setblock 136 149 336 minecraft:raw_iron_block
fill 95 150 333 95 150 334 minecraft:stone
setblock 95 150 335 minecraft:stripped_spruce_log
fill 95 150 336 95 153 336 minecraft:stone
setblock 95 150 339 minecraft:stone
setblock 95 150 340 minecraft:stripped_spruce_log
fill 95 150 341 95 150 344 minecraft:stone
setblock 95 150 345 minecraft:stripped_spruce_log
fill 95 150 346 95 150 349 minecraft:stone
setblock 95 150 350 minecraft:stripped_spruce_log
fill 95 150 351 95 150 354 minecraft:stone
setblock 95 150 355 minecraft:stripped_spruce_log
fill 95 150 356 95 153 356 minecraft:stone
setblock 95 150 360 minecraft:stripped_spruce_log
fill 95 150 361 96 150 363 minecraft:stone
setblock 96 150 323 minecraft:stone
setblock 96 150 334 minecraft:stripped_spruce_log
fill 96 150 335 96 153 335 minecraft:stone
setblock 96 150 339 minecraft:stripped_spruce_log
fill 96 150 340 96 153 340 minecraft:stone
fill 96 150 342 96 150 343 minecraft:stone
setblock 96 150 344 minecraft:stripped_spruce_log
fill 96 150 345 97 152 345 minecraft:stone
setblock 96 150 348 minecraft:stone
setblock 96 150 349 minecraft:stripped_spruce_log
fill 96 150 350 96 150 353 minecraft:stone
fill 96 150 354 107 150 354 minecraft:stripped_spruce_log
fill 96 150 355 96 153 355 minecraft:stone
setblock 96 150 359 minecraft:stripped_spruce_log
fill 96 150 360 96 153 360 minecraft:stone
setblock 97 150 323 minecraft:stripped_spruce_log
setblock 97 150 325 minecraft:light[level=12]
setblock 97 150 332 minecraft:light[level=12]
setblock 97 150 337 minecraft:stone
setblock 97 150 338 minecraft:stripped_spruce_log
fill 97 150 339 97 153 339 minecraft:stone
setblock 97 150 342 minecraft:stone
setblock 97 150 343 minecraft:stripped_spruce_log
fill 97 150 344 98 152 344 minecraft:stone
fill 97 150 346 97 150 347 minecraft:stone
setblock 97 150 353 minecraft:light[level=12]
fill 97 150 355 100 151 355 minecraft:stripped_spruce_log
setblock 97 150 358 minecraft:stripped_spruce_log
fill 97 150 359 97 153 359 minecraft:stone
fill 97 150 361 97 150 362 minecraft:stone
setblock 97 150 363 minecraft:stripped_spruce_log
fill 98 150 323 98 153 323 minecraft:stone
setblock 98 150 337 minecraft:stripped_spruce_log
fill 98 150 338 98 153 338 minecraft:stone
setblock 98 150 342 minecraft:stripped_spruce_log
fill 98 150 343 98 153 343 minecraft:stone
setblock 98 150 361 minecraft:stone
setblock 98 150 362 minecraft:stripped_spruce_log
fill 98 150 363 98 153 363 minecraft:stone
setblock 99 150 361 minecraft:stripped_spruce_log
fill 99 150 362 99 153 362 minecraft:stone
fill 100 150 361 100 153 361 minecraft:stone
setblock 101 150 323 minecraft:stone
setblock 102 150 323 minecraft:stripped_spruce_log
setblock 102 150 363 minecraft:stripped_spruce_log
fill 103 150 323 103 153 323 minecraft:stone
setblock 103 150 362 minecraft:stripped_spruce_log
fill 103 150 363 103 153 363 minecraft:stone
setblock 104 150 325 minecraft:light[level=12]
setblock 104 150 332 minecraft:light[level=12]
setblock 104 150 339 minecraft:light[level=12]
setblock 104 150 346 minecraft:light[level=12]
setblock 104 150 353 minecraft:light[level=12]
setblock 104 150 360 minecraft:light[level=12]
fill 104 150 362 104 152 362 minecraft:stone
fill 105 150 323 106 150 323 minecraft:stone
fill 106 150 324 107 150 325 minecraft:stripped_spruce_log
fill 106 150 353 112 151 353 minecraft:stripped_spruce_log
setblock 107 150 323 minecraft:stripped_spruce_log
fill 107 150 326 107 150 331 minecraft:stripped_spruce_log
fill 107 150 348 107 151 349 minecraft:cobbled_deepslate
setblock 107 150 363 minecraft:stripped_spruce_log
fill 108 150 334 108 150 341 minecraft:stripped_dark_oak_log
fill 108 150 347 108 151 347 minecraft:cobbled_deepslate
fill 108 150 350 108 151 350 minecraft:cobbled_deepslate
fill 109 150 341 109 150 345 minecraft:stripped_dark_oak_log
fill 109 150 346 111 151 346 minecraft:cobbled_deepslate
fill 109 150 347 110 204 347 minecraft:stripped_spruce_log
fill 109 150 351 110 151 351 minecraft:cobbled_deepslate
fill 110 150 348 110 204 350 minecraft:stripped_spruce_log
setblock 111 150 323 minecraft:stone
setblock 111 150 325 minecraft:light[level=12]
setblock 111 150 332 minecraft:light[level=12]
setblock 111 150 339 minecraft:light[level=12]
fill 111 150 350 112 151 350 minecraft:cobbled_deepslate
setblock 111 150 360 minecraft:light[level=12]
setblock 112 150 323 minecraft:stripped_spruce_log
fill 112 150 347 112 151 349 minecraft:cobbled_deepslate
setblock 112 150 363 minecraft:stripped_spruce_log
fill 113 150 323 116 150 323 minecraft:stone
fill 113 150 363 116 150 363 minecraft:stone
fill 114 150 324 115 150 324 minecraft:stone
fill 114 150 362 117 150 362 minecraft:stone
setblock 116 150 324 minecraft:stripped_spruce_log
setblock 117 150 323 minecraft:stripped_spruce_log
fill 117 150 324 120 150 324 minecraft:stone
fill 117 150 361 118 150 361 minecraft:stone
setblock 117 150 363 minecraft:stripped_spruce_log
fill 118 150 323 121 150 323 minecraft:stone
fill 118 150 325 119 150 325 minecraft:stone
setblock 118 150 332 minecraft:light[level=12]
setblock 118 150 339 minecraft:light[level=12]
setblock 118 150 346 minecraft:light[level=12]
setblock 118 150 353 minecraft:light[level=12]
setblock 118 150 360 minecraft:light[level=12]
setblock 118 150 362 minecraft:stripped_spruce_log
fill 118 150 363 121 150 363 minecraft:stone
setblock 119 150 361 minecraft:stripped_spruce_log
fill 119 150 362 122 150 362 minecraft:stone
setblock 120 150 325 minecraft:stripped_spruce_log
setblock 120 150 360 minecraft:stripped_spruce_log
fill 120 150 361 120 153 361 minecraft:stone
setblock 121 150 324 minecraft:stripped_spruce_log
fill 121 150 325 122 152 325 minecraft:stone
fill 121 150 360 122 152 360 minecraft:stone
setblock 122 150 323 minecraft:stripped_spruce_log
fill 122 150 324 122 153 324 minecraft:stone
setblock 122 150 363 minecraft:stripped_spruce_log
fill 123 150 323 123 153 323 minecraft:stone
setblock 123 150 362 minecraft:stripped_spruce_log
fill 123 150 363 126 150 363 minecraft:stone
setblock 124 150 361 minecraft:stripped_spruce_log
fill 124 150 362 124 153 362 minecraft:stone
setblock 125 150 325 minecraft:light[level=12]
setblock 125 150 332 minecraft:light[level=12]
setblock 125 150 339 minecraft:light[level=12]
setblock 125 150 346 minecraft:light[level=12]
setblock 125 150 353 minecraft:light[level=12]
setblock 125 150 360 minecraft:light[level=12]
fill 125 150 361 125 153 361 minecraft:stone
setblock 126 150 324 minecraft:stripped_spruce_log
setblock 127 150 323 minecraft:stripped_spruce_log
setblock 127 150 363 minecraft:stripped_spruce_log
fill 128 150 323 128 153 323 minecraft:stone
setblock 128 150 361 minecraft:stone
setblock 128 150 362 minecraft:stripped_spruce_log
fill 128 150 363 131 150 363 minecraft:stone
fill 129 150 362 129 153 362 minecraft:stone
fill 130 150 323 131 150 323 minecraft:stone
fill 131 150 362 132 150 362 minecraft:stone
setblock 132 150 323 minecraft:stripped_spruce_log
setblock 132 150 325 minecraft:light[level=12]
setblock 132 150 332 minecraft:light[level=12]
setblock 132 150 339 minecraft:light[level=12]
setblock 132 150 346 minecraft:light[level=12]
setblock 132 150 353 minecraft:light[level=12]
setblock 132 150 360 minecraft:light[level=12]
fill 132 150 361 133 150 361 minecraft:stone
setblock 132 150 363 minecraft:stripped_spruce_log
fill 133 150 323 135 151 323 minecraft:stone
fill 133 150 359 133 151 360 minecraft:stone
setblock 133 150 362 minecraft:stripped_spruce_log
fill 133 150 363 133 153 363 minecraft:stone
setblock 134 150 355 minecraft:stone
setblock 134 150 356 minecraft:stripped_spruce_log
fill 134 150 357 134 153 357 minecraft:stone
setblock 134 150 360 minecraft:stone
setblock 134 150 361 minecraft:stripped_spruce_log
fill 134 150 362 134 153 362 minecraft:stone
setblock 135 150 324 minecraft:stone
setblock 135 150 335 minecraft:stripped_spruce_log
fill 135 150 336 135 153 336 minecraft:stone
fill 135 150 338 135 150 339 minecraft:stone
setblock 135 150 340 minecraft:stripped_spruce_log
fill 135 150 341 135 153 341 minecraft:stone
setblock 135 150 345 minecraft:stripped_spruce_log
fill 135 150 346 135 150 349 minecraft:stone
setblock 135 150 350 minecraft:stripped_spruce_log
fill 135 150 351 135 150 354 minecraft:stone
setblock 135 150 355 minecraft:stripped_spruce_log
fill 135 150 356 135 153 356 minecraft:stone
setblock 135 150 360 minecraft:stripped_spruce_log
fill 135 150 361 135 153 361 minecraft:stone
fill 136 150 333 136 172 333 minecraft:deepslate
fill 136 150 336 136 174 336 minecraft:deepslate
setblock 95 151 323 minecraft:stone
setblock 95 151 324 minecraft:stripped_spruce_log
fill 95 151 332 95 151 333 minecraft:stone
setblock 95 151 334 minecraft:stripped_spruce_log
fill 95 151 335 95 154 335 minecraft:stone
setblock 95 151 339 minecraft:stripped_spruce_log
fill 95 151 340 95 151 343 minecraft:stone
setblock 95 151 344 minecraft:stripped_spruce_log
fill 95 151 345 95 151 348 minecraft:stone
setblock 95 151 349 minecraft:stripped_spruce_log
fill 95 151 350 95 151 353 minecraft:stone
setblock 95 151 354 minecraft:stripped_spruce_log
fill 95 151 355 95 154 355 minecraft:stone
setblock 95 151 359 minecraft:stripped_spruce_log
fill 95 151 360 95 151 363 minecraft:stone
setblock 96 151 323 minecraft:stripped_spruce_log
fill 96 151 334 96 154 334 minecraft:stone
setblock 96 151 338 minecraft:stripped_spruce_log
fill 96 151 339 96 154 339 minecraft:stone
setblock 96 151 342 minecraft:stone
setblock 96 151 343 minecraft:stripped_spruce_log
fill 96 151 344 96 154 344 minecraft:stone
setblock 96 151 348 minecraft:stripped_spruce_log
fill 96 151 349 96 151 352 minecraft:stone
setblock 96 151 353 minecraft:stripped_spruce_log
fill 96 151 354 96 154 354 minecraft:stone
setblock 96 151 357 minecraft:stone
setblock 96 151 358 minecraft:stripped_spruce_log
fill 96 151 359 96 154 359 minecraft:stone
fill 96 151 361 96 151 362 minecraft:stone
setblock 96 151 363 minecraft:stripped_spruce_log
fill 97 151 323 97 154 323 minecraft:stone
fill 97 151 335 97 152 335 minecraft:stone
setblock 97 151 337 minecraft:stripped_spruce_log
fill 97 151 338 97 154 338 minecraft:stone
setblock 97 151 342 minecraft:stripped_spruce_log
fill 97 151 343 97 154 343 minecraft:stone
setblock 97 151 346 minecraft:stone
setblock 97 151 347 minecraft:stripped_spruce_log
fill 97 151 348 97 154 348 minecraft:stone
fill 97 151 354 110 151 354 minecraft:stripped_spruce_log
setblock 97 151 357 minecraft:stripped_spruce_log
fill 97 151 358 97 153 358 minecraft:stone
setblock 97 151 361 minecraft:stone
setblock 97 151 362 minecraft:stripped_spruce_log
fill 97 151 363 97 154 363 minecraft:stone
fill 98 151 337 98 153 337 minecraft:stone
setblock 98 151 341 minecraft:stripped_spruce_log
fill 98 151 342 99 153 342 minecraft:stone
setblock 98 151 345 minecraft:stone
setblock 98 151 361 minecraft:stripped_spruce_log
fill 98 151 362 98 154 362 minecraft:stone
setblock 99 151 324 minecraft:stone
setblock 99 151 339 minecraft:stone
setblock 99 151 340 minecraft:stripped_spruce_log
fill 99 151 341 99 154 341 minecraft:stone
fill 99 151 361 99 153 361 minecraft:stone
setblock 100 151 324 minecraft:stripped_spruce_log
setblock 101 151 323 minecraft:stripped_spruce_log
fill 101 151 324 102 153 324 minecraft:stone
fill 101 151 355 102 151 355 minecraft:stripped_spruce_log
setblock 101 151 363 minecraft:stripped_spruce_log
fill 102 151 323 102 154 323 minecraft:stone
setblock 102 151 362 minecraft:stripped_spruce_log
fill 102 151 363 102 154 363 minecraft:stone
fill 103 151 362 103 153 362 minecraft:stone
fill 104 151 353 105 151 353 minecraft:stripped_spruce_log
setblock 105 151 323 minecraft:stone
setblock 106 151 323 minecraft:stripped_spruce_log
fill 106 151 324 107 151 324 minecraft:stripped_dark_oak_log
fill 106 151 348 106 151 349 minecraft:cobbled_deepslate
setblock 106 151 363 minecraft:stripped_spruce_log
fill 107 151 323 110 151 323 minecraft:stone
fill 107 151 325 107 151 330 minecraft:stripped_dark_oak_log
fill 107 151 346 107 151 347 minecraft:cobbled_deepslate
fill 107 151 350 107 151 351 minecraft:cobbled_deepslate
fill 107 151 363 110 151 363 minecraft:stone
setblock 108 151 346 minecraft:cobbled_deepslate
setblock 108 151 351 minecraft:cobbled_deepslate
fill 109 151 345 111 151 345 minecraft:cobbled_deepslate
fill 109 151 352 110 151 352 minecraft:cobbled_deepslate
setblock 111 151 323 minecraft:stripped_spruce_log
fill 111 151 351 112 151 351 minecraft:cobbled_deepslate
fill 111 151 352 126 151 352 minecraft:stripped_spruce_log
setblock 111 151 363 minecraft:stripped_spruce_log
fill 112 151 323 115 151 323 minecraft:stone
setblock 112 151 346 minecraft:cobbled_deepslate
fill 112 151 363 115 151 363 minecraft:stone
fill 113 151 324 114 151 324 minecraft:stone
fill 113 151 347 113 151 350 minecraft:cobbled_deepslate
fill 113 151 353 118 151 353 minecraft:stripped_spruce_log
fill 113 151 362 116 151 362 minecraft:stone
setblock 115 151 324 minecraft:stripped_spruce_log
setblock 116 151 323 minecraft:stripped_spruce_log
fill 116 151 324 118 151 325 minecraft:stone
fill 116 151 361 117 151 361 minecraft:stone
setblock 116 151 363 minecraft:stripped_spruce_log
fill 117 151 323 120 151 323 minecraft:stone
setblock 117 151 362 minecraft:stripped_spruce_log
fill 117 151 363 120 151 363 minecraft:stone
setblock 118 151 361 minecraft:stripped_spruce_log
fill 118 151 362 121 151 362 minecraft:stone
setblock 119 151 324 minecraft:stone
setblock 119 151 325 minecraft:stripped_spruce_log
fill 119 151 351 133 151 351 minecraft:stripped_spruce_log
setblock 119 151 360 minecraft:stripped_spruce_log
fill 119 151 361 119 154 361 minecraft:stone
setblock 120 151 324 minecraft:stripped_spruce_log
fill 120 151 325 120 154 325 minecraft:stone
fill 120 151 360 120 153 360 minecraft:stone
setblock 121 151 323 minecraft:stripped_spruce_log
fill 121 151 324 121 154 324 minecraft:stone
setblock 121 151 363 minecraft:stripped_spruce_log
fill 122 151 323 122 154 323 minecraft:stone
setblock 122 151 362 minecraft:stripped_spruce_log
fill 122 151 363 125 151 363 minecraft:stone
setblock 123 151 325 minecraft:stone
setblock 123 151 360 minecraft:stone
setblock 123 151 361 minecraft:stripped_spruce_log
fill 123 151 362 123 154 362 minecraft:stone
setblock 124 151 324 minecraft:stone
fill 124 151 361 124 154 361 minecraft:stone
setblock 125 151 324 minecraft:stripped_spruce_log
setblock 126 151 323 minecraft:stripped_spruce_log
fill 126 151 324 126 154 324 minecraft:stone
setblock 126 151 363 minecraft:stripped_spruce_log
fill 127 151 323 127 154 323 minecraft:stone
fill 127 151 350 134 151 350 minecraft:stripped_spruce_log
setblock 127 151 362 minecraft:stripped_spruce_log
fill 127 151 363 130 151 363 minecraft:stone
setblock 128 151 361 minecraft:stripped_spruce_log
fill 128 151 362 128 154 362 minecraft:stone
fill 129 151 361 132 151 361 minecraft:stone
setblock 130 151 323 minecraft:stone
setblock 131 151 323 minecraft:stripped_spruce_log
setblock 131 151 362 minecraft:stone
setblock 131 151 363 minecraft:stripped_spruce_log
fill 132 151 323 132 154 323 minecraft:stone
setblock 132 151 362 minecraft:stripped_spruce_log
fill 132 151 363 132 154 363 minecraft:stone
fill 133 151 358 133 153 358 minecraft:stone
setblock 133 151 361 minecraft:stripped_spruce_log
fill 133 151 362 133 154 362 minecraft:stone
setblock 134 151 339 minecraft:stone
setblock 134 151 340 minecraft:stripped_spruce_log
fill 134 151 341 134 151 344 minecraft:stone
setblock 134 151 354 minecraft:stone
setblock 134 151 355 minecraft:stripped_spruce_log
fill 134 151 356 134 154 356 minecraft:stone
setblock 134 151 360 minecraft:stripped_spruce_log
fill 134 151 361 134 154 361 minecraft:stone
setblock 135 151 324 minecraft:stripped_spruce_log
fill 135 151 325 135 154 325 minecraft:stone
fill 135 151 335 135 154 335 minecraft:stone
setblock 135 151 338 minecraft:stone
setblock 135 151 339 minecraft:stripped_spruce_log
fill 135 151 340 135 154 340 minecraft:stone
fill 135 151 342 135 151 343 minecraft:stone
setblock 135 151 344 minecraft:stripped_spruce_log
fill 135 151 345 135 151 348 minecraft:stone
setblock 135 151 349 minecraft:stripped_spruce_log
fill 135 151 350 135 151 353 minecraft:stone
setblock 135 151 354 minecraft:stripped_spruce_log
fill 135 151 355 135 154 355 minecraft:stone
setblock 135 151 359 minecraft:stripped_spruce_log
fill 135 151 360 135 154 360 minecraft:stone
setblock 136 151 325 minecraft:gold_block
setblock 136 151 347 minecraft:raw_iron_block
setblock 95 152 323 minecraft:stripped_spruce_log
fill 95 152 324 95 153 326 minecraft:stone
setblock 95 152 332 minecraft:stone
setblock 95 152 333 minecraft:stripped_spruce_log
fill 95 152 334 95 155 334 minecraft:stone
setblock 95 152 338 minecraft:stripped_spruce_log
fill 95 152 339 95 152 342 minecraft:stone
setblock 95 152 343 minecraft:stripped_spruce_log
fill 95 152 344 95 152 347 minecraft:stone
setblock 95 152 348 minecraft:stripped_spruce_log
fill 95 152 349 95 152 352 minecraft:stone
setblock 95 152 353 minecraft:stripped_spruce_log
fill 95 152 354 95 155 354 minecraft:stone
setblock 95 152 358 minecraft:stripped_spruce_log
fill 95 152 359 95 152 362 minecraft:stone
setblock 95 152 363 minecraft:stripped_spruce_log
fill 96 152 323 96 155 323 minecraft:stone
setblock 96 152 336 minecraft:stone
setblock 96 152 337 minecraft:stripped_spruce_log
fill 96 152 338 96 155 338 minecraft:stone
setblock 96 152 342 minecraft:stripped_spruce_log
fill 96 152 343 96 154 343 minecraft:stone
setblock 96 152 346 minecraft:stone
setblock 96 152 347 minecraft:stripped_spruce_log
fill 96 152 348 96 152 351 minecraft:stone
setblock 96 152 352 minecraft:stripped_spruce_log
fill 96 152 353 96 155 353 minecraft:stone
setblock 96 152 356 minecraft:stone
setblock 96 152 357 minecraft:stripped_spruce_log
fill 96 152 358 96 155 358 minecraft:stone
setblock 96 152 361 minecraft:stone
setblock 96 152 362 minecraft:stripped_spruce_log
fill 96 152 363 96 155 363 minecraft:stone
fill 97 152 324 98 152 324 minecraft:stone
setblock 97 152 336 minecraft:stripped_spruce_log
fill 97 152 337 97 155 337 minecraft:stone
setblock 97 152 340 minecraft:stone
setblock 97 152 341 minecraft:stripped_spruce_log
fill 97 152 342 97 155 342 minecraft:stone
setblock 97 152 346 minecraft:stripped_spruce_log
fill 97 152 347 97 155 347 minecraft:stone
fill 97 152 349 97 152 350 minecraft:stone
fill 97 152 355 99 152 355 minecraft:stripped_dark_oak_log
setblock 97 152 356 minecraft:stripped_spruce_log
setblock 97 152 357 minecraft:stone
setblock 97 152 361 minecraft:stripped_spruce_log
fill 97 152 362 97 155 362 minecraft:stone
setblock 98 152 340 minecraft:stripped_spruce_log
fill 98 152 341 98 155 341 minecraft:stone
setblock 98 152 345 minecraft:stripped_spruce_log
fill 98 152 346 98 155 346 minecraft:stone
fill 98 152 361 98 154 361 minecraft:stone
setblock 99 152 323 minecraft:stone
setblock 99 152 324 minecraft:stripped_spruce_log
setblock 99 152 339 minecraft:stripped_spruce_log
fill 99 152 340 99 153 340 minecraft:stone
setblock 99 152 343 minecraft:stone
fill 99 152 354 106 152 354 minecraft:stripped_dark_oak_log
setblock 100 152 323 minecraft:stripped_spruce_log
fill 100 152 324 100 155 324 minecraft:stone
setblock 100 152 363 minecraft:stripped_spruce_log
fill 101 152 323 101 155 323 minecraft:stone
setblock 101 152 362 minecraft:stripped_spruce_log
fill 101 152 363 101 155 363 minecraft:stone
fill 102 152 362 102 154 362 minecraft:stone
setblock 103 152 324 minecraft:stone
setblock 105 152 323 minecraft:stripped_spruce_log
setblock 105 152 363 minecraft:stripped_spruce_log
fill 106 152 323 109 152 323 minecraft:stone
fill 106 152 363 109 152 363 minecraft:stone
fill 107 152 353 113 152 353 minecraft:stripped_dark_oak_log
setblock 110 152 323 minecraft:stripped_spruce_log
setblock 110 152 363 minecraft:stripped_spruce_log
fill 111 152 323 113 152 324 minecraft:stone
fill 111 152 363 114 152 363 minecraft:stone
fill 113 152 362 115 152 362 minecraft:stone
setblock 114 152 323 minecraft:stone
setblock 114 152 324 minecraft:stripped_spruce_log
fill 114 152 325 117 152 325 minecraft:stone
setblock 115 152 323 minecraft:stripped_spruce_log
fill 115 152 324 118 152 324 minecraft:stone
fill 115 152 361 116 152 361 minecraft:stone
setblock 115 152 363 minecraft:stripped_spruce_log
fill 116 152 323 119 152 323 minecraft:stone
setblock 116 152 352 minecraft:stripped_dark_oak_log
setblock 116 152 362 minecraft:stripped_spruce_log
fill 116 152 363 119 152 363 minecraft:stone
fill 117 152 352 123 152 352 minecraft:stripped_spruce_log
setblock 117 152 361 minecraft:stripped_spruce_log
fill 117 152 362 120 152 362 minecraft:stone
setblock 118 152 325 minecraft:stripped_spruce_log
fill 118 152 361 118 155 361 minecraft:stone
setblock 119 152 324 minecraft:stripped_spruce_log
fill 119 152 325 119 155 325 minecraft:stone
fill 119 152 360 119 153 360 minecraft:stone
setblock 120 152 323 minecraft:stripped_spruce_log
fill 120 152 324 120 155 324 minecraft:stone
setblock 120 152 363 minecraft:stripped_spruce_log
fill 121 152 323 121 155 323 minecraft:stone
setblock 121 152 362 minecraft:stripped_spruce_log
fill 121 152 363 124 152 363 minecraft:stone
fill 122 152 351 132 152 351 minecraft:stripped_spruce_log
setblock 122 152 361 minecraft:stripped_spruce_log
fill 122 152 362 122 155 362 minecraft:stone
setblock 123 152 325 minecraft:stripped_spruce_log
fill 123 152 361 123 155 361 minecraft:stone
setblock 124 152 324 minecraft:stripped_spruce_log
setblock 125 152 323 minecraft:stripped_spruce_log
fill 125 152 324 125 155 324 minecraft:stone
setblock 125 152 363 minecraft:stripped_spruce_log
fill 126 152 323 126 155 323 minecraft:stone
setblock 126 152 361 minecraft:stone
setblock 126 152 362 minecraft:stripped_spruce_log
fill 126 152 363 129 152 363 minecraft:stone
setblock 127 152 361 minecraft:stripped_spruce_log
fill 127 152 362 127 155 362 minecraft:stone
fill 128 152 361 131 152 361 minecraft:stone
fill 129 152 350 134 152 350 minecraft:stripped_spruce_log
setblock 130 152 323 minecraft:stripped_spruce_log
setblock 130 152 363 minecraft:stripped_spruce_log
fill 131 152 323 131 155 323 minecraft:stone
setblock 131 152 362 minecraft:stripped_spruce_log
fill 131 152 363 131 155 363 minecraft:stone
setblock 132 152 361 minecraft:stripped_spruce_log
fill 132 152 362 132 155 362 minecraft:stone
fill 133 152 323 134 152 323 minecraft:stone
setblock 133 152 359 minecraft:stone
setblock 133 152 360 minecraft:stripped_spruce_log
fill 133 152 361 133 155 361 minecraft:stone
setblock 134 152 338 minecraft:stone
setblock 134 152 339 minecraft:stripped_spruce_log
fill 134 152 340 134 152 343 minecraft:stone
setblock 134 152 344 minecraft:stripped_spruce_log
fill 134 152 345 135 152 347 minecraft:stone
setblock 134 152 353 minecraft:stone
setblock 134 152 354 minecraft:stripped_spruce_log
fill 134 152 355 134 155 355 minecraft:stone
setblock 134 152 359 minecraft:stripped_spruce_log
fill 134 152 360 134 155 360 minecraft:stone
setblock 135 152 323 minecraft:stripped_spruce_log
fill 135 152 324 135 155 324 minecraft:stone
fill 135 152 326 135 153 326 minecraft:stone
setblock 135 152 338 minecraft:stripped_spruce_log
fill 135 152 339 135 155 339 minecraft:stone
setblock 135 152 342 minecraft:stone
setblock 135 152 343 minecraft:stripped_spruce_log
fill 135 152 344 135 155 344 minecraft:stone
setblock 135 152 348 minecraft:stripped_spruce_log
fill 135 152 349 135 152 352 minecraft:stone
setblock 135 152 353 minecraft:stripped_spruce_log
fill 135 152 354 135 155 354 minecraft:stone
setblock 135 152 358 minecraft:stripped_spruce_log
fill 135 152 359 135 155 359 minecraft:stone
setblock 135 152 363 minecraft:stripped_spruce_log
fill 136 152 325 136 170 325 minecraft:deepslate
setblock 136 152 334 minecraft:diamond_block
fill 136 152 335 136 174 335 minecraft:deepslate
fill 136 152 347 136 174 347 minecraft:deepslate
setblock 94 153 354 minecraft:raw_iron_block
fill 95 153 323 95 156 323 minecraft:stone
setblock 95 153 327 minecraft:stripped_spruce_log
fill 95 153 328 95 153 331 minecraft:stone
setblock 95 153 332 minecraft:stripped_spruce_log
fill 95 153 333 96 154 333 minecraft:stone
setblock 95 153 337 minecraft:stripped_spruce_log
fill 95 153 338 95 153 341 minecraft:stone
setblock 95 153 342 minecraft:stripped_spruce_log
fill 95 153 343 95 153 346 minecraft:stone
setblock 95 153 347 minecraft:stripped_spruce_log
fill 95 153 348 95 153 351 minecraft:stone
setblock 95 153 352 minecraft:stripped_spruce_log
fill 95 153 353 95 156 353 minecraft:stone
setblock 95 153 357 minecraft:stripped_spruce_log
fill 95 153 358 95 153 361 minecraft:stone
setblock 95 153 362 minecraft:stripped_spruce_log
fill 95 153 363 95 156 363 minecraft:stone
fill 96 153 324 96 153 325 minecraft:stone
setblock 96 153 336 minecraft:stripped_spruce_log
fill 96 153 337 96 156 337 minecraft:stone
setblock 96 153 341 minecraft:stripped_spruce_log
fill 96 153 342 96 156 342 minecraft:stone
setblock 96 153 345 minecraft:stone
setblock 96 153 346 minecraft:stripped_spruce_log
fill 96 153 347 96 153 350 minecraft:stone
setblock 96 153 351 minecraft:stripped_spruce_log
fill 96 153 352 96 156 352 minecraft:stone
setblock 96 153 356 minecraft:stripped_spruce_log
fill 96 153 357 96 155 357 minecraft:stone
setblock 96 153 361 minecraft:stripped_spruce_log
fill 96 153 362 96 154 362 minecraft:stone
setblock 97 153 324 minecraft:stone
setblock 97 153 335 minecraft:stripped_spruce_log
fill 97 153 336 97 155 336 minecraft:stone
setblock 97 153 340 minecraft:stripped_spruce_log
fill 97 153 341 97 156 341 minecraft:stone
setblock 97 153 344 minecraft:stone
setblock 97 153 345 minecraft:stripped_spruce_log
fill 97 153 346 97 156 346 minecraft:stone
setblock 97 153 349 minecraft:stone
setblock 97 153 350 minecraft:stripped_spruce_log
setblock 97 153 360 minecraft:stripped_spruce_log
fill 97 153 361 97 154 361 minecraft:stone
setblock 98 153 324 minecraft:stripped_spruce_log
setblock 98 153 339 minecraft:stripped_spruce_log
fill 98 153 340 98 156 340 minecraft:stone
setblock 98 153 344 minecraft:stripped_spruce_log
fill 98 153 345 98 156 345 minecraft:stone
fill 98 153 347 98 154 347 minecraft:stone
setblock 99 153 323 minecraft:stripped_spruce_log
fill 99 153 324 99 156 324 minecraft:stone
setblock 99 153 343 minecraft:stripped_spruce_log
fill 99 153 344 99 154 344 minecraft:stone
setblock 99 153 363 minecraft:stripped_spruce_log
fill 100 153 323 100 156 323 minecraft:stone
setblock 100 153 362 minecraft:stripped_spruce_log
fill 100 153 363 100 156 363 minecraft:stone
fill 101 153 362 101 154 362 minecraft:stone
setblock 103 153 324 minecraft:stripped_spruce_log
setblock 104 153 323 minecraft:stripped_spruce_log
fill 104 153 324 104 154 324 minecraft:stone
setblock 104 153 363 minecraft:stripped_spruce_log
fill 105 153 323 108 153 323 minecraft:stone
fill 105 153 363 108 153 363 minecraft:stone
setblock 108 153 364 minecraft:raw_iron_block
setblock 109 153 323 minecraft:stripped_spruce_log
setblock 109 153 363 minecraft:stripped_spruce_log
fill 110 153 323 112 153 324 minecraft:stone
fill 110 153 363 113 153 363 minecraft:stone
fill 112 153 362 114 153 362 minecraft:stone
setblock 113 153 323 minecraft:stone
setblock 113 153 324 minecraft:stripped_spruce_log
fill 113 153 325 116 153 325 minecraft:stone
setblock 114 153 323 minecraft:stripped_spruce_log
fill 114 153 324 117 153 324 minecraft:stone
setblock 114 153 363 minecraft:stripped_spruce_log
fill 115 153 323 118 153 323 minecraft:stone
setblock 115 153 361 minecraft:stone
setblock 115 153 362 minecraft:stripped_spruce_log
fill 115 153 363 118 153 363 minecraft:stone
setblock 116 153 361 minecraft:stripped_spruce_log
fill 116 153 362 119 153 362 minecraft:stone
setblock 117 153 325 minecraft:stripped_spruce_log
fill 117 153 361 117 156 361 minecraft:stone
setblock 118 153 324 minecraft:stripped_spruce_log
fill 118 153 325 118 155 326 minecraft:stone
fill 118 153 352 121 153 352 minecraft:stripped_dark_oak_log
setblock 119 153 323 minecraft:stripped_spruce_log
fill 119 153 324 119 156 324 minecraft:stone
setblock 119 153 363 minecraft:stripped_spruce_log
setblock 119 153 364 minecraft:raw_gold_block
fill 120 153 323 120 156 323 minecraft:stone
setblock 120 153 362 minecraft:stripped_spruce_log
fill 120 153 363 123 153 363 minecraft:stone
fill 120 153 364 120 171 364 minecraft:deepslate
setblock 121 153 325 minecraft:stone
setblock 121 153 361 minecraft:stripped_spruce_log
fill 121 153 362 121 156 362 minecraft:stone
setblock 122 153 325 minecraft:stripped_spruce_log
fill 122 153 361 122 155 361 minecraft:stone
setblock 123 153 324 minecraft:stripped_spruce_log
fill 123 153 325 123 154 325 minecraft:stone
setblock 124 153 323 minecraft:stripped_spruce_log
fill 124 153 324 124 156 324 minecraft:stone
fill 124 153 351 130 153 351 minecraft:stripped_dark_oak_log
setblock 124 153 363 minecraft:stripped_spruce_log
fill 125 153 323 125 156 323 minecraft:stone
setblock 125 153 362 minecraft:stripped_spruce_log
fill 125 153 363 128 153 363 minecraft:stone
setblock 126 153 361 minecraft:stripped_spruce_log
fill 126 153 362 126 156 362 minecraft:stone
fill 127 153 361 130 153 361 minecraft:stone
setblock 129 153 323 minecraft:stripped_spruce_log
setblock 129 153 363 minecraft:stripped_spruce_log
fill 130 153 323 130 156 323 minecraft:stone
setblock 130 153 362 minecraft:stripped_spruce_log
fill 130 153 363 130 156 363 minecraft:stone
fill 131 153 350 133 153 350 minecraft:stripped_dark_oak_log
setblock 131 153 361 minecraft:stripped_spruce_log
fill 131 153 362 131 156 362 minecraft:stone
fill 132 153 361 132 155 361 minecraft:stone
setblock 133 153 323 minecraft:stone
setblock 133 153 359 minecraft:stripped_spruce_log
fill 133 153 360 133 155 360 minecraft:stone
setblock 134 153 323 minecraft:stripped_spruce_log
fill 134 153 324 134 154 324 minecraft:stone
setblock 134 153 338 minecraft:stripped_spruce_log
fill 134 153 339 134 153 342 minecraft:stone
setblock 134 153 343 minecraft:stripped_spruce_log
fill 134 153 344 134 153 347 minecraft:stone
setblock 134 153 348 minecraft:stripped_spruce_log
fill 134 153 349 134 153 352 minecraft:stone
setblock 134 153 353 minecraft:stripped_spruce_log
fill 134 153 354 134 156 354 minecraft:stone
setblock 134 153 358 minecraft:stripped_spruce_log
fill 134 153 359 134 156 359 minecraft:stone
setblock 134 153 363 minecraft:stripped_spruce_log
fill 135 153 323 135 156 323 minecraft:stone
setblock 135 153 327 minecraft:stripped_spruce_log
setblock 135 153 337 minecraft:stripped_spruce_log
fill 135 153 338 135 156 338 minecraft:stone
setblock 135 153 342 minecraft:stripped_spruce_log
fill 135 153 343 135 156 343 minecraft:stone
fill 135 153 345 135 153 346 minecraft:stone
setblock 135 153 347 minecraft:stripped_spruce_log
fill 135 153 348 135 153 351 minecraft:stone
setblock 135 153 352 minecraft:stripped_spruce_log
fill 135 153 353 135 156 353 minecraft:stone
setblock 135 153 357 minecraft:stripped_spruce_log
fill 135 153 358 135 156 358 minecraft:stone
setblock 135 153 362 minecraft:stripped_spruce_log
fill 135 153 363 135 156 363 minecraft:stone
setblock 136 153 330 minecraft:raw_gold_block
fill 136 153 331 136 163 331 minecraft:deepslate
fill 136 153 334 136 174 334 minecraft:deepslate
setblock 94 154 348 minecraft:raw_gold_block
fill 94 154 354 94 174 354 minecraft:deepslate
fill 95 154 324 95 154 325 minecraft:stone
setblock 95 154 326 minecraft:stripped_spruce_log
fill 95 154 327 95 154 330 minecraft:stone
setblock 95 154 331 minecraft:stripped_spruce_log
fill 95 154 332 95 157 332 minecraft:stone
setblock 95 154 336 minecraft:stripped_spruce_log
fill 95 154 337 95 154 340 minecraft:stone
setblock 95 154 341 minecraft:stripped_spruce_log
fill 95 154 342 95 154 345 minecraft:stone
setblock 95 154 346 minecraft:stripped_spruce_log
fill 95 154 347 95 154 350 minecraft:stone
setblock 95 154 351 minecraft:stripped_spruce_log
fill 95 154 352 95 157 352 minecraft:stone
setblock 95 154 356 minecraft:stripped_spruce_log
fill 95 154 357 95 154 360 minecraft:stone
setblock 95 154 361 minecraft:stripped_spruce_log
fill 95 154 362 95 157 362 minecraft:stone
setblock 96 154 324 minecraft:stone
setblock 96 154 325 minecraft:stripped_spruce_log
fill 96 154 326 96 157 326 minecraft:stone
setblock 96 154 335 minecraft:stripped_spruce_log
fill 96 154 336 96 157 336 minecraft:stone
setblock 96 154 340 minecraft:stripped_spruce_log
fill 96 154 341 96 157 341 minecraft:stone
setblock 96 154 345 minecraft:stripped_spruce_log
fill 96 154 346 96 154 349 minecraft:stone
setblock 96 154 350 minecraft:stripped_spruce_log
fill 96 154 351 96 157 351 minecraft:stone
setblock 96 154 355 minecraft:stripped_spruce_log
fill 96 154 356 96 155 356 minecraft:stone
setblock 96 154 360 minecraft:stripped_spruce_log
fill 96 154 361 96 156 361 minecraft:stone
setblock 97 154 324 minecraft:stripped_spruce_log
setblock 97 154 325 minecraft:light[level=15]
setblock 97 154 333 minecraft:light[level=15]
setblock 97 154 339 minecraft:stripped_spruce_log
fill 97 154 340 97 157 340 minecraft:stone
setblock 97 154 344 minecraft:stripped_spruce_log
fill 97 154 345 97 157 345 minecraft:stone
setblock 97 154 349 minecraft:stripped_spruce_log
fill 97 154 350 97 156 350 minecraft:stone
setblock 97 154 357 minecraft:light[level=15]
setblock 97 154 360 minecraft:stone
setblock 98 154 323 minecraft:stripped_spruce_log
fill 98 154 324 98 157 324 minecraft:stone
setblock 98 154 338 minecraft:stripped_spruce_log
fill 98 154 339 98 155 339 minecraft:stone
setblock 98 154 342 minecraft:stone
setblock 98 154 343 minecraft:stripped_spruce_log
fill 98 154 344 98 157 344 minecraft:stone
setblock 98 154 363 minecraft:stripped_spruce_log
fill 99 154 323 99 157 323 minecraft:stone
setblock 99 154 342 minecraft:stripped_spruce_log
setblock 99 154 343 minecraft:stone
setblock 99 154 362 minecraft:stripped_spruce_log
fill 99 154 363 99 157 363 minecraft:stone
fill 100 154 362 100 155 362 minecraft:stone
setblock 101 154 324 minecraft:stone
setblock 102 154 324 minecraft:stripped_spruce_log
setblock 103 154 323 minecraft:stripped_spruce_log
fill 103 154 324 103 155 324 minecraft:stone
setblock 103 154 363 minecraft:stripped_spruce_log
fill 104 154 323 107 154 323 minecraft:stone
fill 104 154 363 107 154 363 minecraft:stone
setblock 105 154 325 minecraft:light[level=15]
setblock 105 154 333 minecraft:light[level=15]
setblock 105 154 341 minecraft:light[level=15]
setblock 105 154 349 minecraft:light[level=15]
setblock 105 154 357 minecraft:light[level=15]
setblock 108 154 323 minecraft:stripped_spruce_log
setblock 108 154 363 minecraft:stripped_spruce_log
fill 108 154 364 108 172 364 minecraft:deepslate
fill 109 154 323 111 154 324 minecraft:stone
fill 109 154 363 112 154 363 minecraft:stone
setblock 112 154 323 minecraft:stone
setblock 112 154 324 minecraft:stripped_spruce_log
fill 112 154 325 115 154 325 minecraft:stone
fill 112 154 362 113 154 362 minecraft:stone
setblock 113 154 323 minecraft:stripped_spruce_log
fill 113 154 324 116 154 324 minecraft:stone
setblock 113 154 333 minecraft:light[level=15]
setblock 113 154 341 minecraft:light[level=15]
setblock 113 154 349 minecraft:light[level=15]
setblock 113 154 357 minecraft:light[level=15]
setblock 113 154 363 minecraft:stripped_spruce_log
fill 114 154 323 117 154 323 minecraft:stone
setblock 114 154 362 minecraft:stripped_spruce_log
fill 114 154 363 117 154 363 minecraft:stone
setblock 115 154 361 minecraft:stripped_spruce_log
fill 115 154 362 118 154 362 minecraft:stone
setblock 116 154 325 minecraft:stripped_spruce_log
fill 116 154 326 117 156 326 minecraft:stone
fill 116 154 361 116 156 361 minecraft:stone
setblock 117 154 324 minecraft:stripped_spruce_log
fill 117 154 325 117 157 325 minecraft:stone
setblock 118 154 323 minecraft:stripped_spruce_log
fill 118 154 324 118 157 324 minecraft:stone
setblock 118 154 363 minecraft:stripped_spruce_log
fill 119 154 323 119 157 323 minecraft:stone
setblock 119 154 326 minecraft:stone
setblock 119 154 362 minecraft:stripped_spruce_log
fill 119 154 363 122 154 363 minecraft:stone
fill 119 154 364 119 171 364 minecraft:deepslate
setblock 120 154 361 minecraft:stripped_spruce_log
fill 120 154 362 120 157 362 minecraft:stone
setblock 121 154 325 minecraft:stripped_spruce_log
setblock 121 154 333 minecraft:light[level=15]
setblock 121 154 341 minecraft:light[level=15]
setblock 121 154 349 minecraft:light[level=15]
setblock 121 154 357 minecraft:light[level=15]
fill 121 154 361 121 156 361 minecraft:stone
setblock 122 154 324 minecraft:stripped_spruce_log
fill 122 154 325 122 155 325 minecraft:stone
setblock 123 154 323 minecraft:stripped_spruce_log
fill 123 154 324 123 157 324 minecraft:stone
setblock 123 154 363 minecraft:stripped_spruce_log
fill 124 154 323 124 157 323 minecraft:stone
setblock 124 154 362 minecraft:stripped_spruce_log
fill 124 154 363 127 154 363 minecraft:stone
setblock 125 154 361 minecraft:stripped_spruce_log
fill 125 154 362 125 156 362 minecraft:stone
setblock 128 154 323 minecraft:stripped_spruce_log
setblock 128 154 363 minecraft:stripped_spruce_log
fill 129 154 323 129 157 323 minecraft:stone
setblock 129 154 333 minecraft:light[level=15]
setblock 129 154 341 minecraft:light[level=15]
setblock 129 154 349 minecraft:light[level=15]
setblock 129 154 357 minecraft:light[level=15]
setblock 129 154 362 minecraft:stripped_spruce_log
fill 129 154 363 129 157 363 minecraft:stone
fill 130 154 362 130 157 362 minecraft:stone
setblock 131 154 361 minecraft:stone
setblock 133 154 323 minecraft:stripped_spruce_log
fill 133 154 324 133 157 324 minecraft:stone
setblock 133 154 359 minecraft:stone
setblock 133 154 363 minecraft:stripped_spruce_log
fill 134 154 323 134 157 323 minecraft:stone
fill 134 154 338 134 154 341 minecraft:stone
setblock 134 154 342 minecraft:stripped_spruce_log
fill 134 154 343 134 154 346 minecraft:stone
setblock 134 154 347 minecraft:stripped_spruce_log
fill 134 154 348 134 154 351 minecraft:stone
setblock 134 154 352 minecraft:stripped_spruce_log
fill 134 154 353 134 157 353 minecraft:stone
setblock 134 154 357 minecraft:stripped_spruce_log
fill 134 154 358 134 157 358 minecraft:stone
setblock 134 154 362 minecraft:stripped_spruce_log
fill 134 154 363 134 157 363 minecraft:stone
setblock 135 154 326 minecraft:stripped_spruce_log
fill 135 154 327 135 157 327 minecraft:stone
setblock 135 154 336 minecraft:stripped_spruce_log
fill 135 154 337 135 157 337 minecraft:stone
setblock 135 154 341 minecraft:stripped_spruce_log
fill 135 154 342 135 157 342 minecraft:stone
setblock 135 154 345 minecraft:stone
setblock 135 154 346 minecraft:stripped_spruce_log
fill 135 154 347 135 154 350 minecraft:stone
setblock 135 154 351 minecraft:stripped_spruce_log
fill 135 154 352 135 157 352 minecraft:stone
setblock 135 154 356 minecraft:stripped_spruce_log
fill 135 154 357 135 157 357 minecraft:stone
setblock 135 154 361 minecraft:stripped_spruce_log
fill 135 154 362 135 157 362 minecraft:stone
fill 136 154 330 136 170 330 minecraft:deepslate
setblock 136 154 332 minecraft:gold_block
setblock 136 154 341 minecraft:diamond_block
setblock 136 154 356 minecraft:gold_block
setblock 136 154 361 minecraft:raw_gold_block
fill 94 155 344 94 174 344 minecraft:deepslate
setblock 94 155 345 minecraft:diamond_block
fill 94 155 346 94 174 346 minecraft:deepslate
fill 94 155 348 94 174 348 minecraft:deepslate
setblock 95 155 324 minecraft:stone
setblock 95 155 325 minecraft:stripped_spruce_log
fill 95 155 326 95 155 329 minecraft:stone
setblock 95 155 330 minecraft:stripped_spruce_log
fill 95 155 331 95 158 331 minecraft:stone
fill 95 155 333 95 156 333 minecraft:stone
setblock 95 155 335 minecraft:stripped_spruce_log
fill 95 155 336 95 155 339 minecraft:stone
setblock 95 155 340 minecraft:stripped_spruce_log
fill 95 155 341 95 155 344 minecraft:stone
setblock 95 155 345 minecraft:stripped_spruce_log
fill 95 155 346 95 155 349 minecraft:stone
setblock 95 155 350 minecraft:stripped_spruce_log
fill 95 155 351 95 158 351 minecraft:stone
setblock 95 155 355 minecraft:stripped_spruce_log
fill 95 155 356 95 155 359 minecraft:stone
setblock 95 155 360 minecraft:stripped_spruce_log
fill 95 155 361 95 158 361 minecraft:stone
fill 96 155 324 96 158 324 minecraft:spruce_log
fill 96 155 325 96 158 325 minecraft:stone
fill 96 155 327 96 156 327 minecraft:stone
setblock 96 155 334 minecraft:stripped_spruce_log
fill 96 155 335 96 157 335 minecraft:stone
setblock 96 155 339 minecraft:stripped_spruce_log
fill 96 155 340 96 158 340 minecraft:stone
fill 96 155 343 96 158 343 minecraft:spruce_log
setblock 96 155 344 minecraft:stripped_spruce_log
fill 96 155 345 96 155 348 minecraft:stone
setblock 96 155 349 minecraft:stripped_spruce_log
fill 96 155 350 96 158 350 minecraft:stone
setblock 96 155 354 minecraft:stripped_spruce_log
setblock 96 155 355 minecraft:stone
setblock 96 155 359 minecraft:stripped_spruce_log
fill 96 155 360 96 156 360 minecraft:stone
fill 96 155 362 96 158 362 minecraft:spruce_log
setblock 97 155 323 minecraft:stripped_spruce_log
fill 97 155 324 97 158 324 minecraft:stone
setblock 97 155 338 minecraft:stripped_spruce_log
fill 97 155 339 97 158 339 minecraft:stone
setblock 97 155 343 minecraft:stripped_spruce_log
fill 97 155 344 97 158 344 minecraft:stone
setblock 97 155 348 minecraft:stripped_spruce_log
fill 97 155 349 97 158 349 minecraft:stone
setblock 97 155 363 minecraft:stripped_spruce_log
fill 98 155 323 98 158 323 minecraft:stone
setblock 98 155 342 minecraft:stripped_spruce_log
fill 98 155 343 98 157 343 minecraft:stone
setblock 98 155 347 minecraft:stripped_spruce_log
setblock 98 155 362 minecraft:stripped_spruce_log
fill 98 155 363 98 158 363 minecraft:stone
fill 99 155 362 99 156 362 minecraft:stone
setblock 101 155 324 minecraft:stripped_spruce_log
setblock 102 155 323 minecraft:stripped_spruce_log
fill 102 155 324 102 156 324 minecraft:stone
setblock 102 155 363 minecraft:stripped_spruce_log
fill 103 155 323 106 155 323 minecraft:stone
fill 103 155 363 104 155 363 minecraft:stone
setblock 107 155 323 minecraft:stripped_spruce_log
fill 108 155 323 110 155 324 minecraft:stone
fill 108 155 363 111 155 363 minecraft:stone
setblock 111 155 323 minecraft:stone
setblock 111 155 324 minecraft:stripped_spruce_log
setblock 112 155 323 minecraft:stripped_spruce_log
fill 112 155 324 114 155 325 minecraft:stone
setblock 112 155 362 minecraft:stone
setblock 112 155 363 minecraft:stripped_spruce_log
fill 113 155 323 116 155 323 minecraft:stone
setblock 113 155 362 minecraft:stripped_spruce_log
fill 113 155 363 116 155 363 minecraft:stone
fill 114 155 362 114 158 362 minecraft:stone
fill 115 155 324 115 158 324 minecraft:spruce_log
setblock 115 155 325 minecraft:stripped_spruce_log
fill 115 155 326 115 158 326 minecraft:stone
setblock 115 155 361 minecraft:stone
fill 115 155 362 115 158 362 minecraft:spruce_log
setblock 116 155 324 minecraft:stripped_spruce_log
fill 116 155 325 116 158 325 minecraft:stone
fill 116 155 362 117 155 362 minecraft:stone
setblock 117 155 323 minecraft:stripped_spruce_log
fill 117 155 324 117 158 324 minecraft:stone
setblock 117 155 363 minecraft:stripped_spruce_log
fill 118 155 323 118 158 323 minecraft:stone
setblock 118 155 362 minecraft:stripped_spruce_log
fill 118 155 363 121 155 363 minecraft:stone
setblock 119 155 361 minecraft:stripped_spruce_log
fill 119 155 362 119 158 362 minecraft:stone
setblock 120 155 325 minecraft:stripped_spruce_log
fill 120 155 361 120 156 361 minecraft:stone
setblock 121 155 324 minecraft:stripped_spruce_log
fill 121 155 325 121 157 325 minecraft:stone
setblock 122 155 323 minecraft:stripped_spruce_log
fill 122 155 324 122 158 324 minecraft:stone
setblock 122 155 363 minecraft:stripped_spruce_log
fill 123 155 323 123 158 323 minecraft:stone
setblock 123 155 362 minecraft:stripped_spruce_log
fill 123 155 363 126 155 363 minecraft:stone
fill 124 155 362 124 157 362 minecraft:stone
setblock 127 155 323 minecraft:stripped_spruce_log
setblock 127 155 363 minecraft:stripped_spruce_log
fill 128 155 323 128 158 323 minecraft:stone
fill 128 155 325 128 158 325 minecraft:stripped_spruce_log
setblock 128 155 362 minecraft:stripped_spruce_log
fill 128 155 363 128 158 363 minecraft:stone
fill 129 155 324 129 158 324 minecraft:stripped_spruce_log
fill 129 155 326 129 158 326 minecraft:stripped_spruce_log
fill 129 155 362 129 157 362 minecraft:stone
fill 130 155 325 130 158 325 minecraft:stripped_spruce_log
setblock 132 155 323 minecraft:stripped_spruce_log
setblock 132 155 363 minecraft:stripped_spruce_log
fill 133 155 323 133 158 323 minecraft:stone
fill 133 155 343 133 155 346 minecraft:stone
setblock 133 155 362 minecraft:stripped_spruce_log
fill 133 155 363 133 158 363 minecraft:stone
fill 134 155 324 134 158 324 minecraft:spruce_log
setblock 134 155 325 minecraft:stone
fill 134 155 339 134 155 340 minecraft:stone
setblock 134 155 341 minecraft:stripped_spruce_log
fill 134 155 342 134 158 342 minecraft:stone
fill 134 155 343 134 158 343 minecraft:spruce_log
fill 134 155 344 134 155 345 minecraft:stone
setblock 134 155 346 minecraft:stripped_spruce_log
fill 134 155 347 134 155 350 minecraft:stone
setblock 134 155 351 minecraft:stripped_spruce_log
fill 134 155 352 134 158 352 minecraft:stone
setblock 134 155 356 minecraft:stripped_spruce_log
fill 134 155 357 134 157 357 minecraft:stone
setblock 134 155 361 minecraft:stripped_spruce_log
fill 134 155 362 134 158 362 minecraft:spruce_log
setblock 135 155 325 minecraft:stripped_spruce_log
fill 135 155 326 135 158 326 minecraft:stone
fill 135 155 328 135 156 328 minecraft:stone
setblock 135 155 335 minecraft:stripped_spruce_log
fill 135 155 336 135 156 336 minecraft:stone
setblock 135 155 340 minecraft:stripped_spruce_log
fill 135 155 341 135 158 341 minecraft:stone
setblock 135 155 345 minecraft:stripped_spruce_log
fill 135 155 346 135 155 349 minecraft:stone
setblock 135 155 350 minecraft:stripped_spruce_log
fill 135 155 351 135 158 351 minecraft:stone
setblock 135 155 355 minecraft:stripped_spruce_log
fill 135 155 356 135 158 356 minecraft:stone
setblock 135 155 360 minecraft:stripped_spruce_log
fill 135 155 361 135 158 361 minecraft:stone
fill 136 155 332 136 174 332 minecraft:deepslate
fill 136 155 341 136 174 341 minecraft:deepslate
setblock 136 155 356 minecraft:deepslate
fill 136 155 361 136 174 361 minecraft:deepslate
fill 94 156 345 94 167 345 minecraft:deepslate
setblock 94 156 349 minecraft:raw_gold_block
fill 95 156 322 96 160 322 minecraft:deepslate
setblock 95 156 324 minecraft:stripped_spruce_log
fill 95 156 325 95 156 328 minecraft:stone
setblock 95 156 329 minecraft:stripped_spruce_log
fill 95 156 330 95 159 330 minecraft:stone
setblock 95 156 334 minecraft:stripped_spruce_log
fill 95 156 335 95 156 338 minecraft:stone
setblock 95 156 339 minecraft:stripped_spruce_log
fill 95 156 340 95 156 343 minecraft:stone
setblock 95 156 344 minecraft:stripped_spruce_log
fill 95 156 345 95 156 348 minecraft:stone
setblock 95 156 349 minecraft:stripped_spruce_log
fill 95 156 350 95 159 350 minecraft:stone
setblock 95 156 354 minecraft:stripped_spruce_log
fill 95 156 355 95 156 358 minecraft:stone
setblock 95 156 359 minecraft:stripped_spruce_log
fill 95 156 360 95 158 360 minecraft:stone
setblock 96 156 323 minecraft:stripped_spruce_log
setblock 96 156 328 minecraft:stripped_spruce_log
setblock 96 156 334 minecraft:stone
setblock 96 156 338 minecraft:stripped_spruce_log
fill 96 156 339 96 159 339 minecraft:stone
fill 96 156 344 96 156 347 minecraft:stone
setblock 96 156 348 minecraft:stripped_spruce_log
fill 96 156 349 96 159 349 minecraft:stone
setblock 96 156 353 minecraft:stripped_spruce_log
setblock 96 156 363 minecraft:stripped_spruce_log
setblock 97 156 322 minecraft:gold_block
fill 97 156 323 97 159 323 minecraft:stone
setblock 97 156 325 minecraft:light[level=12]
setblock 97 156 332 minecraft:light[level=12]
setblock 97 156 337 minecraft:stripped_spruce_log
fill 97 156 338 97 157 338 minecraft:stone
setblock 97 156 342 minecraft:stripped_spruce_log
fill 97 156 343 97 159 343 minecraft:stone
setblock 97 156 347 minecraft:stripped_spruce_log
fill 97 156 348 97 159 348 minecraft:stone
setblock 97 156 353 minecraft:light[level=12]
setblock 97 156 360 minecraft:light[level=12]
setblock 97 156 362 minecraft:stripped_spruce_log
fill 97 156 363 97 159 363 minecraft:stone
setblock 98 156 341 minecraft:stripped_spruce_log
fill 98 156 342 98 157 342 minecraft:stone
setblock 98 156 346 minecraft:stripped_spruce_log
setblock 98 156 347 minecraft:stone
setblock 98 156 362 minecraft:stone
setblock 100 156 324 minecraft:stripped_spruce_log
setblock 101 156 323 minecraft:stripped_spruce_log
fill 101 156 324 101 157 324 minecraft:stone
setblock 101 156 363 minecraft:stripped_spruce_log
fill 102 156 323 105 156 323 minecraft:stone
setblock 102 156 363 minecraft:stone
setblock 104 156 325 minecraft:light[level=12]
setblock 104 156 332 minecraft:light[level=12]
setblock 104 156 339 minecraft:light[level=12]
setblock 104 156 346 minecraft:light[level=12]
setblock 104 156 353 minecraft:light[level=12]
setblock 104 156 360 minecraft:light[level=12]
setblock 105 156 322 minecraft:raw_gold_block
setblock 106 156 323 minecraft:stripped_spruce_log
fill 107 156 323 110 156 323 minecraft:stone
fill 108 156 324 109 156 324 minecraft:stone
fill 109 156 363 110 156 363 minecraft:stone
setblock 110 156 324 minecraft:stripped_spruce_log
setblock 111 156 323 minecraft:stripped_spruce_log
fill 111 156 324 113 156 325 minecraft:stone
setblock 111 156 332 minecraft:light[level=12]
setblock 111 156 339 minecraft:light[level=12]
setblock 111 156 346 minecraft:light[level=12]
setblock 111 156 353 minecraft:light[level=12]
setblock 111 156 360 minecraft:light[level=12]
setblock 111 156 363 minecraft:stripped_spruce_log
fill 112 156 323 115 156 323 minecraft:stone
setblock 112 156 362 minecraft:stripped_spruce_log
fill 112 156 363 115 156 363 minecraft:stone
fill 113 156 362 113 159 362 minecraft:stone
setblock 114 156 324 minecraft:stone
setblock 114 156 325 minecraft:stripped_spruce_log
fill 115 156 325 115 159 325 minecraft:stone
setblock 116 156 323 minecraft:stripped_spruce_log
fill 116 156 324 116 159 324 minecraft:stone
setblock 116 156 362 minecraft:stone
setblock 116 156 363 minecraft:stripped_spruce_log
fill 117 156 323 117 159 323 minecraft:stone
setblock 117 156 362 minecraft:stripped_spruce_log
fill 117 156 363 120 156 363 minecraft:stone
setblock 118 156 325 minecraft:stone
setblock 118 156 326 minecraft:stripped_spruce_log
setblock 118 156 332 minecraft:light[level=12]
setblock 118 156 339 minecraft:light[level=12]
setblock 118 156 346 minecraft:light[level=12]
setblock 118 156 353 minecraft:light[level=12]
setblock 118 156 360 minecraft:light[level=12]
setblock 118 156 361 minecraft:stripped_spruce_log
fill 118 156 362 118 159 362 minecraft:stone
setblock 119 156 325 minecraft:stripped_spruce_log
setblock 119 156 361 minecraft:stone
setblock 120 156 324 minecraft:stripped_spruce_log
fill 120 156 325 120 158 325 minecraft:stone
setblock 121 156 323 minecraft:stripped_spruce_log
fill 121 156 324 121 159 324 minecraft:stone
setblock 121 156 363 minecraft:stripped_spruce_log
fill 122 156 323 122 159 323 minecraft:stone
setblock 122 156 362 minecraft:stripped_spruce_log
fill 122 156 363 125 156 363 minecraft:stone
fill 123 156 362 123 157 362 minecraft:stone
fill 124 156 364 124 170 364 minecraft:deepslate
setblock 125 156 324 minecraft:stripped_spruce_log
setblock 125 156 325 minecraft:light[level=12]
setblock 125 156 332 minecraft:light[level=12]
setblock 125 156 339 minecraft:light[level=12]
setblock 125 156 346 minecraft:light[level=12]
setblock 125 156 353 minecraft:light[level=12]
setblock 125 156 360 minecraft:light[level=12]
setblock 125 156 364 minecraft:diamond_block
setblock 126 156 323 minecraft:stripped_spruce_log
setblock 126 156 363 minecraft:stripped_spruce_log
fill 127 156 323 127 159 323 minecraft:stone
setblock 127 156 362 minecraft:stripped_spruce_log
fill 127 156 363 127 159 363 minecraft:stone
setblock 128 156 362 minecraft:stone
setblock 131 156 323 minecraft:stripped_spruce_log
setblock 131 156 363 minecraft:stripped_spruce_log
fill 132 156 323 132 159 323 minecraft:stone
setblock 132 156 325 minecraft:light[level=12]
setblock 132 156 332 minecraft:light[level=12]
setblock 132 156 339 minecraft:light[level=12]
setblock 132 156 346 minecraft:light[level=12]
setblock 132 156 353 minecraft:light[level=12]
setblock 132 156 360 minecraft:light[level=12]
setblock 132 156 362 minecraft:stripped_spruce_log
fill 132 156 363 132 159 363 minecraft:stone
fill 133 156 343 133 156 345 minecraft:stone
setblock 133 156 346 minecraft:stripped_spruce_log
fill 133 156 347 135 157 347 minecraft:stone
setblock 133 156 361 minecraft:stripped_spruce_log
fill 133 156 362 133 159 362 minecraft:stone
setblock 134 156 325 minecraft:stripped_spruce_log
setblock 134 156 339 minecraft:stone
setblock 134 156 340 minecraft:stripped_spruce_log
fill 134 156 341 134 159 341 minecraft:stone
setblock 134 156 344 minecraft:stone
setblock 134 156 345 minecraft:stripped_spruce_log
fill 134 156 346 135 158 346 minecraft:stone
fill 134 156 348 134 156 349 minecraft:stone
setblock 134 156 350 minecraft:stripped_spruce_log
fill 134 156 351 134 159 351 minecraft:stone
setblock 134 156 355 minecraft:stripped_spruce_log
fill 134 156 356 134 158 356 minecraft:stone
setblock 134 156 360 minecraft:stripped_spruce_log
fill 134 156 361 134 159 361 minecraft:stone
setblock 135 156 324 minecraft:stripped_spruce_log
fill 135 156 325 135 159 325 minecraft:stone
setblock 135 156 339 minecraft:stripped_spruce_log
fill 135 156 340 135 159 340 minecraft:stone
setblock 135 156 344 minecraft:stripped_spruce_log
fill 135 156 345 135 159 345 minecraft:stone
setblock 135 156 348 minecraft:stone
setblock 135 156 349 minecraft:stripped_spruce_log
fill 135 156 350 135 159 350 minecraft:stone
setblock 135 156 354 minecraft:stripped_spruce_log
fill 135 156 355 135 159 355 minecraft:stone
setblock 135 156 359 minecraft:stripped_spruce_log
fill 135 156 360 135 159 360 minecraft:stone
fill 136 156 348 136 171 349 minecraft:deepslate
setblock 136 156 350 minecraft:raw_iron_block
setblock 136 156 354 minecraft:raw_gold_block
setblock 136 156 356 minecraft:raw_iron_block
fill 94 157 349 94 175 349 minecraft:deepslate
setblock 95 157 323 minecraft:stripped_spruce_log
fill 95 157 324 95 157 327 minecraft:stone
setblock 95 157 328 minecraft:stripped_spruce_log
fill 95 157 329 95 160 329 minecraft:stone
setblock 95 157 333 minecraft:stripped_spruce_log
fill 95 157 334 95 157 337 minecraft:stone
setblock 95 157 338 minecraft:stripped_spruce_log
fill 95 157 339 95 157 342 minecraft:stone
setblock 95 157 343 minecraft:stripped_spruce_log
fill 95 157 344 95 157 347 minecraft:stone
setblock 95 157 348 minecraft:stripped_spruce_log
fill 95 157 349 95 160 349 minecraft:stone
setblock 95 157 353 minecraft:stripped_spruce_log
fill 95 157 354 95 157 357 minecraft:stone
setblock 95 157 358 minecraft:stripped_spruce_log
fill 95 157 359 95 158 359 minecraft:stone
setblock 95 157 363 minecraft:stripped_spruce_log
fill 96 157 323 96 160 323 minecraft:stone
setblock 96 157 327 minecraft:stripped_spruce_log
fill 96 157 328 96 160 328 minecraft:stone
setblock 96 157 337 minecraft:stripped_spruce_log
fill 96 157 338 96 160 338 minecraft:stone
setblock 96 157 342 minecraft:stripped_spruce_log
fill 96 157 344 96 157 346 minecraft:stone
setblock 96 157 347 minecraft:stripped_spruce_log
fill 96 157 348 96 160 348 minecraft:stone
setblock 96 157 352 minecraft:stripped_spruce_log
fill 96 157 363 96 160 363 minecraft:stone
fill 97 157 322 97 174 322 minecraft:deepslate
setblock 97 157 341 minecraft:stripped_spruce_log
fill 97 157 342 97 160 342 minecraft:stone
setblock 97 157 346 minecraft:stripped_spruce_log
fill 97 157 347 97 160 347 minecraft:stone
setblock 98 157 345 minecraft:stripped_spruce_log
setblock 98 157 346 minecraft:stone
setblock 99 157 324 minecraft:stripped_spruce_log
setblock 100 157 323 minecraft:stripped_spruce_log
fill 100 157 324 100 158 324 minecraft:stone
setblock 100 157 363 minecraft:stripped_spruce_log
fill 101 157 323 104 157 323 minecraft:stone
setblock 101 157 363 minecraft:stone
fill 105 157 322 105 169 322 minecraft:deepslate
setblock 105 157 323 minecraft:stripped_spruce_log
fill 106 157 323 109 157 323 minecraft:stone
setblock 108 157 324 minecraft:stone
setblock 109 157 324 minecraft:stripped_spruce_log
setblock 110 157 323 minecraft:stripped_spruce_log
fill 110 157 324 113 157 324 minecraft:stone
setblock 110 157 363 minecraft:stripped_spruce_log
fill 111 157 323 114 157 323 minecraft:stone
fill 111 157 325 112 157 325 minecraft:stone
fill 111 157 363 114 157 363 minecraft:stone
setblock 113 157 325 minecraft:stripped_spruce_log
setblock 114 157 324 minecraft:stripped_spruce_log
fill 114 157 325 114 160 325 minecraft:stone
setblock 115 157 323 minecraft:stripped_spruce_log
setblock 115 157 363 minecraft:stripped_spruce_log
fill 116 157 323 116 160 323 minecraft:stone
setblock 116 157 326 minecraft:stone
setblock 116 157 362 minecraft:stripped_spruce_log
fill 116 157 363 119 157 363 minecraft:stone
setblock 117 157 326 minecraft:stripped_spruce_log
fill 117 157 362 117 160 362 minecraft:stone
setblock 118 157 325 minecraft:stripped_spruce_log
setblock 119 157 324 minecraft:stripped_spruce_log
fill 119 157 325 119 160 325 minecraft:stone
setblock 120 157 323 minecraft:stripped_spruce_log
fill 120 157 324 120 160 324 minecraft:stone
setblock 120 157 363 minecraft:stripped_spruce_log
fill 121 157 323 121 160 323 minecraft:stone
setblock 121 157 362 minecraft:stripped_spruce_log
fill 121 157 363 124 157 363 minecraft:stone
fill 122 157 362 122 158 362 minecraft:stone
setblock 124 157 324 minecraft:stripped_spruce_log
setblock 125 157 323 minecraft:stripped_spruce_log
setblock 125 157 363 minecraft:stripped_spruce_log
fill 125 157 364 125 174 364 minecraft:deepslate
fill 126 157 323 126 159 323 minecraft:stone
fill 126 157 363 126 160 363 minecraft:stone
setblock 130 157 323 minecraft:stripped_spruce_log
setblock 130 157 363 minecraft:stripped_spruce_log
fill 131 157 323 131 160 323 minecraft:stone
setblock 131 157 362 minecraft:stripped_spruce_log
fill 131 157 363 131 160 363 minecraft:stone
fill 132 157 362 132 159 362 minecraft:stone
fill 133 157 343 133 157 344 minecraft:stone
setblock 133 157 345 minecraft:stripped_spruce_log
fill 133 157 346 133 160 346 minecraft:stone
fill 133 157 348 133 157 349 minecraft:stone
fill 134 157 325 134 160 325 minecraft:stone
fill 134 157 340 134 158 340 minecraft:stone
setblock 134 157 344 minecraft:stripped_spruce_log
fill 134 157 345 134 160 345 minecraft:stone
setblock 134 157 348 minecraft:stone
setblock 134 157 349 minecraft:stripped_spruce_log
fill 134 157 350 134 160 350 minecraft:stone
setblock 134 157 354 minecraft:stripped_spruce_log
fill 134 157 355 134 160 355 minecraft:stone
setblock 134 157 359 minecraft:stripped_spruce_log
fill 134 157 360 134 159 360 minecraft:stone
setblock 135 157 323 minecraft:stripped_spruce_log
fill 135 157 324 135 160 324 minecraft:stone
setblock 135 157 328 minecraft:stripped_spruce_log
fill 135 157 329 135 160 329 minecraft:stone
setblock 135 157 338 minecraft:stripped_spruce_log
fill 135 157 339 135 160 339 minecraft:stone
setblock 135 157 343 minecraft:stripped_spruce_log
fill 135 157 344 135 160 344 minecraft:stone
setblock 135 157 348 minecraft:stripped_spruce_log
fill 135 157 349 135 160 349 minecraft:stone
setblock 135 157 353 minecraft:stripped_spruce_log
fill 135 157 354 135 160 354 minecraft:stone
setblock 135 157 358 minecraft:stripped_spruce_log
fill 135 157 359 135 160 359 minecraft:stone
setblock 135 157 363 minecraft:stripped_spruce_log
fill 136 157 350 136 171 350 minecraft:deepslate
fill 136 157 354 136 174 354 minecraft:deepslate
fill 136 157 356 136 174 356 minecraft:deepslate
fill 95 158 323 95 158 326 minecraft:stone
setblock 95 158 327 minecraft:stripped_spruce_log
fill 95 158 328 95 160 328 minecraft:stone
setblock 95 158 332 minecraft:stripped_spruce_log
fill 95 158 333 95 158 336 minecraft:stone
setblock 95 158 337 minecraft:stripped_spruce_log
fill 95 158 338 95 158 341 minecraft:stone
setblock 95 158 342 minecraft:stripped_spruce_log
fill 95 158 343 95 158 346 minecraft:stone
setblock 95 158 347 minecraft:stripped_spruce_log
fill 95 158 348 95 160 348 minecraft:stone
setblock 95 158 352 minecraft:stripped_spruce_log
fill 95 158 353 95 158 356 minecraft:stone
setblock 95 158 357 minecraft:stripped_spruce_log
setblock 95 158 358 minecraft:stone
setblock 95 158 362 minecraft:stripped_spruce_log
fill 95 158 363 95 160 363 minecraft:stone
setblock 96 158 326 minecraft:stripped_spruce_log
fill 96 158 327 96 160 327 minecraft:stone
fill 96 158 329 96 159 329 minecraft:stone
setblock 96 158 336 minecraft:stripped_spruce_log
fill 96 158 337 96 159 337 minecraft:stone
setblock 96 158 341 minecraft:stripped_spruce_log
fill 96 158 342 96 160 342 minecraft:stone
fill 96 158 344 96 158 345 minecraft:stone
setblock 96 158 346 minecraft:stripped_spruce_log
fill 96 158 347 96 160 347 minecraft:stone
setblock 96 158 351 minecraft:stripped_spruce_log
fill 96 158 352 96 160 352 minecraft:stone
setblock 97 158 340 minecraft:stripped_spruce_log
fill 97 158 341 97 159 341 minecraft:stone
setblock 97 158 345 minecraft:stripped_spruce_log
fill 97 158 346 97 161 346 minecraft:stone
setblock 98 158 324 minecraft:stripped_spruce_log
setblock 99 158 323 minecraft:stripped_spruce_log
fill 99 158 324 99 159 324 minecraft:stone
setblock 99 158 363 minecraft:stripped_spruce_log
fill 100 158 323 103 158 323 minecraft:stone
setblock 104 158 323 minecraft:stripped_spruce_log
fill 105 158 323 108 158 323 minecraft:stone
setblock 108 158 324 minecraft:stripped_spruce_log
setblock 109 158 323 minecraft:stripped_spruce_log
fill 109 158 324 112 158 324 minecraft:stone
setblock 109 158 364 minecraft:diamond_block
fill 110 158 323 113 158 323 minecraft:stone
fill 110 158 363 113 158 363 minecraft:stone
fill 110 158 364 111 174 364 minecraft:deepslate
setblock 111 158 325 minecraft:stone
setblock 112 158 325 minecraft:stripped_spruce_log
setblock 113 158 324 minecraft:stripped_spruce_log
fill 113 158 325 113 161 325 minecraft:stone
setblock 114 158 323 minecraft:stripped_spruce_log
fill 114 158 324 114 160 324 minecraft:stone
fill 114 158 326 114 159 326 minecraft:stone
setblock 114 158 363 minecraft:stripped_spruce_log
fill 115 158 323 115 160 323 minecraft:stone
fill 115 158 363 118 158 363 minecraft:stone
setblock 116 158 326 minecraft:stripped_spruce_log
fill 116 158 362 116 160 362 minecraft:stone
setblock 117 158 325 minecraft:stripped_spruce_log
setblock 118 158 324 minecraft:stripped_spruce_log
fill 118 158 325 118 161 325 minecraft:stone
setblock 119 158 323 minecraft:stripped_spruce_log
fill 119 158 324 119 160 324 minecraft:stone
setblock 119 158 363 minecraft:stripped_spruce_log
fill 120 158 323 120 160 323 minecraft:stone
setblock 120 158 362 minecraft:stripped_spruce_log
fill 120 158 363 123 158 363 minecraft:stone
setblock 121 158 362 minecraft:stone
setblock 123 158 324 minecraft:stripped_spruce_log
setblock 124 158 323 minecraft:stripped_spruce_log
setblock 124 158 363 minecraft:stripped_spruce_log
fill 125 158 323 125 160 323 minecraft:stone
fill 125 158 363 125 160 363 minecraft:stone
setblock 128 158 324 minecraft:stripped_spruce_log
setblock 128 158 326 minecraft:stripped_spruce_log
setblock 129 158 323 minecraft:stripped_spruce_log
setblock 129 158 363 minecraft:stripped_spruce_log
setblock 130 158 322 minecraft:raw_gold_block
fill 130 158 323 130 160 323 minecraft:stone
setblock 130 158 324 minecraft:stripped_spruce_log
setblock 130 158 326 minecraft:stripped_spruce_log
fill 130 158 363 130 160 363 minecraft:stone
setblock 131 158 362 minecraft:stone
setblock 133 158 324 minecraft:stripped_spruce_log
setblock 133 158 344 minecraft:stripped_spruce_log
fill 133 158 345 133 161 345 minecraft:stone
fill 133 158 347 133 158 348 minecraft:stone
setblock 133 158 349 minecraft:stripped_spruce_log
fill 133 158 350 133 161 350 minecraft:stone
setblock 134 158 323 minecraft:stripped_spruce_log
fill 134 158 344 134 160 344 minecraft:stone
setblock 134 158 347 minecraft:stone
setblock 134 158 348 minecraft:stripped_spruce_log
fill 134 158 349 134 160 349 minecraft:stone
setblock 134 158 353 minecraft:stripped_spruce_log
fill 134 158 354 134 160 354 minecraft:stone
setblock 134 158 358 minecraft:stripped_spruce_log
setblock 134 158 359 minecraft:stone
setblock 134 158 363 minecraft:stripped_spruce_log
fill 135 158 323 135 160 323 minecraft:stone
setblock 135 158 327 minecraft:stripped_spruce_log
fill 135 158 328 135 160 328 minecraft:stone
setblock 135 158 337 minecraft:stripped_spruce_log
fill 135 158 338 135 160 338 minecraft:stone
setblock 135 158 342 minecraft:stripped_spruce_log
fill 135 158 343 135 160 343 minecraft:stone
setblock 135 158 347 minecraft:stripped_spruce_log
fill 135 158 348 135 160 348 minecraft:stone
setblock 135 158 352 minecraft:stripped_spruce_log
fill 135 158 353 135 160 353 minecraft:stone
setblock 135 158 357 minecraft:stripped_spruce_log
fill 135 158 358 135 160 358 minecraft:stone
setblock 135 158 362 minecraft:stripped_spruce_log
fill 135 158 363 135 160 363 minecraft:stone
fill 95 159 323 95 159 325 minecraft:stone
setblock 95 159 326 minecraft:stripped_spruce_log
fill 95 159 327 95 160 327 minecraft:stone
setblock 95 159 331 minecraft:stripped_spruce_log
fill 95 159 332 95 159 335 minecraft:stone
setblock 95 159 336 minecraft:stripped_spruce_log
fill 95 159 337 95 159 340 minecraft:stone
setblock 95 159 341 minecraft:stripped_spruce_log
fill 95 159 342 95 159 345 minecraft:stone
setblock 95 159 346 minecraft:stripped_spruce_log
fill 95 159 347 95 160 347 minecraft:stone
setblock 95 159 351 minecraft:stripped_spruce_log
fill 95 159 352 95 159 355 minecraft:stone
setblock 95 159 361 minecraft:stripped_spruce_log
setblock 95 159 362 minecraft:stone
setblock 96 159 324 minecraft:glowstone
setblock 96 159 325 minecraft:stripped_spruce_log
fill 96 159 326 96 160 326 minecraft:stone
setblock 96 159 330 minecraft:stripped_spruce_log
setblock 96 159 340 minecraft:stripped_spruce_log
fill 96 159 341 96 160 341 minecraft:stone
setblock 96 159 343 minecraft:glowstone
setblock 96 159 344 minecraft:stone
setblock 96 159 345 minecraft:stripped_spruce_log
fill 96 159 346 96 160 346 minecraft:stone
setblock 96 159 350 minecraft:stripped_spruce_log
fill 96 159 351 96 160 351 minecraft:stone
setblock 96 159 362 minecraft:glowstone
setblock 97 159 324 minecraft:stripped_spruce_log
setblock 97 159 344 minecraft:stripped_spruce_log
fill 97 159 345 97 162 345 minecraft:stone
setblock 97 159 349 minecraft:stripped_spruce_log
setblock 98 159 323 minecraft:stripped_spruce_log
fill 98 159 324 98 160 324 minecraft:stone
fill 98 159 364 99 174 364 minecraft:deepslate
fill 99 159 323 102 159 323 minecraft:stone
setblock 100 159 364 minecraft:diamond_block
fill 101 159 364 101 172 364 minecraft:deepslate
setblock 103 159 323 minecraft:stripped_spruce_log
fill 104 159 323 107 159 323 minecraft:stone
setblock 107 159 324 minecraft:stripped_spruce_log
setblock 108 159 323 minecraft:stripped_spruce_log
fill 108 159 324 111 159 324 minecraft:stone
fill 109 159 323 112 159 323 minecraft:stone
fill 109 159 364 109 175 364 minecraft:deepslate
setblock 110 159 325 minecraft:stone
fill 110 159 363 112 159 363 minecraft:stone
setblock 111 159 325 minecraft:stripped_spruce_log
setblock 112 159 324 minecraft:stripped_spruce_log
fill 112 159 325 112 162 325 minecraft:stone
setblock 113 159 323 minecraft:stripped_spruce_log
fill 113 159 324 113 160 324 minecraft:stone
setblock 113 159 363 minecraft:stripped_spruce_log
fill 114 159 323 114 160 323 minecraft:stone
setblock 114 159 362 minecraft:stripped_spruce_log
fill 114 159 363 117 159 363 minecraft:stone
setblock 115 159 324 minecraft:glowstone
setblock 115 159 326 minecraft:stripped_spruce_log
setblock 115 159 362 minecraft:glowstone
setblock 116 159 325 minecraft:stripped_spruce_log
setblock 116 159 326 minecraft:stone
setblock 117 159 324 minecraft:stripped_spruce_log
fill 117 159 325 117 162 325 minecraft:stone
setblock 118 159 323 minecraft:stripped_spruce_log
fill 118 159 324 118 160 324 minecraft:stone
setblock 118 159 363 minecraft:stripped_spruce_log
fill 119 159 323 119 160 323 minecraft:stone
setblock 119 159 362 minecraft:stripped_spruce_log
fill 119 159 363 122 159 363 minecraft:stone
setblock 120 159 362 minecraft:stone
setblock 122 159 324 minecraft:stripped_spruce_log
setblock 123 159 323 minecraft:stripped_spruce_log
setblock 123 159 363 minecraft:stripped_spruce_log
fill 124 159 323 124 160 323 minecraft:stone
fill 124 159 363 124 160 363 minecraft:stone
setblock 128 159 323 minecraft:stripped_spruce_log
setblock 128 159 363 minecraft:stripped_spruce_log
fill 129 159 323 129 160 323 minecraft:stone
fill 129 159 363 129 160 363 minecraft:stone
fill 130 159 322 130 171 322 minecraft:deepslate
setblock 133 159 323 minecraft:stripped_spruce_log
fill 133 159 324 133 160 324 minecraft:stone
fill 133 159 344 133 162 344 minecraft:stone
setblock 133 159 347 minecraft:stone
setblock 133 159 348 minecraft:stripped_spruce_log
fill 133 159 349 133 162 349 minecraft:stone
fill 133 159 351 133 160 351 minecraft:stone
setblock 133 159 363 minecraft:stripped_spruce_log
fill 134 159 323 134 160 323 minecraft:stone
setblock 134 159 324 minecraft:glowstone
setblock 134 159 342 minecraft:stripped_spruce_log
setblock 134 159 343 minecraft:glowstone
setblock 134 159 346 minecraft:stone
setblock 134 159 347 minecraft:stripped_spruce_log
fill 134 159 348 134 160 348 minecraft:stone
setblock 134 159 352 minecraft:stripped_spruce_log
fill 134 159 353 134 160 353 minecraft:stone
setblock 134 159 362 minecraft:glowstone
fill 134 159 363 134 160 363 minecraft:stone
setblock 135 159 326 minecraft:stripped_spruce_log
fill 135 159 327 135 160 327 minecraft:stone
setblock 135 159 330 minecraft:stone
setblock 135 159 341 minecraft:stripped_spruce_log
fill 135 159 342 135 160 342 minecraft:stone
setblock 135 159 346 minecraft:stripped_spruce_log
fill 135 159 347 135 160 347 minecraft:stone
setblock 135 159 351 minecraft:stripped_spruce_log
fill 135 159 352 135 160 352 minecraft:stone
setblock 135 159 356 minecraft:stripped_spruce_log
fill 135 159 357 135 160 357 minecraft:stone
setblock 135 159 361 minecraft:stripped_spruce_log
fill 135 159 362 135 160 362 minecraft:stone
fill 95 160 323 95 160 324 minecraft:stone
setblock 95 160 325 minecraft:stripped_spruce_log
setblock 95 160 326 minecraft:stone
setblock 95 160 330 minecraft:stripped_spruce_log
fill 95 160 331 95 160 334 minecraft:stone
setblock 95 160 335 minecraft:stripped_spruce_log
fill 95 160 336 95 160 339 minecraft:stone
setblock 95 160 340 minecraft:stripped_spruce_log
fill 95 160 341 95 160 344 minecraft:stone
setblock 95 160 345 minecraft:stripped_spruce_log
setblock 95 160 346 minecraft:stone
setblock 95 160 350 minecraft:stripped_spruce_log
fill 95 160 351 95 160 354 minecraft:stone
setblock 95 160 355 minecraft:stripped_spruce_log
fill 96 160 324 96 161 324 minecraft:spruce_log
setblock 96 160 325 minecraft:stone
setblock 96 160 329 minecraft:stripped_spruce_log
fill 96 160 330 96 160 331 minecraft:stone
setblock 96 160 339 minecraft:stripped_spruce_log
setblock 96 160 340 minecraft:stone
fill 96 160 343 96 161 343 minecraft:spruce_log
setblock 96 160 344 minecraft:stripped_spruce_log
setblock 96 160 345 minecraft:stone
setblock 96 160 349 minecraft:stripped_spruce_log
setblock 96 160 350 minecraft:stone
fill 96 160 362 96 161 362 minecraft:spruce_log
setblock 97 160 323 minecraft:stripped_spruce_log
setblock 97 160 324 minecraft:stone
setblock 97 160 343 minecraft:stripped_spruce_log
fill 97 160 344 97 161 344 minecraft:stone
setblock 97 160 348 minecraft:stripped_spruce_log
fill 97 160 349 97 161 349 minecraft:stone
fill 98 160 323 101 160 323 minecraft:stone
fill 98 160 346 98 175 346 minecraft:iron_bars
fill 100 160 364 100 174 364 minecraft:deepslate
setblock 102 160 323 minecraft:stripped_spruce_log
fill 103 160 323 106 160 323 minecraft:stone
setblock 107 160 323 minecraft:stripped_spruce_log
fill 107 160 324 110 160 324 minecraft:stone
fill 108 160 323 111 160 323 minecraft:stone
setblock 109 160 325 minecraft:stone
setblock 110 160 325 minecraft:stripped_spruce_log
fill 110 160 363 111 160 363 minecraft:stone
setblock 111 160 324 minecraft:stripped_spruce_log
fill 111 160 325 111 163 325 minecraft:stone
setblock 112 160 323 minecraft:stripped_spruce_log
setblock 112 160 324 minecraft:stone
setblock 112 160 363 minecraft:stripped_spruce_log
setblock 113 160 323 minecraft:stone
setblock 113 160 326 minecraft:stone
setblock 113 160 362 minecraft:stripped_spruce_log
fill 113 160 363 116 160 363 minecraft:stone
setblock 114 160 326 minecraft:stripped_spruce_log
setblock 114 160 362 minecraft:stone
fill 115 160 324 115 161 324 minecraft:spruce_log
setblock 115 160 325 minecraft:stripped_spruce_log
fill 115 160 326 115 163 326 minecraft:stone
fill 115 160 362 115 161 362 minecraft:spruce_log
setblock 116 160 324 minecraft:stripped_spruce_log
fill 116 160 325 116 163 325 minecraft:stone
setblock 117 160 323 minecraft:stripped_spruce_log
setblock 117 160 324 minecraft:stone
setblock 117 160 363 minecraft:stripped_spruce_log
setblock 118 160 323 minecraft:stone
setblock 118 160 362 minecraft:stripped_spruce_log
fill 118 160 363 121 160 363 minecraft:stone
setblock 121 160 324 minecraft:stripped_spruce_log
setblock 122 160 323 minecraft:stripped_spruce_log
setblock 122 160 363 minecraft:stripped_spruce_log
setblock 123 160 323 minecraft:stone
setblock 123 160 363 minecraft:stone
setblock 127 160 323 minecraft:stripped_spruce_log
setblock 127 160 363 minecraft:stripped_spruce_log
setblock 128 160 323 minecraft:stone
setblock 128 160 363 minecraft:stone
setblock 132 160 323 minecraft:stripped_spruce_log
setblock 132 160 363 minecraft:stripped_spruce_log
setblock 133 160 323 minecraft:stone
setblock 133 160 347 minecraft:stripped_spruce_log
fill 133 160 348 133 163 348 minecraft:stone
setblock 133 160 352 minecraft:stripped_spruce_log
setblock 133 160 362 minecraft:stripped_spruce_log
setblock 133 160 363 minecraft:stone
fill 134 160 324 134 161 324 minecraft:spruce_log
setblock 134 160 326 minecraft:stripped_spruce_log
setblock 134 160 341 minecraft:stripped_spruce_log
setblock 134 160 342 minecraft:stone
fill 134 160 343 134 161 343 minecraft:spruce_log
setblock 134 160 346 minecraft:stripped_spruce_log
setblock 134 160 347 minecraft:stone
setblock 134 160 351 minecraft:stripped_spruce_log
setblock 134 160 352 minecraft:stone
setblock 134 160 356 minecraft:stripped_spruce_log
fill 134 160 362 134 161 362 minecraft:spruce_log
setblock 135 160 325 minecraft:stripped_spruce_log
setblock 135 160 326 minecraft:stone
setblock 135 160 330 minecraft:stripped_spruce_log
setblock 135 160 331 minecraft:stone
setblock 135 160 340 minecraft:stripped_spruce_log
setblock 135 160 341 minecraft:stone
setblock 135 160 345 minecraft:stripped_spruce_log
setblock 135 160 346 minecraft:stone
setblock 135 160 350 minecraft:stripped_spruce_log
setblock 135 160 351 minecraft:stone
setblock 135 160 355 minecraft:stripped_spruce_log
setblock 135 160 356 minecraft:stone
setblock 135 160 360 minecraft:stripped_spruce_log
setblock 135 160 361 minecraft:stone
fill 95 161 322 95 174 322 minecraft:deepslate
fill 95 161 323 95 161 363 minecraft:spruce_planks
setblock 96 161 322 minecraft:raw_gold_block
fill 96 161 323 135 161 323 minecraft:spruce_planks
fill 96 161 325 96 161 342 minecraft:spruce_planks
fill 96 161 344 96 161 361 minecraft:spruce_planks
fill 96 161 363 135 161 363 minecraft:spruce_planks
fill 97 161 324 114 161 324 minecraft:spruce_planks
setblock 97 161 343 minecraft:stone
setblock 97 161 347 minecraft:stripped_spruce_log
fill 97 161 348 97 163 348 minecraft:stone
fill 97 161 362 114 161 362 minecraft:spruce_planks
setblock 109 161 325 minecraft:stripped_spruce_log
fill 110 161 325 110 164 325 minecraft:stone
setblock 112 161 326 minecraft:stone
setblock 113 161 326 minecraft:stripped_spruce_log
setblock 114 161 325 minecraft:stripped_spruce_log
fill 114 161 326 114 164 326 minecraft:stone
fill 115 161 325 115 164 325 minecraft:stone
fill 116 161 324 133 161 324 minecraft:spruce_planks
fill 116 161 362 133 161 362 minecraft:spruce_planks
setblock 133 161 346 minecraft:stripped_spruce_log
fill 133 161 347 133 164 347 minecraft:stone
setblock 133 161 351 minecraft:stripped_spruce_log
fill 133 161 352 133 163 353 minecraft:stone
setblock 134 161 322 minecraft:gold_block
fill 134 161 325 135 161 342 minecraft:spruce_planks
fill 134 161 344 135 161 361 minecraft:spruce_planks
setblock 135 161 324 minecraft:spruce_planks
setblock 135 161 343 minecraft:spruce_planks
setblock 135 161 362 minecraft:spruce_planks
setblock 94 162 330 minecraft:raw_gold_block
setblock 94 162 336 minecraft:gold_block
setblock 95 162 323 minecraft:stripped_spruce_log
fill 95 162 324 95 162 327 minecraft:stone
setblock 95 162 328 minecraft:stripped_spruce_log
fill 95 162 329 95 162 332 minecraft:stone
setblock 95 162 333 minecraft:stripped_spruce_log
fill 95 162 334 95 162 337 minecraft:stone
setblock 95 162 338 minecraft:stripped_spruce_log
fill 95 162 339 95 162 342 minecraft:stone
setblock 95 162 343 minecraft:stripped_spruce_log
fill 95 162 344 95 162 347 minecraft:stone
setblock 95 162 348 minecraft:stripped_spruce_log
fill 95 162 349 95 162 352 minecraft:stone
setblock 95 162 353 minecraft:stripped_spruce_log
fill 95 162 354 95 163 356 minecraft:stone
fill 96 162 322 96 174 322 minecraft:deepslate
fill 96 162 323 96 162 326 minecraft:stone
setblock 96 162 327 minecraft:stripped_spruce_log
fill 96 162 328 96 162 331 minecraft:stone
setblock 96 162 332 minecraft:stripped_spruce_log
fill 96 162 333 96 163 335 minecraft:stone
fill 96 162 339 96 162 341 minecraft:stone
setblock 96 162 342 minecraft:stripped_spruce_log
fill 96 162 343 96 162 346 minecraft:stone
setblock 96 162 347 minecraft:stripped_spruce_log
fill 96 162 348 96 162 351 minecraft:stone
setblock 96 162 352 minecraft:stripped_spruce_log
fill 97 162 323 98 162 324 minecraft:stone
setblock 97 162 325 minecraft:light[level=15]
setblock 97 162 332 minecraft:light[level=12]
setblock 97 162 333 minecraft:light[level=15]
setblock 97 162 339 minecraft:light[level=12]
setblock 97 162 341 minecraft:light[level=15]
setblock 97 162 346 minecraft:stripped_spruce_log
fill 97 162 347 97 163 347 minecraft:stone
setblock 97 162 349 minecraft:light[level=15]
setblock 97 162 353 minecraft:light[level=12]
setblock 97 162 357 minecraft:light[level=15]
setblock 97 162 360 minecraft:light[level=12]
setblock 99 162 323 minecraft:stone
setblock 100 162 323 minecraft:stripped_spruce_log
fill 101 162 323 104 162 323 minecraft:stone
setblock 103 162 322 minecraft:raw_iron_block
setblock 104 162 325 minecraft:light[level=12]
setblock 104 162 332 minecraft:light[level=12]
setblock 104 162 339 minecraft:light[level=12]
setblock 104 162 346 minecraft:light[level=12]
setblock 104 162 353 minecraft:light[level=12]
setblock 104 162 360 minecraft:light[level=12]
setblock 105 162 323 minecraft:stripped_spruce_log
setblock 105 162 325 minecraft:light[level=15]
setblock 105 162 333 minecraft:light[level=15]
setblock 105 162 341 minecraft:light[level=15]
setblock 105 162 349 minecraft:light[level=15]
setblock 105 162 357 minecraft:light[level=15]
fill 106 162 323 108 162 324 minecraft:stone
setblock 106 162 364 minecraft:gold_block
setblock 108 162 325 minecraft:stripped_spruce_log
setblock 109 162 323 minecraft:stone
setblock 109 162 324 minecraft:stripped_spruce_log
fill 109 162 325 109 165 325 minecraft:stone
setblock 109 162 363 minecraft:stone
setblock 110 162 323 minecraft:stripped_spruce_log
fill 110 162 324 113 162 324 minecraft:stone
setblock 110 162 363 minecraft:stripped_spruce_log
fill 111 162 323 114 162 323 minecraft:stone
setblock 111 162 326 minecraft:stone
setblock 111 162 332 minecraft:light[level=12]
setblock 111 162 339 minecraft:light[level=12]
setblock 111 162 346 minecraft:light[level=12]
setblock 111 162 353 minecraft:light[level=12]
setblock 111 162 360 minecraft:light[level=12]
fill 111 162 363 114 162 363 minecraft:stone
setblock 112 162 326 minecraft:stripped_spruce_log
setblock 113 162 325 minecraft:stripped_spruce_log
fill 113 162 326 113 165 326 minecraft:stone
setblock 113 162 333 minecraft:light[level=15]
setblock 113 162 341 minecraft:light[level=15]
setblock 113 162 349 minecraft:light[level=15]
setblock 113 162 357 minecraft:light[level=15]
fill 113 162 362 115 162 362 minecraft:stone
setblock 114 162 324 minecraft:stripped_spruce_log
fill 114 162 325 114 165 325 minecraft:stone
setblock 115 162 323 minecraft:stripped_spruce_log
fill 115 162 324 118 162 324 minecraft:stone
setblock 115 162 363 minecraft:stripped_spruce_log
fill 116 162 323 119 162 323 minecraft:stone
setblock 116 162 362 minecraft:stripped_spruce_log
fill 116 162 363 119 162 363 minecraft:stone
setblock 118 162 325 minecraft:stripped_spruce_log
setblock 118 162 332 minecraft:light[level=12]
setblock 118 162 339 minecraft:light[level=12]
setblock 118 162 346 minecraft:light[level=12]
setblock 118 162 353 minecraft:light[level=12]
setblock 118 162 360 minecraft:light[level=12]
setblock 119 162 324 minecraft:stripped_spruce_log
setblock 120 162 323 minecraft:stripped_spruce_log
setblock 120 162 324 minecraft:stone
setblock 120 162 363 minecraft:stripped_spruce_log
fill 121 162 323 123 162 323 minecraft:stone
setblock 121 162 325 minecraft:light[level=15]
setblock 121 162 333 minecraft:light[level=15]
setblock 121 162 341 minecraft:light[level=15]
setblock 121 162 349 minecraft:light[level=15]
setblock 121 162 357 minecraft:light[level=15]
fill 121 162 363 122 162 363 minecraft:stone
setblock 125 162 325 minecraft:light[level=12]
setblock 125 162 332 minecraft:light[level=12]
setblock 125 162 339 minecraft:light[level=12]
setblock 125 162 346 minecraft:light[level=12]
setblock 125 162 353 minecraft:light[level=12]
setblock 125 162 360 minecraft:light[level=12]
fill 127 162 323 129 162 323 minecraft:stone
fill 127 162 363 129 162 363 minecraft:stone
setblock 129 162 325 minecraft:light[level=15]
setblock 129 162 333 minecraft:light[level=15]
setblock 129 162 341 minecraft:light[level=15]
setblock 129 162 349 minecraft:light[level=15]
setblock 129 162 357 minecraft:light[level=15]
setblock 130 162 323 minecraft:stripped_spruce_log
setblock 130 162 363 minecraft:stripped_spruce_log
fill 131 162 323 134 162 323 minecraft:stone
fill 131 162 363 134 162 363 minecraft:stone
fill 132 162 324 133 162 324 minecraft:stone
setblock 132 162 325 minecraft:light[level=12]
setblock 132 162 332 minecraft:light[level=12]
setblock 132 162 339 minecraft:light[level=12]
setblock 132 162 346 minecraft:light[level=12]
fill 132 162 347 132 162 350 minecraft:stone
setblock 132 162 351 minecraft:stripped_spruce_log
setblock 132 162 353 minecraft:light[level=12]
setblock 132 162 360 minecraft:light[level=12]
fill 133 162 343 134 162 343 minecraft:stone
setblock 133 162 345 minecraft:stripped_spruce_log
fill 133 162 346 135 163 346 minecraft:stone
setblock 133 162 350 minecraft:stripped_spruce_log
fill 133 162 351 135 163 351 minecraft:stone
setblock 133 162 354 minecraft:stone
fill 134 162 322 134 166 322 minecraft:deepslate
setblock 134 162 324 minecraft:stripped_spruce_log
fill 134 162 325 134 162 328 minecraft:stone
setblock 134 162 329 minecraft:stripped_spruce_log
fill 134 162 341 135 162 342 minecraft:stone
setblock 134 162 344 minecraft:stripped_spruce_log
fill 134 162 345 135 164 345 minecraft:stone
fill 134 162 347 134 162 348 minecraft:stone
setblock 134 162 349 minecraft:stripped_spruce_log
fill 134 162 350 135 164 350 minecraft:stone
fill 134 162 352 134 162 353 minecraft:stone
setblock 134 162 354 minecraft:stripped_spruce_log
fill 134 162 355 135 162 357 minecraft:stone
setblock 135 162 323 minecraft:stripped_spruce_log
fill 135 162 324 135 162 327 minecraft:stone
setblock 135 162 328 minecraft:stripped_spruce_log
fill 135 162 329 135 162 332 minecraft:stone
setblock 135 162 333 minecraft:stripped_spruce_log
fill 135 162 334 135 162 337 minecraft:stone
setblock 135 162 338 minecraft:stripped_spruce_log
fill 135 162 339 135 164 340 minecraft:stone
setblock 135 162 343 minecraft:stripped_spruce_log
fill 135 162 344 135 165 344 minecraft:stone
setblock 135 162 347 minecraft:stone
setblock 135 162 348 minecraft:stripped_spruce_log
fill 135 162 349 135 165 349 minecraft:stone
setblock 135 162 352 minecraft:stone
setblock 135 162 353 minecraft:stripped_spruce_log
fill 135 162 354 135 165 354 minecraft:stone
setblock 135 162 358 minecraft:stripped_spruce_log
fill 135 162 359 135 162 362 minecraft:stone
setblock 135 162 363 minecraft:stripped_spruce_log
setblock 136 162 357 minecraft:raw_iron_block
fill 94 163 330 94 174 330 minecraft:deepslate
fill 94 163 336 94 174 336 minecraft:deepslate
fill 95 163 323 95 163 326 minecraft:stone
setblock 95 163 327 minecraft:stripped_spruce_log
fill 95 163 328 95 163 331 minecraft:stone
setblock 95 163 332 minecraft:stripped_spruce_log
fill 95 163 333 95 163 336 minecraft:stone
setblock 95 163 337 minecraft:stripped_spruce_log
fill 95 163 338 95 163 341 minecraft:stone
setblock 95 163 342 minecraft:stripped_spruce_log
fill 95 163 343 95 163 346 minecraft:stone
setblock 95 163 347 minecraft:stripped_spruce_log
fill 95 163 348 95 163 351 minecraft:stone
setblock 95 163 352 minecraft:stripped_spruce_log
fill 95 163 353 96 165 353 minecraft:stone
fill 96 163 323 96 163 325 minecraft:stone
setblock 96 163 326 minecraft:stripped_spruce_log
fill 96 163 327 96 163 330 minecraft:stone
setblock 96 163 331 minecraft:stripped_spruce_log
fill 96 163 332 96 166 332 minecraft:stone
setblock 96 163 336 minecraft:stripped_spruce_log
fill 96 163 337 96 163 340 minecraft:stone
setblock 96 163 341 minecraft:stripped_spruce_log
fill 96 163 342 96 163 345 minecraft:stone
setblock 96 163 346 minecraft:stripped_spruce_log
fill 96 163 347 96 163 350 minecraft:stone
setblock 96 163 351 minecraft:stripped_spruce_log
fill 96 163 352 96 166 352 minecraft:stone
fill 97 163 323 97 163 324 minecraft:stone
fill 97 163 327 97 163 329 minecraft:stone
setblock 97 163 330 minecraft:stripped_spruce_log
setblock 97 163 346 minecraft:stone
setblock 98 163 323 minecraft:stone
setblock 99 163 323 minecraft:stripped_spruce_log
fill 100 163 323 103 163 323 minecraft:stone
fill 103 163 322 103 174 322 minecraft:deepslate
setblock 104 163 323 minecraft:stripped_spruce_log
fill 105 163 323 107 163 324 minecraft:stone
fill 106 163 364 106 174 364 minecraft:deepslate
setblock 107 163 325 minecraft:stripped_spruce_log
setblock 108 163 323 minecraft:stone
setblock 108 163 324 minecraft:stripped_spruce_log
fill 108 163 325 108 166 325 minecraft:stone
setblock 109 163 323 minecraft:stripped_spruce_log
fill 109 163 324 112 163 324 minecraft:stone
fill 109 163 326 110 163 326 minecraft:stone
setblock 109 163 363 minecraft:stripped_spruce_log
fill 110 163 323 113 163 323 minecraft:stone
fill 110 163 363 113 163 363 minecraft:stone
setblock 111 163 326 minecraft:stripped_spruce_log
setblock 112 163 325 minecraft:stripped_spruce_log
fill 112 163 326 112 166 326 minecraft:stone
fill 112 163 362 114 163 362 minecraft:stone
setblock 113 163 324 minecraft:stripped_spruce_log
fill 113 163 325 113 166 325 minecraft:stone
setblock 114 163 323 minecraft:stripped_spruce_log
fill 114 163 324 117 163 324 minecraft:stone
setblock 114 163 363 minecraft:stripped_spruce_log
fill 115 163 323 118 163 323 minecraft:stone
fill 115 163 355 115 163 362 minecraft:stripped_spruce_log
fill 115 163 363 118 163 363 minecraft:stone
fill 116 163 360 116 164 361 minecraft:stripped_spruce_log
fill 116 163 362 116 166 362 minecraft:stone
setblock 117 163 325 minecraft:stripped_spruce_log
setblock 118 163 324 minecraft:stripped_spruce_log
setblock 119 163 323 minecraft:stripped_spruce_log
fill 119 163 324 119 164 324 minecraft:stone
setblock 119 163 363 minecraft:stripped_spruce_log
fill 120 163 323 122 164 323 minecraft:stone
fill 120 163 363 121 165 363 minecraft:stone
fill 126 163 363 128 163 363 minecraft:stone
fill 127 163 323 128 163 323 minecraft:stone
setblock 129 163 323 minecraft:stripped_spruce_log
setblock 129 163 363 minecraft:stripped_spruce_log
fill 130 163 323 133 163 323 minecraft:stone
fill 130 163 363 133 163 363 minecraft:stone
fill 131 163 324 132 163 324 minecraft:stone
fill 132 163 346 132 163 349 minecraft:stone
setblock 132 163 350 minecraft:stripped_spruce_log
fill 132 163 351 132 165 352 minecraft:stone
setblock 133 163 324 minecraft:stripped_spruce_log
setblock 133 163 343 minecraft:stone
setblock 133 163 344 minecraft:stripped_spruce_log
fill 133 163 345 133 166 345 minecraft:stone
setblock 133 163 349 minecraft:stripped_spruce_log
fill 133 163 350 133 166 350 minecraft:stone
setblock 133 163 354 minecraft:stripped_spruce_log
fill 133 163 355 135 164 355 minecraft:stone
setblock 134 163 323 minecraft:stripped_spruce_log
fill 134 163 324 134 163 327 minecraft:stone
setblock 134 163 328 minecraft:stripped_spruce_log
fill 134 163 329 134 163 332 minecraft:stone
fill 134 163 340 134 163 342 minecraft:stone
setblock 134 163 343 minecraft:stripped_spruce_log
fill 134 163 344 134 166 344 minecraft:stone
setblock 134 163 347 minecraft:stone
setblock 134 163 348 minecraft:stripped_spruce_log
fill 134 163 349 134 166 349 minecraft:stone
setblock 134 163 352 minecraft:stone
setblock 134 163 353 minecraft:stripped_spruce_log
fill 134 163 354 134 166 354 minecraft:stone
fill 134 163 356 134 163 357 minecraft:stone
setblock 134 163 358 minecraft:stripped_spruce_log
setblock 134 163 363 minecraft:stripped_spruce_log
fill 135 163 323 135 163 326 minecraft:stone
setblock 135 163 327 minecraft:stripped_spruce_log
fill 135 163 328 135 163 331 minecraft:stone
setblock 135 163 332 minecraft:stripped_spruce_log
fill 135 163 333 135 163 336 minecraft:stone
setblock 135 163 337 minecraft:stripped_spruce_log
fill 135 163 338 135 166 338 minecraft:stone
setblock 135 163 341 minecraft:stone
setblock 135 163 342 minecraft:stripped_spruce_log
fill 135 163 343 135 166 343 minecraft:stone
setblock 135 163 347 minecraft:stripped_spruce_log
fill 135 163 348 135 166 348 minecraft:stone
setblock 135 163 352 minecraft:stripped_spruce_log
fill 135 163 353 135 166 353 minecraft:stone
setblock 135 163 356 minecraft:stone
setblock 135 163 357 minecraft:stripped_spruce_log
fill 135 163 358 135 163 361 minecraft:stone
setblock 135 163 362 minecraft:stripped_spruce_log
fill 135 163 363 135 165 363 minecraft:stone
setblock 136 163 323 minecraft:gold_block
fill 136 163 357 136 170 357 minecraft:deepslate
fill 95 164 323 95 164 325 minecraft:stone
setblock 95 164 326 minecraft:stripped_spruce_log
fill 95 164 327 95 164 330 minecraft:stone
setblock 95 164 331 minecraft:stripped_spruce_log
fill 95 164 332 95 164 335 minecraft:stone
setblock 95 164 336 minecraft:stripped_spruce_log
fill 95 164 337 95 164 340 minecraft:stone
setblock 95 164 341 minecraft:stripped_spruce_log
fill 95 164 342 95 164 345 minecraft:stone
setblock 95 164 346 minecraft:stripped_spruce_log
fill 95 164 347 95 164 350 minecraft:stone
setblock 95 164 351 minecraft:stripped_spruce_log
fill 95 164 352 95 167 352 minecraft:stone
fill 95 164 354 95 164 355 minecraft:stone
setblock 95 164 356 minecraft:stripped_spruce_log
fill 95 164 357 95 167 357 minecraft:stone
fill 96 164 323 96 164 324 minecraft:stone
setblock 96 164 325 minecraft:stripped_spruce_log
fill 96 164 326 96 164 329 minecraft:stone
setblock 96 164 330 minecraft:stripped_spruce_log
fill 96 164 331 97 166 331 minecraft:stone
fill 96 164 333 96 164 334 minecraft:stone
setblock 96 164 335 minecraft:stripped_spruce_log
fill 96 164 336 96 164 339 minecraft:stone
setblock 96 164 340 minecraft:stripped_spruce_log
fill 96 164 341 96 164 344 minecraft:stone
setblock 96 164 345 minecraft:stripped_spruce_log
fill 96 164 346 96 164 349 minecraft:stone
setblock 96 164 350 minecraft:stripped_spruce_log
fill 96 164 351 96 167 351 minecraft:stone
setblock 97 164 323 minecraft:stone
setblock 97 164 324 minecraft:stripped_spruce_log
fill 97 164 327 97 164 328 minecraft:stone
setblock 97 164 329 minecraft:stripped_spruce_log
fill 97 164 330 97 167 330 minecraft:stone
fill 97 164 332 97 165 332 minecraft:stone
setblock 98 164 323 minecraft:stripped_spruce_log
fill 99 164 323 102 164 323 minecraft:stone
setblock 103 164 323 minecraft:stripped_spruce_log
fill 104 164 323 106 164 324 minecraft:stone
setblock 106 164 325 minecraft:stripped_spruce_log
setblock 107 164 323 minecraft:stone
setblock 107 164 324 minecraft:stripped_spruce_log
fill 107 164 325 107 167 325 minecraft:stone
setblock 108 164 323 minecraft:stripped_spruce_log
fill 108 164 324 111 164 324 minecraft:stone
fill 108 164 326 109 164 326 minecraft:stone
setblock 108 164 363 minecraft:stripped_spruce_log
fill 109 164 323 112 164 323 minecraft:stone
fill 109 164 363 112 164 363 minecraft:stone
setblock 110 164 326 minecraft:stripped_spruce_log
setblock 111 164 325 minecraft:stripped_spruce_log
fill 111 164 326 111 167 326 minecraft:stone
fill 111 164 362 113 164 362 minecraft:stone
setblock 112 164 324 minecraft:stripped_spruce_log
fill 112 164 325 112 167 325 minecraft:stone
fill 112 164 333 112 165 336 minecraft:stripped_spruce_log
setblock 113 164 323 minecraft:stripped_spruce_log
fill 113 164 324 116 164 324 minecraft:stone
fill 113 164 343 113 164 349 minecraft:stripped_spruce_log
setblock 113 164 363 minecraft:stripped_spruce_log
fill 114 164 323 117 164 323 minecraft:stone
fill 114 164 344 114 164 357 minecraft:stripped_spruce_log
setblock 114 164 362 minecraft:stripped_spruce_log
fill 114 164 363 117 164 363 minecraft:stone
setblock 115 164 326 minecraft:stripped_spruce_log
fill 115 164 350 115 164 361 minecraft:stripped_spruce_log
fill 115 164 362 115 167 362 minecraft:stone
setblock 116 164 325 minecraft:stripped_spruce_log
fill 116 164 358 116 164 359 minecraft:stripped_spruce_log
setblock 117 164 324 minecraft:stripped_spruce_log
setblock 117 164 325 minecraft:stone
setblock 118 164 323 minecraft:stripped_spruce_log
fill 118 164 324 118 166 324 minecraft:stone
setblock 118 164 363 minecraft:stripped_spruce_log
fill 119 164 323 119 167 323 minecraft:stone
fill 119 164 363 119 167 363 minecraft:stone
fill 125 164 363 127 164 363 minecraft:stone
fill 126 164 323 127 164 323 minecraft:stone
setblock 128 164 323 minecraft:stripped_spruce_log
setblock 128 164 363 minecraft:stripped_spruce_log
fill 129 164 323 132 164 323 minecraft:stone
fill 129 164 363 132 164 363 minecraft:stone
fill 130 164 324 131 164 324 minecraft:stone
setblock 132 164 324 minecraft:stripped_spruce_log
fill 132 164 346 132 164 348 minecraft:stone
setblock 132 164 349 minecraft:stripped_spruce_log
fill 132 164 350 132 167 350 minecraft:stone
setblock 132 164 353 minecraft:stone
setblock 132 164 354 minecraft:stripped_spruce_log
setblock 133 164 323 minecraft:stripped_spruce_log
fill 133 164 324 135 165 324 minecraft:stone
setblock 133 164 343 minecraft:stripped_spruce_log
fill 133 164 344 133 167 344 minecraft:stone
fill 133 164 346 134 164 346 minecraft:stone
setblock 133 164 348 minecraft:stripped_spruce_log
fill 133 164 349 133 167 349 minecraft:stone
fill 133 164 351 133 164 352 minecraft:stone
setblock 133 164 353 minecraft:stripped_spruce_log
fill 133 164 354 133 167 354 minecraft:stone
fill 133 164 356 134 164 356 minecraft:stone
setblock 133 164 363 minecraft:stripped_spruce_log
fill 134 164 323 135 166 323 minecraft:stone
fill 134 164 325 134 164 326 minecraft:stone
setblock 134 164 327 minecraft:stripped_spruce_log
fill 134 164 328 134 164 331 minecraft:stone
setblock 134 164 332 minecraft:stripped_spruce_log
fill 134 164 333 135 165 334 minecraft:stone
fill 134 164 340 134 164 341 minecraft:stone
setblock 134 164 342 minecraft:stripped_spruce_log
fill 134 164 343 134 167 343 minecraft:stone
setblock 134 164 347 minecraft:stripped_spruce_log
fill 134 164 348 134 167 348 minecraft:stone
setblock 134 164 351 minecraft:stone
setblock 134 164 352 minecraft:stripped_spruce_log
fill 134 164 353 134 167 353 minecraft:stone
setblock 134 164 357 minecraft:stripped_spruce_log
fill 134 164 358 135 166 358 minecraft:stone
fill 134 164 363 134 167 363 minecraft:stone
setblock 135 164 322 minecraft:raw_gold_block
setblock 135 164 325 minecraft:stone
setblock 135 164 326 minecraft:stripped_spruce_log
fill 135 164 327 135 164 330 minecraft:stone
setblock 135 164 331 minecraft:stripped_spruce_log
fill 135 164 332 135 167 332 minecraft:stone
setblock 135 164 335 minecraft:stone
setblock 135 164 336 minecraft:stripped_spruce_log
fill 135 164 337 135 167 337 minecraft:stone
setblock 135 164 341 minecraft:stripped_spruce_log
fill 135 164 342 135 167 342 minecraft:stone
setblock 135 164 346 minecraft:stripped_spruce_log
fill 135 164 347 135 167 347 minecraft:stone
setblock 135 164 351 minecraft:stripped_spruce_log
fill 135 164 352 135 167 352 minecraft:stone
setblock 135 164 356 minecraft:stripped_spruce_log
fill 135 164 357 135 167 357 minecraft:stone
fill 135 164 359 135 164 360 minecraft:stone
setblock 135 164 361 minecraft:stripped_spruce_log
fill 135 164 362 135 166 362 minecraft:stone
fill 136 164 323 136 174 323 minecraft:deepslate
setblock 136 164 331 minecraft:raw_iron_block
setblock 136 164 360 minecraft:diamond_block
fill 95 165 323 95 165 324 minecraft:stone
setblock 95 165 325 minecraft:stripped_spruce_log
fill 95 165 326 95 165 329 minecraft:stone
setblock 95 165 330 minecraft:stripped_spruce_log
fill 95 165 331 95 165 334 minecraft:stone
setblock 95 165 335 minecraft:stripped_spruce_log
fill 95 165 336 95 165 339 minecraft:stone
setblock 95 165 340 minecraft:stripped_spruce_log
fill 95 165 341 95 165 344 minecraft:stone
setblock 95 165 345 minecraft:stripped_spruce_log
fill 95 165 346 95 165 349 minecraft:stone
setblock 95 165 350 minecraft:stripped_spruce_log
fill 95 165 351 95 168 351 minecraft:stone
setblock 95 165 354 minecraft:stone
setblock 95 165 355 minecraft:stripped_spruce_log
fill 95 165 356 95 168 356 minecraft:stone
setblock 96 165 323 minecraft:stone
setblock 96 165 324 minecraft:stripped_spruce_log
fill 96 165 325 96 165 328 minecraft:stone
setblock 96 165 329 minecraft:stripped_spruce_log
fill 96 165 330 96 168 330 minecraft:stone
setblock 96 165 333 minecraft:stone
setblock 96 165 334 minecraft:stripped_spruce_log
fill 96 165 335 96 165 338 minecraft:stone
setblock 96 165 339 minecraft:stripped_spruce_log
fill 96 165 340 96 165 343 minecraft:stone
setblock 96 165 344 minecraft:stripped_spruce_log
fill 96 165 345 96 165 348 minecraft:stone
setblock 96 165 349 minecraft:stripped_spruce_log
fill 96 165 350 96 168 350 minecraft:stone
setblock 96 165 354 minecraft:stripped_spruce_log
setblock 97 165 323 minecraft:stripped_spruce_log
setblock 97 165 324 minecraft:stone
setblock 97 165 327 minecraft:stone
setblock 97 165 328 minecraft:stripped_spruce_log
fill 97 165 329 97 168 329 minecraft:stone
setblock 97 165 333 minecraft:stripped_spruce_log
fill 98 165 323 101 165 323 minecraft:stone
setblock 102 165 323 minecraft:stripped_spruce_log
fill 103 165 323 106 165 323 minecraft:stone
fill 104 165 324 105 165 324 minecraft:stone
setblock 106 165 324 minecraft:stripped_spruce_log
fill 106 165 325 106 168 325 minecraft:stone
setblock 107 165 323 minecraft:stripped_spruce_log
fill 107 165 324 110 165 324 minecraft:stone
setblock 107 165 363 minecraft:stripped_spruce_log
fill 108 165 323 111 165 323 minecraft:stone
setblock 108 165 326 minecraft:stone
fill 108 165 363 111 165 363 minecraft:stone
setblock 109 165 326 minecraft:stripped_spruce_log
setblock 110 165 325 minecraft:stripped_spruce_log
fill 110 165 326 110 168 326 minecraft:stone
fill 110 165 362 112 165 362 minecraft:stone
setblock 111 165 324 minecraft:stripped_spruce_log
fill 111 165 325 111 168 325 minecraft:stone
fill 111 165 327 111 165 334 minecraft:stripped_spruce_log
setblock 112 165 323 minecraft:stripped_spruce_log
fill 112 165 324 115 165 324 minecraft:stone
fill 112 165 328 112 165 332 minecraft:stripped_spruce_log
fill 112 165 360 112 181 360 minecraft:iron_bars
setblock 112 165 363 minecraft:stripped_spruce_log
fill 113 165 323 116 165 323 minecraft:stone
fill 113 165 335 113 165 336 minecraft:stripped_spruce_log
fill 113 165 343 113 165 347 minecraft:stripped_spruce_log
setblock 113 165 362 minecraft:stripped_spruce_log
fill 113 165 363 116 165 363 minecraft:stone
setblock 114 165 326 minecraft:stripped_spruce_log
fill 114 165 344 114 165 351 minecraft:stripped_spruce_log
setblock 114 165 352 minecraft:stripped_dark_oak_log
fill 114 165 362 114 168 362 minecraft:stone
setblock 115 165 325 minecraft:stripped_spruce_log
fill 115 165 354 115 165 361 minecraft:stripped_dark_oak_log
setblock 116 165 324 minecraft:stripped_spruce_log
fill 116 165 325 116 166 325 minecraft:stone
setblock 116 165 361 minecraft:stripped_dark_oak_log
setblock 117 165 323 minecraft:stripped_spruce_log
fill 117 165 324 117 167 324 minecraft:stone
setblock 117 165 363 minecraft:stripped_spruce_log
fill 118 165 323 118 167 323 minecraft:stone
fill 118 165 363 118 168 363 minecraft:stone
fill 120 165 323 121 165 323 minecraft:stone
fill 125 165 363 126 165 363 minecraft:stone
setblock 126 165 323 minecraft:stone
setblock 127 165 323 minecraft:stripped_spruce_log
setblock 127 165 363 minecraft:stripped_spruce_log
fill 128 165 323 131 165 323 minecraft:stone
fill 128 165 363 131 165 363 minecraft:stone
setblock 130 165 324 minecraft:stone
fill 130 165 347 131 166 347 minecraft:raw_gold_block
fill 130 165 362 131 166 362 minecraft:stone
setblock 131 165 324 minecraft:stripped_spruce_log
fill 131 165 346 131 166 346 minecraft:raw_gold_block
fill 131 165 348 131 166 348 minecraft:raw_gold_block
setblock 131 165 349 minecraft:stripped_spruce_log
fill 131 165 350 131 166 352 minecraft:stone
setblock 132 165 323 minecraft:stripped_spruce_log
fill 132 165 324 132 166 324 minecraft:stone
fill 132 165 345 132 165 347 minecraft:stone
setblock 132 165 348 minecraft:stripped_spruce_log
fill 132 165 349 132 168 349 minecraft:stone
setblock 132 165 353 minecraft:stripped_spruce_log
fill 132 165 354 132 167 355 minecraft:stone
setblock 132 165 363 minecraft:stripped_spruce_log
fill 133 165 323 133 168 323 minecraft:stone
fill 133 165 328 133 165 331 minecraft:stone
fill 133 165 343 133 167 343 minecraft:stone
setblock 133 165 346 minecraft:stone
setblock 133 165 347 minecraft:stripped_spruce_log
fill 133 165 348 133 168 348 minecraft:stone
setblock 133 165 351 minecraft:stone
setblock 133 165 352 minecraft:stripped_spruce_log
fill 133 165 353 133 168 353 minecraft:stone
fill 133 165 355 133 165 356 minecraft:stone
setblock 133 165 357 minecraft:stripped_spruce_log
fill 133 165 363 133 168 363 minecraft:stone
setblock 134 165 325 minecraft:stone
setblock 134 165 326 minecraft:stripped_spruce_log
fill 134 165 327 134 165 330 minecraft:stone
setblock 134 165 331 minecraft:stripped_spruce_log
fill 134 165 332 134 168 332 minecraft:stone
setblock 134 165 335 minecraft:stone
setblock 134 165 336 minecraft:stripped_spruce_log
fill 134 165 337 134 165 340 minecraft:stone
setblock 134 165 341 minecraft:stripped_spruce_log
fill 134 165 342 134 168 342 minecraft:stone
setblock 134 165 345 minecraft:stone
setblock 134 165 346 minecraft:stripped_spruce_log
fill 134 165 347 134 168 347 minecraft:stone
setblock 134 165 350 minecraft:stone
setblock 134 165 351 minecraft:stripped_spruce_log
fill 134 165 352 134 168 352 minecraft:stone
setblock 134 165 355 minecraft:stone
setblock 134 165 356 minecraft:stripped_spruce_log
fill 134 165 357 134 168 357 minecraft:stone
fill 134 165 359 135 165 359 minecraft:stone
fill 135 165 322 135 174 322 minecraft:deepslate
setblock 135 165 325 minecraft:stripped_spruce_log
fill 135 165 326 135 165 329 minecraft:stone
setblock 135 165 330 minecraft:stripped_spruce_log
fill 135 165 331 135 168 331 minecraft:stone
setblock 135 165 335 minecraft:stripped_spruce_log
fill 135 165 336 135 168 336 minecraft:stone
setblock 135 165 339 minecraft:stone
setblock 135 165 340 minecraft:stripped_spruce_log
schedule function dropper:buildpart/74_5 1t
