scoreboard objectives add dp_level dummy {"text":"LEVEL","color":"gold","bold":true}
scoreboard objectives add dp_fails dummy
scoreboard objectives add dp_grace dummy
scoreboard objectives add dp_cfg dummy
scoreboard objectives add dp_deaths deathCount
scoreboard objectives add dp_stage dummy
scoreboard objectives add dp_pstage dummy
scoreboard objectives add dp_wins dummy
scoreboard objectives add dp_tmp dummy
scoreboard players set #max dp_cfg 103
scoreboard players set #min dp_cfg -11
execute unless score #hardcore dp_cfg = #hardcore dp_cfg run scoreboard players set #hardcore dp_cfg 0
execute unless score #platform dp_cfg = #platform dp_cfg run scoreboard players set #platform dp_cfg 0
function dropper:rt/load
