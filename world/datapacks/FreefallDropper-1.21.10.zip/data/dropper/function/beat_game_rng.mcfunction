scoreboard players set @s dp_level 103
function dropper:victory
execute if score #aftermode dp_cfg matches 0 run function rngwin:enter_win
execute if score #aftermode dp_cfg matches 0 at @s run return run function dropper:victory_sfx
scoreboard players operation @s dp_level = #startlevel dp_cfg
function dropper:move/apply
function rngwin:enter_win
execute at @s run function dropper:victory_sfx
