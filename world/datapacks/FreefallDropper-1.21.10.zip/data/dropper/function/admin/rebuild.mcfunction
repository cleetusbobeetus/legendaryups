$scoreboard players set #rb dp_ev $(level)
execute unless score #rb dp_ev matches -11..100 run return run tellraw @s {"text":"[Freefall] Level must be -11..100. Level 100 stages: /function dropper:admin/rebuild_stage {n:2}","color":"red"}
$function dropper:rebuild/l$(level)
