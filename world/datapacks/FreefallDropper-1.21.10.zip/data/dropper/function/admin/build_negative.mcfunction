execute if score #rbneg dp_ev matches 1 run return run tellraw @s {"text":"[Freefall] negative build already running","color":"red"}
scoreboard players set #rbneg dp_ev 1
tellraw @s {"text":"[Freefall] Building the 11 negative dungeon levels -11..-1 (staggered, about 60 s). Levels 1-100 are not touched. Keep players out of them.","color":"yellow"}
schedule function dropper:rebuild/l-11 20t
schedule function dropper:rebuild/l-10 120t
schedule function dropper:rebuild/l-9 220t
schedule function dropper:rebuild/l-8 320t
schedule function dropper:rebuild/l-7 420t
schedule function dropper:rebuild/l-6 520t
schedule function dropper:rebuild/l-5 620t
schedule function dropper:rebuild/l-4 720t
schedule function dropper:rebuild/l-3 820t
schedule function dropper:rebuild/l-2 920t
schedule function dropper:rebuild/l-1 1020t
schedule function dropper:rebuild/neg_done 1320t
