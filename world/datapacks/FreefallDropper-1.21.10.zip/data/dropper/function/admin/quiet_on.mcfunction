gamerule sendCommandFeedback false
scoreboard players set #cmdfeedback dp_cfg 0
tellraw @s {"text":"[Freefall] command feedback OFF (no more Running function ... lines). Errors still go to the server console.","color":"green"}
