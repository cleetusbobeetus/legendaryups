function dropper:admin/test_begin
$scoreboard players set @s dp_level $(n)
execute unless score @s dp_level matches 1..4 run scoreboard players set @s dp_level 1
scoreboard players add @s dp_level 99
scoreboard players set @s dp_plevel -999
execute if score @s dp_level matches 101.. run scoreboard players set @s dp_plevel 100
function dropper:move/apply
