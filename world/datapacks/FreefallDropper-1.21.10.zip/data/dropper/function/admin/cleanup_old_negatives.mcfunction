execute if score #negclean dp_ev matches 1 run return run tellraw @s {"text":"[Freefall] cleanup already running","color":"red"}
scoreboard players set #negclean dp_ev 1
tellraw @s {"text":"[Freefall] Clearing the unused old negative rooms -50..-12 (about 117 s). Levels -11..100 are not touched.","color":"yellow"}
function dropper:cleanup/n-50
