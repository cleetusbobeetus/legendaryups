gamerule sendCommandFeedback true
scoreboard players set #cmdfeedback dp_cfg 1
tellraw @s {"text":"[Freefall] command feedback ON (admin diagnostics).","color":"yellow"}
