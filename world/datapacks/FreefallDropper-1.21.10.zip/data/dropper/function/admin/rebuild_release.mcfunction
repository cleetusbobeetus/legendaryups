execute if score #rbrel dp_ev matches 1 run return run tellraw @s {"text":"[Freefall] A release rebuild is already running - wait for Level 103 rebuilt.","color":"red"}
scoreboard players set #rbrel dp_ev 1
schedule function dropper:rebuild/release_done 1020t
tellraw @s {"text":"[Freefall] Rebuilding the 8 changed rooms 95, 96, 97, 98, 99, 101, 102, 103 (101-103 = Level 100 stages 2-4; staggered, about 40 s). Keep players out of them.","color":"yellow"}
schedule function dropper:rebuild/l95 20t
schedule function dropper:rebuild/l96 120t
schedule function dropper:rebuild/l97 220t
schedule function dropper:rebuild/l98 320t
schedule function dropper:rebuild/l99 420t
schedule function dropper:rebuild/l101 520t
schedule function dropper:rebuild/l102 620t
schedule function dropper:rebuild/l103 720t
